
;try {

;(function () { /* LIBRARY_CLOSURE_START () */


            let getGlobalVar = "getCloudSDKGlobalVar"
            let sdkSubpakcageGlobalVarGetter
            if(globalThis[getGlobalVar]) {
              sdkSubpakcageGlobalVarGetter = globalThis[getGlobalVar]
            } else if(typeof globalThis.WeixinJSBridge !== "undefined" && globalThis.WeixinJSBridge[getGlobalVar]){
              sdkSubpakcageGlobalVarGetter = globalThis.WeixinJSBridge[getGlobalVar]
            }
            var {WeixinJSBridge,wxConsole,Reporter,console,__appServiceSDK__,__wxConfig,Foundation,IS_APP,__subContextEngine__} = sdkSubpakcageGlobalVarGetter();
          

/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 515:
/***/ ((module) => {

function asyncGeneratorStep(n, t, e, r, o, a, c) {
  try {
    var i = n[a](c),
      u = i.value;
  } catch (n) {
    return void e(n);
  }
  i.done ? t(u) : Promise.resolve(u).then(r, o);
}
function _asyncToGenerator(n) {
  return function () {
    var t = this,
      e = arguments;
    return new Promise(function (r, o) {
      var a = n.apply(t, e);
      function _next(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
      }
      function _throw(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
      }
      _next(void 0);
    });
  };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V1: () => (/* binding */ hn),
/* harmony export */   V3: () => (/* binding */ wn),
/* harmony export */   e: () => (/* binding */ jn),
/* harmony export */   h: () => (/* binding */ Ue)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(515);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);

var Dn = Object.create;
var ft = Object.defineProperty;
var qn = Object.getOwnPropertyDescriptor;
var Gn = Object.getOwnPropertyNames;
var xn = Object.getPrototypeOf,
  kn = Object.prototype.hasOwnProperty;
var Ln = (n, r) => () => (n && (r = n(n = 0)), r);
var q = (n, r) => () => (r || n((r = {
    exports: {}
  }).exports, r), r.exports),
  kt = (n, r) => {
    for (var e in r) ft(n, e, {
      get: r[e],
      enumerable: !0
    });
  },
  Mn = (n, r, e, t) => {
    if (r && typeof r == "object" || typeof r == "function") {
      var _loop = function (i) {
        !kn.call(n, i) && i !== e && ft(n, i, {
          get: () => r[i],
          enumerable: !(t = qn(r, i)) || t.enumerable
        });
      };
      for (var i of Gn(r)) {
        _loop(i);
      }
    }
    return n;
  };
var Le = (n, r, e) => (e = n != null ? Dn(xn(n)) : {}, Mn(r || !n || !n.__esModule ? ft(e, "default", {
  value: n,
  enumerable: !0
}) : e, n));
var h = Ln(() => {});
var Vt = q(Xt => {
  "use strict";

  h();
  var Wn = [0, 255, 65535, 16777215, 4294967295];
  function $n(n, r, e, t, i) {
    var o;
    for (o = 0; o < i; o++) e[t + o] = n[r + o];
  }
  function ei(n, r, e, t) {
    var i;
    for (i = 0; i < t; i++) n[r + i] = n[r - e + i];
  }
  function ht(n) {
    this.array = n, this.pos = 0;
  }
  ht.prototype.readUncompressedLength = function () {
    for (var n = 0, r = 0, e, t; r < 32 && this.pos < this.array.length;) {
      if (e = this.array[this.pos], this.pos += 1, t = e & 127, t << r >>> r !== t) return -1;
      if (n |= t << r, e < 128) return n;
      r += 7;
    }
    return -1;
  };
  ht.prototype.uncompressToBuffer = function (n) {
    for (var r = this.array, e = r.length, t = this.pos, i = 0, o, f, s, A; t < r.length;) if (o = r[t], t += 1, (o & 3) === 0) {
      if (f = (o >>> 2) + 1, f > 60) {
        if (t + 3 >= e) return !1;
        s = f - 60, f = r[t] + (r[t + 1] << 8) + (r[t + 2] << 16) + (r[t + 3] << 24), f = (f & Wn[s]) + 1, t += s;
      }
      if (t + f > e) return !1;
      $n(r, t, n, i, f), t += f, i += f;
    } else {
      switch (o & 3) {
        case 1:
          f = (o >>> 2 & 7) + 4, A = r[t] + (o >>> 5 << 8), t += 1;
          break;
        case 2:
          if (t + 1 >= e) return !1;
          f = (o >>> 2) + 1, A = r[t] + (r[t + 1] << 8), t += 2;
          break;
        case 3:
          if (t + 3 >= e) return !1;
          f = (o >>> 2) + 1, A = r[t] + (r[t + 1] << 8) + (r[t + 2] << 16) + (r[t + 3] << 24), t += 4;
          break;
        default:
          break;
      }
      if (A === 0 || A > i) return !1;
      ei(n, i, A, f), i += f;
    }
    return !0;
  };
  Xt.SnappyDecompressor = ht;
});
var rr = q(tr => {
  "use strict";

  h();
  var ti = 16,
    ri = 1 << ti,
    er = 14,
    yt = new Array(er + 1);
  function Ne(n, r) {
    return n * 506832829 >>> r;
  }
  function _e(n, r) {
    return n[r] + (n[r + 1] << 8) + (n[r + 2] << 16) + (n[r + 3] << 24);
  }
  function Wt(n, r, e) {
    return n[r] === n[e] && n[r + 1] === n[e + 1] && n[r + 2] === n[e + 2] && n[r + 3] === n[e + 3];
  }
  function ni(n, r, e, t, i) {
    var o;
    for (o = 0; o < i; o++) e[t + o] = n[r + o];
  }
  function $t(n, r, e, t, i) {
    return e <= 60 ? (t[i] = e - 1 << 2, i += 1) : e < 256 ? (t[i] = 60 << 2, t[i + 1] = e - 1, i += 2) : (t[i] = 61 << 2, t[i + 1] = e - 1 & 255, t[i + 2] = e - 1 >>> 8, i += 3), ni(n, r, t, i, e), i + e;
  }
  function pt(n, r, e, t) {
    return t < 12 && e < 2048 ? (n[r] = 1 + (t - 4 << 2) + (e >>> 8 << 5), n[r + 1] = e & 255, r + 2) : (n[r] = 2 + (t - 1 << 2), n[r + 1] = e & 255, n[r + 2] = e >>> 8, r + 3);
  }
  function ii(n, r, e, t) {
    for (; t >= 68;) r = pt(n, r, e, 64), t -= 64;
    return t > 64 && (r = pt(n, r, e, 60), t -= 60), pt(n, r, e, t);
  }
  function oi(n, r, e, t, i) {
    for (var o = 1; 1 << o <= e && o <= er;) o += 1;
    o -= 1;
    var f = 32 - o;
    typeof yt[o] > "u" && (yt[o] = new Uint16Array(1 << o));
    var s = yt[o],
      A;
    for (A = 0; A < s.length; A++) s[A] = 0;
    var u = r + e,
      l,
      g = r,
      y = r,
      B,
      C,
      T,
      k,
      ee,
      J,
      D,
      te,
      ye,
      x,
      v,
      O = !0,
      R = 15;
    if (e >= R) for (l = u - R, r += 1, C = Ne(_e(n, r), f); O;) {
      ee = 32, T = r;
      do {
        if (r = T, B = C, J = ee >>> 5, ee += 1, T = r + J, r > l) {
          O = !1;
          break;
        }
        C = Ne(_e(n, T), f), k = g + s[B], s[B] = r - g;
      } while (!Wt(n, r, k));
      if (!O) break;
      i = $t(n, y, r - y, t, i);
      do {
        for (D = r, te = 4; r + te < u && n[r + te] === n[k + te];) te += 1;
        if (r += te, ye = D - k, i = ii(t, i, ye, te), y = r, r >= l) {
          O = !1;
          break;
        }
        x = Ne(_e(n, r - 1), f), s[x] = r - 1 - g, v = Ne(_e(n, r), f), k = g + s[v], s[v] = r - g;
      } while (Wt(n, r, k));
      if (!O) break;
      r += 1, C = Ne(_e(n, r), f);
    }
    return y < u && (i = $t(n, y, u - y, t, i)), i;
  }
  function Ai(n, r, e) {
    do r[e] = n & 127, n = n >>> 7, n > 0 && (r[e] += 128), e += 1; while (n > 0);
    return e;
  }
  function Bt(n) {
    this.array = n;
  }
  Bt.prototype.maxCompressedLength = function () {
    var n = this.array.length;
    return 32 + n + Math.floor(n / 6);
  };
  Bt.prototype.compressToBuffer = function (n) {
    var r = this.array,
      e = r.length,
      t = 0,
      i = 0,
      o;
    for (i = Ai(e, n, i); t < e;) o = Math.min(e - t, ri), i = oi(r, t, o, n, i), t += o;
    return i;
  };
  tr.SnappyCompressor = Bt;
});
var ze = q(gt => {
  "use strict";

  h();
  function nr() {
    return typeof process == "object" && typeof process.versions == "object" && typeof process.versions.node < "u";
  }
  function We(n) {
    return n instanceof Uint8Array && (!nr() || !Buffer.isBuffer(n));
  }
  function $e(n) {
    return n instanceof ArrayBuffer;
  }
  function ir(n) {
    return nr() ? Buffer.isBuffer(n) : !1;
  }
  var fi = Vt().SnappyDecompressor,
    ui = rr().SnappyCompressor,
    or = "Argument compressed must be type of ArrayBuffer, Buffer, or Uint8Array";
  function si(n, r) {
    if (!We(n) && !$e(n) && !ir(n)) throw new TypeError(or);
    var e = !1,
      t = !1;
    We(n) ? e = !0 : $e(n) && (t = !0, n = new Uint8Array(n));
    var i = new fi(n),
      o = i.readUncompressedLength();
    if (o === -1) throw new Error("Invalid Snappy bitstream");
    if (o > r) throw new Error(`The uncompressed length of ${o} is too big, expect at most ${r}`);
    var f, s;
    if (e) {
      if (f = new Uint8Array(o), !i.uncompressToBuffer(f)) throw new Error("Invalid Snappy bitstream");
    } else if (t) {
      if (f = new ArrayBuffer(o), s = new Uint8Array(f), !i.uncompressToBuffer(s)) throw new Error("Invalid Snappy bitstream");
    } else if (f = Buffer.alloc(o), !i.uncompressToBuffer(f)) throw new Error("Invalid Snappy bitstream");
    return f;
  }
  function ai(n) {
    if (!We(n) && !$e(n) && !ir(n)) throw new TypeError(or);
    var r = !1,
      e = !1;
    We(n) ? r = !0 : $e(n) && (e = !0, n = new Uint8Array(n));
    var t = new ui(n),
      i = t.maxCompressedLength(),
      o,
      f,
      s;
    if (r ? (o = new Uint8Array(i), s = t.compressToBuffer(o)) : e ? (o = new ArrayBuffer(i), f = new Uint8Array(o), s = t.compressToBuffer(f)) : (o = Buffer.alloc(i), s = t.compressToBuffer(o)), !o.slice) {
      var A = new Uint8Array(Array.prototype.slice.call(o, 0, s));
      if (r) return A;
      if (e) return A.buffer;
      throw new Error("Not implemented");
    }
    return o.slice(0, s);
  }
  gt.uncompress = si;
  gt.compress = ai;
});
var fr = q((xi, Ar) => {
  "use strict";

  h();
  Ar.exports = li;
  function li(n, r) {
    for (var e = new Array(arguments.length - 1), t = 0, i = 2, o = !0; i < arguments.length;) e[t++] = arguments[i++];
    return new Promise(function (s, A) {
      e[t] = function (l) {
        if (o) if (o = !1, l) A(l);else {
          for (var g = new Array(arguments.length - 1), y = 0; y < g.length;) g[y++] = arguments[y];
          s.apply(null, g);
        }
      };
      try {
        n.apply(r || null, e);
      } catch (u) {
        o && (o = !1, A(u));
      }
    });
  }
});
var lr = q(ar => {
  "use strict";

  h();
  var et = ar;
  et.length = function (r) {
    var e = r.length;
    if (!e) return 0;
    for (var t = 0; --e % 4 > 1 && r.charAt(e) === "=";) ++t;
    return Math.ceil(r.length * 3) / 4 - t;
  };
  var Fe = new Array(64),
    sr = new Array(123);
  for (fe = 0; fe < 64;) sr[Fe[fe] = fe < 26 ? fe + 65 : fe < 52 ? fe + 71 : fe < 62 ? fe - 4 : fe - 59 | 43] = fe++;
  var fe;
  et.encode = function (r, e, t) {
    for (var i = null, o = [], f = 0, s = 0, A; e < t;) {
      var u = r[e++];
      switch (s) {
        case 0:
          o[f++] = Fe[u >> 2], A = (u & 3) << 4, s = 1;
          break;
        case 1:
          o[f++] = Fe[A | u >> 4], A = (u & 15) << 2, s = 2;
          break;
        case 2:
          o[f++] = Fe[A | u >> 6], o[f++] = Fe[u & 63], s = 0;
          break;
      }
      f > 8191 && ((i || (i = [])).push(String.fromCharCode.apply(String, o)), f = 0);
    }
    return s && (o[f++] = Fe[A], o[f++] = 61, s === 1 && (o[f++] = 61)), i ? (f && i.push(String.fromCharCode.apply(String, o.slice(0, f))), i.join("")) : String.fromCharCode.apply(String, o.slice(0, f));
  };
  var ur = "invalid encoding";
  et.decode = function (r, e, t) {
    for (var i = t, o = 0, f, s = 0; s < r.length;) {
      var A = r.charCodeAt(s++);
      if (A === 61 && o > 1) break;
      if ((A = sr[A]) === void 0) throw Error(ur);
      switch (o) {
        case 0:
          f = A, o = 1;
          break;
        case 1:
          e[t++] = f << 2 | (A & 48) >> 4, f = A, o = 2;
          break;
        case 2:
          e[t++] = (f & 15) << 4 | (A & 60) >> 2, f = A, o = 3;
          break;
        case 3:
          e[t++] = (f & 3) << 6 | A, o = 0;
          break;
      }
    }
    if (o === 1) throw Error(ur);
    return t - i;
  };
  et.test = function (r) {
    return /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(r);
  };
});
var dr = q((Li, cr) => {
  "use strict";

  h();
  cr.exports = tt;
  function tt() {
    this._listeners = {};
  }
  tt.prototype.on = function (r, e, t) {
    return (this._listeners[r] || (this._listeners[r] = [])).push({
      fn: e,
      ctx: t || this
    }), this;
  };
  tt.prototype.off = function (r, e) {
    if (r === void 0) this._listeners = {};else if (e === void 0) this._listeners[r] = [];else for (var t = this._listeners[r], i = 0; i < t.length;) t[i].fn === e ? t.splice(i, 1) : ++i;
    return this;
  };
  tt.prototype.emit = function (r) {
    var e = this._listeners[r];
    if (e) {
      for (var t = [], i = 1; i < arguments.length;) t.push(arguments[i++]);
      for (i = 0; i < e.length;) e[i].fn.apply(e[i++].ctx, t);
    }
    return this;
  };
});
var Cr = q((Mi, Ir) => {
  "use strict";

  h();
  Ir.exports = hr(hr);
  function hr(n) {
    return typeof Float32Array < "u" ? function () {
      var r = new Float32Array([-0]),
        e = new Uint8Array(r.buffer),
        t = e[3] === 128;
      function i(A, u, l) {
        r[0] = A, u[l] = e[0], u[l + 1] = e[1], u[l + 2] = e[2], u[l + 3] = e[3];
      }
      function o(A, u, l) {
        r[0] = A, u[l] = e[3], u[l + 1] = e[2], u[l + 2] = e[1], u[l + 3] = e[0];
      }
      n.writeFloatLE = t ? i : o, n.writeFloatBE = t ? o : i;
      function f(A, u) {
        return e[0] = A[u], e[1] = A[u + 1], e[2] = A[u + 2], e[3] = A[u + 3], r[0];
      }
      function s(A, u) {
        return e[3] = A[u], e[2] = A[u + 1], e[1] = A[u + 2], e[0] = A[u + 3], r[0];
      }
      n.readFloatLE = t ? f : s, n.readFloatBE = t ? s : f;
    }() : function () {
      function r(t, i, o, f) {
        var s = i < 0 ? 1 : 0;
        if (s && (i = -i), i === 0) t(1 / i > 0 ? 0 : 2147483648, o, f);else if (isNaN(i)) t(2143289344, o, f);else if (i > 34028234663852886e22) t((s << 31 | 2139095040) >>> 0, o, f);else if (i < 11754943508222875e-54) t((s << 31 | Math.round(i / 1401298464324817e-60)) >>> 0, o, f);else {
          var A = Math.floor(Math.log(i) / Math.LN2),
            u = Math.round(i * Math.pow(2, -A) * 8388608) & 8388607;
          t((s << 31 | A + 127 << 23 | u) >>> 0, o, f);
        }
      }
      n.writeFloatLE = r.bind(null, yr), n.writeFloatBE = r.bind(null, pr);
      function e(t, i, o) {
        var f = t(i, o),
          s = (f >> 31) * 2 + 1,
          A = f >>> 23 & 255,
          u = f & 8388607;
        return A === 255 ? u ? NaN : s * (1 / 0) : A === 0 ? s * 1401298464324817e-60 * u : s * Math.pow(2, A - 150) * (u + 8388608);
      }
      n.readFloatLE = e.bind(null, Br), n.readFloatBE = e.bind(null, gr);
    }(), typeof Float64Array < "u" ? function () {
      var r = new Float64Array([-0]),
        e = new Uint8Array(r.buffer),
        t = e[7] === 128;
      function i(A, u, l) {
        r[0] = A, u[l] = e[0], u[l + 1] = e[1], u[l + 2] = e[2], u[l + 3] = e[3], u[l + 4] = e[4], u[l + 5] = e[5], u[l + 6] = e[6], u[l + 7] = e[7];
      }
      function o(A, u, l) {
        r[0] = A, u[l] = e[7], u[l + 1] = e[6], u[l + 2] = e[5], u[l + 3] = e[4], u[l + 4] = e[3], u[l + 5] = e[2], u[l + 6] = e[1], u[l + 7] = e[0];
      }
      n.writeDoubleLE = t ? i : o, n.writeDoubleBE = t ? o : i;
      function f(A, u) {
        return e[0] = A[u], e[1] = A[u + 1], e[2] = A[u + 2], e[3] = A[u + 3], e[4] = A[u + 4], e[5] = A[u + 5], e[6] = A[u + 6], e[7] = A[u + 7], r[0];
      }
      function s(A, u) {
        return e[7] = A[u], e[6] = A[u + 1], e[5] = A[u + 2], e[4] = A[u + 3], e[3] = A[u + 4], e[2] = A[u + 5], e[1] = A[u + 6], e[0] = A[u + 7], r[0];
      }
      n.readDoubleLE = t ? f : s, n.readDoubleBE = t ? s : f;
    }() : function () {
      function r(t, i, o, f, s, A) {
        var u = f < 0 ? 1 : 0;
        if (u && (f = -f), f === 0) t(0, s, A + i), t(1 / f > 0 ? 0 : 2147483648, s, A + o);else if (isNaN(f)) t(0, s, A + i), t(2146959360, s, A + o);else if (f > 17976931348623157e292) t(0, s, A + i), t((u << 31 | 2146435072) >>> 0, s, A + o);else {
          var l;
          if (f < 22250738585072014e-324) l = f / 5e-324, t(l >>> 0, s, A + i), t((u << 31 | l / 4294967296) >>> 0, s, A + o);else {
            var g = Math.floor(Math.log(f) / Math.LN2);
            g === 1024 && (g = 1023), l = f * Math.pow(2, -g), t(l * 4503599627370496 >>> 0, s, A + i), t((u << 31 | g + 1023 << 20 | l * 1048576 & 1048575) >>> 0, s, A + o);
          }
        }
      }
      n.writeDoubleLE = r.bind(null, yr, 0, 4), n.writeDoubleBE = r.bind(null, pr, 4, 0);
      function e(t, i, o, f, s) {
        var A = t(f, s + i),
          u = t(f, s + o),
          l = (u >> 31) * 2 + 1,
          g = u >>> 20 & 2047,
          y = 4294967296 * (u & 1048575) + A;
        return g === 2047 ? y ? NaN : l * (1 / 0) : g === 0 ? l * 5e-324 * y : l * Math.pow(2, g - 1075) * (y + 4503599627370496);
      }
      n.readDoubleLE = e.bind(null, Br, 0, 4), n.readDoubleBE = e.bind(null, gr, 4, 0);
    }(), n;
  }
  function yr(n, r, e) {
    r[e] = n & 255, r[e + 1] = n >>> 8 & 255, r[e + 2] = n >>> 16 & 255, r[e + 3] = n >>> 24;
  }
  function pr(n, r, e) {
    r[e] = n >>> 24, r[e + 1] = n >>> 16 & 255, r[e + 2] = n >>> 8 & 255, r[e + 3] = n & 255;
  }
  function Br(n, r) {
    return (n[r] | n[r + 1] << 8 | n[r + 2] << 16 | n[r + 3] << 24) >>> 0;
  }
  function gr(n, r) {
    return (n[r] << 24 | n[r + 1] << 16 | n[r + 2] << 8 | n[r + 3]) >>> 0;
  }
});
var Qr = q((exports, module) => {
  "use strict";

  h();
  module.exports = inquire;
  function inquire(moduleName) {
    try {
      var mod = eval("quire".replace(/^/, "re"))(moduleName);
      if (mod && (mod.length || Object.keys(mod).length)) return mod;
    } catch (n) {}
    return null;
  }
});
var br = q(wr => {
  "use strict";

  h();
  var It = wr;
  It.length = function (r) {
    for (var e = 0, t = 0, i = 0; i < r.length; ++i) t = r.charCodeAt(i), t < 128 ? e += 1 : t < 2048 ? e += 2 : (t & 64512) === 55296 && (r.charCodeAt(i + 1) & 64512) === 56320 ? (++i, e += 4) : e += 3;
    return e;
  };
  It.read = function (r, e, t) {
    if (t - e < 1) return "";
    for (var i = "", o = e; o < t;) {
      var f = r[o++];
      if (f <= 127) i += String.fromCharCode(f);else if (f >= 192 && f < 224) i += String.fromCharCode((f & 31) << 6 | r[o++] & 63);else if (f >= 224 && f < 240) i += String.fromCharCode((f & 15) << 12 | (r[o++] & 63) << 6 | r[o++] & 63);else if (f >= 240) {
        var s = ((f & 7) << 18 | (r[o++] & 63) << 12 | (r[o++] & 63) << 6 | r[o++] & 63) - 65536;
        i += String.fromCharCode(55296 + (s >> 10)), i += String.fromCharCode(56320 + (s & 1023));
      }
    }
    return i;
  };
  It.write = function (r, e, t) {
    for (var i = t, o, f, s = 0; s < r.length; ++s) o = r.charCodeAt(s), o < 128 ? e[t++] = o : o < 2048 ? (e[t++] = o >> 6 | 192, e[t++] = o & 63 | 128) : (o & 64512) === 55296 && ((f = r.charCodeAt(s + 1)) & 64512) === 56320 ? (o = 65536 + ((o & 1023) << 10) + (f & 1023), ++s, e[t++] = o >> 18 | 240, e[t++] = o >> 12 & 63 | 128, e[t++] = o >> 6 & 63 | 128, e[t++] = o & 63 | 128) : (e[t++] = o >> 12 | 224, e[t++] = o >> 6 & 63 | 128, e[t++] = o & 63 | 128);
    return t - i;
  };
});
var mr = q((Ni, Er) => {
  "use strict";

  h();
  Er.exports = ci;
  function ci(n, r, e) {
    var t = e || 8192,
      i = t >>> 1,
      o = null,
      f = t;
    return function (A) {
      if (A < 1 || A > i) return n(A);
      f + A > t && (o = n(t), f = 0);
      var u = r.call(o, f, f += A);
      return f & 7 && (f = (f | 7) + 1), u;
    };
  }
});
var Tr = q((_i, Hr) => {
  "use strict";

  h();
  Hr.exports = P;
  var Ye = Qe();
  function P(n, r) {
    this.lo = n >>> 0, this.hi = r >>> 0;
  }
  var Te = P.zero = new P(0, 0);
  Te.toNumber = function () {
    return 0;
  };
  Te.zzEncode = Te.zzDecode = function () {
    return this;
  };
  Te.length = function () {
    return 1;
  };
  var di = P.zeroHash = "\0\0\0\0\0\0\0\0";
  P.fromNumber = function (r) {
    if (r === 0) return Te;
    var e = r < 0;
    e && (r = -r);
    var t = r >>> 0,
      i = (r - t) / 4294967296 >>> 0;
    return e && (i = ~i >>> 0, t = ~t >>> 0, ++t > 4294967295 && (t = 0, ++i > 4294967295 && (i = 0))), new P(t, i);
  };
  P.from = function (r) {
    if (typeof r == "number") return P.fromNumber(r);
    if (Ye.isString(r)) if (Ye.Long) r = Ye.Long.fromString(r);else return P.fromNumber(parseInt(r, 10));
    return r.low || r.high ? new P(r.low >>> 0, r.high >>> 0) : Te;
  };
  P.prototype.toNumber = function (r) {
    if (!r && this.hi >>> 31) {
      var e = ~this.lo + 1 >>> 0,
        t = ~this.hi >>> 0;
      return e || (t = t + 1 >>> 0), -(e + t * 4294967296);
    }
    return this.lo + this.hi * 4294967296;
  };
  P.prototype.toLong = function (r) {
    return Ye.Long ? new Ye.Long(this.lo | 0, this.hi | 0, Boolean(r)) : {
      low: this.lo | 0,
      high: this.hi | 0,
      unsigned: Boolean(r)
    };
  };
  var Ce = String.prototype.charCodeAt;
  P.fromHash = function (r) {
    return r === di ? Te : new P((Ce.call(r, 0) | Ce.call(r, 1) << 8 | Ce.call(r, 2) << 16 | Ce.call(r, 3) << 24) >>> 0, (Ce.call(r, 4) | Ce.call(r, 5) << 8 | Ce.call(r, 6) << 16 | Ce.call(r, 7) << 24) >>> 0);
  };
  P.prototype.toHash = function () {
    return String.fromCharCode(this.lo & 255, this.lo >>> 8 & 255, this.lo >>> 16 & 255, this.lo >>> 24, this.hi & 255, this.hi >>> 8 & 255, this.hi >>> 16 & 255, this.hi >>> 24);
  };
  P.prototype.zzEncode = function () {
    var r = this.hi >> 31;
    return this.hi = ((this.hi << 1 | this.lo >>> 31) ^ r) >>> 0, this.lo = (this.lo << 1 ^ r) >>> 0, this;
  };
  P.prototype.zzDecode = function () {
    var r = -(this.lo & 1);
    return this.lo = ((this.lo >>> 1 | this.hi << 31) ^ r) >>> 0, this.hi = (this.hi >>> 1 ^ r) >>> 0, this;
  };
  P.prototype.length = function () {
    var r = this.lo,
      e = (this.lo >>> 28 | this.hi << 4) >>> 0,
      t = this.hi >>> 24;
    return t === 0 ? e === 0 ? r < 16384 ? r < 128 ? 1 : 2 : r < 2097152 ? 3 : 4 : e < 16384 ? e < 128 ? 5 : 6 : e < 2097152 ? 7 : 8 : t < 128 ? 9 : 10;
  };
});
var Qe = q(Ct => {
  "use strict";

  h();
  var I = Ct;
  I.asPromise = fr();
  I.base64 = lr();
  I.EventEmitter = dr();
  I.float = Cr();
  I.inquire = Qr();
  I.utf8 = br();
  I.pool = mr();
  I.LongBits = Tr();
  I.isNode = Boolean(typeof __webpack_require__.g < "u" && __webpack_require__.g && __webpack_require__.g.process && __webpack_require__.g.process.versions && __webpack_require__.g.process.versions.node);
  I.global = I.isNode && __webpack_require__.g || typeof window < "u" && window || typeof self < "u" && self || Ct;
  I.emptyArray = Object.freeze ? Object.freeze([]) : [];
  I.emptyObject = Object.freeze ? Object.freeze({}) : {};
  I.isInteger = Number.isInteger || function (r) {
    return typeof r == "number" && isFinite(r) && Math.floor(r) === r;
  };
  I.isString = function (r) {
    return typeof r == "string" || r instanceof String;
  };
  I.isObject = function (r) {
    return r && typeof r == "object";
  };
  I.isset = I.isSet = function (r, e) {
    var t = r[e];
    return t != null && r.hasOwnProperty(e) ? typeof t != "object" || (Array.isArray(t) ? t.length : Object.keys(t).length) > 0 : !1;
  };
  I.Buffer = function () {
    try {
      var n = I.inquire("buffer").Buffer;
      return n.prototype.utf8Write ? n : null;
    } catch {
      return null;
    }
  }();
  I._Buffer_from = null;
  I._Buffer_allocUnsafe = null;
  I.newBuffer = function (r) {
    return typeof r == "number" ? I.Buffer ? I._Buffer_allocUnsafe(r) : new I.Array(r) : I.Buffer ? I._Buffer_from(r) : typeof Uint8Array > "u" ? r : new Uint8Array(r);
  };
  I.Array = typeof Uint8Array < "u" ? Uint8Array : Array;
  I.Long = I.global.dcodeIO && I.global.dcodeIO.Long || I.global.Long || I.inquire("long");
  I.key2Re = /^true|false|0|1$/;
  I.key32Re = /^-?(?:0|[1-9][0-9]*)$/;
  I.key64Re = /^(?:[\\x00-\\xff]{8}|-?(?:0|[1-9][0-9]*))$/;
  I.longToHash = function (r) {
    return r ? I.LongBits.from(r).toHash() : I.LongBits.zeroHash;
  };
  I.longFromHash = function (r, e) {
    var t = I.LongBits.fromHash(r);
    return I.Long ? I.Long.fromBits(t.lo, t.hi, e) : t.toNumber(Boolean(e));
  };
  function Or(n, r, e) {
    for (var t = Object.keys(r), i = 0; i < t.length; ++i) (n[t[i]] === void 0 || !e) && (n[t[i]] = r[t[i]]);
    return n;
  }
  I.merge = Or;
  I.lcFirst = function (r) {
    return r.charAt(0).toLowerCase() + r.substring(1);
  };
  function Sr(n) {
    function r(e, t) {
      if (!(this instanceof r)) return new r(e, t);
      Object.defineProperty(this, "message", {
        get: function () {
          return e;
        }
      }), Error.captureStackTrace ? Error.captureStackTrace(this, r) : Object.defineProperty(this, "stack", {
        value: new Error().stack || ""
      }), t && Or(this, t);
    }
    return r.prototype = Object.create(Error.prototype, {
      constructor: {
        value: r,
        writable: !0,
        enumerable: !1,
        configurable: !0
      },
      name: {
        get() {
          return n;
        },
        set: void 0,
        enumerable: !1,
        configurable: !0
      },
      toString: {
        value() {
          return this.name + ": " + this.message;
        },
        writable: !0,
        enumerable: !1,
        configurable: !0
      }
    }), r;
  }
  I.newError = Sr;
  I.ProtocolError = Sr("ProtocolError");
  I.oneOfGetter = function (r) {
    for (var e = {}, t = 0; t < r.length; ++t) e[r[t]] = 1;
    return function () {
      for (var i = Object.keys(this), o = i.length - 1; o > -1; --o) if (e[i[o]] === 1 && this[i[o]] !== void 0 && this[i[o]] !== null) return i[o];
    };
  };
  I.oneOfSetter = function (r) {
    return function (e) {
      for (var t = 0; t < r.length; ++t) r[t] !== e && delete this[r[t]];
    };
  };
  I.toJSONOptions = {
    longs: String,
    enums: String,
    bytes: String,
    json: !0
  };
  I._configure = function () {
    var n = I.Buffer;
    if (!n) {
      I._Buffer_from = I._Buffer_allocUnsafe = null;
      return;
    }
    I._Buffer_from = n.from !== Uint8Array.from && n.from || function (e, t) {
      return new n(e, t);
    }, I._Buffer_allocUnsafe = n.allocUnsafe || function (e) {
      return new n(e);
    };
  };
});
var Tt = q((Yi, Fr) => {
  "use strict";

  h();
  Fr.exports = H;
  var oe = Qe(),
    Qt,
    rt = oe.LongBits,
    Rr = oe.base64,
    Ur = oe.utf8;
  function Je(n, r, e) {
    this.fn = n, this.len = r, this.next = void 0, this.val = e;
  }
  function bt() {}
  function hi(n) {
    this.head = n.head, this.tail = n.tail, this.len = n.len, this.next = n.states;
  }
  function H() {
    this.len = 0, this.head = new Je(bt, 0, 0), this.tail = this.head, this.states = null;
  }
  var vr = function () {
    return oe.Buffer ? function () {
      return (H.create = function () {
        return new Qt();
      })();
    } : function () {
      return new H();
    };
  };
  H.create = vr();
  H.alloc = function (r) {
    return new oe.Array(r);
  };
  oe.Array !== Array && (H.alloc = oe.pool(H.alloc, oe.Array.prototype.subarray));
  H.prototype._push = function (r, e, t) {
    return this.tail = this.tail.next = new Je(r, e, t), this.len += e, this;
  };
  function Et(n, r, e) {
    r[e] = n & 255;
  }
  function yi(n, r, e) {
    for (; n > 127;) r[e++] = n & 127 | 128, n >>>= 7;
    r[e] = n;
  }
  function mt(n, r) {
    this.len = n, this.next = void 0, this.val = r;
  }
  mt.prototype = Object.create(Je.prototype);
  mt.prototype.fn = yi;
  H.prototype.uint32 = function (r) {
    return this.len += (this.tail = this.tail.next = new mt((r = r >>> 0) < 128 ? 1 : r < 16384 ? 2 : r < 2097152 ? 3 : r < 268435456 ? 4 : 5, r)).len, this;
  };
  H.prototype.int32 = function (r) {
    return r < 0 ? this._push(Ht, 10, rt.fromNumber(r)) : this.uint32(r);
  };
  H.prototype.sint32 = function (r) {
    return this.uint32((r << 1 ^ r >> 31) >>> 0);
  };
  function Ht(n, r, e) {
    for (; n.hi;) r[e++] = n.lo & 127 | 128, n.lo = (n.lo >>> 7 | n.hi << 25) >>> 0, n.hi >>>= 7;
    for (; n.lo > 127;) r[e++] = n.lo & 127 | 128, n.lo = n.lo >>> 7;
    r[e++] = n.lo;
  }
  H.prototype.uint64 = function (r) {
    var e = rt.from(r);
    return this._push(Ht, e.length(), e);
  };
  H.prototype.int64 = H.prototype.uint64;
  H.prototype.sint64 = function (r) {
    var e = rt.from(r).zzEncode();
    return this._push(Ht, e.length(), e);
  };
  H.prototype.bool = function (r) {
    return this._push(Et, 1, r ? 1 : 0);
  };
  function wt(n, r, e) {
    r[e] = n & 255, r[e + 1] = n >>> 8 & 255, r[e + 2] = n >>> 16 & 255, r[e + 3] = n >>> 24;
  }
  H.prototype.fixed32 = function (r) {
    return this._push(wt, 4, r >>> 0);
  };
  H.prototype.sfixed32 = H.prototype.fixed32;
  H.prototype.fixed64 = function (r) {
    var e = rt.from(r);
    return this._push(wt, 4, e.lo)._push(wt, 4, e.hi);
  };
  H.prototype.sfixed64 = H.prototype.fixed64;
  H.prototype.float = function (r) {
    return this._push(oe.float.writeFloatLE, 4, r);
  };
  H.prototype.double = function (r) {
    return this._push(oe.float.writeDoubleLE, 8, r);
  };
  var pi = oe.Array.prototype.set ? function (r, e, t) {
    e.set(r, t);
  } : function (r, e, t) {
    for (var i = 0; i < r.length; ++i) e[t + i] = r[i];
  };
  H.prototype.bytes = function (r) {
    var e = r.length >>> 0;
    if (!e) return this._push(Et, 1, 0);
    if (oe.isString(r)) {
      var t = H.alloc(e = Rr.length(r));
      Rr.decode(r, t, 0), r = t;
    }
    return this.uint32(e)._push(pi, e, r);
  };
  H.prototype.string = function (r) {
    var e = Ur.length(r);
    return e ? this.uint32(e)._push(Ur.write, e, r) : this._push(Et, 1, 0);
  };
  H.prototype.fork = function () {
    return this.states = new hi(this), this.head = this.tail = new Je(bt, 0, 0), this.len = 0, this;
  };
  H.prototype.reset = function () {
    return this.states ? (this.head = this.states.head, this.tail = this.states.tail, this.len = this.states.len, this.states = this.states.next) : (this.head = this.tail = new Je(bt, 0, 0), this.len = 0), this;
  };
  H.prototype.ldelim = function () {
    var r = this.head,
      e = this.tail,
      t = this.len;
    return this.reset().uint32(t), t && (this.tail.next = r.next, this.tail = e, this.len += t), this;
  };
  H.prototype.finish = function () {
    for (var r = this.head.next, e = this.constructor.alloc(this.len), t = 0; r;) r.fn(r.val, e, t), t += r.len, r = r.next;
    return e;
  };
  H._configure = function (n) {
    Qt = n, H.create = vr(), Qt._configure();
  };
});
var Gr = q((Ji, qr) => {
  "use strict";

  h();
  qr.exports = ce;
  var Dr = Tt();
  (ce.prototype = Object.create(Dr.prototype)).constructor = ce;
  var we = Qe();
  function ce() {
    Dr.call(this);
  }
  ce._configure = function () {
    ce.alloc = we._Buffer_allocUnsafe, ce.writeBytesBuffer = we.Buffer && we.Buffer.prototype instanceof Uint8Array && we.Buffer.prototype.set.name === "set" ? function (r, e, t) {
      e.set(r, t);
    } : function (r, e, t) {
      if (r.copy) r.copy(e, t, 0, r.length);else for (var i = 0; i < r.length;) e[t++] = r[i++];
    };
  };
  ce.prototype.bytes = function (r) {
    we.isString(r) && (r = we._Buffer_from(r, "base64"));
    var e = r.length >>> 0;
    return this.uint32(e), e && this._push(ce.writeBytesBuffer, e, r), this;
  };
  function Bi(n, r, e) {
    n.length < 40 ? we.utf8.write(n, r, e) : r.utf8Write ? r.utf8Write(n, e) : r.write(n, e);
  }
  ce.prototype.string = function (r) {
    var e = we.Buffer.byteLength(r);
    return this.uint32(e), e && this._push(Bi, e, r), this;
  };
  ce._configure();
});
var Rt = q((Zi, Pr) => {
  "use strict";

  h();
  Pr.exports = G;
  var de = Qe(),
    St,
    Lr = de.LongBits,
    gi = de.utf8;
  function ue(n, r) {
    return RangeError("index out of range: " + n.pos + " + " + (r || 1) + " > " + n.len);
  }
  function G(n) {
    this.buf = n, this.pos = 0, this.len = n.length;
  }
  var xr = typeof Uint8Array < "u" ? function (r) {
      if (r instanceof Uint8Array || Array.isArray(r)) return new G(r);
      throw Error("illegal buffer");
    } : function (r) {
      if (Array.isArray(r)) return new G(r);
      throw Error("illegal buffer");
    },
    Mr = function () {
      return de.Buffer ? function (e) {
        return (G.create = function (i) {
          return de.Buffer.isBuffer(i) ? new St(i) : xr(i);
        })(e);
      } : xr;
    };
  G.create = Mr();
  G.prototype._slice = de.Array.prototype.subarray || de.Array.prototype.slice;
  G.prototype.uint32 = function () {
    var r = 4294967295;
    return function () {
      if (r = (this.buf[this.pos] & 127) >>> 0, this.buf[this.pos++] < 128 || (r = (r | (this.buf[this.pos] & 127) << 7) >>> 0, this.buf[this.pos++] < 128) || (r = (r | (this.buf[this.pos] & 127) << 14) >>> 0, this.buf[this.pos++] < 128) || (r = (r | (this.buf[this.pos] & 127) << 21) >>> 0, this.buf[this.pos++] < 128) || (r = (r | (this.buf[this.pos] & 15) << 28) >>> 0, this.buf[this.pos++] < 128)) return r;
      if ((this.pos += 5) > this.len) throw this.pos = this.len, ue(this, 10);
      return r;
    };
  }();
  G.prototype.int32 = function () {
    return this.uint32() | 0;
  };
  G.prototype.sint32 = function () {
    var r = this.uint32();
    return r >>> 1 ^ -(r & 1) | 0;
  };
  function Ot() {
    var n = new Lr(0, 0),
      r = 0;
    if (this.len - this.pos > 4) {
      for (; r < 4; ++r) if (n.lo = (n.lo | (this.buf[this.pos] & 127) << r * 7) >>> 0, this.buf[this.pos++] < 128) return n;
      if (n.lo = (n.lo | (this.buf[this.pos] & 127) << 28) >>> 0, n.hi = (n.hi | (this.buf[this.pos] & 127) >> 4) >>> 0, this.buf[this.pos++] < 128) return n;
      r = 0;
    } else {
      for (; r < 3; ++r) {
        if (this.pos >= this.len) throw ue(this);
        if (n.lo = (n.lo | (this.buf[this.pos] & 127) << r * 7) >>> 0, this.buf[this.pos++] < 128) return n;
      }
      return n.lo = (n.lo | (this.buf[this.pos++] & 127) << r * 7) >>> 0, n;
    }
    if (this.len - this.pos > 4) {
      for (; r < 5; ++r) if (n.hi = (n.hi | (this.buf[this.pos] & 127) << r * 7 + 3) >>> 0, this.buf[this.pos++] < 128) return n;
    } else for (; r < 5; ++r) {
      if (this.pos >= this.len) throw ue(this);
      if (n.hi = (n.hi | (this.buf[this.pos] & 127) << r * 7 + 3) >>> 0, this.buf[this.pos++] < 128) return n;
    }
    throw Error("invalid varint encoding");
  }
  G.prototype.bool = function () {
    return this.uint32() !== 0;
  };
  function nt(n, r) {
    return (n[r - 4] | n[r - 3] << 8 | n[r - 2] << 16 | n[r - 1] << 24) >>> 0;
  }
  G.prototype.fixed32 = function () {
    if (this.pos + 4 > this.len) throw ue(this, 4);
    return nt(this.buf, this.pos += 4);
  };
  G.prototype.sfixed32 = function () {
    if (this.pos + 4 > this.len) throw ue(this, 4);
    return nt(this.buf, this.pos += 4) | 0;
  };
  function kr() {
    if (this.pos + 8 > this.len) throw ue(this, 8);
    return new Lr(nt(this.buf, this.pos += 4), nt(this.buf, this.pos += 4));
  }
  G.prototype.float = function () {
    if (this.pos + 4 > this.len) throw ue(this, 4);
    var r = de.float.readFloatLE(this.buf, this.pos);
    return this.pos += 4, r;
  };
  G.prototype.double = function () {
    if (this.pos + 8 > this.len) throw ue(this, 4);
    var r = de.float.readDoubleLE(this.buf, this.pos);
    return this.pos += 8, r;
  };
  G.prototype.bytes = function () {
    var r = this.uint32(),
      e = this.pos,
      t = this.pos + r;
    if (t > this.len) throw ue(this, r);
    return this.pos += r, Array.isArray(this.buf) ? this.buf.slice(e, t) : e === t ? new this.buf.constructor(0) : this._slice.call(this.buf, e, t);
  };
  G.prototype.string = function () {
    var r = this.bytes();
    return gi.read(r, 0, r.length);
  };
  G.prototype.skip = function (r) {
    if (typeof r == "number") {
      if (this.pos + r > this.len) throw ue(this, r);
      this.pos += r;
    } else do if (this.pos >= this.len) throw ue(this); while (this.buf[this.pos++] & 128);
    return this;
  };
  G.prototype.skipType = function (n) {
    switch (n) {
      case 0:
        this.skip();
        break;
      case 1:
        this.skip(8);
        break;
      case 2:
        this.skip(this.uint32());
        break;
      case 3:
        for (; (n = this.uint32() & 7) !== 4;) this.skipType(n);
        break;
      case 5:
        this.skip(4);
        break;
      default:
        throw Error("invalid wire type " + n + " at offset " + this.pos);
    }
    return this;
  };
  G._configure = function (n) {
    St = n, G.create = Mr(), St._configure();
    var r = de.Long ? "toLong" : "toNumber";
    de.merge(G.prototype, {
      int64: function () {
        return Ot.call(this)[r](!1);
      },
      uint64: function () {
        return Ot.call(this)[r](!0);
      },
      sint64: function () {
        return Ot.call(this).zzDecode()[r](!1);
      },
      fixed64: function () {
        return kr.call(this)[r](!0);
      },
      sfixed64: function () {
        return kr.call(this)[r](!1);
      }
    });
  };
});
var Yr = q((Ki, zr) => {
  "use strict";

  h();
  zr.exports = Oe;
  var _r = Rt();
  (Oe.prototype = Object.create(_r.prototype)).constructor = Oe;
  var Nr = Qe();
  function Oe(n) {
    _r.call(this, n);
  }
  Oe._configure = function () {
    Nr.Buffer && (Oe.prototype._slice = Nr.Buffer.prototype.slice);
  };
  Oe.prototype.string = function () {
    var r = this.uint32();
    return this.buf.utf8Slice ? this.buf.utf8Slice(this.pos, this.pos = Math.min(this.pos + r, this.len)) : this.buf.toString("utf-8", this.pos, this.pos = Math.min(this.pos + r, this.len));
  };
  Oe._configure();
});
var Zr = q((ji, Jr) => {
  "use strict";

  h();
  Jr.exports = Ze;
  var Ut = Qe();
  (Ze.prototype = Object.create(Ut.EventEmitter.prototype)).constructor = Ze;
  function Ze(n, r, e) {
    if (typeof n != "function") throw TypeError("rpcImpl must be a function");
    Ut.EventEmitter.call(this), this.rpcImpl = n, this.requestDelimited = Boolean(r), this.responseDelimited = Boolean(e);
  }
  Ze.prototype.rpcCall = function n(r, e, t, i, o) {
    if (!i) throw TypeError("request must be specified");
    var f = this;
    if (!o) return Ut.asPromise(n, f, r, e, t, i);
    if (!f.rpcImpl) {
      setTimeout(function () {
        o(Error("already ended"));
      }, 0);
      return;
    }
    try {
      return f.rpcImpl(r, e[f.requestDelimited ? "encodeDelimited" : "encode"](i).finish(), function (A, u) {
        if (A) return f.emit("error", A, r), o(A);
        if (u === null) {
          f.end(!0);
          return;
        }
        if (!(u instanceof t)) try {
          u = t[f.responseDelimited ? "decodeDelimited" : "decode"](u);
        } catch (l) {
          return f.emit("error", l, r), o(l);
        }
        return f.emit("data", u, r), o(null, u);
      });
    } catch (s) {
      f.emit("error", s, r), setTimeout(function () {
        o(s);
      }, 0);
      return;
    }
  };
  Ze.prototype.end = function (r) {
    return this.rpcImpl && (r || this.rpcImpl(null, null, null), this.rpcImpl = null, this.emit("end").off()), this;
  };
});
var jr = q(Kr => {
  "use strict";

  h();
  var Ii = Kr;
  Ii.Service = Zr();
});
var Vr = q((Vi, Xr) => {
  "use strict";

  h();
  Xr.exports = {};
});
var en = q($r => {
  "use strict";

  h();
  var K = $r;
  K.build = "minimal";
  K.Writer = Tt();
  K.BufferWriter = Gr();
  K.Reader = Rt();
  K.BufferReader = Yr();
  K.util = Qe();
  K.rpc = jr();
  K.roots = Vr();
  K.configure = Wr;
  function Wr() {
    K.util._configure(), K.Writer._configure(K.BufferWriter), K.Reader._configure(K.BufferReader);
  }
  Wr();
});
var rn = q(($i, tn) => {
  "use strict";

  h();
  tn.exports = en();
});
h();
var hn = {};
kt(hn, {
  decode: () => je,
  decodeRequest: () => ln,
  decodeResponse: () => cn,
  decodeStdPrivResponse: () => dn,
  encode: () => Ke,
  encodeRequest: () => An,
  encodeResponse: () => fn,
  encodeStdPrivRequest: () => un
});
h();
h();
h();
var Ue = (e => (e.pb = "PB", e.json = "JSON", e))(Ue || {});
h();
h();
function Pn(n) {
  return typeof n == "number";
}
function Me(n) {
  return n instanceof Uint8Array;
}
function Nn(n, r, e) {
  var t = r ? r.byteLength : e || 65536;
  if (t & 4095 || t <= 0) throw new Error("heap size must be a positive integer and a multiple of 4096");
  return r = r || new n(new ArrayBuffer(t)), r;
}
function Lt(n, r, e, t, i) {
  var o = n.length - r,
    f = o < i ? o : i;
  return n.set(e.subarray(t, t + f), r), f;
}
var me = (() => {
    function n() {
      var r = Error.apply(this, arguments);
      this.message = r.message, this.stack = r.stack;
    }
    return n.prototype = Object.create(Error.prototype, {
      name: {
        value: "IllegalArgumentError"
      }
    }), n;
  })(),
  Mt = (() => {
    function n() {
      var r = Error.apply(this, arguments);
      this.message = r.message, this.stack = r.stack;
    }
    return n.prototype = Object.create(Error.prototype, {
      name: {
        value: "SecurityError"
      }
    }), n;
  })(),
  Ae = (() => {
    var n = !1,
      r,
      e;
    function t() {
      r = [], e = [];
      var y = 1,
        B,
        C;
      for (B = 0; B < 255; B++) r[B] = y, C = y & 128, y <<= 1, y &= 255, C === 128 && (y ^= 27), y ^= r[B], e[r[B]] = B;
      r[255] = r[0], e[0] = 0, n = !0;
    }
    function i(y, B) {
      var C = r[(e[y] + e[B]) % 255];
      return (y === 0 || B === 0) && (C = 0), C;
    }
    function o(y) {
      var B = r[255 - e[y]];
      return y === 0 && (B = 0), B;
    }
    var f, s, A, u;
    function l() {
      n || t();
      function y(k) {
        var ee, J, D;
        for (J = D = o(k), ee = 0; ee < 4; ee++) J = (J << 1 | J >>> 7) & 255, D ^= J;
        return D ^= 99, D;
      }
      f = [], s = [], A = [[], [], [], []], u = [[], [], [], []];
      for (var B = 0; B < 256; B++) {
        var C = y(B);
        f[B] = C, s[C] = B, A[0][B] = i(2, C) << 24 | C << 16 | C << 8 | i(3, C), u[0][C] = i(14, B) << 24 | i(9, B) << 16 | i(13, B) << 8 | i(11, B);
        for (var T = 1; T < 4; T++) A[T][B] = A[T - 1][B] >>> 8 | A[T - 1][B] << 24, u[T][C] = u[T - 1][C] >>> 8 | u[T - 1][C] << 24;
      }
    }
    var g = function (y, B) {
      l();
      var C = new Uint32Array(B);
      C.set(f, 512), C.set(s, 768);
      for (var T = 0; T < 4; T++) C.set(A[T], 4096 + 1024 * T >> 2), C.set(u[T], 8192 + 1024 * T >> 2);
      function k(D, te, ye, x, v, O, R, j, X) {
        var M = C.subarray(0, 60),
          Z = C.subarray(256, 256 + 60);
        M.set([te, ye, x, v, O, R, j, X]);
        for (var N = D, se = 1; N < 4 * D + 28; N++) {
          var F = M[N - 1];
          (N % D === 0 || D === 8 && N % D === 4) && (F = f[F >>> 24] << 24 ^ f[F >>> 16 & 255] << 16 ^ f[F >>> 8 & 255] << 8 ^ f[F & 255]), N % D === 0 && (F = F << 8 ^ F >>> 24 ^ se << 24, se = se << 1 ^ (se & 128 ? 27 : 0)), M[N] = M[N - D] ^ F;
        }
        for (var _ = 0; _ < N; _ += 4) for (var re = 0; re < 4; re++) {
          var F = M[N - (4 + _) + (4 - re) % 4];
          _ < 4 || _ >= N - 4 ? Z[_ + re] = F : Z[_ + re] = u[0][f[F >>> 24]] ^ u[1][f[F >>> 16 & 255]] ^ u[2][f[F >>> 8 & 255]] ^ u[3][f[F & 255]];
        }
        J.set_rounds(D + 5);
      }
      var ee = {
          Uint8Array,
          Uint32Array
        },
        J = function (D, te, ye) {
          var x = 0,
            v = 0,
            O = 0,
            R = 0,
            j = 0,
            X = 0,
            M = 0,
            Z = 0,
            N = 0,
            se = 0,
            F = 0,
            _ = 0,
            re = 0,
            De = 0,
            ge = 0,
            Re = 0,
            Q = 0,
            U = 0,
            pe = 0,
            ae = 0,
            Be = 0,
            b = new D.Uint32Array(ye),
            d = new D.Uint8Array(ye);
          function ne(c, a, w, m, z, V, W, $) {
            c = c | 0, a = a | 0, w = w | 0, m = m | 0, z = z | 0, V = V | 0, W = W | 0, $ = $ | 0;
            var Ge = 0,
              xe = 0,
              ke = 0,
              Dt = 0,
              qt = 0,
              Gt = 0,
              xt = 0,
              ie = 0;
            for (Ge = w | 1024, xe = w | 2048, ke = w | 3072, z = z ^ b[(c | 0) >> 2], V = V ^ b[(c | 4) >> 2], W = W ^ b[(c | 8) >> 2], $ = $ ^ b[(c | 12) >> 2], ie = 16; (ie | 0) <= m << 4; ie = ie + 16 | 0) Dt = b[(w | z >> 22 & 1020) >> 2] ^ b[(Ge | V >> 14 & 1020) >> 2] ^ b[(xe | W >> 6 & 1020) >> 2] ^ b[(ke | $ << 2 & 1020) >> 2] ^ b[(c | ie | 0) >> 2], qt = b[(w | V >> 22 & 1020) >> 2] ^ b[(Ge | W >> 14 & 1020) >> 2] ^ b[(xe | $ >> 6 & 1020) >> 2] ^ b[(ke | z << 2 & 1020) >> 2] ^ b[(c | ie | 4) >> 2], Gt = b[(w | W >> 22 & 1020) >> 2] ^ b[(Ge | $ >> 14 & 1020) >> 2] ^ b[(xe | z >> 6 & 1020) >> 2] ^ b[(ke | V << 2 & 1020) >> 2] ^ b[(c | ie | 8) >> 2], xt = b[(w | $ >> 22 & 1020) >> 2] ^ b[(Ge | z >> 14 & 1020) >> 2] ^ b[(xe | V >> 6 & 1020) >> 2] ^ b[(ke | W << 2 & 1020) >> 2] ^ b[(c | ie | 12) >> 2], z = Dt, V = qt, W = Gt, $ = xt;
            x = b[(a | z >> 22 & 1020) >> 2] << 24 ^ b[(a | V >> 14 & 1020) >> 2] << 16 ^ b[(a | W >> 6 & 1020) >> 2] << 8 ^ b[(a | $ << 2 & 1020) >> 2] ^ b[(c | ie | 0) >> 2], v = b[(a | V >> 22 & 1020) >> 2] << 24 ^ b[(a | W >> 14 & 1020) >> 2] << 16 ^ b[(a | $ >> 6 & 1020) >> 2] << 8 ^ b[(a | z << 2 & 1020) >> 2] ^ b[(c | ie | 4) >> 2], O = b[(a | W >> 22 & 1020) >> 2] << 24 ^ b[(a | $ >> 14 & 1020) >> 2] << 16 ^ b[(a | z >> 6 & 1020) >> 2] << 8 ^ b[(a | V << 2 & 1020) >> 2] ^ b[(c | ie | 8) >> 2], R = b[(a | $ >> 22 & 1020) >> 2] << 24 ^ b[(a | z >> 14 & 1020) >> 2] << 16 ^ b[(a | V >> 6 & 1020) >> 2] << 8 ^ b[(a | W << 2 & 1020) >> 2] ^ b[(c | ie | 12) >> 2];
          }
          function Ee(c, a, w, m) {
            c = c | 0, a = a | 0, w = w | 0, m = m | 0, ne(0, 2048, 4096, Be, j ^ c, X ^ a, M ^ w, Z ^ m), j = x, X = v, M = O, Z = R;
          }
          function Xe(c, a, w, m) {
            c = c | 0, a = a | 0, w = w | 0, m = m | 0;
            var z = 0;
            ne(1024, 3072, 8192, Be, c, m, w, a), z = v, v = R, R = z, x = x ^ j, v = v ^ X, O = O ^ M, R = R ^ Z, j = c, X = a, M = w, Z = m;
          }
          function qe(c) {
            c = c | 0, Be = c;
          }
          function bn(c, a, w, m) {
            c = c | 0, a = a | 0, w = w | 0, m = m | 0, x = c, v = a, O = w, R = m;
          }
          function En(c, a, w, m) {
            c = c | 0, a = a | 0, w = w | 0, m = m | 0, j = c, X = a, M = w, Z = m;
          }
          function mn(c, a, w, m) {
            c = c | 0, a = a | 0, w = w | 0, m = m | 0, N = c, se = a, F = w, _ = m;
          }
          function Hn(c, a, w, m) {
            c = c | 0, a = a | 0, w = w | 0, m = m | 0, re = c, De = a, ge = w, Re = m;
          }
          function Tn(c, a, w, m) {
            c = c | 0, a = a | 0, w = w | 0, m = m | 0, _ = ~Re & _ | Re & m, F = ~ge & F | ge & w, se = ~De & se | De & a, N = ~re & N | re & c;
          }
          function On(c) {
            return c = c | 0, c & 15 ? -1 : (d[c | 0] = x >>> 24, d[c | 1] = x >>> 16 & 255, d[c | 2] = x >>> 8 & 255, d[c | 3] = x & 255, d[c | 4] = v >>> 24, d[c | 5] = v >>> 16 & 255, d[c | 6] = v >>> 8 & 255, d[c | 7] = v & 255, d[c | 8] = O >>> 24, d[c | 9] = O >>> 16 & 255, d[c | 10] = O >>> 8 & 255, d[c | 11] = O & 255, d[c | 12] = R >>> 24, d[c | 13] = R >>> 16 & 255, d[c | 14] = R >>> 8 & 255, d[c | 15] = R & 255, 16);
          }
          function Sn(c) {
            return c = c | 0, c & 15 ? -1 : (d[c | 0] = j >>> 24, d[c | 1] = j >>> 16 & 255, d[c | 2] = j >>> 8 & 255, d[c | 3] = j & 255, d[c | 4] = X >>> 24, d[c | 5] = X >>> 16 & 255, d[c | 6] = X >>> 8 & 255, d[c | 7] = X & 255, d[c | 8] = M >>> 24, d[c | 9] = M >>> 16 & 255, d[c | 10] = M >>> 8 & 255, d[c | 11] = M & 255, d[c | 12] = Z >>> 24, d[c | 13] = Z >>> 16 & 255, d[c | 14] = Z >>> 8 & 255, d[c | 15] = Z & 255, 16);
          }
          function Rn(c, a, w) {
            c = c | 0, a = a | 0, w = w | 0;
            var m = 0;
            if (a & 15) return -1;
            for (; (w | 0) >= 16;) vn[c & 7](d[a | 0] << 24 | d[a | 1] << 16 | d[a | 2] << 8 | d[a | 3], d[a | 4] << 24 | d[a | 5] << 16 | d[a | 6] << 8 | d[a | 7], d[a | 8] << 24 | d[a | 9] << 16 | d[a | 10] << 8 | d[a | 11], d[a | 12] << 24 | d[a | 13] << 16 | d[a | 14] << 8 | d[a | 15]), d[a | 0] = x >>> 24, d[a | 1] = x >>> 16 & 255, d[a | 2] = x >>> 8 & 255, d[a | 3] = x & 255, d[a | 4] = v >>> 24, d[a | 5] = v >>> 16 & 255, d[a | 6] = v >>> 8 & 255, d[a | 7] = v & 255, d[a | 8] = O >>> 24, d[a | 9] = O >>> 16 & 255, d[a | 10] = O >>> 8 & 255, d[a | 11] = O & 255, d[a | 12] = R >>> 24, d[a | 13] = R >>> 16 & 255, d[a | 14] = R >>> 8 & 255, d[a | 15] = R & 255, m = m + 16 | 0, a = a + 16 | 0, w = w - 16 | 0;
            return m | 0;
          }
          function Un(c, a, w) {
            c = c | 0, a = a | 0, w = w | 0;
            var m = 0;
            if (a & 15) return -1;
            for (; (w | 0) >= 16;) Fn[c & 1](d[a | 0] << 24 | d[a | 1] << 16 | d[a | 2] << 8 | d[a | 3], d[a | 4] << 24 | d[a | 5] << 16 | d[a | 6] << 8 | d[a | 7], d[a | 8] << 24 | d[a | 9] << 16 | d[a | 10] << 8 | d[a | 11], d[a | 12] << 24 | d[a | 13] << 16 | d[a | 14] << 8 | d[a | 15]), m = m + 16 | 0, a = a + 16 | 0, w = w - 16 | 0;
            return m | 0;
          }
          var vn = [,, Ee, Xe,,,,],
            Fn = [Ee];
          return {
            set_rounds: qe,
            set_state: bn,
            set_iv: En,
            set_nonce: mn,
            set_mask: Hn,
            set_counter: Tn,
            get_state: On,
            get_iv: Sn,
            cipher: Rn,
            mac: Un
          };
        }(ee, y, B);
      return J.set_key = k, J;
    };
    return g.ENC = {
      CBC: 2
    }, g.DEC = {
      CBC: 3
    }, g.MAC = {
      CBC: 0
    }, g.HEAP_DATA = 16384, g;
  })(),
  st = new Uint8Array(1048576),
  Pt = (() => Ae(null, st.buffer))(),
  ut = class {
    constructor(r, e, t, i, o) {
      this.nonce = null, this.counter = 0, this.counterSize = 0, this.heap = Nn(Uint8Array, i).subarray(Ae.HEAP_DATA), this.asm = o || Ae(null, this.heap.buffer), this.mode = null, this.key = null, this.AES_reset(r, e, t);
    }
    AES_set_key(r) {
      if (r !== void 0) {
        if (!Me(r)) throw new TypeError("unexpected key type");
        var e = r.length;
        if (e !== 16 && e !== 24 && e !== 32) throw new me("illegal key size");
        var t = new DataView(r.buffer, r.byteOffset, r.byteLength);
        this.asm.set_key(e >> 2, t.getUint32(0), t.getUint32(4), t.getUint32(8), t.getUint32(12), e > 16 ? t.getUint32(16) : 0, e > 16 ? t.getUint32(20) : 0, e > 24 ? t.getUint32(24) : 0, e > 24 ? t.getUint32(28) : 0), this.key = r;
      } else if (!this.key) throw new Error("key is required");
    }
    AES_CTR_set_options(r, e, t) {
      if (t !== void 0) {
        if (t < 8 || t > 48) throw new me("illegal counter size");
        this.counterSize = t;
        var i = Math.pow(2, t) - 1;
        this.asm.set_mask(0, 0, i / 4294967296 | 0, i | 0);
      } else this.counterSize = t = 48, this.asm.set_mask(0, 0, 65535, 4294967295);
      if (r !== void 0) {
        if (!Me(r)) throw new TypeError("unexpected nonce type");
        var o = r.length;
        if (!o || o > 16) throw new me("illegal nonce size");
        this.nonce = r;
        var f = new DataView(new ArrayBuffer(16));
        new Uint8Array(f.buffer).set(r), this.asm.set_nonce(f.getUint32(0), f.getUint32(4), f.getUint32(8), f.getUint32(12));
      } else throw new Error("nonce is required");
      if (e !== void 0) {
        if (!Pn(e)) throw new TypeError("unexpected counter type");
        if (e < 0 || e >= Math.pow(2, t)) throw new me("illegal counter value");
        this.counter = e, this.asm.set_counter(0, 0, e / 4294967296 | 0, e | 0);
      } else this.counter = 0;
    }
    AES_set_iv(r) {
      if (r !== void 0) {
        if (!Me(r)) throw new TypeError("unexpected iv type");
        if (r.length !== 16) throw new me("illegal iv size");
        var e = new DataView(r.buffer, r.byteOffset, r.byteLength);
        this.iv = r, this.asm.set_iv(e.getUint32(0), e.getUint32(4), e.getUint32(8), e.getUint32(12));
      } else this.iv = null, this.asm.set_iv(0, 0, 0, 0);
    }
    AES_set_padding(r) {
      r !== void 0 ? this.padding = !!r : this.padding = !0;
    }
    AES_reset(r, e, t) {
      return this.result = null, this.pos = 0, this.len = 0, this.AES_set_key(r), this.AES_set_iv(e), this.AES_set_padding(t), this;
    }
    AES_Encrypt_process(r) {
      if (!Me(r)) throw new TypeError("data isn't of expected type");
      for (var e = this.asm, t = this.heap, i = Ae.ENC[this.mode], o = Ae.HEAP_DATA, f = this.pos, s = this.len, A = 0, u = r.length || 0, l = 0, g = s + u & -16, y = 0, B = new Uint8Array(g); u > 0;) y = Lt(t, f + s, r, A, u), s += y, A += y, u -= y, y = e.cipher(i, o + f, s), y && B.set(t.subarray(f, f + y), l), l += y, y < s ? (f += y, s -= y) : (f = 0, s = 0);
      return this.result = B, this.pos = f, this.len = s, this;
    }
    AES_Encrypt_finish(r) {
      var e = null,
        t = 0;
      r !== void 0 && (e = this.AES_Encrypt_process(r).result, t = e.length);
      var i = this.asm,
        o = this.heap,
        f = Ae.ENC[this.mode],
        s = Ae.HEAP_DATA,
        A = this.pos,
        u = this.len,
        l = 16 - u % 16,
        g = u;
      if (this.hasOwnProperty("padding")) {
        if (this.padding) {
          for (var y = 0; y < l; ++y) o[A + u + y] = l;
          u += l, g = u;
        } else if (u % 16) throw new me("data length must be a multiple of the block size");
      } else u += l;
      var B = new Uint8Array(t + g);
      return t && B.set(e), u && i.cipher(f, s + A, u), g && B.set(o.subarray(A, A + g), t), this.result = B, this.pos = 0, this.len = 0, this;
    }
    AES_Decrypt_process(r) {
      if (!Me(r)) throw new TypeError("data isn't of expected type");
      var e = this.asm,
        t = this.heap,
        i = Ae.DEC[this.mode],
        o = Ae.HEAP_DATA,
        f = this.pos,
        s = this.len,
        A = 0,
        u = r.length || 0,
        l = 0,
        g = s + u & -16,
        y = 0,
        B = 0;
      this.padding && (y = s + u - g || 16, g -= y);
      for (var C = new Uint8Array(g); u > 0;) B = Lt(t, f + s, r, A, u), s += B, A += B, u -= B, B = e.cipher(i, o + f, s - (u ? 0 : y)), B && C.set(t.subarray(f, f + B), l), l += B, B < s ? (f += B, s -= B) : (f = 0, s = 0);
      return this.result = C, this.pos = f, this.len = s, this;
    }
    AES_Decrypt_finish(r) {
      var e = null,
        t = 0;
      r !== void 0 && (e = this.AES_Decrypt_process(r).result, t = e.length);
      var i = this.asm,
        o = this.heap,
        f = Ae.DEC[this.mode],
        s = Ae.HEAP_DATA,
        A = this.pos,
        u = this.len,
        l = u;
      if (u > 0) {
        if (u % 16) {
          if (this.hasOwnProperty("padding")) throw new me("data length must be a multiple of the block size");
          u += 16 - u % 16;
        }
        if (i.cipher(f, s + A, u), this.hasOwnProperty("padding") && this.padding) {
          var g = o[A + l - 1];
          if (g < 1 || g > 16 || g > l) throw new Mt("bad padding");
          for (var y = 0, B = g; B > 1; B--) y |= g ^ o[A + l - B];
          if (y) throw new Mt("bad padding");
          l -= g;
        }
      }
      var C = new Uint8Array(t + l);
      return t > 0 && C.set(e), l > 0 && C.set(o.subarray(A, A + l), t), this.result = C, this.pos = 0, this.len = 0, this;
    }
  },
  le = (() => {
    class n extends ut {
      constructor(e, t = null, i = !0, o, f) {
        super(e, t, i, o, f), this.mode = "CBC", this.BLOCK_SIZE = 16;
      }
      encrypt(e) {
        return this.AES_Encrypt_finish(e);
      }
      decrypt(e) {
        return this.AES_Decrypt_finish(e);
      }
    }
    return n.encrypt = _n, n.decrypt = zn, n;
  })();
function _n(n, r, e, t) {
  if (n === void 0) throw new SyntaxError("data required");
  if (r === void 0) throw new SyntaxError("key required");
  return new le(r, t, e, st, Pt).encrypt(n).result;
}
function zn(n, r, e, t) {
  if (n === void 0) throw new SyntaxError("data required");
  if (r === void 0) throw new SyntaxError("key required");
  return new le(r, t, e, st, Pt).decrypt(n).result;
}
h();
h();
function Yn(n) {
  if (true) return new Promise((r, e) => {
    for (var t = "AGFzbQEAAAABIgVgA39/fwBgBH9/f38AYAAAYAV/f39/fwBgBn9/f39/fwADBwYBAgADBAAEBQFwAQEBBQYBAYABgAEGCQF/AUHAzMACCwcdBwFhAgABYgABAWMAAgFkAAUBZQAEAWYAAwFnAQAK5zoG/hIBCn8gACgCBCIFQRBqIQQgBSgCDCACKAAMcyEGIAUoAgggAigACHMhByAFKAIEIAIoAARzIQggBSgCACACKAAAcyECIAAoAgAhAAJ/IAFFBEAgAEEETgRAIABBAXYhCQNAIAhBFnZB/AdxQbAiaigCACAHQQ52QfwHcUGwGmooAgAgBkEGdkH8B3FBsBJqKAIAIAJB/wFxQQJ0QbAKaigCACAEKAIAc3NzcyIAQRZ2QfwHcUGwImooAgAgB0EWdkH8B3FBsCJqKAIAIAZBDnZB/AdxQbAaaigCACACQQZ2QfwHcUGwEmooAgAgCEH/AXFBAnRBsApqKAIAIAQoAgRzc3NzIgFBDnZB/AdxQbAaaigCACAGQRZ2QfwHcUGwImooAgAgAkEOdkH8B3FBsBpqKAIAIAhBBnZB/AdxQbASaigCACAHQf8BcUECdEGwCmooAgAgBCgCCHNzc3MiBUEGdkH8B3FBsBJqKAIAIAJBFnZB/AdxQbAiaigCACAIQQ52QfwHcUGwGmooAgAgB0EGdkH8B3FBsBJqKAIAIAZB/wFxQQJ0QbAKaigCACAEKAIMc3NzcyICQf8BcUECdEGwCmooAgAgBCgCHHNzc3MhBiACQRZ2QfwHcUGwImooAgAgAEEOdkH8B3FBsBpqKAIAIAFBBnZB/AdxQbASaigCACAFQf8BcUECdEGwCmooAgAgBCgCGHNzc3MhByAFQRZ2QfwHcUGwImooAgAgAkEOdkH8B3FBsBpqKAIAIABBBnZB/AdxQbASaigCACABQf8BcUECdEGwCmooAgAgBCgCFHNzc3MhCCABQRZ2QfwHcUGwImooAgAgBUEOdkH8B3FBsBpqKAIAIAJBBnZB/AdxQbASaigCACAAQf8BcUECdEGwCmooAgAgBCgCEHNzc3MhAiAEQSBqIQQgCUECSyEAIAlBAWshCSAADQALC0GwKiEFIAdBFnZB/AdxQbAiaigCACAGQQ52QfwHcUGwGmooAgAgAkEGdkH8B3FBsBJqKAIAIAhB/wFxQQJ0QbAKaigCACAEKAIEc3NzcyIAIQEgCEEWdkH8B3FBsCJqKAIAIAdBDnZB/AdxQbAaaigCACAGQQZ2QfwHcUGwEmooAgAgAkH/AXFBAnRBsApqKAIAIAQoAgBzc3NzIgkhCiACQRZ2QfwHcUGwImooAgAgCEEOdkH8B3FBsBpqKAIAIAdBBnZB/AdxQbASaigCACAGQf8BcUECdEGwCmooAgAgBCgCDHNzc3MiCyEMIAZBFnZB/AdxQbAiaigCACACQQ52QfwHcUGwGmooAgAgCEEGdkH8B3FBsBJqKAIAIAdB/wFxQQJ0QbAKaigCACAEKAIIc3NzcyINDAELIABBBE4EQCAAQQF2IQkDQCAIQRZ2QfwHcUGwxABqKAIAIAJBDnZB/AdxQbA8aigCACAGQQZ2QfwHcUGwNGooAgAgB0H/AXFBAnRBsCxqKAIAIAQoAghzc3NzIgBBFnZB/AdxQbDEAGooAgAgAkEWdkH8B3FBsMQAaigCACAGQQ52QfwHcUGwPGooAgAgB0EGdkH8B3FBsDRqKAIAIAhB/wFxQQJ0QbAsaigCACAEKAIEc3NzcyIBQQ52QfwHcUGwPGooAgAgBkEWdkH8B3FBsMQAaigCACAHQQ52QfwHcUGwPGooAgAgCEEGdkH8B3FBsDRqKAIAIAJB/wFxQQJ0QbAsaigCACAEKAIAc3NzcyIFQQZ2QfwHcUGwNGooAgAgB0EWdkH8B3FBsMQAaigCACAIQQ52QfwHcUGwPGooAgAgAkEGdkH8B3FBsDRqKAIAIAZB/wFxQQJ0QbAsaigCACAEKAIMc3NzcyICQf8BcUECdEGwLGooAgAgBCgCHHNzc3MhBiABQRZ2QfwHcUGwxABqKAIAIAVBDnZB/AdxQbA8aigCACACQQZ2QfwHcUGwNGooAgAgAEH/AXFBAnRBsCxqKAIAIAQoAhhzc3NzIQcgBUEWdkH8B3FBsMQAaigCACACQQ52QfwHcUGwPGooAgAgAEEGdkH8B3FBsDRqKAIAIAFB/wFxQQJ0QbAsaigCACAEKAIUc3NzcyEIIAJBFnZB/AdxQbDEAGooAgAgAEEOdkH8B3FBsDxqKAIAIAFBBnZB/AdxQbA0aigCACAFQf8BcUECdEGwLGooAgAgBCgCEHNzc3MhAiAEQSBqIQQgCUECSyEAIAlBAWshCSAADQALC0GwCCEFIAJBFnZB/AdxQbDEAGooAgAgBkEOdkH8B3FBsDxqKAIAIAdBBnZB/AdxQbA0aigCACAIQf8BcUECdEGwLGooAgAgBCgCBHNzc3MiCyEBIAhBFnZB/AdxQbDEAGooAgAgAkEOdkH8B3FBsDxqKAIAIAZBBnZB/AdxQbA0aigCACAHQf8BcUECdEGwLGooAgAgBCgCCHNzc3MiDSEKIAdBFnZB/AdxQbDEAGooAgAgCEEOdkH8B3FBsDxqKAIAIAJBBnZB/AdxQbA0aigCACAGQf8BcUECdEGwLGooAgAgBCgCDHNzc3MiACEMIAZBFnZB/AdxQbDEAGooAgAgB0EOdkH8B3FBsDxqKAIAIAhBBnZB/AdxQbA0aigCACACQf8BcUECdEGwLGooAgAgBCgCAHNzc3MiCQshAiAEKAIQIQYgBCgCFCEHIAQoAhghCCADIAQoAhwiBCAFIAxB/wFxai0AAHM6AAwgAyAIIAUgDUH/AXFqLQAAczoACCADIAcgBSABQf8BcWotAABzOgAEIAMgBiAFIAlB/wFxai0AAHM6AAAgAyAEIAUgCkEYdmotAABBGHRzQRh2OgAPIAMgCCAFIAtBGHZqLQAAQRh0c0EYdjoACyADIAcgBSACQRh2ai0AAEEYdHNBGHY6AAcgAyAGIAUgAEEYdmotAABBGHRzQRh2OgADIAMgBCAFIAFBEHZB/wFxai0AAEEQdHNBEHY6AA4gAyAEIAUgAkEIdkH/AXFqLQAAQQh0c0EIdjoADSADIAggBSAJQRB2Qf8BcWotAABBEHRzQRB2OgAKIAMgCCAFIABBCHZB/wFxai0AAEEIdHNBCHY6AAkgAyAHIAUgDEEQdkH/AXFqLQAAQRB0c0EQdjoABiADIAcgBSAKQQh2Qf8BcWotAABBCHRzQQh2OgAFIAMgBiAFIA1BEHZB/wFxai0AAEEQdHNBEHY6AAIgAyAGIAUgC0EIdkH/AXFqLQAAQQh0c0EIdjoAAQsDAAELpxYBBn8CQCAAAn9BCiACQYABRg0AGiACQYACRwRAIAJBwAFHDQJBDAwBC0EOCyIENgIAIAAgAEEIaiIDNgIEIAJBBXYhBUEAIQIDQCADIAJBAnQiBmogASAGaigAADYCACACQQFqIgIgBUcNAAsCQAJAAkAgBEEKaw4FAQMAAwIDCyAAIAAoAgggACgCHCIBQQh2Qf8BcUGwCGotAABzIAFBEHZB/wFxQbAIai0AAEEIdHMgAUEYdkGwCGotAABBEHRzIAFB/wFxQbAIai0AAEEYdHMiA0EBcyICNgIgIAAgAiAAKAIMcyICNgIkIAAgACgCECIGIAJzIgQ2AiggACAAKAIUIARzIgQ2AiwgACAAKAIYIgcgBHMiBTYCMCAAIAEgBXMiATYCNCAAIAFBCHZB/wFxQbAIai0AACABQRB2Qf8BcUGwCGotAABBCHRyIAFBGHZBsAhqLQAAQRB0ciABQf8BcUGwCGotAABBGHRyIANzIghBA3MiBTYCOCAAQUBrIAUgBnMiAzYCACAAIAIgBXMiBTYCPCAAIAMgB3MiBjYCSCAAIAMgBHM2AkQgACABIAZzIgI2AkwgACACQQh2Qf8BcUGwCGotAAAgAkEQdkH/AXFBsAhqLQAAQQh0ciACQRh2QbAIai0AAEEQdHIgAkH/AXFBsAhqLQAAQRh0ciAIcyIIQQdzIgI2AlAgACACIAVzIgU2AlQgACAEIAVzIgQ2AlwgACADIAVzNgJYIAAgASAEcyICNgJkIAAgBCAGczYCYCAAIAJBCHZB/wFxQbAIai0AACACQRB2Qf8BcUGwCGotAABBCHRyIAJBGHZBsAhqLQAAQRB0ciACQf8BcUGwCGotAABBGHRyIAhzIghBD3MiBjYCaCAAIAYgB3MiBzYCeCAAIAMgBnMiAzYCcCAAIAUgBnMiBTYCbCAAIAIgB3MiAjYCfCAAIAMgBHM2AnQgACACQQh2Qf8BcUGwCGotAAAgAkEQdkH/AXFBsAhqLQAAQQh0ciACQRh2QbAIai0AAEEQdHIgAkH/AXFBsAhqLQAAQRh0ciAIcyIGQR9zIgI2AoABIAAgAiAFcyICNgKEASAAIAEgAnMiATYClAEgACACIARzIgQ2AowBIAAgAiADcyIDNgKIASAAIAQgB3MiBTYCkAEgACABQQh2Qf8BcUGwCGotAAAgAUEQdkH/AXFBsAhqLQAAQQh0ciABQRh2QbAIai0AAEEQdHIgAUH/AXFBsAhqLQAAQRh0ciAGcyIGQT9zIgc2ApgBIAAgAiAHcyICNgKcASAAIAIgA3MiAzYCoAEgACADIARzIgQ2AqQBIAAgBCAFcyIFNgKoASAAIAEgBXMiATYCrAEgACABQQh2Qf8BcUGwCGotAAAgAUEQdkH/AXFBsAhqLQAAQQh0ciABQRh2QbAIai0AAEEQdHIgAUH/AXFBsAhqLQAAQRh0ciAGcyIGQf8AcyIHNgKwASAAIAIgB3MiAjYCtAEgACACIANzIgM2ArgBIAAgAyAEcyIENgK8ASAAIAQgBXMiBTYCwAEgACABIAVzIgE2AsQBIAAgAUEIdkH/AXFBsAhqLQAAIAFBEHZB/wFxQbAIai0AAEEIdHIgAUEYdkGwCGotAABBEHRyIAFB/wFxQbAIai0AAEEYdHIgBnNB/wFzIgY2AsgBIAAgAiAGcyICNgLMASAAIAIgA3MiAjYC0AEgACACIARzIgI2AtQBIAAgAiAFcyICNgLYASAAIAEgAnM2AtwBDwsgACAAKAIIIAAoAhQiAUEIdkH/AXFBsAhqLQAAcyABQRB2Qf8BcUGwCGotAABBCHRzIAFBGHZBsAhqLQAAQRB0cyABQf8BcUGwCGotAABBGHRzIgRBAXMiAjYCGCAAIAIgACgCDHMiAjYCHCAAIAAoAhAgAnMiAzYCICAAIAEgA3MiATYCJCAAIAFBCHZB/wFxQbAIai0AACABQRB2Qf8BcUGwCGotAABBCHRyIAFBGHZBsAhqLQAAQRB0ciABQf8BcUGwCGotAABBGHRyIARzIgRBA3MiBTYCKCAAIAIgBXMiAjYCLCAAIAIgA3MiAzYCMCAAIAEgA3MiATYCNCAAIAFBCHZB/wFxQbAIai0AACABQRB2Qf8BcUGwCGotAABBCHRyIAFBGHZBsAhqLQAAQRB0ciABQf8BcUGwCGotAABBGHRyIARzIgRBB3MiBTYCOCAAIAIgBXMiAjYCPCAAQUBrIAIgA3MiAzYCACAAIAEgA3MiATYCRCAAIAFBCHZB/wFxQbAIai0AACABQRB2Qf8BcUGwCGotAABBCHRyIAFBGHZBsAhqLQAAQRB0ciABQf8BcUGwCGotAABBGHRyIARzIgRBD3MiBTYCSCAAIAIgBXMiAjYCTCAAIAIgA3MiAzYCUCAAIAEgA3MiATYCVCAAIAFBCHZB/wFxQbAIai0AACABQRB2Qf8BcUGwCGotAABBCHRyIAFBGHZBsAhqLQAAQRB0ciABQf8BcUGwCGotAABBGHRyIARzIgRBH3MiBTYCWCAAIAIgBXMiAjYCXCAAIAIgA3MiAzYCYCAAIAEgA3MiATYCZCAAIAFBCHZB/wFxQbAIai0AACABQRB2Qf8BcUGwCGotAABBCHRyIAFBGHZBsAhqLQAAQRB0ciABQf8BcUGwCGotAABBGHRyIARzIgRBP3MiBTYCaCAAIAIgBXMiAjYCbCAAIAIgA3MiAzYCcCAAIAEgA3MiATYCdCAAIAFBCHZB/wFxQbAIai0AACABQRB2Qf8BcUGwCGotAABBCHRyIAFBGHZBsAhqLQAAQRB0ciABQf8BcUGwCGotAABBGHRyIARzIgRB/wBzIgU2AnggACACIAVzIgI2AnwgACACIANzIgM2AoABIAAgASADcyIBNgKEASAAIAFBCHZB/wFxQbAIai0AACABQRB2Qf8BcUGwCGotAABBCHRyIAFBGHZBsAhqLQAAQRB0ciABQf8BcUGwCGotAABBGHRyIARzIgRB/wFzIgU2AogBIAAgAiAFcyICNgKMASAAIAIgA3MiAzYCkAEgACABIANzIgE2ApQBIAAgAUEIdkH/AXFBsAhqLQAAIAFBEHZB/wFxQbAIai0AAEEIdHIgAUEYdkGwCGotAABBEHRyIAFB/wFxQbAIai0AAEEYdHIgBHMiBEHkAXMiBTYCmAEgACACIAVzIgI2ApwBIAAgAiADcyIDNgKgASAAIAEgA3MiATYCpAEgACABQQh2Qf8BcUGwCGotAAAgAUEQdkH/AXFBsAhqLQAAQQh0ciABQRh2QbAIai0AAEEQdHIgAUH/AXFBsAhqLQAAQRh0ciAEc0HSAXMiBDYCqAEgACACIARzIgI2AqwBIAAgAiADcyICNgKwASAAIAEgAnM2ArQBDwsgAygCACEBQQAhBANAIAMgAygCHCIAQQh2Qf8BcUGwCGotAAAgBEECdEGACGooAgAgAXNzIABBEHZB/wFxQbAIai0AAEEIdHMgAEEYdkGwCGotAABBEHRzIABB/wFxQbAIai0AAEEYdHMiATYCICADIAEgAygCBHMiAjYCJCADIAMoAgggAnMiAjYCKCADIAMoAgwgAnMiAjYCLCADIAMoAhAgAkH/AXFBsAhqLQAAcyACQQh2Qf8BcUGwCGotAABBCHRzIAJBEHZB/wFxQbAIai0AAEEQdHMgAkEYdkGwCGotAABBGHRzIgI2AjAgAyACIAMoAhRzIgI2AjQgAyADKAIYIAJzIgI2AjggAyAAIAJzNgI8IANBIGohAyAEQQFqIgRBB0cNAAsLC8IGARJ/IwBBEGsiBSQAIAFBAEoEQCACQQFqIRYgAkECaiEIIAJBA2ohCSACQQRqIQogAkEFaiELIAJBBmohDCACQQdqIQ0gAkEIaiEOIAJBCWohDyACQQpqIRAgAkELaiERIAJBDGohEiACQQ1qIRMgAkEOaiEUIAJBD2ohFQNAIABBASACIAUQACAEIAUtAAAgAy0AAHM6AAAgBCAFLQABIAMtAAFzOgABIAQgBS0AAiADLQACczoAAiAEIAUtAAMgAy0AA3M6AAMgBCAFLQAEIAMtAARzOgAEIAQgBS0ABSADLQAFczoABSAEIAUtAAYgAy0ABnM6AAYgBCAFLQAHIAMtAAdzOgAHIAQgBS0ACCADLQAIczoACCAEIAUtAAkgAy0ACXM6AAkgBCAFLQAKIAMtAApzOgAKIAQgBS0ACyADLQALczoACyAEIAUtAAwgAy0ADHM6AAwgBCAFLQANIAMtAA1zOgANIAQgBS0ADiADLQAOczoADiAEIAUtAA8gAy0AD3M6AA8gFSEGAkACQCACLQAPIgdB/wFHDQAgFUEAOgAAIBQhBiAULQAAIgdB/wFHDQAgFEEAOgAAIBMhBiATLQAAIgdB/wFHDQAgE0EAOgAAIBIhBiASLQAAIgdB/wFHDQAgEkEAOgAAIBEhBiARLQAAIgdB/wFHDQAgEUEAOgAAIBAhBiAQLQAAIgdB/wFHDQAgEEEAOgAAIA8hBiAPLQAAIgdB/wFHDQAgD0EAOgAAIA4hBiAOLQAAIgdB/wFHDQAgDkEAOgAAIA0hBiANLQAAIgdB/wFHDQAgDUEAOgAAIAwhBiAMLQAAIgdB/wFHDQAgDEEAOgAAIAshBiALLQAAIgdB/wFHDQAgC0EAOgAAIAohBiAKLQAAIgdB/wFHDQAgCkEAOgAAIAkhBiAJLQAAIgdB/wFHDQAgCUEAOgAAIAghBiAILQAAIgdB/wFHDQAgCEEAOgAAIBYiBi0AACIHQf8BRw0AIAJBADoAASACIQYgAi0AACIHQf8BRw0AIAJBADoAAAwBCyAGIAdBAWo6AAALIARBEGohBCADQRBqIQMgAUEQSyEGIAFBEGshASAGDQALCyAFQRBqJAALxQUBAn8jAEEQayIGJAACQCABBEAgAkEATA0BA0AgBSADLQAAIAQtAABzOgAAIAUgAy0AASAELQABczoAASAFIAMtAAIgBC0AAnM6AAIgBSADLQADIAQtAANzOgADIAUgAy0ABCAELQAEczoABCAFIAMtAAUgBC0ABXM6AAUgBSADLQAGIAQtAAZzOgAGIAUgAy0AByAELQAHczoAByAFQQhqIAMtAAggBC0ACHM6AAAgBSADLQAJIAQtAAlzOgAJIAUgAy0ACiAELQAKczoACiAFIAMtAAsgBC0AC3M6AAsgBSADLQAMIAQtAAxzOgAMIAUgAy0ADSAELQANczoADSAFIAMtAA4gBC0ADnM6AA4gBSADLQAPIAQtAA9zOgAPIAAgASAFIAUQACADIAUpAAg3AAggAyAFKQAANwAAIAVBEGohBSAEQRBqIQQgAkEQSyEHIAJBEGshAiAHDQALDAELIAJBAEwNAANAIAYgBCkAADcDACAGIAQpAAg3AwggAEEAIAQgBRAAIAUgAy0AACAFLQAAczoAACAFIAMtAAEgBS0AAXM6AAEgBSADLQACIAUtAAJzOgACIAUgAy0AAyAFLQADczoAAyAFIAMtAAQgBS0ABHM6AAQgBSADLQAFIAUtAAVzOgAFIAUgAy0ABiAFLQAGczoABiAFIAMtAAcgBS0AB3M6AAcgBSADLQAIIAUtAAhzOgAIIAUgAy0ACSAFLQAJczoACSAFIAMtAAogBS0ACnM6AAogBSADLQALIAUtAAtzOgALIAUgAy0ADCAFLQAMczoADCAFIAMtAA0gBS0ADXM6AA0gBSADLQAOIAUtAA5zOgAOIAUgAy0ADyAFLQAPczoADyADIAYpAwg3AAggAyAGKQMANwAAIAVBEGohBSAEQRBqIQQgAkEQSyEBIAJBEGshAiABDQALCyAGQRBqJAALrAUBAn8jAEGgAmsiAyQAAkAgAAJ/QQogAkGAAUYNABogAkGAAkcEQCACQcABRw0CQQwMAQtBDgs2AgAgACAAQQhqNgIEIANBCGogASACEAIgACADKAIMIAMoAghBBHRqIgEoAgA2AgggACABKAIENgIMIAAgASgCCDYCECAAIAEoAgw2AhQgAEEYaiECIAFBEGshASAAKAIAIgRBAk4EQANAIAIgASgCACIAQQh2Qf8BcUGwCGotAABBAnRBsBJqKAIAIABB/wFxQbAIai0AAEECdEGwCmooAgBzIABBEHZB/wFxQbAIai0AAEECdEGwGmooAgBzIABBGHZBsAhqLQAAQQJ0QbAiaigCAHM2AgAgAiABKAIEIgBBCHZB/wFxQbAIai0AAEECdEGwEmooAgAgAEH/AXFBsAhqLQAAQQJ0QbAKaigCAHMgAEEQdkH/AXFBsAhqLQAAQQJ0QbAaaigCAHMgAEEYdkGwCGotAABBAnRBsCJqKAIAczYCBCACIAEoAggiAEEIdkH/AXFBsAhqLQAAQQJ0QbASaigCACAAQf8BcUGwCGotAABBAnRBsApqKAIAcyAAQRB2Qf8BcUGwCGotAABBAnRBsBpqKAIAcyAAQRh2QbAIai0AAEECdEGwImooAgBzNgIIIAIgASgCDCIAQQh2Qf8BcUGwCGotAABBAnRBsBJqKAIAIABB/wFxQbAIai0AAEECdEGwCmooAgBzIABBEHZB/wFxQbAIai0AAEECdEGwGmooAgBzIABBGHZBsAhqLQAAQQJ0QbAiaigCAHM2AgwgAUEQayEBIAJBEGohAiAEQQJLIQAgBEEBayEEIAANAAsLIAIgASgCADYCACACIAEoAgQ2AgQgAiABKAIINgIIIAIgASgCDDYCDAsgA0GgAmokAAsLs0QCAEGACAslAQAAAAIAAAAEAAAACAAAABAAAAAgAAAAQAAAAIAAAAAbAAAANgBBsAgLgERjfHd78mtvxTABZyv+16t2yoLJffpZR/Ct1KKvnKRywLf9kyY2P/fMNKXl8XHYMRUExyPDGJYFmgcSgOLrJ7J1CYMsGhtuWqBSO9azKeMvhFPRAO0g/LFbasu+OUpMWM/Q76r7Q00zhUX5An9QPJ+oUaNAj5KdOPW8ttohEP/z0s0ME+xfl0QXxKd+PWRdGXNggU/cIiqQiEbuuBTeXgvb4DI6CkkGJFzC06xikZXkeefIN22N1U6pbFb06mV6rgi6eCUuHKa0xujddB9LvYuKcD61ZkgD9g5hNVe5hsEdnuH4mBFp2Y6Umx6H6c5VKN+MoYkNv+ZCaEGZLQ+wVLsWUfSnUH5BZVMaF6TDOideljura8sfnUXxrPpYq0vjA5MgMPpVrXZt9ojMdpH1AkwlT+XX/MUqy9cmNUSAtWKjj96xWkkluhtnReoOmF3+wOHDL3UCgUzwEo1Gl6Nr0/nGA49f5xWSnJW/bXrrlVJZ2tS+gy1YdCHTSeBpKY7JyER1wolq9I55eJlYPmsnuXHdvuFPtvCIrRfJIKxmfc46tGPfShjlGjGCl1EzYGJTf0WxZHfgu2uuhP6BoBz5CCuUcEhoWI9F/RmU3myHUnv4t6tz0yNySwLi4x+PV2ZVqyqy6ygHL7XCA4bFe5rTNwilMCiH8iO/pbICA2q67RaCXIrPHCunebSS8wfy8E5p4qFl2vTNBgW+1dE0Yh/Epv6KNC5TnaLzVaAFiuEypPbrdQuD7DlAYO+qXnGfBr1uEFE+IYr5lt0GPd0+Ba5N5r1GkVSNtXHEXQUEBtRvYFAV/xmY+yTWvemXiUBDzGfZnnew6EK9B4mLiOcZWzh5yO7boXwKR3xCD+n4hB7JAAAAAAmAhoMyK+1IHhFwrGxack79Dv/7D4U4Vj2u1R42LTknCg/ZZGhcpiGbW1TRJDYuOgwKZ7GTV+cPtO6W0hubkZ6AwMVPYdwgolp3S2kcEhoW4pO6CsCgKuU8IuBDEhsXHQ4JDQvyi8etLbaouRQeqchX8RmFr3UHTO6Z3bujf2D99wEmn1xy9bxEZjvFW/t+NItDKXbLI8bctu38aLjk8WPXMdzKQmOFEBOXIkCExhEghUokfdK7Pfiu+TIRxymhbR2eL0vcsjDzDYZS7HfB49ArsxZsqXC5mRGUSPpH6WQiqPyMxKDwPxpWfSzYIjOQ74dJTsfZONHBjMqi/pjUCzam9YHPpXreKNq3jiY/rb+kLDqd5FB4kg1qX8ybVH5GYvaNE8KQ2LjoLjn3XoLDr/WfXYC+adCTfG/VLanPJRKzyKyZOxAYfafonGNu2zu7e80meAluWRj07Jq3AYNPmqjmlW5lqv/mfiG8zwjvFejmuueb2UpvNs7qnwnUKbB81jGksq8qPyMxxqWUMDWiZsB0Trw3/ILKpuCQ0LAzp9gV8QSYSkHs2vd/zVAOF5H2L3ZN1o1D77BNzKpNVOSWBN+e0bXjTGqIG8EsH7hGZVF/nV7qBAGMNV36h3Rz+wtBLrNnHVqS29JS6RBWM23WRxOa12GMN6EMeln4FI7rEzyJzqkn7rdhyTXhHOXtekexPJzS31lV8nM/GBTOeXPHN79T983qX/2qW989bxR4RNuGyq/zgbloxD44JDQswqNAXxYdw3K84iUMKDxJi/8NlUE5qAFxCAyz3ti05JxkVsGQe8uEYdUytnBIbFx00LhXQlBR9KdTfkFlwxoXpJY6J17LO6tr8R+dRaus+liTS+MDVSAw+vatdm2RiMx2JfUCTPxP5dfXxSrLgCY1RI+1YqNJ3rFaZyW6G5hF6g7hXf7AAsMvdRKBTPCjjUaXxmvT+ecDj1+VFZKc679tetqVUlkt1L6D01h0ISlJ4GlEjsnIanXCiXj0jnlrmVg+3Se5cba+4U8X8IitZskgrLR9zjoYY99KguUaMWCXUTNFYlN/4LFkd4S7a64c/oGglPkIK1hwSGgZj0X9h5TebLdSe/gjq3PT4nJLAlfjH48qZlWrB7LrKAMvtcKahsV7pdM3CPIwKIeyI7+lugIDalztFoIris8ckqd5tPDzB/KhTmnizWXa9NUGBb4f0TRiisSm/p00LlOgovNVMgWK4XWk9us5C4PsqkBg7wZecZ9RvW4Q+T4hij2W3Qau3T4FRk3mvbWRVI0FccRdbwQG1P9gUBUkGZj7l9a96cyJQEN3Z9mevbDoQogHiYs45xlb23nI7kehfArpfEIPyfiEHgAAAACDCYCGSDIr7aweEXBObFpy+/0O/1YPhTgePa7VJzYtOWQKD9khaFym0ZtbVDokNi6xDApnD5NX59K07paeG5uRT4DAxaJh3CBpWndLFhwSGgrik7rlwKAqQzwi4B0SGxcLDgkNrfKLx7kttqjIFB6phVfxGUyvdQe77pnd/aN/YJ/3ASa8XHL1xURmOzRb+352i0Mp3Msjxmi27fxjuOTxytcx3BBCY4VAE5ciIITGEX2FSiT40rs9Ea75Mm3HKaFLHZ4v89yyMOwNhlLQd8HjbCuzFpmpcLn6EZRIIkfpZMSo/IwaoPA/2FZ9LO8iM5DHh0lOwdk40f6MyqI2mNQLz6b1gSilet4m2reOpD+tv+QsOp0NUHiSm2pfzGJUfkbC9o0T6JDYuF4uOff1gsOvvp9dgHxp0JOpb9Uts88lEjvIrJmnEBh9buicY3vbO7sJzSZ49G5ZGAHsmreog0+aZeaVbn6q/+YIIbzP5u8V6Nm655vOSm821OqfCdYpsHyvMaSyMSo/IzDGpZTANaJmN3ROvKb8gsqw4JDQFTOn2ErxBJj3QezaDn/NUC8XkfaNdk3WTUPvsFTMqk3f5JYE457RtRtMaoi4wSwff0ZlUQSdXupdAYw1c/qHdC77C0Fas2cdUpLb0jPpEFYTbdZHjJrXYXo3oQyOWfgUiesTPO7OqSc1t2HJ7eEc5Tx6R7FZnNLfP1Xyc3kYFM6/c8c36lP3zVtf/aoU3z1vhnhE24HKr/M+uWjELDgkNF/Co0ByFh3DDLziJYsoPElB/w2VcTmoAd4IDLOc2LTkkGRWwWF7y4Rw1TK2dEhsXELQuFenUFH0ZVN+QaTDGhdeljona8s7q0XxH51Yq6z6A5NL4/pVIDBt9q12dpGIzEwl9QLX/E/ly9fFKkSAJjWjj7ViWknesRtnJboOmEXqwOFd/nUCwy/wEoFMl6ONRvnGa9Nf5wOPnJUVknrrv21Z2pVSgy3UviHTWHRpKUngyESOyYlqdcJ5ePSOPmuZWHHdJ7lPtr7hrRfwiKxmySA6tH3OShhj3zGC5RozYJdRf0ViU3fgsWSuhLtroBz+gSuU+QhoWHBI/RmPRWyHlN74t1J70yOrcwLickuPV+MfqypmVSgHsuvCAy+1e5qGxQil0zeH8jAopbIjv2q6AgOCXO0WHCuKz7SSp3ny8PMH4qFOafTNZdq+1QYFYh/RNP6KxKZTnTQuVaCi8+EyBYrrdaT27DkLg++qQGCfBl5xEFG9bor5PiEGPZbdBa7dPr1GTeaNtZFUXQVxxNRvBAYV/2BQ+yQZmOmX1r1DzIlAnndn2UK9sOiLiAeJWzjnGe7becgKR6F8D+l8Qh7J+IQAAAAAhoMJgO1IMitwrB4Rck5sWv/7/Q44Vg+F1R49rjknNi3ZZAoPpiFoXFTRm1suOiQ2Z7EMCucPk1eW0rTukZ4bm8VPgMAgomHcS2ladxoWHBK6CuKTKuXAoOBDPCIXHRIbDQsOCcet8ououS22qcgUHhmFV/EHTK913bvumWD9o38mn/cB9bxccjvFRGZ+NFv7KXaLQ8bcyyP8aLbt8WO45NzK1zGFEEJjIkATlxEghMYkfYVKPfjSuzIRrvmhbccpL0sdnjDz3LJS7A2G49B3wRZsK7O5malwSPoRlGQiR+mMxKj8Pxqg8CzYVn2Q7yIzTseHSdHB2Tii/ozKCzaY1IHPpvXeKKV6jibat7+kP62d5Cw6kg1QeMybal9GYlR+E8L2jbjokNj3Xi45r/WCw4C+n12TfGnQLalv1RKzzyWZO8isfacQGGNu6Jy7e9s7eAnNJhj0blm3AeyamqiDT25l5pXmfqr/zwghvOjm7xWb2brnNs5KbwnU6p981imwsq8xpCMxKj+UMMalZsA1orw3dE7KpvyC0LDgkNgVM6eYSvEE2vdB7FAOf832LxeR1o12TbBNQ+9NVMyqBN/klrXjntGIG0xqH7jBLFF/RmXqBJ1eNV0BjHRz+odBLvsLHVqzZ9JSkttWM+kQRxNt1mGMmtcMejehFI5Z+DyJ6xMn7s6pyTW3YeXt4RyxPHpH31mc0nM/VfLOeRgUN79zx83qU/eqW1/9bxTfPduGeETzgcqvxD65aDQsOCRAX8Kjw3IWHSUMvOJJiyg8lUH/DQFxOaiz3ggM5JzYtMGQZFaEYXvLtnDVMlx0SGxXQtC49KdQUUFlU34XpMMaJ16WOqtryzudRfEf+lirrOMDk0sw+lUgdm32rcx2kYgCTCX15df8TyrL18U1RIAmYqOPtbFaSd66G2cl6g6YRf7A4V0vdQLDTPASgUaXo43T+cZrj1/nA5KclRVteuu/Ulnalb6DLdR0IdNY4GkpScnIRI7CiWp1jnl49Fg+a5m5cd0n4U+2voitF/AgrGbJzjq0fd9KGGMaMYLlUTNgl1N/RWJkd+Cxa66Eu4GgHP4IK5T5SGhYcEX9GY/ebIeUe/i3UnPTI6tLAuJyH49X41WrKmbrKAeytcIDL8V7moY3CKXTKIfyML+lsiMDaroCFoJc7c8cK4p5tJKnB/Lw82nioU7a9M1lBb7VBjRiH9Gm/orELlOdNPNVoKKK4TIF9ut1pIPsOQtg76pAcZ8GXm4QUb0hivk+3QY9lj4Frt3mvUZNVI21kcRdBXEG1G8EUBX/YJj7JBm96ZfWQEPMidmed2foQr2wiYuIBxlbOOfI7tt5fApHoUIP6XyEHsn4AAAAAICGgwkr7UgyEXCsHlpyTmwO//v9hThWD67VHj0tOSc2D9lkClymIWhbVNGbNi46JApnsQxX5w+T7pbStJuRnhvAxU+A3CCiYXdLaVoSGhYck7oK4qAq5cAi4EM8GxcdEgkNCw6Lx63ytqi5LR6pyBTxGYVXdQdMr5ndu+5/YP2jASaf93L1vFxmO8VE+340W0MpdosjxtzL7fxotuTxY7gx3MrXY4UQQpciQBPGESCESiR9hbs9+NL5MhGuKaFtx54vSx2yMPPchlLsDcHj0HezFmwrcLmZqZRI+hHpZCJH/IzEqPA/GqB9LNhWM5DvIklOx4c40cHZyqL+jNQLNpj1gc+met4opbeOJtqtv6Q/Op3kLHiSDVBfzJtqfkZiVI0TwvbYuOiQOfdeLsOv9YJdgL6f0JN8adUtqW8lErPPrJk7yBh9pxCcY27oO7t72yZ4Cc1ZGPRumrcB7E+aqIOVbmXm/+Z+qrzPCCEV6Obv55vZum82zkqfCdTqsHzWKaSyrzE/IzEqpZQwxqJmwDVOvDd0gsqm/JDQsOCn2BUzBJhK8eza90HNUA5/kfYvF03WjXbvsE1Dqk1UzJYE3+TRteOeaogbTCwfuMFlUX9GXuoEnYw1XQGHdHP6C0Eu+2cdWrPb0lKSEFYz6dZHE23XYYyaoQx6N/gUjlkTPInrqSfuzmHJNbcc5e3hR7E8etLfWZzycz9VFM55GMc3v3P3zepT/apbXz1vFN9E24Z4r/OBymjEPrkkNCw4o0Bfwh3DchbiJQy8PEmLKA2VQf+oAXE5DLPeCLTknNhWwZBky4RhezK2cNVsXHRIuFdC0FIJatUwNqU4v0CjnoHz1/t84zmCmy//hzSOQ0TE3unLVHuUMqbCIz3uTJULQvrDTgguoWYo2SSydluiSW2L0SVy+PZkhmiYFtSkXMxdZbaSbHBIUP3tudpeFUZXp42dhJDYqwCMvNMK9+RYBbizRQbQLB6Pyj8PAsGvvQMBE4prOpERQU9n3OqX8s/O8LTmc5asdCLnrTWF4vk36Bx1325H8RpxHSnFiW+3Yg6qGL4b/FY+S8bSeSCa28D+eM1a9B/dqDOIB8cxsRIQWSeA7F9gUX+pGbVKDS3lep+TyZzvoOA7Ta4q9bDI67s8g1OZYRcrBH66d9Ym4WkUY1UhDH3GY2Ol+Hx8hO53d5n2e3uN//LyDdZra73eb2+xkcXFVGAwMFACAQEDzmdnqVYrK33n/v4ZtdfXYk2rq+bsdnaaj8rKRR+Cgp2JyclA+n19h+/6+hWyWVnrjkdHyfvw8AtBra3ss9TUZ1+iov1Fr6/qI5ycv1OkpPfkcnKWm8DAW3W3t8Lh/f0cPZOTrkwmJmpsNjZafj8/QfX39wKDzMxPaDQ0XFGlpfTR5eU0+fHxCOJxcZOr2NhzYjExUyoVFT8IBAQMlcfHUkYjI2Wdw8NeMBgYKDeWlqEKBQUPL5qatQ4HBwkkEhI2G4CAm9/i4j3N6+smTicnaX+yss3qdXWfEgkJGx2Dg55YLCx0NBoaLjYbGy3cbm6ytFpa7lugoPukUlL2djs7TbfW1mF9s7POUikpe93j4z5eLy9xE4SEl6ZTU/W50dFoAAAAAMHt7SxAICBg4/z8H3mxsci2W1vt1Gpqvo3Ly0Znvr7Zcjk5S5RKSt6YTEzUsFhY6IXPz0q70NBrxe/vKk+qquXt+/sWhkNDxZpNTddmMzNVEYWFlIpFRc/p+fkQBAICBv5/f4GgUFDweDw8RCWfn7pLqKjjolFR812jo/6AQEDABY+Pij+Skq0hnZ28cDg4SPH19QRjvLzfd7a2wa/a2nVCISFjIBAQMOX//xr98/MOv9LSbYHNzUwYDAwUJhMTNcPs7C++X1/hNZeXoohERMwuFxc5k8TEV1Wnp/L8fn6Cej09R8hkZKy6XV3nMhkZK+Zzc5XAYGCgGYGBmJ5PT9Gj3Nx/RCIiZlQqKn47kJCrC4iIg4xGRsrH7u4pa7i40ygUFDyn3t55vF5e4hYLCx2t29t22+DgO2QyMlZ0OjpOFAoKHpJJSdsMBgYKSCQkbLhcXOSfwsJdvdPTbkOsrO/EYmKmOZGRqDGVlaTT5OQ38nl5i9Xn5zKLyMhDbjc3WdptbbcBjY2MsdXVZJxOTtJJqang2GxstKxWVvrz9PQHz+rqJcplZa/0enqOR66u6RAICBhvurrV8Hh4iEolJW9cLi5yOBwcJFempvFztLTHl8bGUcvo6COh3d186HR0nD4fHyGWS0vdYb293A2Li4YPioqF4HBwkHw+PkJxtbXEzGZmqpBISNgGAwMF9/b2ARwODhLCYWGjajU1X65XV/lpubnQF4aGkZnBwVg6HR0nJ56eudnh4Tjr+PgTK5iYsyIRETPSaWm7qdnZcAeOjokzlJSnLZubtjweHiIVh4eSyenpIIfOzkmqVVX/UCgoeKXf33oDjIyPWaGh+AmJiYAaDQ0XZb+/2tfm5jGEQkLG0GhouIJBQcMpmZmwWi0tdx4PDxF7sLDLqFRU/G27u9YsFhY6pcZjY4T4fHyZ7nd3jfZ7ew3/8vK91mtrsd5vb1SRxcVQYDAwAwIBAanOZ2d9VisrGef+/mK119fmTaurmux2dkWPysqdH4KCQInJyYf6fX0V7/r667JZWcmOR0cL+/Dw7EGtrWez1NT9X6Ki6kWvr78jnJz3U6SkluRyclubwMDCdbe3HOH9/a49k5NqTCYmWmw2NkF+Pz8C9ff3T4PMzFxoNDT0UaWlNNHl5Qj58fGT4nFxc6vY2FNiMTE/KhUVDAgEBFKVx8dlRiMjXp3DwygwGBihN5aWDwoFBbUvmpoJDgcHNiQSEpsbgIA93+LiJs3r62lOJyfNf7Kyn+p1dRsSCQmeHYODdFgsLC40GhotNhsbstxubu60Wlr7W6Cg9qRSUk12Oztht9bWzn2zs3tSKSk+3ePjcV4vL5cThIT1plNTaLnR0QAAAAAswe3tYEAgIB/j/PzIebGx7bZbW77UampGjcvL2We+vktyOTnelEpK1JhMTOiwWFhKhc/Pa7vQ0CrF7+/lT6qqFu37+8WGQ0PXmk1NVWYzM5QRhYXPikVFEOn5+QYEAgKB/n9/8KBQUER4PDy6JZ+f40uoqPOiUVH+XaOjwIBAQIoFj4+tP5KSvCGdnUhwODgE8fX132O8vMF3trZ1r9raY0IhITAgEBAa5f//Dv3z822/0tJMgc3NFBgMDDUmExMvw+zs4b5fX6I1l5fMiEREOS4XF1eTxMTyVaengvx+fkd6PT2syGRk57pdXSsyGRmV5nNzoMBgYJgZgYHRnk9Pf6Pc3GZEIiJ+VCoqqzuQkIMLiIjKjEZGKcfu7tNruLg8KBQUeafe3uK8Xl4dFgsLdq3b2zvb4OBWZDIyTnQ6Oh4UCgrbkklJCgwGBmxIJCTkuFxcXZ/Cwm6909PvQ6yspsRiYqg5kZGkMZWVN9Pk5IvyeXky1efnQ4vIyFluNze32m1tjAGNjWSx1dXSnE5O4EmpqbTYbGz6rFZWB/P09CXP6uqvymVljvR6eulHrq4YEAgI1W+6uojweHhvSiUlclwuLiQ4HBzxV6amx3O0tFGXxsYjy+jofKHd3ZzodHQhPh8f3ZZLS9xhvb2GDYuLhQ+KipDgcHBCfD4+xHG1tarMZmbYkEhIBQYDAwH39vYSHA4Oo8JhYV9qNTX5rldX0Gm5uZEXhoZYmcHBJzodHbknnp442eHhE+v4+LMrmJgzIhERu9JpaXCp2dmJB46OpzOUlLYtm5siPB4ekhWHhyDJ6elJh87O/6pVVXhQKCh6pd/fjwOMjPhZoaGACYmJFxoNDdplv78x1+bmxoRCQrjQaGjDgkFBsCmZmXdaLS0RHg8Py3uwsPyoVFTWbbu7OiwWFmOlxmN8hPh8d5nud3uN9nvyDf/ya73Wa2+x3m/FVJHFMFBgMAEDAgFnqc5nK31WK/4Z5/7XYrXXq+ZNq3aa7HbKRY/Kgp0fgslAicl9h/p9+hXv+lnrsllHyY5H8Av78K3sQa3UZ7PUov1foq/qRa+cvyOcpPdTpHKW5HLAW5vAt8J1t/0c4f2Trj2TJmpMJjZabDY/QX4/9wL198xPg8w0XGg0pfRRpeU00eXxCPnxcZPicdhzq9gxU2IxFT8qFQQMCATHUpXHI2VGI8NencMYKDAYlqE3lgUPCgWatS+aBwkOBxI2JBKAmxuA4j3f4usmzesnaU4nss1/snWf6nUJGxIJg54dgyx0WCwaLjQaGy02G26y3G5a7rRaoPtboFL2pFI7TXY71mG31rPOfbMpe1Ip4z7d4y9xXi+ElxOEU/WmU9FoudEAAAAA7SzB7SBgQCD8H+P8sch5sVvttltqvtRqy0aNy77ZZ745S3I5St6USkzUmExY6LBYz0qFz9Bru9DvKsXvquVPqvsW7ftDxYZDTdeaTTNVZjOFlBGFRc+KRfkQ6fkCBgQCf4H+f1DwoFA8RHg8n7oln6jjS6hR86JRo/5do0DAgECPigWPkq0/kp28IZ04SHA49QTx9bzfY7y2wXe22nWv2iFjQiEQMCAQ/xrl//MO/fPSbb/SzUyBzQwUGAwTNSYT7C/D7F/hvl+XojWXRMyIRBc5LhfEV5PEp/JVp36C/H49R3o9ZKzIZF3nul0ZKzIZc5Xmc2CgwGCBmBmBT9GeT9x/o9wiZkQiKn5UKpCrO5CIgwuIRsqMRu4px+6402u4FDwoFN55p95e4rxeCx0WC9t2rdvgO9vgMlZkMjpOdDoKHhQKSduSSQYKDAYkbEgkXOS4XMJdn8LTbr3TrO9DrGKmxGKRqDmRlaQxleQ30+R5i/J55zLV58hDi8g3WW43bbfabY2MAY3VZLHVTtKcTqngSalstNhsVvqsVvQH8/TqJc/qZa/KZXqO9Hqu6UeuCBgQCLrVb7p4iPB4JW9KJS5yXC4cJDgcpvFXprTHc7TGUZfG6CPL6N18od10nOh0HyE+H0vdlku93GG9i4YNi4qFD4pwkOBwPkJ8PrXEcbVmqsxmSNiQSAMFBgP2Aff2DhIcDmGjwmE1X2o1V/muV7nQabmGkReGwViZwR0nOh2euSee4TjZ4fgT6/iYsyuYETMiEWm70mnZcKnZjokHjpSnM5Sbti2bHiI8HoeSFYfpIMnpzkmHzlX/qlUoeFAo33ql34yPA4yh+FmhiYAJiQ0XGg2/2mW/5jHX5kLGhEJouNBoQcOCQZmwKZktd1otDxEeD7DLe7BU/KhUu9ZtuxY6LBZjY6XGfHyE+Hd3me57e4328vIN/2trvdZvb7HexcVUkTAwUGABAQMCZ2epzisrfVb+/hnn19ditaur5k12dprsyspFj4KCnR/JyUCJfX2H+vr6Fe9ZWeuyR0fJjvDwC/utrexB1NRns6Ki/V+vr+pFnJy/I6Sk91NycpbkwMBbm7e3wnX9/Rzhk5OuPSYmakw2NlpsPz9Bfvf3AvXMzE+DNDRcaKWl9FHl5TTR8fEI+XFxk+LY2HOrMTFTYhUVPyoEBAwIx8dSlSMjZUbDw16dGBgoMJaWoTcFBQ8Kmpq1LwcHCQ4SEjYkgICbG+LiPd/r6ybNJydpTrKyzX91dZ/qCQkbEoODnh0sLHRYGhouNBsbLTZubrLcWlrutKCg+1tSUvakOztNdtbWYbezs859KSl7UuPjPt0vL3FehISXE1NT9abR0Wi5AAAAAO3tLMEgIGBA/Pwf47GxyHlbW+22amq+1MvLRo2+vtlnOTlLckpK3pRMTNSYWFjosM/PSoXQ0Gu77+8qxaqq5U/7+xbtQ0PFhk1N15ozM1VmhYWUEUVFz4r5+RDpAgIGBH9/gf5QUPCgPDxEeJ+fuiWoqONLUVHzoqOj/l1AQMCAj4+KBZKSrT+dnbwhODhIcPX1BPG8vN9jtrbBd9rada8hIWNCEBAwIP//GuXz8w790tJtv83NTIEMDBQYExM1JuzsL8NfX+G+l5eiNUREzIgXFzkuxMRXk6en8lV+foL8PT1HemRkrMhdXee6GRkrMnNzleZgYKDAgYGYGU9P0Z7c3H+jIiJmRCoqflSQkKs7iIiDC0ZGyozu7inHuLjTaxQUPCje3nmnXl7ivAsLHRbb23at4OA72zIyVmQ6Ok50CgoeFElJ25IGBgoMJCRsSFxc5LjCwl2f09Nuvays70NiYqbEkZGoOZWVpDHk5DfTeXmL8ufnMtXIyEOLNzdZbm1tt9qNjYwB1dVksU5O0pypqeBJbGy02FZW+qz09Afz6uolz2Vlr8p6eo70rq7pRwgIGBC6utVveHiI8CUlb0ouLnJcHBwkOKam8Ve0tMdzxsZRl+joI8vd3XyhdHSc6B8fIT5LS92Wvb3cYYuLhg2KioUPcHCQ4D4+Qny1tcRxZmaqzEhI2JADAwUG9vYB9w4OEhxhYaPCNTVfaldX+a65udBphoaRF8HBWJkdHSc6np65J+HhONn4+BPrmJizKxERMyJpabvS2dlwqY6OiQeUlKczm5u2LR4eIjyHh5IV6ekgyc7OSYdVVf+qKCh4UN/feqWMjI8DoaH4WYmJgAkNDRcav7/aZebmMddCQsaEaGi40EFBw4KZmbApLS13Wg8PER6wsMt7VFT8qLu71m0WFjos", i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", o = new Uint8Array(256), f = 0; f < i.length; f++) o[i.charCodeAt(f)] = f;
    function s(Q) {
      var U = Q.length * .75,
        pe = Q.length,
        ae,
        Be = 0,
        b,
        d,
        ne,
        Ee;
      Q[Q.length - 1] === "=" && (U--, Q[Q.length - 2] === "=" && U--);
      var Xe = new ArrayBuffer(U),
        qe = new Uint8Array(Xe);
      for (ae = 0; ae < pe; ae += 4) b = o[Q.charCodeAt(ae)], d = o[Q.charCodeAt(ae + 1)], ne = o[Q.charCodeAt(ae + 2)], Ee = o[Q.charCodeAt(ae + 3)], qe[Be++] = b << 2 | d >> 4, qe[Be++] = (d & 15) << 4 | ne >> 2, qe[Be++] = (ne & 3) << 6 | Ee & 63;
      return Xe;
    }
    var A = typeof A < "u" ? A : {},
      u = Object.assign({}, A);
    typeof process == "object" && typeof process.versions == "object" && process.versions.node, A.print || console.log.bind(console);
    var l = A.printErr || console.warn.bind(console);
    Object.assign(A, u), u = null, A.arguments && A.arguments, A.thisProgram && A.thisProgram, A.quit && A.quit, A.wasmBinary && A.wasmBinary, A.noExitRuntime, typeof n != "object" && M("[WACloudCrypto] no native wasm support detected");
    var g,
      y = !1;
    function B(Q) {
      A.HEAP8 = new Int8Array(Q), A.HEAP16 = new Int16Array(Q), A.HEAP32 = new Int32Array(Q), A.HEAPU8 = new Uint8Array(Q), A.HEAPU16 = new Uint16Array(Q), A.HEAPU32 = new Uint32Array(Q), A.HEAPF32 = new Float32Array(Q), A.HEAPF64 = new Float64Array(Q);
    }
    A.INITIAL_MEMORY;
    var C,
      T = [],
      k = [],
      ee = [];
    function J() {
      if (A.preRun) for (typeof A.preRun == "function" && (A.preRun = [A.preRun]); A.preRun.length;) ye(A.preRun.shift());
      F(T);
    }
    function D() {
      F(k);
    }
    function te() {
      if (A.postRun) for (typeof A.postRun == "function" && (A.postRun = [A.postRun]); A.postRun.length;) v(A.postRun.shift());
      F(ee);
    }
    function ye(Q) {
      T.unshift(Q);
    }
    function x(Q) {
      k.unshift(Q);
    }
    function v(Q) {
      ee.unshift(Q);
    }
    var O = 0,
      R = null;
    function j(Q) {
      O++, A.monitorRunDependencies && A.monitorRunDependencies(O);
    }
    function X(Q) {
      if (O--, A.monitorRunDependencies && A.monitorRunDependencies(O), O == 0 && R) {
        var U = R;
        R = null, U();
      }
    }
    function M(Q) {
      A.onAbort && A.onAbort(Q), Q = "Aborted(" + Q + ")", l(Q), y = !0, Q += ". Build with -sASSERTIONS for more info.";
      var U = new n.RuntimeError(Q);
      e(U);
    }
    function Z() {
      return {
        env: {
          STACKTOP: 0
        }
      };
    }
    var N = Z();
    function se() {
      var Q = {
        a: De
      };
      function U(d, ne) {
        var Ee = d.exports;
        A.asm = Ee, g = A.asm.a, A.memory = g, B(g.buffer), C = A.asm.g, x(A.asm.b), X(), r(A);
      }
      j();
      function pe(d) {
        U(d.instance);
      }
      function ae(d) {
        return n.instantiate(s(t), N).then(function (ne) {
          return ne;
        }).then(d, function (ne) {
          l("[WACloudCrypto] failed to asynchronously prepare wasm: " + ne), M(ne);
        });
      }
      function Be() {
        return ae(pe);
      }
      if (A.instantiateWasm) try {
        var b = A.instantiateWasm(Q, U);
        return b;
      } catch (d) {
        return l("[WACloudCrypto] Module.instantiateWasm callback failed with error: " + d), !1;
      }
      return Be(), {};
    }
    function F(Q) {
      for (; Q.length > 0;) {
        var U = Q.shift();
        if (typeof U == "function") {
          U(A);
          continue;
        }
        var pe = U.func;
        typeof pe == "number" ? U.arg === void 0 ? re(pe)() : re(pe)(U.arg) : pe(U.arg === void 0 ? null : U.arg);
      }
    }
    var _ = [];
    function re(Q) {
      var U = _[Q];
      return U || (Q >= _.length && (_.length = Q + 1), _[Q] = U = C.get(Q)), U;
    }
    var De = {};
    se(), A.___wasm_call_ctors = function () {
      return (A.___wasm_call_ctors = A.asm.b).apply(null, arguments);
    }, A._aes_setkey_enc = function () {
      return (A._aes_setkey_enc = A.asm.c).apply(null, arguments);
    }, A._aes_setkey_dec = function () {
      return (A._aes_setkey_dec = A.asm.d).apply(null, arguments);
    }, A._aes_crypt_cbc = function () {
      return (A._aes_crypt_cbc = A.asm.e).apply(null, arguments);
    }, A._aes_crypt_ctr = function () {
      return (A._aes_crypt_ctr = A.asm.f).apply(null, arguments);
    };
    var ge;
    R = function Q() {
      ge || Re(), ge || (R = Q);
    };
    function Re(Q) {
      if (O > 0 || (J(), O > 0)) return;
      function U() {
        ge || (ge = !0, A.calledRun = !0, !y && (D(), A.onRuntimeInitialized && A.onRuntimeInitialized(), te()));
      }
      A.setStatus ? (A.setStatus("Running..."), setTimeout(function () {
        setTimeout(function () {
          A.setStatus("");
        }, 1), U();
      }, 1)) : U();
    }
    if (A.run = Re, A.preInit) for (typeof A.preInit == "function" && (A.preInit = [A.preInit]); A.preInit.length > 0;) A.preInit.pop()();
    return A;
  });
}
function at(n) {
  return parseInt(n) === n;
}
function Nt(n) {
  if (!at(n.length)) return !1;
  for (var r = 0; r < n.length; r++) if (!at(n[r]) || n[r] < 0 || n[r] > 255) return !1;
  return !0;
}
function lt(n, r) {
  if (n.buffer && ArrayBuffer.isView(n)) return r && (n.slice ? n = n.slice() : n = Array.prototype.slice.call(n)), n;
  if (Array.isArray(n)) {
    if (!Nt(n)) throw new Error("[WACloudCrypto] Array contains invalid value: " + n);
    return new Uint8Array(n);
  }
  if (at(n.length) && Nt(n)) return new Uint8Array(n);
  throw new Error("[WACloudCrypto] unsupported array-like object");
}
function Jn() {
  var n = 16384;
  return r => (n += r, n - r);
}
function _t(n) {
  return new Uint8Array(n);
}
function zt(n, r, e, t, i) {
  (t != null || i != null) && (n.slice ? n = n.slice(t, i) : n = Array.prototype.slice.call(n, t, i)), r.set(n, e);
}
function Zn(n) {
  n = lt(n, !0);
  var r = 16 - n.length % 16,
    e = _t(n.length + r);
  zt(n, e);
  for (var t = n.length; t < e.length; t++) e[t] = r;
  return e;
}
function Kn(n) {
  if (n = lt(n, !0), n.length < 16) throw new Error("[WACloudCrypto] PKCS#7 invalid length");
  var r = n[n.length - 1];
  if (r > 16) throw new Error("[WACloudCrypto] PKCS#7 padding byte out of range");
  for (var e = n.length - r, t = 0; t < r; t++) if (n[e + t] !== r) throw new Error("[WACloudCrypto] PKCS#7 invalid padding byte");
  var i = _t(e);
  return zt(n, i, 0, 0, e), i;
}
function Yt(_x) {
  return _Yt.apply(this, arguments);
}
function _Yt() {
  _Yt = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()(function* (n) {
    var r = yield Yn(n),
      e = 128,
      t = Jn(),
      i = r,
      o = new Uint8Array(i.memory.buffer),
      f = t(276),
      s = t(276),
      A = t(e / 8),
      u = t(16),
      l = t(0),
      g;
    function y(C) {
      var T = lt(C);
      o.set(T, l);
    }
    function B(C, T, k = "CBC") {
      o.set(T, u), o.set(C, A), i._aes_setkey_enc(f, A, e), i._aes_setkey_dec(s, A, e), g = k;
    }
    return {
      init: B,
      encrypt: (C, T, k) => (B(T, k, "CBC"), C = Zn(C), y(C), g === "CBC" ? i._aes_crypt_cbc(f, 1, C.length, u, l, l) : i._aes_crypt_ctr(f, C.length, u, l, l), o.subarray(l, l + C.length).slice()),
      decrypt: (C, T, k) => (B(T, k, "CBC"), y(C), g === "CBC" ? i._aes_crypt_cbc(s, 0, C.length, u, l, l) : i._aes_crypt_ctr(f, C.length, u, l, l), Kn(o.subarray(l, l + C.length).slice()))
    };
  });
  return _Yt.apply(this, arguments);
}
var ct,
  Jt = !1;
function jn(n) {
  if (!ct && !Jt) return Jt = !0, Yt(n).then(r => {
    ct = r;
  }).catch(() => {});
}
function Ie() {
  return ct;
}
function Zt(n, r) {
  var e = Ie();
  return {
    encrypted: e ? e.encrypt(r, n, n) : le.encrypt(r, n, void 0, n),
    backend: e ? "wasm" : "js"
  };
}
h();
function Ve(n) {
  return Xn(n).buffer;
}
function Pe(n) {
  return Object.prototype.toString.call(n).slice(8, -1).toLowerCase();
}
function ve(n) {
  return n == null;
}
function Xn(n) {
  for (var r = [], e = 0; e < n.length; e++) {
    var t = n.charCodeAt(e);
    t < 128 ? r.push(t) : t < 2048 ? r.push(192 | t >> 6, 128 | t & 63) : t < 55296 || t >= 57344 ? r.push(224 | t >> 12, 128 | t >> 6 & 63, 128 | t & 63) : (e++, t = 65536 + ((t & 1023) << 10 | n.charCodeAt(e) & 1023), r.push(240 | t >> 18, 128 | t >> 12 & 63, 128 | t >> 6 & 63, 128 | t & 63));
  }
  return new Uint8Array(r);
}
function Kt(n) {
  for (var r = n.length; r--;) n[r] = Math.floor(Math.random() * 256);
  return n;
}
function jt(n) {
  var r = n.reduce((i, o) => i + o.length, 0);
  if (!n.length) return null;
  var e = new Uint8Array(r),
    t = 0;
  for (var i of n) e.set(i, t), t += i.length;
  return e;
}
function He(n) {
  return Vn(n);
}
var Vn = function () {
  var n = new Array(128),
    r = String.fromCodePoint || String.fromCharCode,
    e = [];
  return function (t) {
    var i,
      o,
      f = t.length;
    e.length = 0;
    for (var s = 0; s < f;) o = t[s++], o <= 127 ? i = o : o <= 223 ? i = (o & 31) << 6 | t[s++] & 63 : o <= 239 ? i = (o & 15) << 12 | (t[s++] & 63) << 6 | t[s++] & 63 : String.fromCodePoint ? i = (o & 7) << 18 | (t[s++] & 63) << 12 | (t[s++] & 63) << 6 | t[s++] & 63 : (i = 63, s += 3), e.push(n[i] || (n[i] = r(i)));
    return e.join("");
  };
}();
var on = Le(ze(), 1);
h();
var Y = Le(rn(), 1),
  S = Y.Reader,
  Se = Y.Writer,
  p = Y.util,
  E = Y.roots.default || (Y.roots.default = {}),
  be = E.HTTPRequest = (() => {
    function n(r) {
      if (this.header = [], r) for (var e = Object.keys(r), t = 0; t < e.length; ++t) r[e[t]] != null && (this[e[t]] = r[e[t]]);
    }
    return n.prototype.method = "", n.prototype.header = p.emptyArray, n.prototype.body = p.newBuffer([]), n.prototype.callId = "", n.create = function (e) {
      return new n(e);
    }, n.encode = function (e, t) {
      if (t || (t = Se.create()), e.method != null && Object.hasOwnProperty.call(e, "method") && t.uint32(10).string(e.method), e.header != null && e.header.length) for (var i = 0; i < e.header.length; ++i) E.HTTPHeader.encode(e.header[i], t.uint32(18).fork()).ldelim();
      return e.body != null && Object.hasOwnProperty.call(e, "body") && t.uint32(26).bytes(e.body), e.callId != null && Object.hasOwnProperty.call(e, "callId") && t.uint32(34).string(e.callId), t;
    }, n.encodeDelimited = function (e, t) {
      return this.encode(e, t).ldelim();
    }, n.decode = function (e, t) {
      e instanceof S || (e = S.create(e));
      var i = t === void 0 ? e.len : e.pos + t,
        o = new E.HTTPRequest();
      for (; e.pos < i;) {
        var f = e.uint32();
        switch (f >>> 3) {
          case 1:
            {
              o.method = e.string();
              break;
            }
          case 2:
            {
              o.header && o.header.length || (o.header = []), o.header.push(E.HTTPHeader.decode(e, e.uint32()));
              break;
            }
          case 3:
            {
              o.body = e.bytes();
              break;
            }
          case 4:
            {
              o.callId = e.string();
              break;
            }
          default:
            e.skipType(f & 7);
            break;
        }
      }
      return o;
    }, n.decodeDelimited = function (e) {
      return e instanceof S || (e = new S(e)), this.decode(e, e.uint32());
    }, n.verify = function (e) {
      if (typeof e != "object" || e === null) return "object expected";
      if (e.method != null && e.hasOwnProperty("method") && !p.isString(e.method)) return "method: string expected";
      if (e.header != null && e.hasOwnProperty("header")) {
        if (!Array.isArray(e.header)) return "header: array expected";
        for (var t = 0; t < e.header.length; ++t) {
          var i = E.HTTPHeader.verify(e.header[t]);
          if (i) return "header." + i;
        }
      }
      return e.body != null && e.hasOwnProperty("body") && !(e.body && typeof e.body.length == "number" || p.isString(e.body)) ? "body: buffer expected" : e.callId != null && e.hasOwnProperty("callId") && !p.isString(e.callId) ? "callId: string expected" : null;
    }, n.fromObject = function (e) {
      if (e instanceof E.HTTPRequest) return e;
      var t = new E.HTTPRequest();
      if (e.method != null && (t.method = String(e.method)), e.header) {
        if (!Array.isArray(e.header)) throw TypeError(".HTTPRequest.header: array expected");
        t.header = [];
        for (var i = 0; i < e.header.length; ++i) {
          if (typeof e.header[i] != "object") throw TypeError(".HTTPRequest.header: object expected");
          t.header[i] = E.HTTPHeader.fromObject(e.header[i]);
        }
      }
      return e.body != null && (typeof e.body == "string" ? p.base64.decode(e.body, t.body = p.newBuffer(p.base64.length(e.body)), 0) : e.body.length >= 0 && (t.body = e.body)), e.callId != null && (t.callId = String(e.callId)), t;
    }, n.toObject = function (e, t) {
      t || (t = {});
      var i = {};
      if ((t.arrays || t.defaults) && (i.header = []), t.defaults && (i.method = "", t.bytes === String ? i.body = "" : (i.body = [], t.bytes !== Array && (i.body = p.newBuffer(i.body))), i.callId = ""), e.method != null && e.hasOwnProperty("method") && (i.method = e.method), e.header && e.header.length) {
        i.header = [];
        for (var o = 0; o < e.header.length; ++o) i.header[o] = E.HTTPHeader.toObject(e.header[o], t);
      }
      return e.body != null && e.hasOwnProperty("body") && (i.body = t.bytes === String ? p.base64.encode(e.body, 0, e.body.length) : t.bytes === Array ? Array.prototype.slice.call(e.body) : e.body), e.callId != null && e.hasOwnProperty("callId") && (i.callId = e.callId), i;
    }, n.prototype.toJSON = function () {
      return this.constructor.toObject(this, Y.util.toJSONOptions);
    }, n.getTypeUrl = function (e) {
      return e === void 0 && (e = "type.googleapis.com"), e + "/HTTPRequest";
    }, n;
  })(),
  he = E.HTTPResponse = (() => {
    function n(r) {
      if (this.header = [], r) for (var e = Object.keys(r), t = 0; t < e.length; ++t) r[e[t]] != null && (this[e[t]] = r[e[t]]);
    }
    return n.prototype.statusCode = 0, n.prototype.header = p.emptyArray, n.prototype.bodyBuffer = p.newBuffer([]), n.prototype.bodyString = "", n.create = function (e) {
      return new n(e);
    }, n.encode = function (e, t) {
      if (t || (t = Se.create()), e.statusCode != null && Object.hasOwnProperty.call(e, "statusCode") && t.uint32(8).uint32(e.statusCode), e.header != null && e.header.length) for (var i = 0; i < e.header.length; ++i) E.HTTPHeader.encode(e.header[i], t.uint32(18).fork()).ldelim();
      return e.bodyBuffer != null && Object.hasOwnProperty.call(e, "bodyBuffer") && t.uint32(26).bytes(e.bodyBuffer), e.bodyString != null && Object.hasOwnProperty.call(e, "bodyString") && t.uint32(34).string(e.bodyString), t;
    }, n.encodeDelimited = function (e, t) {
      return this.encode(e, t).ldelim();
    }, n.decode = function (e, t) {
      e instanceof S || (e = S.create(e));
      var i = t === void 0 ? e.len : e.pos + t,
        o = new E.HTTPResponse();
      for (; e.pos < i;) {
        var f = e.uint32();
        switch (f >>> 3) {
          case 1:
            {
              o.statusCode = e.uint32();
              break;
            }
          case 2:
            {
              o.header && o.header.length || (o.header = []), o.header.push(E.HTTPHeader.decode(e, e.uint32()));
              break;
            }
          case 3:
            {
              o.bodyBuffer = e.bytes();
              break;
            }
          case 4:
            {
              o.bodyString = e.string();
              break;
            }
          default:
            e.skipType(f & 7);
            break;
        }
      }
      return o;
    }, n.decodeDelimited = function (e) {
      return e instanceof S || (e = new S(e)), this.decode(e, e.uint32());
    }, n.verify = function (e) {
      if (typeof e != "object" || e === null) return "object expected";
      if (e.statusCode != null && e.hasOwnProperty("statusCode") && !p.isInteger(e.statusCode)) return "statusCode: integer expected";
      if (e.header != null && e.hasOwnProperty("header")) {
        if (!Array.isArray(e.header)) return "header: array expected";
        for (var t = 0; t < e.header.length; ++t) {
          var i = E.HTTPHeader.verify(e.header[t]);
          if (i) return "header." + i;
        }
      }
      return e.bodyBuffer != null && e.hasOwnProperty("bodyBuffer") && !(e.bodyBuffer && typeof e.bodyBuffer.length == "number" || p.isString(e.bodyBuffer)) ? "bodyBuffer: buffer expected" : e.bodyString != null && e.hasOwnProperty("bodyString") && !p.isString(e.bodyString) ? "bodyString: string expected" : null;
    }, n.fromObject = function (e) {
      if (e instanceof E.HTTPResponse) return e;
      var t = new E.HTTPResponse();
      if (e.statusCode != null && (t.statusCode = e.statusCode >>> 0), e.header) {
        if (!Array.isArray(e.header)) throw TypeError(".HTTPResponse.header: array expected");
        t.header = [];
        for (var i = 0; i < e.header.length; ++i) {
          if (typeof e.header[i] != "object") throw TypeError(".HTTPResponse.header: object expected");
          t.header[i] = E.HTTPHeader.fromObject(e.header[i]);
        }
      }
      return e.bodyBuffer != null && (typeof e.bodyBuffer == "string" ? p.base64.decode(e.bodyBuffer, t.bodyBuffer = p.newBuffer(p.base64.length(e.bodyBuffer)), 0) : e.bodyBuffer.length >= 0 && (t.bodyBuffer = e.bodyBuffer)), e.bodyString != null && (t.bodyString = String(e.bodyString)), t;
    }, n.toObject = function (e, t) {
      t || (t = {});
      var i = {};
      if ((t.arrays || t.defaults) && (i.header = []), t.defaults && (i.statusCode = 0, t.bytes === String ? i.bodyBuffer = "" : (i.bodyBuffer = [], t.bytes !== Array && (i.bodyBuffer = p.newBuffer(i.bodyBuffer))), i.bodyString = ""), e.statusCode != null && e.hasOwnProperty("statusCode") && (i.statusCode = e.statusCode), e.header && e.header.length) {
        i.header = [];
        for (var o = 0; o < e.header.length; ++o) i.header[o] = E.HTTPHeader.toObject(e.header[o], t);
      }
      return e.bodyBuffer != null && e.hasOwnProperty("bodyBuffer") && (i.bodyBuffer = t.bytes === String ? p.base64.encode(e.bodyBuffer, 0, e.bodyBuffer.length) : t.bytes === Array ? Array.prototype.slice.call(e.bodyBuffer) : e.bodyBuffer), e.bodyString != null && e.hasOwnProperty("bodyString") && (i.bodyString = e.bodyString), i;
    }, n.prototype.toJSON = function () {
      return this.constructor.toObject(this, Y.util.toJSONOptions);
    }, n.getTypeUrl = function (e) {
      return e === void 0 && (e = "type.googleapis.com"), e + "/HTTPResponse";
    }, n;
  })(),
  eo = E.HTTPHeader = (() => {
    function n(r) {
      if (r) for (var e = Object.keys(r), t = 0; t < e.length; ++t) r[e[t]] != null && (this[e[t]] = r[e[t]]);
    }
    return n.prototype.key = "", n.prototype.value = "", n.create = function (e) {
      return new n(e);
    }, n.encode = function (e, t) {
      return t || (t = Se.create()), e.key != null && Object.hasOwnProperty.call(e, "key") && t.uint32(10).string(e.key), e.value != null && Object.hasOwnProperty.call(e, "value") && t.uint32(18).string(e.value), t;
    }, n.encodeDelimited = function (e, t) {
      return this.encode(e, t).ldelim();
    }, n.decode = function (e, t) {
      e instanceof S || (e = S.create(e));
      var i = t === void 0 ? e.len : e.pos + t,
        o = new E.HTTPHeader();
      for (; e.pos < i;) {
        var f = e.uint32();
        switch (f >>> 3) {
          case 1:
            {
              o.key = e.string();
              break;
            }
          case 2:
            {
              o.value = e.string();
              break;
            }
          default:
            e.skipType(f & 7);
            break;
        }
      }
      return o;
    }, n.decodeDelimited = function (e) {
      return e instanceof S || (e = new S(e)), this.decode(e, e.uint32());
    }, n.verify = function (e) {
      return typeof e != "object" || e === null ? "object expected" : e.key != null && e.hasOwnProperty("key") && !p.isString(e.key) ? "key: string expected" : e.value != null && e.hasOwnProperty("value") && !p.isString(e.value) ? "value: string expected" : null;
    }, n.fromObject = function (e) {
      if (e instanceof E.HTTPHeader) return e;
      var t = new E.HTTPHeader();
      return e.key != null && (t.key = String(e.key)), e.value != null && (t.value = String(e.value)), t;
    }, n.toObject = function (e, t) {
      t || (t = {});
      var i = {};
      return t.defaults && (i.key = "", i.value = ""), e.key != null && e.hasOwnProperty("key") && (i.key = e.key), e.value != null && e.hasOwnProperty("value") && (i.value = e.value), i;
    }, n.prototype.toJSON = function () {
      return this.constructor.toObject(this, Y.util.toJSONOptions);
    }, n.getTypeUrl = function (e) {
      return e === void 0 && (e = "type.googleapis.com"), e + "/HTTPHeader";
    }, n;
  })(),
  nn = E.QBaseApiData = (() => {
    function n(r) {
      if (r) for (var e = Object.keys(r), t = 0; t < e.length; ++t) r[e[t]] != null && (this[e[t]] = r[e[t]]);
    }
    return n.prototype.qbaseApiName = "", n.prototype.qbaseMeta = null, n.prototype.qbaseOptions = null, n.prototype.qbaseReq = "", n.prototype.cliReqId = "", n.create = function (e) {
      return new n(e);
    }, n.encode = function (e, t) {
      return t || (t = Se.create()), e.qbaseApiName != null && Object.hasOwnProperty.call(e, "qbaseApiName") && t.uint32(10).string(e.qbaseApiName), e.qbaseMeta != null && Object.hasOwnProperty.call(e, "qbaseMeta") && E.QBaseApiData.QBaseMeta.encode(e.qbaseMeta, t.uint32(18).fork()).ldelim(), e.qbaseOptions != null && Object.hasOwnProperty.call(e, "qbaseOptions") && E.QBaseApiData.QBaseOptions.encode(e.qbaseOptions, t.uint32(26).fork()).ldelim(), e.qbaseReq != null && Object.hasOwnProperty.call(e, "qbaseReq") && t.uint32(34).string(e.qbaseReq), e.cliReqId != null && Object.hasOwnProperty.call(e, "cliReqId") && t.uint32(42).string(e.cliReqId), t;
    }, n.encodeDelimited = function (e, t) {
      return this.encode(e, t).ldelim();
    }, n.decode = function (e, t) {
      e instanceof S || (e = S.create(e));
      var i = t === void 0 ? e.len : e.pos + t,
        o = new E.QBaseApiData();
      for (; e.pos < i;) {
        var f = e.uint32();
        switch (f >>> 3) {
          case 1:
            {
              o.qbaseApiName = e.string();
              break;
            }
          case 2:
            {
              o.qbaseMeta = E.QBaseApiData.QBaseMeta.decode(e, e.uint32());
              break;
            }
          case 3:
            {
              o.qbaseOptions = E.QBaseApiData.QBaseOptions.decode(e, e.uint32());
              break;
            }
          case 4:
            {
              o.qbaseReq = e.string();
              break;
            }
          case 5:
            {
              o.cliReqId = e.string();
              break;
            }
          default:
            e.skipType(f & 7);
            break;
        }
      }
      return o;
    }, n.decodeDelimited = function (e) {
      return e instanceof S || (e = new S(e)), this.decode(e, e.uint32());
    }, n.verify = function (e) {
      if (typeof e != "object" || e === null) return "object expected";
      if (e.qbaseApiName != null && e.hasOwnProperty("qbaseApiName") && !p.isString(e.qbaseApiName)) return "qbaseApiName: string expected";
      if (e.qbaseMeta != null && e.hasOwnProperty("qbaseMeta")) {
        var t = E.QBaseApiData.QBaseMeta.verify(e.qbaseMeta);
        if (t) return "qbaseMeta." + t;
      }
      if (e.qbaseOptions != null && e.hasOwnProperty("qbaseOptions")) {
        var _t2 = E.QBaseApiData.QBaseOptions.verify(e.qbaseOptions);
        if (_t2) return "qbaseOptions." + _t2;
      }
      return e.qbaseReq != null && e.hasOwnProperty("qbaseReq") && !p.isString(e.qbaseReq) ? "qbaseReq: string expected" : e.cliReqId != null && e.hasOwnProperty("cliReqId") && !p.isString(e.cliReqId) ? "cliReqId: string expected" : null;
    }, n.fromObject = function (e) {
      if (e instanceof E.QBaseApiData) return e;
      var t = new E.QBaseApiData();
      if (e.qbaseApiName != null && (t.qbaseApiName = String(e.qbaseApiName)), e.qbaseMeta != null) {
        if (typeof e.qbaseMeta != "object") throw TypeError(".QBaseApiData.qbaseMeta: object expected");
        t.qbaseMeta = E.QBaseApiData.QBaseMeta.fromObject(e.qbaseMeta);
      }
      if (e.qbaseOptions != null) {
        if (typeof e.qbaseOptions != "object") throw TypeError(".QBaseApiData.qbaseOptions: object expected");
        t.qbaseOptions = E.QBaseApiData.QBaseOptions.fromObject(e.qbaseOptions);
      }
      return e.qbaseReq != null && (t.qbaseReq = String(e.qbaseReq)), e.cliReqId != null && (t.cliReqId = String(e.cliReqId)), t;
    }, n.toObject = function (e, t) {
      t || (t = {});
      var i = {};
      return t.defaults && (i.qbaseApiName = "", i.qbaseMeta = null, i.qbaseOptions = null, i.qbaseReq = "", i.cliReqId = ""), e.qbaseApiName != null && e.hasOwnProperty("qbaseApiName") && (i.qbaseApiName = e.qbaseApiName), e.qbaseMeta != null && e.hasOwnProperty("qbaseMeta") && (i.qbaseMeta = E.QBaseApiData.QBaseMeta.toObject(e.qbaseMeta, t)), e.qbaseOptions != null && e.hasOwnProperty("qbaseOptions") && (i.qbaseOptions = E.QBaseApiData.QBaseOptions.toObject(e.qbaseOptions, t)), e.qbaseReq != null && e.hasOwnProperty("qbaseReq") && (i.qbaseReq = e.qbaseReq), e.cliReqId != null && e.hasOwnProperty("cliReqId") && (i.cliReqId = e.cliReqId), i;
    }, n.prototype.toJSON = function () {
      return this.constructor.toObject(this, Y.util.toJSONOptions);
    }, n.getTypeUrl = function (e) {
      return e === void 0 && (e = "type.googleapis.com"), e + "/QBaseApiData";
    }, n.QBaseMeta = function () {
      function r(e) {
        if (e) for (var t = Object.keys(e), i = 0; i < t.length; ++i) e[t[i]] != null && (this[t[i]] = e[t[i]]);
      }
      return r.prototype.firstLaunch = !1, r.prototype.sessionId = "", r.prototype.sdkVersion = "", r.prototype.filterUserInfo = !1, r.create = function (t) {
        return new r(t);
      }, r.encode = function (t, i) {
        return i || (i = Se.create()), t.firstLaunch != null && Object.hasOwnProperty.call(t, "firstLaunch") && i.uint32(8).bool(t.firstLaunch), t.sessionId != null && Object.hasOwnProperty.call(t, "sessionId") && i.uint32(18).string(t.sessionId), t.sdkVersion != null && Object.hasOwnProperty.call(t, "sdkVersion") && i.uint32(26).string(t.sdkVersion), t.filterUserInfo != null && Object.hasOwnProperty.call(t, "filterUserInfo") && i.uint32(32).bool(t.filterUserInfo), i;
      }, r.encodeDelimited = function (t, i) {
        return this.encode(t, i).ldelim();
      }, r.decode = function (t, i) {
        t instanceof S || (t = S.create(t));
        var o = i === void 0 ? t.len : t.pos + i,
          f = new E.QBaseApiData.QBaseMeta();
        for (; t.pos < o;) {
          var s = t.uint32();
          switch (s >>> 3) {
            case 1:
              {
                f.firstLaunch = t.bool();
                break;
              }
            case 2:
              {
                f.sessionId = t.string();
                break;
              }
            case 3:
              {
                f.sdkVersion = t.string();
                break;
              }
            case 4:
              {
                f.filterUserInfo = t.bool();
                break;
              }
            default:
              t.skipType(s & 7);
              break;
          }
        }
        return f;
      }, r.decodeDelimited = function (t) {
        return t instanceof S || (t = new S(t)), this.decode(t, t.uint32());
      }, r.verify = function (t) {
        return typeof t != "object" || t === null ? "object expected" : t.firstLaunch != null && t.hasOwnProperty("firstLaunch") && typeof t.firstLaunch != "boolean" ? "firstLaunch: boolean expected" : t.sessionId != null && t.hasOwnProperty("sessionId") && !p.isString(t.sessionId) ? "sessionId: string expected" : t.sdkVersion != null && t.hasOwnProperty("sdkVersion") && !p.isString(t.sdkVersion) ? "sdkVersion: string expected" : t.filterUserInfo != null && t.hasOwnProperty("filterUserInfo") && typeof t.filterUserInfo != "boolean" ? "filterUserInfo: boolean expected" : null;
      }, r.fromObject = function (t) {
        if (t instanceof E.QBaseApiData.QBaseMeta) return t;
        var i = new E.QBaseApiData.QBaseMeta();
        return t.firstLaunch != null && (i.firstLaunch = Boolean(t.firstLaunch)), t.sessionId != null && (i.sessionId = String(t.sessionId)), t.sdkVersion != null && (i.sdkVersion = String(t.sdkVersion)), t.filterUserInfo != null && (i.filterUserInfo = Boolean(t.filterUserInfo)), i;
      }, r.toObject = function (t, i) {
        i || (i = {});
        var o = {};
        return i.defaults && (o.firstLaunch = !1, o.sessionId = "", o.sdkVersion = "", o.filterUserInfo = !1), t.firstLaunch != null && t.hasOwnProperty("firstLaunch") && (o.firstLaunch = t.firstLaunch), t.sessionId != null && t.hasOwnProperty("sessionId") && (o.sessionId = t.sessionId), t.sdkVersion != null && t.hasOwnProperty("sdkVersion") && (o.sdkVersion = t.sdkVersion), t.filterUserInfo != null && t.hasOwnProperty("filterUserInfo") && (o.filterUserInfo = t.filterUserInfo), o;
      }, r.prototype.toJSON = function () {
        return this.constructor.toObject(this, Y.util.toJSONOptions);
      }, r.getTypeUrl = function (t) {
        return t === void 0 && (t = "type.googleapis.com"), t + "/QBaseApiData.QBaseMeta";
      }, r;
    }(), n.QBaseOptions = function () {
      function r(e) {
        if (e) for (var t = Object.keys(e), i = 0; i < t.length; ++i) e[t[i]] != null && (this[t[i]] = e[t[i]]);
      }
      return r.prototype.env = "", r.prototype.appid = "", r.prototype.region = "", r.create = function (t) {
        return new r(t);
      }, r.encode = function (t, i) {
        return i || (i = Se.create()), t.env != null && Object.hasOwnProperty.call(t, "env") && i.uint32(10).string(t.env), t.appid != null && Object.hasOwnProperty.call(t, "appid") && i.uint32(18).string(t.appid), t.region != null && Object.hasOwnProperty.call(t, "region") && i.uint32(26).string(t.region), i;
      }, r.encodeDelimited = function (t, i) {
        return this.encode(t, i).ldelim();
      }, r.decode = function (t, i) {
        t instanceof S || (t = S.create(t));
        var o = i === void 0 ? t.len : t.pos + i,
          f = new E.QBaseApiData.QBaseOptions();
        for (; t.pos < o;) {
          var s = t.uint32();
          switch (s >>> 3) {
            case 1:
              {
                f.env = t.string();
                break;
              }
            case 2:
              {
                f.appid = t.string();
                break;
              }
            case 3:
              {
                f.region = t.string();
                break;
              }
            default:
              t.skipType(s & 7);
              break;
          }
        }
        return f;
      }, r.decodeDelimited = function (t) {
        return t instanceof S || (t = new S(t)), this.decode(t, t.uint32());
      }, r.verify = function (t) {
        return typeof t != "object" || t === null ? "object expected" : t.env != null && t.hasOwnProperty("env") && !p.isString(t.env) ? "env: string expected" : t.appid != null && t.hasOwnProperty("appid") && !p.isString(t.appid) ? "appid: string expected" : t.region != null && t.hasOwnProperty("region") && !p.isString(t.region) ? "region: string expected" : null;
      }, r.fromObject = function (t) {
        if (t instanceof E.QBaseApiData.QBaseOptions) return t;
        var i = new E.QBaseApiData.QBaseOptions();
        return t.env != null && (i.env = String(t.env)), t.appid != null && (i.appid = String(t.appid)), t.region != null && (i.region = String(t.region)), i;
      }, r.toObject = function (t, i) {
        i || (i = {});
        var o = {};
        return i.defaults && (o.env = "", o.appid = "", o.region = ""), t.env != null && t.hasOwnProperty("env") && (o.env = t.env), t.appid != null && t.hasOwnProperty("appid") && (o.appid = t.appid), t.region != null && t.hasOwnProperty("region") && (o.region = t.region), o;
      }, r.prototype.toJSON = function () {
        return this.constructor.toObject(this, Y.util.toJSONOptions);
      }, r.getTypeUrl = function (t) {
        return t === void 0 && (t = "type.googleapis.com"), t + "/QBaseApiData.QBaseOptions";
      }, r;
    }(), n;
  })(),
  it = E.V3Header = (() => {
    function n(r) {
      if (r) for (var e = Object.keys(r), t = 0; t < e.length; ++t) r[e[t]] != null && (this[e[t]] = r[e[t]]);
    }
    return n.prototype.encryptionTimestamp = p.Long ? p.Long.fromBits(0, 0, !0) : 0, n.prototype.compression = "", n.prototype.userTimeout = p.Long ? p.Long.fromBits(0, 0, !0) : 0, n.prototype.libBuildTs = p.Long ? p.Long.fromBits(0, 0, !0) : 0, n.prototype.appProtocol = "", n.create = function (e) {
      return new n(e);
    }, n.encode = function (e, t) {
      return t || (t = Se.create()), e.encryptionTimestamp != null && Object.hasOwnProperty.call(e, "encryptionTimestamp") && t.uint32(8).uint64(e.encryptionTimestamp), e.compression != null && Object.hasOwnProperty.call(e, "compression") && t.uint32(18).string(e.compression), e.userTimeout != null && Object.hasOwnProperty.call(e, "userTimeout") && t.uint32(24).uint64(e.userTimeout), e.libBuildTs != null && Object.hasOwnProperty.call(e, "libBuildTs") && t.uint32(32).uint64(e.libBuildTs), e.appProtocol != null && Object.hasOwnProperty.call(e, "appProtocol") && t.uint32(42).string(e.appProtocol), t;
    }, n.encodeDelimited = function (e, t) {
      return this.encode(e, t).ldelim();
    }, n.decode = function (e, t) {
      e instanceof S || (e = S.create(e));
      var i = t === void 0 ? e.len : e.pos + t,
        o = new E.V3Header();
      for (; e.pos < i;) {
        var f = e.uint32();
        switch (f >>> 3) {
          case 1:
            {
              o.encryptionTimestamp = e.uint64();
              break;
            }
          case 2:
            {
              o.compression = e.string();
              break;
            }
          case 3:
            {
              o.userTimeout = e.uint64();
              break;
            }
          case 4:
            {
              o.libBuildTs = e.uint64();
              break;
            }
          case 5:
            {
              o.appProtocol = e.string();
              break;
            }
          default:
            e.skipType(f & 7);
            break;
        }
      }
      return o;
    }, n.decodeDelimited = function (e) {
      return e instanceof S || (e = new S(e)), this.decode(e, e.uint32());
    }, n.verify = function (e) {
      return typeof e != "object" || e === null ? "object expected" : e.encryptionTimestamp != null && e.hasOwnProperty("encryptionTimestamp") && !p.isInteger(e.encryptionTimestamp) && !(e.encryptionTimestamp && p.isInteger(e.encryptionTimestamp.low) && p.isInteger(e.encryptionTimestamp.high)) ? "encryptionTimestamp: integer|Long expected" : e.compression != null && e.hasOwnProperty("compression") && !p.isString(e.compression) ? "compression: string expected" : e.userTimeout != null && e.hasOwnProperty("userTimeout") && !p.isInteger(e.userTimeout) && !(e.userTimeout && p.isInteger(e.userTimeout.low) && p.isInteger(e.userTimeout.high)) ? "userTimeout: integer|Long expected" : e.libBuildTs != null && e.hasOwnProperty("libBuildTs") && !p.isInteger(e.libBuildTs) && !(e.libBuildTs && p.isInteger(e.libBuildTs.low) && p.isInteger(e.libBuildTs.high)) ? "libBuildTs: integer|Long expected" : e.appProtocol != null && e.hasOwnProperty("appProtocol") && !p.isString(e.appProtocol) ? "appProtocol: string expected" : null;
    }, n.fromObject = function (e) {
      if (e instanceof E.V3Header) return e;
      var t = new E.V3Header();
      return e.encryptionTimestamp != null && (p.Long ? (t.encryptionTimestamp = p.Long.fromValue(e.encryptionTimestamp)).unsigned = !0 : typeof e.encryptionTimestamp == "string" ? t.encryptionTimestamp = parseInt(e.encryptionTimestamp, 10) : typeof e.encryptionTimestamp == "number" ? t.encryptionTimestamp = e.encryptionTimestamp : typeof e.encryptionTimestamp == "object" && (t.encryptionTimestamp = new p.LongBits(e.encryptionTimestamp.low >>> 0, e.encryptionTimestamp.high >>> 0).toNumber(!0))), e.compression != null && (t.compression = String(e.compression)), e.userTimeout != null && (p.Long ? (t.userTimeout = p.Long.fromValue(e.userTimeout)).unsigned = !0 : typeof e.userTimeout == "string" ? t.userTimeout = parseInt(e.userTimeout, 10) : typeof e.userTimeout == "number" ? t.userTimeout = e.userTimeout : typeof e.userTimeout == "object" && (t.userTimeout = new p.LongBits(e.userTimeout.low >>> 0, e.userTimeout.high >>> 0).toNumber(!0))), e.libBuildTs != null && (p.Long ? (t.libBuildTs = p.Long.fromValue(e.libBuildTs)).unsigned = !0 : typeof e.libBuildTs == "string" ? t.libBuildTs = parseInt(e.libBuildTs, 10) : typeof e.libBuildTs == "number" ? t.libBuildTs = e.libBuildTs : typeof e.libBuildTs == "object" && (t.libBuildTs = new p.LongBits(e.libBuildTs.low >>> 0, e.libBuildTs.high >>> 0).toNumber(!0))), e.appProtocol != null && (t.appProtocol = String(e.appProtocol)), t;
    }, n.toObject = function (e, t) {
      t || (t = {});
      var i = {};
      if (t.defaults) {
        if (p.Long) {
          var o = new p.Long(0, 0, !0);
          i.encryptionTimestamp = t.longs === String ? o.toString() : t.longs === Number ? o.toNumber() : o;
        } else i.encryptionTimestamp = t.longs === String ? "0" : 0;
        if (i.compression = "", p.Long) {
          var _o = new p.Long(0, 0, !0);
          i.userTimeout = t.longs === String ? _o.toString() : t.longs === Number ? _o.toNumber() : _o;
        } else i.userTimeout = t.longs === String ? "0" : 0;
        if (p.Long) {
          var _o2 = new p.Long(0, 0, !0);
          i.libBuildTs = t.longs === String ? _o2.toString() : t.longs === Number ? _o2.toNumber() : _o2;
        } else i.libBuildTs = t.longs === String ? "0" : 0;
        i.appProtocol = "";
      }
      return e.encryptionTimestamp != null && e.hasOwnProperty("encryptionTimestamp") && (typeof e.encryptionTimestamp == "number" ? i.encryptionTimestamp = t.longs === String ? String(e.encryptionTimestamp) : e.encryptionTimestamp : i.encryptionTimestamp = t.longs === String ? p.Long.prototype.toString.call(e.encryptionTimestamp) : t.longs === Number ? new p.LongBits(e.encryptionTimestamp.low >>> 0, e.encryptionTimestamp.high >>> 0).toNumber(!0) : e.encryptionTimestamp), e.compression != null && e.hasOwnProperty("compression") && (i.compression = e.compression), e.userTimeout != null && e.hasOwnProperty("userTimeout") && (typeof e.userTimeout == "number" ? i.userTimeout = t.longs === String ? String(e.userTimeout) : e.userTimeout : i.userTimeout = t.longs === String ? p.Long.prototype.toString.call(e.userTimeout) : t.longs === Number ? new p.LongBits(e.userTimeout.low >>> 0, e.userTimeout.high >>> 0).toNumber(!0) : e.userTimeout), e.libBuildTs != null && e.hasOwnProperty("libBuildTs") && (typeof e.libBuildTs == "number" ? i.libBuildTs = t.longs === String ? String(e.libBuildTs) : e.libBuildTs : i.libBuildTs = t.longs === String ? p.Long.prototype.toString.call(e.libBuildTs) : t.longs === Number ? new p.LongBits(e.libBuildTs.low >>> 0, e.libBuildTs.high >>> 0).toNumber(!0) : e.libBuildTs), e.appProtocol != null && e.hasOwnProperty("appProtocol") && (i.appProtocol = e.appProtocol), i;
    }, n.prototype.toJSON = function () {
      return this.constructor.toObject(this, Y.util.toJSONOptions);
    }, n.getTypeUrl = function (e) {
      return e === void 0 && (e = "type.googleapis.com"), e + "/V3Header";
    }, n;
  })();
h();
function L(n, r, e) {
  var t = Date.now();
  return (...i) => {
    var o = r(...i),
      f = Date.now();
    return n[e] = f - t, o;
  };
}
function Ke(n, r, e) {
  var i = L(e, on.default.compress, "compress")(r),
    o = L(e, Zt, "encrypt")(n, i),
    f = o.encrypted;
  return e.backend = o.backend, {
    data: f
  };
}
function An(n, r, e, t, i, o) {
  var f = Object.entries(r).filter(([g, y]) => !ve(g) && !ve(y)).map(([g, y]) => ({
      key: g.toString().toLowerCase(),
      value: y.toString()
    })),
    s = Pe(t),
    A,
    u = !1;
  s === "object" ? A = JSON.stringify(t) : s !== "arraybuffer" ? s === "undefined" ? A = void 0 : A = t + "" : (A = t, u = !0);
  var l = u ? L(o, be.encode, "encodePb")({
    body: new Uint8Array(t),
    callId: i,
    header: f,
    method: e
  }).finish() : new Uint8Array(L(o, Ve, "stringToBuffer")(JSON.stringify({
    method: e,
    header: f,
    body: A,
    call_id: i
  })));
  return {
    ...Ke(n, l, o),
    contentEncoding: u ? "PB" : "JSON"
  };
}
function fn(n, r, e, t, i) {
  var o = t instanceof ArrayBuffer,
    f,
    s = Object.entries(r).filter(([A, u]) => A && u).map(([A, u]) => ({
      key: A.toLowerCase(),
      value: u
    }));
  return o ? f = he.encode({
    bodyBuffer: new Uint8Array(t),
    statusCode: e,
    header: s
  }).finish() : f = he.encode({
    bodyString: JSON.stringify(t),
    statusCode: e,
    header: s
  }).finish(), {
    ...Ke(n, f, i),
    contentEncoding: o ? "PB" : "JSON"
  };
}
function un(n, r, e) {
  var t = nn.encode(r).finish();
  return {
    ...Ke(n, t, e)
  };
}
h();
h();
function sn(n, r) {
  var e = Ie();
  return e ? e.decrypt(r, n, n) : le.decrypt(r, n, void 0, n);
}
var an = Le(ze(), 1);
function je(n, r, e, t = {}) {
  var i = L(t, sn, "decrypt")(n, r);
  return {
    data: e ? L(t, an.default.uncompress, "uncompress")(i) : i
  };
}
function ln(n, r, e, t, i = {}) {
  var {
      data: o
    } = je(n, r, e, i),
    f = t === "PB",
    s;
  if (f) s = be.decode(o);else {
    var A = He(o);
    s = JSON.parse(A);
  }
  return s;
}
function cn(n, r, e, t, i = {}) {
  var {
      data: o
    } = je(n, r, e, i),
    f = t === "PB",
    s;
  if (f) s = he.decode(o);else {
    var A = He(o);
    s = JSON.parse(A);
  }
  return {
    statusCode: s.statusCode,
    body: s.bodyString || s.bodyBuffer,
    header: s.header.reduce((A, u) => (u.key && u.value && (A[u.key] = A[u.key] ? A[u.key] + "," + u.value : u.value), A), {})
  };
}
function dn(n, r, e, t = {}) {
  var {
      data: i
    } = je(n, r, e, t),
    o = He(i);
  return {
    data: JSON.parse(o)
  };
}
var wn = {};
kt(wn, {
  decode: () => At,
  decodeRequest: () => Cn,
  decodeResponse: () => Qn,
  encode: () => ot,
  encodeRequest: () => Bn,
  encodeResponse: () => gn
});
h();
h();
h();
function vt(n, r) {
  var e = Ie(),
    t = new Uint8Array(16);
  Kt(t);
  var i = e ? e.encrypt(r, n, t) : le.encrypt(r, n, void 0, t);
  return {
    iv: t,
    encrypted: i,
    backend: e ? "wasm" : "js"
  };
}
h();
var Qi = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict";
var yn = (n = 21) => {
  var r = "",
    e = n;
  for (; e--;) r += Qi[Math.random() * 64 | 0];
  return r;
};
var pn = Le(ze(), 1);
function wi(n, r, e) {
  return r = +r, e = e >>> 0, n[e] = r >>> 8, n[e + 1] = r & 255, e + 2;
}
function ot(n, r, e = "JSON", t = {}) {
  var o = {
      appProtocol: `1/${e}`,
      compression: "snappy",
      encryptionTimestamp: Date.now(),
      libBuildTs: 1688712372026
    },
    f = it.encode(o).finish(),
    s = vt(n, f),
    A = s.iv.length + s.encrypted.length,
    u = new Uint8Array(2);
  wi(u, A, 0);
  var l = L(t, pn.default.compress, "compress")(r),
    g = L(t, vt, "encrypt")(n, l);
  return t.backend = g.backend, {
    data: jt([u, s.iv, s.encrypted, g.iv, g.encrypted]),
    __v3__header: o
  };
}
function Bn(n, r, e, t, i = {}) {
  var o = Pe(t),
    f = Object.entries(r).filter(([g, y]) => !ve(g) && !ve(y)).map(([g, y]) => ({
      key: g.toString().toLowerCase(),
      value: y.toString()
    })),
    s = `${Date.now()}-${yn(8)}`,
    A,
    u = !1;
  o === "object" ? A = JSON.stringify(t) : o !== "arraybuffer" ? o === "undefined" ? A = void 0 : A = t + "" : (A = t, u = !0);
  var l = u ? L(i, be.encode, "encodePb")({
    body: new Uint8Array(A),
    callId: s,
    header: f,
    method: e
  }).finish() : new Uint8Array(L(i, Ve, "stringToBuffer")(JSON.stringify({
    body: A,
    call_id: s,
    header: f,
    method: e
  })));
  return {
    ...ot(n, l, u ? "PB" : "JSON", i),
    callId: s,
    stats: i
  };
}
function gn(n, r, e, t) {
  var i = Pe(t),
    o = Object.entries(r).filter(([u, l]) => u && l).map(([u, l]) => ({
      key: u.toString().toLowerCase(),
      value: l.toString()
    })),
    f,
    s = !1;
  i === "object" ? f = JSON.stringify(t) : i !== "arraybuffer" ? f = t + "" : (f = t, s = !0), i === "object" ? f = JSON.stringify(t) : i !== "arraybuffer" ? f = t + "" : (f = t, s = !0);
  var A = s ? he.encode({
    bodyBuffer: new Uint8Array(f),
    statusCode: e,
    header: o
  }).finish() : he.encode({
    bodyString: JSON.stringify(t),
    statusCode: e,
    header: o
  }).finish();
  return ot(n, A, "PB");
}
h();
h();
function Ft(n, r) {
  var e = Ie(),
    t = r.subarray(0, 16),
    i = r.subarray(16);
  return e ? e.decrypt(i, n, t) : le.decrypt(i, n, void 0, t);
}
var In = Le(ze(), 1);
function bi(n, r) {
  return r = r >>> 0, n[r] << 8 | n[r + 1];
}
function At(n, r, e = {}) {
  var t = bi(r, 0),
    i = Ft(n, r.slice(2, t + 2)),
    o = it.decode(i),
    f = o.compression === "snappy",
    s = L(e, Ft, "decrypt")(n, r.slice(t + 2));
  return {
    data: f ? L(e, In.default.uncompress, "uncompress")(s) : s,
    __v3__header: o
  };
}
function Cn(n, r, e = {}) {
  var {
      data: t,
      __v3__header: i
    } = At(n, r, e),
    o = !1,
    f,
    s = i.appProtocol.split("/")[1];
  return s && (o = s === "PB"), o ? f = be.decode(t) : f = L(e, A => JSON.parse(He(A)), "decodeJson")(t), {
    ...f,
    __v3__header: i,
    stats: e
  };
}
function Qn(n, r, e = {}) {
  var {
      data: t,
      __v3__header: i
    } = At(n, r, e),
    o = !1,
    f,
    s = i.appProtocol.split("/")[1];
  return s && (o = s === "PB"), o ? f = L(e, he.decode, "decodePb")(t) : f = L(e, A => JSON.parse(He(A)), "decodeJson")(t), {
    statusCode: f.statusCode,
    body: f.bodyString || f.bodyBuffer,
    header: f.header.reduce((A, u) => (u.key && u.value && (A[u.key] = A[u.key] ? A[u.key] + "," + u.value : u.value), A), {}),
    __v3__header: i
  };
}


/***/ }),

/***/ 424:
/***/ ((module, exports, __webpack_require__) => {

/* module decorator */ module = __webpack_require__.nmd(module);
var __WEBPACK_AMD_DEFINE_RESULT__;;(function(){var undefined;var VERSION='4.17.15';var LARGE_ARRAY_SIZE=200;var CORE_ERROR_TEXT='Unsupported core-js use. Try https://npms.io/search?q=ponyfill.',FUNC_ERROR_TEXT='Expected a function';var HASH_UNDEFINED='__lodash_hash_undefined__';var MAX_MEMOIZE_SIZE=500;var PLACEHOLDER='__lodash_placeholder__';var CLONE_DEEP_FLAG=1,CLONE_FLAT_FLAG=2,CLONE_SYMBOLS_FLAG=4;var COMPARE_PARTIAL_FLAG=1,COMPARE_UNORDERED_FLAG=2;var WRAP_BIND_FLAG=1,WRAP_BIND_KEY_FLAG=2,WRAP_CURRY_BOUND_FLAG=4,WRAP_CURRY_FLAG=8,WRAP_CURRY_RIGHT_FLAG=16,WRAP_PARTIAL_FLAG=32,WRAP_PARTIAL_RIGHT_FLAG=64,WRAP_ARY_FLAG=128,WRAP_REARG_FLAG=256,WRAP_FLIP_FLAG=512;var DEFAULT_TRUNC_LENGTH=30,DEFAULT_TRUNC_OMISSION='...';var HOT_COUNT=800,HOT_SPAN=16;var LAZY_FILTER_FLAG=1,LAZY_MAP_FLAG=2,LAZY_WHILE_FLAG=3;var INFINITY=1/0,MAX_SAFE_INTEGER=9007199254740991,MAX_INTEGER=1.7976931348623157e+308,NAN=0/0;var MAX_ARRAY_LENGTH=4294967295,MAX_ARRAY_INDEX=MAX_ARRAY_LENGTH-1,HALF_MAX_ARRAY_LENGTH=MAX_ARRAY_LENGTH>>>1;var wrapFlags=[['ary',WRAP_ARY_FLAG],['bind',WRAP_BIND_FLAG],['bindKey',WRAP_BIND_KEY_FLAG],['curry',WRAP_CURRY_FLAG],['curryRight',WRAP_CURRY_RIGHT_FLAG],['flip',WRAP_FLIP_FLAG],['partial',WRAP_PARTIAL_FLAG],['partialRight',WRAP_PARTIAL_RIGHT_FLAG],['rearg',WRAP_REARG_FLAG]];var argsTag='[object Arguments]',arrayTag='[object Array]',asyncTag='[object AsyncFunction]',boolTag='[object Boolean]',dateTag='[object Date]',domExcTag='[object DOMException]',errorTag='[object Error]',funcTag='[object Function]',genTag='[object GeneratorFunction]',mapTag='[object Map]',numberTag='[object Number]',nullTag='[object Null]',objectTag='[object Object]',promiseTag='[object Promise]',proxyTag='[object Proxy]',regexpTag='[object RegExp]',setTag='[object Set]',stringTag='[object String]',symbolTag='[object Symbol]',undefinedTag='[object Undefined]',weakMapTag='[object WeakMap]',weakSetTag='[object WeakSet]';var arrayBufferTag='[object ArrayBuffer]',dataViewTag='[object DataView]',float32Tag='[object Float32Array]',float64Tag='[object Float64Array]',int8Tag='[object Int8Array]',int16Tag='[object Int16Array]',int32Tag='[object Int32Array]',uint8Tag='[object Uint8Array]',uint8ClampedTag='[object Uint8ClampedArray]',uint16Tag='[object Uint16Array]',uint32Tag='[object Uint32Array]';var reEmptyStringLeading=/\b__p \+= '';/g,reEmptyStringMiddle=/\b(__p \+=) '' \+/g,reEmptyStringTrailing=/(__e\(.*?\)|\b__t\)) \+\n'';/g;var reEscapedHtml=/&(?:amp|lt|gt|quot|#39);/g,reUnescapedHtml=/[&<>"']/g,reHasEscapedHtml=RegExp(reEscapedHtml.source),reHasUnescapedHtml=RegExp(reUnescapedHtml.source);var reEscape=/<%-([\s\S]+?)%>/g,reEvaluate=/<%([\s\S]+?)%>/g,reInterpolate=/<%=([\s\S]+?)%>/g;var reIsDeepProp=/\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,reIsPlainProp=/^\w*$/,rePropName=/[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;var reRegExpChar=/[\\^$.*+?()[\]{}|]/g,reHasRegExpChar=RegExp(reRegExpChar.source);var reTrim=/^\s+|\s+$/g,reTrimStart=/^\s+/,reTrimEnd=/\s+$/;var reWrapComment=/\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/,reWrapDetails=/\{\n\/\* \[wrapped with (.+)\] \*/,reSplitDetails=/,? & /;var reAsciiWord=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;var reEscapeChar=/\\(\\)?/g;var reEsTemplate=/\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g;var reFlags=/\w*$/;var reIsBadHex=/^[-+]0x[0-9a-f]+$/i;var reIsBinary=/^0b[01]+$/i;var reIsHostCtor=/^\[object .+?Constructor\]$/;var reIsOctal=/^0o[0-7]+$/i;var reIsUint=/^(?:0|[1-9]\d*)$/;var reLatin=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g;var reNoMatch=/($^)/;var reUnescapedString=/['\n\r\u2028\u2029\\]/g;var rsAstralRange='\\ud800-\\udfff',rsComboMarksRange='\\u0300-\\u036f',reComboHalfMarksRange='\\ufe20-\\ufe2f',rsComboSymbolsRange='\\u20d0-\\u20ff',rsComboRange=rsComboMarksRange+reComboHalfMarksRange+rsComboSymbolsRange,rsDingbatRange='\\u2700-\\u27bf',rsLowerRange='a-z\\xdf-\\xf6\\xf8-\\xff',rsMathOpRange='\\xac\\xb1\\xd7\\xf7',rsNonCharRange='\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf',rsPunctuationRange='\\u2000-\\u206f',rsSpaceRange=' \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000',rsUpperRange='A-Z\\xc0-\\xd6\\xd8-\\xde',rsVarRange='\\ufe0e\\ufe0f',rsBreakRange=rsMathOpRange+rsNonCharRange+rsPunctuationRange+rsSpaceRange;var rsApos="['\u2019]",rsAstral='['+rsAstralRange+']',rsBreak='['+rsBreakRange+']',rsCombo='['+rsComboRange+']',rsDigits='\\d+',rsDingbat='['+rsDingbatRange+']',rsLower='['+rsLowerRange+']',rsMisc='[^'+rsAstralRange+rsBreakRange+rsDigits+rsDingbatRange+rsLowerRange+rsUpperRange+']',rsFitz='\\ud83c[\\udffb-\\udfff]',rsModifier='(?:'+rsCombo+'|'+rsFitz+')',rsNonAstral='[^'+rsAstralRange+']',rsRegional='(?:\\ud83c[\\udde6-\\uddff]){2}',rsSurrPair='[\\ud800-\\udbff][\\udc00-\\udfff]',rsUpper='['+rsUpperRange+']',rsZWJ='\\u200d';var rsMiscLower='(?:'+rsLower+'|'+rsMisc+')',rsMiscUpper='(?:'+rsUpper+'|'+rsMisc+')',rsOptContrLower='(?:'+rsApos+'(?:d|ll|m|re|s|t|ve))?',rsOptContrUpper='(?:'+rsApos+'(?:D|LL|M|RE|S|T|VE))?',reOptMod=rsModifier+'?',rsOptVar='['+rsVarRange+']?',rsOptJoin='(?:'+rsZWJ+'(?:'+[rsNonAstral,rsRegional,rsSurrPair].join('|')+')'+rsOptVar+reOptMod+')*',rsOrdLower='\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])',rsOrdUpper='\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])',rsSeq=rsOptVar+reOptMod+rsOptJoin,rsEmoji='(?:'+[rsDingbat,rsRegional,rsSurrPair].join('|')+')'+rsSeq,rsSymbol='(?:'+[rsNonAstral+rsCombo+'?',rsCombo,rsRegional,rsSurrPair,rsAstral].join('|')+')';var reApos=RegExp(rsApos,'g');var reComboMark=RegExp(rsCombo,'g');var reUnicode=RegExp(rsFitz+'(?='+rsFitz+')|'+rsSymbol+rsSeq,'g');var reUnicodeWord=RegExp([rsUpper+'?'+rsLower+'+'+rsOptContrLower+'(?='+[rsBreak,rsUpper,'$'].join('|')+')',rsMiscUpper+'+'+rsOptContrUpper+'(?='+[rsBreak,rsUpper+rsMiscLower,'$'].join('|')+')',rsUpper+'?'+rsMiscLower+'+'+rsOptContrLower,rsUpper+'+'+rsOptContrUpper,rsOrdUpper,rsOrdLower,rsDigits,rsEmoji].join('|'),'g');var reHasUnicode=RegExp('['+rsZWJ+rsAstralRange+rsComboRange+rsVarRange+']');var reHasUnicodeWord=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;var contextProps=['Array','Buffer','DataView','Date','Error','Float32Array','Float64Array','Function','Int8Array','Int16Array','Int32Array','Map','Math','Object','Promise','RegExp','Set','String','Symbol','TypeError','Uint8Array','Uint8ClampedArray','Uint16Array','Uint32Array','WeakMap','_','clearTimeout','isFinite','parseInt','setTimeout'];var templateCounter=-1;var typedArrayTags={};typedArrayTags[float32Tag]=typedArrayTags[float64Tag]=typedArrayTags[int8Tag]=typedArrayTags[int16Tag]=typedArrayTags[int32Tag]=typedArrayTags[uint8Tag]=typedArrayTags[uint8ClampedTag]=typedArrayTags[uint16Tag]=typedArrayTags[uint32Tag]=true;typedArrayTags[argsTag]=typedArrayTags[arrayTag]=typedArrayTags[arrayBufferTag]=typedArrayTags[boolTag]=typedArrayTags[dataViewTag]=typedArrayTags[dateTag]=typedArrayTags[errorTag]=typedArrayTags[funcTag]=typedArrayTags[mapTag]=typedArrayTags[numberTag]=typedArrayTags[objectTag]=typedArrayTags[regexpTag]=typedArrayTags[setTag]=typedArrayTags[stringTag]=typedArrayTags[weakMapTag]=false;var cloneableTags={};cloneableTags[argsTag]=cloneableTags[arrayTag]=cloneableTags[arrayBufferTag]=cloneableTags[dataViewTag]=cloneableTags[boolTag]=cloneableTags[dateTag]=cloneableTags[float32Tag]=cloneableTags[float64Tag]=cloneableTags[int8Tag]=cloneableTags[int16Tag]=cloneableTags[int32Tag]=cloneableTags[mapTag]=cloneableTags[numberTag]=cloneableTags[objectTag]=cloneableTags[regexpTag]=cloneableTags[setTag]=cloneableTags[stringTag]=cloneableTags[symbolTag]=cloneableTags[uint8Tag]=cloneableTags[uint8ClampedTag]=cloneableTags[uint16Tag]=cloneableTags[uint32Tag]=true;cloneableTags[errorTag]=cloneableTags[funcTag]=cloneableTags[weakMapTag]=false;var deburredLetters={'\xc0':'A','\xc1':'A','\xc2':'A','\xc3':'A','\xc4':'A','\xc5':'A','\xe0':'a','\xe1':'a','\xe2':'a','\xe3':'a','\xe4':'a','\xe5':'a','\xc7':'C','\xe7':'c','\xd0':'D','\xf0':'d','\xc8':'E','\xc9':'E','\xca':'E','\xcb':'E','\xe8':'e','\xe9':'e','\xea':'e','\xeb':'e','\xcc':'I','\xcd':'I','\xce':'I','\xcf':'I','\xec':'i','\xed':'i','\xee':'i','\xef':'i','\xd1':'N','\xf1':'n','\xd2':'O','\xd3':'O','\xd4':'O','\xd5':'O','\xd6':'O','\xd8':'O','\xf2':'o','\xf3':'o','\xf4':'o','\xf5':'o','\xf6':'o','\xf8':'o','\xd9':'U','\xda':'U','\xdb':'U','\xdc':'U','\xf9':'u','\xfa':'u','\xfb':'u','\xfc':'u','\xdd':'Y','\xfd':'y','\xff':'y','\xc6':'Ae','\xe6':'ae','\xde':'Th','\xfe':'th','\xdf':'ss','\u0100':'A','\u0102':'A','\u0104':'A','\u0101':'a','\u0103':'a','\u0105':'a','\u0106':'C','\u0108':'C','\u010a':'C','\u010c':'C','\u0107':'c','\u0109':'c','\u010b':'c','\u010d':'c','\u010e':'D','\u0110':'D','\u010f':'d','\u0111':'d','\u0112':'E','\u0114':'E','\u0116':'E','\u0118':'E','\u011a':'E','\u0113':'e','\u0115':'e','\u0117':'e','\u0119':'e','\u011b':'e','\u011c':'G','\u011e':'G','\u0120':'G','\u0122':'G','\u011d':'g','\u011f':'g','\u0121':'g','\u0123':'g','\u0124':'H','\u0126':'H','\u0125':'h','\u0127':'h','\u0128':'I','\u012a':'I','\u012c':'I','\u012e':'I','\u0130':'I','\u0129':'i','\u012b':'i','\u012d':'i','\u012f':'i','\u0131':'i','\u0134':'J','\u0135':'j','\u0136':'K','\u0137':'k','\u0138':'k','\u0139':'L','\u013b':'L','\u013d':'L','\u013f':'L','\u0141':'L','\u013a':'l','\u013c':'l','\u013e':'l','\u0140':'l','\u0142':'l','\u0143':'N','\u0145':'N','\u0147':'N','\u014a':'N','\u0144':'n','\u0146':'n','\u0148':'n','\u014b':'n','\u014c':'O','\u014e':'O','\u0150':'O','\u014d':'o','\u014f':'o','\u0151':'o','\u0154':'R','\u0156':'R','\u0158':'R','\u0155':'r','\u0157':'r','\u0159':'r','\u015a':'S','\u015c':'S','\u015e':'S','\u0160':'S','\u015b':'s','\u015d':'s','\u015f':'s','\u0161':'s','\u0162':'T','\u0164':'T','\u0166':'T','\u0163':'t','\u0165':'t','\u0167':'t','\u0168':'U','\u016a':'U','\u016c':'U','\u016e':'U','\u0170':'U','\u0172':'U','\u0169':'u','\u016b':'u','\u016d':'u','\u016f':'u','\u0171':'u','\u0173':'u','\u0174':'W','\u0175':'w','\u0176':'Y','\u0177':'y','\u0178':'Y','\u0179':'Z','\u017b':'Z','\u017d':'Z','\u017a':'z','\u017c':'z','\u017e':'z','\u0132':'IJ','\u0133':'ij','\u0152':'Oe','\u0153':'oe','\u0149':"'n",'\u017f':'s'};var htmlEscapes={'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'};var htmlUnescapes={'&amp;':'&','&lt;':'<','&gt;':'>','&quot;':'"','&#39;':"'"};var stringEscapes={'\\':'\\',"'":"'",'\n':'n','\r':'r','\u2028':'u2028','\u2029':'u2029'};var freeParseFloat=parseFloat,freeParseInt=parseInt;var freeGlobal=typeof __webpack_require__.g=='object'&&__webpack_require__.g&&__webpack_require__.g.Object===Object&&__webpack_require__.g;var freeSelf=typeof self=='object'&&self&&self.Object===Object&&self;var root=freeGlobal||freeSelf||Function('return this')();var freeExports= true&&exports&&!exports.nodeType&&exports;var freeModule=freeExports&&"object"=='object'&&module&&!module.nodeType&&module;var moduleExports=freeModule&&freeModule.exports===freeExports;var freeProcess=moduleExports&&freeGlobal.process;var nodeUtil=function(){try{var types=freeModule&&freeModule.require&&freeModule.require('util').types;if(types){return types;}return freeProcess&&freeProcess.binding&&freeProcess.binding('util');}catch(e){}}();var nodeIsArrayBuffer=nodeUtil&&nodeUtil.isArrayBuffer,nodeIsDate=nodeUtil&&nodeUtil.isDate,nodeIsMap=nodeUtil&&nodeUtil.isMap,nodeIsRegExp=nodeUtil&&nodeUtil.isRegExp,nodeIsSet=nodeUtil&&nodeUtil.isSet,nodeIsTypedArray=nodeUtil&&nodeUtil.isTypedArray;function apply(func,thisArg,args){switch(args.length){case 0:return func.call(thisArg);case 1:return func.call(thisArg,args[0]);case 2:return func.call(thisArg,args[0],args[1]);case 3:return func.call(thisArg,args[0],args[1],args[2]);}return func.apply(thisArg,args);}function arrayAggregator(array,setter,iteratee,accumulator){var index=-1,length=array==null?0:array.length;while(++index<length){var value=array[index];setter(accumulator,value,iteratee(value),array);}return accumulator;}function arrayEach(array,iteratee){var index=-1,length=array==null?0:array.length;while(++index<length){if(iteratee(array[index],index,array)===false){break;}}return array;}function arrayEachRight(array,iteratee){var length=array==null?0:array.length;while(length--){if(iteratee(array[length],length,array)===false){break;}}return array;}function arrayEvery(array,predicate){var index=-1,length=array==null?0:array.length;while(++index<length){if(!predicate(array[index],index,array)){return false;}}return true;}function arrayFilter(array,predicate){var index=-1,length=array==null?0:array.length,resIndex=0,result=[];while(++index<length){var value=array[index];if(predicate(value,index,array)){result[resIndex++]=value;}}return result;}function arrayIncludes(array,value){var length=array==null?0:array.length;return!!length&&baseIndexOf(array,value,0)>-1;}function arrayIncludesWith(array,value,comparator){var index=-1,length=array==null?0:array.length;while(++index<length){if(comparator(value,array[index])){return true;}}return false;}function arrayMap(array,iteratee){var index=-1,length=array==null?0:array.length,result=Array(length);while(++index<length){result[index]=iteratee(array[index],index,array);}return result;}function arrayPush(array,values){var index=-1,length=values.length,offset=array.length;while(++index<length){array[offset+index]=values[index];}return array;}function arrayReduce(array,iteratee,accumulator,initAccum){var index=-1,length=array==null?0:array.length;if(initAccum&&length){accumulator=array[++index];}while(++index<length){accumulator=iteratee(accumulator,array[index],index,array);}return accumulator;}function arrayReduceRight(array,iteratee,accumulator,initAccum){var length=array==null?0:array.length;if(initAccum&&length){accumulator=array[--length];}while(length--){accumulator=iteratee(accumulator,array[length],length,array);}return accumulator;}function arraySome(array,predicate){var index=-1,length=array==null?0:array.length;while(++index<length){if(predicate(array[index],index,array)){return true;}}return false;}var asciiSize=baseProperty('length');function asciiToArray(string){return string.split('');}function asciiWords(string){return string.match(reAsciiWord)||[];}function baseFindKey(collection,predicate,eachFunc){var result;eachFunc(collection,function(value,key,collection){if(predicate(value,key,collection)){result=key;return false;}});return result;}function baseFindIndex(array,predicate,fromIndex,fromRight){var length=array.length,index=fromIndex+(fromRight?1:-1);while(fromRight?index--:++index<length){if(predicate(array[index],index,array)){return index;}}return-1;}function baseIndexOf(array,value,fromIndex){return value===value?strictIndexOf(array,value,fromIndex):baseFindIndex(array,baseIsNaN,fromIndex);}function baseIndexOfWith(array,value,fromIndex,comparator){var index=fromIndex-1,length=array.length;while(++index<length){if(comparator(array[index],value)){return index;}}return-1;}function baseIsNaN(value){return value!==value;}function baseMean(array,iteratee){var length=array==null?0:array.length;return length?baseSum(array,iteratee)/length:NAN;}function baseProperty(key){return function(object){return object==null?undefined:object[key];};}function basePropertyOf(object){return function(key){return object==null?undefined:object[key];};}function baseReduce(collection,iteratee,accumulator,initAccum,eachFunc){eachFunc(collection,function(value,index,collection){accumulator=initAccum?(initAccum=false,value):iteratee(accumulator,value,index,collection);});return accumulator;}function baseSortBy(array,comparer){var length=array.length;array.sort(comparer);while(length--){array[length]=array[length].value;}return array;}function baseSum(array,iteratee){var result,index=-1,length=array.length;while(++index<length){var current=iteratee(array[index]);if(current!==undefined){result=result===undefined?current:result+current;}}return result;}function baseTimes(n,iteratee){var index=-1,result=Array(n);while(++index<n){result[index]=iteratee(index);}return result;}function baseToPairs(object,props){return arrayMap(props,function(key){return[key,object[key]];});}function baseUnary(func){return function(value){return func(value);};}function baseValues(object,props){return arrayMap(props,function(key){return object[key];});}function cacheHas(cache,key){return cache.has(key);}function charsStartIndex(strSymbols,chrSymbols){var index=-1,length=strSymbols.length;while(++index<length&&baseIndexOf(chrSymbols,strSymbols[index],0)>-1){}return index;}function charsEndIndex(strSymbols,chrSymbols){var index=strSymbols.length;while(index--&&baseIndexOf(chrSymbols,strSymbols[index],0)>-1){}return index;}function countHolders(array,placeholder){var length=array.length,result=0;while(length--){if(array[length]===placeholder){++result;}}return result;}var deburrLetter=basePropertyOf(deburredLetters);var escapeHtmlChar=basePropertyOf(htmlEscapes);function escapeStringChar(chr){return'\\'+stringEscapes[chr];}function getValue(object,key){return object==null?undefined:object[key];}function hasUnicode(string){return reHasUnicode.test(string);}function hasUnicodeWord(string){return reHasUnicodeWord.test(string);}function iteratorToArray(iterator){var data,result=[];while(!(data=iterator.next()).done){result.push(data.value);}return result;}function mapToArray(map){var index=-1,result=Array(map.size);map.forEach(function(value,key){result[++index]=[key,value];});return result;}function overArg(func,transform){return function(arg){return func(transform(arg));};}function replaceHolders(array,placeholder){var index=-1,length=array.length,resIndex=0,result=[];while(++index<length){var value=array[index];if(value===placeholder||value===PLACEHOLDER){array[index]=PLACEHOLDER;result[resIndex++]=index;}}return result;}function setToArray(set){var index=-1,result=Array(set.size);set.forEach(function(value){result[++index]=value;});return result;}function setToPairs(set){var index=-1,result=Array(set.size);set.forEach(function(value){result[++index]=[value,value];});return result;}function strictIndexOf(array,value,fromIndex){var index=fromIndex-1,length=array.length;while(++index<length){if(array[index]===value){return index;}}return-1;}function strictLastIndexOf(array,value,fromIndex){var index=fromIndex+1;while(index--){if(array[index]===value){return index;}}return index;}function stringSize(string){return hasUnicode(string)?unicodeSize(string):asciiSize(string);}function stringToArray(string){return hasUnicode(string)?unicodeToArray(string):asciiToArray(string);}var unescapeHtmlChar=basePropertyOf(htmlUnescapes);function unicodeSize(string){var result=reUnicode.lastIndex=0;while(reUnicode.test(string)){++result;}return result;}function unicodeToArray(string){return string.match(reUnicode)||[];}function unicodeWords(string){return string.match(reUnicodeWord)||[];}var runInContext=function runInContext(context){context=context==null?root:_.defaults(root.Object(),context,_.pick(root,contextProps));var Array=context.Array,Date=context.Date,Error=context.Error,Function=context.Function,Math=context.Math,Object=context.Object,RegExp=context.RegExp,String=context.String,TypeError=context.TypeError;var arrayProto=Array.prototype,funcProto=Function.prototype,objectProto=Object.prototype;var coreJsData=context['__core-js_shared__'];var funcToString=funcProto.toString;var hasOwnProperty=objectProto.hasOwnProperty;var idCounter=0;var maskSrcKey=function(){var uid=/[^.]+$/.exec(coreJsData&&coreJsData.keys&&coreJsData.keys.IE_PROTO||'');return uid?'Symbol(src)_1.'+uid:'';}();var nativeObjectToString=objectProto.toString;var objectCtorString=funcToString.call(Object);var oldDash=root._;var reIsNative=RegExp('^'+funcToString.call(hasOwnProperty).replace(reRegExpChar,'\\$&').replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,'$1.*?')+'$');var Buffer=moduleExports?context.Buffer:undefined,Symbol=context.Symbol,Uint8Array=context.Uint8Array,allocUnsafe=Buffer?Buffer.allocUnsafe:undefined,getPrototype=overArg(Object.getPrototypeOf,Object),objectCreate=Object.create,propertyIsEnumerable=objectProto.propertyIsEnumerable,splice=arrayProto.splice,spreadableSymbol=Symbol?Symbol.isConcatSpreadable:undefined,symIterator=Symbol?Symbol.iterator:undefined,symToStringTag=Symbol?Symbol.toStringTag:undefined;var defineProperty=function(){try{var func=getNative(Object,'defineProperty');func({},'',{});return func;}catch(e){}}();var ctxClearTimeout=context.clearTimeout!==root.clearTimeout&&context.clearTimeout,ctxNow=Date&&Date.now!==root.Date.now&&Date.now,ctxSetTimeout=context.setTimeout!==root.setTimeout&&context.setTimeout;var nativeCeil=Math.ceil,nativeFloor=Math.floor,nativeGetSymbols=Object.getOwnPropertySymbols,nativeIsBuffer=Buffer?Buffer.isBuffer:undefined,nativeIsFinite=context.isFinite,nativeJoin=arrayProto.join,nativeKeys=overArg(Object.keys,Object),nativeMax=Math.max,nativeMin=Math.min,nativeNow=Date.now,nativeParseInt=context.parseInt,nativeRandom=Math.random,nativeReverse=arrayProto.reverse;var DataView=getNative(context,'DataView'),Map=getNative(context,'Map'),Promise=getNative(context,'Promise'),Set=getNative(context,'Set'),WeakMap=getNative(context,'WeakMap'),nativeCreate=getNative(Object,'create');var metaMap=WeakMap&&new WeakMap();var realNames={};var dataViewCtorString=toSource(DataView),mapCtorString=toSource(Map),promiseCtorString=toSource(Promise),setCtorString=toSource(Set),weakMapCtorString=toSource(WeakMap);var symbolProto=Symbol?Symbol.prototype:undefined,symbolValueOf=symbolProto?symbolProto.valueOf:undefined,symbolToString=symbolProto?symbolProto.toString:undefined;function lodash(value){if(isObjectLike(value)&&!isArray(value)&&!(value instanceof LazyWrapper)){if(value instanceof LodashWrapper){return value;}if(hasOwnProperty.call(value,'__wrapped__')){return wrapperClone(value);}}return new LodashWrapper(value);}var baseCreate=function(){function object(){}return function(proto){if(!isObject(proto)){return{};}if(objectCreate){return objectCreate(proto);}object.prototype=proto;var result=new object();object.prototype=undefined;return result;};}();function baseLodash(){}function LodashWrapper(value,chainAll){this.__wrapped__=value;this.__actions__=[];this.__chain__=!!chainAll;this.__index__=0;this.__values__=undefined;}lodash.templateSettings={'escape':reEscape,'evaluate':reEvaluate,'interpolate':reInterpolate,'variable':'','imports':{'_':lodash}};lodash.prototype=baseLodash.prototype;lodash.prototype.constructor=lodash;LodashWrapper.prototype=baseCreate(baseLodash.prototype);LodashWrapper.prototype.constructor=LodashWrapper;function LazyWrapper(value){this.__wrapped__=value;this.__actions__=[];this.__dir__=1;this.__filtered__=false;this.__iteratees__=[];this.__takeCount__=MAX_ARRAY_LENGTH;this.__views__=[];}function lazyClone(){var result=new LazyWrapper(this.__wrapped__);result.__actions__=copyArray(this.__actions__);result.__dir__=this.__dir__;result.__filtered__=this.__filtered__;result.__iteratees__=copyArray(this.__iteratees__);result.__takeCount__=this.__takeCount__;result.__views__=copyArray(this.__views__);return result;}function lazyReverse(){if(this.__filtered__){var result=new LazyWrapper(this);result.__dir__=-1;result.__filtered__=true;}else{result=this.clone();result.__dir__*=-1;}return result;}function lazyValue(){var array=this.__wrapped__.value(),dir=this.__dir__,isArr=isArray(array),isRight=dir<0,arrLength=isArr?array.length:0,view=getView(0,arrLength,this.__views__),start=view.start,end=view.end,length=end-start,index=isRight?end:start-1,iteratees=this.__iteratees__,iterLength=iteratees.length,resIndex=0,takeCount=nativeMin(length,this.__takeCount__);if(!isArr||!isRight&&arrLength==length&&takeCount==length){return baseWrapperValue(array,this.__actions__);}var result=[];outer:while(length--&&resIndex<takeCount){index+=dir;var iterIndex=-1,value=array[index];while(++iterIndex<iterLength){var data=iteratees[iterIndex],iteratee=data.iteratee,type=data.type,computed=iteratee(value);if(type==LAZY_MAP_FLAG){value=computed;}else if(!computed){if(type==LAZY_FILTER_FLAG){continue outer;}else{break outer;}}}result[resIndex++]=value;}return result;}LazyWrapper.prototype=baseCreate(baseLodash.prototype);LazyWrapper.prototype.constructor=LazyWrapper;function Hash(entries){var index=-1,length=entries==null?0:entries.length;this.clear();while(++index<length){var entry=entries[index];this.set(entry[0],entry[1]);}}function hashClear(){this.__data__=nativeCreate?nativeCreate(null):{};this.size=0;}function hashDelete(key){var result=this.has(key)&&delete this.__data__[key];this.size-=result?1:0;return result;}function hashGet(key){var data=this.__data__;if(nativeCreate){var result=data[key];return result===HASH_UNDEFINED?undefined:result;}return hasOwnProperty.call(data,key)?data[key]:undefined;}function hashHas(key){var data=this.__data__;return nativeCreate?data[key]!==undefined:hasOwnProperty.call(data,key);}function hashSet(key,value){var data=this.__data__;this.size+=this.has(key)?0:1;data[key]=nativeCreate&&value===undefined?HASH_UNDEFINED:value;return this;}Hash.prototype.clear=hashClear;Hash.prototype['delete']=hashDelete;Hash.prototype.get=hashGet;Hash.prototype.has=hashHas;Hash.prototype.set=hashSet;function ListCache(entries){var index=-1,length=entries==null?0:entries.length;this.clear();while(++index<length){var entry=entries[index];this.set(entry[0],entry[1]);}}function listCacheClear(){this.__data__=[];this.size=0;}function listCacheDelete(key){var data=this.__data__,index=assocIndexOf(data,key);if(index<0){return false;}var lastIndex=data.length-1;if(index==lastIndex){data.pop();}else{splice.call(data,index,1);}--this.size;return true;}function listCacheGet(key){var data=this.__data__,index=assocIndexOf(data,key);return index<0?undefined:data[index][1];}function listCacheHas(key){return assocIndexOf(this.__data__,key)>-1;}function listCacheSet(key,value){var data=this.__data__,index=assocIndexOf(data,key);if(index<0){++this.size;data.push([key,value]);}else{data[index][1]=value;}return this;}ListCache.prototype.clear=listCacheClear;ListCache.prototype['delete']=listCacheDelete;ListCache.prototype.get=listCacheGet;ListCache.prototype.has=listCacheHas;ListCache.prototype.set=listCacheSet;function MapCache(entries){var index=-1,length=entries==null?0:entries.length;this.clear();while(++index<length){var entry=entries[index];this.set(entry[0],entry[1]);}}function mapCacheClear(){this.size=0;this.__data__={'hash':new Hash(),'map':new(Map||ListCache)(),'string':new Hash()};}function mapCacheDelete(key){var result=getMapData(this,key)['delete'](key);this.size-=result?1:0;return result;}function mapCacheGet(key){return getMapData(this,key).get(key);}function mapCacheHas(key){return getMapData(this,key).has(key);}function mapCacheSet(key,value){var data=getMapData(this,key),size=data.size;data.set(key,value);this.size+=data.size==size?0:1;return this;}MapCache.prototype.clear=mapCacheClear;MapCache.prototype['delete']=mapCacheDelete;MapCache.prototype.get=mapCacheGet;MapCache.prototype.has=mapCacheHas;MapCache.prototype.set=mapCacheSet;function SetCache(values){var index=-1,length=values==null?0:values.length;this.__data__=new MapCache();while(++index<length){this.add(values[index]);}}function setCacheAdd(value){this.__data__.set(value,HASH_UNDEFINED);return this;}function setCacheHas(value){return this.__data__.has(value);}SetCache.prototype.add=SetCache.prototype.push=setCacheAdd;SetCache.prototype.has=setCacheHas;function Stack(entries){var data=this.__data__=new ListCache(entries);this.size=data.size;}function stackClear(){this.__data__=new ListCache();this.size=0;}function stackDelete(key){var data=this.__data__,result=data['delete'](key);this.size=data.size;return result;}function stackGet(key){return this.__data__.get(key);}function stackHas(key){return this.__data__.has(key);}function stackSet(key,value){var data=this.__data__;if(data instanceof ListCache){var pairs=data.__data__;if(!Map||pairs.length<LARGE_ARRAY_SIZE-1){pairs.push([key,value]);this.size=++data.size;return this;}data=this.__data__=new MapCache(pairs);}data.set(key,value);this.size=data.size;return this;}Stack.prototype.clear=stackClear;Stack.prototype['delete']=stackDelete;Stack.prototype.get=stackGet;Stack.prototype.has=stackHas;Stack.prototype.set=stackSet;function arrayLikeKeys(value,inherited){var isArr=isArray(value),isArg=!isArr&&isArguments(value),isBuff=!isArr&&!isArg&&isBuffer(value),isType=!isArr&&!isArg&&!isBuff&&isTypedArray(value),skipIndexes=isArr||isArg||isBuff||isType,result=skipIndexes?baseTimes(value.length,String):[],length=result.length;for(var key in value){if((inherited||hasOwnProperty.call(value,key))&&!(skipIndexes&&(key=='length'||isBuff&&(key=='offset'||key=='parent')||isType&&(key=='buffer'||key=='byteLength'||key=='byteOffset')||isIndex(key,length)))){result.push(key);}}return result;}function arraySample(array){var length=array.length;return length?array[baseRandom(0,length-1)]:undefined;}function arraySampleSize(array,n){return shuffleSelf(copyArray(array),baseClamp(n,0,array.length));}function arrayShuffle(array){return shuffleSelf(copyArray(array));}function assignMergeValue(object,key,value){if(value!==undefined&&!eq(object[key],value)||value===undefined&&!(key in object)){baseAssignValue(object,key,value);}}function assignValue(object,key,value){var objValue=object[key];if(!(hasOwnProperty.call(object,key)&&eq(objValue,value))||value===undefined&&!(key in object)){baseAssignValue(object,key,value);}}function assocIndexOf(array,key){var length=array.length;while(length--){if(eq(array[length][0],key)){return length;}}return-1;}function baseAggregator(collection,setter,iteratee,accumulator){baseEach(collection,function(value,key,collection){setter(accumulator,value,iteratee(value),collection);});return accumulator;}function baseAssign(object,source){return object&&copyObject(source,keys(source),object);}function baseAssignIn(object,source){return object&&copyObject(source,keysIn(source),object);}function baseAssignValue(object,key,value){if(key=='__proto__'&&defineProperty){defineProperty(object,key,{'configurable':true,'enumerable':true,'value':value,'writable':true});}else{object[key]=value;}}function baseAt(object,paths){var index=-1,length=paths.length,result=Array(length),skip=object==null;while(++index<length){result[index]=skip?undefined:get(object,paths[index]);}return result;}function baseClamp(number,lower,upper){if(number===number){if(upper!==undefined){number=number<=upper?number:upper;}if(lower!==undefined){number=number>=lower?number:lower;}}return number;}function baseClone(value,bitmask,customizer,key,object,stack){var result,isDeep=bitmask&CLONE_DEEP_FLAG,isFlat=bitmask&CLONE_FLAT_FLAG,isFull=bitmask&CLONE_SYMBOLS_FLAG;if(customizer){result=object?customizer(value,key,object,stack):customizer(value);}if(result!==undefined){return result;}if(!isObject(value)){return value;}var isArr=isArray(value);if(isArr){result=initCloneArray(value);if(!isDeep){return copyArray(value,result);}}else{var tag=getTag(value),isFunc=tag==funcTag||tag==genTag;if(isBuffer(value)){return cloneBuffer(value,isDeep);}if(tag==objectTag||tag==argsTag||isFunc&&!object){result=isFlat||isFunc?{}:initCloneObject(value);if(!isDeep){return isFlat?copySymbolsIn(value,baseAssignIn(result,value)):copySymbols(value,baseAssign(result,value));}}else{if(!cloneableTags[tag]){return object?value:{};}result=initCloneByTag(value,tag,isDeep);}}stack||(stack=new Stack());var stacked=stack.get(value);if(stacked){return stacked;}stack.set(value,result);if(isSet(value)){value.forEach(function(subValue){result.add(baseClone(subValue,bitmask,customizer,subValue,value,stack));});}else if(isMap(value)){value.forEach(function(subValue,key){result.set(key,baseClone(subValue,bitmask,customizer,key,value,stack));});}var keysFunc=isFull?isFlat?getAllKeysIn:getAllKeys:isFlat?keysIn:keys;var props=isArr?undefined:keysFunc(value);arrayEach(props||value,function(subValue,key){if(props){key=subValue;subValue=value[key];}assignValue(result,key,baseClone(subValue,bitmask,customizer,key,value,stack));});return result;}function baseConforms(source){var props=keys(source);return function(object){return baseConformsTo(object,source,props);};}function baseConformsTo(object,source,props){var length=props.length;if(object==null){return!length;}object=Object(object);while(length--){var key=props[length],predicate=source[key],value=object[key];if(value===undefined&&!(key in object)||!predicate(value)){return false;}}return true;}function baseDelay(func,wait,args){if(typeof func!='function'){throw new TypeError(FUNC_ERROR_TEXT);}return setTimeout(function(){func.apply(undefined,args);},wait);}function baseDifference(array,values,iteratee,comparator){var index=-1,includes=arrayIncludes,isCommon=true,length=array.length,result=[],valuesLength=values.length;if(!length){return result;}if(iteratee){values=arrayMap(values,baseUnary(iteratee));}if(comparator){includes=arrayIncludesWith;isCommon=false;}else if(values.length>=LARGE_ARRAY_SIZE){includes=cacheHas;isCommon=false;values=new SetCache(values);}outer:while(++index<length){var value=array[index],computed=iteratee==null?value:iteratee(value);value=comparator||value!==0?value:0;if(isCommon&&computed===computed){var valuesIndex=valuesLength;while(valuesIndex--){if(values[valuesIndex]===computed){continue outer;}}result.push(value);}else if(!includes(values,computed,comparator)){result.push(value);}}return result;}var baseEach=createBaseEach(baseForOwn);var baseEachRight=createBaseEach(baseForOwnRight,true);function baseEvery(collection,predicate){var result=true;baseEach(collection,function(value,index,collection){result=!!predicate(value,index,collection);return result;});return result;}function baseExtremum(array,iteratee,comparator){var index=-1,length=array.length;while(++index<length){var value=array[index],current=iteratee(value);if(current!=null&&(computed===undefined?current===current&&!isSymbol(current):comparator(current,computed))){var computed=current,result=value;}}return result;}function baseFill(array,value,start,end){var length=array.length;start=toInteger(start);if(start<0){start=-start>length?0:length+start;}end=end===undefined||end>length?length:toInteger(end);if(end<0){end+=length;}end=start>end?0:toLength(end);while(start<end){array[start++]=value;}return array;}function baseFilter(collection,predicate){var result=[];baseEach(collection,function(value,index,collection){if(predicate(value,index,collection)){result.push(value);}});return result;}function baseFlatten(array,depth,predicate,isStrict,result){var index=-1,length=array.length;predicate||(predicate=isFlattenable);result||(result=[]);while(++index<length){var value=array[index];if(depth>0&&predicate(value)){if(depth>1){baseFlatten(value,depth-1,predicate,isStrict,result);}else{arrayPush(result,value);}}else if(!isStrict){result[result.length]=value;}}return result;}var baseFor=createBaseFor();var baseForRight=createBaseFor(true);function baseForOwn(object,iteratee){return object&&baseFor(object,iteratee,keys);}function baseForOwnRight(object,iteratee){return object&&baseForRight(object,iteratee,keys);}function baseFunctions(object,props){return arrayFilter(props,function(key){return isFunction(object[key]);});}function baseGet(object,path){path=castPath(path,object);var index=0,length=path.length;while(object!=null&&index<length){object=object[toKey(path[index++])];}return index&&index==length?object:undefined;}function baseGetAllKeys(object,keysFunc,symbolsFunc){var result=keysFunc(object);return isArray(object)?result:arrayPush(result,symbolsFunc(object));}function baseGetTag(value){if(value==null){return value===undefined?undefinedTag:nullTag;}return symToStringTag&&symToStringTag in Object(value)?getRawTag(value):objectToString(value);}function baseGt(value,other){return value>other;}function baseHas(object,key){return object!=null&&hasOwnProperty.call(object,key);}function baseHasIn(object,key){return object!=null&&key in Object(object);}function baseInRange(number,start,end){return number>=nativeMin(start,end)&&number<nativeMax(start,end);}function baseIntersection(arrays,iteratee,comparator){var includes=comparator?arrayIncludesWith:arrayIncludes,length=arrays[0].length,othLength=arrays.length,othIndex=othLength,caches=Array(othLength),maxLength=Infinity,result=[];while(othIndex--){var array=arrays[othIndex];if(othIndex&&iteratee){array=arrayMap(array,baseUnary(iteratee));}maxLength=nativeMin(array.length,maxLength);caches[othIndex]=!comparator&&(iteratee||length>=120&&array.length>=120)?new SetCache(othIndex&&array):undefined;}array=arrays[0];var index=-1,seen=caches[0];outer:while(++index<length&&result.length<maxLength){var value=array[index],computed=iteratee?iteratee(value):value;value=comparator||value!==0?value:0;if(!(seen?cacheHas(seen,computed):includes(result,computed,comparator))){othIndex=othLength;while(--othIndex){var cache=caches[othIndex];if(!(cache?cacheHas(cache,computed):includes(arrays[othIndex],computed,comparator))){continue outer;}}if(seen){seen.push(computed);}result.push(value);}}return result;}function baseInverter(object,setter,iteratee,accumulator){baseForOwn(object,function(value,key,object){setter(accumulator,iteratee(value),key,object);});return accumulator;}function baseInvoke(object,path,args){path=castPath(path,object);object=parent(object,path);var func=object==null?object:object[toKey(last(path))];return func==null?undefined:apply(func,object,args);}function baseIsArguments(value){return isObjectLike(value)&&baseGetTag(value)==argsTag;}function baseIsArrayBuffer(value){return isObjectLike(value)&&baseGetTag(value)==arrayBufferTag;}function baseIsDate(value){return isObjectLike(value)&&baseGetTag(value)==dateTag;}function baseIsEqual(value,other,bitmask,customizer,stack){if(value===other){return true;}if(value==null||other==null||!isObjectLike(value)&&!isObjectLike(other)){return value!==value&&other!==other;}return baseIsEqualDeep(value,other,bitmask,customizer,baseIsEqual,stack);}function baseIsEqualDeep(object,other,bitmask,customizer,equalFunc,stack){var objIsArr=isArray(object),othIsArr=isArray(other),objTag=objIsArr?arrayTag:getTag(object),othTag=othIsArr?arrayTag:getTag(other);objTag=objTag==argsTag?objectTag:objTag;othTag=othTag==argsTag?objectTag:othTag;var objIsObj=objTag==objectTag,othIsObj=othTag==objectTag,isSameTag=objTag==othTag;if(isSameTag&&isBuffer(object)){if(!isBuffer(other)){return false;}objIsArr=true;objIsObj=false;}if(isSameTag&&!objIsObj){stack||(stack=new Stack());return objIsArr||isTypedArray(object)?equalArrays(object,other,bitmask,customizer,equalFunc,stack):equalByTag(object,other,objTag,bitmask,customizer,equalFunc,stack);}if(!(bitmask&COMPARE_PARTIAL_FLAG)){var objIsWrapped=objIsObj&&hasOwnProperty.call(object,'__wrapped__'),othIsWrapped=othIsObj&&hasOwnProperty.call(other,'__wrapped__');if(objIsWrapped||othIsWrapped){var objUnwrapped=objIsWrapped?object.value():object,othUnwrapped=othIsWrapped?other.value():other;stack||(stack=new Stack());return equalFunc(objUnwrapped,othUnwrapped,bitmask,customizer,stack);}}if(!isSameTag){return false;}stack||(stack=new Stack());return equalObjects(object,other,bitmask,customizer,equalFunc,stack);}function baseIsMap(value){return isObjectLike(value)&&getTag(value)==mapTag;}function baseIsMatch(object,source,matchData,customizer){var index=matchData.length,length=index,noCustomizer=!customizer;if(object==null){return!length;}object=Object(object);while(index--){var data=matchData[index];if(noCustomizer&&data[2]?data[1]!==object[data[0]]:!(data[0]in object)){return false;}}while(++index<length){data=matchData[index];var key=data[0],objValue=object[key],srcValue=data[1];if(noCustomizer&&data[2]){if(objValue===undefined&&!(key in object)){return false;}}else{var stack=new Stack();if(customizer){var result=customizer(objValue,srcValue,key,object,source,stack);}if(!(result===undefined?baseIsEqual(srcValue,objValue,COMPARE_PARTIAL_FLAG|COMPARE_UNORDERED_FLAG,customizer,stack):result)){return false;}}}return true;}function baseIsNative(value){if(!isObject(value)||isMasked(value)){return false;}var pattern=isFunction(value)?reIsNative:reIsHostCtor;return pattern.test(toSource(value));}function baseIsRegExp(value){return isObjectLike(value)&&baseGetTag(value)==regexpTag;}function baseIsSet(value){return isObjectLike(value)&&getTag(value)==setTag;}function baseIsTypedArray(value){return isObjectLike(value)&&isLength(value.length)&&!!typedArrayTags[baseGetTag(value)];}function baseIteratee(value){if(typeof value=='function'){return value;}if(value==null){return identity;}if(typeof value=='object'){return isArray(value)?baseMatchesProperty(value[0],value[1]):baseMatches(value);}return property(value);}function baseKeys(object){if(!isPrototype(object)){return nativeKeys(object);}var result=[];for(var key in Object(object)){if(hasOwnProperty.call(object,key)&&key!='constructor'){result.push(key);}}return result;}function baseKeysIn(object){if(!isObject(object)){return nativeKeysIn(object);}var isProto=isPrototype(object),result=[];for(var key in object){if(!(key=='constructor'&&(isProto||!hasOwnProperty.call(object,key)))){result.push(key);}}return result;}function baseLt(value,other){return value<other;}function baseMap(collection,iteratee){var index=-1,result=isArrayLike(collection)?Array(collection.length):[];baseEach(collection,function(value,key,collection){result[++index]=iteratee(value,key,collection);});return result;}function baseMatches(source){var matchData=getMatchData(source);if(matchData.length==1&&matchData[0][2]){return matchesStrictComparable(matchData[0][0],matchData[0][1]);}return function(object){return object===source||baseIsMatch(object,source,matchData);};}function baseMatchesProperty(path,srcValue){if(isKey(path)&&isStrictComparable(srcValue)){return matchesStrictComparable(toKey(path),srcValue);}return function(object){var objValue=get(object,path);return objValue===undefined&&objValue===srcValue?hasIn(object,path):baseIsEqual(srcValue,objValue,COMPARE_PARTIAL_FLAG|COMPARE_UNORDERED_FLAG);};}function baseMerge(object,source,srcIndex,customizer,stack){if(object===source){return;}baseFor(source,function(srcValue,key){stack||(stack=new Stack());if(isObject(srcValue)){baseMergeDeep(object,source,key,srcIndex,baseMerge,customizer,stack);}else{var newValue=customizer?customizer(safeGet(object,key),srcValue,key+'',object,source,stack):undefined;if(newValue===undefined){newValue=srcValue;}assignMergeValue(object,key,newValue);}},keysIn);}function baseMergeDeep(object,source,key,srcIndex,mergeFunc,customizer,stack){var objValue=safeGet(object,key),srcValue=safeGet(source,key),stacked=stack.get(srcValue);if(stacked){assignMergeValue(object,key,stacked);return;}var newValue=customizer?customizer(objValue,srcValue,key+'',object,source,stack):undefined;var isCommon=newValue===undefined;if(isCommon){var isArr=isArray(srcValue),isBuff=!isArr&&isBuffer(srcValue),isTyped=!isArr&&!isBuff&&isTypedArray(srcValue);newValue=srcValue;if(isArr||isBuff||isTyped){if(isArray(objValue)){newValue=objValue;}else if(isArrayLikeObject(objValue)){newValue=copyArray(objValue);}else if(isBuff){isCommon=false;newValue=cloneBuffer(srcValue,true);}else if(isTyped){isCommon=false;newValue=cloneTypedArray(srcValue,true);}else{newValue=[];}}else if(isPlainObject(srcValue)||isArguments(srcValue)){newValue=objValue;if(isArguments(objValue)){newValue=toPlainObject(objValue);}else if(!isObject(objValue)||isFunction(objValue)){newValue=initCloneObject(srcValue);}}else{isCommon=false;}}if(isCommon){stack.set(srcValue,newValue);mergeFunc(newValue,srcValue,srcIndex,customizer,stack);stack['delete'](srcValue);}assignMergeValue(object,key,newValue);}function baseNth(array,n){var length=array.length;if(!length){return;}n+=n<0?length:0;return isIndex(n,length)?array[n]:undefined;}function baseOrderBy(collection,iteratees,orders){var index=-1;iteratees=arrayMap(iteratees.length?iteratees:[identity],baseUnary(getIteratee()));var result=baseMap(collection,function(value,key,collection){var criteria=arrayMap(iteratees,function(iteratee){return iteratee(value);});return{'criteria':criteria,'index':++index,'value':value};});return baseSortBy(result,function(object,other){return compareMultiple(object,other,orders);});}function basePick(object,paths){return basePickBy(object,paths,function(value,path){return hasIn(object,path);});}function basePickBy(object,paths,predicate){var index=-1,length=paths.length,result={};while(++index<length){var path=paths[index],value=baseGet(object,path);if(predicate(value,path)){baseSet(result,castPath(path,object),value);}}return result;}function basePropertyDeep(path){return function(object){return baseGet(object,path);};}function basePullAll(array,values,iteratee,comparator){var indexOf=comparator?baseIndexOfWith:baseIndexOf,index=-1,length=values.length,seen=array;if(array===values){values=copyArray(values);}if(iteratee){seen=arrayMap(array,baseUnary(iteratee));}while(++index<length){var fromIndex=0,value=values[index],computed=iteratee?iteratee(value):value;while((fromIndex=indexOf(seen,computed,fromIndex,comparator))>-1){if(seen!==array){splice.call(seen,fromIndex,1);}splice.call(array,fromIndex,1);}}return array;}function basePullAt(array,indexes){var length=array?indexes.length:0,lastIndex=length-1;while(length--){var index=indexes[length];if(length==lastIndex||index!==previous){var previous=index;if(isIndex(index)){splice.call(array,index,1);}else{baseUnset(array,index);}}}return array;}function baseRandom(lower,upper){return lower+nativeFloor(nativeRandom()*(upper-lower+1));}function baseRange(start,end,step,fromRight){var index=-1,length=nativeMax(nativeCeil((end-start)/(step||1)),0),result=Array(length);while(length--){result[fromRight?length:++index]=start;start+=step;}return result;}function baseRepeat(string,n){var result='';if(!string||n<1||n>MAX_SAFE_INTEGER){return result;}do{if(n%2){result+=string;}n=nativeFloor(n/2);if(n){string+=string;}}while(n);return result;}function baseRest(func,start){return setToString(overRest(func,start,identity),func+'');}function baseSample(collection){return arraySample(values(collection));}function baseSampleSize(collection,n){var array=values(collection);return shuffleSelf(array,baseClamp(n,0,array.length));}function baseSet(object,path,value,customizer){if(!isObject(object)){return object;}path=castPath(path,object);var index=-1,length=path.length,lastIndex=length-1,nested=object;while(nested!=null&&++index<length){var key=toKey(path[index]),newValue=value;if(index!=lastIndex){var objValue=nested[key];newValue=customizer?customizer(objValue,key,nested):undefined;if(newValue===undefined){newValue=isObject(objValue)?objValue:isIndex(path[index+1])?[]:{};}}assignValue(nested,key,newValue);nested=nested[key];}return object;}var baseSetData=!metaMap?identity:function(func,data){metaMap.set(func,data);return func;};var baseSetToString=!defineProperty?identity:function(func,string){return defineProperty(func,'toString',{'configurable':true,'enumerable':false,'value':constant(string),'writable':true});};function baseShuffle(collection){return shuffleSelf(values(collection));}function baseSlice(array,start,end){var index=-1,length=array.length;if(start<0){start=-start>length?0:length+start;}end=end>length?length:end;if(end<0){end+=length;}length=start>end?0:end-start>>>0;start>>>=0;var result=Array(length);while(++index<length){result[index]=array[index+start];}return result;}function baseSome(collection,predicate){var result;baseEach(collection,function(value,index,collection){result=predicate(value,index,collection);return!result;});return!!result;}function baseSortedIndex(array,value,retHighest){var low=0,high=array==null?low:array.length;if(typeof value=='number'&&value===value&&high<=HALF_MAX_ARRAY_LENGTH){while(low<high){var mid=low+high>>>1,computed=array[mid];if(computed!==null&&!isSymbol(computed)&&(retHighest?computed<=value:computed<value)){low=mid+1;}else{high=mid;}}return high;}return baseSortedIndexBy(array,value,identity,retHighest);}function baseSortedIndexBy(array,value,iteratee,retHighest){value=iteratee(value);var low=0,high=array==null?0:array.length,valIsNaN=value!==value,valIsNull=value===null,valIsSymbol=isSymbol(value),valIsUndefined=value===undefined;while(low<high){var mid=nativeFloor((low+high)/2),computed=iteratee(array[mid]),othIsDefined=computed!==undefined,othIsNull=computed===null,othIsReflexive=computed===computed,othIsSymbol=isSymbol(computed);if(valIsNaN){var setLow=retHighest||othIsReflexive;}else if(valIsUndefined){setLow=othIsReflexive&&(retHighest||othIsDefined);}else if(valIsNull){setLow=othIsReflexive&&othIsDefined&&(retHighest||!othIsNull);}else if(valIsSymbol){setLow=othIsReflexive&&othIsDefined&&!othIsNull&&(retHighest||!othIsSymbol);}else if(othIsNull||othIsSymbol){setLow=false;}else{setLow=retHighest?computed<=value:computed<value;}if(setLow){low=mid+1;}else{high=mid;}}return nativeMin(high,MAX_ARRAY_INDEX);}function baseSortedUniq(array,iteratee){var index=-1,length=array.length,resIndex=0,result=[];while(++index<length){var value=array[index],computed=iteratee?iteratee(value):value;if(!index||!eq(computed,seen)){var seen=computed;result[resIndex++]=value===0?0:value;}}return result;}function baseToNumber(value){if(typeof value=='number'){return value;}if(isSymbol(value)){return NAN;}return+value;}function baseToString(value){if(typeof value=='string'){return value;}if(isArray(value)){return arrayMap(value,baseToString)+'';}if(isSymbol(value)){return symbolToString?symbolToString.call(value):'';}var result=value+'';return result=='0'&&1/value==-INFINITY?'-0':result;}function baseUniq(array,iteratee,comparator){var index=-1,includes=arrayIncludes,length=array.length,isCommon=true,result=[],seen=result;if(comparator){isCommon=false;includes=arrayIncludesWith;}else if(length>=LARGE_ARRAY_SIZE){var set=iteratee?null:createSet(array);if(set){return setToArray(set);}isCommon=false;includes=cacheHas;seen=new SetCache();}else{seen=iteratee?[]:result;}outer:while(++index<length){var value=array[index],computed=iteratee?iteratee(value):value;value=comparator||value!==0?value:0;if(isCommon&&computed===computed){var seenIndex=seen.length;while(seenIndex--){if(seen[seenIndex]===computed){continue outer;}}if(iteratee){seen.push(computed);}result.push(value);}else if(!includes(seen,computed,comparator)){if(seen!==result){seen.push(computed);}result.push(value);}}return result;}function baseUnset(object,path){path=castPath(path,object);object=parent(object,path);return object==null||delete object[toKey(last(path))];}function baseUpdate(object,path,updater,customizer){return baseSet(object,path,updater(baseGet(object,path)),customizer);}function baseWhile(array,predicate,isDrop,fromRight){var length=array.length,index=fromRight?length:-1;while((fromRight?index--:++index<length)&&predicate(array[index],index,array)){}return isDrop?baseSlice(array,fromRight?0:index,fromRight?index+1:length):baseSlice(array,fromRight?index+1:0,fromRight?length:index);}function baseWrapperValue(value,actions){var result=value;if(result instanceof LazyWrapper){result=result.value();}return arrayReduce(actions,function(result,action){return action.func.apply(action.thisArg,arrayPush([result],action.args));},result);}function baseXor(arrays,iteratee,comparator){var length=arrays.length;if(length<2){return length?baseUniq(arrays[0]):[];}var index=-1,result=Array(length);while(++index<length){var array=arrays[index],othIndex=-1;while(++othIndex<length){if(othIndex!=index){result[index]=baseDifference(result[index]||array,arrays[othIndex],iteratee,comparator);}}}return baseUniq(baseFlatten(result,1),iteratee,comparator);}function baseZipObject(props,values,assignFunc){var index=-1,length=props.length,valsLength=values.length,result={};while(++index<length){var value=index<valsLength?values[index]:undefined;assignFunc(result,props[index],value);}return result;}function castArrayLikeObject(value){return isArrayLikeObject(value)?value:[];}function castFunction(value){return typeof value=='function'?value:identity;}function castPath(value,object){if(isArray(value)){return value;}return isKey(value,object)?[value]:stringToPath(toString(value));}var castRest=baseRest;function castSlice(array,start,end){var length=array.length;end=end===undefined?length:end;return!start&&end>=length?array:baseSlice(array,start,end);}var clearTimeout=ctxClearTimeout||function(id){return root.clearTimeout(id);};function cloneBuffer(buffer,isDeep){if(isDeep){return buffer.slice();}var length=buffer.length,result=allocUnsafe?allocUnsafe(length):new buffer.constructor(length);buffer.copy(result);return result;}function cloneArrayBuffer(arrayBuffer){var result=new arrayBuffer.constructor(arrayBuffer.byteLength);new Uint8Array(result).set(new Uint8Array(arrayBuffer));return result;}function cloneDataView(dataView,isDeep){var buffer=isDeep?cloneArrayBuffer(dataView.buffer):dataView.buffer;return new dataView.constructor(buffer,dataView.byteOffset,dataView.byteLength);}function cloneRegExp(regexp){var result=new regexp.constructor(regexp.source,reFlags.exec(regexp));result.lastIndex=regexp.lastIndex;return result;}function cloneSymbol(symbol){return symbolValueOf?Object(symbolValueOf.call(symbol)):{};}function cloneTypedArray(typedArray,isDeep){var buffer=isDeep?cloneArrayBuffer(typedArray.buffer):typedArray.buffer;return new typedArray.constructor(buffer,typedArray.byteOffset,typedArray.length);}function compareAscending(value,other){if(value!==other){var valIsDefined=value!==undefined,valIsNull=value===null,valIsReflexive=value===value,valIsSymbol=isSymbol(value);var othIsDefined=other!==undefined,othIsNull=other===null,othIsReflexive=other===other,othIsSymbol=isSymbol(other);if(!othIsNull&&!othIsSymbol&&!valIsSymbol&&value>other||valIsSymbol&&othIsDefined&&othIsReflexive&&!othIsNull&&!othIsSymbol||valIsNull&&othIsDefined&&othIsReflexive||!valIsDefined&&othIsReflexive||!valIsReflexive){return 1;}if(!valIsNull&&!valIsSymbol&&!othIsSymbol&&value<other||othIsSymbol&&valIsDefined&&valIsReflexive&&!valIsNull&&!valIsSymbol||othIsNull&&valIsDefined&&valIsReflexive||!othIsDefined&&valIsReflexive||!othIsReflexive){return-1;}}return 0;}function compareMultiple(object,other,orders){var index=-1,objCriteria=object.criteria,othCriteria=other.criteria,length=objCriteria.length,ordersLength=orders.length;while(++index<length){var result=compareAscending(objCriteria[index],othCriteria[index]);if(result){if(index>=ordersLength){return result;}var order=orders[index];return result*(order=='desc'?-1:1);}}return object.index-other.index;}function composeArgs(args,partials,holders,isCurried){var argsIndex=-1,argsLength=args.length,holdersLength=holders.length,leftIndex=-1,leftLength=partials.length,rangeLength=nativeMax(argsLength-holdersLength,0),result=Array(leftLength+rangeLength),isUncurried=!isCurried;while(++leftIndex<leftLength){result[leftIndex]=partials[leftIndex];}while(++argsIndex<holdersLength){if(isUncurried||argsIndex<argsLength){result[holders[argsIndex]]=args[argsIndex];}}while(rangeLength--){result[leftIndex++]=args[argsIndex++];}return result;}function composeArgsRight(args,partials,holders,isCurried){var argsIndex=-1,argsLength=args.length,holdersIndex=-1,holdersLength=holders.length,rightIndex=-1,rightLength=partials.length,rangeLength=nativeMax(argsLength-holdersLength,0),result=Array(rangeLength+rightLength),isUncurried=!isCurried;while(++argsIndex<rangeLength){result[argsIndex]=args[argsIndex];}var offset=argsIndex;while(++rightIndex<rightLength){result[offset+rightIndex]=partials[rightIndex];}while(++holdersIndex<holdersLength){if(isUncurried||argsIndex<argsLength){result[offset+holders[holdersIndex]]=args[argsIndex++];}}return result;}function copyArray(source,array){var index=-1,length=source.length;array||(array=Array(length));while(++index<length){array[index]=source[index];}return array;}function copyObject(source,props,object,customizer){var isNew=!object;object||(object={});var index=-1,length=props.length;while(++index<length){var key=props[index];var newValue=customizer?customizer(object[key],source[key],key,object,source):undefined;if(newValue===undefined){newValue=source[key];}if(isNew){baseAssignValue(object,key,newValue);}else{assignValue(object,key,newValue);}}return object;}function copySymbols(source,object){return copyObject(source,getSymbols(source),object);}function copySymbolsIn(source,object){return copyObject(source,getSymbolsIn(source),object);}function createAggregator(setter,initializer){return function(collection,iteratee){var func=isArray(collection)?arrayAggregator:baseAggregator,accumulator=initializer?initializer():{};return func(collection,setter,getIteratee(iteratee,2),accumulator);};}function createAssigner(assigner){return baseRest(function(object,sources){var index=-1,length=sources.length,customizer=length>1?sources[length-1]:undefined,guard=length>2?sources[2]:undefined;customizer=assigner.length>3&&typeof customizer=='function'?(length--,customizer):undefined;if(guard&&isIterateeCall(sources[0],sources[1],guard)){customizer=length<3?undefined:customizer;length=1;}object=Object(object);while(++index<length){var source=sources[index];if(source){assigner(object,source,index,customizer);}}return object;});}function createBaseEach(eachFunc,fromRight){return function(collection,iteratee){if(collection==null){return collection;}if(!isArrayLike(collection)){return eachFunc(collection,iteratee);}var length=collection.length,index=fromRight?length:-1,iterable=Object(collection);while(fromRight?index--:++index<length){if(iteratee(iterable[index],index,iterable)===false){break;}}return collection;};}function createBaseFor(fromRight){return function(object,iteratee,keysFunc){var index=-1,iterable=Object(object),props=keysFunc(object),length=props.length;while(length--){var key=props[fromRight?length:++index];if(iteratee(iterable[key],key,iterable)===false){break;}}return object;};}function createBind(func,bitmask,thisArg){var isBind=bitmask&WRAP_BIND_FLAG,Ctor=createCtor(func);function wrapper(){var fn=this&&this!==root&&this instanceof wrapper?Ctor:func;return fn.apply(isBind?thisArg:this,arguments);}return wrapper;}function createCaseFirst(methodName){return function(string){string=toString(string);var strSymbols=hasUnicode(string)?stringToArray(string):undefined;var chr=strSymbols?strSymbols[0]:string.charAt(0);var trailing=strSymbols?castSlice(strSymbols,1).join(''):string.slice(1);return chr[methodName]()+trailing;};}function createCompounder(callback){return function(string){return arrayReduce(words(deburr(string).replace(reApos,'')),callback,'');};}function createCtor(Ctor){return function(){var args=arguments;switch(args.length){case 0:return new Ctor();case 1:return new Ctor(args[0]);case 2:return new Ctor(args[0],args[1]);case 3:return new Ctor(args[0],args[1],args[2]);case 4:return new Ctor(args[0],args[1],args[2],args[3]);case 5:return new Ctor(args[0],args[1],args[2],args[3],args[4]);case 6:return new Ctor(args[0],args[1],args[2],args[3],args[4],args[5]);case 7:return new Ctor(args[0],args[1],args[2],args[3],args[4],args[5],args[6]);}var thisBinding=baseCreate(Ctor.prototype),result=Ctor.apply(thisBinding,args);return isObject(result)?result:thisBinding;};}function createCurry(func,bitmask,arity){var Ctor=createCtor(func);function wrapper(){var length=arguments.length,args=Array(length),index=length,placeholder=getHolder(wrapper);while(index--){args[index]=arguments[index];}var holders=length<3&&args[0]!==placeholder&&args[length-1]!==placeholder?[]:replaceHolders(args,placeholder);length-=holders.length;if(length<arity){return createRecurry(func,bitmask,createHybrid,wrapper.placeholder,undefined,args,holders,undefined,undefined,arity-length);}var fn=this&&this!==root&&this instanceof wrapper?Ctor:func;return apply(fn,this,args);}return wrapper;}function createFind(findIndexFunc){return function(collection,predicate,fromIndex){var iterable=Object(collection);if(!isArrayLike(collection)){var iteratee=getIteratee(predicate,3);collection=keys(collection);predicate=function(key){return iteratee(iterable[key],key,iterable);};}var index=findIndexFunc(collection,predicate,fromIndex);return index>-1?iterable[iteratee?collection[index]:index]:undefined;};}function createFlow(fromRight){return flatRest(function(funcs){var length=funcs.length,index=length,prereq=LodashWrapper.prototype.thru;if(fromRight){funcs.reverse();}while(index--){var func=funcs[index];if(typeof func!='function'){throw new TypeError(FUNC_ERROR_TEXT);}if(prereq&&!wrapper&&getFuncName(func)=='wrapper'){var wrapper=new LodashWrapper([],true);}}index=wrapper?index:length;while(++index<length){func=funcs[index];var funcName=getFuncName(func),data=funcName=='wrapper'?getData(func):undefined;if(data&&isLaziable(data[0])&&data[1]==(WRAP_ARY_FLAG|WRAP_CURRY_FLAG|WRAP_PARTIAL_FLAG|WRAP_REARG_FLAG)&&!data[4].length&&data[9]==1){wrapper=wrapper[getFuncName(data[0])].apply(wrapper,data[3]);}else{wrapper=func.length==1&&isLaziable(func)?wrapper[funcName]():wrapper.thru(func);}}return function(){var args=arguments,value=args[0];if(wrapper&&args.length==1&&isArray(value)){return wrapper.plant(value).value();}var index=0,result=length?funcs[index].apply(this,args):value;while(++index<length){result=funcs[index].call(this,result);}return result;};});}function createHybrid(func,bitmask,thisArg,partials,holders,partialsRight,holdersRight,argPos,ary,arity){var isAry=bitmask&WRAP_ARY_FLAG,isBind=bitmask&WRAP_BIND_FLAG,isBindKey=bitmask&WRAP_BIND_KEY_FLAG,isCurried=bitmask&(WRAP_CURRY_FLAG|WRAP_CURRY_RIGHT_FLAG),isFlip=bitmask&WRAP_FLIP_FLAG,Ctor=isBindKey?undefined:createCtor(func);function wrapper(){var length=arguments.length,args=Array(length),index=length;while(index--){args[index]=arguments[index];}if(isCurried){var placeholder=getHolder(wrapper),holdersCount=countHolders(args,placeholder);}if(partials){args=composeArgs(args,partials,holders,isCurried);}if(partialsRight){args=composeArgsRight(args,partialsRight,holdersRight,isCurried);}length-=holdersCount;if(isCurried&&length<arity){var newHolders=replaceHolders(args,placeholder);return createRecurry(func,bitmask,createHybrid,wrapper.placeholder,thisArg,args,newHolders,argPos,ary,arity-length);}var thisBinding=isBind?thisArg:this,fn=isBindKey?thisBinding[func]:func;length=args.length;if(argPos){args=reorder(args,argPos);}else if(isFlip&&length>1){args.reverse();}if(isAry&&ary<length){args.length=ary;}if(this&&this!==root&&this instanceof wrapper){fn=Ctor||createCtor(fn);}return fn.apply(thisBinding,args);}return wrapper;}function createInverter(setter,toIteratee){return function(object,iteratee){return baseInverter(object,setter,toIteratee(iteratee),{});};}function createMathOperation(operator,defaultValue){return function(value,other){var result;if(value===undefined&&other===undefined){return defaultValue;}if(value!==undefined){result=value;}if(other!==undefined){if(result===undefined){return other;}if(typeof value=='string'||typeof other=='string'){value=baseToString(value);other=baseToString(other);}else{value=baseToNumber(value);other=baseToNumber(other);}result=operator(value,other);}return result;};}function createOver(arrayFunc){return flatRest(function(iteratees){iteratees=arrayMap(iteratees,baseUnary(getIteratee()));return baseRest(function(args){var thisArg=this;return arrayFunc(iteratees,function(iteratee){return apply(iteratee,thisArg,args);});});});}function createPadding(length,chars){chars=chars===undefined?' ':baseToString(chars);var charsLength=chars.length;if(charsLength<2){return charsLength?baseRepeat(chars,length):chars;}var result=baseRepeat(chars,nativeCeil(length/stringSize(chars)));return hasUnicode(chars)?castSlice(stringToArray(result),0,length).join(''):result.slice(0,length);}function createPartial(func,bitmask,thisArg,partials){var isBind=bitmask&WRAP_BIND_FLAG,Ctor=createCtor(func);function wrapper(){var argsIndex=-1,argsLength=arguments.length,leftIndex=-1,leftLength=partials.length,args=Array(leftLength+argsLength),fn=this&&this!==root&&this instanceof wrapper?Ctor:func;while(++leftIndex<leftLength){args[leftIndex]=partials[leftIndex];}while(argsLength--){args[leftIndex++]=arguments[++argsIndex];}return apply(fn,isBind?thisArg:this,args);}return wrapper;}function createRange(fromRight){return function(start,end,step){if(step&&typeof step!='number'&&isIterateeCall(start,end,step)){end=step=undefined;}start=toFinite(start);if(end===undefined){end=start;start=0;}else{end=toFinite(end);}step=step===undefined?start<end?1:-1:toFinite(step);return baseRange(start,end,step,fromRight);};}function createRelationalOperation(operator){return function(value,other){if(!(typeof value=='string'&&typeof other=='string')){value=toNumber(value);other=toNumber(other);}return operator(value,other);};}function createRecurry(func,bitmask,wrapFunc,placeholder,thisArg,partials,holders,argPos,ary,arity){var isCurry=bitmask&WRAP_CURRY_FLAG,newHolders=isCurry?holders:undefined,newHoldersRight=isCurry?undefined:holders,newPartials=isCurry?partials:undefined,newPartialsRight=isCurry?undefined:partials;bitmask|=isCurry?WRAP_PARTIAL_FLAG:WRAP_PARTIAL_RIGHT_FLAG;bitmask&=~(isCurry?WRAP_PARTIAL_RIGHT_FLAG:WRAP_PARTIAL_FLAG);if(!(bitmask&WRAP_CURRY_BOUND_FLAG)){bitmask&=~(WRAP_BIND_FLAG|WRAP_BIND_KEY_FLAG);}var newData=[func,bitmask,thisArg,newPartials,newHolders,newPartialsRight,newHoldersRight,argPos,ary,arity];var result=wrapFunc.apply(undefined,newData);if(isLaziable(func)){setData(result,newData);}result.placeholder=placeholder;return setWrapToString(result,func,bitmask);}function createRound(methodName){var func=Math[methodName];return function(number,precision){number=toNumber(number);precision=precision==null?0:nativeMin(toInteger(precision),292);if(precision&&nativeIsFinite(number)){var pair=(toString(number)+'e').split('e'),value=func(pair[0]+'e'+(+pair[1]+precision));pair=(toString(value)+'e').split('e');return+(pair[0]+'e'+(+pair[1]-precision));}return func(number);};}var createSet=!(Set&&1/setToArray(new Set([,-0]))[1]==INFINITY)?noop:function(values){return new Set(values);};function createToPairs(keysFunc){return function(object){var tag=getTag(object);if(tag==mapTag){return mapToArray(object);}if(tag==setTag){return setToPairs(object);}return baseToPairs(object,keysFunc(object));};}function createWrap(func,bitmask,thisArg,partials,holders,argPos,ary,arity){var isBindKey=bitmask&WRAP_BIND_KEY_FLAG;if(!isBindKey&&typeof func!='function'){throw new TypeError(FUNC_ERROR_TEXT);}var length=partials?partials.length:0;if(!length){bitmask&=~(WRAP_PARTIAL_FLAG|WRAP_PARTIAL_RIGHT_FLAG);partials=holders=undefined;}ary=ary===undefined?ary:nativeMax(toInteger(ary),0);arity=arity===undefined?arity:toInteger(arity);length-=holders?holders.length:0;if(bitmask&WRAP_PARTIAL_RIGHT_FLAG){var partialsRight=partials,holdersRight=holders;partials=holders=undefined;}var data=isBindKey?undefined:getData(func);var newData=[func,bitmask,thisArg,partials,holders,partialsRight,holdersRight,argPos,ary,arity];if(data){mergeData(newData,data);}func=newData[0];bitmask=newData[1];thisArg=newData[2];partials=newData[3];holders=newData[4];arity=newData[9]=newData[9]===undefined?isBindKey?0:func.length:nativeMax(newData[9]-length,0);if(!arity&&bitmask&(WRAP_CURRY_FLAG|WRAP_CURRY_RIGHT_FLAG)){bitmask&=~(WRAP_CURRY_FLAG|WRAP_CURRY_RIGHT_FLAG);}if(!bitmask||bitmask==WRAP_BIND_FLAG){var result=createBind(func,bitmask,thisArg);}else if(bitmask==WRAP_CURRY_FLAG||bitmask==WRAP_CURRY_RIGHT_FLAG){result=createCurry(func,bitmask,arity);}else if((bitmask==WRAP_PARTIAL_FLAG||bitmask==(WRAP_BIND_FLAG|WRAP_PARTIAL_FLAG))&&!holders.length){result=createPartial(func,bitmask,thisArg,partials);}else{result=createHybrid.apply(undefined,newData);}var setter=data?baseSetData:setData;return setWrapToString(setter(result,newData),func,bitmask);}function customDefaultsAssignIn(objValue,srcValue,key,object){if(objValue===undefined||eq(objValue,objectProto[key])&&!hasOwnProperty.call(object,key)){return srcValue;}return objValue;}function customDefaultsMerge(objValue,srcValue,key,object,source,stack){if(isObject(objValue)&&isObject(srcValue)){stack.set(srcValue,objValue);baseMerge(objValue,srcValue,undefined,customDefaultsMerge,stack);stack['delete'](srcValue);}return objValue;}function customOmitClone(value){return isPlainObject(value)?undefined:value;}function equalArrays(array,other,bitmask,customizer,equalFunc,stack){var isPartial=bitmask&COMPARE_PARTIAL_FLAG,arrLength=array.length,othLength=other.length;if(arrLength!=othLength&&!(isPartial&&othLength>arrLength)){return false;}var stacked=stack.get(array);if(stacked&&stack.get(other)){return stacked==other;}var index=-1,result=true,seen=bitmask&COMPARE_UNORDERED_FLAG?new SetCache():undefined;stack.set(array,other);stack.set(other,array);while(++index<arrLength){var arrValue=array[index],othValue=other[index];if(customizer){var compared=isPartial?customizer(othValue,arrValue,index,other,array,stack):customizer(arrValue,othValue,index,array,other,stack);}if(compared!==undefined){if(compared){continue;}result=false;break;}if(seen){if(!arraySome(other,function(othValue,othIndex){if(!cacheHas(seen,othIndex)&&(arrValue===othValue||equalFunc(arrValue,othValue,bitmask,customizer,stack))){return seen.push(othIndex);}})){result=false;break;}}else if(!(arrValue===othValue||equalFunc(arrValue,othValue,bitmask,customizer,stack))){result=false;break;}}stack['delete'](array);stack['delete'](other);return result;}function equalByTag(object,other,tag,bitmask,customizer,equalFunc,stack){switch(tag){case dataViewTag:if(object.byteLength!=other.byteLength||object.byteOffset!=other.byteOffset){return false;}object=object.buffer;other=other.buffer;case arrayBufferTag:if(object.byteLength!=other.byteLength||!equalFunc(new Uint8Array(object),new Uint8Array(other))){return false;}return true;case boolTag:case dateTag:case numberTag:return eq(+object,+other);case errorTag:return object.name==other.name&&object.message==other.message;case regexpTag:case stringTag:return object==other+'';case mapTag:var convert=mapToArray;case setTag:var isPartial=bitmask&COMPARE_PARTIAL_FLAG;convert||(convert=setToArray);if(object.size!=other.size&&!isPartial){return false;}var stacked=stack.get(object);if(stacked){return stacked==other;}bitmask|=COMPARE_UNORDERED_FLAG;stack.set(object,other);var result=equalArrays(convert(object),convert(other),bitmask,customizer,equalFunc,stack);stack['delete'](object);return result;case symbolTag:if(symbolValueOf){return symbolValueOf.call(object)==symbolValueOf.call(other);}}return false;}function equalObjects(object,other,bitmask,customizer,equalFunc,stack){var isPartial=bitmask&COMPARE_PARTIAL_FLAG,objProps=getAllKeys(object),objLength=objProps.length,othProps=getAllKeys(other),othLength=othProps.length;if(objLength!=othLength&&!isPartial){return false;}var index=objLength;while(index--){var key=objProps[index];if(!(isPartial?key in other:hasOwnProperty.call(other,key))){return false;}}var stacked=stack.get(object);if(stacked&&stack.get(other)){return stacked==other;}var result=true;stack.set(object,other);stack.set(other,object);var skipCtor=isPartial;while(++index<objLength){key=objProps[index];var objValue=object[key],othValue=other[key];if(customizer){var compared=isPartial?customizer(othValue,objValue,key,other,object,stack):customizer(objValue,othValue,key,object,other,stack);}if(!(compared===undefined?objValue===othValue||equalFunc(objValue,othValue,bitmask,customizer,stack):compared)){result=false;break;}skipCtor||(skipCtor=key=='constructor');}if(result&&!skipCtor){var objCtor=object.constructor,othCtor=other.constructor;if(objCtor!=othCtor&&'constructor'in object&&'constructor'in other&&!(typeof objCtor=='function'&&objCtor instanceof objCtor&&typeof othCtor=='function'&&othCtor instanceof othCtor)){result=false;}}stack['delete'](object);stack['delete'](other);return result;}function flatRest(func){return setToString(overRest(func,undefined,flatten),func+'');}function getAllKeys(object){return baseGetAllKeys(object,keys,getSymbols);}function getAllKeysIn(object){return baseGetAllKeys(object,keysIn,getSymbolsIn);}var getData=!metaMap?noop:function(func){return metaMap.get(func);};function getFuncName(func){var result=func.name+'',array=realNames[result],length=hasOwnProperty.call(realNames,result)?array.length:0;while(length--){var data=array[length],otherFunc=data.func;if(otherFunc==null||otherFunc==func){return data.name;}}return result;}function getHolder(func){var object=hasOwnProperty.call(lodash,'placeholder')?lodash:func;return object.placeholder;}function getIteratee(){var result=lodash.iteratee||iteratee;result=result===iteratee?baseIteratee:result;return arguments.length?result(arguments[0],arguments[1]):result;}function getMapData(map,key){var data=map.__data__;return isKeyable(key)?data[typeof key=='string'?'string':'hash']:data.map;}function getMatchData(object){var result=keys(object),length=result.length;while(length--){var key=result[length],value=object[key];result[length]=[key,value,isStrictComparable(value)];}return result;}function getNative(object,key){var value=getValue(object,key);return baseIsNative(value)?value:undefined;}function getRawTag(value){var isOwn=hasOwnProperty.call(value,symToStringTag),tag=value[symToStringTag];try{value[symToStringTag]=undefined;var unmasked=true;}catch(e){}var result=nativeObjectToString.call(value);if(unmasked){if(isOwn){value[symToStringTag]=tag;}else{delete value[symToStringTag];}}return result;}var getSymbols=!nativeGetSymbols?stubArray:function(object){if(object==null){return[];}object=Object(object);return arrayFilter(nativeGetSymbols(object),function(symbol){return propertyIsEnumerable.call(object,symbol);});};var getSymbolsIn=!nativeGetSymbols?stubArray:function(object){var result=[];while(object){arrayPush(result,getSymbols(object));object=getPrototype(object);}return result;};var getTag=baseGetTag;if(DataView&&getTag(new DataView(new ArrayBuffer(1)))!=dataViewTag||Map&&getTag(new Map())!=mapTag||Promise&&getTag(Promise.resolve())!=promiseTag||Set&&getTag(new Set())!=setTag||WeakMap&&getTag(new WeakMap())!=weakMapTag){getTag=function(value){var result=baseGetTag(value),Ctor=result==objectTag?value.constructor:undefined,ctorString=Ctor?toSource(Ctor):'';if(ctorString){switch(ctorString){case dataViewCtorString:return dataViewTag;case mapCtorString:return mapTag;case promiseCtorString:return promiseTag;case setCtorString:return setTag;case weakMapCtorString:return weakMapTag;}}return result;};}function getView(start,end,transforms){var index=-1,length=transforms.length;while(++index<length){var data=transforms[index],size=data.size;switch(data.type){case'drop':start+=size;break;case'dropRight':end-=size;break;case'take':end=nativeMin(end,start+size);break;case'takeRight':start=nativeMax(start,end-size);break;}}return{'start':start,'end':end};}function getWrapDetails(source){var match=source.match(reWrapDetails);return match?match[1].split(reSplitDetails):[];}function hasPath(object,path,hasFunc){path=castPath(path,object);var index=-1,length=path.length,result=false;while(++index<length){var key=toKey(path[index]);if(!(result=object!=null&&hasFunc(object,key))){break;}object=object[key];}if(result||++index!=length){return result;}length=object==null?0:object.length;return!!length&&isLength(length)&&isIndex(key,length)&&(isArray(object)||isArguments(object));}function initCloneArray(array){var length=array.length,result=new array.constructor(length);if(length&&typeof array[0]=='string'&&hasOwnProperty.call(array,'index')){result.index=array.index;result.input=array.input;}return result;}function initCloneObject(object){return typeof object.constructor=='function'&&!isPrototype(object)?baseCreate(getPrototype(object)):{};}function initCloneByTag(object,tag,isDeep){var Ctor=object.constructor;switch(tag){case arrayBufferTag:return cloneArrayBuffer(object);case boolTag:case dateTag:return new Ctor(+object);case dataViewTag:return cloneDataView(object,isDeep);case float32Tag:case float64Tag:case int8Tag:case int16Tag:case int32Tag:case uint8Tag:case uint8ClampedTag:case uint16Tag:case uint32Tag:return cloneTypedArray(object,isDeep);case mapTag:return new Ctor();case numberTag:case stringTag:return new Ctor(object);case regexpTag:return cloneRegExp(object);case setTag:return new Ctor();case symbolTag:return cloneSymbol(object);}}function insertWrapDetails(source,details){var length=details.length;if(!length){return source;}var lastIndex=length-1;details[lastIndex]=(length>1?'& ':'')+details[lastIndex];details=details.join(length>2?', ':' ');return source.replace(reWrapComment,'{\n/* [wrapped with '+details+'] */\n');}function isFlattenable(value){return isArray(value)||isArguments(value)||!!(spreadableSymbol&&value&&value[spreadableSymbol]);}function isIndex(value,length){var type=typeof value;length=length==null?MAX_SAFE_INTEGER:length;return!!length&&(type=='number'||type!='symbol'&&reIsUint.test(value))&&value>-1&&value%1==0&&value<length;}function isIterateeCall(value,index,object){if(!isObject(object)){return false;}var type=typeof index;if(type=='number'?isArrayLike(object)&&isIndex(index,object.length):type=='string'&&index in object){return eq(object[index],value);}return false;}function isKey(value,object){if(isArray(value)){return false;}var type=typeof value;if(type=='number'||type=='symbol'||type=='boolean'||value==null||isSymbol(value)){return true;}return reIsPlainProp.test(value)||!reIsDeepProp.test(value)||object!=null&&value in Object(object);}function isKeyable(value){var type=typeof value;return type=='string'||type=='number'||type=='symbol'||type=='boolean'?value!=='__proto__':value===null;}function isLaziable(func){var funcName=getFuncName(func),other=lodash[funcName];if(typeof other!='function'||!(funcName in LazyWrapper.prototype)){return false;}if(func===other){return true;}var data=getData(other);return!!data&&func===data[0];}function isMasked(func){return!!maskSrcKey&&maskSrcKey in func;}var isMaskable=coreJsData?isFunction:stubFalse;function isPrototype(value){var Ctor=value&&value.constructor,proto=typeof Ctor=='function'&&Ctor.prototype||objectProto;return value===proto;}function isStrictComparable(value){return value===value&&!isObject(value);}function matchesStrictComparable(key,srcValue){return function(object){if(object==null){return false;}return object[key]===srcValue&&(srcValue!==undefined||key in Object(object));};}function memoizeCapped(func){var result=memoize(func,function(key){if(cache.size===MAX_MEMOIZE_SIZE){cache.clear();}return key;});var cache=result.cache;return result;}function mergeData(data,source){var bitmask=data[1],srcBitmask=source[1],newBitmask=bitmask|srcBitmask,isCommon=newBitmask<(WRAP_BIND_FLAG|WRAP_BIND_KEY_FLAG|WRAP_ARY_FLAG);var isCombo=srcBitmask==WRAP_ARY_FLAG&&bitmask==WRAP_CURRY_FLAG||srcBitmask==WRAP_ARY_FLAG&&bitmask==WRAP_REARG_FLAG&&data[7].length<=source[8]||srcBitmask==(WRAP_ARY_FLAG|WRAP_REARG_FLAG)&&source[7].length<=source[8]&&bitmask==WRAP_CURRY_FLAG;if(!(isCommon||isCombo)){return data;}if(srcBitmask&WRAP_BIND_FLAG){data[2]=source[2];newBitmask|=bitmask&WRAP_BIND_FLAG?0:WRAP_CURRY_BOUND_FLAG;}var value=source[3];if(value){var partials=data[3];data[3]=partials?composeArgs(partials,value,source[4]):value;data[4]=partials?replaceHolders(data[3],PLACEHOLDER):source[4];}value=source[5];if(value){partials=data[5];data[5]=partials?composeArgsRight(partials,value,source[6]):value;data[6]=partials?replaceHolders(data[5],PLACEHOLDER):source[6];}value=source[7];if(value){data[7]=value;}if(srcBitmask&WRAP_ARY_FLAG){data[8]=data[8]==null?source[8]:nativeMin(data[8],source[8]);}if(data[9]==null){data[9]=source[9];}data[0]=source[0];data[1]=newBitmask;return data;}function nativeKeysIn(object){var result=[];if(object!=null){for(var key in Object(object)){result.push(key);}}return result;}function objectToString(value){return nativeObjectToString.call(value);}function overRest(func,start,transform){start=nativeMax(start===undefined?func.length-1:start,0);return function(){var args=arguments,index=-1,length=nativeMax(args.length-start,0),array=Array(length);while(++index<length){array[index]=args[start+index];}index=-1;var otherArgs=Array(start+1);while(++index<start){otherArgs[index]=args[index];}otherArgs[start]=transform(array);return apply(func,this,otherArgs);};}function parent(object,path){return path.length<2?object:baseGet(object,baseSlice(path,0,-1));}function reorder(array,indexes){var arrLength=array.length,length=nativeMin(indexes.length,arrLength),oldArray=copyArray(array);while(length--){var index=indexes[length];array[length]=isIndex(index,arrLength)?oldArray[index]:undefined;}return array;}function safeGet(object,key){if(key==='constructor'&&typeof object[key]==='function'){return;}if(key=='__proto__'){return;}return object[key];}var setData=shortOut(baseSetData);var setTimeout=ctxSetTimeout||function(func,wait){return root.setTimeout(func,wait);};var setToString=shortOut(baseSetToString);function setWrapToString(wrapper,reference,bitmask){var source=reference+'';return setToString(wrapper,insertWrapDetails(source,updateWrapDetails(getWrapDetails(source),bitmask)));}function shortOut(func){var count=0,lastCalled=0;return function(){var stamp=nativeNow(),remaining=HOT_SPAN-(stamp-lastCalled);lastCalled=stamp;if(remaining>0){if(++count>=HOT_COUNT){return arguments[0];}}else{count=0;}return func.apply(undefined,arguments);};}function shuffleSelf(array,size){var index=-1,length=array.length,lastIndex=length-1;size=size===undefined?length:size;while(++index<size){var rand=baseRandom(index,lastIndex),value=array[rand];array[rand]=array[index];array[index]=value;}array.length=size;return array;}var stringToPath=memoizeCapped(function(string){var result=[];if(string.charCodeAt(0)===46){result.push('');}string.replace(rePropName,function(match,number,quote,subString){result.push(quote?subString.replace(reEscapeChar,'$1'):number||match);});return result;});function toKey(value){if(typeof value=='string'||isSymbol(value)){return value;}var result=value+'';return result=='0'&&1/value==-INFINITY?'-0':result;}function toSource(func){if(func!=null){try{return funcToString.call(func);}catch(e){}try{return func+'';}catch(e){}}return'';}function updateWrapDetails(details,bitmask){arrayEach(wrapFlags,function(pair){var value='_.'+pair[0];if(bitmask&pair[1]&&!arrayIncludes(details,value)){details.push(value);}});return details.sort();}function wrapperClone(wrapper){if(wrapper instanceof LazyWrapper){return wrapper.clone();}var result=new LodashWrapper(wrapper.__wrapped__,wrapper.__chain__);result.__actions__=copyArray(wrapper.__actions__);result.__index__=wrapper.__index__;result.__values__=wrapper.__values__;return result;}function chunk(array,size,guard){if(guard?isIterateeCall(array,size,guard):size===undefined){size=1;}else{size=nativeMax(toInteger(size),0);}var length=array==null?0:array.length;if(!length||size<1){return[];}var index=0,resIndex=0,result=Array(nativeCeil(length/size));while(index<length){result[resIndex++]=baseSlice(array,index,index+=size);}return result;}function compact(array){var index=-1,length=array==null?0:array.length,resIndex=0,result=[];while(++index<length){var value=array[index];if(value){result[resIndex++]=value;}}return result;}function concat(){var length=arguments.length;if(!length){return[];}var args=Array(length-1),array=arguments[0],index=length;while(index--){args[index-1]=arguments[index];}return arrayPush(isArray(array)?copyArray(array):[array],baseFlatten(args,1));}var difference=baseRest(function(array,values){return isArrayLikeObject(array)?baseDifference(array,baseFlatten(values,1,isArrayLikeObject,true)):[];});var differenceBy=baseRest(function(array,values){var iteratee=last(values);if(isArrayLikeObject(iteratee)){iteratee=undefined;}return isArrayLikeObject(array)?baseDifference(array,baseFlatten(values,1,isArrayLikeObject,true),getIteratee(iteratee,2)):[];});var differenceWith=baseRest(function(array,values){var comparator=last(values);if(isArrayLikeObject(comparator)){comparator=undefined;}return isArrayLikeObject(array)?baseDifference(array,baseFlatten(values,1,isArrayLikeObject,true),undefined,comparator):[];});function drop(array,n,guard){var length=array==null?0:array.length;if(!length){return[];}n=guard||n===undefined?1:toInteger(n);return baseSlice(array,n<0?0:n,length);}function dropRight(array,n,guard){var length=array==null?0:array.length;if(!length){return[];}n=guard||n===undefined?1:toInteger(n);n=length-n;return baseSlice(array,0,n<0?0:n);}function dropRightWhile(array,predicate){return array&&array.length?baseWhile(array,getIteratee(predicate,3),true,true):[];}function dropWhile(array,predicate){return array&&array.length?baseWhile(array,getIteratee(predicate,3),true):[];}function fill(array,value,start,end){var length=array==null?0:array.length;if(!length){return[];}if(start&&typeof start!='number'&&isIterateeCall(array,value,start)){start=0;end=length;}return baseFill(array,value,start,end);}function findIndex(array,predicate,fromIndex){var length=array==null?0:array.length;if(!length){return-1;}var index=fromIndex==null?0:toInteger(fromIndex);if(index<0){index=nativeMax(length+index,0);}return baseFindIndex(array,getIteratee(predicate,3),index);}function findLastIndex(array,predicate,fromIndex){var length=array==null?0:array.length;if(!length){return-1;}var index=length-1;if(fromIndex!==undefined){index=toInteger(fromIndex);index=fromIndex<0?nativeMax(length+index,0):nativeMin(index,length-1);}return baseFindIndex(array,getIteratee(predicate,3),index,true);}function flatten(array){var length=array==null?0:array.length;return length?baseFlatten(array,1):[];}function flattenDeep(array){var length=array==null?0:array.length;return length?baseFlatten(array,INFINITY):[];}function flattenDepth(array,depth){var length=array==null?0:array.length;if(!length){return[];}depth=depth===undefined?1:toInteger(depth);return baseFlatten(array,depth);}function fromPairs(pairs){var index=-1,length=pairs==null?0:pairs.length,result={};while(++index<length){var pair=pairs[index];result[pair[0]]=pair[1];}return result;}function head(array){return array&&array.length?array[0]:undefined;}function indexOf(array,value,fromIndex){var length=array==null?0:array.length;if(!length){return-1;}var index=fromIndex==null?0:toInteger(fromIndex);if(index<0){index=nativeMax(length+index,0);}return baseIndexOf(array,value,index);}function initial(array){var length=array==null?0:array.length;return length?baseSlice(array,0,-1):[];}var intersection=baseRest(function(arrays){var mapped=arrayMap(arrays,castArrayLikeObject);return mapped.length&&mapped[0]===arrays[0]?baseIntersection(mapped):[];});var intersectionBy=baseRest(function(arrays){var iteratee=last(arrays),mapped=arrayMap(arrays,castArrayLikeObject);if(iteratee===last(mapped)){iteratee=undefined;}else{mapped.pop();}return mapped.length&&mapped[0]===arrays[0]?baseIntersection(mapped,getIteratee(iteratee,2)):[];});var intersectionWith=baseRest(function(arrays){var comparator=last(arrays),mapped=arrayMap(arrays,castArrayLikeObject);comparator=typeof comparator=='function'?comparator:undefined;if(comparator){mapped.pop();}return mapped.length&&mapped[0]===arrays[0]?baseIntersection(mapped,undefined,comparator):[];});function join(array,separator){return array==null?'':nativeJoin.call(array,separator);}function last(array){var length=array==null?0:array.length;return length?array[length-1]:undefined;}function lastIndexOf(array,value,fromIndex){var length=array==null?0:array.length;if(!length){return-1;}var index=length;if(fromIndex!==undefined){index=toInteger(fromIndex);index=index<0?nativeMax(length+index,0):nativeMin(index,length-1);}return value===value?strictLastIndexOf(array,value,index):baseFindIndex(array,baseIsNaN,index,true);}function nth(array,n){return array&&array.length?baseNth(array,toInteger(n)):undefined;}var pull=baseRest(pullAll);function pullAll(array,values){return array&&array.length&&values&&values.length?basePullAll(array,values):array;}function pullAllBy(array,values,iteratee){return array&&array.length&&values&&values.length?basePullAll(array,values,getIteratee(iteratee,2)):array;}function pullAllWith(array,values,comparator){return array&&array.length&&values&&values.length?basePullAll(array,values,undefined,comparator):array;}var pullAt=flatRest(function(array,indexes){var length=array==null?0:array.length,result=baseAt(array,indexes);basePullAt(array,arrayMap(indexes,function(index){return isIndex(index,length)?+index:index;}).sort(compareAscending));return result;});function remove(array,predicate){var result=[];if(!(array&&array.length)){return result;}var index=-1,indexes=[],length=array.length;predicate=getIteratee(predicate,3);while(++index<length){var value=array[index];if(predicate(value,index,array)){result.push(value);indexes.push(index);}}basePullAt(array,indexes);return result;}function reverse(array){return array==null?array:nativeReverse.call(array);}function slice(array,start,end){var length=array==null?0:array.length;if(!length){return[];}if(end&&typeof end!='number'&&isIterateeCall(array,start,end)){start=0;end=length;}else{start=start==null?0:toInteger(start);end=end===undefined?length:toInteger(end);}return baseSlice(array,start,end);}function sortedIndex(array,value){return baseSortedIndex(array,value);}function sortedIndexBy(array,value,iteratee){return baseSortedIndexBy(array,value,getIteratee(iteratee,2));}function sortedIndexOf(array,value){var length=array==null?0:array.length;if(length){var index=baseSortedIndex(array,value);if(index<length&&eq(array[index],value)){return index;}}return-1;}function sortedLastIndex(array,value){return baseSortedIndex(array,value,true);}function sortedLastIndexBy(array,value,iteratee){return baseSortedIndexBy(array,value,getIteratee(iteratee,2),true);}function sortedLastIndexOf(array,value){var length=array==null?0:array.length;if(length){var index=baseSortedIndex(array,value,true)-1;if(eq(array[index],value)){return index;}}return-1;}function sortedUniq(array){return array&&array.length?baseSortedUniq(array):[];}function sortedUniqBy(array,iteratee){return array&&array.length?baseSortedUniq(array,getIteratee(iteratee,2)):[];}function tail(array){var length=array==null?0:array.length;return length?baseSlice(array,1,length):[];}function take(array,n,guard){if(!(array&&array.length)){return[];}n=guard||n===undefined?1:toInteger(n);return baseSlice(array,0,n<0?0:n);}function takeRight(array,n,guard){var length=array==null?0:array.length;if(!length){return[];}n=guard||n===undefined?1:toInteger(n);n=length-n;return baseSlice(array,n<0?0:n,length);}function takeRightWhile(array,predicate){return array&&array.length?baseWhile(array,getIteratee(predicate,3),false,true):[];}function takeWhile(array,predicate){return array&&array.length?baseWhile(array,getIteratee(predicate,3)):[];}var union=baseRest(function(arrays){return baseUniq(baseFlatten(arrays,1,isArrayLikeObject,true));});var unionBy=baseRest(function(arrays){var iteratee=last(arrays);if(isArrayLikeObject(iteratee)){iteratee=undefined;}return baseUniq(baseFlatten(arrays,1,isArrayLikeObject,true),getIteratee(iteratee,2));});var unionWith=baseRest(function(arrays){var comparator=last(arrays);comparator=typeof comparator=='function'?comparator:undefined;return baseUniq(baseFlatten(arrays,1,isArrayLikeObject,true),undefined,comparator);});function uniq(array){return array&&array.length?baseUniq(array):[];}function uniqBy(array,iteratee){return array&&array.length?baseUniq(array,getIteratee(iteratee,2)):[];}function uniqWith(array,comparator){comparator=typeof comparator=='function'?comparator:undefined;return array&&array.length?baseUniq(array,undefined,comparator):[];}function unzip(array){if(!(array&&array.length)){return[];}var length=0;array=arrayFilter(array,function(group){if(isArrayLikeObject(group)){length=nativeMax(group.length,length);return true;}});return baseTimes(length,function(index){return arrayMap(array,baseProperty(index));});}function unzipWith(array,iteratee){if(!(array&&array.length)){return[];}var result=unzip(array);if(iteratee==null){return result;}return arrayMap(result,function(group){return apply(iteratee,undefined,group);});}var without=baseRest(function(array,values){return isArrayLikeObject(array)?baseDifference(array,values):[];});var xor=baseRest(function(arrays){return baseXor(arrayFilter(arrays,isArrayLikeObject));});var xorBy=baseRest(function(arrays){var iteratee=last(arrays);if(isArrayLikeObject(iteratee)){iteratee=undefined;}return baseXor(arrayFilter(arrays,isArrayLikeObject),getIteratee(iteratee,2));});var xorWith=baseRest(function(arrays){var comparator=last(arrays);comparator=typeof comparator=='function'?comparator:undefined;return baseXor(arrayFilter(arrays,isArrayLikeObject),undefined,comparator);});var zip=baseRest(unzip);function zipObject(props,values){return baseZipObject(props||[],values||[],assignValue);}function zipObjectDeep(props,values){return baseZipObject(props||[],values||[],baseSet);}var zipWith=baseRest(function(arrays){var length=arrays.length,iteratee=length>1?arrays[length-1]:undefined;iteratee=typeof iteratee=='function'?(arrays.pop(),iteratee):undefined;return unzipWith(arrays,iteratee);});function chain(value){var result=lodash(value);result.__chain__=true;return result;}function tap(value,interceptor){interceptor(value);return value;}function thru(value,interceptor){return interceptor(value);}var wrapperAt=flatRest(function(paths){var length=paths.length,start=length?paths[0]:0,value=this.__wrapped__,interceptor=function(object){return baseAt(object,paths);};if(length>1||this.__actions__.length||!(value instanceof LazyWrapper)||!isIndex(start)){return this.thru(interceptor);}value=value.slice(start,+start+(length?1:0));value.__actions__.push({'func':thru,'args':[interceptor],'thisArg':undefined});return new LodashWrapper(value,this.__chain__).thru(function(array){if(length&&!array.length){array.push(undefined);}return array;});});function wrapperChain(){return chain(this);}function wrapperCommit(){return new LodashWrapper(this.value(),this.__chain__);}function wrapperNext(){if(this.__values__===undefined){this.__values__=toArray(this.value());}var done=this.__index__>=this.__values__.length,value=done?undefined:this.__values__[this.__index__++];return{'done':done,'value':value};}function wrapperToIterator(){return this;}function wrapperPlant(value){var result,parent=this;while(parent instanceof baseLodash){var clone=wrapperClone(parent);clone.__index__=0;clone.__values__=undefined;if(result){previous.__wrapped__=clone;}else{result=clone;}var previous=clone;parent=parent.__wrapped__;}previous.__wrapped__=value;return result;}function wrapperReverse(){var value=this.__wrapped__;if(value instanceof LazyWrapper){var wrapped=value;if(this.__actions__.length){wrapped=new LazyWrapper(this);}wrapped=wrapped.reverse();wrapped.__actions__.push({'func':thru,'args':[reverse],'thisArg':undefined});return new LodashWrapper(wrapped,this.__chain__);}return this.thru(reverse);}function wrapperValue(){return baseWrapperValue(this.__wrapped__,this.__actions__);}var countBy=createAggregator(function(result,value,key){if(hasOwnProperty.call(result,key)){++result[key];}else{baseAssignValue(result,key,1);}});function every(collection,predicate,guard){var func=isArray(collection)?arrayEvery:baseEvery;if(guard&&isIterateeCall(collection,predicate,guard)){predicate=undefined;}return func(collection,getIteratee(predicate,3));}function filter(collection,predicate){var func=isArray(collection)?arrayFilter:baseFilter;return func(collection,getIteratee(predicate,3));}var find=createFind(findIndex);var findLast=createFind(findLastIndex);function flatMap(collection,iteratee){return baseFlatten(map(collection,iteratee),1);}function flatMapDeep(collection,iteratee){return baseFlatten(map(collection,iteratee),INFINITY);}function flatMapDepth(collection,iteratee,depth){depth=depth===undefined?1:toInteger(depth);return baseFlatten(map(collection,iteratee),depth);}function forEach(collection,iteratee){var func=isArray(collection)?arrayEach:baseEach;return func(collection,getIteratee(iteratee,3));}function forEachRight(collection,iteratee){var func=isArray(collection)?arrayEachRight:baseEachRight;return func(collection,getIteratee(iteratee,3));}var groupBy=createAggregator(function(result,value,key){if(hasOwnProperty.call(result,key)){result[key].push(value);}else{baseAssignValue(result,key,[value]);}});function includes(collection,value,fromIndex,guard){collection=isArrayLike(collection)?collection:values(collection);fromIndex=fromIndex&&!guard?toInteger(fromIndex):0;var length=collection.length;if(fromIndex<0){fromIndex=nativeMax(length+fromIndex,0);}return isString(collection)?fromIndex<=length&&collection.indexOf(value,fromIndex)>-1:!!length&&baseIndexOf(collection,value,fromIndex)>-1;}var invokeMap=baseRest(function(collection,path,args){var index=-1,isFunc=typeof path=='function',result=isArrayLike(collection)?Array(collection.length):[];baseEach(collection,function(value){result[++index]=isFunc?apply(path,value,args):baseInvoke(value,path,args);});return result;});var keyBy=createAggregator(function(result,value,key){baseAssignValue(result,key,value);});function map(collection,iteratee){var func=isArray(collection)?arrayMap:baseMap;return func(collection,getIteratee(iteratee,3));}function orderBy(collection,iteratees,orders,guard){if(collection==null){return[];}if(!isArray(iteratees)){iteratees=iteratees==null?[]:[iteratees];}orders=guard?undefined:orders;if(!isArray(orders)){orders=orders==null?[]:[orders];}return baseOrderBy(collection,iteratees,orders);}var partition=createAggregator(function(result,value,key){result[key?0:1].push(value);},function(){return[[],[]];});function reduce(collection,iteratee,accumulator){var func=isArray(collection)?arrayReduce:baseReduce,initAccum=arguments.length<3;return func(collection,getIteratee(iteratee,4),accumulator,initAccum,baseEach);}function reduceRight(collection,iteratee,accumulator){var func=isArray(collection)?arrayReduceRight:baseReduce,initAccum=arguments.length<3;return func(collection,getIteratee(iteratee,4),accumulator,initAccum,baseEachRight);}function reject(collection,predicate){var func=isArray(collection)?arrayFilter:baseFilter;return func(collection,negate(getIteratee(predicate,3)));}function sample(collection){var func=isArray(collection)?arraySample:baseSample;return func(collection);}function sampleSize(collection,n,guard){if(guard?isIterateeCall(collection,n,guard):n===undefined){n=1;}else{n=toInteger(n);}var func=isArray(collection)?arraySampleSize:baseSampleSize;return func(collection,n);}function shuffle(collection){var func=isArray(collection)?arrayShuffle:baseShuffle;return func(collection);}function size(collection){if(collection==null){return 0;}if(isArrayLike(collection)){return isString(collection)?stringSize(collection):collection.length;}var tag=getTag(collection);if(tag==mapTag||tag==setTag){return collection.size;}return baseKeys(collection).length;}function some(collection,predicate,guard){var func=isArray(collection)?arraySome:baseSome;if(guard&&isIterateeCall(collection,predicate,guard)){predicate=undefined;}return func(collection,getIteratee(predicate,3));}var sortBy=baseRest(function(collection,iteratees){if(collection==null){return[];}var length=iteratees.length;if(length>1&&isIterateeCall(collection,iteratees[0],iteratees[1])){iteratees=[];}else if(length>2&&isIterateeCall(iteratees[0],iteratees[1],iteratees[2])){iteratees=[iteratees[0]];}return baseOrderBy(collection,baseFlatten(iteratees,1),[]);});var now=ctxNow||function(){return root.Date.now();};function after(n,func){if(typeof func!='function'){throw new TypeError(FUNC_ERROR_TEXT);}n=toInteger(n);return function(){if(--n<1){return func.apply(this,arguments);}};}function ary(func,n,guard){n=guard?undefined:n;n=func&&n==null?func.length:n;return createWrap(func,WRAP_ARY_FLAG,undefined,undefined,undefined,undefined,n);}function before(n,func){var result;if(typeof func!='function'){throw new TypeError(FUNC_ERROR_TEXT);}n=toInteger(n);return function(){if(--n>0){result=func.apply(this,arguments);}if(n<=1){func=undefined;}return result;};}var bind=baseRest(function(func,thisArg,partials){var bitmask=WRAP_BIND_FLAG;if(partials.length){var holders=replaceHolders(partials,getHolder(bind));bitmask|=WRAP_PARTIAL_FLAG;}return createWrap(func,bitmask,thisArg,partials,holders);});var bindKey=baseRest(function(object,key,partials){var bitmask=WRAP_BIND_FLAG|WRAP_BIND_KEY_FLAG;if(partials.length){var holders=replaceHolders(partials,getHolder(bindKey));bitmask|=WRAP_PARTIAL_FLAG;}return createWrap(key,bitmask,object,partials,holders);});function curry(func,arity,guard){arity=guard?undefined:arity;var result=createWrap(func,WRAP_CURRY_FLAG,undefined,undefined,undefined,undefined,undefined,arity);result.placeholder=curry.placeholder;return result;}function curryRight(func,arity,guard){arity=guard?undefined:arity;var result=createWrap(func,WRAP_CURRY_RIGHT_FLAG,undefined,undefined,undefined,undefined,undefined,arity);result.placeholder=curryRight.placeholder;return result;}function debounce(func,wait,options){var lastArgs,lastThis,maxWait,result,timerId,lastCallTime,lastInvokeTime=0,leading=false,maxing=false,trailing=true;if(typeof func!='function'){throw new TypeError(FUNC_ERROR_TEXT);}wait=toNumber(wait)||0;if(isObject(options)){leading=!!options.leading;maxing='maxWait'in options;maxWait=maxing?nativeMax(toNumber(options.maxWait)||0,wait):maxWait;trailing='trailing'in options?!!options.trailing:trailing;}function invokeFunc(time){var args=lastArgs,thisArg=lastThis;lastArgs=lastThis=undefined;lastInvokeTime=time;result=func.apply(thisArg,args);return result;}function leadingEdge(time){lastInvokeTime=time;timerId=setTimeout(timerExpired,wait);return leading?invokeFunc(time):result;}function remainingWait(time){var timeSinceLastCall=time-lastCallTime,timeSinceLastInvoke=time-lastInvokeTime,timeWaiting=wait-timeSinceLastCall;return maxing?nativeMin(timeWaiting,maxWait-timeSinceLastInvoke):timeWaiting;}function shouldInvoke(time){var timeSinceLastCall=time-lastCallTime,timeSinceLastInvoke=time-lastInvokeTime;return lastCallTime===undefined||timeSinceLastCall>=wait||timeSinceLastCall<0||maxing&&timeSinceLastInvoke>=maxWait;}function timerExpired(){var time=now();if(shouldInvoke(time)){return trailingEdge(time);}timerId=setTimeout(timerExpired,remainingWait(time));}function trailingEdge(time){timerId=undefined;if(trailing&&lastArgs){return invokeFunc(time);}lastArgs=lastThis=undefined;return result;}function cancel(){if(timerId!==undefined){clearTimeout(timerId);}lastInvokeTime=0;lastArgs=lastCallTime=lastThis=timerId=undefined;}function flush(){return timerId===undefined?result:trailingEdge(now());}function debounced(){var time=now(),isInvoking=shouldInvoke(time);lastArgs=arguments;lastThis=this;lastCallTime=time;if(isInvoking){if(timerId===undefined){return leadingEdge(lastCallTime);}if(maxing){clearTimeout(timerId);timerId=setTimeout(timerExpired,wait);return invokeFunc(lastCallTime);}}if(timerId===undefined){timerId=setTimeout(timerExpired,wait);}return result;}debounced.cancel=cancel;debounced.flush=flush;return debounced;}var defer=baseRest(function(func,args){return baseDelay(func,1,args);});var delay=baseRest(function(func,wait,args){return baseDelay(func,toNumber(wait)||0,args);});function flip(func){return createWrap(func,WRAP_FLIP_FLAG);}function memoize(func,resolver){if(typeof func!='function'||resolver!=null&&typeof resolver!='function'){throw new TypeError(FUNC_ERROR_TEXT);}var memoized=function(){var args=arguments,key=resolver?resolver.apply(this,args):args[0],cache=memoized.cache;if(cache.has(key)){return cache.get(key);}var result=func.apply(this,args);memoized.cache=cache.set(key,result)||cache;return result;};memoized.cache=new(memoize.Cache||MapCache)();return memoized;}memoize.Cache=MapCache;function negate(predicate){if(typeof predicate!='function'){throw new TypeError(FUNC_ERROR_TEXT);}return function(){var args=arguments;switch(args.length){case 0:return!predicate.call(this);case 1:return!predicate.call(this,args[0]);case 2:return!predicate.call(this,args[0],args[1]);case 3:return!predicate.call(this,args[0],args[1],args[2]);}return!predicate.apply(this,args);};}function once(func){return before(2,func);}var overArgs=castRest(function(func,transforms){transforms=transforms.length==1&&isArray(transforms[0])?arrayMap(transforms[0],baseUnary(getIteratee())):arrayMap(baseFlatten(transforms,1),baseUnary(getIteratee()));var funcsLength=transforms.length;return baseRest(function(args){var index=-1,length=nativeMin(args.length,funcsLength);while(++index<length){args[index]=transforms[index].call(this,args[index]);}return apply(func,this,args);});});var partial=baseRest(function(func,partials){var holders=replaceHolders(partials,getHolder(partial));return createWrap(func,WRAP_PARTIAL_FLAG,undefined,partials,holders);});var partialRight=baseRest(function(func,partials){var holders=replaceHolders(partials,getHolder(partialRight));return createWrap(func,WRAP_PARTIAL_RIGHT_FLAG,undefined,partials,holders);});var rearg=flatRest(function(func,indexes){return createWrap(func,WRAP_REARG_FLAG,undefined,undefined,undefined,indexes);});function rest(func,start){if(typeof func!='function'){throw new TypeError(FUNC_ERROR_TEXT);}start=start===undefined?start:toInteger(start);return baseRest(func,start);}function spread(func,start){if(typeof func!='function'){throw new TypeError(FUNC_ERROR_TEXT);}start=start==null?0:nativeMax(toInteger(start),0);return baseRest(function(args){var array=args[start],otherArgs=castSlice(args,0,start);if(array){arrayPush(otherArgs,array);}return apply(func,this,otherArgs);});}function throttle(func,wait,options){var leading=true,trailing=true;if(typeof func!='function'){throw new TypeError(FUNC_ERROR_TEXT);}if(isObject(options)){leading='leading'in options?!!options.leading:leading;trailing='trailing'in options?!!options.trailing:trailing;}return debounce(func,wait,{'leading':leading,'maxWait':wait,'trailing':trailing});}function unary(func){return ary(func,1);}function wrap(value,wrapper){return partial(castFunction(wrapper),value);}function castArray(){if(!arguments.length){return[];}var value=arguments[0];return isArray(value)?value:[value];}function clone(value){return baseClone(value,CLONE_SYMBOLS_FLAG);}function cloneWith(value,customizer){customizer=typeof customizer=='function'?customizer:undefined;return baseClone(value,CLONE_SYMBOLS_FLAG,customizer);}function cloneDeep(value){return baseClone(value,CLONE_DEEP_FLAG|CLONE_SYMBOLS_FLAG);}function cloneDeepWith(value,customizer){customizer=typeof customizer=='function'?customizer:undefined;return baseClone(value,CLONE_DEEP_FLAG|CLONE_SYMBOLS_FLAG,customizer);}function conformsTo(object,source){return source==null||baseConformsTo(object,source,keys(source));}function eq(value,other){return value===other||value!==value&&other!==other;}var gt=createRelationalOperation(baseGt);var gte=createRelationalOperation(function(value,other){return value>=other;});var isArguments=baseIsArguments(function(){return arguments;}())?baseIsArguments:function(value){return isObjectLike(value)&&hasOwnProperty.call(value,'callee')&&!propertyIsEnumerable.call(value,'callee');};var isArray=Array.isArray;var isArrayBuffer=nodeIsArrayBuffer?baseUnary(nodeIsArrayBuffer):baseIsArrayBuffer;function isArrayLike(value){return value!=null&&isLength(value.length)&&!isFunction(value);}function isArrayLikeObject(value){return isObjectLike(value)&&isArrayLike(value);}function isBoolean(value){return value===true||value===false||isObjectLike(value)&&baseGetTag(value)==boolTag;}var isBuffer=nativeIsBuffer||stubFalse;var isDate=nodeIsDate?baseUnary(nodeIsDate):baseIsDate;function isElement(value){return isObjectLike(value)&&value.nodeType===1&&!isPlainObject(value);}function isEmpty(value){if(value==null){return true;}if(isArrayLike(value)&&(isArray(value)||typeof value=='string'||typeof value.splice=='function'||isBuffer(value)||isTypedArray(value)||isArguments(value))){return!value.length;}var tag=getTag(value);if(tag==mapTag||tag==setTag){return!value.size;}if(isPrototype(value)){return!baseKeys(value).length;}for(var key in value){if(hasOwnProperty.call(value,key)){return false;}}return true;}function isEqual(value,other){return baseIsEqual(value,other);}function isEqualWith(value,other,customizer){customizer=typeof customizer=='function'?customizer:undefined;var result=customizer?customizer(value,other):undefined;return result===undefined?baseIsEqual(value,other,undefined,customizer):!!result;}function isError(value){if(!isObjectLike(value)){return false;}var tag=baseGetTag(value);return tag==errorTag||tag==domExcTag||typeof value.message=='string'&&typeof value.name=='string'&&!isPlainObject(value);}function isFinite(value){return typeof value=='number'&&nativeIsFinite(value);}function isFunction(value){if(!isObject(value)){return false;}var tag=baseGetTag(value);return tag==funcTag||tag==genTag||tag==asyncTag||tag==proxyTag;}function isInteger(value){return typeof value=='number'&&value==toInteger(value);}function isLength(value){return typeof value=='number'&&value>-1&&value%1==0&&value<=MAX_SAFE_INTEGER;}function isObject(value){var type=typeof value;return value!=null&&(type=='object'||type=='function');}function isObjectLike(value){return value!=null&&typeof value=='object';}var isMap=nodeIsMap?baseUnary(nodeIsMap):baseIsMap;function isMatch(object,source){return object===source||baseIsMatch(object,source,getMatchData(source));}function isMatchWith(object,source,customizer){customizer=typeof customizer=='function'?customizer:undefined;return baseIsMatch(object,source,getMatchData(source),customizer);}function isNaN(value){return isNumber(value)&&value!=+value;}function isNative(value){if(isMaskable(value)){throw new Error(CORE_ERROR_TEXT);}return baseIsNative(value);}function isNull(value){return value===null;}function isNil(value){return value==null;}function isNumber(value){return typeof value=='number'||isObjectLike(value)&&baseGetTag(value)==numberTag;}function isPlainObject(value){if(!isObjectLike(value)||baseGetTag(value)!=objectTag){return false;}var proto=getPrototype(value);if(proto===null){return true;}var Ctor=hasOwnProperty.call(proto,'constructor')&&proto.constructor;return typeof Ctor=='function'&&Ctor instanceof Ctor&&funcToString.call(Ctor)==objectCtorString;}var isRegExp=nodeIsRegExp?baseUnary(nodeIsRegExp):baseIsRegExp;function isSafeInteger(value){return isInteger(value)&&value>=-MAX_SAFE_INTEGER&&value<=MAX_SAFE_INTEGER;}var isSet=nodeIsSet?baseUnary(nodeIsSet):baseIsSet;function isString(value){return typeof value=='string'||!isArray(value)&&isObjectLike(value)&&baseGetTag(value)==stringTag;}function isSymbol(value){return typeof value=='symbol'||isObjectLike(value)&&baseGetTag(value)==symbolTag;}var isTypedArray=nodeIsTypedArray?baseUnary(nodeIsTypedArray):baseIsTypedArray;function isUndefined(value){return value===undefined;}function isWeakMap(value){return isObjectLike(value)&&getTag(value)==weakMapTag;}function isWeakSet(value){return isObjectLike(value)&&baseGetTag(value)==weakSetTag;}var lt=createRelationalOperation(baseLt);var lte=createRelationalOperation(function(value,other){return value<=other;});function toArray(value){if(!value){return[];}if(isArrayLike(value)){return isString(value)?stringToArray(value):copyArray(value);}if(symIterator&&value[symIterator]){return iteratorToArray(value[symIterator]());}var tag=getTag(value),func=tag==mapTag?mapToArray:tag==setTag?setToArray:values;return func(value);}function toFinite(value){if(!value){return value===0?value:0;}value=toNumber(value);if(value===INFINITY||value===-INFINITY){var sign=value<0?-1:1;return sign*MAX_INTEGER;}return value===value?value:0;}function toInteger(value){var result=toFinite(value),remainder=result%1;return result===result?remainder?result-remainder:result:0;}function toLength(value){return value?baseClamp(toInteger(value),0,MAX_ARRAY_LENGTH):0;}function toNumber(value){if(typeof value=='number'){return value;}if(isSymbol(value)){return NAN;}if(isObject(value)){var other=typeof value.valueOf=='function'?value.valueOf():value;value=isObject(other)?other+'':other;}if(typeof value!='string'){return value===0?value:+value;}value=value.replace(reTrim,'');var isBinary=reIsBinary.test(value);return isBinary||reIsOctal.test(value)?freeParseInt(value.slice(2),isBinary?2:8):reIsBadHex.test(value)?NAN:+value;}function toPlainObject(value){return copyObject(value,keysIn(value));}function toSafeInteger(value){return value?baseClamp(toInteger(value),-MAX_SAFE_INTEGER,MAX_SAFE_INTEGER):value===0?value:0;}function toString(value){return value==null?'':baseToString(value);}var assign=createAssigner(function(object,source){if(isPrototype(source)||isArrayLike(source)){copyObject(source,keys(source),object);return;}for(var key in source){if(hasOwnProperty.call(source,key)){assignValue(object,key,source[key]);}}});var assignIn=createAssigner(function(object,source){copyObject(source,keysIn(source),object);});var assignInWith=createAssigner(function(object,source,srcIndex,customizer){copyObject(source,keysIn(source),object,customizer);});var assignWith=createAssigner(function(object,source,srcIndex,customizer){copyObject(source,keys(source),object,customizer);});var at=flatRest(baseAt);function create(prototype,properties){var result=baseCreate(prototype);return properties==null?result:baseAssign(result,properties);}var defaults=baseRest(function(object,sources){object=Object(object);var index=-1;var length=sources.length;var guard=length>2?sources[2]:undefined;if(guard&&isIterateeCall(sources[0],sources[1],guard)){length=1;}while(++index<length){var source=sources[index];var props=keysIn(source);var propsIndex=-1;var propsLength=props.length;while(++propsIndex<propsLength){var key=props[propsIndex];var value=object[key];if(value===undefined||eq(value,objectProto[key])&&!hasOwnProperty.call(object,key)){object[key]=source[key];}}}return object;});var defaultsDeep=baseRest(function(args){args.push(undefined,customDefaultsMerge);return apply(mergeWith,undefined,args);});function findKey(object,predicate){return baseFindKey(object,getIteratee(predicate,3),baseForOwn);}function findLastKey(object,predicate){return baseFindKey(object,getIteratee(predicate,3),baseForOwnRight);}function forIn(object,iteratee){return object==null?object:baseFor(object,getIteratee(iteratee,3),keysIn);}function forInRight(object,iteratee){return object==null?object:baseForRight(object,getIteratee(iteratee,3),keysIn);}function forOwn(object,iteratee){return object&&baseForOwn(object,getIteratee(iteratee,3));}function forOwnRight(object,iteratee){return object&&baseForOwnRight(object,getIteratee(iteratee,3));}function functions(object){return object==null?[]:baseFunctions(object,keys(object));}function functionsIn(object){return object==null?[]:baseFunctions(object,keysIn(object));}function get(object,path,defaultValue){var result=object==null?undefined:baseGet(object,path);return result===undefined?defaultValue:result;}function has(object,path){return object!=null&&hasPath(object,path,baseHas);}function hasIn(object,path){return object!=null&&hasPath(object,path,baseHasIn);}var invert=createInverter(function(result,value,key){if(value!=null&&typeof value.toString!='function'){value=nativeObjectToString.call(value);}result[value]=key;},constant(identity));var invertBy=createInverter(function(result,value,key){if(value!=null&&typeof value.toString!='function'){value=nativeObjectToString.call(value);}if(hasOwnProperty.call(result,value)){result[value].push(key);}else{result[value]=[key];}},getIteratee);var invoke=baseRest(baseInvoke);function keys(object){return isArrayLike(object)?arrayLikeKeys(object):baseKeys(object);}function keysIn(object){return isArrayLike(object)?arrayLikeKeys(object,true):baseKeysIn(object);}function mapKeys(object,iteratee){var result={};iteratee=getIteratee(iteratee,3);baseForOwn(object,function(value,key,object){baseAssignValue(result,iteratee(value,key,object),value);});return result;}function mapValues(object,iteratee){var result={};iteratee=getIteratee(iteratee,3);baseForOwn(object,function(value,key,object){baseAssignValue(result,key,iteratee(value,key,object));});return result;}var merge=createAssigner(function(object,source,srcIndex){baseMerge(object,source,srcIndex);});var mergeWith=createAssigner(function(object,source,srcIndex,customizer){baseMerge(object,source,srcIndex,customizer);});var omit=flatRest(function(object,paths){var result={};if(object==null){return result;}var isDeep=false;paths=arrayMap(paths,function(path){path=castPath(path,object);isDeep||(isDeep=path.length>1);return path;});copyObject(object,getAllKeysIn(object),result);if(isDeep){result=baseClone(result,CLONE_DEEP_FLAG|CLONE_FLAT_FLAG|CLONE_SYMBOLS_FLAG,customOmitClone);}var length=paths.length;while(length--){baseUnset(result,paths[length]);}return result;});function omitBy(object,predicate){return pickBy(object,negate(getIteratee(predicate)));}var pick=flatRest(function(object,paths){return object==null?{}:basePick(object,paths);});function pickBy(object,predicate){if(object==null){return{};}var props=arrayMap(getAllKeysIn(object),function(prop){return[prop];});predicate=getIteratee(predicate);return basePickBy(object,props,function(value,path){return predicate(value,path[0]);});}function result(object,path,defaultValue){path=castPath(path,object);var index=-1,length=path.length;if(!length){length=1;object=undefined;}while(++index<length){var value=object==null?undefined:object[toKey(path[index])];if(value===undefined){index=length;value=defaultValue;}object=isFunction(value)?value.call(object):value;}return object;}function set(object,path,value){return object==null?object:baseSet(object,path,value);}function setWith(object,path,value,customizer){customizer=typeof customizer=='function'?customizer:undefined;return object==null?object:baseSet(object,path,value,customizer);}var toPairs=createToPairs(keys);var toPairsIn=createToPairs(keysIn);function transform(object,iteratee,accumulator){var isArr=isArray(object),isArrLike=isArr||isBuffer(object)||isTypedArray(object);iteratee=getIteratee(iteratee,4);if(accumulator==null){var Ctor=object&&object.constructor;if(isArrLike){accumulator=isArr?new Ctor():[];}else if(isObject(object)){accumulator=isFunction(Ctor)?baseCreate(getPrototype(object)):{};}else{accumulator={};}}(isArrLike?arrayEach:baseForOwn)(object,function(value,index,object){return iteratee(accumulator,value,index,object);});return accumulator;}function unset(object,path){return object==null?true:baseUnset(object,path);}function update(object,path,updater){return object==null?object:baseUpdate(object,path,castFunction(updater));}function updateWith(object,path,updater,customizer){customizer=typeof customizer=='function'?customizer:undefined;return object==null?object:baseUpdate(object,path,castFunction(updater),customizer);}function values(object){return object==null?[]:baseValues(object,keys(object));}function valuesIn(object){return object==null?[]:baseValues(object,keysIn(object));}function clamp(number,lower,upper){if(upper===undefined){upper=lower;lower=undefined;}if(upper!==undefined){upper=toNumber(upper);upper=upper===upper?upper:0;}if(lower!==undefined){lower=toNumber(lower);lower=lower===lower?lower:0;}return baseClamp(toNumber(number),lower,upper);}function inRange(number,start,end){start=toFinite(start);if(end===undefined){end=start;start=0;}else{end=toFinite(end);}number=toNumber(number);return baseInRange(number,start,end);}function random(lower,upper,floating){if(floating&&typeof floating!='boolean'&&isIterateeCall(lower,upper,floating)){upper=floating=undefined;}if(floating===undefined){if(typeof upper=='boolean'){floating=upper;upper=undefined;}else if(typeof lower=='boolean'){floating=lower;lower=undefined;}}if(lower===undefined&&upper===undefined){lower=0;upper=1;}else{lower=toFinite(lower);if(upper===undefined){upper=lower;lower=0;}else{upper=toFinite(upper);}}if(lower>upper){var temp=lower;lower=upper;upper=temp;}if(floating||lower%1||upper%1){var rand=nativeRandom();return nativeMin(lower+rand*(upper-lower+freeParseFloat('1e-'+((rand+'').length-1))),upper);}return baseRandom(lower,upper);}var camelCase=createCompounder(function(result,word,index){word=word.toLowerCase();return result+(index?capitalize(word):word);});function capitalize(string){return upperFirst(toString(string).toLowerCase());}function deburr(string){string=toString(string);return string&&string.replace(reLatin,deburrLetter).replace(reComboMark,'');}function endsWith(string,target,position){string=toString(string);target=baseToString(target);var length=string.length;position=position===undefined?length:baseClamp(toInteger(position),0,length);var end=position;position-=target.length;return position>=0&&string.slice(position,end)==target;}function escape(string){string=toString(string);return string&&reHasUnescapedHtml.test(string)?string.replace(reUnescapedHtml,escapeHtmlChar):string;}function escapeRegExp(string){string=toString(string);return string&&reHasRegExpChar.test(string)?string.replace(reRegExpChar,'\\$&'):string;}var kebabCase=createCompounder(function(result,word,index){return result+(index?'-':'')+word.toLowerCase();});var lowerCase=createCompounder(function(result,word,index){return result+(index?' ':'')+word.toLowerCase();});var lowerFirst=createCaseFirst('toLowerCase');function pad(string,length,chars){string=toString(string);length=toInteger(length);var strLength=length?stringSize(string):0;if(!length||strLength>=length){return string;}var mid=(length-strLength)/2;return createPadding(nativeFloor(mid),chars)+string+createPadding(nativeCeil(mid),chars);}function padEnd(string,length,chars){string=toString(string);length=toInteger(length);var strLength=length?stringSize(string):0;return length&&strLength<length?string+createPadding(length-strLength,chars):string;}function padStart(string,length,chars){string=toString(string);length=toInteger(length);var strLength=length?stringSize(string):0;return length&&strLength<length?createPadding(length-strLength,chars)+string:string;}function parseInt(string,radix,guard){if(guard||radix==null){radix=0;}else if(radix){radix=+radix;}return nativeParseInt(toString(string).replace(reTrimStart,''),radix||0);}function repeat(string,n,guard){if(guard?isIterateeCall(string,n,guard):n===undefined){n=1;}else{n=toInteger(n);}return baseRepeat(toString(string),n);}function replace(){var args=arguments,string=toString(args[0]);return args.length<3?string:string.replace(args[1],args[2]);}var snakeCase=createCompounder(function(result,word,index){return result+(index?'_':'')+word.toLowerCase();});function split(string,separator,limit){if(limit&&typeof limit!='number'&&isIterateeCall(string,separator,limit)){separator=limit=undefined;}limit=limit===undefined?MAX_ARRAY_LENGTH:limit>>>0;if(!limit){return[];}string=toString(string);if(string&&(typeof separator=='string'||separator!=null&&!isRegExp(separator))){separator=baseToString(separator);if(!separator&&hasUnicode(string)){return castSlice(stringToArray(string),0,limit);}}return string.split(separator,limit);}var startCase=createCompounder(function(result,word,index){return result+(index?' ':'')+upperFirst(word);});function startsWith(string,target,position){string=toString(string);position=position==null?0:baseClamp(toInteger(position),0,string.length);target=baseToString(target);return string.slice(position,position+target.length)==target;}function template(string,options,guard){var settings=lodash.templateSettings;if(guard&&isIterateeCall(string,options,guard)){options=undefined;}string=toString(string);options=assignInWith({},options,settings,customDefaultsAssignIn);var imports=assignInWith({},options.imports,settings.imports,customDefaultsAssignIn),importsKeys=keys(imports),importsValues=baseValues(imports,importsKeys);var isEscaping,isEvaluating,index=0,interpolate=options.interpolate||reNoMatch,source="__p += '";var reDelimiters=RegExp((options.escape||reNoMatch).source+'|'+interpolate.source+'|'+(interpolate===reInterpolate?reEsTemplate:reNoMatch).source+'|'+(options.evaluate||reNoMatch).source+'|$','g');var sourceURL='//# sourceURL='+(hasOwnProperty.call(options,'sourceURL')?(options.sourceURL+'').replace(/[\r\n]/g,' '):'lodash.templateSources['+ ++templateCounter+']')+'\n';string.replace(reDelimiters,function(match,escapeValue,interpolateValue,esTemplateValue,evaluateValue,offset){interpolateValue||(interpolateValue=esTemplateValue);source+=string.slice(index,offset).replace(reUnescapedString,escapeStringChar);if(escapeValue){isEscaping=true;source+="' +\n__e("+escapeValue+") +\n'";}if(evaluateValue){isEvaluating=true;source+="';\n"+evaluateValue+";\n__p += '";}if(interpolateValue){source+="' +\n((__t = ("+interpolateValue+")) == null ? '' : __t) +\n'";}index=offset+match.length;return match;});source+="';\n";var variable=hasOwnProperty.call(options,'variable')&&options.variable;if(!variable){source='with (obj) {\n'+source+'\n}\n';}source=(isEvaluating?source.replace(reEmptyStringLeading,''):source).replace(reEmptyStringMiddle,'$1').replace(reEmptyStringTrailing,'$1;');source='function('+(variable||'obj')+') {\n'+(variable?'':'obj || (obj = {});\n')+"var __t, __p = ''"+(isEscaping?', __e = _.escape':'')+(isEvaluating?', __j = Array.prototype.join;\n'+"function print() { __p += __j.call(arguments, '') }\n":';\n')+source+'return __p\n}';var result=attempt(function(){return Function(importsKeys,sourceURL+'return '+source).apply(undefined,importsValues);});result.source=source;if(isError(result)){throw result;}return result;}function toLower(value){return toString(value).toLowerCase();}function toUpper(value){return toString(value).toUpperCase();}function trim(string,chars,guard){string=toString(string);if(string&&(guard||chars===undefined)){return string.replace(reTrim,'');}if(!string||!(chars=baseToString(chars))){return string;}var strSymbols=stringToArray(string),chrSymbols=stringToArray(chars),start=charsStartIndex(strSymbols,chrSymbols),end=charsEndIndex(strSymbols,chrSymbols)+1;return castSlice(strSymbols,start,end).join('');}function trimEnd(string,chars,guard){string=toString(string);if(string&&(guard||chars===undefined)){return string.replace(reTrimEnd,'');}if(!string||!(chars=baseToString(chars))){return string;}var strSymbols=stringToArray(string),end=charsEndIndex(strSymbols,stringToArray(chars))+1;return castSlice(strSymbols,0,end).join('');}function trimStart(string,chars,guard){string=toString(string);if(string&&(guard||chars===undefined)){return string.replace(reTrimStart,'');}if(!string||!(chars=baseToString(chars))){return string;}var strSymbols=stringToArray(string),start=charsStartIndex(strSymbols,stringToArray(chars));return castSlice(strSymbols,start).join('');}function truncate(string,options){var length=DEFAULT_TRUNC_LENGTH,omission=DEFAULT_TRUNC_OMISSION;if(isObject(options)){var separator='separator'in options?options.separator:separator;length='length'in options?toInteger(options.length):length;omission='omission'in options?baseToString(options.omission):omission;}string=toString(string);var strLength=string.length;if(hasUnicode(string)){var strSymbols=stringToArray(string);strLength=strSymbols.length;}if(length>=strLength){return string;}var end=length-stringSize(omission);if(end<1){return omission;}var result=strSymbols?castSlice(strSymbols,0,end).join(''):string.slice(0,end);if(separator===undefined){return result+omission;}if(strSymbols){end+=result.length-end;}if(isRegExp(separator)){if(string.slice(end).search(separator)){var match,substring=result;if(!separator.global){separator=RegExp(separator.source,toString(reFlags.exec(separator))+'g');}separator.lastIndex=0;while(match=separator.exec(substring)){var newEnd=match.index;}result=result.slice(0,newEnd===undefined?end:newEnd);}}else if(string.indexOf(baseToString(separator),end)!=end){var index=result.lastIndexOf(separator);if(index>-1){result=result.slice(0,index);}}return result+omission;}function unescape(string){string=toString(string);return string&&reHasEscapedHtml.test(string)?string.replace(reEscapedHtml,unescapeHtmlChar):string;}var upperCase=createCompounder(function(result,word,index){return result+(index?' ':'')+word.toUpperCase();});var upperFirst=createCaseFirst('toUpperCase');function words(string,pattern,guard){string=toString(string);pattern=guard?undefined:pattern;if(pattern===undefined){return hasUnicodeWord(string)?unicodeWords(string):asciiWords(string);}return string.match(pattern)||[];}var attempt=baseRest(function(func,args){try{return apply(func,undefined,args);}catch(e){return isError(e)?e:new Error(e);}});var bindAll=flatRest(function(object,methodNames){arrayEach(methodNames,function(key){key=toKey(key);baseAssignValue(object,key,bind(object[key],object));});return object;});function cond(pairs){var length=pairs==null?0:pairs.length,toIteratee=getIteratee();pairs=!length?[]:arrayMap(pairs,function(pair){if(typeof pair[1]!='function'){throw new TypeError(FUNC_ERROR_TEXT);}return[toIteratee(pair[0]),pair[1]];});return baseRest(function(args){var index=-1;while(++index<length){var pair=pairs[index];if(apply(pair[0],this,args)){return apply(pair[1],this,args);}}});}function conforms(source){return baseConforms(baseClone(source,CLONE_DEEP_FLAG));}function constant(value){return function(){return value;};}function defaultTo(value,defaultValue){return value==null||value!==value?defaultValue:value;}var flow=createFlow();var flowRight=createFlow(true);function identity(value){return value;}function iteratee(func){return baseIteratee(typeof func=='function'?func:baseClone(func,CLONE_DEEP_FLAG));}function matches(source){return baseMatches(baseClone(source,CLONE_DEEP_FLAG));}function matchesProperty(path,srcValue){return baseMatchesProperty(path,baseClone(srcValue,CLONE_DEEP_FLAG));}var method=baseRest(function(path,args){return function(object){return baseInvoke(object,path,args);};});var methodOf=baseRest(function(object,args){return function(path){return baseInvoke(object,path,args);};});function mixin(object,source,options){var props=keys(source),methodNames=baseFunctions(source,props);if(options==null&&!(isObject(source)&&(methodNames.length||!props.length))){options=source;source=object;object=this;methodNames=baseFunctions(source,keys(source));}var chain=!(isObject(options)&&'chain'in options)||!!options.chain,isFunc=isFunction(object);arrayEach(methodNames,function(methodName){var func=source[methodName];object[methodName]=func;if(isFunc){object.prototype[methodName]=function(){var chainAll=this.__chain__;if(chain||chainAll){var result=object(this.__wrapped__),actions=result.__actions__=copyArray(this.__actions__);actions.push({'func':func,'args':arguments,'thisArg':object});result.__chain__=chainAll;return result;}return func.apply(object,arrayPush([this.value()],arguments));};}});return object;}function noConflict(){if(root._===this){root._=oldDash;}return this;}function noop(){}function nthArg(n){n=toInteger(n);return baseRest(function(args){return baseNth(args,n);});}var over=createOver(arrayMap);var overEvery=createOver(arrayEvery);var overSome=createOver(arraySome);function property(path){return isKey(path)?baseProperty(toKey(path)):basePropertyDeep(path);}function propertyOf(object){return function(path){return object==null?undefined:baseGet(object,path);};}var range=createRange();var rangeRight=createRange(true);function stubArray(){return[];}function stubFalse(){return false;}function stubObject(){return{};}function stubString(){return'';}function stubTrue(){return true;}function times(n,iteratee){n=toInteger(n);if(n<1||n>MAX_SAFE_INTEGER){return[];}var index=MAX_ARRAY_LENGTH,length=nativeMin(n,MAX_ARRAY_LENGTH);iteratee=getIteratee(iteratee);n-=MAX_ARRAY_LENGTH;var result=baseTimes(length,iteratee);while(++index<n){iteratee(index);}return result;}function toPath(value){if(isArray(value)){return arrayMap(value,toKey);}return isSymbol(value)?[value]:copyArray(stringToPath(toString(value)));}function uniqueId(prefix){var id=++idCounter;return toString(prefix)+id;}var add=createMathOperation(function(augend,addend){return augend+addend;},0);var ceil=createRound('ceil');var divide=createMathOperation(function(dividend,divisor){return dividend/divisor;},1);var floor=createRound('floor');function max(array){return array&&array.length?baseExtremum(array,identity,baseGt):undefined;}function maxBy(array,iteratee){return array&&array.length?baseExtremum(array,getIteratee(iteratee,2),baseGt):undefined;}function mean(array){return baseMean(array,identity);}function meanBy(array,iteratee){return baseMean(array,getIteratee(iteratee,2));}function min(array){return array&&array.length?baseExtremum(array,identity,baseLt):undefined;}function minBy(array,iteratee){return array&&array.length?baseExtremum(array,getIteratee(iteratee,2),baseLt):undefined;}var multiply=createMathOperation(function(multiplier,multiplicand){return multiplier*multiplicand;},1);var round=createRound('round');var subtract=createMathOperation(function(minuend,subtrahend){return minuend-subtrahend;},0);function sum(array){return array&&array.length?baseSum(array,identity):0;}function sumBy(array,iteratee){return array&&array.length?baseSum(array,getIteratee(iteratee,2)):0;}lodash.after=after;lodash.ary=ary;lodash.assign=assign;lodash.assignIn=assignIn;lodash.assignInWith=assignInWith;lodash.assignWith=assignWith;lodash.at=at;lodash.before=before;lodash.bind=bind;lodash.bindAll=bindAll;lodash.bindKey=bindKey;lodash.castArray=castArray;lodash.chain=chain;lodash.chunk=chunk;lodash.compact=compact;lodash.concat=concat;lodash.cond=cond;lodash.conforms=conforms;lodash.constant=constant;lodash.countBy=countBy;lodash.create=create;lodash.curry=curry;lodash.curryRight=curryRight;lodash.debounce=debounce;lodash.defaults=defaults;lodash.defaultsDeep=defaultsDeep;lodash.defer=defer;lodash.delay=delay;lodash.difference=difference;lodash.differenceBy=differenceBy;lodash.differenceWith=differenceWith;lodash.drop=drop;lodash.dropRight=dropRight;lodash.dropRightWhile=dropRightWhile;lodash.dropWhile=dropWhile;lodash.fill=fill;lodash.filter=filter;lodash.flatMap=flatMap;lodash.flatMapDeep=flatMapDeep;lodash.flatMapDepth=flatMapDepth;lodash.flatten=flatten;lodash.flattenDeep=flattenDeep;lodash.flattenDepth=flattenDepth;lodash.flip=flip;lodash.flow=flow;lodash.flowRight=flowRight;lodash.fromPairs=fromPairs;lodash.functions=functions;lodash.functionsIn=functionsIn;lodash.groupBy=groupBy;lodash.initial=initial;lodash.intersection=intersection;lodash.intersectionBy=intersectionBy;lodash.intersectionWith=intersectionWith;lodash.invert=invert;lodash.invertBy=invertBy;lodash.invokeMap=invokeMap;lodash.iteratee=iteratee;lodash.keyBy=keyBy;lodash.keys=keys;lodash.keysIn=keysIn;lodash.map=map;lodash.mapKeys=mapKeys;lodash.mapValues=mapValues;lodash.matches=matches;lodash.matchesProperty=matchesProperty;lodash.memoize=memoize;lodash.merge=merge;lodash.mergeWith=mergeWith;lodash.method=method;lodash.methodOf=methodOf;lodash.mixin=mixin;lodash.negate=negate;lodash.nthArg=nthArg;lodash.omit=omit;lodash.omitBy=omitBy;lodash.once=once;lodash.orderBy=orderBy;lodash.over=over;lodash.overArgs=overArgs;lodash.overEvery=overEvery;lodash.overSome=overSome;lodash.partial=partial;lodash.partialRight=partialRight;lodash.partition=partition;lodash.pick=pick;lodash.pickBy=pickBy;lodash.property=property;lodash.propertyOf=propertyOf;lodash.pull=pull;lodash.pullAll=pullAll;lodash.pullAllBy=pullAllBy;lodash.pullAllWith=pullAllWith;lodash.pullAt=pullAt;lodash.range=range;lodash.rangeRight=rangeRight;lodash.rearg=rearg;lodash.reject=reject;lodash.remove=remove;lodash.rest=rest;lodash.reverse=reverse;lodash.sampleSize=sampleSize;lodash.set=set;lodash.setWith=setWith;lodash.shuffle=shuffle;lodash.slice=slice;lodash.sortBy=sortBy;lodash.sortedUniq=sortedUniq;lodash.sortedUniqBy=sortedUniqBy;lodash.split=split;lodash.spread=spread;lodash.tail=tail;lodash.take=take;lodash.takeRight=takeRight;lodash.takeRightWhile=takeRightWhile;lodash.takeWhile=takeWhile;lodash.tap=tap;lodash.throttle=throttle;lodash.thru=thru;lodash.toArray=toArray;lodash.toPairs=toPairs;lodash.toPairsIn=toPairsIn;lodash.toPath=toPath;lodash.toPlainObject=toPlainObject;lodash.transform=transform;lodash.unary=unary;lodash.union=union;lodash.unionBy=unionBy;lodash.unionWith=unionWith;lodash.uniq=uniq;lodash.uniqBy=uniqBy;lodash.uniqWith=uniqWith;lodash.unset=unset;lodash.unzip=unzip;lodash.unzipWith=unzipWith;lodash.update=update;lodash.updateWith=updateWith;lodash.values=values;lodash.valuesIn=valuesIn;lodash.without=without;lodash.words=words;lodash.wrap=wrap;lodash.xor=xor;lodash.xorBy=xorBy;lodash.xorWith=xorWith;lodash.zip=zip;lodash.zipObject=zipObject;lodash.zipObjectDeep=zipObjectDeep;lodash.zipWith=zipWith;lodash.entries=toPairs;lodash.entriesIn=toPairsIn;lodash.extend=assignIn;lodash.extendWith=assignInWith;mixin(lodash,lodash);lodash.add=add;lodash.attempt=attempt;lodash.camelCase=camelCase;lodash.capitalize=capitalize;lodash.ceil=ceil;lodash.clamp=clamp;lodash.clone=clone;lodash.cloneDeep=cloneDeep;lodash.cloneDeepWith=cloneDeepWith;lodash.cloneWith=cloneWith;lodash.conformsTo=conformsTo;lodash.deburr=deburr;lodash.defaultTo=defaultTo;lodash.divide=divide;lodash.endsWith=endsWith;lodash.eq=eq;lodash.escape=escape;lodash.escapeRegExp=escapeRegExp;lodash.every=every;lodash.find=find;lodash.findIndex=findIndex;lodash.findKey=findKey;lodash.findLast=findLast;lodash.findLastIndex=findLastIndex;lodash.findLastKey=findLastKey;lodash.floor=floor;lodash.forEach=forEach;lodash.forEachRight=forEachRight;lodash.forIn=forIn;lodash.forInRight=forInRight;lodash.forOwn=forOwn;lodash.forOwnRight=forOwnRight;lodash.get=get;lodash.gt=gt;lodash.gte=gte;lodash.has=has;lodash.hasIn=hasIn;lodash.head=head;lodash.identity=identity;lodash.includes=includes;lodash.indexOf=indexOf;lodash.inRange=inRange;lodash.invoke=invoke;lodash.isArguments=isArguments;lodash.isArray=isArray;lodash.isArrayBuffer=isArrayBuffer;lodash.isArrayLike=isArrayLike;lodash.isArrayLikeObject=isArrayLikeObject;lodash.isBoolean=isBoolean;lodash.isBuffer=isBuffer;lodash.isDate=isDate;lodash.isElement=isElement;lodash.isEmpty=isEmpty;lodash.isEqual=isEqual;lodash.isEqualWith=isEqualWith;lodash.isError=isError;lodash.isFinite=isFinite;lodash.isFunction=isFunction;lodash.isInteger=isInteger;lodash.isLength=isLength;lodash.isMap=isMap;lodash.isMatch=isMatch;lodash.isMatchWith=isMatchWith;lodash.isNaN=isNaN;lodash.isNative=isNative;lodash.isNil=isNil;lodash.isNull=isNull;lodash.isNumber=isNumber;lodash.isObject=isObject;lodash.isObjectLike=isObjectLike;lodash.isPlainObject=isPlainObject;lodash.isRegExp=isRegExp;lodash.isSafeInteger=isSafeInteger;lodash.isSet=isSet;lodash.isString=isString;lodash.isSymbol=isSymbol;lodash.isTypedArray=isTypedArray;lodash.isUndefined=isUndefined;lodash.isWeakMap=isWeakMap;lodash.isWeakSet=isWeakSet;lodash.join=join;lodash.kebabCase=kebabCase;lodash.last=last;lodash.lastIndexOf=lastIndexOf;lodash.lowerCase=lowerCase;lodash.lowerFirst=lowerFirst;lodash.lt=lt;lodash.lte=lte;lodash.max=max;lodash.maxBy=maxBy;lodash.mean=mean;lodash.meanBy=meanBy;lodash.min=min;lodash.minBy=minBy;lodash.stubArray=stubArray;lodash.stubFalse=stubFalse;lodash.stubObject=stubObject;lodash.stubString=stubString;lodash.stubTrue=stubTrue;lodash.multiply=multiply;lodash.nth=nth;lodash.noConflict=noConflict;lodash.noop=noop;lodash.now=now;lodash.pad=pad;lodash.padEnd=padEnd;lodash.padStart=padStart;lodash.parseInt=parseInt;lodash.random=random;lodash.reduce=reduce;lodash.reduceRight=reduceRight;lodash.repeat=repeat;lodash.replace=replace;lodash.result=result;lodash.round=round;lodash.runInContext=runInContext;lodash.sample=sample;lodash.size=size;lodash.snakeCase=snakeCase;lodash.some=some;lodash.sortedIndex=sortedIndex;lodash.sortedIndexBy=sortedIndexBy;lodash.sortedIndexOf=sortedIndexOf;lodash.sortedLastIndex=sortedLastIndex;lodash.sortedLastIndexBy=sortedLastIndexBy;lodash.sortedLastIndexOf=sortedLastIndexOf;lodash.startCase=startCase;lodash.startsWith=startsWith;lodash.subtract=subtract;lodash.sum=sum;lodash.sumBy=sumBy;lodash.template=template;lodash.times=times;lodash.toFinite=toFinite;lodash.toInteger=toInteger;lodash.toLength=toLength;lodash.toLower=toLower;lodash.toNumber=toNumber;lodash.toSafeInteger=toSafeInteger;lodash.toString=toString;lodash.toUpper=toUpper;lodash.trim=trim;lodash.trimEnd=trimEnd;lodash.trimStart=trimStart;lodash.truncate=truncate;lodash.unescape=unescape;lodash.uniqueId=uniqueId;lodash.upperCase=upperCase;lodash.upperFirst=upperFirst;lodash.each=forEach;lodash.eachRight=forEachRight;lodash.first=head;mixin(lodash,function(){var source={};baseForOwn(lodash,function(func,methodName){if(!hasOwnProperty.call(lodash.prototype,methodName)){source[methodName]=func;}});return source;}(),{'chain':false});lodash.VERSION=VERSION;arrayEach(['bind','bindKey','curry','curryRight','partial','partialRight'],function(methodName){lodash[methodName].placeholder=lodash;});arrayEach(['drop','take'],function(methodName,index){LazyWrapper.prototype[methodName]=function(n){n=n===undefined?1:nativeMax(toInteger(n),0);var result=this.__filtered__&&!index?new LazyWrapper(this):this.clone();if(result.__filtered__){result.__takeCount__=nativeMin(n,result.__takeCount__);}else{result.__views__.push({'size':nativeMin(n,MAX_ARRAY_LENGTH),'type':methodName+(result.__dir__<0?'Right':'')});}return result;};LazyWrapper.prototype[methodName+'Right']=function(n){return this.reverse()[methodName](n).reverse();};});arrayEach(['filter','map','takeWhile'],function(methodName,index){var type=index+1,isFilter=type==LAZY_FILTER_FLAG||type==LAZY_WHILE_FLAG;LazyWrapper.prototype[methodName]=function(iteratee){var result=this.clone();result.__iteratees__.push({'iteratee':getIteratee(iteratee,3),'type':type});result.__filtered__=result.__filtered__||isFilter;return result;};});arrayEach(['head','last'],function(methodName,index){var takeName='take'+(index?'Right':'');LazyWrapper.prototype[methodName]=function(){return this[takeName](1).value()[0];};});arrayEach(['initial','tail'],function(methodName,index){var dropName='drop'+(index?'':'Right');LazyWrapper.prototype[methodName]=function(){return this.__filtered__?new LazyWrapper(this):this[dropName](1);};});LazyWrapper.prototype.compact=function(){return this.filter(identity);};LazyWrapper.prototype.find=function(predicate){return this.filter(predicate).head();};LazyWrapper.prototype.findLast=function(predicate){return this.reverse().find(predicate);};LazyWrapper.prototype.invokeMap=baseRest(function(path,args){if(typeof path=='function'){return new LazyWrapper(this);}return this.map(function(value){return baseInvoke(value,path,args);});});LazyWrapper.prototype.reject=function(predicate){return this.filter(negate(getIteratee(predicate)));};LazyWrapper.prototype.slice=function(start,end){start=toInteger(start);var result=this;if(result.__filtered__&&(start>0||end<0)){return new LazyWrapper(result);}if(start<0){result=result.takeRight(-start);}else if(start){result=result.drop(start);}if(end!==undefined){end=toInteger(end);result=end<0?result.dropRight(-end):result.take(end-start);}return result;};LazyWrapper.prototype.takeRightWhile=function(predicate){return this.reverse().takeWhile(predicate).reverse();};LazyWrapper.prototype.toArray=function(){return this.take(MAX_ARRAY_LENGTH);};baseForOwn(LazyWrapper.prototype,function(func,methodName){var checkIteratee=/^(?:filter|find|map|reject)|While$/.test(methodName),isTaker=/^(?:head|last)$/.test(methodName),lodashFunc=lodash[isTaker?'take'+(methodName=='last'?'Right':''):methodName],retUnwrapped=isTaker||/^find/.test(methodName);if(!lodashFunc){return;}lodash.prototype[methodName]=function(){var value=this.__wrapped__,args=isTaker?[1]:arguments,isLazy=value instanceof LazyWrapper,iteratee=args[0],useLazy=isLazy||isArray(value);var interceptor=function(value){var result=lodashFunc.apply(lodash,arrayPush([value],args));return isTaker&&chainAll?result[0]:result;};if(useLazy&&checkIteratee&&typeof iteratee=='function'&&iteratee.length!=1){isLazy=useLazy=false;}var chainAll=this.__chain__,isHybrid=!!this.__actions__.length,isUnwrapped=retUnwrapped&&!chainAll,onlyLazy=isLazy&&!isHybrid;if(!retUnwrapped&&useLazy){value=onlyLazy?value:new LazyWrapper(this);var result=func.apply(value,args);result.__actions__.push({'func':thru,'args':[interceptor],'thisArg':undefined});return new LodashWrapper(result,chainAll);}if(isUnwrapped&&onlyLazy){return func.apply(this,args);}result=this.thru(interceptor);return isUnwrapped?isTaker?result.value()[0]:result.value():result;};});arrayEach(['pop','push','shift','sort','splice','unshift'],function(methodName){var func=arrayProto[methodName],chainName=/^(?:push|sort|unshift)$/.test(methodName)?'tap':'thru',retUnwrapped=/^(?:pop|shift)$/.test(methodName);lodash.prototype[methodName]=function(){var args=arguments;if(retUnwrapped&&!this.__chain__){var value=this.value();return func.apply(isArray(value)?value:[],args);}return this[chainName](function(value){return func.apply(isArray(value)?value:[],args);});};});baseForOwn(LazyWrapper.prototype,function(func,methodName){var lodashFunc=lodash[methodName];if(lodashFunc){var key=lodashFunc.name+'';if(!hasOwnProperty.call(realNames,key)){realNames[key]=[];}realNames[key].push({'name':methodName,'func':lodashFunc});}});realNames[createHybrid(undefined,WRAP_BIND_KEY_FLAG).name]=[{'name':'wrapper','func':undefined}];LazyWrapper.prototype.clone=lazyClone;LazyWrapper.prototype.reverse=lazyReverse;LazyWrapper.prototype.value=lazyValue;lodash.prototype.at=wrapperAt;lodash.prototype.chain=wrapperChain;lodash.prototype.commit=wrapperCommit;lodash.prototype.next=wrapperNext;lodash.prototype.plant=wrapperPlant;lodash.prototype.reverse=wrapperReverse;lodash.prototype.toJSON=lodash.prototype.valueOf=lodash.prototype.value=wrapperValue;lodash.prototype.first=lodash.prototype.head;if(symIterator){lodash.prototype[symIterator]=wrapperToIterator;}return lodash;};var _=runInContext();if(true){root._=_;!(__WEBPACK_AMD_DEFINE_RESULT__ = (function(){return _;}).call(exports, __webpack_require__, exports, module),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));}else {}}).call(globalThis);

/***/ }),

/***/ 432:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var lookup = [];
var revLookup = [];
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array;
var inited = false;
function init() {
  inited = true;
  var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  for (var i = 0, len = code.length; i < len; ++i) {
    lookup[i] = code[i];
    revLookup[code.charCodeAt(i)] = i;
  }
  revLookup['-'.charCodeAt(0)] = 62;
  revLookup['_'.charCodeAt(0)] = 63;
}
function toByteArray(b64) {
  if (!inited) {
    init();
  }
  var i, j, l, tmp, placeHolders, arr;
  var len = b64.length;
  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4');
  }
  placeHolders = b64[len - 2] === '=' ? 2 : b64[len - 1] === '=' ? 1 : 0;
  arr = new Arr(len * 3 / 4 - placeHolders);
  l = placeHolders > 0 ? len - 4 : len;
  var L = 0;
  for (i = 0, j = 0; i < l; i += 4, j += 3) {
    tmp = revLookup[b64.charCodeAt(i)] << 18 | revLookup[b64.charCodeAt(i + 1)] << 12 | revLookup[b64.charCodeAt(i + 2)] << 6 | revLookup[b64.charCodeAt(i + 3)];
    arr[L++] = tmp >> 16 & 0xFF;
    arr[L++] = tmp >> 8 & 0xFF;
    arr[L++] = tmp & 0xFF;
  }
  if (placeHolders === 2) {
    tmp = revLookup[b64.charCodeAt(i)] << 2 | revLookup[b64.charCodeAt(i + 1)] >> 4;
    arr[L++] = tmp & 0xFF;
  } else if (placeHolders === 1) {
    tmp = revLookup[b64.charCodeAt(i)] << 10 | revLookup[b64.charCodeAt(i + 1)] << 4 | revLookup[b64.charCodeAt(i + 2)] >> 2;
    arr[L++] = tmp >> 8 & 0xFF;
    arr[L++] = tmp & 0xFF;
  }
  return arr;
}
function tripletToBase64(num) {
  return lookup[num >> 18 & 0x3F] + lookup[num >> 12 & 0x3F] + lookup[num >> 6 & 0x3F] + lookup[num & 0x3F];
}
function encodeChunk(uint8, start, end) {
  var tmp;
  var output = [];
  for (var i = start; i < end; i += 3) {
    tmp = (uint8[i] << 16) + (uint8[i + 1] << 8) + uint8[i + 2];
    output.push(tripletToBase64(tmp));
  }
  return output.join('');
}
function fromByteArray(uint8) {
  if (!inited) {
    init();
  }
  var tmp;
  var len = uint8.length;
  var extraBytes = len % 3;
  var output = '';
  var parts = [];
  var maxChunkLength = 16383;
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, i + maxChunkLength > len2 ? len2 : i + maxChunkLength));
  }
  if (extraBytes === 1) {
    tmp = uint8[len - 1];
    output += lookup[tmp >> 2];
    output += lookup[tmp << 4 & 0x3F];
    output += '==';
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + uint8[len - 1];
    output += lookup[tmp >> 10];
    output += lookup[tmp >> 4 & 0x3F];
    output += lookup[tmp << 2 & 0x3F];
    output += '=';
  }
  parts.push(output);
  return parts.join('');
}
function read(buffer, offset, isLE, mLen, nBytes) {
  var e, m;
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var nBits = -7;
  var i = isLE ? nBytes - 1 : 0;
  var d = isLE ? -1 : 1;
  var s = buffer[offset + i];
  i += d;
  e = s & (1 << -nBits) - 1;
  s >>= -nBits;
  nBits += eLen;
  for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {}
  m = e & (1 << -nBits) - 1;
  e >>= -nBits;
  nBits += mLen;
  for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {}
  if (e === 0) {
    e = 1 - eBias;
  } else if (e === eMax) {
    return m ? NaN : (s ? -1 : 1) * Infinity;
  } else {
    m = m + Math.pow(2, mLen);
    e = e - eBias;
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
}
function write(buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c;
  var eLen = nBytes * 8 - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
  var i = isLE ? 0 : nBytes - 1;
  var d = isLE ? 1 : -1;
  var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
  value = Math.abs(value);
  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0;
    e = eMax;
  } else {
    e = Math.floor(Math.log(value) / Math.LN2);
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--;
      c *= 2;
    }
    if (e + eBias >= 1) {
      value += rt / c;
    } else {
      value += rt * Math.pow(2, 1 - eBias);
    }
    if (value * c >= 2) {
      e++;
      c /= 2;
    }
    if (e + eBias >= eMax) {
      m = 0;
      e = eMax;
    } else if (e + eBias >= 1) {
      m = (value * c - 1) * Math.pow(2, mLen);
      e = e + eBias;
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
      e = 0;
    }
  }
  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}
  e = e << mLen | m;
  eLen += mLen;
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}
  buffer[offset + i - d] |= s * 128;
}
var toString = {}.toString;
var isArray = Array.isArray || function (arr) {
  return toString.call(arr) == '[object Array]';
};

/*!
  * The buffer module from node.js, for the browser.
  *
  * @author   Feross Aboukhadijeh <feross@feross.org> <http://feross.org>
  * @license  MIT
  */
var INSPECT_MAX_BYTES = 50;
Buffer$1.TYPED_ARRAY_SUPPORT = __webpack_require__.g.TYPED_ARRAY_SUPPORT !== undefined ? __webpack_require__.g.TYPED_ARRAY_SUPPORT : true;
var _kMaxLength = kMaxLength();
function kMaxLength() {
  return Buffer$1.TYPED_ARRAY_SUPPORT ? 0x7fffffff : 0x3fffffff;
}
function createBuffer(that, length) {
  if (kMaxLength() < length) {
    throw new RangeError('Invalid typed array length');
  }
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    that = new Uint8Array(length);
    that.__proto__ = Buffer$1.prototype;
  } else {
    if (that === null) {
      that = new Buffer$1(length);
    }
    that.length = length;
  }
  return that;
}
function Buffer$1(arg, encodingOrOffset, length) {
  if (!Buffer$1.TYPED_ARRAY_SUPPORT && !(this instanceof Buffer$1)) {
    return new Buffer$1(arg, encodingOrOffset, length);
  }
  if (typeof arg === 'number') {
    if (typeof encodingOrOffset === 'string') {
      throw new Error('If encoding is specified then the first argument must be a string');
    }
    return allocUnsafe(this, arg);
  }
  return from(this, arg, encodingOrOffset, length);
}
Buffer$1.poolSize = 8192;
Buffer$1._augment = function (arr) {
  arr.__proto__ = Buffer$1.prototype;
  return arr;
};
function from(that, value, encodingOrOffset, length) {
  if (typeof value === 'number') {
    throw new TypeError('"value" argument must not be a number');
  }
  if (typeof ArrayBuffer !== 'undefined' && value instanceof ArrayBuffer) {
    return fromArrayBuffer(that, value, encodingOrOffset, length);
  }
  if (typeof value === 'string') {
    return fromString(that, value, encodingOrOffset);
  }
  return fromObject(that, value);
}
Buffer$1.from = function (value, encodingOrOffset, length) {
  return from(null, value, encodingOrOffset, length);
};
if (Buffer$1.TYPED_ARRAY_SUPPORT) {
  Buffer$1.prototype.__proto__ = Uint8Array.prototype;
  Buffer$1.__proto__ = Uint8Array;
}
function assertSize(size) {
  if (typeof size !== 'number') {
    throw new TypeError('"size" argument must be a number');
  } else if (size < 0) {
    throw new RangeError('"size" argument must not be negative');
  }
}
function alloc(that, size, fill, encoding) {
  assertSize(size);
  if (size <= 0) {
    return createBuffer(that, size);
  }
  if (fill !== undefined) {
    return typeof encoding === 'string' ? createBuffer(that, size).fill(fill, encoding) : createBuffer(that, size).fill(fill);
  }
  return createBuffer(that, size);
}
Buffer$1.alloc = function (size, fill, encoding) {
  return alloc(null, size, fill, encoding);
};
function allocUnsafe(that, size) {
  assertSize(size);
  that = createBuffer(that, size < 0 ? 0 : checked(size) | 0);
  if (!Buffer$1.TYPED_ARRAY_SUPPORT) {
    for (var i = 0; i < size; ++i) {
      that[i] = 0;
    }
  }
  return that;
}
Buffer$1.allocUnsafe = function (size) {
  return allocUnsafe(null, size);
};
Buffer$1.allocUnsafeSlow = function (size) {
  return allocUnsafe(null, size);
};
function fromString(that, string, encoding) {
  if (typeof encoding !== 'string' || encoding === '') {
    encoding = 'utf8';
  }
  if (!Buffer$1.isEncoding(encoding)) {
    throw new TypeError('"encoding" must be a valid string encoding');
  }
  var length = byteLength(string, encoding) | 0;
  that = createBuffer(that, length);
  var actual = that.write(string, encoding);
  if (actual !== length) {
    that = that.slice(0, actual);
  }
  return that;
}
function fromArrayLike(that, array) {
  var length = array.length < 0 ? 0 : checked(array.length) | 0;
  that = createBuffer(that, length);
  for (var i = 0; i < length; i += 1) {
    that[i] = array[i] & 255;
  }
  return that;
}
function fromArrayBuffer(that, array, byteOffset, length) {
  array.byteLength;
  if (byteOffset < 0 || array.byteLength < byteOffset) {
    throw new RangeError('\'offset\' is out of bounds');
  }
  if (array.byteLength < byteOffset + (length || 0)) {
    throw new RangeError('\'length\' is out of bounds');
  }
  if (byteOffset === undefined && length === undefined) {
    array = new Uint8Array(array);
  } else if (length === undefined) {
    array = new Uint8Array(array, byteOffset);
  } else {
    array = new Uint8Array(array, byteOffset, length);
  }
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    that = array;
    that.__proto__ = Buffer$1.prototype;
  } else {
    that = fromArrayLike(that, array);
  }
  return that;
}
function fromObject(that, obj) {
  if (internalIsBuffer(obj)) {
    var len = checked(obj.length) | 0;
    that = createBuffer(that, len);
    if (that.length === 0) {
      return that;
    }
    obj.copy(that, 0, 0, len);
    return that;
  }
  if (obj) {
    if (typeof ArrayBuffer !== 'undefined' && obj.buffer instanceof ArrayBuffer || 'length' in obj) {
      if (typeof obj.length !== 'number' || isnan(obj.length)) {
        return createBuffer(that, 0);
      }
      return fromArrayLike(that, obj);
    }
    if (obj.type === 'Buffer' && isArray(obj.data)) {
      return fromArrayLike(that, obj.data);
    }
  }
  throw new TypeError('First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.');
}
function checked(length) {
  if (length >= kMaxLength()) {
    throw new RangeError('Attempt to allocate Buffer larger than maximum ' + 'size: 0x' + kMaxLength().toString(16) + ' bytes');
  }
  return length | 0;
}
function SlowBuffer(length) {
  if (+length != length) {
    length = 0;
  }
  return Buffer$1.alloc(+length);
}
Buffer$1.isBuffer = isBuffer;
function internalIsBuffer(b) {
  return !!(b != null && b._isBuffer);
}
Buffer$1.compare = function compare(a, b) {
  if (!internalIsBuffer(a) || !internalIsBuffer(b)) {
    throw new TypeError('Arguments must be Buffers');
  }
  if (a === b) return 0;
  var x = a.length;
  var y = b.length;
  for (var i = 0, len = Math.min(x, y); i < len; ++i) {
    if (a[i] !== b[i]) {
      x = a[i];
      y = b[i];
      break;
    }
  }
  if (x < y) return -1;
  if (y < x) return 1;
  return 0;
};
Buffer$1.isEncoding = function isEncoding(encoding) {
  switch (String(encoding).toLowerCase()) {
    case 'hex':
    case 'utf8':
    case 'utf-8':
    case 'ascii':
    case 'latin1':
    case 'binary':
    case 'base64':
    case 'ucs2':
    case 'ucs-2':
    case 'utf16le':
    case 'utf-16le':
      return true;
    default:
      return false;
  }
};
Buffer$1.concat = function concat(list, length) {
  if (!isArray(list)) {
    throw new TypeError('"list" argument must be an Array of Buffers');
  }
  if (list.length === 0) {
    return Buffer$1.alloc(0);
  }
  var i;
  if (length === undefined) {
    length = 0;
    for (i = 0; i < list.length; ++i) {
      length += list[i].length;
    }
  }
  var buffer = Buffer$1.allocUnsafe(length);
  var pos = 0;
  for (i = 0; i < list.length; ++i) {
    var buf = list[i];
    if (!internalIsBuffer(buf)) {
      throw new TypeError('"list" argument must be an Array of Buffers');
    }
    buf.copy(buffer, pos);
    pos += buf.length;
  }
  return buffer;
};
function byteLength(string, encoding) {
  if (internalIsBuffer(string)) {
    return string.length;
  }
  if (typeof ArrayBuffer !== 'undefined' && typeof ArrayBuffer.isView === 'function' && (ArrayBuffer.isView(string) || string instanceof ArrayBuffer)) {
    return string.byteLength;
  }
  if (typeof string !== 'string') {
    string = '' + string;
  }
  var len = string.length;
  if (len === 0) return 0;
  var loweredCase = false;
  for (;;) {
    switch (encoding) {
      case 'ascii':
      case 'latin1':
      case 'binary':
        return len;
      case 'utf8':
      case 'utf-8':
      case undefined:
        return utf8ToBytes(string).length;
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return len * 2;
      case 'hex':
        return len >>> 1;
      case 'base64':
        return base64ToBytes(string).length;
      default:
        if (loweredCase) return utf8ToBytes(string).length;
        encoding = ('' + encoding).toLowerCase();
        loweredCase = true;
    }
  }
}
Buffer$1.byteLength = byteLength;
function slowToString(encoding, start, end) {
  var loweredCase = false;
  if (start === undefined || start < 0) {
    start = 0;
  }
  if (start > this.length) {
    return '';
  }
  if (end === undefined || end > this.length) {
    end = this.length;
  }
  if (end <= 0) {
    return '';
  }
  end >>>= 0;
  start >>>= 0;
  if (end <= start) {
    return '';
  }
  if (!encoding) encoding = 'utf8';
  while (true) {
    switch (encoding) {
      case 'hex':
        return hexSlice(this, start, end);
      case 'utf8':
      case 'utf-8':
        return utf8Slice(this, start, end);
      case 'ascii':
        return asciiSlice(this, start, end);
      case 'latin1':
      case 'binary':
        return latin1Slice(this, start, end);
      case 'base64':
        return base64Slice(this, start, end);
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return utf16leSlice(this, start, end);
      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding);
        encoding = (encoding + '').toLowerCase();
        loweredCase = true;
    }
  }
}
Buffer$1.prototype._isBuffer = true;
function swap(b, n, m) {
  var i = b[n];
  b[n] = b[m];
  b[m] = i;
}
Buffer$1.prototype.swap16 = function swap16() {
  var len = this.length;
  if (len % 2 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 16-bits');
  }
  for (var i = 0; i < len; i += 2) {
    swap(this, i, i + 1);
  }
  return this;
};
Buffer$1.prototype.swap32 = function swap32() {
  var len = this.length;
  if (len % 4 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 32-bits');
  }
  for (var i = 0; i < len; i += 4) {
    swap(this, i, i + 3);
    swap(this, i + 1, i + 2);
  }
  return this;
};
Buffer$1.prototype.swap64 = function swap64() {
  var len = this.length;
  if (len % 8 !== 0) {
    throw new RangeError('Buffer size must be a multiple of 64-bits');
  }
  for (var i = 0; i < len; i += 8) {
    swap(this, i, i + 7);
    swap(this, i + 1, i + 6);
    swap(this, i + 2, i + 5);
    swap(this, i + 3, i + 4);
  }
  return this;
};
Buffer$1.prototype.toString = function toString() {
  var length = this.length | 0;
  if (length === 0) return '';
  if (arguments.length === 0) return utf8Slice(this, 0, length);
  return slowToString.apply(this, arguments);
};
Buffer$1.prototype.equals = function equals(b) {
  if (!internalIsBuffer(b)) throw new TypeError('Argument must be a Buffer');
  if (this === b) return true;
  return Buffer$1.compare(this, b) === 0;
};
Buffer$1.prototype.inspect = function inspect() {
  var str = '';
  var max = INSPECT_MAX_BYTES;
  if (this.length > 0) {
    str = this.toString('hex', 0, max).match(/.{2}/g).join(' ');
    if (this.length > max) str += ' ... ';
  }
  return '<Buffer ' + str + '>';
};
Buffer$1.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
  if (!internalIsBuffer(target)) {
    throw new TypeError('Argument must be a Buffer');
  }
  if (start === undefined) {
    start = 0;
  }
  if (end === undefined) {
    end = target ? target.length : 0;
  }
  if (thisStart === undefined) {
    thisStart = 0;
  }
  if (thisEnd === undefined) {
    thisEnd = this.length;
  }
  if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
    throw new RangeError('out of range index');
  }
  if (thisStart >= thisEnd && start >= end) {
    return 0;
  }
  if (thisStart >= thisEnd) {
    return -1;
  }
  if (start >= end) {
    return 1;
  }
  start >>>= 0;
  end >>>= 0;
  thisStart >>>= 0;
  thisEnd >>>= 0;
  if (this === target) return 0;
  var x = thisEnd - thisStart;
  var y = end - start;
  var len = Math.min(x, y);
  var thisCopy = this.slice(thisStart, thisEnd);
  var targetCopy = target.slice(start, end);
  for (var i = 0; i < len; ++i) {
    if (thisCopy[i] !== targetCopy[i]) {
      x = thisCopy[i];
      y = targetCopy[i];
      break;
    }
  }
  if (x < y) return -1;
  if (y < x) return 1;
  return 0;
};
function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
  if (buffer.length === 0) return -1;
  if (typeof byteOffset === 'string') {
    encoding = byteOffset;
    byteOffset = 0;
  } else if (byteOffset > 0x7fffffff) {
    byteOffset = 0x7fffffff;
  } else if (byteOffset < -0x80000000) {
    byteOffset = -0x80000000;
  }
  byteOffset = +byteOffset;
  if (isNaN(byteOffset)) {
    byteOffset = dir ? 0 : buffer.length - 1;
  }
  if (byteOffset < 0) byteOffset = buffer.length + byteOffset;
  if (byteOffset >= buffer.length) {
    if (dir) return -1;else byteOffset = buffer.length - 1;
  } else if (byteOffset < 0) {
    if (dir) byteOffset = 0;else return -1;
  }
  if (typeof val === 'string') {
    val = Buffer$1.from(val, encoding);
  }
  if (internalIsBuffer(val)) {
    if (val.length === 0) {
      return -1;
    }
    return arrayIndexOf(buffer, val, byteOffset, encoding, dir);
  } else if (typeof val === 'number') {
    val = val & 0xFF;
    if (Buffer$1.TYPED_ARRAY_SUPPORT && typeof Uint8Array.prototype.indexOf === 'function') {
      if (dir) {
        return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset);
      } else {
        return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset);
      }
    }
    return arrayIndexOf(buffer, [val], byteOffset, encoding, dir);
  }
  throw new TypeError('val must be string, number or Buffer');
}
function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
  var indexSize = 1;
  var arrLength = arr.length;
  var valLength = val.length;
  if (encoding !== undefined) {
    encoding = String(encoding).toLowerCase();
    if (encoding === 'ucs2' || encoding === 'ucs-2' || encoding === 'utf16le' || encoding === 'utf-16le') {
      if (arr.length < 2 || val.length < 2) {
        return -1;
      }
      indexSize = 2;
      arrLength /= 2;
      valLength /= 2;
      byteOffset /= 2;
    }
  }
  function read$$1(buf, i) {
    if (indexSize === 1) {
      return buf[i];
    } else {
      return buf.readUInt16BE(i * indexSize);
    }
  }
  var i;
  if (dir) {
    var foundIndex = -1;
    for (i = byteOffset; i < arrLength; i++) {
      if (read$$1(arr, i) === read$$1(val, foundIndex === -1 ? 0 : i - foundIndex)) {
        if (foundIndex === -1) foundIndex = i;
        if (i - foundIndex + 1 === valLength) return foundIndex * indexSize;
      } else {
        if (foundIndex !== -1) i -= i - foundIndex;
        foundIndex = -1;
      }
    }
  } else {
    if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
    for (i = byteOffset; i >= 0; i--) {
      var found = true;
      for (var j = 0; j < valLength; j++) {
        if (read$$1(arr, i + j) !== read$$1(val, j)) {
          found = false;
          break;
        }
      }
      if (found) return i;
    }
  }
  return -1;
}
Buffer$1.prototype.includes = function includes(val, byteOffset, encoding) {
  return this.indexOf(val, byteOffset, encoding) !== -1;
};
Buffer$1.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
};
Buffer$1.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
  return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
};
function hexWrite(buf, string, offset, length) {
  offset = Number(offset) || 0;
  var remaining = buf.length - offset;
  if (!length) {
    length = remaining;
  } else {
    length = Number(length);
    if (length > remaining) {
      length = remaining;
    }
  }
  var strLen = string.length;
  if (strLen % 2 !== 0) throw new TypeError('Invalid hex string');
  if (length > strLen / 2) {
    length = strLen / 2;
  }
  for (var i = 0; i < length; ++i) {
    var parsed = parseInt(string.substr(i * 2, 2), 16);
    if (isNaN(parsed)) return i;
    buf[offset + i] = parsed;
  }
  return i;
}
function utf8Write(buf, string, offset, length) {
  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
}
function asciiWrite(buf, string, offset, length) {
  return blitBuffer(asciiToBytes(string), buf, offset, length);
}
function latin1Write(buf, string, offset, length) {
  return asciiWrite(buf, string, offset, length);
}
function base64Write(buf, string, offset, length) {
  return blitBuffer(base64ToBytes(string), buf, offset, length);
}
function ucs2Write(buf, string, offset, length) {
  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
}
Buffer$1.prototype.write = function write$$1(string, offset, length, encoding) {
  if (offset === undefined) {
    encoding = 'utf8';
    length = this.length;
    offset = 0;
  } else if (length === undefined && typeof offset === 'string') {
    encoding = offset;
    length = this.length;
    offset = 0;
  } else if (isFinite(offset)) {
    offset = offset | 0;
    if (isFinite(length)) {
      length = length | 0;
      if (encoding === undefined) encoding = 'utf8';
    } else {
      encoding = length;
      length = undefined;
    }
  } else {
    throw new Error('Buffer.write(string, encoding, offset[, length]) is no longer supported');
  }
  var remaining = this.length - offset;
  if (length === undefined || length > remaining) length = remaining;
  if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) {
    throw new RangeError('Attempt to write outside buffer bounds');
  }
  if (!encoding) encoding = 'utf8';
  var loweredCase = false;
  for (;;) {
    switch (encoding) {
      case 'hex':
        return hexWrite(this, string, offset, length);
      case 'utf8':
      case 'utf-8':
        return utf8Write(this, string, offset, length);
      case 'ascii':
        return asciiWrite(this, string, offset, length);
      case 'latin1':
      case 'binary':
        return latin1Write(this, string, offset, length);
      case 'base64':
        return base64Write(this, string, offset, length);
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return ucs2Write(this, string, offset, length);
      default:
        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding);
        encoding = ('' + encoding).toLowerCase();
        loweredCase = true;
    }
  }
};
Buffer$1.prototype.toJSON = function toJSON() {
  return {
    type: 'Buffer',
    data: Array.prototype.slice.call(this._arr || this, 0)
  };
};
function base64Slice(buf, start, end) {
  if (start === 0 && end === buf.length) {
    return fromByteArray(buf);
  } else {
    return fromByteArray(buf.slice(start, end));
  }
}
function utf8Slice(buf, start, end) {
  end = Math.min(buf.length, end);
  var res = [];
  var i = start;
  while (i < end) {
    var firstByte = buf[i];
    var codePoint = null;
    var bytesPerSequence = firstByte > 0xEF ? 4 : firstByte > 0xDF ? 3 : firstByte > 0xBF ? 2 : 1;
    if (i + bytesPerSequence <= end) {
      var secondByte, thirdByte, fourthByte, tempCodePoint;
      switch (bytesPerSequence) {
        case 1:
          if (firstByte < 0x80) {
            codePoint = firstByte;
          }
          break;
        case 2:
          secondByte = buf[i + 1];
          if ((secondByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0x1F) << 0x6 | secondByte & 0x3F;
            if (tempCodePoint > 0x7F) {
              codePoint = tempCodePoint;
            }
          }
          break;
        case 3:
          secondByte = buf[i + 1];
          thirdByte = buf[i + 2];
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | thirdByte & 0x3F;
            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
              codePoint = tempCodePoint;
            }
          }
          break;
        case 4:
          secondByte = buf[i + 1];
          thirdByte = buf[i + 2];
          fourthByte = buf[i + 3];
          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | fourthByte & 0x3F;
            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
              codePoint = tempCodePoint;
            }
          }
      }
    }
    if (codePoint === null) {
      codePoint = 0xFFFD;
      bytesPerSequence = 1;
    } else if (codePoint > 0xFFFF) {
      codePoint -= 0x10000;
      res.push(codePoint >>> 10 & 0x3FF | 0xD800);
      codePoint = 0xDC00 | codePoint & 0x3FF;
    }
    res.push(codePoint);
    i += bytesPerSequence;
  }
  return decodeCodePointsArray(res);
}
var MAX_ARGUMENTS_LENGTH = 0x1000;
function decodeCodePointsArray(codePoints) {
  var len = codePoints.length;
  if (len <= MAX_ARGUMENTS_LENGTH) {
    return String.fromCharCode.apply(String, codePoints);
  }
  var res = '';
  var i = 0;
  while (i < len) {
    res += String.fromCharCode.apply(String, codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH));
  }
  return res;
}
function asciiSlice(buf, start, end) {
  var ret = '';
  end = Math.min(buf.length, end);
  for (var i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i] & 0x7F);
  }
  return ret;
}
function latin1Slice(buf, start, end) {
  var ret = '';
  end = Math.min(buf.length, end);
  for (var i = start; i < end; ++i) {
    ret += String.fromCharCode(buf[i]);
  }
  return ret;
}
function hexSlice(buf, start, end) {
  var len = buf.length;
  if (!start || start < 0) start = 0;
  if (!end || end < 0 || end > len) end = len;
  var out = '';
  for (var i = start; i < end; ++i) {
    out += toHex(buf[i]);
  }
  return out;
}
function utf16leSlice(buf, start, end) {
  var bytes = buf.slice(start, end);
  var res = '';
  for (var i = 0; i < bytes.length; i += 2) {
    res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
  }
  return res;
}
Buffer$1.prototype.slice = function slice(start, end) {
  var len = this.length;
  start = ~~start;
  end = end === undefined ? len : ~~end;
  if (start < 0) {
    start += len;
    if (start < 0) start = 0;
  } else if (start > len) {
    start = len;
  }
  if (end < 0) {
    end += len;
    if (end < 0) end = 0;
  } else if (end > len) {
    end = len;
  }
  if (end < start) end = start;
  var newBuf;
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    newBuf = this.subarray(start, end);
    newBuf.__proto__ = Buffer$1.prototype;
  } else {
    var sliceLen = end - start;
    newBuf = new Buffer$1(sliceLen, undefined);
    for (var i = 0; i < sliceLen; ++i) {
      newBuf[i] = this[i + start];
    }
  }
  return newBuf;
};
function checkOffset(offset, ext, length) {
  if (offset % 1 !== 0 || offset < 0) throw new RangeError('offset is not uint');
  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length');
}
Buffer$1.prototype.readUIntLE = function readUIntLE(offset, byteLength, noAssert) {
  offset = offset | 0;
  byteLength = byteLength | 0;
  if (!noAssert) checkOffset(offset, byteLength, this.length);
  var val = this[offset];
  var mul = 1;
  var i = 0;
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul;
  }
  return val;
};
Buffer$1.prototype.readUIntBE = function readUIntBE(offset, byteLength, noAssert) {
  offset = offset | 0;
  byteLength = byteLength | 0;
  if (!noAssert) {
    checkOffset(offset, byteLength, this.length);
  }
  var val = this[offset + --byteLength];
  var mul = 1;
  while (byteLength > 0 && (mul *= 0x100)) {
    val += this[offset + --byteLength] * mul;
  }
  return val;
};
Buffer$1.prototype.readUInt8 = function readUInt8(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 1, this.length);
  return this[offset];
};
Buffer$1.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length);
  return this[offset] | this[offset + 1] << 8;
};
Buffer$1.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length);
  return this[offset] << 8 | this[offset + 1];
};
Buffer$1.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length);
  return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 0x1000000;
};
Buffer$1.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length);
  return this[offset] * 0x1000000 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
};
Buffer$1.prototype.readIntLE = function readIntLE(offset, byteLength, noAssert) {
  offset = offset | 0;
  byteLength = byteLength | 0;
  if (!noAssert) checkOffset(offset, byteLength, this.length);
  var val = this[offset];
  var mul = 1;
  var i = 0;
  while (++i < byteLength && (mul *= 0x100)) {
    val += this[offset + i] * mul;
  }
  mul *= 0x80;
  if (val >= mul) val -= Math.pow(2, 8 * byteLength);
  return val;
};
Buffer$1.prototype.readIntBE = function readIntBE(offset, byteLength, noAssert) {
  offset = offset | 0;
  byteLength = byteLength | 0;
  if (!noAssert) checkOffset(offset, byteLength, this.length);
  var i = byteLength;
  var mul = 1;
  var val = this[offset + --i];
  while (i > 0 && (mul *= 0x100)) {
    val += this[offset + --i] * mul;
  }
  mul *= 0x80;
  if (val >= mul) val -= Math.pow(2, 8 * byteLength);
  return val;
};
Buffer$1.prototype.readInt8 = function readInt8(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 1, this.length);
  if (!(this[offset] & 0x80)) return this[offset];
  return (0xff - this[offset] + 1) * -1;
};
Buffer$1.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length);
  var val = this[offset] | this[offset + 1] << 8;
  return val & 0x8000 ? val | 0xFFFF0000 : val;
};
Buffer$1.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 2, this.length);
  var val = this[offset + 1] | this[offset] << 8;
  return val & 0x8000 ? val | 0xFFFF0000 : val;
};
Buffer$1.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length);
  return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
};
Buffer$1.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length);
  return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
};
Buffer$1.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length);
  return read(this, offset, true, 23, 4);
};
Buffer$1.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 4, this.length);
  return read(this, offset, false, 23, 4);
};
Buffer$1.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 8, this.length);
  return read(this, offset, true, 52, 8);
};
Buffer$1.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
  if (!noAssert) checkOffset(offset, 8, this.length);
  return read(this, offset, false, 52, 8);
};
function checkInt(buf, value, offset, ext, max, min) {
  if (!internalIsBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
  if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
  if (offset + ext > buf.length) throw new RangeError('Index out of range');
}
Buffer$1.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength, noAssert) {
  value = +value;
  offset = offset | 0;
  byteLength = byteLength | 0;
  if (!noAssert) {
    var maxBytes = Math.pow(2, 8 * byteLength) - 1;
    checkInt(this, value, offset, byteLength, maxBytes, 0);
  }
  var mul = 1;
  var i = 0;
  this[offset] = value & 0xFF;
  while (++i < byteLength && (mul *= 0x100)) {
    this[offset + i] = value / mul & 0xFF;
  }
  return offset + byteLength;
};
Buffer$1.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength, noAssert) {
  value = +value;
  offset = offset | 0;
  byteLength = byteLength | 0;
  if (!noAssert) {
    var maxBytes = Math.pow(2, 8 * byteLength) - 1;
    checkInt(this, value, offset, byteLength, maxBytes, 0);
  }
  var i = byteLength - 1;
  var mul = 1;
  this[offset + i] = value & 0xFF;
  while (--i >= 0 && (mul *= 0x100)) {
    this[offset + i] = value / mul & 0xFF;
  }
  return offset + byteLength;
};
Buffer$1.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0);
  if (!Buffer$1.TYPED_ARRAY_SUPPORT) value = Math.floor(value);
  this[offset] = value & 0xff;
  return offset + 1;
};
function objectWriteUInt16(buf, value, offset, littleEndian) {
  if (value < 0) value = 0xffff + value + 1;
  for (var i = 0, j = Math.min(buf.length - offset, 2); i < j; ++i) {
    buf[offset + i] = (value & 0xff << 8 * (littleEndian ? i : 1 - i)) >>> (littleEndian ? i : 1 - i) * 8;
  }
}
Buffer$1.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0);
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    this[offset] = value & 0xff;
    this[offset + 1] = value >>> 8;
  } else {
    objectWriteUInt16(this, value, offset, true);
  }
  return offset + 2;
};
Buffer$1.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0);
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    this[offset] = value >>> 8;
    this[offset + 1] = value & 0xff;
  } else {
    objectWriteUInt16(this, value, offset, false);
  }
  return offset + 2;
};
function objectWriteUInt32(buf, value, offset, littleEndian) {
  if (value < 0) value = 0xffffffff + value + 1;
  for (var i = 0, j = Math.min(buf.length - offset, 4); i < j; ++i) {
    buf[offset + i] = value >>> (littleEndian ? i : 3 - i) * 8 & 0xff;
  }
}
Buffer$1.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0);
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    this[offset + 3] = value >>> 24;
    this[offset + 2] = value >>> 16;
    this[offset + 1] = value >>> 8;
    this[offset] = value & 0xff;
  } else {
    objectWriteUInt32(this, value, offset, true);
  }
  return offset + 4;
};
Buffer$1.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0);
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    this[offset] = value >>> 24;
    this[offset + 1] = value >>> 16;
    this[offset + 2] = value >>> 8;
    this[offset + 3] = value & 0xff;
  } else {
    objectWriteUInt32(this, value, offset, false);
  }
  return offset + 4;
};
Buffer$1.prototype.writeIntLE = function writeIntLE(value, offset, byteLength, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) {
    var limit = Math.pow(2, 8 * byteLength - 1);
    checkInt(this, value, offset, byteLength, limit - 1, -limit);
  }
  var i = 0;
  var mul = 1;
  var sub = 0;
  this[offset] = value & 0xFF;
  while (++i < byteLength && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
      sub = 1;
    }
    this[offset + i] = (value / mul >> 0) - sub & 0xFF;
  }
  return offset + byteLength;
};
Buffer$1.prototype.writeIntBE = function writeIntBE(value, offset, byteLength, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) {
    var limit = Math.pow(2, 8 * byteLength - 1);
    checkInt(this, value, offset, byteLength, limit - 1, -limit);
  }
  var i = byteLength - 1;
  var mul = 1;
  var sub = 0;
  this[offset + i] = value & 0xFF;
  while (--i >= 0 && (mul *= 0x100)) {
    if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
      sub = 1;
    }
    this[offset + i] = (value / mul >> 0) - sub & 0xFF;
  }
  return offset + byteLength;
};
Buffer$1.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80);
  if (!Buffer$1.TYPED_ARRAY_SUPPORT) value = Math.floor(value);
  if (value < 0) value = 0xff + value + 1;
  this[offset] = value & 0xff;
  return offset + 1;
};
Buffer$1.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000);
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    this[offset] = value & 0xff;
    this[offset + 1] = value >>> 8;
  } else {
    objectWriteUInt16(this, value, offset, true);
  }
  return offset + 2;
};
Buffer$1.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000);
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    this[offset] = value >>> 8;
    this[offset + 1] = value & 0xff;
  } else {
    objectWriteUInt16(this, value, offset, false);
  }
  return offset + 2;
};
Buffer$1.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000);
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    this[offset] = value & 0xff;
    this[offset + 1] = value >>> 8;
    this[offset + 2] = value >>> 16;
    this[offset + 3] = value >>> 24;
  } else {
    objectWriteUInt32(this, value, offset, true);
  }
  return offset + 4;
};
Buffer$1.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
  value = +value;
  offset = offset | 0;
  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000);
  if (value < 0) value = 0xffffffff + value + 1;
  if (Buffer$1.TYPED_ARRAY_SUPPORT) {
    this[offset] = value >>> 24;
    this[offset + 1] = value >>> 16;
    this[offset + 2] = value >>> 8;
    this[offset + 3] = value & 0xff;
  } else {
    objectWriteUInt32(this, value, offset, false);
  }
  return offset + 4;
};
function checkIEEE754(buf, value, offset, ext, max, min) {
  if (offset + ext > buf.length) throw new RangeError('Index out of range');
  if (offset < 0) throw new RangeError('Index out of range');
}
function writeFloat(buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38);
  }
  write(buf, value, offset, littleEndian, 23, 4);
  return offset + 4;
}
Buffer$1.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
  return writeFloat(this, value, offset, true, noAssert);
};
Buffer$1.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
  return writeFloat(this, value, offset, false, noAssert);
};
function writeDouble(buf, value, offset, littleEndian, noAssert) {
  if (!noAssert) {
    checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308);
  }
  write(buf, value, offset, littleEndian, 52, 8);
  return offset + 8;
}
Buffer$1.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
  return writeDouble(this, value, offset, true, noAssert);
};
Buffer$1.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
  return writeDouble(this, value, offset, false, noAssert);
};
Buffer$1.prototype.copy = function copy(target, targetStart, start, end) {
  if (!start) start = 0;
  if (!end && end !== 0) end = this.length;
  if (targetStart >= target.length) targetStart = target.length;
  if (!targetStart) targetStart = 0;
  if (end > 0 && end < start) end = start;
  if (end === start) return 0;
  if (target.length === 0 || this.length === 0) return 0;
  if (targetStart < 0) {
    throw new RangeError('targetStart out of bounds');
  }
  if (start < 0 || start >= this.length) throw new RangeError('sourceStart out of bounds');
  if (end < 0) throw new RangeError('sourceEnd out of bounds');
  if (end > this.length) end = this.length;
  if (target.length - targetStart < end - start) {
    end = target.length - targetStart + start;
  }
  var len = end - start;
  var i;
  if (this === target && start < targetStart && targetStart < end) {
    for (i = len - 1; i >= 0; --i) {
      target[i + targetStart] = this[i + start];
    }
  } else if (len < 1000 || !Buffer$1.TYPED_ARRAY_SUPPORT) {
    for (i = 0; i < len; ++i) {
      target[i + targetStart] = this[i + start];
    }
  } else {
    Uint8Array.prototype.set.call(target, this.subarray(start, start + len), targetStart);
  }
  return len;
};
Buffer$1.prototype.fill = function fill(val, start, end, encoding) {
  if (typeof val === 'string') {
    if (typeof start === 'string') {
      encoding = start;
      start = 0;
      end = this.length;
    } else if (typeof end === 'string') {
      encoding = end;
      end = this.length;
    }
    if (val.length === 1) {
      var code = val.charCodeAt(0);
      if (code < 256) {
        val = code;
      }
    }
    if (encoding !== undefined && typeof encoding !== 'string') {
      throw new TypeError('encoding must be a string');
    }
    if (typeof encoding === 'string' && !Buffer$1.isEncoding(encoding)) {
      throw new TypeError('Unknown encoding: ' + encoding);
    }
  } else if (typeof val === 'number') {
    val = val & 255;
  }
  if (start < 0 || this.length < start || this.length < end) {
    throw new RangeError('Out of range index');
  }
  if (end <= start) {
    return this;
  }
  start = start >>> 0;
  end = end === undefined ? this.length : end >>> 0;
  if (!val) val = 0;
  var i;
  if (typeof val === 'number') {
    for (i = start; i < end; ++i) {
      this[i] = val;
    }
  } else {
    var bytes = internalIsBuffer(val) ? val : utf8ToBytes(new Buffer$1(val, encoding).toString());
    var len = bytes.length;
    for (i = 0; i < end - start; ++i) {
      this[i + start] = bytes[i % len];
    }
  }
  return this;
};
var INVALID_BASE64_RE = /[^+\/0-9A-Za-z-_]/g;
function base64clean(str) {
  str = stringtrim(str).replace(INVALID_BASE64_RE, '');
  if (str.length < 2) return '';
  while (str.length % 4 !== 0) {
    str = str + '=';
  }
  return str;
}
function stringtrim(str) {
  if (str.trim) return str.trim();
  return str.replace(/^\s+|\s+$/g, '');
}
function toHex(n) {
  if (n < 16) return '0' + n.toString(16);
  return n.toString(16);
}
function utf8ToBytes(string, units) {
  units = units || Infinity;
  var codePoint;
  var length = string.length;
  var leadSurrogate = null;
  var bytes = [];
  for (var i = 0; i < length; ++i) {
    codePoint = string.charCodeAt(i);
    if (codePoint > 0xD7FF && codePoint < 0xE000) {
      if (!leadSurrogate) {
        if (codePoint > 0xDBFF) {
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
          continue;
        } else if (i + 1 === length) {
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
          continue;
        }
        leadSurrogate = codePoint;
        continue;
      }
      if (codePoint < 0xDC00) {
        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
        leadSurrogate = codePoint;
        continue;
      }
      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000;
    } else if (leadSurrogate) {
      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
    }
    leadSurrogate = null;
    if (codePoint < 0x80) {
      if ((units -= 1) < 0) break;
      bytes.push(codePoint);
    } else if (codePoint < 0x800) {
      if ((units -= 2) < 0) break;
      bytes.push(codePoint >> 0x6 | 0xC0, codePoint & 0x3F | 0x80);
    } else if (codePoint < 0x10000) {
      if ((units -= 3) < 0) break;
      bytes.push(codePoint >> 0xC | 0xE0, codePoint >> 0x6 & 0x3F | 0x80, codePoint & 0x3F | 0x80);
    } else if (codePoint < 0x110000) {
      if ((units -= 4) < 0) break;
      bytes.push(codePoint >> 0x12 | 0xF0, codePoint >> 0xC & 0x3F | 0x80, codePoint >> 0x6 & 0x3F | 0x80, codePoint & 0x3F | 0x80);
    } else {
      throw new Error('Invalid code point');
    }
  }
  return bytes;
}
function asciiToBytes(str) {
  var byteArray = [];
  for (var i = 0; i < str.length; ++i) {
    byteArray.push(str.charCodeAt(i) & 0xFF);
  }
  return byteArray;
}
function utf16leToBytes(str, units) {
  var c, hi, lo;
  var byteArray = [];
  for (var i = 0; i < str.length; ++i) {
    if ((units -= 2) < 0) break;
    c = str.charCodeAt(i);
    hi = c >> 8;
    lo = c % 256;
    byteArray.push(lo);
    byteArray.push(hi);
  }
  return byteArray;
}
function base64ToBytes(str) {
  return toByteArray(base64clean(str));
}
function blitBuffer(src, dst, offset, length) {
  for (var i = 0; i < length; ++i) {
    if (i + offset >= dst.length || i >= src.length) break;
    dst[i + offset] = src[i];
  }
  return i;
}
function isnan(val) {
  return val !== val;
}
function isBuffer(obj) {
  return obj != null && (!!obj._isBuffer || isFastBuffer(obj) || isSlowBuffer(obj));
}
function isFastBuffer(obj) {
  return !!obj.constructor && typeof obj.constructor.isBuffer === 'function' && obj.constructor.isBuffer(obj);
}
function isSlowBuffer(obj) {
  return typeof obj.readFloatLE === 'function' && typeof obj.slice === 'function' && isFastBuffer(obj.slice(0, 0));
}
var bufferEs6 = /*#__PURE__*/Object.freeze({
  INSPECT_MAX_BYTES: INSPECT_MAX_BYTES,
  kMaxLength: _kMaxLength,
  Buffer: Buffer$1,
  SlowBuffer: SlowBuffer,
  isBuffer: isBuffer
});
function createCommonjsModule(fn, module) {
  return module = {
    exports: {}
  }, fn(module, module.exports), module.exports;
}
var map = (/* unused pure expression or super */ null && (Map));
var wasm = null;
var Long = /*#__PURE__*/
function () {
  function Long(low, high, unsigned) {
    this.low = low | 0;
    this.high = high | 0;
    this.unsigned = !!unsigned;
  }
  Long.prototype.__isLong__;
  Object.defineProperty(Long.prototype, "__isLong__", {
    value: true
  });
  function isLong(obj) {
    return (obj && obj["__isLong__"]) === true;
  }
  Long.isLong = isLong;
  var INT_CACHE = {};
  var UINT_CACHE = {};
  function fromInt(value, unsigned) {
    var obj, cachedObj, cache;
    if (unsigned) {
      value >>>= 0;
      if (cache = 0 <= value && value < 256) {
        cachedObj = UINT_CACHE[value];
        if (cachedObj) return cachedObj;
      }
      obj = fromBits(value, (value | 0) < 0 ? -1 : 0, true);
      if (cache) UINT_CACHE[value] = obj;
      return obj;
    } else {
      value |= 0;
      if (cache = -128 <= value && value < 128) {
        cachedObj = INT_CACHE[value];
        if (cachedObj) return cachedObj;
      }
      obj = fromBits(value, value < 0 ? -1 : 0, false);
      if (cache) INT_CACHE[value] = obj;
      return obj;
    }
  }
  Long.fromInt = fromInt;
  function fromNumber(value, unsigned) {
    if (isNaN(value)) return unsigned ? UZERO : ZERO;
    if (unsigned) {
      if (value < 0) return UZERO;
      if (value >= TWO_PWR_64_DBL) return MAX_UNSIGNED_VALUE;
    } else {
      if (value <= -TWO_PWR_63_DBL) return MIN_VALUE;
      if (value + 1 >= TWO_PWR_63_DBL) return MAX_VALUE;
    }
    if (value < 0) return fromNumber(-value, unsigned).neg();
    return fromBits(value % TWO_PWR_32_DBL | 0, value / TWO_PWR_32_DBL | 0, unsigned);
  }
  Long.fromNumber = fromNumber;
  function fromBits(lowBits, highBits, unsigned) {
    return new Long(lowBits, highBits, unsigned);
  }
  Long.fromBits = fromBits;
  var pow_dbl = Math.pow;
  function fromString$1(str, unsigned, radix) {
    if (str.length === 0) throw Error('empty string');
    if (str === "NaN" || str === "Infinity" || str === "+Infinity" || str === "-Infinity") return ZERO;
    if (typeof unsigned === 'number') {
      radix = unsigned, unsigned = false;
    } else {
      unsigned = !!unsigned;
    }
    radix = radix || 10;
    if (radix < 2 || 36 < radix) throw RangeError('radix');
    var p;
    if ((p = str.indexOf('-')) > 0) throw Error('interior hyphen');else if (p === 0) {
      return fromString$1(str.substring(1), unsigned, radix).neg();
    }
    var radixToPower = fromNumber(pow_dbl(radix, 8));
    var result = ZERO;
    for (var i = 0; i < str.length; i += 8) {
      var size = Math.min(8, str.length - i),
        value = parseInt(str.substring(i, i + size), radix);
      if (size < 8) {
        var power = fromNumber(pow_dbl(radix, size));
        result = result.mul(power).add(fromNumber(value));
      } else {
        result = result.mul(radixToPower);
        result = result.add(fromNumber(value));
      }
    }
    result.unsigned = unsigned;
    return result;
  }
  Long.fromString = fromString$1;
  function fromValue(val, unsigned) {
    if (typeof val === 'number') return fromNumber(val, unsigned);
    if (typeof val === 'string') return fromString$1(val, unsigned);
    return fromBits(val.low, val.high, typeof unsigned === 'boolean' ? unsigned : val.unsigned);
  }
  Long.fromValue = fromValue;
  var TWO_PWR_16_DBL = 1 << 16;
  var TWO_PWR_24_DBL = 1 << 24;
  var TWO_PWR_32_DBL = TWO_PWR_16_DBL * TWO_PWR_16_DBL;
  var TWO_PWR_64_DBL = TWO_PWR_32_DBL * TWO_PWR_32_DBL;
  var TWO_PWR_63_DBL = TWO_PWR_64_DBL / 2;
  var TWO_PWR_24 = fromInt(TWO_PWR_24_DBL);
  var ZERO = fromInt(0);
  Long.ZERO = ZERO;
  var UZERO = fromInt(0, true);
  Long.UZERO = UZERO;
  var ONE = fromInt(1);
  Long.ONE = ONE;
  var UONE = fromInt(1, true);
  Long.UONE = UONE;
  var NEG_ONE = fromInt(-1);
  Long.NEG_ONE = NEG_ONE;
  var MAX_VALUE = fromBits(0xFFFFFFFF | 0, 0x7FFFFFFF | 0, false);
  Long.MAX_VALUE = MAX_VALUE;
  var MAX_UNSIGNED_VALUE = fromBits(0xFFFFFFFF | 0, 0xFFFFFFFF | 0, true);
  Long.MAX_UNSIGNED_VALUE = MAX_UNSIGNED_VALUE;
  var MIN_VALUE = fromBits(0, 0x80000000 | 0, false);
  Long.MIN_VALUE = MIN_VALUE;
  var LongPrototype = Long.prototype;
  LongPrototype.toInt = function toInt() {
    return this.unsigned ? this.low >>> 0 : this.low;
  };
  LongPrototype.toNumber = function toNumber() {
    if (this.unsigned) return (this.high >>> 0) * TWO_PWR_32_DBL + (this.low >>> 0);
    return this.high * TWO_PWR_32_DBL + (this.low >>> 0);
  };
  LongPrototype.toString = function toString(radix) {
    radix = radix || 10;
    if (radix < 2 || 36 < radix) throw RangeError('radix');
    if (this.isZero()) return '0';
    if (this.isNegative()) {
      if (this.eq(MIN_VALUE)) {
        var radixLong = fromNumber(radix),
          div = this.div(radixLong),
          rem1 = div.mul(radixLong).sub(this);
        return div.toString(radix) + rem1.toInt().toString(radix);
      } else return '-' + this.neg().toString(radix);
    }
    var radixToPower = fromNumber(pow_dbl(radix, 6), this.unsigned),
      rem = this;
    var result = '';
    while (true) {
      var remDiv = rem.div(radixToPower),
        intval = rem.sub(remDiv.mul(radixToPower)).toInt() >>> 0,
        digits = intval.toString(radix);
      rem = remDiv;
      if (rem.isZero()) return digits + result;else {
        while (digits.length < 6) {
          digits = '0' + digits;
        }
        result = '' + digits + result;
      }
    }
  };
  LongPrototype.getHighBits = function getHighBits() {
    return this.high;
  };
  LongPrototype.getHighBitsUnsigned = function getHighBitsUnsigned() {
    return this.high >>> 0;
  };
  LongPrototype.getLowBits = function getLowBits() {
    return this.low;
  };
  LongPrototype.getLowBitsUnsigned = function getLowBitsUnsigned() {
    return this.low >>> 0;
  };
  LongPrototype.getNumBitsAbs = function getNumBitsAbs() {
    if (this.isNegative()) return this.eq(MIN_VALUE) ? 64 : this.neg().getNumBitsAbs();
    var val = this.high != 0 ? this.high : this.low;
    for (var bit = 31; bit > 0; bit--) {
      if ((val & 1 << bit) != 0) break;
    }
    return this.high != 0 ? bit + 33 : bit + 1;
  };
  LongPrototype.isZero = function isZero() {
    return this.high === 0 && this.low === 0;
  };
  LongPrototype.eqz = LongPrototype.isZero;
  LongPrototype.isNegative = function isNegative() {
    return !this.unsigned && this.high < 0;
  };
  LongPrototype.isPositive = function isPositive() {
    return this.unsigned || this.high >= 0;
  };
  LongPrototype.isOdd = function isOdd() {
    return (this.low & 1) === 1;
  };
  LongPrototype.isEven = function isEven() {
    return (this.low & 1) === 0;
  };
  LongPrototype.equals = function equals(other) {
    if (!isLong(other)) other = fromValue(other);
    if (this.unsigned !== other.unsigned && this.high >>> 31 === 1 && other.high >>> 31 === 1) return false;
    return this.high === other.high && this.low === other.low;
  };
  LongPrototype.eq = LongPrototype.equals;
  LongPrototype.notEquals = function notEquals(other) {
    return !this.eq(other);
  };
  LongPrototype.neq = LongPrototype.notEquals;
  LongPrototype.ne = LongPrototype.notEquals;
  LongPrototype.lessThan = function lessThan(other) {
    return this.comp(other) < 0;
  };
  LongPrototype.lt = LongPrototype.lessThan;
  LongPrototype.lessThanOrEqual = function lessThanOrEqual(other) {
    return this.comp(other) <= 0;
  };
  LongPrototype.lte = LongPrototype.lessThanOrEqual;
  LongPrototype.le = LongPrototype.lessThanOrEqual;
  LongPrototype.greaterThan = function greaterThan(other) {
    return this.comp(other) > 0;
  };
  LongPrototype.gt = LongPrototype.greaterThan;
  LongPrototype.greaterThanOrEqual = function greaterThanOrEqual(other) {
    return this.comp(other) >= 0;
  };
  LongPrototype.gte = LongPrototype.greaterThanOrEqual;
  LongPrototype.ge = LongPrototype.greaterThanOrEqual;
  LongPrototype.compare = function compare(other) {
    if (!isLong(other)) other = fromValue(other);
    if (this.eq(other)) return 0;
    var thisNeg = this.isNegative(),
      otherNeg = other.isNegative();
    if (thisNeg && !otherNeg) return -1;
    if (!thisNeg && otherNeg) return 1;
    if (!this.unsigned) return this.sub(other).isNegative() ? -1 : 1;
    return other.high >>> 0 > this.high >>> 0 || other.high === this.high && other.low >>> 0 > this.low >>> 0 ? -1 : 1;
  };
  LongPrototype.comp = LongPrototype.compare;
  LongPrototype.negate = function negate() {
    if (!this.unsigned && this.eq(MIN_VALUE)) return MIN_VALUE;
    return this.not().add(ONE);
  };
  LongPrototype.neg = LongPrototype.negate;
  LongPrototype.add = function add(addend) {
    if (!isLong(addend)) addend = fromValue(addend);
    var a48 = this.high >>> 16;
    var a32 = this.high & 0xFFFF;
    var a16 = this.low >>> 16;
    var a00 = this.low & 0xFFFF;
    var b48 = addend.high >>> 16;
    var b32 = addend.high & 0xFFFF;
    var b16 = addend.low >>> 16;
    var b00 = addend.low & 0xFFFF;
    var c48 = 0,
      c32 = 0,
      c16 = 0,
      c00 = 0;
    c00 += a00 + b00;
    c16 += c00 >>> 16;
    c00 &= 0xFFFF;
    c16 += a16 + b16;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c32 += a32 + b32;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c48 += a48 + b48;
    c48 &= 0xFFFF;
    return fromBits(c16 << 16 | c00, c48 << 16 | c32, this.unsigned);
  };
  LongPrototype.subtract = function subtract(subtrahend) {
    if (!isLong(subtrahend)) subtrahend = fromValue(subtrahend);
    return this.add(subtrahend.neg());
  };
  LongPrototype.sub = LongPrototype.subtract;
  LongPrototype.multiply = function multiply(multiplier) {
    if (this.isZero()) return ZERO;
    if (!isLong(multiplier)) multiplier = fromValue(multiplier);
    if (wasm) {
      var low = wasm.mul(this.low, this.high, multiplier.low, multiplier.high);
      return fromBits(low, wasm.get_high(), this.unsigned);
    }
    if (multiplier.isZero()) return ZERO;
    if (this.eq(MIN_VALUE)) return multiplier.isOdd() ? MIN_VALUE : ZERO;
    if (multiplier.eq(MIN_VALUE)) return this.isOdd() ? MIN_VALUE : ZERO;
    if (this.isNegative()) {
      if (multiplier.isNegative()) return this.neg().mul(multiplier.neg());else return this.neg().mul(multiplier).neg();
    } else if (multiplier.isNegative()) return this.mul(multiplier.neg()).neg();
    if (this.lt(TWO_PWR_24) && multiplier.lt(TWO_PWR_24)) return fromNumber(this.toNumber() * multiplier.toNumber(), this.unsigned);
    var a48 = this.high >>> 16;
    var a32 = this.high & 0xFFFF;
    var a16 = this.low >>> 16;
    var a00 = this.low & 0xFFFF;
    var b48 = multiplier.high >>> 16;
    var b32 = multiplier.high & 0xFFFF;
    var b16 = multiplier.low >>> 16;
    var b00 = multiplier.low & 0xFFFF;
    var c48 = 0,
      c32 = 0,
      c16 = 0,
      c00 = 0;
    c00 += a00 * b00;
    c16 += c00 >>> 16;
    c00 &= 0xFFFF;
    c16 += a16 * b00;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c16 += a00 * b16;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c32 += a32 * b00;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c32 += a16 * b16;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c32 += a00 * b32;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c48 += a48 * b00 + a32 * b16 + a16 * b32 + a00 * b48;
    c48 &= 0xFFFF;
    return fromBits(c16 << 16 | c00, c48 << 16 | c32, this.unsigned);
  };
  LongPrototype.mul = LongPrototype.multiply;
  LongPrototype.divide = function divide(divisor) {
    if (!isLong(divisor)) divisor = fromValue(divisor);
    if (divisor.isZero()) throw Error('division by zero');
    if (wasm) {
      if (!this.unsigned && this.high === -0x80000000 && divisor.low === -1 && divisor.high === -1) {
        return this;
      }
      var low = (this.unsigned ? wasm.div_u : wasm.div_s)(this.low, this.high, divisor.low, divisor.high);
      return fromBits(low, wasm.get_high(), this.unsigned);
    }
    if (this.isZero()) return this.unsigned ? UZERO : ZERO;
    var approx, rem, res;
    if (!this.unsigned) {
      if (this.eq(MIN_VALUE)) {
        if (divisor.eq(ONE) || divisor.eq(NEG_ONE)) return MIN_VALUE;else if (divisor.eq(MIN_VALUE)) return ONE;else {
          var halfThis = this.shr(1);
          approx = halfThis.div(divisor).shl(1);
          if (approx.eq(ZERO)) {
            return divisor.isNegative() ? ONE : NEG_ONE;
          } else {
            rem = this.sub(divisor.mul(approx));
            res = approx.add(rem.div(divisor));
            return res;
          }
        }
      } else if (divisor.eq(MIN_VALUE)) return this.unsigned ? UZERO : ZERO;
      if (this.isNegative()) {
        if (divisor.isNegative()) return this.neg().div(divisor.neg());
        return this.neg().div(divisor).neg();
      } else if (divisor.isNegative()) return this.div(divisor.neg()).neg();
      res = ZERO;
    } else {
      if (!divisor.unsigned) divisor = divisor.toUnsigned();
      if (divisor.gt(this)) return UZERO;
      if (divisor.gt(this.shru(1))) return UONE;
      res = UZERO;
    }
    rem = this;
    while (rem.gte(divisor)) {
      approx = Math.max(1, Math.floor(rem.toNumber() / divisor.toNumber()));
      var log2 = Math.ceil(Math.log(approx) / Math.LN2),
        delta = log2 <= 48 ? 1 : pow_dbl(2, log2 - 48),
        approxRes = fromNumber(approx),
        approxRem = approxRes.mul(divisor);
      while (approxRem.isNegative() || approxRem.gt(rem)) {
        approx -= delta;
        approxRes = fromNumber(approx, this.unsigned);
        approxRem = approxRes.mul(divisor);
      }
      if (approxRes.isZero()) approxRes = ONE;
      res = res.add(approxRes);
      rem = rem.sub(approxRem);
    }
    return res;
  };
  LongPrototype.div = LongPrototype.divide;
  LongPrototype.modulo = function modulo(divisor) {
    if (!isLong(divisor)) divisor = fromValue(divisor);
    if (wasm) {
      var low = (this.unsigned ? wasm.rem_u : wasm.rem_s)(this.low, this.high, divisor.low, divisor.high);
      return fromBits(low, wasm.get_high(), this.unsigned);
    }
    return this.sub(this.div(divisor).mul(divisor));
  };
  LongPrototype.mod = LongPrototype.modulo;
  LongPrototype.rem = LongPrototype.modulo;
  LongPrototype.not = function not() {
    return fromBits(~this.low, ~this.high, this.unsigned);
  };
  LongPrototype.and = function and(other) {
    if (!isLong(other)) other = fromValue(other);
    return fromBits(this.low & other.low, this.high & other.high, this.unsigned);
  };
  LongPrototype.or = function or(other) {
    if (!isLong(other)) other = fromValue(other);
    return fromBits(this.low | other.low, this.high | other.high, this.unsigned);
  };
  LongPrototype.xor = function xor(other) {
    if (!isLong(other)) other = fromValue(other);
    return fromBits(this.low ^ other.low, this.high ^ other.high, this.unsigned);
  };
  LongPrototype.shiftLeft = function shiftLeft(numBits) {
    if (isLong(numBits)) numBits = numBits.toInt();
    if ((numBits &= 63) === 0) return this;else if (numBits < 32) return fromBits(this.low << numBits, this.high << numBits | this.low >>> 32 - numBits, this.unsigned);else return fromBits(0, this.low << numBits - 32, this.unsigned);
  };
  LongPrototype.shl = LongPrototype.shiftLeft;
  LongPrototype.shiftRight = function shiftRight(numBits) {
    if (isLong(numBits)) numBits = numBits.toInt();
    if ((numBits &= 63) === 0) return this;else if (numBits < 32) return fromBits(this.low >>> numBits | this.high << 32 - numBits, this.high >> numBits, this.unsigned);else return fromBits(this.high >> numBits - 32, this.high >= 0 ? 0 : -1, this.unsigned);
  };
  LongPrototype.shr = LongPrototype.shiftRight;
  LongPrototype.shiftRightUnsigned = function shiftRightUnsigned(numBits) {
    if (isLong(numBits)) numBits = numBits.toInt();
    numBits &= 63;
    if (numBits === 0) return this;else {
      var high = this.high;
      if (numBits < 32) {
        var low = this.low;
        return fromBits(low >>> numBits | high << 32 - numBits, high >>> numBits, this.unsigned);
      } else if (numBits === 32) return fromBits(high, 0, this.unsigned);else return fromBits(high >>> numBits - 32, 0, this.unsigned);
    }
  };
  LongPrototype.shru = LongPrototype.shiftRightUnsigned;
  LongPrototype.shr_u = LongPrototype.shiftRightUnsigned;
  LongPrototype.toSigned = function toSigned() {
    if (!this.unsigned) return this;
    return fromBits(this.low, this.high, false);
  };
  LongPrototype.toUnsigned = function toUnsigned() {
    if (this.unsigned) return this;
    return fromBits(this.low, this.high, true);
  };
  LongPrototype.toBytes = function toBytes(le) {
    return le ? this.toBytesLE() : this.toBytesBE();
  };
  LongPrototype.toBytesLE = function toBytesLE() {
    var hi = this.high,
      lo = this.low;
    return [lo & 0xff, lo >>> 8 & 0xff, lo >>> 16 & 0xff, lo >>> 24, hi & 0xff, hi >>> 8 & 0xff, hi >>> 16 & 0xff, hi >>> 24];
  };
  LongPrototype.toBytesBE = function toBytesBE() {
    var hi = this.high,
      lo = this.low;
    return [hi >>> 24, hi >>> 16 & 0xff, hi >>> 8 & 0xff, hi & 0xff, lo >>> 24, lo >>> 16 & 0xff, lo >>> 8 & 0xff, lo & 0xff];
  };
  Long.fromBytes = function fromBytes(bytes, unsigned, le) {
    return le ? Long.fromBytesLE(bytes, unsigned) : Long.fromBytesBE(bytes, unsigned);
  };
  Long.fromBytesLE = function fromBytesLE(bytes, unsigned) {
    return new Long(bytes[0] | bytes[1] << 8 | bytes[2] << 16 | bytes[3] << 24, bytes[4] | bytes[5] << 8 | bytes[6] << 16 | bytes[7] << 24, unsigned);
  };
  Long.fromBytesBE = function fromBytesBE(bytes, unsigned) {
    return new Long(bytes[4] << 24 | bytes[5] << 16 | bytes[6] << 8 | bytes[7], bytes[0] << 24 | bytes[1] << 16 | bytes[2] << 8 | bytes[3], unsigned);
  };
  Long.prototype.toExtendedJSON = function (options) {
    if (options && options.relaxed) return this.toNumber();
    return {
      $numberLong: this.toString()
    };
  };
  Long.fromExtendedJSON = function (doc, options) {
    var result = Long.fromString(doc.$numberLong);
    return options && options.relaxed ? result.toNumber() : result;
  };
  Object.defineProperty(Long.prototype, '_bsontype', {
    value: 'Long'
  });
  return Long;
}();
var long_1$1 = Long;
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}
var Double = /*#__PURE__*/
function () {
  function Double(value) {
    _classCallCheck(this, Double);
    if (value instanceof Number) {
      value = value.valueOf();
    }
    this.value = value;
  }
  _createClass(Double, [{
    key: "valueOf",
    value: function valueOf() {
      return this.value;
    }
  }, {
    key: "toJSON",
    value: function toJSON() {
      return this.value;
    }
  }, {
    key: "toExtendedJSON",
    value: function toExtendedJSON(options) {
      if (options && (options.legacy || options.relaxed && isFinite(this.value))) {
        return this.value;
      }
      return {
        $numberDouble: this.value.toString()
      };
    }
  }], [{
    key: "fromExtendedJSON",
    value: function fromExtendedJSON(doc, options) {
      return options && options.relaxed ? parseFloat(doc.$numberDouble) : new Double(parseFloat(doc.$numberDouble));
    }
  }]);
  Object.defineProperty(Double.prototype, '_bsontype', {
    value: 'Double'
  });
  return Double;
}();
var double_1 = Double;
function _typeof(obj) {
  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }
  return _typeof(obj);
}
function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }
  return _assertThisInitialized(self);
}
function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return self;
}
function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}
function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}
function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };
  return _setPrototypeOf(o, p);
}
var Timestamp = /*#__PURE__*/
function (_Long) {
  _inherits(Timestamp, _Long);
  function Timestamp(low, high) {
    var _this;
    _classCallCheck(this, Timestamp);
    if (long_1$1.isLong(low)) {
      _this = _possibleConstructorReturn(this, _getPrototypeOf(Timestamp).call(this, low.low, low.high, true));
    } else {
      _this = _possibleConstructorReturn(this, _getPrototypeOf(Timestamp).call(this, low, high, true));
    }
    return _possibleConstructorReturn(_this);
  }
  _createClass(Timestamp, [{
    key: "toJSON",
    value: function toJSON() {
      return {
        $timestamp: this.toString()
      };
    }
  }, {
    key: "toExtendedJSON",
    value: function toExtendedJSON() {
      return {
        $timestamp: {
          t: this.high >>> 0,
          i: this.low >>> 0
        }
      };
    }
  }], [{
    key: "fromInt",
    value: function fromInt(value) {
      return new Timestamp(long_1$1.fromInt(value, true));
    }
  }, {
    key: "fromNumber",
    value: function fromNumber(value) {
      return new Timestamp(long_1$1.fromNumber(value, true));
    }
  }, {
    key: "fromBits",
    value: function fromBits(lowBits, highBits) {
      return new Timestamp(lowBits, highBits);
    }
  }, {
    key: "fromString",
    value: function fromString(str, opt_radix) {
      return new Timestamp(long_1$1.fromString(str, opt_radix, true));
    }
  }, {
    key: "fromExtendedJSON",
    value: function fromExtendedJSON(doc) {
      return new Timestamp(doc.$timestamp.i, doc.$timestamp.t);
    }
  }]);
  Object.defineProperty(Timestamp.prototype, '_bsontype', {
    value: 'Timestamp'
  });
  Timestamp.MAX_VALUE = Timestamp.MAX_UNSIGNED_VALUE;
  return Timestamp;
}(long_1$1);
var timestamp = Timestamp;
var require$$0 = {};
function normalizedFunctionString(fn) {
  return fn.toString().replace('function(', 'function (');
}
function insecureRandomBytes(size) {
  var result = new Uint8Array(size);
  for (var i = 0; i < size; ++i) {
    result[i] = Math.floor(Math.random() * 256);
  }
  return result;
}
var randomBytes = /*#__PURE__*/
function () {
  var randomBytes = insecureRandomBytes;
  if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
    randomBytes = function randomBytes(size) {
      return window.crypto.getRandomValues(new Uint8Array(size));
    };
  } else {
    try {
      randomBytes = require$$0.randomBytes;
    } catch (e) {}
    if (randomBytes == null) {
      randomBytes = insecureRandomBytes;
    }
  }
  return randomBytes;
}();
var utils = {
  normalizedFunctionString: normalizedFunctionString,
  randomBytes: randomBytes
};
function defaultSetTimout() {
  throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout() {
  throw new Error('clearTimeout has not been defined');
}
var cachedSetTimeout = /*#__PURE__*/(() => typeof __webpack_require__.g.setTimeout === 'function' ? setTimeout : defaultSetTimout)();
var cachedClearTimeout = /*#__PURE__*/(() => typeof __webpack_require__.g.clearTimeout === 'function' ? clearTimeout : defaultClearTimeout)();
function runTimeout(fun) {
  if (cachedSetTimeout === setTimeout) {
    return setTimeout(fun, 0);
  }
  if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
    cachedSetTimeout = setTimeout;
    return setTimeout(fun, 0);
  }
  try {
    return cachedSetTimeout(fun, 0);
  } catch (e) {
    try {
      return cachedSetTimeout.call(null, fun, 0);
    } catch (e) {
      return cachedSetTimeout.call(this, fun, 0);
    }
  }
}
function runClearTimeout(marker) {
  if (cachedClearTimeout === clearTimeout) {
    return clearTimeout(marker);
  }
  if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
    cachedClearTimeout = clearTimeout;
    return clearTimeout(marker);
  }
  try {
    return cachedClearTimeout(marker);
  } catch (e) {
    try {
      return cachedClearTimeout.call(null, marker);
    } catch (e) {
      return cachedClearTimeout.call(this, marker);
    }
  }
}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;
function cleanUpNextTick() {
  if (!draining || !currentQueue) {
    return;
  }
  draining = false;
  if (currentQueue.length) {
    queue = currentQueue.concat(queue);
  } else {
    queueIndex = -1;
  }
  if (queue.length) {
    drainQueue();
  }
}
function drainQueue() {
  if (draining) {
    return;
  }
  var timeout = runTimeout(cleanUpNextTick);
  draining = true;
  var len = queue.length;
  while (len) {
    currentQueue = queue;
    queue = [];
    while (++queueIndex < len) {
      if (currentQueue) {
        currentQueue[queueIndex].run();
      }
    }
    queueIndex = -1;
    len = queue.length;
  }
  currentQueue = null;
  draining = false;
  runClearTimeout(timeout);
}
function nextTick(fun) {
  var args = new Array(arguments.length - 1);
  if (arguments.length > 1) {
    for (var i = 1; i < arguments.length; i++) {
      args[i - 1] = arguments[i];
    }
  }
  queue.push(new Item(fun, args));
  if (queue.length === 1 && !draining) {
    runTimeout(drainQueue);
  }
}
var Item = /*#__PURE__*/
function () {
  function Item(fun, array) {
    this.fun = fun;
    this.array = array;
  }
  Item.prototype.run = function () {
    this.fun.apply(null, this.array);
  };
  return Item;
}();
var title = 'browser';
var platform = 'browser';
var browser = true;
var env = {};
var argv = [];
var version = '';
var versions = {};
var release = {};
var config = {};
function noop() {}
var on = noop;
var addListener = noop;
var once = noop;
var off = noop;
var removeListener = noop;
var removeAllListeners = noop;
var emit = noop;
function binding(name) {
  throw new Error('process.binding is not supported');
}
function cwd() {
  return '/';
}
function chdir(dir) {
  throw new Error('process.chdir is not supported');
}
function umask() {
  return 0;
}
var performance = /*#__PURE__*/(() => __webpack_require__.g.performance || {})();
var performanceNow = /*#__PURE__*/
function () {
  return performance.now || performance.mozNow || performance.msNow || performance.oNow || performance.webkitNow || function () {
    return new Date().getTime();
  };
}();
function hrtime(previousTimestamp) {
  var clocktime = performanceNow.call(performance) * 1e-3;
  var seconds = Math.floor(clocktime);
  var nanoseconds = Math.floor(clocktime % 1 * 1e9);
  if (previousTimestamp) {
    seconds = seconds - previousTimestamp[0];
    nanoseconds = nanoseconds - previousTimestamp[1];
    if (nanoseconds < 0) {
      seconds--;
      nanoseconds += 1e9;
    }
  }
  return [seconds, nanoseconds];
}
var startTime = new Date();
function uptime() {
  var currentTime = new Date();
  var dif = currentTime - startTime;
  return dif / 1000;
}
var process = {
  nextTick: nextTick,
  title: title,
  browser: browser,
  env: env,
  argv: argv,
  version: version,
  versions: versions,
  on: on,
  addListener: addListener,
  once: once,
  off: off,
  removeListener: removeListener,
  removeAllListeners: removeAllListeners,
  emit: emit,
  binding: binding,
  cwd: cwd,
  chdir: chdir,
  umask: umask,
  hrtime: hrtime,
  platform: platform,
  release: release,
  config: config,
  uptime: uptime
};
var inherits = /*#__PURE__*/
function () {
  var inherits;
  if (typeof Object.create === 'function') {
    inherits = function inherits(ctor, superCtor) {
      ctor.super_ = superCtor;
      ctor.prototype = Object.create(superCtor.prototype, {
        constructor: {
          value: ctor,
          enumerable: false,
          writable: true,
          configurable: true
        }
      });
    };
  } else {
    inherits = function inherits(ctor, superCtor) {
      ctor.super_ = superCtor;
      var TempCtor = function TempCtor() {};
      TempCtor.prototype = superCtor.prototype;
      ctor.prototype = new TempCtor();
      ctor.prototype.constructor = ctor;
    };
  }
  return inherits;
}();
var inherits$1 = inherits;
var formatRegExp = /%[sdj%]/g;
function format(f) {
  if (!isString(f)) {
    var objects = [];
    for (var i = 0; i < arguments.length; i++) {
      objects.push(inspect(arguments[i]));
    }
    return objects.join(' ');
  }
  var i = 1;
  var args = arguments;
  var len = args.length;
  var str = String(f).replace(formatRegExp, function (x) {
    if (x === '%%') return '%';
    if (i >= len) return x;
    switch (x) {
      case '%s':
        return String(args[i++]);
      case '%d':
        return Number(args[i++]);
      case '%j':
        try {
          return JSON.stringify(args[i++]);
        } catch (_) {
          return '[Circular]';
        }
      default:
        return x;
    }
  });
  for (var x = args[i]; i < len; x = args[++i]) {
    if (isNull(x) || !isObject(x)) {
      str += ' ' + x;
    } else {
      str += ' ' + inspect(x);
    }
  }
  return str;
}
function deprecate(fn, msg) {
  if (isUndefined(__webpack_require__.g.process)) {
    return function () {
      return deprecate(fn, msg).apply(this, arguments);
    };
  }
  var warned = false;
  function deprecated() {
    if (!warned) {
      {
        console.error(msg);
      }
      warned = true;
    }
    return fn.apply(this, arguments);
  }
  return deprecated;
}
var debugs = {};
var debugEnviron;
function debuglog(set) {
  if (isUndefined(debugEnviron)) debugEnviron = process.env.NODE_DEBUG || '';
  set = set.toUpperCase();
  if (!debugs[set]) {
    if (new RegExp('\\b' + set + '\\b', 'i').test(debugEnviron)) {
      var pid = 0;
      debugs[set] = function () {
        var msg = format.apply(null, arguments);
        console.error('%s %d: %s', set, pid, msg);
      };
    } else {
      debugs[set] = function () {};
    }
  }
  return debugs[set];
}
var inspect = /*#__PURE__*/
function () {
  function inspect(obj, opts) {
    var ctx = {
      seen: [],
      stylize: stylizeNoColor
    };
    if (arguments.length >= 3) ctx.depth = arguments[2];
    if (arguments.length >= 4) ctx.colors = arguments[3];
    if (isBoolean(opts)) {
      ctx.showHidden = opts;
    } else if (opts) {
      _extend(ctx, opts);
    }
    if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
    if (isUndefined(ctx.depth)) ctx.depth = 2;
    if (isUndefined(ctx.colors)) ctx.colors = false;
    if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
    if (ctx.colors) ctx.stylize = stylizeWithColor;
    return formatValue(ctx, obj, ctx.depth);
  }
  inspect.colors = {
    'bold': [1, 22],
    'italic': [3, 23],
    'underline': [4, 24],
    'inverse': [7, 27],
    'white': [37, 39],
    'grey': [90, 39],
    'black': [30, 39],
    'blue': [34, 39],
    'cyan': [36, 39],
    'green': [32, 39],
    'magenta': [35, 39],
    'red': [31, 39],
    'yellow': [33, 39]
  };
  inspect.styles = {
    'special': 'cyan',
    'number': 'yellow',
    'boolean': 'yellow',
    'undefined': 'grey',
    'null': 'bold',
    'string': 'green',
    'date': 'magenta',
    'regexp': 'red'
  };
  return inspect;
}();
function stylizeWithColor(str, styleType) {
  var style = inspect.styles[styleType];
  if (style) {
    return "\x1B[" + inspect.colors[style][0] + 'm' + str + "\x1B[" + inspect.colors[style][1] + 'm';
  } else {
    return str;
  }
}
function stylizeNoColor(str, styleType) {
  return str;
}
function arrayToHash(array) {
  var hash = {};
  array.forEach(function (val, idx) {
    hash[val] = true;
  });
  return hash;
}
function formatValue(ctx, value, recurseTimes) {
  if (ctx.customInspect && value && isFunction(value.inspect) && value.inspect !== inspect && !(value.constructor && value.constructor.prototype === value)) {
    var ret = value.inspect(recurseTimes, ctx);
    if (!isString(ret)) {
      ret = formatValue(ctx, ret, recurseTimes);
    }
    return ret;
  }
  var primitive = formatPrimitive(ctx, value);
  if (primitive) {
    return primitive;
  }
  var keys = Object.keys(value);
  var visibleKeys = arrayToHash(keys);
  if (ctx.showHidden) {
    keys = Object.getOwnPropertyNames(value);
  }
  if (isError(value) && (keys.indexOf('message') >= 0 || keys.indexOf('description') >= 0)) {
    return formatError(value);
  }
  if (keys.length === 0) {
    if (isFunction(value)) {
      var name = value.name ? ': ' + value.name : '';
      return ctx.stylize('[Function' + name + ']', 'special');
    }
    if (isRegExp(value)) {
      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
    }
    if (isDate(value)) {
      return ctx.stylize(Date.prototype.toString.call(value), 'date');
    }
    if (isError(value)) {
      return formatError(value);
    }
  }
  var base = '',
    array = false,
    braces = ['{', '}'];
  if (isArray$1(value)) {
    array = true;
    braces = ['[', ']'];
  }
  if (isFunction(value)) {
    var n = value.name ? ': ' + value.name : '';
    base = ' [Function' + n + ']';
  }
  if (isRegExp(value)) {
    base = ' ' + RegExp.prototype.toString.call(value);
  }
  if (isDate(value)) {
    base = ' ' + Date.prototype.toUTCString.call(value);
  }
  if (isError(value)) {
    base = ' ' + formatError(value);
  }
  if (keys.length === 0 && (!array || value.length == 0)) {
    return braces[0] + base + braces[1];
  }
  if (recurseTimes < 0) {
    if (isRegExp(value)) {
      return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
    } else {
      return ctx.stylize('[Object]', 'special');
    }
  }
  ctx.seen.push(value);
  var output;
  if (array) {
    output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
  } else {
    output = keys.map(function (key) {
      return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
    });
  }
  ctx.seen.pop();
  return reduceToSingleString(output, base, braces);
}
function formatPrimitive(ctx, value) {
  if (isUndefined(value)) return ctx.stylize('undefined', 'undefined');
  if (isString(value)) {
    var simple = '\'' + JSON.stringify(value).replace(/^"|"$/g, '').replace(/'/g, "\\'").replace(/\\"/g, '"') + '\'';
    return ctx.stylize(simple, 'string');
  }
  if (isNumber(value)) return ctx.stylize('' + value, 'number');
  if (isBoolean(value)) return ctx.stylize('' + value, 'boolean');
  if (isNull(value)) return ctx.stylize('null', 'null');
}
function formatError(value) {
  return '[' + Error.prototype.toString.call(value) + ']';
}
function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
  var output = [];
  for (var i = 0, l = value.length; i < l; ++i) {
    if (hasOwnProperty(value, String(i))) {
      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys, String(i), true));
    } else {
      output.push('');
    }
  }
  keys.forEach(function (key) {
    if (!key.match(/^\d+$/)) {
      output.push(formatProperty(ctx, value, recurseTimes, visibleKeys, key, true));
    }
  });
  return output;
}
function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
  var name, str, desc;
  desc = Object.getOwnPropertyDescriptor(value, key) || {
    value: value[key]
  };
  if (desc.get) {
    if (desc.set) {
      str = ctx.stylize('[Getter/Setter]', 'special');
    } else {
      str = ctx.stylize('[Getter]', 'special');
    }
  } else {
    if (desc.set) {
      str = ctx.stylize('[Setter]', 'special');
    }
  }
  if (!hasOwnProperty(visibleKeys, key)) {
    name = '[' + key + ']';
  }
  if (!str) {
    if (ctx.seen.indexOf(desc.value) < 0) {
      if (isNull(recurseTimes)) {
        str = formatValue(ctx, desc.value, null);
      } else {
        str = formatValue(ctx, desc.value, recurseTimes - 1);
      }
      if (str.indexOf('\n') > -1) {
        if (array) {
          str = str.split('\n').map(function (line) {
            return '  ' + line;
          }).join('\n').substr(2);
        } else {
          str = '\n' + str.split('\n').map(function (line) {
            return '   ' + line;
          }).join('\n');
        }
      }
    } else {
      str = ctx.stylize('[Circular]', 'special');
    }
  }
  if (isUndefined(name)) {
    if (array && key.match(/^\d+$/)) {
      return str;
    }
    name = JSON.stringify('' + key);
    if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
      name = name.substr(1, name.length - 2);
      name = ctx.stylize(name, 'name');
    } else {
      name = name.replace(/'/g, "\\'").replace(/\\"/g, '"').replace(/(^"|"$)/g, "'");
      name = ctx.stylize(name, 'string');
    }
  }
  return name + ': ' + str;
}
function reduceToSingleString(output, base, braces) {
  var length = output.reduce(function (prev, cur) {
    if (cur.indexOf('\n') >= 0) ;
    return prev + cur.replace(/\u001b\[\d\d?m/g, '').length + 1;
  }, 0);
  if (length > 60) {
    return braces[0] + (base === '' ? '' : base + '\n ') + ' ' + output.join(',\n  ') + ' ' + braces[1];
  }
  return braces[0] + base + ' ' + output.join(', ') + ' ' + braces[1];
}
function isArray$1(ar) {
  return Array.isArray(ar);
}
function isBoolean(arg) {
  return typeof arg === 'boolean';
}
function isNull(arg) {
  return arg === null;
}
function isNullOrUndefined(arg) {
  return arg == null;
}
function isNumber(arg) {
  return typeof arg === 'number';
}
function isString(arg) {
  return typeof arg === 'string';
}
function isSymbol(arg) {
  return _typeof(arg) === 'symbol';
}
function isUndefined(arg) {
  return arg === void 0;
}
function isRegExp(re) {
  return isObject(re) && objectToString(re) === '[object RegExp]';
}
function isObject(arg) {
  return _typeof(arg) === 'object' && arg !== null;
}
function isDate(d) {
  return isObject(d) && objectToString(d) === '[object Date]';
}
function isError(e) {
  return isObject(e) && (objectToString(e) === '[object Error]' || e instanceof Error);
}
function isFunction(arg) {
  return typeof arg === 'function';
}
function isPrimitive(arg) {
  return arg === null || typeof arg === 'boolean' || typeof arg === 'number' || typeof arg === 'string' || _typeof(arg) === 'symbol' || typeof arg === 'undefined';
}
function isBuffer$1(maybeBuf) {
  return Buffer.isBuffer(maybeBuf);
}
function objectToString(o) {
  return Object.prototype.toString.call(o);
}
function pad(n) {
  return n < 10 ? '0' + n.toString(10) : n.toString(10);
}
var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function timestamp$1() {
  var d = new Date();
  var time = [pad(d.getHours()), pad(d.getMinutes()), pad(d.getSeconds())].join(':');
  return [d.getDate(), months[d.getMonth()], time].join(' ');
}
function log() {
  console.log('%s - %s', timestamp$1(), format.apply(null, arguments));
}
function _extend(origin, add) {
  if (!add || !isObject(add)) return origin;
  var keys = Object.keys(add);
  var i = keys.length;
  while (i--) {
    origin[keys[i]] = add[keys[i]];
  }
  return origin;
}
function hasOwnProperty(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
}
var util = {
  inherits: inherits$1,
  _extend: _extend,
  log: log,
  isBuffer: isBuffer$1,
  isPrimitive: isPrimitive,
  isFunction: isFunction,
  isError: isError,
  isDate: isDate,
  isObject: isObject,
  isRegExp: isRegExp,
  isUndefined: isUndefined,
  isSymbol: isSymbol,
  isString: isString,
  isNumber: isNumber,
  isNullOrUndefined: isNullOrUndefined,
  isNull: isNull,
  isBoolean: isBoolean,
  isArray: isArray$1,
  inspect: inspect,
  deprecate: deprecate,
  format: format,
  debuglog: debuglog
};
var Buffer$2 = /*#__PURE__*/(() => bufferEs6.Buffer)();
var randomBytes$1 = utils.randomBytes;
var deprecate$1 = util.deprecate;
var PROCESS_UNIQUE = /*#__PURE__*/randomBytes$1(5);
var checkForHexRegExp = /*#__PURE__*/new RegExp('^[0-9a-fA-F]{24}$');
var hasBufferType = /*#__PURE__*/
function () {
  var hasBufferType = false;
  try {
    if (Buffer$2 && Buffer$2.from) hasBufferType = true;
  } catch (err) {
    hasBufferType = false;
  }
  return hasBufferType;
}();
var hexTable = /*#__PURE__*/
function () {
  var hexTable = [];
  for (var _i = 0; _i < 256; _i++) {
    hexTable[_i] = (_i <= 15 ? '0' : '') + _i.toString(16);
  }
  return hexTable;
}();
var decodeLookup = /*#__PURE__*/
function () {
  var decodeLookup = [];
  var i = 0;
  while (i < 10) {
    decodeLookup[0x30 + i] = i++;
  }
  while (i < 16) {
    decodeLookup[0x41 - 10 + i] = decodeLookup[0x61 - 10 + i] = i++;
  }
  return decodeLookup;
}();
var _Buffer = Buffer$2;
function convertToHex(bytes) {
  return bytes.toString('hex');
}
function makeObjectIdError(invalidString, index) {
  var invalidCharacter = invalidString[index];
  return new TypeError("ObjectId string \"".concat(invalidString, "\" contains invalid character \"").concat(invalidCharacter, "\" with character code (").concat(invalidString.charCodeAt(index), "). All character codes for a non-hex string must be less than 256."));
}
var ObjectId = /*#__PURE__*/
function () {
  function ObjectId(id) {
    _classCallCheck(this, ObjectId);
    if (id instanceof ObjectId) return id;
    if (id == null || typeof id === 'number') {
      this.id = ObjectId.generate(id);
      if (ObjectId.cacheHexString) this.__id = this.toString('hex');
      return;
    }
    var valid = ObjectId.isValid(id);
    if (!valid && id != null) {
      throw new TypeError('Argument passed in must be a single String of 12 bytes or a string of 24 hex characters');
    } else if (valid && typeof id === 'string' && id.length === 24 && hasBufferType) {
      return new ObjectId(Buffer$2.from(id, 'hex'));
    } else if (valid && typeof id === 'string' && id.length === 24) {
      return ObjectId.createFromHexString(id);
    } else if (id != null && id.length === 12) {
      this.id = id;
    } else if (id != null && id.toHexString) {
      return ObjectId.createFromHexString(id.toHexString());
    } else {
      throw new TypeError('Argument passed in must be a single String of 12 bytes or a string of 24 hex characters');
    }
    if (ObjectId.cacheHexString) this.__id = this.toString('hex');
  }
  _createClass(ObjectId, [{
    key: "toHexString",
    value: function toHexString() {
      if (ObjectId.cacheHexString && this.__id) return this.__id;
      var hexString = '';
      if (!this.id || !this.id.length) {
        throw new TypeError('invalid ObjectId, ObjectId.id must be either a string or a Buffer, but is [' + JSON.stringify(this.id) + ']');
      }
      if (this.id instanceof _Buffer) {
        hexString = convertToHex(this.id);
        if (ObjectId.cacheHexString) this.__id = hexString;
        return hexString;
      }
      for (var _i2 = 0; _i2 < this.id.length; _i2++) {
        var hexChar = hexTable[this.id.charCodeAt(_i2)];
        if (typeof hexChar !== 'string') {
          throw makeObjectIdError(this.id, _i2);
        }
        hexString += hexChar;
      }
      if (ObjectId.cacheHexString) this.__id = hexString;
      return hexString;
    }
  }, {
    key: "toString",
    value: function toString(format) {
      if (this.id && this.id.copy) {
        return this.id.toString(typeof format === 'string' ? format : 'hex');
      }
      return this.toHexString();
    }
  }, {
    key: "toJSON",
    value: function toJSON() {
      return this.toHexString();
    }
  }, {
    key: "equals",
    value: function equals(otherId) {
      if (otherId instanceof ObjectId) {
        return this.toString() === otherId.toString();
      }
      if (typeof otherId === 'string' && ObjectId.isValid(otherId) && otherId.length === 12 && this.id instanceof _Buffer) {
        return otherId === this.id.toString('binary');
      }
      if (typeof otherId === 'string' && ObjectId.isValid(otherId) && otherId.length === 24) {
        return otherId.toLowerCase() === this.toHexString();
      }
      if (typeof otherId === 'string' && ObjectId.isValid(otherId) && otherId.length === 12) {
        return otherId === this.id;
      }
      if (otherId != null && (otherId instanceof ObjectId || otherId.toHexString)) {
        return otherId.toHexString() === this.toHexString();
      }
      return false;
    }
  }, {
    key: "getTimestamp",
    value: function getTimestamp() {
      var timestamp = new Date();
      var time = this.id.readUInt32BE(0);
      timestamp.setTime(Math.floor(time) * 1000);
      return timestamp;
    }
  }, {
    key: "toExtendedJSON",
    value: function toExtendedJSON() {
      if (this.toHexString) return {
        $oid: this.toHexString()
      };
      return {
        $oid: this.toString('hex')
      };
    }
  }], [{
    key: "getInc",
    value: function getInc() {
      return ObjectId.index = (ObjectId.index + 1) % 0xffffff;
    }
  }, {
    key: "generate",
    value: function generate(time) {
      if ('number' !== typeof time) {
        time = ~~(Date.now() / 1000);
      }
      var inc = ObjectId.getInc();
      var buffer = Buffer$2.alloc(12);
      buffer[3] = time & 0xff;
      buffer[2] = time >> 8 & 0xff;
      buffer[1] = time >> 16 & 0xff;
      buffer[0] = time >> 24 & 0xff;
      buffer[4] = PROCESS_UNIQUE[0];
      buffer[5] = PROCESS_UNIQUE[1];
      buffer[6] = PROCESS_UNIQUE[2];
      buffer[7] = PROCESS_UNIQUE[3];
      buffer[8] = PROCESS_UNIQUE[4];
      buffer[11] = inc & 0xff;
      buffer[10] = inc >> 8 & 0xff;
      buffer[9] = inc >> 16 & 0xff;
      return buffer;
    }
  }, {
    key: "createPk",
    value: function createPk() {
      return new ObjectId();
    }
  }, {
    key: "createFromTime",
    value: function createFromTime(time) {
      var buffer = Buffer$2.from([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
      buffer[3] = time & 0xff;
      buffer[2] = time >> 8 & 0xff;
      buffer[1] = time >> 16 & 0xff;
      buffer[0] = time >> 24 & 0xff;
      return new ObjectId(buffer);
    }
  }, {
    key: "createFromHexString",
    value: function createFromHexString(string) {
      if (typeof string === 'undefined' || string != null && string.length !== 24) {
        throw new TypeError('Argument passed in must be a single String of 12 bytes or a string of 24 hex characters');
      }
      if (hasBufferType) return new ObjectId(Buffer$2.from(string, 'hex'));
      var array = new _Buffer(12);
      var n = 0;
      var i = 0;
      while (i < 24) {
        array[n++] = decodeLookup[string.charCodeAt(i++)] << 4 | decodeLookup[string.charCodeAt(i++)];
      }
      return new ObjectId(array);
    }
  }, {
    key: "isValid",
    value: function isValid(id) {
      if (id == null) return false;
      if (typeof id === 'number') {
        return true;
      }
      if (typeof id === 'string') {
        return id.length === 12 || id.length === 24 && checkForHexRegExp.test(id);
      }
      if (id instanceof ObjectId) {
        return true;
      }
      if (id instanceof _Buffer && id.length === 12) {
        return true;
      }
      if (id.toHexString) {
        return id.id.length === 12 || id.id.length === 24 && checkForHexRegExp.test(id.id);
      }
      return false;
    }
  }, {
    key: "fromExtendedJSON",
    value: function fromExtendedJSON(doc) {
      return new ObjectId(doc.$oid);
    }
  }]);
  ObjectId.get_inc = deprecate$1(function () {
    return ObjectId.getInc();
  }, 'Please use the static `ObjectId.getInc()` instead');
  ObjectId.prototype.get_inc = deprecate$1(function () {
    return ObjectId.getInc();
  }, 'Please use the static `ObjectId.getInc()` instead');
  ObjectId.prototype.getInc = deprecate$1(function () {
    return ObjectId.getInc();
  }, 'Please use the static `ObjectId.getInc()` instead');
  ObjectId.prototype.generate = deprecate$1(function (time) {
    return ObjectId.generate(time);
  }, 'Please use the static `ObjectId.generate(time)` instead');
  Object.defineProperty(ObjectId.prototype, 'generationTime', {
    enumerable: true,
    get: function get() {
      return this.id[3] | this.id[2] << 8 | this.id[1] << 16 | this.id[0] << 24;
    },
    set: function set(value) {
      this.id[3] = value & 0xff;
      this.id[2] = value >> 8 & 0xff;
      this.id[1] = value >> 16 & 0xff;
      this.id[0] = value >> 24 & 0xff;
    }
  });
  ObjectId.prototype[util.inspect.custom || 'inspect'] = ObjectId.prototype.toString;
  ObjectId.index = ~~(Math.random() * 0xffffff);
  Object.defineProperty(ObjectId.prototype, '_bsontype', {
    value: 'ObjectID'
  });
  return ObjectId;
}();
var objectid = ObjectId;
function alphabetize(str) {
  return str.split('').sort().join('');
}
var BSONRegExp = /*#__PURE__*/
function () {
  function BSONRegExp(pattern, options) {
    _classCallCheck(this, BSONRegExp);
    this.pattern = pattern || '';
    this.options = options ? alphabetize(options) : '';
    for (var i = 0; i < this.options.length; i++) {
      if (!(this.options[i] === 'i' || this.options[i] === 'm' || this.options[i] === 'x' || this.options[i] === 'l' || this.options[i] === 's' || this.options[i] === 'u')) {
        throw new Error("The regular expression option [".concat(this.options[i], "] is not supported"));
      }
    }
  }
  _createClass(BSONRegExp, [{
    key: "toExtendedJSON",
    value: function toExtendedJSON(options) {
      options = options || {};
      if (options.legacy) {
        return {
          $regex: this.pattern,
          $options: this.options
        };
      }
      return {
        $regularExpression: {
          pattern: this.pattern,
          options: this.options
        }
      };
    }
  }], [{
    key: "parseOptions",
    value: function parseOptions(options) {
      return options ? options.split('').sort().join('') : '';
    }
  }, {
    key: "fromExtendedJSON",
    value: function fromExtendedJSON(doc) {
      if (doc.$regex) {
        if (doc.$regex._bsontype === 'BSONRegExp') {
          return doc;
        }
        return new BSONRegExp(doc.$regex, BSONRegExp.parseOptions(doc.$options));
      }
      return new BSONRegExp(doc.$regularExpression.pattern, BSONRegExp.parseOptions(doc.$regularExpression.options));
    }
  }]);
  Object.defineProperty(BSONRegExp.prototype, '_bsontype', {
    value: 'BSONRegExp'
  });
  return BSONRegExp;
}();
var regexp = BSONRegExp;
var BSONSymbol = /*#__PURE__*/
function () {
  function BSONSymbol(value) {
    _classCallCheck(this, BSONSymbol);
    this.value = value;
  }
  _createClass(BSONSymbol, [{
    key: "valueOf",
    value: function valueOf() {
      return this.value;
    }
  }, {
    key: "toString",
    value: function toString() {
      return this.value;
    }
  }, {
    key: "inspect",
    value: function inspect() {
      return this.value;
    }
  }, {
    key: "toJSON",
    value: function toJSON() {
      return this.value;
    }
  }, {
    key: "toExtendedJSON",
    value: function toExtendedJSON() {
      return {
        $symbol: this.value
      };
    }
  }], [{
    key: "fromExtendedJSON",
    value: function fromExtendedJSON(doc) {
      return new BSONSymbol(doc.$symbol);
    }
  }]);
  Object.defineProperty(BSONSymbol.prototype, '_bsontype', {
    value: 'Symbol'
  });
  return BSONSymbol;
}();
var symbol = BSONSymbol;
var Int32 = /*#__PURE__*/
function () {
  function Int32(value) {
    _classCallCheck(this, Int32);
    if (value instanceof Number) {
      value = value.valueOf();
    }
    this.value = value;
  }
  _createClass(Int32, [{
    key: "valueOf",
    value: function valueOf() {
      return this.value;
    }
  }, {
    key: "toJSON",
    value: function toJSON() {
      return this.value;
    }
  }, {
    key: "toExtendedJSON",
    value: function toExtendedJSON(options) {
      if (options && (options.relaxed || options.legacy)) return this.value;
      return {
        $numberInt: this.value.toString()
      };
    }
  }], [{
    key: "fromExtendedJSON",
    value: function fromExtendedJSON(doc, options) {
      return options && options.relaxed ? parseInt(doc.$numberInt, 10) : new Int32(doc.$numberInt);
    }
  }]);
  Object.defineProperty(Int32.prototype, '_bsontype', {
    value: 'Int32'
  });
  return Int32;
}();
var int_32 = Int32;
var Code = /*#__PURE__*/
function () {
  function Code(code, scope) {
    _classCallCheck(this, Code);
    this.code = code;
    this.scope = scope;
  }
  _createClass(Code, [{
    key: "toJSON",
    value: function toJSON() {
      return {
        scope: this.scope,
        code: this.code
      };
    }
  }, {
    key: "toExtendedJSON",
    value: function toExtendedJSON() {
      if (this.scope) {
        return {
          $code: this.code,
          $scope: this.scope
        };
      }
      return {
        $code: this.code
      };
    }
  }], [{
    key: "fromExtendedJSON",
    value: function fromExtendedJSON(doc) {
      return new Code(doc.$code, doc.$scope);
    }
  }]);
  Object.defineProperty(Code.prototype, '_bsontype', {
    value: 'Code'
  });
  return Code;
}();
var code = Code;
var Buffer$3 = /*#__PURE__*/(() => bufferEs6.Buffer)();
var PARSE_STRING_REGEXP = /^(\+|-)?(\d+|(\d*\.\d*))?(E|e)?([-+])?(\d+)?$/;
var PARSE_INF_REGEXP = /^(\+|-)?(Infinity|inf)$/i;
var PARSE_NAN_REGEXP = /^(\+|-)?NaN$/i;
var EXPONENT_MAX = 6111;
var EXPONENT_MIN = -6176;
var EXPONENT_BIAS = 6176;
var MAX_DIGITS = 34;
var NAN_BUFFER = /*#__PURE__*/[0x7c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00].reverse();
var INF_NEGATIVE_BUFFER = /*#__PURE__*/[0xf8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00].reverse();
var INF_POSITIVE_BUFFER = /*#__PURE__*/[0x78, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00].reverse();
var EXPONENT_REGEX = /^([-+])?(\d+)?$/;
function isDigit(value) {
  return !isNaN(parseInt(value, 10));
}
function divideu128(value) {
  var DIVISOR = long_1$1.fromNumber(1000 * 1000 * 1000);
  var _rem = long_1$1.fromNumber(0);
  if (!value.parts[0] && !value.parts[1] && !value.parts[2] && !value.parts[3]) {
    return {
      quotient: value,
      rem: _rem
    };
  }
  for (var i = 0; i <= 3; i++) {
    _rem = _rem.shiftLeft(32);
    _rem = _rem.add(new long_1$1(value.parts[i], 0));
    value.parts[i] = _rem.div(DIVISOR).low;
    _rem = _rem.modulo(DIVISOR);
  }
  return {
    quotient: value,
    rem: _rem
  };
}
function multiply64x2(left, right) {
  if (!left && !right) {
    return {
      high: long_1$1.fromNumber(0),
      low: long_1$1.fromNumber(0)
    };
  }
  var leftHigh = left.shiftRightUnsigned(32);
  var leftLow = new long_1$1(left.getLowBits(), 0);
  var rightHigh = right.shiftRightUnsigned(32);
  var rightLow = new long_1$1(right.getLowBits(), 0);
  var productHigh = leftHigh.multiply(rightHigh);
  var productMid = leftHigh.multiply(rightLow);
  var productMid2 = leftLow.multiply(rightHigh);
  var productLow = leftLow.multiply(rightLow);
  productHigh = productHigh.add(productMid.shiftRightUnsigned(32));
  productMid = new long_1$1(productMid.getLowBits(), 0).add(productMid2).add(productLow.shiftRightUnsigned(32));
  productHigh = productHigh.add(productMid.shiftRightUnsigned(32));
  productLow = productMid.shiftLeft(32).add(new long_1$1(productLow.getLowBits(), 0));
  return {
    high: productHigh,
    low: productLow
  };
}
function lessThan(left, right) {
  var uhleft = left.high >>> 0;
  var uhright = right.high >>> 0;
  if (uhleft < uhright) {
    return true;
  } else if (uhleft === uhright) {
    var ulleft = left.low >>> 0;
    var ulright = right.low >>> 0;
    if (ulleft < ulright) return true;
  }
  return false;
}
function invalidErr(string, message) {
  throw new TypeError("\"".concat(string, "\" is not a valid Decimal128 string - ").concat(message));
}
var Decimal128 = /*#__PURE__*/
function () {
  function Decimal128(bytes) {
    this.bytes = bytes;
  }
  Decimal128.fromString = function (string) {
    var isNegative = false;
    var sawRadix = false;
    var foundNonZero = false;
    var significantDigits = 0;
    var nDigitsRead = 0;
    var nDigits = 0;
    var radixPosition = 0;
    var firstNonZero = 0;
    var digits = [0];
    var nDigitsStored = 0;
    var digitsInsert = 0;
    var firstDigit = 0;
    var lastDigit = 0;
    var exponent = 0;
    var i = 0;
    var significandHigh = [0, 0];
    var significandLow = [0, 0];
    var biasedExponent = 0;
    var index = 0;
    if (string.length >= 7000) {
      throw new TypeError('' + string + ' not a valid Decimal128 string');
    }
    var stringMatch = string.match(PARSE_STRING_REGEXP);
    var infMatch = string.match(PARSE_INF_REGEXP);
    var nanMatch = string.match(PARSE_NAN_REGEXP);
    if (!stringMatch && !infMatch && !nanMatch || string.length === 0) {
      throw new TypeError('' + string + ' not a valid Decimal128 string');
    }
    if (stringMatch) {
      var unsignedNumber = stringMatch[2];
      var e = stringMatch[4];
      var expSign = stringMatch[5];
      var expNumber = stringMatch[6];
      if (e && expNumber === undefined) invalidErr(string, 'missing exponent power');
      if (e && unsignedNumber === undefined) invalidErr(string, 'missing exponent base');
      if (e === undefined && (expSign || expNumber)) {
        invalidErr(string, 'missing e before exponent');
      }
    }
    if (string[index] === '+' || string[index] === '-') {
      isNegative = string[index++] === '-';
    }
    if (!isDigit(string[index]) && string[index] !== '.') {
      if (string[index] === 'i' || string[index] === 'I') {
        return new Decimal128(Buffer$3.from(isNegative ? INF_NEGATIVE_BUFFER : INF_POSITIVE_BUFFER));
      } else if (string[index] === 'N') {
        return new Decimal128(Buffer$3.from(NAN_BUFFER));
      }
    }
    while (isDigit(string[index]) || string[index] === '.') {
      if (string[index] === '.') {
        if (sawRadix) invalidErr(string, 'contains multiple periods');
        sawRadix = true;
        index = index + 1;
        continue;
      }
      if (nDigitsStored < 34) {
        if (string[index] !== '0' || foundNonZero) {
          if (!foundNonZero) {
            firstNonZero = nDigitsRead;
          }
          foundNonZero = true;
          digits[digitsInsert++] = parseInt(string[index], 10);
          nDigitsStored = nDigitsStored + 1;
        }
      }
      if (foundNonZero) nDigits = nDigits + 1;
      if (sawRadix) radixPosition = radixPosition + 1;
      nDigitsRead = nDigitsRead + 1;
      index = index + 1;
    }
    if (sawRadix && !nDigitsRead) throw new TypeError('' + string + ' not a valid Decimal128 string');
    if (string[index] === 'e' || string[index] === 'E') {
      var match = string.substr(++index).match(EXPONENT_REGEX);
      if (!match || !match[2]) return new Decimal128(Buffer$3.from(NAN_BUFFER));
      exponent = parseInt(match[0], 10);
      index = index + match[0].length;
    }
    if (string[index]) return new Decimal128(Buffer$3.from(NAN_BUFFER));
    firstDigit = 0;
    if (!nDigitsStored) {
      firstDigit = 0;
      lastDigit = 0;
      digits[0] = 0;
      nDigits = 1;
      nDigitsStored = 1;
      significantDigits = 0;
    } else {
      lastDigit = nDigitsStored - 1;
      significantDigits = nDigits;
      if (significantDigits !== 1) {
        while (string[firstNonZero + significantDigits - 1] === '0') {
          significantDigits = significantDigits - 1;
        }
      }
    }
    if (exponent <= radixPosition && radixPosition - exponent > 1 << 14) {
      exponent = EXPONENT_MIN;
    } else {
      exponent = exponent - radixPosition;
    }
    while (exponent > EXPONENT_MAX) {
      lastDigit = lastDigit + 1;
      if (lastDigit - firstDigit > MAX_DIGITS) {
        var digitsString = digits.join('');
        if (digitsString.match(/^0+$/)) {
          exponent = EXPONENT_MAX;
          break;
        }
        invalidErr(string, 'overflow');
      }
      exponent = exponent - 1;
    }
    while (exponent < EXPONENT_MIN || nDigitsStored < nDigits) {
      if (lastDigit === 0 && significantDigits < nDigitsStored) {
        exponent = EXPONENT_MIN;
        significantDigits = 0;
        break;
      }
      if (nDigitsStored < nDigits) {
        nDigits = nDigits - 1;
      } else {
        lastDigit = lastDigit - 1;
      }
      if (exponent < EXPONENT_MAX) {
        exponent = exponent + 1;
      } else {
        var _digitsString = digits.join('');
        if (_digitsString.match(/^0+$/)) {
          exponent = EXPONENT_MAX;
          break;
        }
        invalidErr(string, 'overflow');
      }
    }
    if (lastDigit - firstDigit + 1 < significantDigits) {
      var endOfString = nDigitsRead;
      if (sawRadix) {
        firstNonZero = firstNonZero + 1;
        endOfString = endOfString + 1;
      }
      if (isNegative) {
        firstNonZero = firstNonZero + 1;
        endOfString = endOfString + 1;
      }
      var roundDigit = parseInt(string[firstNonZero + lastDigit + 1], 10);
      var roundBit = 0;
      if (roundDigit >= 5) {
        roundBit = 1;
        if (roundDigit === 5) {
          roundBit = digits[lastDigit] % 2 === 1;
          for (i = firstNonZero + lastDigit + 2; i < endOfString; i++) {
            if (parseInt(string[i], 10)) {
              roundBit = 1;
              break;
            }
          }
        }
      }
      if (roundBit) {
        var dIdx = lastDigit;
        for (; dIdx >= 0; dIdx--) {
          if (++digits[dIdx] > 9) {
            digits[dIdx] = 0;
            if (dIdx === 0) {
              if (exponent < EXPONENT_MAX) {
                exponent = exponent + 1;
                digits[dIdx] = 1;
              } else {
                return new Decimal128(Buffer$3.from(isNegative ? INF_NEGATIVE_BUFFER : INF_POSITIVE_BUFFER));
              }
            }
          }
        }
      }
    }
    significandHigh = long_1$1.fromNumber(0);
    significandLow = long_1$1.fromNumber(0);
    if (significantDigits === 0) {
      significandHigh = long_1$1.fromNumber(0);
      significandLow = long_1$1.fromNumber(0);
    } else if (lastDigit - firstDigit < 17) {
      var _dIdx = firstDigit;
      significandLow = long_1$1.fromNumber(digits[_dIdx++]);
      significandHigh = new long_1$1(0, 0);
      for (; _dIdx <= lastDigit; _dIdx++) {
        significandLow = significandLow.multiply(long_1$1.fromNumber(10));
        significandLow = significandLow.add(long_1$1.fromNumber(digits[_dIdx]));
      }
    } else {
      var _dIdx2 = firstDigit;
      significandHigh = long_1$1.fromNumber(digits[_dIdx2++]);
      for (; _dIdx2 <= lastDigit - 17; _dIdx2++) {
        significandHigh = significandHigh.multiply(long_1$1.fromNumber(10));
        significandHigh = significandHigh.add(long_1$1.fromNumber(digits[_dIdx2]));
      }
      significandLow = long_1$1.fromNumber(digits[_dIdx2++]);
      for (; _dIdx2 <= lastDigit; _dIdx2++) {
        significandLow = significandLow.multiply(long_1$1.fromNumber(10));
        significandLow = significandLow.add(long_1$1.fromNumber(digits[_dIdx2]));
      }
    }
    var significand = multiply64x2(significandHigh, long_1$1.fromString('100000000000000000'));
    significand.low = significand.low.add(significandLow);
    if (lessThan(significand.low, significandLow)) {
      significand.high = significand.high.add(long_1$1.fromNumber(1));
    }
    biasedExponent = exponent + EXPONENT_BIAS;
    var dec = {
      low: long_1$1.fromNumber(0),
      high: long_1$1.fromNumber(0)
    };
    if (significand.high.shiftRightUnsigned(49).and(long_1$1.fromNumber(1)).equals(long_1$1.fromNumber(1))) {
      dec.high = dec.high.or(long_1$1.fromNumber(0x3).shiftLeft(61));
      dec.high = dec.high.or(long_1$1.fromNumber(biasedExponent).and(long_1$1.fromNumber(0x3fff).shiftLeft(47)));
      dec.high = dec.high.or(significand.high.and(long_1$1.fromNumber(0x7fffffffffff)));
    } else {
      dec.high = dec.high.or(long_1$1.fromNumber(biasedExponent & 0x3fff).shiftLeft(49));
      dec.high = dec.high.or(significand.high.and(long_1$1.fromNumber(0x1ffffffffffff)));
    }
    dec.low = significand.low;
    if (isNegative) {
      dec.high = dec.high.or(long_1$1.fromString('9223372036854775808'));
    }
    var buffer = Buffer$3.alloc(16);
    index = 0;
    buffer[index++] = dec.low.low & 0xff;
    buffer[index++] = dec.low.low >> 8 & 0xff;
    buffer[index++] = dec.low.low >> 16 & 0xff;
    buffer[index++] = dec.low.low >> 24 & 0xff;
    buffer[index++] = dec.low.high & 0xff;
    buffer[index++] = dec.low.high >> 8 & 0xff;
    buffer[index++] = dec.low.high >> 16 & 0xff;
    buffer[index++] = dec.low.high >> 24 & 0xff;
    buffer[index++] = dec.high.low & 0xff;
    buffer[index++] = dec.high.low >> 8 & 0xff;
    buffer[index++] = dec.high.low >> 16 & 0xff;
    buffer[index++] = dec.high.low >> 24 & 0xff;
    buffer[index++] = dec.high.high & 0xff;
    buffer[index++] = dec.high.high >> 8 & 0xff;
    buffer[index++] = dec.high.high >> 16 & 0xff;
    buffer[index++] = dec.high.high >> 24 & 0xff;
    return new Decimal128(buffer);
  };
  var COMBINATION_MASK = 0x1f;
  var EXPONENT_MASK = 0x3fff;
  var COMBINATION_INFINITY = 30;
  var COMBINATION_NAN = 31;
  Decimal128.prototype.toString = function () {
    var high;
    var midh;
    var midl;
    var low;
    var combination;
    var biased_exponent;
    var significand_digits = 0;
    var significand = new Array(36);
    for (var i = 0; i < significand.length; i++) {
      significand[i] = 0;
    }
    var index = 0;
    var exponent;
    var scientific_exponent;
    var is_zero = false;
    var significand_msb;
    var significand128 = {
      parts: new Array(4)
    };
    var j, k;
    var string = [];
    index = 0;
    var buffer = this.bytes;
    low = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
    midl = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
    midh = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
    high = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
    index = 0;
    var dec = {
      low: new long_1$1(low, midl),
      high: new long_1$1(midh, high)
    };
    if (dec.high.lessThan(long_1$1.ZERO)) {
      string.push('-');
    }
    combination = high >> 26 & COMBINATION_MASK;
    if (combination >> 3 === 3) {
      if (combination === COMBINATION_INFINITY) {
        return string.join('') + 'Infinity';
      } else if (combination === COMBINATION_NAN) {
        return 'NaN';
      } else {
        biased_exponent = high >> 15 & EXPONENT_MASK;
        significand_msb = 0x08 + (high >> 14 & 0x01);
      }
    } else {
      significand_msb = high >> 14 & 0x07;
      biased_exponent = high >> 17 & EXPONENT_MASK;
    }
    exponent = biased_exponent - EXPONENT_BIAS;
    significand128.parts[0] = (high & 0x3fff) + ((significand_msb & 0xf) << 14);
    significand128.parts[1] = midh;
    significand128.parts[2] = midl;
    significand128.parts[3] = low;
    if (significand128.parts[0] === 0 && significand128.parts[1] === 0 && significand128.parts[2] === 0 && significand128.parts[3] === 0) {
      is_zero = true;
    } else {
      for (k = 3; k >= 0; k--) {
        var least_digits = 0;
        var result = divideu128(significand128);
        significand128 = result.quotient;
        least_digits = result.rem.low;
        if (!least_digits) continue;
        for (j = 8; j >= 0; j--) {
          significand[k * 9 + j] = least_digits % 10;
          least_digits = Math.floor(least_digits / 10);
        }
      }
    }
    if (is_zero) {
      significand_digits = 1;
      significand[index] = 0;
    } else {
      significand_digits = 36;
      while (!significand[index]) {
        significand_digits = significand_digits - 1;
        index = index + 1;
      }
    }
    scientific_exponent = significand_digits - 1 + exponent;
    if (scientific_exponent >= 34 || scientific_exponent <= -7 || exponent > 0) {
      if (significand_digits > 34) {
        string.push(0);
        if (exponent > 0) string.push('E+' + exponent);else if (exponent < 0) string.push('E' + exponent);
        return string.join('');
      }
      string.push(significand[index++]);
      significand_digits = significand_digits - 1;
      if (significand_digits) {
        string.push('.');
      }
      for (var _i = 0; _i < significand_digits; _i++) {
        string.push(significand[index++]);
      }
      string.push('E');
      if (scientific_exponent > 0) {
        string.push('+' + scientific_exponent);
      } else {
        string.push(scientific_exponent);
      }
    } else {
      if (exponent >= 0) {
        for (var _i2 = 0; _i2 < significand_digits; _i2++) {
          string.push(significand[index++]);
        }
      } else {
        var radix_position = significand_digits + exponent;
        if (radix_position > 0) {
          for (var _i3 = 0; _i3 < radix_position; _i3++) {
            string.push(significand[index++]);
          }
        } else {
          string.push('0');
        }
        string.push('.');
        while (radix_position++ < 0) {
          string.push('0');
        }
        for (var _i4 = 0; _i4 < significand_digits - Math.max(radix_position - 1, 0); _i4++) {
          string.push(significand[index++]);
        }
      }
    }
    return string.join('');
  };
  Decimal128.prototype.toJSON = function () {
    return {
      $numberDecimal: this.toString()
    };
  };
  Decimal128.prototype.toExtendedJSON = function () {
    return {
      $numberDecimal: this.toString()
    };
  };
  Decimal128.fromExtendedJSON = function (doc) {
    return Decimal128.fromString(doc.$numberDecimal);
  };
  Object.defineProperty(Decimal128.prototype, '_bsontype', {
    value: 'Decimal128'
  });
  return Decimal128;
}();
var decimal128 = Decimal128;
var MinKey = /*#__PURE__*/
function () {
  function MinKey() {
    _classCallCheck(this, MinKey);
  }
  _createClass(MinKey, [{
    key: "toExtendedJSON",
    value: function toExtendedJSON() {
      return {
        $minKey: 1
      };
    }
  }], [{
    key: "fromExtendedJSON",
    value: function fromExtendedJSON() {
      return new MinKey();
    }
  }]);
  Object.defineProperty(MinKey.prototype, '_bsontype', {
    value: 'MinKey'
  });
  return MinKey;
}();
var min_key = MinKey;
var MaxKey = /*#__PURE__*/
function () {
  function MaxKey() {
    _classCallCheck(this, MaxKey);
  }
  _createClass(MaxKey, [{
    key: "toExtendedJSON",
    value: function toExtendedJSON() {
      return {
        $maxKey: 1
      };
    }
  }], [{
    key: "fromExtendedJSON",
    value: function fromExtendedJSON() {
      return new MaxKey();
    }
  }]);
  Object.defineProperty(MaxKey.prototype, '_bsontype', {
    value: 'MaxKey'
  });
  return MaxKey;
}();
var max_key = MaxKey;
var DBRef = /*#__PURE__*/
function () {
  function DBRef(collection, oid, db, fields) {
    _classCallCheck(this, DBRef);
    var parts = collection.split('.');
    if (parts.length === 2) {
      db = parts.shift();
      collection = parts.shift();
    }
    this.collection = collection;
    this.oid = oid;
    this.db = db;
    this.fields = fields || {};
  }
  _createClass(DBRef, [{
    key: "toJSON",
    value: function toJSON() {
      var o = Object.assign({
        $ref: this.collection,
        $id: this.oid
      }, this.fields);
      if (this.db != null) o.$db = this.db;
      return o;
    }
  }, {
    key: "toExtendedJSON",
    value: function toExtendedJSON(options) {
      options = options || {};
      var o = {
        $ref: this.collection,
        $id: this.oid
      };
      if (options.legacy) {
        return o;
      }
      if (this.db) o.$db = this.db;
      o = Object.assign(o, this.fields);
      return o;
    }
  }], [{
    key: "fromExtendedJSON",
    value: function fromExtendedJSON(doc) {
      var copy = Object.assign({}, doc);
      ['$ref', '$id', '$db'].forEach(function (k) {
        return delete copy[k];
      });
      return new DBRef(doc.$ref, doc.$id, doc.$db, copy);
    }
  }]);
  Object.defineProperty(DBRef.prototype, '_bsontype', {
    value: 'DBRef'
  });
  Object.defineProperty(DBRef.prototype, 'namespace', {
    get: function get() {
      return this.collection;
    },
    set: function set(val) {
      this.collection = val;
    },
    configurable: false
  });
  return DBRef;
}();
var db_ref = DBRef;
var Buffer$4 = /*#__PURE__*/(() => bufferEs6.Buffer)();
var Binary = /*#__PURE__*/
function () {
  function Binary(buffer, subType) {
    _classCallCheck(this, Binary);
    if (buffer != null && !(typeof buffer === 'string') && !Buffer$4.isBuffer(buffer) && !(buffer instanceof Uint8Array) && !Array.isArray(buffer)) {
      throw new TypeError('only String, Buffer, Uint8Array or Array accepted');
    }
    this.sub_type = subType == null ? BSON_BINARY_SUBTYPE_DEFAULT : subType;
    this.position = 0;
    if (buffer != null && !(buffer instanceof Number)) {
      if (typeof buffer === 'string') {
        if (typeof Buffer$4 !== 'undefined') {
          this.buffer = Buffer$4.from(buffer);
        } else if (typeof Uint8Array !== 'undefined' || Array.isArray(buffer)) {
          this.buffer = writeStringToArray(buffer);
        } else {
          throw new TypeError('only String, Buffer, Uint8Array or Array accepted');
        }
      } else {
        this.buffer = buffer;
      }
      this.position = buffer.length;
    } else {
      if (typeof Buffer$4 !== 'undefined') {
        this.buffer = Buffer$4.alloc(Binary.BUFFER_SIZE);
      } else if (typeof Uint8Array !== 'undefined') {
        this.buffer = new Uint8Array(new ArrayBuffer(Binary.BUFFER_SIZE));
      } else {
        this.buffer = new Array(Binary.BUFFER_SIZE);
      }
    }
  }
  _createClass(Binary, [{
    key: "put",
    value: function put(byte_value) {
      if (byte_value['length'] != null && typeof byte_value !== 'number' && byte_value.length !== 1) throw new TypeError('only accepts single character String, Uint8Array or Array');
      if (typeof byte_value !== 'number' && byte_value < 0 || byte_value > 255) throw new TypeError('only accepts number in a valid unsigned byte range 0-255');
      var decoded_byte = null;
      if (typeof byte_value === 'string') {
        decoded_byte = byte_value.charCodeAt(0);
      } else if (byte_value['length'] != null) {
        decoded_byte = byte_value[0];
      } else {
        decoded_byte = byte_value;
      }
      if (this.buffer.length > this.position) {
        this.buffer[this.position++] = decoded_byte;
      } else {
        if (typeof Buffer$4 !== 'undefined' && Buffer$4.isBuffer(this.buffer)) {
          var buffer = Buffer$4.alloc(Binary.BUFFER_SIZE + this.buffer.length);
          this.buffer.copy(buffer, 0, 0, this.buffer.length);
          this.buffer = buffer;
          this.buffer[this.position++] = decoded_byte;
        } else {
          var _buffer = null;
          if (isUint8Array(this.buffer)) {
            _buffer = new Uint8Array(new ArrayBuffer(Binary.BUFFER_SIZE + this.buffer.length));
          } else {
            _buffer = new Array(Binary.BUFFER_SIZE + this.buffer.length);
          }
          for (var i = 0; i < this.buffer.length; i++) {
            _buffer[i] = this.buffer[i];
          }
          this.buffer = _buffer;
          this.buffer[this.position++] = decoded_byte;
        }
      }
    }
  }, {
    key: "write",
    value: function write(string, offset) {
      offset = typeof offset === 'number' ? offset : this.position;
      if (this.buffer.length < offset + string.length) {
        var buffer = null;
        if (typeof Buffer$4 !== 'undefined' && Buffer$4.isBuffer(this.buffer)) {
          buffer = Buffer$4.alloc(this.buffer.length + string.length);
          this.buffer.copy(buffer, 0, 0, this.buffer.length);
        } else if (isUint8Array(this.buffer)) {
          buffer = new Uint8Array(new ArrayBuffer(this.buffer.length + string.length));
          for (var i = 0; i < this.position; i++) {
            buffer[i] = this.buffer[i];
          }
        }
        this.buffer = buffer;
      }
      if (typeof Buffer$4 !== 'undefined' && Buffer$4.isBuffer(string) && Buffer$4.isBuffer(this.buffer)) {
        string.copy(this.buffer, offset, 0, string.length);
        this.position = offset + string.length > this.position ? offset + string.length : this.position;
      } else if (typeof Buffer$4 !== 'undefined' && typeof string === 'string' && Buffer$4.isBuffer(this.buffer)) {
        this.buffer.write(string, offset, 'binary');
        this.position = offset + string.length > this.position ? offset + string.length : this.position;
      } else if (isUint8Array(string) || Array.isArray(string) && typeof string !== 'string') {
        for (var _i = 0; _i < string.length; _i++) {
          this.buffer[offset++] = string[_i];
        }
        this.position = offset > this.position ? offset : this.position;
      } else if (typeof string === 'string') {
        for (var _i2 = 0; _i2 < string.length; _i2++) {
          this.buffer[offset++] = string.charCodeAt(_i2);
        }
        this.position = offset > this.position ? offset : this.position;
      }
    }
  }, {
    key: "read",
    value: function read(position, length) {
      length = length && length > 0 ? length : this.position;
      if (this.buffer['slice']) {
        return this.buffer.slice(position, position + length);
      }
      var buffer = typeof Uint8Array !== 'undefined' ? new Uint8Array(new ArrayBuffer(length)) : new Array(length);
      for (var i = 0; i < length; i++) {
        buffer[i] = this.buffer[position++];
      }
      return buffer;
    }
  }, {
    key: "value",
    value: function value(asRaw) {
      asRaw = asRaw == null ? false : asRaw;
      if (asRaw && typeof Buffer$4 !== 'undefined' && Buffer$4.isBuffer(this.buffer) && this.buffer.length === this.position) return this.buffer;
      if (typeof Buffer$4 !== 'undefined' && Buffer$4.isBuffer(this.buffer)) {
        return asRaw ? this.buffer.slice(0, this.position) : this.buffer.toString('binary', 0, this.position);
      } else {
        if (asRaw) {
          if (this.buffer['slice'] != null) {
            return this.buffer.slice(0, this.position);
          } else {
            var newBuffer = isUint8Array(this.buffer) ? new Uint8Array(new ArrayBuffer(this.position)) : new Array(this.position);
            for (var i = 0; i < this.position; i++) {
              newBuffer[i] = this.buffer[i];
            }
            return newBuffer;
          }
        } else {
          return convertArraytoUtf8BinaryString(this.buffer, 0, this.position);
        }
      }
    }
  }, {
    key: "length",
    value: function length() {
      return this.position;
    }
  }, {
    key: "toJSON",
    value: function toJSON() {
      return this.buffer != null ? this.buffer.toString('base64') : '';
    }
  }, {
    key: "toString",
    value: function toString(format) {
      return this.buffer != null ? this.buffer.slice(0, this.position).toString(format) : '';
    }
  }, {
    key: "toExtendedJSON",
    value: function toExtendedJSON(options) {
      options = options || {};
      var base64String = Buffer$4.isBuffer(this.buffer) ? this.buffer.toString('base64') : Buffer$4.from(this.buffer).toString('base64');
      var subType = Number(this.sub_type).toString(16);
      if (options.legacy) {
        return {
          $binary: base64String,
          $type: subType.length === 1 ? '0' + subType : subType
        };
      }
      return {
        $binary: {
          base64: base64String,
          subType: subType.length === 1 ? '0' + subType : subType
        }
      };
    }
  }], [{
    key: "fromExtendedJSON",
    value: function fromExtendedJSON(doc, options) {
      options = options || {};
      var data, type;
      if (options.legacy) {
        type = doc.$type ? parseInt(doc.$type, 16) : 0;
        data = Buffer$4.from(doc.$binary, 'base64');
      } else {
        type = doc.$binary.subType ? parseInt(doc.$binary.subType, 16) : 0;
        data = Buffer$4.from(doc.$binary.base64, 'base64');
      }
      return new Binary(data, type);
    }
  }]);
  var BSON_BINARY_SUBTYPE_DEFAULT = 0;
  function isUint8Array(obj) {
    return Object.prototype.toString.call(obj) === '[object Uint8Array]';
  }
  function writeStringToArray(data) {
    var buffer = typeof Uint8Array !== 'undefined' ? new Uint8Array(new ArrayBuffer(data.length)) : new Array(data.length);
    for (var i = 0; i < data.length; i++) {
      buffer[i] = data.charCodeAt(i);
    }
    return buffer;
  }
  function convertArraytoUtf8BinaryString(byteArray, startIndex, endIndex) {
    var result = '';
    for (var i = startIndex; i < endIndex; i++) {
      result = result + String.fromCharCode(byteArray[i]);
    }
    return result;
  }
  Binary.BUFFER_SIZE = 256;
  Binary.SUBTYPE_DEFAULT = 0;
  Binary.SUBTYPE_FUNCTION = 1;
  Binary.SUBTYPE_BYTE_ARRAY = 2;
  Binary.SUBTYPE_UUID_OLD = 3;
  Binary.SUBTYPE_UUID = 4;
  Binary.SUBTYPE_MD5 = 5;
  Binary.SUBTYPE_USER_DEFINED = 128;
  Object.defineProperty(Binary.prototype, '_bsontype', {
    value: 'Binary'
  });
  return Binary;
}();
var binary = Binary;
var constants = {
  BSON_INT32_MAX: 0x7fffffff,
  BSON_INT32_MIN: -0x80000000,
  BSON_INT64_MAX: Math.pow(2, 63) - 1,
  BSON_INT64_MIN: -Math.pow(2, 63),
  JS_INT_MAX: 0x20000000000000,
  JS_INT_MIN: -0x20000000000000,
  BSON_DATA_NUMBER: 1,
  BSON_DATA_STRING: 2,
  BSON_DATA_OBJECT: 3,
  BSON_DATA_ARRAY: 4,
  BSON_DATA_BINARY: 5,
  BSON_DATA_UNDEFINED: 6,
  BSON_DATA_OID: 7,
  BSON_DATA_BOOLEAN: 8,
  BSON_DATA_DATE: 9,
  BSON_DATA_NULL: 10,
  BSON_DATA_REGEXP: 11,
  BSON_DATA_DBPOINTER: 12,
  BSON_DATA_CODE: 13,
  BSON_DATA_SYMBOL: 14,
  BSON_DATA_CODE_W_SCOPE: 15,
  BSON_DATA_INT: 16,
  BSON_DATA_TIMESTAMP: 17,
  BSON_DATA_LONG: 18,
  BSON_DATA_DECIMAL128: 19,
  BSON_DATA_MIN_KEY: 0xff,
  BSON_DATA_MAX_KEY: 0x7f,
  BSON_BINARY_SUBTYPE_DEFAULT: 0,
  BSON_BINARY_SUBTYPE_FUNCTION: 1,
  BSON_BINARY_SUBTYPE_BYTE_ARRAY: 2,
  BSON_BINARY_SUBTYPE_UUID: 3,
  BSON_BINARY_SUBTYPE_MD5: 4,
  BSON_BINARY_SUBTYPE_USER_DEFINED: 128
};
var keysToCodecs = {
  $oid: objectid,
  $binary: binary,
  $symbol: symbol,
  $numberInt: int_32,
  $numberDecimal: decimal128,
  $numberDouble: double_1,
  $numberLong: long_1$1,
  $minKey: min_key,
  $maxKey: max_key,
  $regex: regexp,
  $regularExpression: regexp,
  $timestamp: timestamp
};
function deserializeValue(self, key, value, options) {
  if (typeof value === 'number') {
    if (options.relaxed || options.legacy) {
      return value;
    }
    if (Math.floor(value) === value) {
      if (value >= BSON_INT32_MIN && value <= BSON_INT32_MAX) return new int_32(value);
      if (value >= BSON_INT64_MIN && value <= BSON_INT64_MAX) return new long_1$1.fromNumber(value);
    }
    return new double_1(value);
  }
  if (value == null || _typeof(value) !== 'object') return value;
  if (value.$undefined) return null;
  var keys = Object.keys(value).filter(function (k) {
    return k.startsWith('$') && value[k] != null;
  });
  for (var i = 0; i < keys.length; i++) {
    var c = keysToCodecs[keys[i]];
    if (c) return c.fromExtendedJSON(value, options);
  }
  if (value.$date != null) {
    var d = value.$date;
    var date = new Date();
    if (options.legacy) {
      if (typeof d === 'number') date.setTime(d);else if (typeof d === 'string') date.setTime(Date.parse(d));
    } else {
      if (typeof d === 'string') date.setTime(Date.parse(d));else if (long_1$1.isLong(d)) date.setTime(d.toNumber());else if (typeof d === 'number' && options.relaxed) date.setTime(d);
    }
    return date;
  }
  if (value.$code != null) {
    var copy = Object.assign({}, value);
    if (value.$scope) {
      copy.$scope = deserializeValue(self, null, value.$scope);
    }
    return code.fromExtendedJSON(value);
  }
  if (value.$ref != null || value.$dbPointer != null) {
    var v = value.$ref ? value : value.$dbPointer;
    if (v instanceof db_ref) return v;
    var dollarKeys = Object.keys(v).filter(function (k) {
      return k.startsWith('$');
    });
    var valid = true;
    dollarKeys.forEach(function (k) {
      if (['$ref', '$id', '$db'].indexOf(k) === -1) valid = false;
    });
    if (valid) return db_ref.fromExtendedJSON(v);
  }
  return value;
}
function parse(text, options) {
  var _this = this;
  options = Object.assign({}, {
    relaxed: true,
    legacy: false
  }, options);
  if (typeof options.relaxed === 'boolean') options.strict = !options.relaxed;
  if (typeof options.strict === 'boolean') options.relaxed = !options.strict;
  return JSON.parse(text, function (key, value) {
    return deserializeValue(_this, key, value, options);
  });
}
var BSON_INT32_MAX = 0x7fffffff,
  BSON_INT32_MIN = -0x80000000,
  BSON_INT64_MAX = 0x7fffffffffffffff,
  BSON_INT64_MIN = -0x8000000000000000;
function stringify(value, replacer, space, options) {
  if (space != null && _typeof(space) === 'object') {
    options = space;
    space = 0;
  }
  if (replacer != null && _typeof(replacer) === 'object' && !Array.isArray(replacer)) {
    options = replacer;
    replacer = null;
    space = 0;
  }
  options = Object.assign({}, {
    relaxed: true,
    legacy: false
  }, options);
  var doc = Array.isArray(value) ? serializeArray(value, options) : serializeDocument(value, options);
  return JSON.stringify(doc, replacer, space);
}
function serialize(bson, options) {
  options = options || {};
  return JSON.parse(stringify(bson, options));
}
function deserialize(ejson, options) {
  options = options || {};
  return parse(JSON.stringify(ejson), options);
}
function serializeArray(array, options) {
  return array.map(function (v) {
    return serializeValue(v, options);
  });
}
function getISOString(date) {
  var isoStr = date.toISOString();
  return date.getUTCMilliseconds() !== 0 ? isoStr : isoStr.slice(0, -5) + 'Z';
}
function serializeValue(value, options) {
  if (Array.isArray(value)) return serializeArray(value, options);
  if (value === undefined) return null;
  if (value instanceof Date) {
    var dateNum = value.getTime(),
      inRange = dateNum > -1 && dateNum < 253402318800000;
    if (options.legacy) {
      return options.relaxed && inRange ? {
        $date: value.getTime()
      } : {
        $date: getISOString(value)
      };
    }
    return options.relaxed && inRange ? {
      $date: getISOString(value)
    } : {
      $date: {
        $numberLong: value.getTime().toString()
      }
    };
  }
  if (typeof value === 'number' && !options.relaxed) {
    if (Math.floor(value) === value) {
      var int32Range = value >= BSON_INT32_MIN && value <= BSON_INT32_MAX,
        int64Range = value >= BSON_INT64_MIN && value <= BSON_INT64_MAX;
      if (int32Range) return {
        $numberInt: value.toString()
      };
      if (int64Range) return {
        $numberLong: value.toString()
      };
    }
    return {
      $numberDouble: value.toString()
    };
  }
  if (value instanceof RegExp) {
    var flags = value.flags;
    if (flags === undefined) {
      flags = value.toString().match(/[gimuy]*$/)[0];
    }
    var rx = new regexp(value.source, flags);
    return rx.toExtendedJSON(options);
  }
  if (value != null && _typeof(value) === 'object') return serializeDocument(value, options);
  return value;
}
var BSON_TYPE_MAPPINGS = {
  Binary: function Binary(o) {
    return new binary(o.value(), o.subtype);
  },
  Code: function Code(o) {
    return new code(o.code, o.scope);
  },
  DBRef: function DBRef(o) {
    return new db_ref(o.collection || o.namespace, o.oid, o.db, o.fields);
  },
  Decimal128: function Decimal128(o) {
    return new decimal128(o.bytes);
  },
  Double: function Double(o) {
    return new double_1(o.value);
  },
  Int32: function Int32(o) {
    return new int_32(o.value);
  },
  Long: function Long(o) {
    return long_1$1.fromBits(o.low != null ? o.low : o.low_, o.low != null ? o.high : o.high_, o.low != null ? o.unsigned : o.unsigned_);
  },
  MaxKey: function MaxKey() {
    return new max_key();
  },
  MinKey: function MinKey() {
    return new min_key();
  },
  ObjectID: function ObjectID(o) {
    return new objectid(o);
  },
  ObjectId: function ObjectId(o) {
    return new objectid(o);
  },
  BSONRegExp: function BSONRegExp(o) {
    return new regexp(o.pattern, o.options);
  },
  Symbol: function Symbol(o) {
    return new symbol(o.value);
  },
  Timestamp: function Timestamp(o) {
    return timestamp.fromBits(o.low, o.high);
  }
};
function serializeDocument(doc, options) {
  if (doc == null || _typeof(doc) !== 'object') throw new Error('not an object instance');
  var bsontype = doc._bsontype;
  if (typeof bsontype === 'undefined') {
    var _doc = {};
    for (var name in doc) {
      _doc[name] = serializeValue(doc[name], options);
    }
    return _doc;
  } else if (typeof bsontype === 'string') {
    var _doc2 = doc;
    if (typeof _doc2.toExtendedJSON !== 'function') {
      var mapper = BSON_TYPE_MAPPINGS[bsontype];
      if (!mapper) {
        throw new TypeError('Unrecognized or invalid _bsontype: ' + bsontype);
      }
      _doc2 = mapper(_doc2);
    }
    if (bsontype === 'Code' && _doc2.scope) {
      _doc2 = new code(_doc2.code, serializeValue(_doc2.scope, options));
    } else if (bsontype === 'DBRef' && _doc2.oid) {
      _doc2 = new db_ref(_doc2.collection, serializeValue(_doc2.oid, options), _doc2.db, _doc2.fields);
    }
    return _doc2.toExtendedJSON(options);
  } else {
    throw new Error('_bsontype must be a string, but was: ' + _typeof(bsontype));
  }
}
var extended_json = {
  parse: parse,
  deserialize: deserialize,
  serialize: serialize,
  stringify: stringify
};
var FIRST_BIT = 0x80;
var FIRST_TWO_BITS = 0xc0;
var FIRST_THREE_BITS = 0xe0;
var FIRST_FOUR_BITS = 0xf0;
var FIRST_FIVE_BITS = 0xf8;
var TWO_BIT_CHAR = 0xc0;
var THREE_BIT_CHAR = 0xe0;
var FOUR_BIT_CHAR = 0xf0;
var CONTINUING_CHAR = 0x80;
function validateUtf8(bytes, start, end) {
  var continuation = 0;
  for (var i = start; i < end; i += 1) {
    var _byte = bytes[i];
    if (continuation) {
      if ((_byte & FIRST_TWO_BITS) !== CONTINUING_CHAR) {
        return false;
      }
      continuation -= 1;
    } else if (_byte & FIRST_BIT) {
      if ((_byte & FIRST_THREE_BITS) === TWO_BIT_CHAR) {
        continuation = 1;
      } else if ((_byte & FIRST_FOUR_BITS) === THREE_BIT_CHAR) {
        continuation = 2;
      } else if ((_byte & FIRST_FIVE_BITS) === FOUR_BIT_CHAR) {
        continuation = 3;
      } else {
        return false;
      }
    }
  }
  return !continuation;
}
var validateUtf8_1 = validateUtf8;
var validate_utf8 = {
  validateUtf8: validateUtf8_1
};
var Buffer$5 = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => bufferEs6.Buffer)()));
var validateUtf8$1 = validate_utf8.validateUtf8;
var JS_INT_MAX_LONG = /*#__PURE__*/long_1$1.fromNumber(constants.JS_INT_MAX);
var JS_INT_MIN_LONG = /*#__PURE__*/long_1$1.fromNumber(constants.JS_INT_MIN);
var functionCache = (/* unused pure expression or super */ null && ({}));
function deserialize$1(buffer, options, isArray) {
  options = options == null ? {} : options;
  var index = options && options.index ? options.index : 0;
  var size = buffer[index] | buffer[index + 1] << 8 | buffer[index + 2] << 16 | buffer[index + 3] << 24;
  if (size < 5) {
    throw new Error("bson size must be >= 5, is ".concat(size));
  }
  if (options.allowObjectSmallerThanBufferSize && buffer.length < size) {
    throw new Error("buffer length ".concat(buffer.length, " must be >= bson size ").concat(size));
  }
  if (!options.allowObjectSmallerThanBufferSize && buffer.length !== size) {
    throw new Error("buffer length ".concat(buffer.length, " must === bson size ").concat(size));
  }
  if (size + index > buffer.length) {
    throw new Error("(bson size ".concat(size, " + options.index ").concat(index, " must be <= buffer length ").concat(Buffer$5.byteLength(buffer), ")"));
  }
  if (buffer[index + size - 1] !== 0) {
    throw new Error("One object, sized correctly, with a spot for an EOO, but the EOO isn't 0x00");
  }
  return deserializeObject(buffer, index, options, isArray);
}
function deserializeObject(buffer, index, options, isArray) {
  var evalFunctions = options['evalFunctions'] == null ? false : options['evalFunctions'];
  var cacheFunctions = options['cacheFunctions'] == null ? false : options['cacheFunctions'];
  var cacheFunctionsCrc32 = options['cacheFunctionsCrc32'] == null ? false : options['cacheFunctionsCrc32'];
  if (!cacheFunctionsCrc32) var crc32 = null;
  var fieldsAsRaw = options['fieldsAsRaw'] == null ? null : options['fieldsAsRaw'];
  var raw = options['raw'] == null ? false : options['raw'];
  var bsonRegExp = typeof options['bsonRegExp'] === 'boolean' ? options['bsonRegExp'] : false;
  var promoteBuffers = options['promoteBuffers'] == null ? false : options['promoteBuffers'];
  var promoteLongs = options['promoteLongs'] == null ? true : options['promoteLongs'];
  var promoteValues = options['promoteValues'] == null ? true : options['promoteValues'];
  var startIndex = index;
  if (buffer.length < 5) throw new Error('corrupt bson message < 5 bytes long');
  var size = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
  if (size < 5 || size > buffer.length) throw new Error('corrupt bson message');
  var object = isArray ? [] : {};
  var arrayIndex = 0;
  var done = false;
  while (!done) {
    var elementType = buffer[index++];
    if (elementType === 0) break;
    var i = index;
    while (buffer[i] !== 0x00 && i < buffer.length) {
      i++;
    }
    if (i >= Buffer$5.byteLength(buffer)) throw new Error('Bad BSON Document: illegal CString');
    var name = isArray ? arrayIndex++ : buffer.toString('utf8', index, i);
    index = i + 1;
    if (elementType === constants.BSON_DATA_STRING) {
      var stringSize = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      if (stringSize <= 0 || stringSize > buffer.length - index || buffer[index + stringSize - 1] !== 0) throw new Error('bad string length in bson');
      if (!validateUtf8$1(buffer, index, index + stringSize - 1)) {
        throw new Error('Invalid UTF-8 string in BSON document');
      }
      var s = buffer.toString('utf8', index, index + stringSize - 1);
      object[name] = s;
      index = index + stringSize;
    } else if (elementType === constants.BSON_DATA_OID) {
      var oid = Buffer$5.alloc(12);
      buffer.copy(oid, 0, index, index + 12);
      object[name] = new objectid(oid);
      index = index + 12;
    } else if (elementType === constants.BSON_DATA_INT && promoteValues === false) {
      object[name] = new int_32(buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24);
    } else if (elementType === constants.BSON_DATA_INT) {
      object[name] = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
    } else if (elementType === constants.BSON_DATA_NUMBER && promoteValues === false) {
      object[name] = new double_1(buffer.readDoubleLE(index));
      index = index + 8;
    } else if (elementType === constants.BSON_DATA_NUMBER) {
      object[name] = buffer.readDoubleLE(index);
      index = index + 8;
    } else if (elementType === constants.BSON_DATA_DATE) {
      var lowBits = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      var highBits = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      object[name] = new Date(new long_1$1(lowBits, highBits).toNumber());
    } else if (elementType === constants.BSON_DATA_BOOLEAN) {
      if (buffer[index] !== 0 && buffer[index] !== 1) throw new Error('illegal boolean type value');
      object[name] = buffer[index++] === 1;
    } else if (elementType === constants.BSON_DATA_OBJECT) {
      var _index = index;
      var objectSize = buffer[index] | buffer[index + 1] << 8 | buffer[index + 2] << 16 | buffer[index + 3] << 24;
      if (objectSize <= 0 || objectSize > buffer.length - index) throw new Error('bad embedded document length in bson');
      if (raw) {
        object[name] = buffer.slice(index, index + objectSize);
      } else {
        object[name] = deserializeObject(buffer, _index, options, false);
      }
      index = index + objectSize;
    } else if (elementType === constants.BSON_DATA_ARRAY) {
      var _index2 = index;
      var _objectSize = buffer[index] | buffer[index + 1] << 8 | buffer[index + 2] << 16 | buffer[index + 3] << 24;
      var arrayOptions = options;
      var stopIndex = index + _objectSize;
      if (fieldsAsRaw && fieldsAsRaw[name]) {
        arrayOptions = {};
        for (var n in options) {
          arrayOptions[n] = options[n];
        }
        arrayOptions['raw'] = true;
      }
      object[name] = deserializeObject(buffer, _index2, arrayOptions, true);
      index = index + _objectSize;
      if (buffer[index - 1] !== 0) throw new Error('invalid array terminator byte');
      if (index !== stopIndex) throw new Error('corrupted array bson');
    } else if (elementType === constants.BSON_DATA_UNDEFINED) {
      object[name] = undefined;
    } else if (elementType === constants.BSON_DATA_NULL) {
      object[name] = null;
    } else if (elementType === constants.BSON_DATA_LONG) {
      var _lowBits = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      var _highBits = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      var _long = new long_1$1(_lowBits, _highBits);
      if (promoteLongs && promoteValues === true) {
        object[name] = _long.lessThanOrEqual(JS_INT_MAX_LONG) && _long.greaterThanOrEqual(JS_INT_MIN_LONG) ? _long.toNumber() : _long;
      } else {
        object[name] = _long;
      }
    } else if (elementType === constants.BSON_DATA_DECIMAL128) {
      var bytes = Buffer$5.alloc(16);
      buffer.copy(bytes, 0, index, index + 16);
      index = index + 16;
      var decimal128$$1 = new decimal128(bytes);
      object[name] = decimal128$$1.toObject ? decimal128$$1.toObject() : decimal128$$1;
    } else if (elementType === constants.BSON_DATA_BINARY) {
      var binarySize = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      var totalBinarySize = binarySize;
      var subType = buffer[index++];
      if (binarySize < 0) throw new Error('Negative binary type element size found');
      if (binarySize > Buffer$5.byteLength(buffer)) throw new Error('Binary type size larger than document size');
      if (buffer['slice'] != null) {
        if (subType === binary.SUBTYPE_BYTE_ARRAY) {
          binarySize = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
          if (binarySize < 0) throw new Error('Negative binary type element size found for subtype 0x02');
          if (binarySize > totalBinarySize - 4) throw new Error('Binary type with subtype 0x02 contains to long binary size');
          if (binarySize < totalBinarySize - 4) throw new Error('Binary type with subtype 0x02 contains to short binary size');
        }
        if (promoteBuffers && promoteValues) {
          object[name] = buffer.slice(index, index + binarySize);
        } else {
          object[name] = new binary(buffer.slice(index, index + binarySize), subType);
        }
      } else {
        var _buffer = typeof Uint8Array !== 'undefined' ? new Uint8Array(new ArrayBuffer(binarySize)) : new Array(binarySize);
        if (subType === binary.SUBTYPE_BYTE_ARRAY) {
          binarySize = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
          if (binarySize < 0) throw new Error('Negative binary type element size found for subtype 0x02');
          if (binarySize > totalBinarySize - 4) throw new Error('Binary type with subtype 0x02 contains to long binary size');
          if (binarySize < totalBinarySize - 4) throw new Error('Binary type with subtype 0x02 contains to short binary size');
        }
        for (i = 0; i < binarySize; i++) {
          _buffer[i] = buffer[index + i];
        }
        if (promoteBuffers && promoteValues) {
          object[name] = _buffer;
        } else {
          object[name] = new binary(_buffer, subType);
        }
      }
      index = index + binarySize;
    } else if (elementType === constants.BSON_DATA_REGEXP && bsonRegExp === false) {
      i = index;
      while (buffer[i] !== 0x00 && i < buffer.length) {
        i++;
      }
      if (i >= buffer.length) throw new Error('Bad BSON Document: illegal CString');
      var source = buffer.toString('utf8', index, i);
      index = i + 1;
      i = index;
      while (buffer[i] !== 0x00 && i < buffer.length) {
        i++;
      }
      if (i >= buffer.length) throw new Error('Bad BSON Document: illegal CString');
      var regExpOptions = buffer.toString('utf8', index, i);
      index = i + 1;
      var optionsArray = new Array(regExpOptions.length);
      for (i = 0; i < regExpOptions.length; i++) {
        switch (regExpOptions[i]) {
          case 'm':
            optionsArray[i] = 'm';
            break;
          case 's':
            optionsArray[i] = 'g';
            break;
          case 'i':
            optionsArray[i] = 'i';
            break;
        }
      }
      object[name] = new RegExp(source, optionsArray.join(''));
    } else if (elementType === constants.BSON_DATA_REGEXP && bsonRegExp === true) {
      i = index;
      while (buffer[i] !== 0x00 && i < buffer.length) {
        i++;
      }
      if (i >= buffer.length) throw new Error('Bad BSON Document: illegal CString');
      var _source = buffer.toString('utf8', index, i);
      index = i + 1;
      i = index;
      while (buffer[i] !== 0x00 && i < buffer.length) {
        i++;
      }
      if (i >= buffer.length) throw new Error('Bad BSON Document: illegal CString');
      var _regExpOptions = buffer.toString('utf8', index, i);
      index = i + 1;
      object[name] = new regexp(_source, _regExpOptions);
    } else if (elementType === constants.BSON_DATA_SYMBOL) {
      var _stringSize = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      if (_stringSize <= 0 || _stringSize > buffer.length - index || buffer[index + _stringSize - 1] !== 0) throw new Error('bad string length in bson');
      object[name] = buffer.toString('utf8', index, index + _stringSize - 1);
      index = index + _stringSize;
    } else if (elementType === constants.BSON_DATA_TIMESTAMP) {
      var _lowBits2 = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      var _highBits2 = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      object[name] = new timestamp(_lowBits2, _highBits2);
    } else if (elementType === constants.BSON_DATA_MIN_KEY) {
      object[name] = new min_key();
    } else if (elementType === constants.BSON_DATA_MAX_KEY) {
      object[name] = new max_key();
    } else if (elementType === constants.BSON_DATA_CODE) {
      var _stringSize2 = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      if (_stringSize2 <= 0 || _stringSize2 > buffer.length - index || buffer[index + _stringSize2 - 1] !== 0) throw new Error('bad string length in bson');
      var functionString = buffer.toString('utf8', index, index + _stringSize2 - 1);
      if (evalFunctions) {
        if (cacheFunctions) {
          var hash = cacheFunctionsCrc32 ? crc32(functionString) : functionString;
          object[name] = isolateEvalWithHash(functionCache, hash, functionString, object);
        } else {
          object[name] = isolateEval(functionString);
        }
      } else {
        object[name] = new code(functionString);
      }
      index = index + _stringSize2;
    } else if (elementType === constants.BSON_DATA_CODE_W_SCOPE) {
      var totalSize = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      if (totalSize < 4 + 4 + 4 + 1) {
        throw new Error('code_w_scope total size shorter minimum expected length');
      }
      var _stringSize3 = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      if (_stringSize3 <= 0 || _stringSize3 > buffer.length - index || buffer[index + _stringSize3 - 1] !== 0) throw new Error('bad string length in bson');
      var _functionString = buffer.toString('utf8', index, index + _stringSize3 - 1);
      index = index + _stringSize3;
      var _index3 = index;
      var _objectSize2 = buffer[index] | buffer[index + 1] << 8 | buffer[index + 2] << 16 | buffer[index + 3] << 24;
      var scopeObject = deserializeObject(buffer, _index3, options, false);
      index = index + _objectSize2;
      if (totalSize < 4 + 4 + _objectSize2 + _stringSize3) {
        throw new Error('code_w_scope total size is to short, truncating scope');
      }
      if (totalSize > 4 + 4 + _objectSize2 + _stringSize3) {
        throw new Error('code_w_scope total size is to long, clips outer document');
      }
      if (evalFunctions) {
        if (cacheFunctions) {
          var _hash = cacheFunctionsCrc32 ? crc32(_functionString) : _functionString;
          object[name] = isolateEvalWithHash(functionCache, _hash, _functionString, object);
        } else {
          object[name] = isolateEval(_functionString);
        }
        object[name].scope = scopeObject;
      } else {
        object[name] = new code(_functionString, scopeObject);
      }
    } else if (elementType === constants.BSON_DATA_DBPOINTER) {
      var _stringSize4 = buffer[index++] | buffer[index++] << 8 | buffer[index++] << 16 | buffer[index++] << 24;
      if (_stringSize4 <= 0 || _stringSize4 > buffer.length - index || buffer[index + _stringSize4 - 1] !== 0) throw new Error('bad string length in bson');
      if (!validateUtf8$1(buffer, index, index + _stringSize4 - 1)) {
        throw new Error('Invalid UTF-8 string in BSON document');
      }
      var namespace = buffer.toString('utf8', index, index + _stringSize4 - 1);
      index = index + _stringSize4;
      var oidBuffer = Buffer$5.alloc(12);
      buffer.copy(oidBuffer, 0, index, index + 12);
      var _oid = new objectid(oidBuffer);
      index = index + 12;
      object[name] = new db_ref(namespace, _oid);
    } else {
      throw new Error('Detected unknown BSON type ' + elementType.toString(16) + ' for fieldname "' + name + '", are you using the latest BSON parser?');
    }
  }
  if (size !== index - startIndex) {
    if (isArray) throw new Error('corrupt array bson');
    throw new Error('corrupt object bson');
  }
  var dollarKeys = Object.keys(object).filter(function (k) {
    return k.startsWith('$');
  });
  var valid = true;
  dollarKeys.forEach(function (k) {
    if (['$ref', '$id', '$db'].indexOf(k) === -1) valid = false;
  });
  if (!valid) return object;
  if (object['$id'] != null && object['$ref'] != null) {
    var copy = Object.assign({}, object);
    delete copy.$ref;
    delete copy.$id;
    delete copy.$db;
    return new db_ref(object.$ref, object.$id, object.$db || null, copy);
  }
  return object;
}
function isolateEvalWithHash(functionCache, hash, functionString, object) {
  var value = null;
  if (functionCache[hash] == null) {
    functionCache[hash] = value;
  }
  return functionCache[hash].bind(object);
}
function isolateEval(functionString) {
  var value = null;
  return value;
}
var deserializer = (/* unused pure expression or super */ null && (deserialize$1));
function readIEEE754(buffer, offset, endian, mLen, nBytes) {
  var e,
    m,
    bBE = endian === 'big',
    eLen = nBytes * 8 - mLen - 1,
    eMax = (1 << eLen) - 1,
    eBias = eMax >> 1,
    nBits = -7,
    i = bBE ? 0 : nBytes - 1,
    d = bBE ? 1 : -1,
    s = buffer[offset + i];
  i += d;
  e = s & (1 << -nBits) - 1;
  s >>= -nBits;
  nBits += eLen;
  for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {}
  m = e & (1 << -nBits) - 1;
  e >>= -nBits;
  nBits += mLen;
  for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {}
  if (e === 0) {
    e = 1 - eBias;
  } else if (e === eMax) {
    return m ? NaN : (s ? -1 : 1) * Infinity;
  } else {
    m = m + Math.pow(2, mLen);
    e = e - eBias;
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
}
function writeIEEE754(buffer, value, offset, endian, mLen, nBytes) {
  var e,
    m,
    c,
    bBE = endian === 'big',
    eLen = nBytes * 8 - mLen - 1,
    eMax = (1 << eLen) - 1,
    eBias = eMax >> 1,
    rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0,
    i = bBE ? nBytes - 1 : 0,
    d = bBE ? -1 : 1,
    s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
  value = Math.abs(value);
  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0;
    e = eMax;
  } else {
    e = Math.floor(Math.log(value) / Math.LN2);
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--;
      c *= 2;
    }
    if (e + eBias >= 1) {
      value += rt / c;
    } else {
      value += rt * Math.pow(2, 1 - eBias);
    }
    if (value * c >= 2) {
      e++;
      c /= 2;
    }
    if (e + eBias >= eMax) {
      m = 0;
      e = eMax;
    } else if (e + eBias >= 1) {
      m = (value * c - 1) * Math.pow(2, mLen);
      e = e + eBias;
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
      e = 0;
    }
  }
  if (isNaN(value)) m = 0;
  while (mLen >= 8) {
    buffer[offset + i] = m & 0xff;
    i += d;
    m /= 256;
    mLen -= 8;
  }
  e = e << mLen | m;
  if (isNaN(value)) e += 8;
  eLen += mLen;
  while (eLen > 0) {
    buffer[offset + i] = e & 0xff;
    i += d;
    e /= 256;
    eLen -= 8;
  }
  buffer[offset + i - d] |= s * 128;
}
var float_parser = {
  readIEEE754: readIEEE754,
  writeIEEE754: writeIEEE754
};
var Buffer$6 = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => bufferEs6.Buffer)()));
var writeIEEE754$1 = float_parser.writeIEEE754;
var normalizedFunctionString$1 = utils.normalizedFunctionString;
var regexp$1 = /\x00/;
var ignoreKeys = /*#__PURE__*/new Set(['$db', '$ref', '$id', '$clusterTime']);
var isDate$1 = function isDate(d) {
  return _typeof(d) === 'object' && Object.prototype.toString.call(d) === '[object Date]';
};
var isRegExp$1 = function isRegExp(d) {
  return Object.prototype.toString.call(d) === '[object RegExp]';
};
function serializeString(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_STRING;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes + 1;
  buffer[index - 1] = 0;
  var size = buffer.write(value, index + 4, 'utf8');
  buffer[index + 3] = size + 1 >> 24 & 0xff;
  buffer[index + 2] = size + 1 >> 16 & 0xff;
  buffer[index + 1] = size + 1 >> 8 & 0xff;
  buffer[index] = size + 1 & 0xff;
  index = index + 4 + size;
  buffer[index++] = 0;
  return index;
}
function serializeNumber(buffer, key, value, index, isArray) {
  if (Math.floor(value) === value && value >= constants.JS_INT_MIN && value <= constants.JS_INT_MAX) {
    if (value >= constants.BSON_INT32_MIN && value <= constants.BSON_INT32_MAX) {
      buffer[index++] = constants.BSON_DATA_INT;
      var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
      index = index + numberOfWrittenBytes;
      buffer[index++] = 0;
      buffer[index++] = value & 0xff;
      buffer[index++] = value >> 8 & 0xff;
      buffer[index++] = value >> 16 & 0xff;
      buffer[index++] = value >> 24 & 0xff;
    } else if (value >= constants.JS_INT_MIN && value <= constants.JS_INT_MAX) {
      buffer[index++] = constants.BSON_DATA_NUMBER;
      var _numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
      index = index + _numberOfWrittenBytes;
      buffer[index++] = 0;
      writeIEEE754$1(buffer, value, index, 'little', 52, 8);
      index = index + 8;
    } else {
      buffer[index++] = constants.BSON_DATA_LONG;
      var _numberOfWrittenBytes2 = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
      index = index + _numberOfWrittenBytes2;
      buffer[index++] = 0;
      var longVal = long_1$1.fromNumber(value);
      var lowBits = longVal.getLowBits();
      var highBits = longVal.getHighBits();
      buffer[index++] = lowBits & 0xff;
      buffer[index++] = lowBits >> 8 & 0xff;
      buffer[index++] = lowBits >> 16 & 0xff;
      buffer[index++] = lowBits >> 24 & 0xff;
      buffer[index++] = highBits & 0xff;
      buffer[index++] = highBits >> 8 & 0xff;
      buffer[index++] = highBits >> 16 & 0xff;
      buffer[index++] = highBits >> 24 & 0xff;
    }
  } else {
    buffer[index++] = constants.BSON_DATA_NUMBER;
    var _numberOfWrittenBytes3 = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
    index = index + _numberOfWrittenBytes3;
    buffer[index++] = 0;
    writeIEEE754$1(buffer, value, index, 'little', 52, 8);
    index = index + 8;
  }
  return index;
}
function serializeNull(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_NULL;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  return index;
}
function serializeBoolean(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_BOOLEAN;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  buffer[index++] = value ? 1 : 0;
  return index;
}
function serializeDate(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_DATE;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  var dateInMilis = long_1$1.fromNumber(value.getTime());
  var lowBits = dateInMilis.getLowBits();
  var highBits = dateInMilis.getHighBits();
  buffer[index++] = lowBits & 0xff;
  buffer[index++] = lowBits >> 8 & 0xff;
  buffer[index++] = lowBits >> 16 & 0xff;
  buffer[index++] = lowBits >> 24 & 0xff;
  buffer[index++] = highBits & 0xff;
  buffer[index++] = highBits >> 8 & 0xff;
  buffer[index++] = highBits >> 16 & 0xff;
  buffer[index++] = highBits >> 24 & 0xff;
  return index;
}
function serializeRegExp(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_REGEXP;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  if (value.source && value.source.match(regexp$1) != null) {
    throw Error('value ' + value.source + ' must not contain null bytes');
  }
  index = index + buffer.write(value.source, index, 'utf8');
  buffer[index++] = 0x00;
  if (value.ignoreCase) buffer[index++] = 0x69;
  if (value.global) buffer[index++] = 0x73;
  if (value.multiline) buffer[index++] = 0x6d;
  buffer[index++] = 0x00;
  return index;
}
function serializeBSONRegExp(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_REGEXP;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  if (value.pattern.match(regexp$1) != null) {
    throw Error('pattern ' + value.pattern + ' must not contain null bytes');
  }
  index = index + buffer.write(value.pattern, index, 'utf8');
  buffer[index++] = 0x00;
  index = index + buffer.write(value.options.split('').sort().join(''), index, 'utf8');
  buffer[index++] = 0x00;
  return index;
}
function serializeMinMax(buffer, key, value, index, isArray) {
  if (value === null) {
    buffer[index++] = constants.BSON_DATA_NULL;
  } else if (value._bsontype === 'MinKey') {
    buffer[index++] = constants.BSON_DATA_MIN_KEY;
  } else {
    buffer[index++] = constants.BSON_DATA_MAX_KEY;
  }
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  return index;
}
function serializeObjectId(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_OID;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  if (typeof value.id === 'string') {
    buffer.write(value.id, index, 'binary');
  } else if (value.id && value.id.copy) {
    value.id.copy(buffer, index, 0, 12);
  } else {
    throw new TypeError('object [' + JSON.stringify(value) + '] is not a valid ObjectId');
  }
  return index + 12;
}
function serializeBuffer(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_BINARY;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  var size = value.length;
  buffer[index++] = size & 0xff;
  buffer[index++] = size >> 8 & 0xff;
  buffer[index++] = size >> 16 & 0xff;
  buffer[index++] = size >> 24 & 0xff;
  buffer[index++] = constants.BSON_BINARY_SUBTYPE_DEFAULT;
  value.copy(buffer, index, 0, size);
  index = index + size;
  return index;
}
function serializeObject(buffer, key, value, index, checkKeys, depth, serializeFunctions, ignoreUndefined, isArray, path) {
  for (var i = 0; i < path.length; i++) {
    if (path[i] === value) throw new Error('cyclic dependency detected');
  }
  path.push(value);
  buffer[index++] = Array.isArray(value) ? constants.BSON_DATA_ARRAY : constants.BSON_DATA_OBJECT;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  var endIndex = serializeInto(buffer, value, checkKeys, index, depth + 1, serializeFunctions, ignoreUndefined, path);
  path.pop();
  return endIndex;
}
function serializeDecimal128(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_DECIMAL128;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  value.bytes.copy(buffer, index, 0, 16);
  return index + 16;
}
function serializeLong(buffer, key, value, index, isArray) {
  buffer[index++] = value._bsontype === 'Long' ? constants.BSON_DATA_LONG : constants.BSON_DATA_TIMESTAMP;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  var lowBits = value.getLowBits();
  var highBits = value.getHighBits();
  buffer[index++] = lowBits & 0xff;
  buffer[index++] = lowBits >> 8 & 0xff;
  buffer[index++] = lowBits >> 16 & 0xff;
  buffer[index++] = lowBits >> 24 & 0xff;
  buffer[index++] = highBits & 0xff;
  buffer[index++] = highBits >> 8 & 0xff;
  buffer[index++] = highBits >> 16 & 0xff;
  buffer[index++] = highBits >> 24 & 0xff;
  return index;
}
function serializeInt32(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_INT;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  buffer[index++] = value & 0xff;
  buffer[index++] = value >> 8 & 0xff;
  buffer[index++] = value >> 16 & 0xff;
  buffer[index++] = value >> 24 & 0xff;
  return index;
}
function serializeDouble(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_NUMBER;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  writeIEEE754$1(buffer, value.value, index, 'little', 52, 8);
  index = index + 8;
  return index;
}
function serializeFunction(buffer, key, value, index, checkKeys, depth, isArray) {
  buffer[index++] = constants.BSON_DATA_CODE;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  var functionString = normalizedFunctionString$1(value);
  var size = buffer.write(functionString, index + 4, 'utf8') + 1;
  buffer[index] = size & 0xff;
  buffer[index + 1] = size >> 8 & 0xff;
  buffer[index + 2] = size >> 16 & 0xff;
  buffer[index + 3] = size >> 24 & 0xff;
  index = index + 4 + size - 1;
  buffer[index++] = 0;
  return index;
}
function serializeCode(buffer, key, value, index, checkKeys, depth, serializeFunctions, ignoreUndefined, isArray) {
  if (value.scope && _typeof(value.scope) === 'object') {
    buffer[index++] = constants.BSON_DATA_CODE_W_SCOPE;
    var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
    index = index + numberOfWrittenBytes;
    buffer[index++] = 0;
    var startIndex = index;
    var functionString = typeof value.code === 'string' ? value.code : value.code.toString();
    index = index + 4;
    var codeSize = buffer.write(functionString, index + 4, 'utf8') + 1;
    buffer[index] = codeSize & 0xff;
    buffer[index + 1] = codeSize >> 8 & 0xff;
    buffer[index + 2] = codeSize >> 16 & 0xff;
    buffer[index + 3] = codeSize >> 24 & 0xff;
    buffer[index + 4 + codeSize - 1] = 0;
    index = index + codeSize + 4;
    var endIndex = serializeInto(buffer, value.scope, checkKeys, index, depth + 1, serializeFunctions, ignoreUndefined);
    index = endIndex - 1;
    var totalSize = endIndex - startIndex;
    buffer[startIndex++] = totalSize & 0xff;
    buffer[startIndex++] = totalSize >> 8 & 0xff;
    buffer[startIndex++] = totalSize >> 16 & 0xff;
    buffer[startIndex++] = totalSize >> 24 & 0xff;
    buffer[index++] = 0;
  } else {
    buffer[index++] = constants.BSON_DATA_CODE;
    var _numberOfWrittenBytes4 = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
    index = index + _numberOfWrittenBytes4;
    buffer[index++] = 0;
    var _functionString = value.code.toString();
    var size = buffer.write(_functionString, index + 4, 'utf8') + 1;
    buffer[index] = size & 0xff;
    buffer[index + 1] = size >> 8 & 0xff;
    buffer[index + 2] = size >> 16 & 0xff;
    buffer[index + 3] = size >> 24 & 0xff;
    index = index + 4 + size - 1;
    buffer[index++] = 0;
  }
  return index;
}
function serializeBinary(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_BINARY;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  var data = value.value(true);
  var size = value.position;
  if (value.sub_type === binary.SUBTYPE_BYTE_ARRAY) size = size + 4;
  buffer[index++] = size & 0xff;
  buffer[index++] = size >> 8 & 0xff;
  buffer[index++] = size >> 16 & 0xff;
  buffer[index++] = size >> 24 & 0xff;
  buffer[index++] = value.sub_type;
  if (value.sub_type === binary.SUBTYPE_BYTE_ARRAY) {
    size = size - 4;
    buffer[index++] = size & 0xff;
    buffer[index++] = size >> 8 & 0xff;
    buffer[index++] = size >> 16 & 0xff;
    buffer[index++] = size >> 24 & 0xff;
  }
  data.copy(buffer, index, 0, value.position);
  index = index + value.position;
  return index;
}
function serializeSymbol(buffer, key, value, index, isArray) {
  buffer[index++] = constants.BSON_DATA_SYMBOL;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  var size = buffer.write(value.value, index + 4, 'utf8') + 1;
  buffer[index] = size & 0xff;
  buffer[index + 1] = size >> 8 & 0xff;
  buffer[index + 2] = size >> 16 & 0xff;
  buffer[index + 3] = size >> 24 & 0xff;
  index = index + 4 + size - 1;
  buffer[index++] = 0x00;
  return index;
}
function serializeDBRef(buffer, key, value, index, depth, serializeFunctions, isArray) {
  buffer[index++] = constants.BSON_DATA_OBJECT;
  var numberOfWrittenBytes = !isArray ? buffer.write(key, index, 'utf8') : buffer.write(key, index, 'ascii');
  index = index + numberOfWrittenBytes;
  buffer[index++] = 0;
  var startIndex = index;
  var endIndex;
  var output = {
    $ref: value.collection || value.namespace,
    $id: value.oid
  };
  if (value.db != null) output.$db = value.db;
  output = Object.assign(output, value.fields);
  endIndex = serializeInto(buffer, output, false, index, depth + 1, serializeFunctions);
  var size = endIndex - startIndex;
  buffer[startIndex++] = size & 0xff;
  buffer[startIndex++] = size >> 8 & 0xff;
  buffer[startIndex++] = size >> 16 & 0xff;
  buffer[startIndex++] = size >> 24 & 0xff;
  return endIndex;
}
function serializeInto(buffer, object, checkKeys, startingIndex, depth, serializeFunctions, ignoreUndefined, path) {
  startingIndex = startingIndex || 0;
  path = path || [];
  path.push(object);
  var index = startingIndex + 4;
  if (Array.isArray(object)) {
    for (var i = 0; i < object.length; i++) {
      var key = '' + i;
      var value = object[i];
      if (value && value.toBSON) {
        if (typeof value.toBSON !== 'function') throw new TypeError('toBSON is not a function');
        value = value.toBSON();
      }
      var type = _typeof(value);
      if (type === 'string') {
        index = serializeString(buffer, key, value, index, true);
      } else if (type === 'number') {
        index = serializeNumber(buffer, key, value, index, true);
      } else if (type === 'boolean') {
        index = serializeBoolean(buffer, key, value, index, true);
      } else if (value instanceof Date || isDate$1(value)) {
        index = serializeDate(buffer, key, value, index, true);
      } else if (value === undefined) {
        index = serializeNull(buffer, key, value, index, true);
      } else if (value === null) {
        index = serializeNull(buffer, key, value, index, true);
      } else if (value['_bsontype'] === 'ObjectId' || value['_bsontype'] === 'ObjectID') {
        index = serializeObjectId(buffer, key, value, index, true);
      } else if (Buffer$6.isBuffer(value)) {
        index = serializeBuffer(buffer, key, value, index, true);
      } else if (value instanceof RegExp || isRegExp$1(value)) {
        index = serializeRegExp(buffer, key, value, index, true);
      } else if (type === 'object' && value['_bsontype'] == null) {
        index = serializeObject(buffer, key, value, index, checkKeys, depth, serializeFunctions, ignoreUndefined, true, path);
      } else if (type === 'object' && value['_bsontype'] === 'Decimal128') {
        index = serializeDecimal128(buffer, key, value, index, true);
      } else if (value['_bsontype'] === 'Long' || value['_bsontype'] === 'Timestamp') {
        index = serializeLong(buffer, key, value, index, true);
      } else if (value['_bsontype'] === 'Double') {
        index = serializeDouble(buffer, key, value, index, true);
      } else if (typeof value === 'function' && serializeFunctions) {
        index = serializeFunction(buffer, key, value, index, checkKeys, depth, serializeFunctions, true);
      } else if (value['_bsontype'] === 'Code') {
        index = serializeCode(buffer, key, value, index, checkKeys, depth, serializeFunctions, ignoreUndefined, true);
      } else if (value['_bsontype'] === 'Binary') {
        index = serializeBinary(buffer, key, value, index, true);
      } else if (value['_bsontype'] === 'Symbol') {
        index = serializeSymbol(buffer, key, value, index, true);
      } else if (value['_bsontype'] === 'DBRef') {
        index = serializeDBRef(buffer, key, value, index, depth, serializeFunctions, true);
      } else if (value['_bsontype'] === 'BSONRegExp') {
        index = serializeBSONRegExp(buffer, key, value, index, true);
      } else if (value['_bsontype'] === 'Int32') {
        index = serializeInt32(buffer, key, value, index, true);
      } else if (value['_bsontype'] === 'MinKey' || value['_bsontype'] === 'MaxKey') {
        index = serializeMinMax(buffer, key, value, index, true);
      } else if (typeof value['_bsontype'] !== 'undefined') {
        throw new TypeError('Unrecognized or invalid _bsontype: ' + value['_bsontype']);
      }
    }
  } else if (object instanceof map) {
    var iterator = object.entries();
    var done = false;
    while (!done) {
      var entry = iterator.next();
      done = entry.done;
      if (done) continue;
      var _key = entry.value[0];
      var _value = entry.value[1];
      var _type = _typeof(_value);
      if (typeof _key === 'string' && !ignoreKeys.has(_key)) {
        if (_key.match(regexp$1) != null) {
          throw Error('key ' + _key + ' must not contain null bytes');
        }
        if (checkKeys) {
          if ('$' === _key[0]) {
            throw Error('key ' + _key + " must not start with '$'");
          } else if (~_key.indexOf('.')) {
            throw Error('key ' + _key + " must not contain '.'");
          }
        }
      }
      if (_type === 'string') {
        index = serializeString(buffer, _key, _value, index);
      } else if (_type === 'number') {
        index = serializeNumber(buffer, _key, _value, index);
      } else if (_type === 'boolean') {
        index = serializeBoolean(buffer, _key, _value, index);
      } else if (_value instanceof Date || isDate$1(_value)) {
        index = serializeDate(buffer, _key, _value, index);
      } else if (_value === null || _value === undefined && ignoreUndefined === false) {
        index = serializeNull(buffer, _key, _value, index);
      } else if (_value['_bsontype'] === 'ObjectId' || _value['_bsontype'] === 'ObjectID') {
        index = serializeObjectId(buffer, _key, _value, index);
      } else if (Buffer$6.isBuffer(_value)) {
        index = serializeBuffer(buffer, _key, _value, index);
      } else if (_value instanceof RegExp || isRegExp$1(_value)) {
        index = serializeRegExp(buffer, _key, _value, index);
      } else if (_type === 'object' && _value['_bsontype'] == null) {
        index = serializeObject(buffer, _key, _value, index, checkKeys, depth, serializeFunctions, ignoreUndefined, false, path);
      } else if (_type === 'object' && _value['_bsontype'] === 'Decimal128') {
        index = serializeDecimal128(buffer, _key, _value, index);
      } else if (_value['_bsontype'] === 'Long' || _value['_bsontype'] === 'Timestamp') {
        index = serializeLong(buffer, _key, _value, index);
      } else if (_value['_bsontype'] === 'Double') {
        index = serializeDouble(buffer, _key, _value, index);
      } else if (_value['_bsontype'] === 'Code') {
        index = serializeCode(buffer, _key, _value, index, checkKeys, depth, serializeFunctions, ignoreUndefined);
      } else if (typeof _value === 'function' && serializeFunctions) {
        index = serializeFunction(buffer, _key, _value, index, checkKeys, depth, serializeFunctions);
      } else if (_value['_bsontype'] === 'Binary') {
        index = serializeBinary(buffer, _key, _value, index);
      } else if (_value['_bsontype'] === 'Symbol') {
        index = serializeSymbol(buffer, _key, _value, index);
      } else if (_value['_bsontype'] === 'DBRef') {
        index = serializeDBRef(buffer, _key, _value, index, depth, serializeFunctions);
      } else if (_value['_bsontype'] === 'BSONRegExp') {
        index = serializeBSONRegExp(buffer, _key, _value, index);
      } else if (_value['_bsontype'] === 'Int32') {
        index = serializeInt32(buffer, _key, _value, index);
      } else if (_value['_bsontype'] === 'MinKey' || _value['_bsontype'] === 'MaxKey') {
        index = serializeMinMax(buffer, _key, _value, index);
      } else if (typeof _value['_bsontype'] !== 'undefined') {
        throw new TypeError('Unrecognized or invalid _bsontype: ' + _value['_bsontype']);
      }
    }
  } else {
    if (object.toBSON) {
      if (typeof object.toBSON !== 'function') throw new TypeError('toBSON is not a function');
      object = object.toBSON();
      if (object != null && _typeof(object) !== 'object') throw new TypeError('toBSON function did not return an object');
    }
    for (var _key2 in object) {
      var _value2 = object[_key2];
      if (_value2 && _value2.toBSON) {
        if (typeof _value2.toBSON !== 'function') throw new TypeError('toBSON is not a function');
        _value2 = _value2.toBSON();
      }
      var _type2 = _typeof(_value2);
      if (typeof _key2 === 'string' && !ignoreKeys.has(_key2)) {
        if (_key2.match(regexp$1) != null) {
          throw Error('key ' + _key2 + ' must not contain null bytes');
        }
        if (checkKeys) {
          if ('$' === _key2[0]) {
            throw Error('key ' + _key2 + " must not start with '$'");
          } else if (~_key2.indexOf('.')) {
            throw Error('key ' + _key2 + " must not contain '.'");
          }
        }
      }
      if (_type2 === 'string') {
        index = serializeString(buffer, _key2, _value2, index);
      } else if (_type2 === 'number') {
        index = serializeNumber(buffer, _key2, _value2, index);
      } else if (_type2 === 'boolean') {
        index = serializeBoolean(buffer, _key2, _value2, index);
      } else if (_value2 instanceof Date || isDate$1(_value2)) {
        index = serializeDate(buffer, _key2, _value2, index);
      } else if (_value2 === undefined) {
        if (ignoreUndefined === false) index = serializeNull(buffer, _key2, _value2, index);
      } else if (_value2 === null) {
        index = serializeNull(buffer, _key2, _value2, index);
      } else if (_value2['_bsontype'] === 'ObjectId' || _value2['_bsontype'] === 'ObjectID') {
        index = serializeObjectId(buffer, _key2, _value2, index);
      } else if (Buffer$6.isBuffer(_value2)) {
        index = serializeBuffer(buffer, _key2, _value2, index);
      } else if (_value2 instanceof RegExp || isRegExp$1(_value2)) {
        index = serializeRegExp(buffer, _key2, _value2, index);
      } else if (_type2 === 'object' && _value2['_bsontype'] == null) {
        index = serializeObject(buffer, _key2, _value2, index, checkKeys, depth, serializeFunctions, ignoreUndefined, false, path);
      } else if (_type2 === 'object' && _value2['_bsontype'] === 'Decimal128') {
        index = serializeDecimal128(buffer, _key2, _value2, index);
      } else if (_value2['_bsontype'] === 'Long' || _value2['_bsontype'] === 'Timestamp') {
        index = serializeLong(buffer, _key2, _value2, index);
      } else if (_value2['_bsontype'] === 'Double') {
        index = serializeDouble(buffer, _key2, _value2, index);
      } else if (_value2['_bsontype'] === 'Code') {
        index = serializeCode(buffer, _key2, _value2, index, checkKeys, depth, serializeFunctions, ignoreUndefined);
      } else if (typeof _value2 === 'function' && serializeFunctions) {
        index = serializeFunction(buffer, _key2, _value2, index, checkKeys, depth, serializeFunctions);
      } else if (_value2['_bsontype'] === 'Binary') {
        index = serializeBinary(buffer, _key2, _value2, index);
      } else if (_value2['_bsontype'] === 'Symbol') {
        index = serializeSymbol(buffer, _key2, _value2, index);
      } else if (_value2['_bsontype'] === 'DBRef') {
        index = serializeDBRef(buffer, _key2, _value2, index, depth, serializeFunctions);
      } else if (_value2['_bsontype'] === 'BSONRegExp') {
        index = serializeBSONRegExp(buffer, _key2, _value2, index);
      } else if (_value2['_bsontype'] === 'Int32') {
        index = serializeInt32(buffer, _key2, _value2, index);
      } else if (_value2['_bsontype'] === 'MinKey' || _value2['_bsontype'] === 'MaxKey') {
        index = serializeMinMax(buffer, _key2, _value2, index);
      } else if (typeof _value2['_bsontype'] !== 'undefined') {
        throw new TypeError('Unrecognized or invalid _bsontype: ' + _value2['_bsontype']);
      }
    }
  }
  path.pop();
  buffer[index++] = 0x00;
  var size = index - startingIndex;
  buffer[startingIndex++] = size & 0xff;
  buffer[startingIndex++] = size >> 8 & 0xff;
  buffer[startingIndex++] = size >> 16 & 0xff;
  buffer[startingIndex++] = size >> 24 & 0xff;
  return index;
}
var serializer = (/* unused pure expression or super */ null && (serializeInto));
var Buffer$7 = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => bufferEs6.Buffer)()));
var normalizedFunctionString$2 = /*#__PURE__*/utils.normalizedFunctionString;
function isDate$2(d) {
  return _typeof(d) === 'object' && Object.prototype.toString.call(d) === '[object Date]';
}
function calculateObjectSize(object, serializeFunctions, ignoreUndefined) {
  var totalLength = 4 + 1;
  if (Array.isArray(object)) {
    for (var i = 0; i < object.length; i++) {
      totalLength += calculateElement(i.toString(), object[i], serializeFunctions, true, ignoreUndefined);
    }
  } else {
    if (object.toBSON) {
      object = object.toBSON();
    }
    for (var key in object) {
      totalLength += calculateElement(key, object[key], serializeFunctions, false, ignoreUndefined);
    }
  }
  return totalLength;
}
function calculateElement(name, value, serializeFunctions, isArray, ignoreUndefined) {
  if (value && value.toBSON) {
    value = value.toBSON();
  }
  switch (_typeof(value)) {
    case 'string':
      return 1 + Buffer$7.byteLength(name, 'utf8') + 1 + 4 + Buffer$7.byteLength(value, 'utf8') + 1;
    case 'number':
      if (Math.floor(value) === value && value >= constants.JS_INT_MIN && value <= constants.JS_INT_MAX) {
        if (value >= constants.BSON_INT32_MIN && value <= constants.BSON_INT32_MAX) {
          return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (4 + 1);
        } else {
          return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (8 + 1);
        }
      } else {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (8 + 1);
      }
    case 'undefined':
      if (isArray || !ignoreUndefined) return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + 1;
      return 0;
    case 'boolean':
      return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (1 + 1);
    case 'object':
      if (value == null || value['_bsontype'] === 'MinKey' || value['_bsontype'] === 'MaxKey') {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + 1;
      } else if (value['_bsontype'] === 'ObjectId' || value['_bsontype'] === 'ObjectID') {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (12 + 1);
      } else if (value instanceof Date || isDate$2(value)) {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (8 + 1);
      } else if (typeof Buffer$7 !== 'undefined' && Buffer$7.isBuffer(value)) {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (1 + 4 + 1) + value.length;
      } else if (value['_bsontype'] === 'Long' || value['_bsontype'] === 'Double' || value['_bsontype'] === 'Timestamp') {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (8 + 1);
      } else if (value['_bsontype'] === 'Decimal128') {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (16 + 1);
      } else if (value['_bsontype'] === 'Code') {
        if (value.scope != null && Object.keys(value.scope).length > 0) {
          return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + 1 + 4 + 4 + Buffer$7.byteLength(value.code.toString(), 'utf8') + 1 + calculateObjectSize(value.scope, serializeFunctions, ignoreUndefined);
        } else {
          return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + 1 + 4 + Buffer$7.byteLength(value.code.toString(), 'utf8') + 1;
        }
      } else if (value['_bsontype'] === 'Binary') {
        if (value.sub_type === binary.SUBTYPE_BYTE_ARRAY) {
          return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (value.position + 1 + 4 + 1 + 4);
        } else {
          return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + (value.position + 1 + 4 + 1);
        }
      } else if (value['_bsontype'] === 'Symbol') {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + Buffer$7.byteLength(value.value, 'utf8') + 4 + 1 + 1;
      } else if (value['_bsontype'] === 'DBRef') {
        var ordered_values = Object.assign({
          $ref: value.collection,
          $id: value.oid
        }, value.fields);
        if (value.db != null) {
          ordered_values['$db'] = value.db;
        }
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + 1 + calculateObjectSize(ordered_values, serializeFunctions, ignoreUndefined);
      } else if (value instanceof RegExp || Object.prototype.toString.call(value) === '[object RegExp]') {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + 1 + Buffer$7.byteLength(value.source, 'utf8') + 1 + (value.global ? 1 : 0) + (value.ignoreCase ? 1 : 0) + (value.multiline ? 1 : 0) + 1;
      } else if (value['_bsontype'] === 'BSONRegExp') {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + 1 + Buffer$7.byteLength(value.pattern, 'utf8') + 1 + Buffer$7.byteLength(value.options, 'utf8') + 1;
      } else {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + calculateObjectSize(value, serializeFunctions, ignoreUndefined) + 1;
      }
    case 'function':
      if (value instanceof RegExp || Object.prototype.toString.call(value) === '[object RegExp]' || String.call(value) === '[object RegExp]') {
        return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + 1 + Buffer$7.byteLength(value.source, 'utf8') + 1 + (value.global ? 1 : 0) + (value.ignoreCase ? 1 : 0) + (value.multiline ? 1 : 0) + 1;
      } else {
        if (serializeFunctions && value.scope != null && Object.keys(value.scope).length > 0) {
          return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + 1 + 4 + 4 + Buffer$7.byteLength(normalizedFunctionString$2(value), 'utf8') + 1 + calculateObjectSize(value.scope, serializeFunctions, ignoreUndefined);
        } else if (serializeFunctions) {
          return (name != null ? Buffer$7.byteLength(name, 'utf8') + 1 : 0) + 1 + 4 + Buffer$7.byteLength(normalizedFunctionString$2(value), 'utf8') + 1;
        }
      }
  }
  return 0;
}
var calculate_size = (/* unused pure expression or super */ null && (calculateObjectSize));
var Buffer$8 = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => bufferEs6.Buffer)()));
var ensure_buffer = function ensureBuffer(potentialBuffer) {
  if (potentialBuffer instanceof Buffer$8) {
    return potentialBuffer;
  }
  if (potentialBuffer instanceof Uint8Array) {
    return Buffer$8.from(potentialBuffer.buffer);
  }
  throw new TypeError('Must use either Buffer or Uint8Array');
};
var Buffer$9 = /*#__PURE__*/(/* unused pure expression or super */ null && ((() => bufferEs6.Buffer)()));
var MAXSIZE = (/* unused pure expression or super */ null && (1024 * 1024 * 17));
var buffer = /*#__PURE__*/(/* unused pure expression or super */ null && (Buffer$9.alloc(MAXSIZE)));
function setInternalBufferSize(size) {
  if (buffer.length < size) {
    buffer = Buffer$9.alloc(size);
  }
}
function serialize$1(object, options) {
  options = options || {};
  var checkKeys = typeof options.checkKeys === 'boolean' ? options.checkKeys : false;
  var serializeFunctions = typeof options.serializeFunctions === 'boolean' ? options.serializeFunctions : false;
  var ignoreUndefined = typeof options.ignoreUndefined === 'boolean' ? options.ignoreUndefined : true;
  var minInternalBufferSize = typeof options.minInternalBufferSize === 'number' ? options.minInternalBufferSize : MAXSIZE;
  if (buffer.length < minInternalBufferSize) {
    buffer = Buffer$9.alloc(minInternalBufferSize);
  }
  var serializationIndex = serializer(buffer, object, checkKeys, 0, 0, serializeFunctions, ignoreUndefined, []);
  var finishedBuffer = Buffer$9.alloc(serializationIndex);
  buffer.copy(finishedBuffer, 0, 0, finishedBuffer.length);
  return finishedBuffer;
}
function serializeWithBufferAndIndex(object, finalBuffer, options) {
  options = options || {};
  var checkKeys = typeof options.checkKeys === 'boolean' ? options.checkKeys : false;
  var serializeFunctions = typeof options.serializeFunctions === 'boolean' ? options.serializeFunctions : false;
  var ignoreUndefined = typeof options.ignoreUndefined === 'boolean' ? options.ignoreUndefined : true;
  var startIndex = typeof options.index === 'number' ? options.index : 0;
  var serializationIndex = serializer(buffer, object, checkKeys, 0, 0, serializeFunctions, ignoreUndefined);
  buffer.copy(finalBuffer, startIndex, 0, serializationIndex);
  return startIndex + serializationIndex - 1;
}
function deserialize$2(buffer, options) {
  buffer = ensure_buffer(buffer);
  return deserializer(buffer, options);
}
function calculateObjectSize$1(object, options) {
  options = options || {};
  var serializeFunctions = typeof options.serializeFunctions === 'boolean' ? options.serializeFunctions : false;
  var ignoreUndefined = typeof options.ignoreUndefined === 'boolean' ? options.ignoreUndefined : true;
  return calculate_size(object, serializeFunctions, ignoreUndefined);
}
function deserializeStream(data, startIndex, numberOfDocuments, documents, docStartIndex, options) {
  options = Object.assign({
    allowObjectSmallerThanBufferSize: true
  }, options);
  data = ensure_buffer(data);
  var index = startIndex;
  for (var i = 0; i < numberOfDocuments; i++) {
    var size = data[index] | data[index + 1] << 8 | data[index + 2] << 16 | data[index + 3] << 24;
    options.index = index;
    documents[docStartIndex + i] = deserializer(data, options);
    index = index + size;
  }
  return index;
}
exports.EJSON = extended_json;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

// UNUSED EXPORTS: checkProducts

// NAMESPACE OBJECT: ./src/servicemarket/index.ts
var servicemarket_namespaceObject = {};
__webpack_require__.r(servicemarket_namespaceObject);
__webpack_require__.d(servicemarket_namespaceObject, {
  getServiceMarketAPI: () => (getServiceMarketAPI)
});

// NAMESPACE OBJECT: ./src/services/database/api/database/geo.ts
var geo_namespaceObject = {};
__webpack_require__.r(geo_namespaceObject);
__webpack_require__.d(geo_namespaceObject, {
  GeoLineString: () => (GeoLineString),
  GeoMultiLineString: () => (GeoMultiLineString),
  GeoMultiPoint: () => (GeoMultiPoint),
  GeoMultiPolygon: () => (GeoMultiPolygon),
  GeoPoint: () => (GeoPoint),
  GeoPolygon: () => (GeoPolygon),
  LineString: () => (LineString),
  MultiLineString: () => (MultiLineString),
  MultiPoint: () => (MultiPoint),
  MultiPolygon: () => (MultiPolygon),
  Point: () => (Point),
  Polygon: () => (Polygon),
  __safe_props__: () => (__safe_props__)
});

// NAMESPACE OBJECT: ./src/services/database/internal/grammar/default/index.ts
var default_namespaceObject = {};
__webpack_require__.r(default_namespaceObject);
__webpack_require__.d(default_namespaceObject, {
  AggregateOperatorMap: () => (AggregateOperatorMap),
  AggregateSerializer: () => (AggregateSerializer),
  Decoder: () => (Decoder),
  OperatorMap: () => (OperatorMap),
  ProjectionSerializer: () => (ProjectionSerializer),
  QuerySerializer: () => (QuerySerializer),
  UpdateSerializer: () => (UpdateSerializer),
  aggregateOperatorToString: () => (aggregateOperatorToString),
  decodeInternalDataType: () => (decodeInternalDataType),
  encode: () => (encode),
  encodeInternalDataType: () => (encodeInternalDataType),
  extractQueryOptions: () => (extractQueryOptions),
  flattenObject: () => (flattenObject),
  flattenQueryObject: () => (flattenQueryObject),
  getProjectionDefinition: () => (getProjectionDefinition),
  isConversionRequired: () => (isConversionRequired),
  mergeConditionAfterEncode: () => (mergeConditionAfterEncode),
  operatorToString: () => (operatorToString)
});

// NAMESPACE OBJECT: ./src/cloud/index.ts
var cloud_namespaceObject = {};
__webpack_require__.r(cloud_namespaceObject);
__webpack_require__.d(cloud_namespaceObject, {
  DefaultCloud: () => (DefaultCloud),
  InstanceCloud: () => (InstanceCloud),
  getCloudAPI: () => (getCloudAPI),
  getCloudInstance: () => (getCloudInstance),
  getRequestMiddleware: () => (getRequestMiddleware)
});

// EXTERNAL MODULE: ../../node_modules/.pnpm/@babel+runtime@7.25.6/node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(515);
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);
;// CONCATENATED MODULE: ./src/utils/merge.ts
function safeGet(object, key) {
  if (key === 'constructor' && typeof object[key] === 'function') {
    return;
  }
  if (key == '__proto__') {
    return;
  }
  return object[key];
}
function merge(object, source) {
  if (object === source) return object;
  for (var key of Object.keys(source)) {
    var srcValue = safeGet(source, key);
    var objValue = safeGet(object, key);
    var newValue = void 0;
    if (typeof srcValue === 'object') {
      newValue = objValue || {};
      merge(newValue, srcValue);
    } else {
      newValue = srcValue;
    }
    object[key] = newValue;
  }
  return object;
}
/* harmony default export */ const utils_merge = (merge);
;// CONCATENATED MODULE: ./src/utils/type.ts
var type_getType = x => Object.prototype.toString.call(x).slice(8, -1).toLowerCase();
var isObject = x => type_getType(x) === 'object';
var isString = x => type_getType(x) === 'string';
var isNumber = x => type_getType(x) === 'number';
var isPromise = x => type_getType(x) === 'promise';
var isFunction = x => typeof x === 'function';
var isArray = x => Array.isArray(x);
var isDate = x => type_getType(x) === 'date';
var isRegExp = x => type_getType(x) === 'regexp';
var isInternalObject = x => x && type_getType(x._internalType) === 'symbol';
var isPlainObject = obj => {
  if (typeof obj !== 'object' || obj === null) return false;
  var proto = obj;
  while (Object.getPrototypeOf(proto) !== null) {
    proto = Object.getPrototypeOf(proto);
  }
  return Object.getPrototypeOf(obj) === proto;
};
;// CONCATENATED MODULE: ./src/config/error.config.ts
var error_config_ERR_CODE = {
  '-1': '',
  UNKNOWN_ERROR: -1,
  '-401001': 'api permission denied',
  SDK_API_PERMISSION_DENIED: -401001,
  '-401002': 'api parameter error',
  SDK_API_PARAMETER_ERROR: -401002,
  '-401003': 'api parameter type error',
  SDK_API_PARAMETER_TYPE_ERROR: -401003,
  '-402001': 'circular reference detected',
  SDK_DATABASE_CIRCULAR_REFERENCE: -402001,
  '-402002': 'realtime listener init watch fail',
  SDK_DATABASE_REALTIME_LISTENER_INIT_WATCH_FAIL: -402002,
  '-402003': 'realtime listener reconnect ws fail',
  SDK_DATABASE_REALTIME_LISTENER_RECONNECT_WS_FAIL: -402003,
  '-402004': 'realtime listener rebuild watch fail',
  SDK_DATABASE_REALTIME_LISTENER_REBUILD_WATCH_FAIL: -402004,
  '-402005': 'realtime listener close watch fail',
  SDK_DATABASE_REALTIME_LISTENER_CLOSE_WATCH_FAIL: -402005,
  '-402006': 'realtime listener receive server error msg',
  SDK_DATABASE_REALTIME_LISTENER_SERVER_ERROR_MSG: -402006,
  '-402007': 'realtime listener receive invalid server data',
  SDK_DATABASE_REALTIME_LISTENER_RECEIVE_INVALID_SERVER_DATA: -402007,
  '-402008': 'realtime listener websocket connection error',
  SDK_DATABASE_REALTIME_LISTENER_WEBSOCKET_CONNECTION_ERROR: -402008,
  '-402009': 'realtime listener websocket connection closed',
  SDK_DATABASE_REALTIME_LISTENER_WEBSOCKET_CONNECTION_CLOSED: -402009,
  '-402010': 'realtime listener check last fail',
  SDK_DATABASE_REALTIME_LISTENER_CHECK_LAST_FAIL: -402010,
  '-402011': 'realtime listener unexpected fatal error',
  SDK_DATABASE_REALTIME_LISTENER_UNEXPECTED_FATAL_ERROR: -402011,
  '-402012': 'realtime listener init ws fail',
  SDK_DATABASE_REALTIME_LISTENER_INIT_WS_FAIL: -402012,
  '-403001': 'max upload file size exceeded',
  SDK_STORAGE_EXCEED_MAX_UPLOAD_SIZE: -403001,
  '-403002': 'internal server error: empty upload url',
  SDK_STORAGE_INTERNAL_SERVER_ERROR_EMPTY_UPLOAD_URL: -403002,
  '-403003': 'internal server error: empty download url',
  SDK_STORAGE_INTERNAL_SERVER_ERROR_EMPTY_DOWNLOAD_URL: -403003,
  '-404001': 'empty call result',
  SDK_FUNCTIONS_EMPTY_CALL_RESULT: -404001,
  '-404002': 'empty event id',
  SDK_FUNCTIONS_EMPTY_EVENT_ID: -404002,
  '-404003': 'empty poll url',
  SDK_FUNCTIONS_EMPTY_POLL_URL: -404003,
  '-404004': 'empty poll result json',
  SDK_FUNCTIONS_EMPTY_POLL_RESULT_JSON: -404004,
  '-404005': 'exceed max poll retry',
  SDK_FUNCTIONS_EXCEED_MAX_POLL_RETRY: -404005,
  '-404006': 'empty poll result base resp',
  SDK_FUNCTIONS_EMPTY_POLL_RESULT_BASE_RESP: -404006,
  '-404007': 'poll result base resp ret abnormal',
  SDK_FUNCTIONS_POLL_RESULT_BASE_RESP_RET_ABNORMAL: -404007,
  '-404008': 'poll result status code error',
  SDK_FUNCTIONS_POLL_RESULT_STATUS_CODE_ERROR: -404008,
  '-404009': 'poll error',
  SDK_FUNCTIONS_POLL_ERROR: -404009,
  '-404010': 'result expired',
  SDK_FUNCTIONS_POLL_RESULT_EXPIRED: -404010,
  '-404011': 'cloud function execution error',
  SDK_FUNCTIONS_CLOUD_FUNCTION_EXECUTION_ERROR: -404011,
  '-404012': 'polling exceed max timeout retry',
  SDK_FUNCTIONS_EXCEED_MAX_TIMEOUT_POLL_RETRY: -404012,
  '-404013': 'polling exceed max system error retry',
  SDK_FUNCTIONS_EXCEED_MAX_SYSTEM_ERROR_POLL_RETRY: -404013,
  '-405001': 'empty call result',
  SDK_CONTAINER_EMPTY_CALL_RESULT: -405001,
  '-405002': 'empty event id',
  SDK_CONTAINER_EMPTY_EVENT_ID: -405002,
  '-405003': 'empty poll url',
  SDK_CONTAINER_EMPTY_POLL_URL: -405003,
  '-405004': 'empty poll result json',
  SDK_CONTAINER_EMPTY_POLL_RESULT_JSON: -405004,
  '-405005': 'exceed max poll retry',
  SDK_CONTAINER_EXCEED_MAX_POLL_RETRY: -405005,
  '-405006': 'empty poll result base resp',
  SDK_CONTAINER_EMPTY_POLL_RESULT_BASE_RESP: -405006,
  '-405007': 'poll result base resp ret abnormal',
  SDK_CONTAINER_POLL_RESULT_BASE_RESP_RET_ABNORMAL: -405007,
  '-405008': 'poll result status code error',
  SDK_CONTAINER_POLL_RESULT_STATUS_CODE_ERROR: -405008,
  '-405009': 'poll error',
  SDK_CONTAINER_POLL_ERROR: -405009,
  '-405010': 'result expired',
  SDK_CONTAINER_POLL_RESULT_EXPIRED: -405010,
  '-405012': 'polling exceed max timeout retry',
  SDK_CONTAINER_EXCEED_MAX_TIMEOUT_POLL_RETRY: -405012,
  '-405013': 'polling exceed max system error retry',
  SDK_CONTAINER_EXCEED_MAX_SYSTEM_ERROR_POLL_RETRY: -405013,
  '-405014': 'cannot download result (cdn)',
  SDK_CONTAINER_DOWNLOAD_RESULT_FROM_CDN_FAIL: -405014,
  '-405015': 'exceed max client request count, avoid infinite loop in your code and retry after 60s',
  SDK_CONTAINER_EXCEED_MAX_SERVER_REQUEST_COUNT: -405015,
  '-601001': 'system error',
  WX_SYSTEM_ERROR: -601001,
  '-601002': 'system args error',
  WX_SYSTEM_ARGS_ERROR: -601002,
  '-601003': 'system network error',
  WX_SYSTEM_NETWORK_ERROR: -601003,
  '-601004': 'api permission denied',
  WX_API_PERMISSION_DENIED: -601004,
  '-601005': 'invalid cloudID',
  WX_INVALID_CLOUDID: -601005,
  '-601006': 'cloudID expired',
  WX_CLOUDID_EXPIRED: -601006,
  '-601007': 'cloudID and calling user does not match',
  WX_CLOUDID_USER_NOT_MATCH: -601007,
  '-601008': 'server-side request timedout',
  WX_SERVER_REQUEST_TIMEOUT: -601008,
  '-601009': 'missing mobile phone',
  WX_MISSING_MOBILE_PHONE: -601009,
  '-601010': 'no write permission',
  WX_NO_WRITE_PERMISSION: -601010,
  '-601011': 'no privilege permission',
  WX_NO_PRIVILEGE_PERMISSION: -601011,
  '-601012': 'unauthorized env',
  WX_UNAUTHORIZED_ENV: -601012,
  '-601013': 'no multiend permission',
  WX_NO_MULTIEND_PERMISSION: -601013,
  '-601015': 'access denied (cloudfunction cloudbase_auth returns empty errCode)',
  WX_CLOUDBASE_AUTH_RETURN_EMPTY_ERRCODE: -601015,
  '-601016': 'missing env auth info',
  WX_MISSING_ENV_AUTH_INFO: -601016,
  '-601017': 'access denied (cloudbase_auth returns non-zero errCode)',
  WX_CLOUDBASE_AUTH_RETURN_NON_ZERO_ERRCODE: -601017,
  '-602018': 'unauthorized API',
  WX_UNAUTHORIZED_API: -601018,
  '-602001': 'database query result size exceed limit (1MB)',
  WX_DATABASE_QUERY_SIZE_EXCEED_LIMIT: -602001,
  '-604001': 'cloudfunction result size exceed limit (1MB)',
  WX_CLOUDFUNCTION_RESULT_SIZE_EXCEED_LIMIT: -604001,
  '-501001': 'resource system error',
  TCB_RESOURCE_SYSTEM_ERROR: -501001,
  '-501002': 'resource server timeout',
  TCB_RESOURCE_SERVER_TIMEOUT: -501002,
  '-501003': 'exceed request limit',
  TCB_EXCEED_REQUEST_LIMIT: -501003,
  '-501004': 'exceed concurrent request limit',
  TCB_EXCEED_CONCURRENT_REQUEST_LIMIT: -501004,
  '-501005': 'invalid env',
  TCB_INVALID_ENV: -501005,
  '-501006': 'invalid common parameters',
  TCB_INVALID_COMMON_PARAM: -501006,
  '-501007': 'invalid parameters',
  TCB_INVALID_PARAM: -501007,
  '-501008': 'invalid request source',
  TCB_INVALID_REQUEST_SOURCE: -501008,
  '-501009': 'resource not initialized',
  TCB_RESOURCE_NOT_INITIALIZED: -501009,
  '-501010': 'tencentcloud key signature verification fail',
  TCB_KEY_SIGNATURE_VERIFICATION_FAIL: -501010,
  '-501011': 'invalid env status',
  TCB_INVALID_ENV_STATUS: -501011,
  '-501012': 'invalid api name',
  TCB_INVALID_API_NAME: -501012,
  '-501013': 'request data size exceeds limit (5M)',
  TCB_REQ_DATA_EXCEED_LIMIT_5M: -501013,
  '-501014': 'upload file size exceeds limit (5M)',
  TCB_UPLOAD_FILE_SIZE_EXCEED_LIMIT_5M: -501014,
  '-501023': 'permission denied',
  TCB_PERMISSION_DENIED: -501023,
  '-502001': 'database request fail',
  TCB_DB_REQUEST_FAIL: -502001,
  '-502002': 'database invalid command',
  TCB_DB_INVALID_COMMAND: -502002,
  '-502003': 'database permission denied',
  TCB_DB_PERMISSION_DENIED: -502003,
  '-502004': 'database exceed collection limit',
  TCB_DB_EXCEED_COLLECTION_LIMIT: -502004,
  '-502005': 'database collection not exists',
  TCB_DB_COLLECTION_NOT_EXISTS: -502005,
  '-503001': 'storage request fail',
  TCB_STORAGE_REQUEST_FAIL: -503001,
  '-503002': 'storage permission denied',
  TCB_STORAGE_PERMISSION_DENIED: -503002,
  '-503003': 'storage file not exists',
  TCB_STORAGE_FILE_NOT_EXISTS: -503003,
  '-503004': 'storage invalid sign parameter',
  TCB_STORAGE_INVALID_SIGN_PARAM: -503004,
  '-504001': 'functions request fail',
  TCB_FUNCTIONS_REQUEST_FAIL: -504001,
  '-504002': 'functions execute fail',
  TCB_FUNCTIONS_EXEC_FAIL: -504002
};
;// CONCATENATED MODULE: ./src/utils/error.ts


class error_CloudSDKError extends Error {
  constructor(options) {
    super(options.errMsg);
    this.errCode = -1;
    this.errMsg = void 0;
    this.requestID = void 0;
    Object.defineProperties(this, {
      message: {
        get() {
          return `errCode: ${this.errCode} ${error_config_ERR_CODE[this.errCode] || ''} | errMsg: ` + this.errMsg;
        },
        set(msg) {
          this.errMsg = msg;
        }
      }
    });
    this.errCode = options.errCode || -1;
    this.errMsg = options.errMsg;
  }
  get message() {
    return `errCode: ${this.errCode} | errMsg: ` + this.errMsg;
  }
  set message(msg) {
    this.errMsg = msg;
  }
}
function isSDKError(error) {
  return error && error instanceof Error && isString(error.errMsg);
}
function returnAsCloudSDKError(err, appendMsg = '') {
  if (err) {
    if (isSDKError(err)) {
      if (appendMsg) {
        err.errMsg += '; ' + appendMsg;
      }
      return err;
    }
    var errCode = err ? err.errCode : undefined;
    var errMsg = (err && err.errMsg || err.toString() || 'unknown error') + '; ' + appendMsg;
    return new error_CloudSDKError({
      errCode,
      errMsg
    });
  }
  return new error_CloudSDKError({
    errMsg: appendMsg
  });
}
function returnAsFinalCloudSDKError(err, apiName) {
  return toSDKError(err, apiName);
}
function toSDKError(e, apiName) {
  if (e) {
    if (isSDKError(e)) {
      return e;
    }
    var prefix = `${apiName}:fail `;
    var _err;
    if (e instanceof Error) {
      e.message = `${prefix}${e.message}`;
      e.stack = e.stack ? e.stack.slice(0, 7) + prefix + e.stack.slice(7) : e.stack;
      _err = e;
      _err.errCode = -1;
    } else if (typeof e === 'string') {
      _err = new Error(`${prefix}${e}`);
      _err.errCode = -1;
    } else {
      var errMsg = e.errMsg || '';
      _err = new Error(`${apiName}:fail ${e.errCode} ${error_config_ERR_CODE[e.errCode] || ''}. ${errMsg}`);
      _err.errCode = e.errCode || -1;
    }
    _err.errMsg = _err.message + '';
    return _err;
  }
  var err = new Error(`${apiName}:fail`);
  err.errCode = -1;
  err.errMsg = err.message + '';
  return err;
}
var isGenericError = e => e.generic;
class TimeoutError extends Error {
  constructor(message, payload) {
    super(message);
    this.type = 'timeout';
    this.payload = void 0;
    this.generic = true;
    this.payload = payload;
  }
}
var isTimeoutError = e => e.type === 'timeout';
class CancelledError extends Error {
  constructor(message, payload) {
    super(message);
    this.type = 'cancelled';
    this.payload = void 0;
    this.generic = true;
    this.payload = payload;
  }
}
var isCancelledError = e => e.type === 'cancelled';
;// CONCATENATED MODULE: ./src/externals/public-lib/reporter.ts

var __reporter__;
var fakeReporter = {
  fake: true,
  surroundThirdByTryCatch: (fn, extend) => {
    return function (...args) {
      return tryCatch(() => {
        try {
          return fn.apply(fn, args);
        } catch (e) {
          console.error(JSON.stringify(e) + `; ${extend}\n` + e.stack);
          console.error(fn.toString());
          throw e;
        }
      }, extend);
    };
  },
  reportIDKey: (...args) => {
    return;
  },
  reportIDKeyDirectly: (...args) => {
    return;
  },
  reportKeyValue: (...args) => {
    return;
  }
};
var isInPublicLib = false;
var getPublicLibReporterTries = 10;
function getReporter() {
  try {
    if (isInPublicLib) {
      return Reporter;
    }
    if (getPublicLibReporterTries <= 0) {
      return __reporter__;
    }
    getPublicLibReporterTries--;
    Reporter.surroundThirdByTryCatch;
    __reporter__ = Reporter;
    isInPublicLib = true;
    return __reporter__;
  } catch (err) {
    __reporter__ = fakeReporter;
    return __reporter__;
  }
}
/* harmony default export */ const reporter = ({
  surroundThirdByTryCatch: (fn, extend) => {
    return getReporter().surroundThirdByTryCatch(fn, extend);
  },
  reportIDKey: options => {
    if (false) {}
    return getReporter().reportIDKey(options);
  },
  reportIDKeyDirectly: options => {
    if (false) {}
    return getReporter().reportIDKeyDirectly(options);
  },
  reportKeyValue: options => {
    if (false) {}
    return getReporter().reportKeyValue(options);
  },
  errorReport: options => {
    if (false) {}
    return getReporter().errorReport(options);
  }
});
;// CONCATENATED MODULE: ./src/utils/fail-safe.ts



function tryCatch(fn, customErrorStack = '') {
  try {
    var res = fn();
    return res;
  } catch (err) {
    if (isSDKError(err)) {
      err.errMsg += customErrorStack;
      return err;
    }
    var errMsg = (err ? err.toString() : '') + customErrorStack;
    return new error_CloudSDKError({
      errMsg
    });
  }
}
function wrapWithTryCatch(fn, customErrorStack = '') {
  return function (...args) {
    return tryCatch(() => fn.apply(fn, args), customErrorStack);
  };
}
function wrapParamCallbacksWithTryCatch(options) {
  var param = options.param;
  if (!param) return;
  if (param.success && isFunction(param.success)) {
    param.success = reporter.surroundThirdByTryCatch(param.success, `at api ${options.apiName} success callback function`);
  }
  if (param.fail && isFunction(param.fail)) {
    param.fail = reporter.surroundThirdByTryCatch(param.fail, `at api ${options.apiName} fail callback function`);
  }
  if (param.complete && isFunction(param.complete)) {
    param.complete = reporter.surroundThirdByTryCatch(param.complete, `at api ${options.apiName} complete callback function`);
  }
}
;// CONCATENATED MODULE: ./src/hook/invoke.ts


function invokeSuccessCallback(name, param, res) {
  if (param.success && isFunction(param.success)) {
    var fn = wrapWithTryCatch(param.success, `at api ${name} success callback function;`);
    fn(res);
  }
}
function invokeFailCallback(name, param, err) {
  if (param.fail && isFunction(param.fail)) {
    var fn = wrapWithTryCatch(param.fail, `at api ${name} fail callback function;`);
    fn(err);
  }
}
function invokeCompleteCallback(name, param, res) {
  if (param.complete && isFunction(param.complete)) {
    var fn = wrapWithTryCatch(param.complete, `at api ${name} complete callback function;`);
    fn(res);
  }
}
function invokeSuccessCompleteCallbacks(name, param, res) {
  invokeSuccessCallback(name, param, res);
  invokeCompleteCallback(name, param, res);
}
function invokeFailCompleteCallbacks(name, param, err) {
  invokeFailCallback(name, param, err);
  invokeCompleteCallback(name, param, err);
}
function hasAPICallback(param) {
  return param && (param.success || param.fail || param.complete);
}
;// CONCATENATED MODULE: ./src/utils/assert.ts



function validType(input, ref, name = 'parameter') {
  function validTypeImpl(input, ref, name) {
    var inputType = type_getType(input);
    var refType = type_getType(ref);
    if (refType === 'string') {
      if (inputType !== ref) {
        return `${name} should be ${ref} instead of ${inputType};`;
      }
      return '';
    } else {
      if (inputType !== refType) {
        return `${name} should be ${refType} instead of ${inputType}; `;
      }
      var errors = '';
      switch (inputType) {
        case 'object':
          {
            for (var key in ref) {
              errors += validTypeImpl(input[key], ref[key], `${name}.${key}`);
            }
            break;
          }
        case 'array':
          {
            for (var i = 0; i < ref.length; i++) {
              errors += validTypeImpl(input[i], ref[i], `${name}[${i}]`);
            }
            break;
          }
        default:
          {
            break;
          }
      }
      return errors;
    }
  }
  var error = validTypeImpl(input, ref, name);
  return {
    passed: !error,
    reason: error
  };
}
function assertType(param, ref, name = 'parameter', ErrorClass = error_CloudSDKError) {
  var paramCheckResult = validType(param, ref, name);
  if (!paramCheckResult.passed) {
    throw new ErrorClass({
      errCode: error_config_ERR_CODE.SDK_API_PARAMETER_TYPE_ERROR,
      errMsg: paramCheckResult.reason
    });
  }
}
function assertRequiredParam(param, name, funcName, ErrorClass = error_CloudSDKError) {
  if (param === undefined || param === null) {
    throw new ErrorClass({
      errCode: error_config_ERR_CODE.SDK_API_PARAMETER_ERROR,
      errMsg: `parameter ${name} of function ${funcName} must be provided`
    });
  }
}
function assertStringLength({
  name,
  input,
  max,
  maxWording = '',
  ErrorClass = error_CloudSDKError
}) {
  if (input.length > max) {
    throw new ErrorClass({
      errCode: error_config_ERR_CODE.SDK_API_PARAMETER_ERROR,
      errMsg: `${name} size must be less than ${maxWording || max}`
    });
  }
}
function assertObjectNotEmpty({
  target,
  name,
  ErrorClass = error_CloudSDKError
}) {
  if (Object.keys(target).length === 0) {
    throw new ErrorClass({
      errCode: error_config_ERR_CODE.SDK_API_PARAMETER_ERROR,
      errMsg: `${name} must not be empty`
    });
  }
}
;// CONCATENATED MODULE: ./src/utils/fn/clone.ts

function shallowClone(value, strict = false) {
  if (strict) {
    return strictShallowClone(value);
  }
  if (isPlainObject(value)) {
    return {
      ...value
    };
  }
  switch (type_getType(value)) {
    case 'object':
      {
        return value;
      }
    case 'array':
      {
        return value.slice();
      }
    default:
      {
        return value;
      }
  }
}
function strictShallowClone(value) {
  switch (type_getType(value)) {
    case 'object':
      {
        return {
          ...value
        };
      }
    case 'array':
      {
        return value.slice();
      }
    case 'number':
      {
        return value instanceof Number ? new Number(value) : value;
      }
    case 'string':
      {
        return value instanceof String ? new String(value) : value;
      }
    case 'boolean':
      {
        return value instanceof Boolean ? new Boolean(value) : value;
      }
    case 'date':
      {
        return new value.constructor(+value);
      }
    case 'map':
      {
        return new Map(value);
      }
    case 'set':
      {
        return new Set(value);
      }
    default:
      {
        return value;
      }
  }
}
;// CONCATENATED MODULE: ./src/externals/public-lib/appserviceSdk.ts
var SDKMap = new WeakMap();
var defaultSDK;
var patchTask = [];
function getDefaultSDK() {
  var _defaultSDK;
  var sdk = (_defaultSDK = defaultSDK) !== null && _defaultSDK !== void 0 ? _defaultSDK : typeof __appServiceSDK__ !== 'undefined' ? __appServiceSDK__ : undefined;
  if (sdk) {
    return patchTask.reduce((prev, curr) => curr(prev), sdk);
  }
  return sdk;
}
var appserviceSdk_getSDK = id => {
  if (!id) return getDefaultSDK();
  var SDK = SDKMap.get(id);
  if (SDK) {
    return SDK || getDefaultSDK();
  } else {
    return getDefaultSDK();
  }
};
var setSDK = (id, sdk) => {
  SDKMap.set(id, sdk);
};
var setDefaultSDK = sdk => {
  defaultSDK = sdk;
};
var patchDefaultSDK = patch => {
  patchTask.push(sdk => Object.assign({}, sdk, patch));
};
;// CONCATENATED MODULE: ./src/utils/throttle.ts
var throttle = (callback, wait) => {
  var timerId = null;
  var hasCall = false;
  var check = () => {
    if (timerId) {
      hasCall = true;
      return;
    }
    callback();
    timerId = setTimeout(() => {
      clearTimeout(timerId);
      timerId = null;
      if (hasCall) {
        hasCall = false;
        check();
      }
    }, wait);
  };
  return check;
};
/* harmony default export */ const utils_throttle = (throttle);
;// CONCATENATED MODULE: ./src/utils/expire.ts
function getPessimisticExpireTs(data) {
  if (typeof data === 'undefined' || !data.timestamp || !data.expires_in) {
    return 0;
  }
  var offset = Date.now() - data.timestamp;
  var decayExpiresIn = data.expires_in * 0.8;
  var pessimisticExpiresTs = Math.min(data.timestamp, Date.now()) + decayExpiresIn * 1000;
  if (offset > decayExpiresIn * 1000) {
    return Date.now() + decayExpiresIn * 1000;
  }
  return pessimisticExpiresTs;
}
;// CONCATENATED MODULE: ./src/utils/utils.ts




var _wxConsole = typeof wxConsole !== 'undefined' ? wxConsole :  false ? 0 : undefined;
var sleep = (ms = 0) => new Promise(r => setTimeout(r, ms));
var nextLoop = () => new Promise(r => setImmediate(r));
var counters = (/* unused pure expression or super */ null && ({}));
var autoCount = (domain = 'any') => {
  if (!counters[domain]) {
    counters[domain] = 0;
  }
  return counters[domain]++;
};
var getWXVersion = () => {
  var wx = appserviceSdk_getSDK().wx;
  var version;
  var updateTime;
  var updateDateInDashes;
  if (wx && wx.version) {
    version = wx.version.version;
    updateTime = wx.version.updateTime;
    var dateMatches = wx.version.updateTime.match(/^(\d+)\.(\d+)\.(\d+)/);
    if (dateMatches) {
      updateDateInDashes = `${dateMatches[1]}-${dateMatches[2]}-${dateMatches[3]}`;
    } else {
      updateDateInDashes = 'unknown';
    }
    return {
      version,
      updateTime,
      updateDateInDashes
    };
  } else {
    return {
      version: 'unknown',
      updateTime: 'unknown',
      updateDateInDashes: 'unknown'
    };
  }
};
var networkStatus;
var networkMonitored = false;
var networkOnlineSubscribers = [];
var getNetworkStatus = () => new Promise((resolve, reject) => {
  if (networkStatus) {
    resolve(networkStatus);
    return;
  }
  if (false) {}
  try {
    appserviceSdk_getSDK().wx.getNetworkType({
      success: res => {
        networkStatus = {
          networkType: res.networkType,
          isConnected: res.networkType !== 'none'
        };
        if (false) {}
        resolve(networkStatus);
        if (!networkMonitored) {
          monitorNetwork();
        }
      },
      fail: reject
    });
  } catch (e) {
    reject(e);
  }
});
var throwErrorIfNetworkOffline = () => new Promise(/*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (resolve, reject) {
    try {
      var {
        isConnected
      } = yield getNetworkStatus();
      if (isConnected) {
        resolve();
        if (false) {}
      } else {
        reject(`network offline`);
      }
    } catch (e) {
      resolve();
    }
  });
  return function (_x, _x2) {
    return _ref.apply(this, arguments);
  };
}());
var onceNetworkOnline = () => new Promise(resolve => {
  if (networkStatus && networkStatus.isConnected) {
    resolve();
  } else {
    networkOnlineSubscribers.push(resolve);
  }
});
function monitorNetwork() {
  appserviceSdk_getSDK().wx.onNetworkStatusChange(res => {
    networkStatus.networkType = res.networkType;
    networkStatus.isConnected = res.isConnected;
    if (res.isConnected && networkOnlineSubscribers.length) {
      while (networkOnlineSubscribers.length) {
        try {
          networkOnlineSubscribers.shift()();
        } catch (e) {}
      }
    }
  });
  networkMonitored = true;
}
var visibilityStatus;
var visibilityMonitored = false;
var appVisibilitySubscribers = new Set();
function onAppVisibilityChange(cb) {
  try {
    if (appserviceSdk_getSDK().wx.onAppShow) {
      if (!visibilityMonitored) {
        monitorAppVisibility();
        visibilityMonitored = true;
      }
      if (appVisibilitySubscribers.size > 50) {
        if (false) {}
        appVisibilitySubscribers.clear();
      }
      appVisibilitySubscribers.add(cb);
    }
  } catch (error) {}
}
function offAppVisibilityChange(cb) {
  appVisibilitySubscribers.delete(cb);
}
function monitorAppVisibility() {
  var wx = appserviceSdk_getSDK().wx;
  if (wx.onAppShow && wx.onAppHide) {
    wx.onAppShow(() => {
      visibilityStatus = 'visible';
      for (var fn of appVisibilitySubscribers) {
        try {
          fn('show');
        } catch (err) {
          if (false) {}
        }
      }
    });
    wx.onAppHide(() => {
      visibilityStatus = 'hidden';
      for (var fn of appVisibilitySubscribers) {
        try {
          fn('hide');
        } catch (err) {
          if (false) {}
        }
      }
    });
  }
}
var systemInfo;
function getSystemInfo() {
  if (systemInfo) return systemInfo;
  var wx = appserviceSdk_getSDK().wx;
  systemInfo = wx.getSystemInfoSync();
  return systemInfo;
}
var accountInfo;
function getAccountInfo() {
  if (accountInfo) return accountInfo;
  var wx = getSDK().wx;
  accountInfo = wx.getAccountInfoSync();
  return accountInfo;
}
var deviceInfo;
function getDeviceInfo() {
  if (deviceInfo) return deviceInfo;
  var wx = appserviceSdk_getSDK().wx;
  deviceInfo = wx.getDeviceInfo();
  return deviceInfo;
}
var launchOptions;
function getLaunchOptions() {
  if (launchOptions) return launchOptions;
  var wx = appserviceSdk_getSDK().wx;
  launchOptions = wx.getLaunchOptionsSync();
  return launchOptions;
}
function getRoutePage() {
  var _getSDK$getCurrentPag, _getSDK, _currentPages$;
  var currentPages = (_getSDK$getCurrentPag = (_getSDK = appserviceSdk_getSDK()).getCurrentPages) === null || _getSDK$getCurrentPag === void 0 ? void 0 : _getSDK$getCurrentPag.call(_getSDK);
  return currentPages === null || currentPages === void 0 ? void 0 : (_currentPages$ = currentPages[0]) === null || _currentPages$ === void 0 ? void 0 : _currentPages$.route;
}
var hasPrefetch = false;
var bgFetchData = undefined;
var bgFetchDataPromise;
function privateGetBackgroundFetchData(timeout = 500, identifiers = {}) {
  if (!appserviceSdk_getSDK().private_getBackgroundFetchData) return;
  if (identifiers.pluginId) return;
  if (bgFetchData) return bgFetchData;
  if (bgFetchDataPromise) return bgFetchDataPromise.then(() => bgFetchData);
  if (hasPrefetch) return;
  hasPrefetch = true;
  var startTs = Date.now();
  var warmStartTime = getWarmStartTs();
  bgFetchDataPromise = Promise.race([sleep(timeout).then(() => ({
    error: 'bg fetch timeout'
  })), new Promise((resolve, reject) => {
    appserviceSdk_getSDK().private_getBackgroundFetchData({
      fetchType: 0,
      success: res => {
        try {
          if (!res) {
            resolve({
              error: 'empty'
            });
          }
          bgFetchData = JSON.parse(res.fetchedData);
          bgFetchData.expiresTs = getPessimisticExpireTs(bgFetchData);
          resolve(bgFetchData);
          reportAPISpeed({
            apiName: 'private_getBackgroundFetchData',
            apiStartTime: startTs,
            apiEndTime: Date.now(),
            warmStartTime
          });
        } catch (error) {
          resolve({
            error
          });
        }
      },
      fail: error => {
        resolve({
          error
        });
      }
    });
  })]);
  if (bgFetchData) {
    _wxConsole === null || _wxConsole === void 0 ? void 0 : _wxConsole.log(`private_getBackgroundFetchData (cloud) (sync)`, JSON.stringify(bgFetchData));
    return bgFetchData;
  }
  return bgFetchDataPromise.then(res => {
    bgFetchDataPromise = undefined;
    _wxConsole === null || _wxConsole === void 0 ? void 0 : _wxConsole.log(`private_getBackgroundFetchData (cloud)`, JSON.stringify(res));
    if (!res.error) {
      return res;
    } else {
      return undefined;
    }
  });
}
function tryJSONParse(x) {
  try {
    return JSON.parse(x);
  } catch (e) {
    return x;
  }
}
function tryDecodeURIComponent(x) {
  try {
    return decodeURIComponent(x);
  } catch (e) {
    return x;
  }
}
function encodeWithDecode(x) {
  return encodeURIComponent(tryDecodeURIComponent(x));
}
var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
function btoa(input) {
  var str = String(input);
  var output = '';
  for (var block, charCode, idx = 0, map = chars; str.charAt(idx | 0) || (map = '=', idx % 1); output += map.charAt(63 & block >> 8 - idx % 1 * 8)) {
    charCode = str.charCodeAt(idx += 3 / 4);
    if (charCode > 0xFF) {
      throw new Error('"btoa" failed');
    }
    block = block << 8 | charCode;
  }
  return output;
}
function atob(input) {
  var str = String(input).replace(/=+$/, '');
  var output = '';
  if (str.length % 4 === 1) {
    throw new Error('"atob" failed');
  }
  for (var bc = 0, bs, buffer, idx = 0; buffer = str.charAt(idx++); ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer, bc++ % 4) ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6)) : 0) {
    buffer = chars.indexOf(buffer);
  }
  return output;
}
function arrayBufferToBase64(buffer) {
  var binaryString = '';
  var bytes = new Uint8Array(buffer);
  var len = bytes.byteLength;
  for (var i = 0; i < len; i++) {
    binaryString += String.fromCharCode(bytes[i]);
  }
  return btoa(binaryString);
}
function base64ToArrayBuffer(base64) {
  var binaryString = atob(base64);
  var len = binaryString.length;
  var bytes = new Uint8Array(len);
  for (var i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}
function arrayBufferToString(buffer) {
  return Utf8ArrayToStr(new Uint8Array(buffer));
}
function stringToArrayBuffer(string) {
  return stringToUtf8Array(string).buffer;
}
function stringToUtf8Array(str) {
  var utf8 = [];
  for (var i = 0; i < str.length; i++) {
    var charcode = str.charCodeAt(i);
    if (charcode < 0x80) utf8.push(charcode);else if (charcode < 0x800) {
      utf8.push(0xc0 | charcode >> 6, 0x80 | charcode & 0x3f);
    } else if (charcode < 0xd800 || charcode >= 0xe000) {
      utf8.push(0xe0 | charcode >> 12, 0x80 | charcode >> 6 & 0x3f, 0x80 | charcode & 0x3f);
    } else {
      i++;
      charcode = 0x10000 + ((charcode & 0x3ff) << 10 | str.charCodeAt(i) & 0x3ff);
      utf8.push(0xf0 | charcode >> 18, 0x80 | charcode >> 12 & 0x3f, 0x80 | charcode >> 6 & 0x3f, 0x80 | charcode & 0x3f);
    }
  }
  return new Uint8Array(utf8);
}
var Utf8ArrayToStr = function () {
  var charCache = new Array(128);
  var charFromCodePt = String.fromCodePoint || String.fromCharCode;
  var result = [];
  return function (array) {
    var codePt, byte1;
    var buffLen = array.length;
    result.length = 0;
    for (var i = 0; i < buffLen;) {
      byte1 = array[i++];
      if (byte1 <= 0x7F) {
        codePt = byte1;
      } else if (byte1 <= 0xDF) {
        codePt = (byte1 & 0x1F) << 6 | array[i++] & 0x3F;
      } else if (byte1 <= 0xEF) {
        codePt = (byte1 & 0x0F) << 12 | (array[i++] & 0x3F) << 6 | array[i++] & 0x3F;
      } else if (String.fromCodePoint) {
        codePt = (byte1 & 0x07) << 18 | (array[i++] & 0x3F) << 12 | (array[i++] & 0x3F) << 6 | array[i++] & 0x3F;
      } else {
        codePt = 63;
        i += 3;
      }
      result.push(charCache[codePt] || (charCache[codePt] = charFromCodePt(codePt)));
    }
    return result.join('');
  };
}();
function parseUrl(url) {
  var urlObj = {
    protocol: /^(.+):\/\//,
    host: /:\/\/(.+?)[?#\s/]/,
    path: /\w(\/.*?)[?#\s]/,
    query: /\?(.+?)[#/\s]/,
    hash: /#(\w+)\s$/
  };
  url += ' ';
  function formatQuery(str) {
    return str.split('&').reduce((a, b) => {
      var arr = b.split('=');
      a[arr[0]] = arr[1];
      return a;
    }, {});
  }
  var ret = {};
  var keys = Object.keys(urlObj);
  keys.forEach(key => {
    var pattern = urlObj[key];
    ret[key] = key === 'query' ? pattern.exec(url) && formatQuery(pattern.exec(url)[1]) : pattern.exec(url) && pattern.exec(url)[1];
  });
  return ret;
}
function compareVersions(version1, version2) {
  var v1parts = version1.split('.').map(Number);
  var v2parts = version2.split('.').map(Number);
  for (var i = 0; i < v1parts.length; ++i) {
    if (v2parts.length === i) {
      return 1;
    }
    if (v1parts[i] === v2parts[i]) {
      continue;
    }
    if (v1parts[i] > v2parts[i]) {
      return 1;
    }
    return -1;
  }
  if (v1parts.length !== v2parts.length) {
    return -1;
  }
  return 0;
}
function fetchFunc(url, {
  method,
  headers,
  body
}) {
  return new Promise((rs, rj) => {
    getSDK()._requestSkipCheckDomain({
      url,
      method,
      header: headers,
      data: body,
      success: rs,
      fail: rj
    });
  });
}
function toStr(s) {
  if (!s) {
    if (isNaN(s)) return 'NaN';
    if (s === null) return 'null';
    return typeof s;
  }
  if (Object.prototype.hasOwnProperty.call(s, 'toString') && typeof s.toString === 'function') {
    return s.toString();
  }
  if (typeof s[Symbol.toPrimitive] === 'function') {
    return s[Symbol.toPrimitive]();
  }
  if (s.message && typeof s.message === 'string') {
    return s.message;
  }
  if (s.errMsg && typeof s.errMsg === 'string') {
    return s.errMsg;
  }
  if (Object.prototype.toString.call(s) === Object.prototype.toString.call({})) {
    return JSON.stringify(s);
  }
  return '' + s;
}
function sizeOf(object) {
  var objectList = [];
  var stack = [object];
  var bytes = 0;
  while (stack.length) {
    var value = stack.pop();
    switch (typeof value) {
      case 'boolean':
        bytes += 4;
        break;
      case 'string':
        bytes += value.length * 2;
        break;
      case 'number':
        bytes += 8;
        break;
      case 'object':
        if (objectList.indexOf(value) === -1) {
          objectList.push(value);
          for (var prop in value) {
            if (value.hasOwnProperty(prop)) {
              stack.push(value[prop]);
            }
          }
        }
        break;
    }
  }
  return bytes;
}
// EXTERNAL MODULE: ../../node_modules/.pnpm/@tencent+cloud-sdk-protocol@1.16.2/node_modules/@tencent/cloud-sdk-protocol/dist/index.js
var dist = __webpack_require__(918);
;// CONCATENATED MODULE: ./src/network/tunnel.ts








var tunnel_wxConsole = _wxConsole;
var IDLE_TRIGGER_WAIT_TIME = 50;
var STD_PRIV_BLACKLIST = new Set(['tcbapi_init', 'tcbapi_get_service_info']);
var SERVER_LIMIT_CONTROL_TIMEOUT = 1000;
class RequestLimiter {
  constructor(limitPerMinute) {
    this.limitPerMinute = void 0;
    this.tokens = void 0;
    this.lastRefillTime = void 0;
    this.reported = false;
    this.serverLastLimitExceedSeen = 0;
    this.serverLimited = false;
    this.limitPerMinute = limitPerMinute;
    this.tokens = this.limitPerMinute;
    this.lastRefillTime = Date.now();
  }
  markServerLimitExceed() {
    this.serverLastLimitExceedSeen = Date.now();
    this.serverLimited = true;
  }
  updateLimit(limit) {
    this.limitPerMinute = limit;
  }
  reportClientLimited() {
    if (this.reported) return;
    this.reported = true;
    var now = Date.now();
    reportAPISpeed({
      apiName: 'RequestLimiter',
      funcName: 'limit',
      apiStartTime: this.lastRefillTime,
      apiEndTime: now,
      tunnelStartTime: this.lastRefillTime,
      tunnelEndTime: now,
      errMsg: 'user request limit exceed',
      resultStatus: 2,
      bypassCheck: true
    });
  }
  refillTokens() {
    var now = Date.now();
    var elapsedTime = now - this.lastRefillTime;
    if (elapsedTime > 60 * 1000) {
      this.tokens = this.limitPerMinute;
      this.lastRefillTime = now;
    }
  }
  allowRequest() {
    this.refillTokens();
    if (this.serverLimited && Date.now() - this.serverLastLimitExceedSeen < SERVER_LIMIT_CONTROL_TIMEOUT) {
      this.reportClientLimited();
      return false;
    }
    if (this.tokens > 0) {
      this.tokens -= 1;
      return true;
    } else {
      this.reportClientLimited();
      return false;
    }
  }
}
var limiter = new RequestLimiter(1000);
class TunnelManager {
  constructor() {
    this._running = 0;
    this._onIdleCallbacks = [];
    this._idleTriggerTimer = void 0;
  }
  get running() {
    return this._running;
  }
  incrementRunning(count = 1) {
    this._running += count;
    if (this._idleTriggerTimer) {
      clearTimeout(this._idleTriggerTimer);
    }
  }
  decrementRunning(count = 1) {
    this._running -= count;
    if (this._running < 0) {
      this._running = 0;
    }
    if (this._running <= 0 && this._onIdleCallbacks.length) {
      this._idleTriggerTimer = setTimeout(() => {
        this._idleTriggerTimer = null;
        if (this._onIdleCallbacks.length) {
          var first = this._onIdleCallbacks.shift();
          if (first) {
            first();
          }
        }
      }, IDLE_TRIGGER_WAIT_TIME);
    }
  }
  onceIdle(callback) {
    if (this._running > 0) {
      this._onIdleCallbacks.push(callback);
    } else {
      callback();
    }
  }
}
var tunnelManager = new TunnelManager();
function tunnel(req, options = {}) {
  if (options.fireOnIdle && tunnelManager.running > 0) {
    return new Promise((resolve, reject) => {
      tunnelManager.onceIdle(/*#__PURE__*/asyncToGenerator_default()(function* () {
        try {
          var result = yield tunnel(req, options);
          resolve(result);
        } catch (err) {
          reject(err);
        }
      }));
    });
  }
  if (options.onFire) {
    try {
      options.onFire();
    } catch (err) {}
  }
  return new Promise((resolve, reject) => {
    var _req$cloud, _req$cloud2, _req$cloud2$instanceO, _req$cloud3, _req$cloud4, _req$cloud4$authStora, _req$cloud5;
    tunnelManager.incrementRunning();
    if (!limiter.allowRequest()) {
      reject(toSDKError({
        errCode: error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_SERVER_REQUEST_COUNT,
        errMsg: `error: exceed max client request count, avoid infinite loop in your code`
      }, 'cloud'));
      return;
    }
    var url;
    if ((_req$cloud = req.cloud) !== null && _req$cloud !== void 0 && _req$cloud.plugins) {
      var metadata = req.cloud.plugins.reduce((metadata, plugin) => plugin.getMetadata(metadata), {});
      url = `https://${metadata.host || 'servicewechat.com'}/wxa-qbase/jsoperatewxdata`;
      req = req.cloud.plugins.reduce((config, plugin) => plugin.beforeTunnelRequest(req), req) || req;
    }
    var __appServiceSDK__ = appserviceSdk_getSDK((req.cloud || options.cloud || {}).identifiers);
    __appServiceSDK__.invokeOperateWXData({
      appid: ((_req$cloud2 = req.cloud) === null || _req$cloud2 === void 0 ? void 0 : (_req$cloud2$instanceO = _req$cloud2.instanceOptions) === null || _req$cloud2$instanceO === void 0 ? void 0 : _req$cloud2$instanceO.resourceAppid) || ((_req$cloud3 = req.cloud) === null || _req$cloud3 === void 0 ? void 0 : _req$cloud3.config.appid),
      accessToken: (_req$cloud4 = req.cloud) === null || _req$cloud4 === void 0 ? void 0 : (_req$cloud4$authStora = _req$cloud4.authStorage) === null || _req$cloud4$authStora === void 0 ? void 0 : _req$cloud4$authStora.getItem('access_token'),
      webRequest: (_req$cloud5 = req.cloud) === null || _req$cloud5 === void 0 ? void 0 : _req$cloud5.webRequest,
      url,
      apiName: req.apiName || 'qbase_commapi',
      reqData: req.data,
      requestInQueue: false,
      success: res => {
        var _req$cloud6;
        res = ((_req$cloud6 = req.cloud) === null || _req$cloud6 === void 0 ? void 0 : _req$cloud6.plugins.reduce((prev, plugin) => plugin.afterTunnelRequest(prev), res)) || res;
        if (false) {}
        var resp = {
          ...res,
          data: res.data
        };
        if (res.data) {
          try {
            var rawRespJSON = res.data;
            if (rawRespJSON.baseresponse && rawRespJSON.baseresponse.errcode !== 0) {
              var error = new error_CloudSDKError({
                errCode: rawRespJSON.baseresponse.errcode,
                errMsg: rawRespJSON.baseresponse.errmsg
              });
              reject(error);
              return;
            } else {
              resp = {
                ...res,
                data: rawRespJSON
              };
            }
          } catch (err) {
            var _error = new error_CloudSDKError({
              errMsg: err && err.toString()
            });
            reject(_error);
            return;
          }
        } else {
          if (options) {
            if (options.requireDataNotEmpty) {
              var _error2 = new error_CloudSDKError({
                errCode: res.errCode,
                errMsg: `error empty internal server response, ${res.errMsg}`
              });
              reject(_error2);
              return;
            }
          }
        }
        resolve(resp);
      },
      fail: err => {
        if (err && err.errMsg) {
          if (err.errMsg.includes('invalid scope')) {
            var errMsg = 'invalid scope 没有权限，请先开通云服务';
            err = new Error(errMsg);
            err.errMsg = errMsg;
            err.operateWXDataFail = true;
          } else {
            var _errMsg = err.errMsg.replace(/^operateWXData:fail /, '');
            if (_errMsg.includes('meet frequency limit')) {
              limiter.markServerLimitExceed();
            }
            err = new Error(_errMsg);
            err.errMsg = _errMsg;
            err.operateWXDataFail = true;
          }
        }
        reject(err);
        if (false) {}
      },
      complete: function () {
        if (req.complete) {
          req.complete.apply(null, arguments);
        }
        tunnelManager.decrementRunning();
      }
    });
  });
}
function constructTunnelReq(options) {
  var cloud = options.cloud;
  var qbaseOptions = cloud.isInstance ? {
    ...cloud.instanceOptions,
    appid: cloud.instanceOptions.resourceAppid,
    env: cloud.instanceOptions.resourceEnv
  } : {
    identityless: cloud.runtimeInfo.platform === 'sdk' ? cloud.config.identityless : undefined,
    appid: cloud.config.appid,
    env: options.env || cloud.config.env
  };
  return {
    apiName: 'qbase_commapi',
    data: {
      qbase_api_name: options.apiName,
      qbase_req: options.serializedReqData,
      qbase_options: qbaseOptions,
      qbase_meta: cloud.getMetaData(),
      cli_req_id: `${+new Date()}_${Math.random()}`
    },
    cloud
  };
}
function getBoundTunnelRequest(getBoundTunnelRequestOptions) {
  var {
    cloud
  } = getBoundTunnelRequestOptions;
  return /*#__PURE__*/function () {
    var _boundTunnelRequest = asyncToGenerator_default()(function* (options) {
      var qbaseOptions = cloud.isInstance ? {
        ...cloud.instanceOptions,
        appid: cloud.instanceOptions.resourceAppid,
        env: cloud.instanceOptions.resourceEnv
      } : {
        identityless: cloud.runtimeInfo.platform === 'sdk' ? true : undefined,
        appid: cloud.runtimeInfo.platform === 'sdk' ? cloud.config.appid : undefined,
        env: options.env || (cloud.runtimeInfo.platform === 'sdk' ? cloud.config.env : undefined)
      };
      var data = {
        qbase_api_name: options.apiName,
        qbase_req: options.serializedReqData,
        qbase_options: qbaseOptions,
        qbase_meta: cloud.getMetaData(),
        cli_req_id: `${+new Date()}_${Math.random()}`
      };
      if (options.stdpriv && !STD_PRIV_BLACKLIST.has(options.apiName) && getSystemInfo().platform !== 'windows') {
        var res = yield stdPrivateProtocol(cloud, data).catch(err => {
          if (err && (err.errCode === -9999 || err.errCode === -9998)) {
            return tunnel({
              apiName: 'qbase_commapi',
              data,
              cloud
            }).then(res => {
              return {
                ...res,
                channelType: err.errCode === -9998 ? 0 : 2
              };
            });
          }
          throw err;
        });
        return res;
      }
      return tunnel({
        apiName: 'qbase_commapi',
        data,
        cloud
      });
    });
    function boundTunnelRequest(_x) {
      return _boundTunnelRequest.apply(this, arguments);
    }
    return boundTunnelRequest;
  }();
}
function stdPrivateProtocol(_x2, _x3) {
  return _stdPrivateProtocol.apply(this, arguments);
}
function _stdPrivateProtocol() {
  _stdPrivateProtocol = asyncToGenerator_default()(function* (cloud, data) {
    var endpoint = cloud.serviceEndpoint.getEndpointSync('container');
    if (!(endpoint !== null && endpoint !== void 0 && endpoint.cloudServiceUrl)) {
      throw {
        errCode: -9998,
        errMsg: 'cloudServiceUrl not found'
      };
    }
    tunnel_wxConsole === null || tunnel_wxConsole === void 0 ? void 0 : tunnel_wxConsole.info(`cloud stdpriv begin`, data);
    var __appServiceSDK__ = appserviceSdk_getSDK(cloud.identifiers);
    var outerRequestHeader = {
      'X-WX-ENCRYPTION-VERSION': 2,
      'X-WX-ENCRYPTION-TIMESTAMP': endpoint.timestamp + '',
      'X-WX-COMPRESSION': 'snappy',
      'X-WX-LIB-BUILD-TS': 1727594124553,
      'X-WX-RESPONSE-CONTENT-ACCEPT-ENCODING': 'JSON',
      'Content-Type': 'application/octet-stream'
    };
    outerRequestHeader['X-WX-REQUEST-CONTENT-ENCODING'] = 'PB';
    var key = new Uint8Array(base64ToArrayBuffer(endpoint.key));
    var {
      data: encReq
    } = dist.V1.encodeStdPrivRequest(key, {
      cliReqId: data.cli_req_id,
      qbaseApiName: data.qbase_api_name,
      qbaseMeta: {
        filterUserInfo: data.qbase_meta.filter_user_info,
        sdkVersion: data.qbase_meta.sdk_version,
        sessionId: data.qbase_meta.session_id
      },
      qbaseOptions: {
        env: data.qbase_options.env
      },
      qbaseReq: data.qbase_req
    }, {});
    var token = getCloudServiceToken({
      rdm: cloud.getConfig().rdm
    });
    return new Promise((resolve, reject) => {
      if (!limiter.allowRequest()) {
        reject(toSDKError({
          errCode: error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_SERVER_REQUEST_COUNT,
          errMsg: `error: exceed max client request count, avoid infinite loop in your code`
        }, 'cloud'));
        return;
      }
      __appServiceSDK__._requestSkipCheckDomain({
        url: token.url,
        method: 'POST',
        header: outerRequestHeader,
        data: encReq.buffer,
        dataType: 'arraybuffer',
        responseType: 'arraybuffer',
        enableHttp2: true,
        success: res => {
          try {
            tunnel_wxConsole === null || tunnel_wxConsole === void 0 ? void 0 : tunnel_wxConsole.info('res', res);
            for (var _key in res.header) {
              if (_key.toLowerCase() === 'x-nws-log-uuid') {
                tunnel_wxConsole === null || tunnel_wxConsole === void 0 ? void 0 : tunnel_wxConsole.log(`[cloud.callContainer] x-nws-log-uuid ${res.header[_key]}`);
              }
              if (_key.toLowerCase() === 'x-wx-system-error') {
                var code = Number(res.header[_key]);
                if (code === 85104) {
                  token.invalidate();
                }
                if (code === 102003) {
                  limiter.markServerLimitExceed();
                }
                reject(new Error(`wx system error. code: ${code}`));
                return;
              }
            }
            if (res.statusCode === 200) {
              var resData = res.data;
              var compressed = false;
              for (var _key2 in res.header) {
                if (_key2.toLowerCase() === 'x-wx-compression' && res.header[_key2] === 'snappy') {
                  compressed = true;
                }
              }
              var rawResponse = dist.V1.decodeStdPrivResponse(key, new Uint8Array(resData), compressed);
              resolve({
                errCode: 0,
                errMsg: '',
                data: rawResponse,
                profile: res.profile,
                channelType: 1
              });
            } else {
              reject({
                errCode: -9999,
                errMsg: `system conn status not 200`
              });
            }
          } catch (e) {
            reject(new Error(`error while processing internal response ${e}`));
          }
        },
        fail: err => {
          reject({
            ...err,
            errCode: -9999,
            errMsg: err.errMsg
          });
        }
      });
    });
  });
  return _stdPrivateProtocol.apply(this, arguments);
}
/* harmony default export */ const network_tunnel = (tunnel);
;// CONCATENATED MODULE: ./src/utils/token-manager.ts



var log =  false ? 0 : () => void 0;
class TokenManager {
  constructor(refreshToken, proactiveRefreshTimer, onRefreshedToken) {
    this.refreshToken = refreshToken;
    this.proactiveRefreshTimer = proactiveRefreshTimer;
    this.onRefreshedToken = onRefreshedToken;
    this.state = "init";
    this.currentToken = undefined;
    this.currentSession = undefined;
    this.currentTask = undefined;
    this.refreshHandler = undefined;
  }
  transition(nextState, payload) {
    log(`[gateway:token] transition ${this.state} -> ${nextState}`, payload);
    switch (this.state) {
      case "init":
        if (nextState === "refreshing") {
          this.state = "refreshing";
          this.currentTask = payload.task;
        } else {
          log(`[gateway:token] invalid transition ${this.state} -> ${nextState}`);
        }
        break;
      case "normal":
        if (nextState === "refreshing") {
          this.state = "refreshing";
          Object.defineProperty(this.currentToken, '__invalidated', {
            value: true
          });
          this.currentToken = undefined;
          this.currentTask = payload.task;
        } else if (nextState === "normal") {
          if (payload.token && this.currentToken) {
            if (payload.token.timestamp > this.currentToken.timestamp) {
              this.currentToken = payload.token;
              this.currentTask = undefined;
            }
          }
        } else {
          log(`[gateway:token] invalid transition ${this.state} -> ${nextState}`);
        }
        break;
      case "refreshing":
        if (nextState === "normal") {
          this.state = "normal";
          this.currentToken = payload.token;
          this.currentTask = undefined;
        } else {
          log(`[gateway:token] invalid transition ${this.state} -> ${nextState}`);
        }
        break;
      default:
        break;
    }
  }
  getTokenSync() {
    if (this.currentToken) {
      if (this.currentToken.exp < Date.now()) {
        this.invalidate(this.currentToken).catch(() => {});
        return undefined;
      }
      return this.currentToken;
    }
    return undefined;
  }
  getToken() {
    var _this = this;
    return asyncToGenerator_default()(function* () {
      if (_this.currentToken) {
        if (_this.currentToken.exp < Date.now()) {
          return _this.invalidate(_this.currentToken);
        }
        return _this.currentToken;
      }
      return _this.invalidate();
    })();
  }
  updateSession(session) {
    var _this2 = this;
    return asyncToGenerator_default()(function* () {
      var sessionPromise = new Promise(res => typeof session === 'string' ? res(session) : session ? session.then(res) : res(session));
      _this2.currentSession = yield sessionPromise;
      return _this2.invalidate();
    })();
  }
  invalidate(token, lax) {
    var _this3 = this;
    return asyncToGenerator_default()(function* () {
      var _this3$onRefreshedTok;
      if (_this3.state === "refreshing" && _this3.currentTask) {
        return _this3.currentTask;
      }
      if (token !== null && token !== void 0 && token.__invalidated && _this3.state === "normal" && _this3.currentToken) {
        log('[gateway:token] already invalidated token returning latest not refreshing');
        return _this3.currentToken;
      }
      if (_this3.refreshHandler) clearTimeout(_this3.refreshHandler);
      var session = _this3.currentSession;
      var promise = new Promise((res, rej) => {
        var startTime = Date.now();
        _this3.refreshToken(session).then(authorization => {
          var timestamp = 0;
          var expires_in = 0;
          if ('iat' in authorization) {
            timestamp = authorization.iat * 1000;
            expires_in = authorization.exp - authorization.iat;
          } else {
            timestamp = authorization.timestamp;
            expires_in = authorization.expires_in;
          }
          var exp = getPessimisticExpireTs({
            timestamp,
            expires_in
          });
          if (exp === 0) {
            rej('invalid token timestamp, abort');
            return;
          }
          var managedToken = {
            ...authorization,
            exp,
            timestamp,
            invalidate: () => _this3.invalidate(token)
          };
          _this3.transition("normal", {
            token: managedToken
          });
          var nextInterval = managedToken.exp - Date.now();
          _this3.refreshHandler = _this3.proactiveRefreshTimer ? setTimeout(() => {
            _this3.invalidate(void 0, true);
          }, _this3.proactiveRefreshTimer(nextInterval)) : undefined;
          res(managedToken);
        }).catch(err => {
          var endTime = Date.now();
          var errMsg = '';
          if (err instanceof Error) {
            errMsg = err.message;
          } else if (typeof err === 'string') {
            errMsg = err;
          } else {
            errMsg = err + '';
          }
          errMsg.replace(/,/g, '.');
          reportAPISpeed({
            apiName: 'TokenManager',
            funcName: lax ? 'ProactiveRefreshTimer' : 'Invalidation',
            apiStartTime: startTime,
            apiEndTime: endTime,
            tunnelStartTime: startTime,
            tunnelEndTime: endTime,
            errMsg,
            resultStatus: 2
          });
          rej(errMsg);
        });
      });
      if (!lax) {
        _this3.transition("refreshing", {
          task: promise
        });
      }
      var managedToken = yield promise;
      (_this3$onRefreshedTok = _this3.onRefreshedToken) === null || _this3$onRefreshedTok === void 0 ? void 0 : _this3$onRefreshedTok.call(_this3, managedToken);
      return managedToken;
    })();
  }
}
;// CONCATENATED MODULE: ./src/utils/service-endpoint.ts







var HOST_REG = /https:\/\/servicewechat\.com/;
var refreshing = (/* unused pure expression or super */ null && ({}));
var timerScheduled = {};
var service_endpoint_hasPrefetch = false;
var clientRandom = `${Math.random()}_${Date.now()}`; // #@snapshot-ignore Date.now,Math.random
if (typeof Foundation !== 'undefined') {
  Foundation.onLoad(() => {
    clientRandom = `${Math.random()}_${Date.now()}`;
  });
}
var tokenManagers = {};
class ServiceEndpoint {
  constructor(identifiers) {
    this.identifiers = identifiers;
    this._tunnelRequest = void 0;
    this._meta = void 0;
    this.containerTokenManager = new TokenManager(this.refreshContainerServiceEndpoint.bind(this), t => t, token => this.processServiceEndpoint(token));
    tokenManagers.container = this.containerTokenManager;
  }
  setMetaData(meta) {
    this._meta = meta;
  }
  setTunnelRequest(boundTunnelRequest) {
    this._tunnelRequest = boundTunnelRequest;
  }
  getEndpointSync(name) {
    if (name === 'container') {
      var info = this.containerTokenManager.getTokenSync();
      if (info !== null && info !== void 0 && info.url) {
        return info;
      }
    }
    return undefined;
  }
  getEndpoint(name) {
    var _this = this;
    return asyncToGenerator_default()(function* () {
      if (name === 'container') {
        return _this.containerTokenManager.getToken();
      }
      if (name === 'servicewechatDNS') {
        return null;
      }
      return null;
    })();
  }
  processServiceEndpoint(data) {
    return asyncToGenerator_default()(function* () {
      setReportToken(data, '1');
      addKeepAliveHost(`${data.domain || 'servicewechat.com'}/wxa-qbase/keepalive`);
      _keepAlive();
      deferKeepAlive();
    })();
  }
  refreshContainerServiceEndpoint() {
    var _this2 = this;
    return asyncToGenerator_default()(function* () {
      clearTimeout(timerScheduled.container);
      if (appserviceSdk_getSDK().private_getBackgroundFetchData && !service_endpoint_hasPrefetch) {
        service_endpoint_hasPrefetch = true;
        var res = privateGetBackgroundFetchData(500, _this2.identifiers);
        if (res && !res.url_info) {
          res = yield res;
        }
        if (res && res.expiresTs > Date.now() && res.url_info) {
          var _res$url_info, _res$url_info2;
          var endpoint = {
            url: (_res$url_info = res.url_info) !== null && _res$url_info !== void 0 && _res$url_info.cloudrun_url ? `${res.url_info.cloudrun_url}?token=${res.token}` : `https://${res.domain}/wxa-qbase/container_service?token=${res.token}`,
            cloudServiceUrl: (_res$url_info2 = res.url_info) !== null && _res$url_info2 !== void 0 && _res$url_info2.cloudbase_url ? `${res.url_info.cloudbase_url}?token=${res.token}` : undefined,
            domain: res.domain || 'servicewechat.com',
            token: res.token,
            http: true,
            key: res.key,
            timestamp: res.timestamp,
            expires_in: res.expires_in,
            exp: res.expires_in
          };
          return endpoint;
        }
      }
      var errors = [];
      for (var i = 0; i < 3; i++) {
        try {
          var _data$url_info, _data$url_info2;
          var startTs = Date.now();
          var info = getSystemInfo();
          var result = _this2._tunnelRequest ? yield _this2._tunnelRequest({
            apiName: 'tcbapi_get_service_info',
            serializedReqData: JSON.stringify({
              client_random: clientRandom,
              system: info.system,
              wx_app_version: info.version
            })
          }) : yield network_tunnel({
            apiName: 'qbase_commapi',
            data: {
              qbase_api_name: 'tcbapi_get_service_info',
              qbase_req: JSON.stringify({
                client_random: clientRandom,
                system: info.system,
                wx_app_version: info.version
              }),
              qbase_options: {},
              qbase_meta: _this2._meta,
              cli_req_id: `${+new Date()}_${Math.random()}`
            }
          });
          var data = result.data;
          if (Date.now() - startTs > data.expires_in * 1000) {
            errors.push(`result already expired (startTs ${startTs} resultTs ${Date.now()})`);
            continue;
          }
          var domain = data.domain || 'servicewechat.com';
          var _endpoint = {
            url: (_data$url_info = data.url_info) !== null && _data$url_info !== void 0 && _data$url_info.cloudrun_url ? `${data.url_info.cloudrun_url}?token=${data.token}` : `https://${domain}/wxa-qbase/container_service?token=${data.token}`,
            cloudServiceUrl: (_data$url_info2 = data.url_info) !== null && _data$url_info2 !== void 0 && _data$url_info2.cloudbase_url ? `${data.url_info.cloudbase_url}?token=${data.token}` : undefined,
            domain,
            token: data.token,
            http: data.http,
            key: data.key,
            timestamp: data.timestamp,
            ip: data.ip,
            vip: data.vip,
            expires_in: data.expires_in,
            exp: data.expires_in
          };
          return _endpoint;
        } catch (e) {
          errors.push(e + '');
        }
      }
      throw new Error(`get container service endpoints errors: ${errors.join('\n')}`);
    })();
  }
  invalidateToken(endpoint, token) {
    if (endpoint === 'container') {
      this.containerTokenManager.invalidate(token);
    }
  }
  static invalidateService(endpoint, token) {
    var _tokenManagers$endpoi;
    (_tokenManagers$endpoi = tokenManagers[endpoint]) === null || _tokenManagers$endpoi === void 0 ? void 0 : _tokenManagers$endpoi.invalidate(token);
  }
}
function getCloudServiceToken(options) {
  var _tokenManagers$contai;
  var endpoint = (_tokenManagers$contai = tokenManagers.container) === null || _tokenManagers$contai === void 0 ? void 0 : _tokenManagers$contai.getTokenSync();
  if (!(endpoint !== null && endpoint !== void 0 && endpoint.cloudServiceUrl)) return;
  if (options.rdm) {
    endpoint.cloudServiceUrl = endpoint.cloudServiceUrl.replace(HOST_REG, 'https://wxardm.weixin.qq.com');
  }
  return endpoint;
}
var __keepalive__ = false;
var __eventMonitored__ = false;
var KEEP_ALIVE_DEFAULT_TIMEOUT = 30 * 1000;
var KEEP_ALIVE_CHECK_INTERVAL = 10 * 1000;
function _keepAlive() {
  return _keepAlive2.apply(this, arguments);
}
function _keepAlive2() {
  _keepAlive2 = asyncToGenerator_default()(function* (preflight = true) {
    if (__keepalive__) {
      return;
    }
    __keepalive__ = true;
    var loopKeepalive = () => {
      if (!__keepalive__) return;
      setTimeout(/*#__PURE__*/asyncToGenerator_default()(function* () {
        keepAlive();
        loopKeepalive();
      }), KEEP_ALIVE_CHECK_INTERVAL);
    };
    loopKeepalive();
    if (!__eventMonitored__) {
      var _sdk$wx;
      __eventMonitored__ = true;
      var sdk = appserviceSdk_getSDK();
      if ((_sdk$wx = sdk.wx) !== null && _sdk$wx !== void 0 && _sdk$wx.onAppHide) {
        sdk.wx.onAppHide(() => {
          __keepalive__ = false;
        });
      }
    }
    if (preflight) {
      keepAlive();
    }
    return;
  });
  return _keepAlive2.apply(this, arguments);
}
var deferKeepAlive = (host = 'servicewechat.com/wxa-qbase/keepalive') => {
  keepAliveURLMap.set(host, Date.now());
};
var keepAliveURLMap = new Map();
function addKeepAliveHost(host) {
  var _keepAliveURLMap$get;
  keepAliveURLMap.set(host, (_keepAliveURLMap$get = keepAliveURLMap.get(host)) !== null && _keepAliveURLMap$get !== void 0 ? _keepAliveURLMap$get : 0);
}
var keepAlive = () => new Promise(resolve => {
  var _loop = function (url) {
    var _keepAliveURLMap$get2;
    var lastHostKeepAliveTime = (_keepAliveURLMap$get2 = keepAliveURLMap.get(url)) !== null && _keepAliveURLMap$get2 !== void 0 ? _keepAliveURLMap$get2 : 0;
    if (Date.now() - lastHostKeepAliveTime < KEEP_ALIVE_DEFAULT_TIMEOUT) {
      return 1;
    }
    var startTs = Date.now();
    keepAliveURLMap.set(url, startTs);
    var usingHostname = !/^\d+/.test(url);
    var args = {
      url: `${usingHostname ? 'https' : 'http'}://${url}?devtools_ignore=true`,
      header: usingHostname ? {} : {
        host: 'servicewechat.com'
      },
      method: 'GET',
      dataType: 'text',
      enableHttp2: usingHostname,
      enableQuic: usingHostname,
      success: () => {
        resolve();
        if (Math.random() > 0.125) return;
        reportMMData(22990, 1, ['privateHttpKeepAlive', url, startTs, Date.now(), Date.now() - startTs].join(','));
      },
      fail: () => {
        resolve();
      }
    };
    appserviceSdk_getSDK()._requestSkipCheckDomain(args);
  };
  for (var url of keepAliveURLMap.keys()) {
    if (_loop(url)) continue;
  }
});
;// CONCATENATED MODULE: ./src/externals/globals/wxconfig.ts
var WXConfig = __wxConfig;
if (false) {}
/* harmony default export */ const wxconfig = (WXConfig);
var isDevTools = () => WXConfig.platform === 'devtools';
var isMINA = () => WXConfig.platform === 'mina';
var isWindows = () => WXConfig.platform === 'windows';
var isMac = () => WXConfig.platform === 'mac';
;// CONCATENATED MODULE: ./src/utils/report.ts







var isReportAPISpeedOptionsValid = options => {
  if (options.bypassCheck) {
    return true;
  }
  if (options.tunnelStartTime && options.tunnelEndTime && options.tunnelEndTime < options.tunnelStartTime) {
    return false;
  }
  if (options.apiStartTime && options.apiEndTime) {
    if (options.apiEndTime > options.apiStartTime) {
      return true;
    }
  }
  return false;
};
var inited = false;
var reportQueue = [];
var coldStart = Date.now(); // #@snapshot-ignore Date.now
var warmStart = Date.now(); // #@snapshot-ignore Date.now

var _networkType = 'unknown';
if (typeof Foundation !== 'undefined') {
  Foundation.onLoad(() => {
    var now = Date.now();
    coldStart = now;
    warmStart = now;
  });
}
wxconfig.onReady(() => {
  coldStart = Date.now();
  warmStart = Date.now();
});
var getColdStartTs = () => coldStart;
var getWarmStartTs = () => warmStart;
var init = () => {
  if (inited) {
    return;
  }
  try {
    var defaultAppserviceSDK = appserviceSdk_getSDK();
    if (defaultAppserviceSDK.wx.onAppShow) {
      defaultAppserviceSDK.wx.onAppShow(() => {
        warmStart = Date.now();
      });
    }
    defaultAppserviceSDK.wx.getNetworkType({
      success: res => {
        _networkType = res.networkType;
      },
      complete: () => {
        inited = true;
        clearQueue();
      }
    });
    defaultAppserviceSDK.wx.onNetworkStatusChange(res => {
      if (!inited) {
        inited = true;
        clearQueue();
      }
      _networkType = res.networkType;
    });
  } catch (err) {
    if (false) {}
  }
};
var clearQueue = () => {
  if (false) {}
  for (var fn of reportQueue) {
    try {
      fn();
    } catch (err) {
      if (false) {}
    }
  }
  reportQueue = [];
};
function replaceCommaInArray(arr) {
  for (var i = 0; i < arr.length; i++) {
    var element = arr[i];
    if (typeof element === 'string') {
      arr[i] = element.replace(/,/g, ' ');
    }
  }
  return arr;
}
var reportAPISpeed = options => {
  if (false) {}
  setTimeout(() => {
    try {
      var _options$channelType, _options$usingPrefetc, _options$resultStatus, _options$errMsg;
      if (!isReportAPISpeedOptionsValid(options)) {
        return;
      }
      if (!inited && reportQueue.length < 100) {
        reportQueue.push(reportAPISpeed.bind(null, options));
        if (false) {}
        return;
      }
      var apiTotalTime = options.apiEndTime - options.apiStartTime;
      var tunnelTotalTime = options.tunnelEndTime ? options.tunnelEndTime - options.tunnelStartTime : 0;
      var valueArray = replaceCommaInArray([0, options.apiName, apiTotalTime, tunnelTotalTime, (options.pollStartTime && options.pollEndTime && options.pollEndTime > options.pollStartTime ? options.pollEndTime - options.pollStartTime : 0) || 0, _networkType, options.tunnelTimeNoCSNetCost ? apiTotalTime - options.tunnelTimeNoCSNetCost : 0, options.tunnelTimeNoCSNetCost ? tunnelTotalTime - options.tunnelTimeNoCSNetCost : 0, options.funcExecTime ? options.funcExecTime : 0, (_options$channelType = options.channelType) !== null && _options$channelType !== void 0 ? _options$channelType : 0, options.funcName || '', options.apiStartTime - coldStart, options.warmStartTime !== undefined ? options.apiStartTime - options.warmStartTime : 0, (_options$usingPrefetc = options.usingPrefetchToken) !== null && _options$usingPrefetc !== void 0 ? _options$usingPrefetc : 0, (_options$resultStatus = options.resultStatus) !== null && _options$resultStatus !== void 0 ? _options$resultStatus : 1, (_options$errMsg = options.errMsg) !== null && _options$errMsg !== void 0 ? _options$errMsg : '']);
      if (reporter.fake) {
        reportMMData(16588, 6, valueArray.join(','));
      } else {
        reporter.reportKeyValue({
          key: 'CloudReport',
          value: valueArray.join(','),
          force: true
        });
      }
    } catch (err) {}
  });
};
var reportIDKey = (id, key, force, immediately) => {
  reporter.reportIDKeyDirectly({
    id,
    key,
    force,
    immediately
  });
};
var token;
var version;
var setReportToken = (t, v) => (token = t, version = v);
var mmdataList = [];
var reportMMData = (log_id, version, user_log_list) => {
  mmdataList.push({
    log_id,
    version,
    user_log_list
  });
  if (token) {
    _reportMMData();
  }
};
var _reportMMData = utils_throttle(() => {
  var SDK = appserviceSdk_getSDK();
  SDK._requestSkipCheckDomain({
    url: `https://servicewechat.com/wxa-qbase/report?token=${token.token}&v=${version}`,
    method: 'POST',
    header: {},
    enableHttp2: true,
    dataType: 'json',
    data: JSON.stringify({
      report_info_list: mmdataList
    }),
    success: res => {
      for (var key in res.header) {
        if (key.toLocaleLowerCase() === 'x-wx-system-error' && res.header[key] === '85104') {
          token.invalidate();
        }
      }
    }
  });
  mmdataList = [];
  keepAlive();
}, 30 * 1000);
var wrapTiming = (target, options) => {
  var targetIsFunction = isFunction(target);
  function wrap(...args) {
    if (options.samplePicker && !options.samplePicker.next()) {
      if (targetIsFunction) {
        return target.apply(this, args);
      } else return target;
    }
    var startTime = Date.now();
    var skip = true;
    try {
      var _options$condition;
      if ((_options$condition = options.condition) !== null && _options$condition !== void 0 && _options$condition.emptyKey && options.timing[options.startKey]) {
        if (targetIsFunction) {
          return target.apply(this, args);
        } else return target;
      }
      var promise;
      if (targetIsFunction) {
        var r = target.apply(this, args);
        if (isPromise(r)) {
          promise = r;
        } else {
          skip = false;
          return r;
        }
      } else {
        promise = target;
      }
      promise.then(() => completeReport(startTime)).catch(() => completeReport(startTime));
      return promise;
    } catch (e) {
      skip = false;
      throw e;
    } finally {
      if (!skip) {
        completeReport(startTime);
      }
    }
  }
  function completeReport(startTime) {
    options.timing[options.startKey] = startTime;
    options.timing[options.endKey] = Date.now();
    if (options.autoReport) {
      reportAPISpeed({
        ...options.timing,
        apiName: options.autoReport
      });
    }
  }
  return targetIsFunction ? wrap : wrap();
};
var newSampleGenerator = (base, reportFirstValue) => function* () {
  var rand = () => parseInt(Math.round(Math.random() * 2 * base), 10);
  var val = reportFirstValue ? 0 : rand();
  while (true) {
    if (val > 0) {
      val--;
      yield false;
    } else {
      val = rand();
      yield true;
    }
  }
};
var socketOnMessageSamplePicker = newSampleGenerator(10, true)();
function clampFunnyValue(num) {
  if (!num) return undefined;
  if (isNaN(num)) return undefined;
  if (num > 60000) return 60000;
  if (num < 0) return 0;
  return num;
}
function reportWxRequest(param) {
  if (!param.stats) param.stats = {};
  param.stats.apiEndTime = Date.now();
  var hasProfile = Boolean(param.stats.profile);
  var profile = param.stats.profile || {};
  var currentTs = param.stats.apiEndTime;
  var cpath = param.path || '';
  cpath = cpath.split('?')[0].replace(/\/\d+\//g, '/*/').replace(/\/\d+$/g, '/*');
  reportMMData(30434, 1, replaceCommaInArray([param.stats.callid, profile.redirectStart, hasProfile ? profile.redirectEnd - profile.redirectStart : undefined, profile.fetchStart, profile.domainLookUpStart, hasProfile ? profile.domainLookUpEnd - profile.domainLookUpStart : undefined, profile.connectStart, hasProfile ? profile.connectEnd - profile.connectStart : undefined, profile.SSLconnectionStart, hasProfile ? profile.SSLconnectionEnd - profile.SSLconnectionStart : undefined, profile.requestStart, hasProfile ? profile.requestEnd - profile.requestStart : undefined, profile.responseStart, hasProfile ? profile.responseEnd - profile.responseStart : undefined, profile.rtt, profile.estimate_nettype, clampFunnyValue(profile.httpRttEstimate), clampFunnyValue(profile.transportRttEstimate), clampFunnyValue(profile.downstreamThroughputKbpsEstimate), profile.throughputKbps, profile.peerIP, profile.port, hasProfile ? profile.socketReused ? 1 : 0 : undefined, profile.sendBytesCount, profile.receivedBytedCount, profile.protocol, getSystemInfo().system, cpath, getSystemInfo().platform, param.stats.requestStartTs, 1727594124553, `SDK:request`, hasProfile ? profile.requestStart - param.stats.requestStartTs : undefined, hasProfile ? param.stats.requestSuccessTs - profile.requestEnd : undefined, param.stats.responseProcessEndTs ? currentTs - param.stats.responseProcessEndTs : undefined, param.stats.errMsg, param.stats.errCode]).join(','));
}
function reportCallContainerLike(API_NAME, param) {
  try {
    var _WXConfig$accountInfo, _getLaunchOptions, _WXConfig$accountInfo2, _getDeviceInfo, _getDeviceInfo2;
    if (!param.stats) param.stats = {};
    if (!param.context) param.context = {};
    param.stats.apiEndTime = Date.now();
    reportAPISpeed({
      ...param.context,
      apiEndTime: param.stats.apiEndTime,
      apiName: API_NAME
    });
    var hasProfile = Boolean(param.stats.profile);
    var profile = param.stats.profile || {};
    var serverCost = param.stats.serverEndTs - param.stats.serverStartTs;
    var httpRequestCost = param.stats.httpRequest ? param.stats.httpRequest <= 60000 ? param.stats.httpRequest : 60000 : undefined;
    var currentTs = param.stats.apiEndTime;
    var apiCost = param.context ? currentTs - param.context.apiStartTime : 0;
    if (apiCost > 90000) {
      apiCost = 90000;
    }
    var cpath = param.path || '';
    cpath = cpath.split('?')[0].replace(/\/\d+\//g, '/*/').replace(/\/\d+$/g, '/*');
    reportMMData(22601, 21, replaceCommaInArray([param.stats.callid, param.context.apiStartTime, currentTs, param.stats.serverStartTs, param.stats.serverEndTs, param.stats.requestBodyBytes, param.stats.responseBodyBytes, param.stats.getServiceEndpoint, param.stats.queryDNS, param.stats.compress, param.stats.loadAsmcrypto, param.stats.encrypt, httpRequestCost, param.stats.decrypt, param.stats.uncompress, param.stats.decodePb, param.stats.decodeBody, param.stats.ip, profile.redirectStart, hasProfile ? profile.redirectEnd - profile.redirectStart : undefined, profile.fetchStart, profile.domainLookUpStart, hasProfile ? profile.domainLookUpEnd - profile.domainLookUpStart : undefined, profile.connectStart, hasProfile ? profile.connectEnd - profile.connectStart : undefined, profile.SSLconnectionStart, hasProfile ? profile.SSLconnectionEnd - profile.SSLconnectionStart : undefined, profile.requestStart, hasProfile ? profile.requestEnd - profile.requestStart : undefined, profile.responseStart, hasProfile ? profile.responseEnd - profile.responseStart : undefined, profile.rtt, profile.estimate_nettype, clampFunnyValue(profile.httpRttEstimate), clampFunnyValue(profile.transportRttEstimate), clampFunnyValue(profile.downstreamThroughputKbpsEstimate), profile.throughputKbps, profile.peerIP, profile.port, hasProfile ? profile.socketReused ? 1 : 0 : undefined, profile.sendBytesCount, profile.receivedBytedCount, profile.protocol, getSystemInfo().system, apiCost, serverCost > 0 ? serverCost : 0, httpRequestCost ? apiCost - httpRequestCost : undefined, cpath, getSystemInfo().platform, param.stats.requestStartTs, 1727594124553, param.stats.ecdnId, param.stats.ecdnEdgeTiming, param.stats.domain, param.stats.stringToBuffer, param.stats.encodePb, param.stats.tsBeforeCallContainerImpl, param.stats.tsCallContainerImplStart, param.stats.decodeJson, `SDK:${param.stats.protocol}`, hasProfile ? profile.requestStart - param.stats.requestStartTs : undefined, hasProfile ? param.stats.requestSuccessTs - profile.requestEnd : undefined, param.stats.responseProcessEndTs ? currentTs - param.stats.responseProcessEndTs : undefined, param.stats.upstreamCost, param.stats.meshStartTs, param.stats.meshEndTs, param.stats.errMsg, param.stats.errCode, (_WXConfig$accountInfo = wxconfig.accountInfo) === null || _WXConfig$accountInfo === void 0 ? void 0 : _WXConfig$accountInfo.appVersion, (_getLaunchOptions = getLaunchOptions()) === null || _getLaunchOptions === void 0 ? void 0 : _getLaunchOptions.scene, (_WXConfig$accountInfo2 = wxconfig.accountInfo) === null || _WXConfig$accountInfo2 === void 0 ? void 0 : _WXConfig$accountInfo2.appId, param.stats.statusCode, (_getDeviceInfo = getDeviceInfo()) === null || _getDeviceInfo === void 0 ? void 0 : _getDeviceInfo.model, param.stats.ret, _networkType, (_getDeviceInfo2 = getDeviceInfo()) === null || _getDeviceInfo2 === void 0 ? void 0 : _getDeviceInfo2.brand, getRoutePage()]).join(','));
  } catch (e) {}
}
;// CONCATENATED MODULE: ./src/utils/msg.ts
function apiSuccessMsg(apiName) {
  return `${apiName}:ok`;
}
function apiCancelMsg(apiName, msg) {
  return `${apiName}:cancel ${msg}`;
}
function apiFailMsg(apiName, msg) {
  return `${apiName}:fail ${msg}`;
}
;// CONCATENATED MODULE: ./src/utils/serializer.ts



function serialize(data, replaceMap) {
  return JSON.stringify(data, (key, data) => {
    if (replaceMap && replaceMap.has(data)) {
      return replaceMap.get(data);
    }
    var type = type_getType(data);
    switch (type) {
      case 'arraybuffer':
        {
          var uint8array = new Uint8Array(data);
          return {
            type: 'Buffer',
            data: [...uint8array]
          };
        }
    }
    return data;
  });
}
function stringifyReplacer(key, data) {
  var type = getType(data);
  switch (type) {
    case 'arraybuffer':
      {
        var uint8array = new Uint8Array(data);
        return {
          type: 'Buffer',
          data: [...uint8array]
        };
      }
  }
  return data;
}
function toJSONSerializable(data, name = 'data') {
  if (data === null || data === undefined) {
    return undefined;
  }
  if (data === true || data === false) {
    return data;
  }
  var type = getType(data);
  switch (type) {
    case 'number':
      {
        if (isFinite(data)) {
          return data;
        }
        break;
      }
    case 'string':
      {
        return data;
      }
    case 'array':
      {
        return data.map((item, i) => toJSONSerializable(item, `${name}[${i}]`));
      }
    case 'object':
      {
        var serializableObject = {};
        for (var key in data) {
          if (data.hasOwnProperty(key)) {
            serializableObject[key] = toJSONSerializable(data[key], `${name}.${key}`);
          }
        }
        return serializableObject;
      }
    case 'arraybuffer':
      {
        var uint8array = new Uint8Array(data);
        return {
          type: 'Buffer',
          data: [...uint8array]
        };
      }
  }
  if (typeof data === 'function') {
    return data;
  }
  throwJSONSerializableError(name);
}
function deserialize(x) {
  var data = JSON.parse(x);
  return deserializeData(data);
}
function deserializeData(data) {
  switch (type_getType(data)) {
    case 'object':
      {
        return deserializeObject(data);
      }
    case 'array':
      {
        return data.map(deserializeData);
      }
    default:
      {
        return data;
      }
  }
}
function deserializeObject(data) {
  var ret = data;
  var retDecoded = deserializeSpecialDataType(ret);
  if (ret !== retDecoded) {
    return retDecoded;
  }
  for (var key in ret) {
    var value = ret[key];
    var valueType = type_getType(value);
    switch (valueType) {
      case 'object':
        {
          var decoded = deserializeSpecialDataType(value);
          if (decoded !== value) {
            ret[key] = decoded;
          } else {
            ret[key] = deserializeObject(ret[key]);
          }
          break;
        }
      case 'array':
        {
          var _decoded = deserializeData(value);
          if (_decoded !== value) {
            ret[key] = _decoded;
          }
          break;
        }
      default:
        {
          continue;
        }
    }
  }
  return ret;
}
function deserializeSpecialDataType(object) {
  for (var key in object) {
    switch (key) {
      case 'type':
        {
          switch (object.type) {
            case 'Buffer':
              {
                if (isArray(object.data) && isNumber(object.data[0])) {
                  try {
                    var array = new Uint8Array(object.data);
                    return array.buffer;
                  } catch (e) {
                    return object;
                  }
                }
              }
          }
          break;
        }
    }
  }
  return object;
}
function throwJSONSerializableError(name) {
  throw new CloudSDKError({
    errCode: ERR_CODE.SDK_API_PARAMETER_TYPE_ERROR,
    errMsg: `${name} is not JSON-serializable`
  });
}
;// CONCATENATED MODULE: ./src/services/functions/api/callFunction/sync.ts




function getAPI(context) {
  return /*#__PURE__*/function () {
    var _callFunction_ = asyncToGenerator_default()(function* (param) {
      var reqData = {
        function_name: param.name,
        data: serialize(param.data),
        cloudid_list: []
      };
      var serializedReqData = serialize(reqData);
      var res = yield context.request({
        apiName: 'tcbapi_callfunction',
        serviceName: context.name,
        serializedReqData,
        env: param.config && param.config.env || context.env
      });
      var resData = res.data;
      var result = resData && resData.data;
      if (result) {
        try {
          result = JSON.parse(result);
        } catch (err) {}
      }
      return {
        errMsg: apiSuccessMsg(API_NAME),
        result
      };
    });
    function callFunction_(_x) {
      return _callFunction_.apply(this, arguments);
    }
    return callFunction_;
  }();
}
;// CONCATENATED MODULE: ./src/utils/symbol.ts
var SYMBOL_CLOUD_ID = Symbol.for('CLOUD_ID');
var symbol_SYMBOL_CDN = Symbol('CDN');
;// CONCATENATED MODULE: ./src/services/functions/utils/extract.ts


function extractCloudID(data) {
  var list = [];
  for (var key in data) {
    if (isObject(data[key]) && data[key]._internalType === SYMBOL_CLOUD_ID) {
      list.push({
        key,
        cloudID: data[key].cloudID
      });
    }
  }
  return list;
}
;// CONCATENATED MODULE: ./src/services/functions/api/callFunction/slow.ts










function slow_getAPI(context) {
  return /*#__PURE__*/function () {
    var _slowCallFunction_ = asyncToGenerator_default()(function* (param) {
      var callData = {
        ...param.data
      };
      var cloudIDList = extractCloudID(callData).map(item => ({
        key_name: item.key,
        cloud_id: item.cloudID
      }));
      if (cloudIDList.length) {
        for (var item of cloudIDList) {
          delete callData[item.key_name];
        }
      }
      var cdnMap = yield param.cdnMapPromise;
      var strData = serialize(callData, cdnMap);
      assertStringLength({
        input: strData,
        max: context.appConfig.maxReqDataSize,
        name: 'callFunction data',
        maxWording: `${context.appConfig.maxReqDataSize / 1024} KB`
      });
      var reqData = {
        function_name: param.name,
        data: strData,
        cloudid_list: cloudIDList
      };
      var serializedReqData = serialize(reqData);
      param.context.tunnelStartTime = +new Date();
      var res = yield context.request({
        ...param.config,
        apiName: 'tcbapi_slowcallfunction',
        serviceName: context.name,
        serializedReqData,
        env: param.config && param.config.env || context.env
      });
      param.context.tunnelEndTime = +new Date();
      var resData = res.data;
      if (!resData) {
        throw returnAsFinalCloudSDKError({
          errCode: error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_CALL_RESULT,
          errMsg: error_config_ERR_CODE[error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_CALL_RESULT]
        }, API_NAME);
      }
      if (!resData.event_id) {}
      if (!resData.poll_url) {
        throw returnAsFinalCloudSDKError({
          errCode: error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_POLL_URL,
          errMsg: error_config_ERR_CODE[error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_POLL_URL]
        }, API_NAME);
      }
      if (resData.poll_url.indexOf('?') > -1) {
        resData.poll_url += '&devtools_ignore=true&skip_domain_check=true';
      } else {
        resData.poll_url += '?devtools_ignore=true&skip_domain_check=true';
      }
      param.context.pollStartTime = +new Date();
      var {
        result,
        requestID
      } = yield waitUntilResult(resData.poll_url);
      param.context.pollEndTime = +new Date();
      return {
        errMsg: apiSuccessMsg(API_NAME),
        result,
        requestID
      };
      function waitUntilResult(_x2) {
        return _waitUntilResult.apply(this, arguments);
      }
      function _waitUntilResult() {
        _waitUntilResult = asyncToGenerator_default()(function* (poll_url) {
          return new Promise((resolve, reject) => {
            poll(poll_url, context.appConfig.maxPollRetry || 50, resolve, reject);
          });
        });
        return _waitUntilResult.apply(this, arguments);
      }
      function poll(_x3, _x4, _x5, _x6) {
        return _poll.apply(this, arguments);
      }
      function _poll() {
        _poll = asyncToGenerator_default()(function* (poll_url, tryCount, resolve, reject) {
          var __appServiceSDK__ = appserviceSdk_getSDK(context.identifiers);
          if (!limiter.allowRequest()) {
            reject(toSDKError({
              errCode: error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_SERVER_REQUEST_COUNT,
              errMsg: `error: exceed max client request count, avoid infinite loop in your code`
            }, API_NAME));
            return;
          }
          __appServiceSDK__._requestSkipCheckDomain({
            url: poll_url,
            success: res => {
              try {
                if (res.statusCode === 200) {
                  var data = res.data;
                  if (!data) {
                    return reject(returnAsFinalCloudSDKError({
                      errCode: error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_POLL_RESULT_JSON,
                      errMsg: error_config_ERR_CODE[error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_POLL_RESULT_JSON]
                    }, API_NAME));
                  }
                  if (data.base_resp && data.base_resp.ret === 0) {
                    if (data.status === 0) {
                      if (tryCount >= 0) {
                        poll(poll_url, tryCount - 1, resolve, reject);
                      } else {
                        return reject(returnAsFinalCloudSDKError({
                          errCode: error_config_ERR_CODE.SDK_FUNCTIONS_EXCEED_MAX_POLL_RETRY,
                          errMsg: error_config_ERR_CODE[error_config_ERR_CODE.SDK_FUNCTIONS_EXCEED_MAX_POLL_RETRY]
                        }, API_NAME));
                      }
                    } else if (data.status === 1) {
                      if (data.service_errcode !== 0) {
                        var error = returnAsFinalCloudSDKError({
                          errCode: error_config_ERR_CODE.SDK_FUNCTIONS_CLOUD_FUNCTION_EXECUTION_ERROR,
                          errMsg: `requestID ${data.func_req_id}, cloud function service error code ${data.service_errcode || 'unknown'}, error message ${data.service_errmsg || 'unknown'}`
                        }, API_NAME);
                        error.requestID = data.func_req_id;
                        return reject(error);
                      } else {
                        var _result = data.content;
                        try {
                          _result = deserialize(_result);
                        } catch (e) {
                          try {
                            _result = JSON.parse(_result);
                          } catch (e) {}
                        }
                        return resolve({
                          result: _result,
                          requestID: data.func_req_id
                        });
                      }
                    } else {
                      return reject(returnAsFinalCloudSDKError({
                        errCode: error_config_ERR_CODE.SDK_FUNCTIONS_POLL_RESULT_EXPIRED,
                        errMsg: 'timeout for result fetching'
                      }, API_NAME));
                    }
                  } else {
                    if (!data.base_resp) {
                      return reject(returnAsFinalCloudSDKError({
                        errCode: error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_POLL_RESULT_BASE_RESP,
                        errMsg: error_config_ERR_CODE[error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_POLL_RESULT_BASE_RESP]
                      }, API_NAME));
                    } else if (data.base_resp.ret !== 0) {
                      return reject(returnAsFinalCloudSDKError({
                        errCode: error_config_ERR_CODE.SDK_FUNCTIONS_POLL_RESULT_BASE_RESP_RET_ABNORMAL,
                        errMsg: `polling base_resp.ret ${data.base_resp.ret}`
                      }, API_NAME));
                    }
                  }
                } else {
                  return reject(returnAsFinalCloudSDKError({
                    errCode: error_config_ERR_CODE.SDK_FUNCTIONS_POLL_RESULT_STATUS_CODE_ERROR,
                    errMsg: `polling status code ${res.statusCode}`
                  }, API_NAME));
                }
              } catch (err) {
                reject(returnAsFinalCloudSDKError({
                  errCode: error_config_ERR_CODE.SDK_FUNCTIONS_POLL_ERROR,
                  errMsg: `polling catch error: ${err}`
                }, API_NAME));
              }
            },
            fail: err => {
              reject(returnAsFinalCloudSDKError(err, API_NAME));
            }
          });
        });
        return _poll.apply(this, arguments);
      }
    });
    function slowCallFunction_(_x) {
      return _slowCallFunction_.apply(this, arguments);
    }
    return slowCallFunction_;
  }();
}
;// CONCATENATED MODULE: ./src/services/functions/api/callFunction/slow.v2.ts










var MAX_NORMAL_POLL_RETRY = 20;
var MAX_SYSTEM_ERROR_RETRY = 2;
var MAX_TIMEOUT_RETRY = 2;
var DEFAULT_CLIENT_ONE_TIME_POLL_TIMEOUT = 20 * 1000;
var newTraceEntry = msg => {
  var d = new Date();
  return `${d.getHours()}:${d.getMinutes()}:${d.getSeconds()} ${msg}`;
};
var traceStr = trace => trace.join('->');
function slow_v2_getAPI(context) {
  return /*#__PURE__*/function () {
    var _slowCallFunctionV = asyncToGenerator_default()(function* (param) {
      var callData = {
        ...param.data
      };
      var cloudIDList = extractCloudID(callData).map(item => ({
        key_name: item.key,
        cloud_id: item.cloudID
      }));
      if (cloudIDList.length) {
        for (var item of cloudIDList) {
          delete callData[item.key_name];
        }
      }
      var cdnMap = yield param.cdnMapPromise;
      var strData = serialize(callData, cdnMap);
      assertStringLength({
        input: strData,
        max: context.appConfig.maxReqDataSize,
        name: 'callFunction data',
        maxWording: `${context.appConfig.maxReqDataSize / 1024} KB`
      });
      var callID = `${+new Date()}-${Math.random()}`;
      param.context.tunnelStartTime = +new Date();
      var {
        result,
        requestID
      } = yield callAndWaitResult(param, strData, cloudIDList, callID);
      param.context.tunnelEndTime = +new Date();
      return {
        errMsg: apiSuccessMsg(API_NAME),
        result,
        requestID
      };
      function callAndWaitResult(_x2, _x3, _x4, _x5) {
        return _callAndWaitResult.apply(this, arguments);
      }
      function _callAndWaitResult() {
        _callAndWaitResult = asyncToGenerator_default()(function* (param, data, cloudIDList, callID) {
          return new Promise((_resolve, _reject) => {
            var trace = [newTraceEntry(`start`)];
            var {
              resolve,
              reject
            } = monitorAppVisiblity(trace, _resolve, _reject);
            poll({
              param,
              functionName: param.name,
              data,
              cloudIDList,
              callID,
              action: SlowCallAction.CALL,
              scene: SlowCallScene.INITIATE_CALL,
              tryCount: context.appConfig.maxPollRetry || MAX_NORMAL_POLL_RETRY,
              systemErrorRetry: MAX_SYSTEM_ERROR_RETRY,
              timeoutErrorRetry: MAX_TIMEOUT_RETRY,
              trace,
              resolve,
              reject
            });
          });
        });
        return _callAndWaitResult.apply(this, arguments);
      }
      function poll(_x6) {
        return _poll.apply(this, arguments);
      }
      function _poll() {
        _poll = asyncToGenerator_default()(function* (options) {
          var {
            functionName,
            data,
            callID,
            action,
            scene,
            tryCount,
            trace,
            systemErrorRetry,
            timeoutErrorRetry,
            resolve,
            reject
          } = options;
          var localDebugNoTimeout = action === SlowCallAction.CALL && isDevTools() ? param.localDebugNoTimeout : undefined;
          var reqData = {
            function_name: functionName,
            data: action === SlowCallAction.CALL ? data : undefined,
            action,
            scene,
            call_id: callID,
            cloudid_list: action === SlowCallAction.CALL ? cloudIDList : [],
            local_debug_no_timeout: localDebugNoTimeout
          };
          var serializedReqData = serialize(reqData);
          var hasTunnelTimeout = false;
          var timeoutCleared = false;
          var clearTunnelTimeout = () => {
            clearTimeout(tunnelTimeoutId);
            timeoutCleared = true;
          };
          var startTime = +new Date();
          var tunnelTimeoutId = localDebugNoTimeout ? undefined : setTimeout(/*#__PURE__*/asyncToGenerator_default()(function* () {
            var timeout = context.appConfig.clientPollTimeout || DEFAULT_CLIENT_ONE_TIME_POLL_TIMEOUT;
            if (+new Date() - startTime > timeout) {
              yield sleep();
              if (timeoutCleared) {
                return;
              }
            }
            if (!isDevTools() && +new Date() - startTime > context.appConfig.maxStartRetryGap) {
              trace.push(newTraceEntry(`timeout, exceed max retry gap`));
              return reject(toSDKError({
                errCode: error_config_ERR_CODE.SDK_FUNCTIONS_POLL_RESULT_EXPIRED,
                errMsg: `timeout for retry, cannot retry fetching the result anymore (callId: ${callID}) (trace: ${traceStr(trace)})`
              }, API_NAME));
            }
            hasTunnelTimeout = true;
            if (options.timeoutErrorRetry > 0) {
              trace.push(newTraceEntry(`timeout, retry`));
              poll({
                ...options,
                scene: SlowCallScene.TIMEOUT_RETRY,
                tryCount: tryCount - 1,
                timeoutErrorRetry: timeoutErrorRetry - 1
              });
            } else {
              trace.push(newTraceEntry(`timeout, abort`));
              reject(toSDKError({
                errCode: error_config_ERR_CODE.SDK_FUNCTIONS_EXCEED_MAX_TIMEOUT_POLL_RETRY,
                errMsg: `(callId: ${callID}) (trace: ${traceStr(trace)})`
              }, API_NAME));
            }
          }), context.appConfig.clientPollTimeout || DEFAULT_CLIENT_ONE_TIME_POLL_TIMEOUT);
          var handleTunnelStats = res => {
            var _res$channelType;
            var data = res.data;
            if (data && data.baseresponse && data.baseresponse.stat) {
              if (data.baseresponse.stat.qbase_cost_time) {
                param.context.tunnelTimeNoCSNetCost += data.baseresponse.stat.qbase_cost_time;
              }
              if (data.baseresponse.stat.func_exec_cost_time) {
                param.context.funcExecTime = data.baseresponse.stat.func_exec_cost_time;
              }
            }
            param.context.channelType = (_res$channelType = res.channelType) !== null && _res$channelType !== void 0 ? _res$channelType : 0;
            if (res.profile) {
              _wxConsole === null || _wxConsole === void 0 ? void 0 : _wxConsole.log('callFunction profile', res.profile);
            }
          };
          context.request({
            ...param.config,
            apiName: 'tcbapi_slowcallfunction_v2',
            serviceName: context.name,
            serializedReqData,
            env: param.config && param.config.env || context.env,
            stdpriv: true
          }).then(onTunnelResult).catch(err => {
            if (hasTunnelTimeout) return;
            clearTunnelTimeout();
            if (err && err.operateWXDataFail && systemErrorRetry > 0) {
              trace.push(newTraceEntry(`system error (${err}), retry`));
              poll({
                ...options,
                scene: SlowCallScene.SYSTEM_ERROR_RETRY,
                tryCount: tryCount - 1,
                systemErrorRetry: systemErrorRetry - 1
              });
            } else {
              trace.push(newTraceEntry(`system error (${err}), abort`));
              reject(toSDKError(`${err} (callId: ${callID}) (trace: ${traceStr(trace)})`, API_NAME));
            }
          });
          function onTunnelResult(res) {
            try {
              if (hasTunnelTimeout) return;
              clearTunnelTimeout();
              handleTunnelStats(res);
              var _data = res.data;
              if (!_data) {
                trace.push(newTraceEntry(`empty resp`));
                return reject(toSDKError({
                  errCode: error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_CALL_RESULT
                }, API_NAME));
              }
              if (_data.baseresponse && _data.baseresponse.errcode === 0) {
                if (_data.status === 0) {
                  if (tryCount >= 0) {
                    trace.push(newTraceEntry(`normal poll`));
                    poll({
                      ...options,
                      action: SlowCallAction.POLL,
                      scene: SlowCallScene.NORMAL_POLL_RETRY,
                      tryCount: tryCount - 1
                    });
                  } else {
                    trace.push(newTraceEntry(`too many polls, abort`));
                    return reject(toSDKError({
                      errCode: error_config_ERR_CODE.SDK_FUNCTIONS_EXCEED_MAX_POLL_RETRY,
                      errMsg: `(callId: ${callID}) (trace: ${traceStr(trace)})`
                    }, API_NAME));
                  }
                } else if (_data.status === 1) {
                  if (_data.service_errcode !== 0) {
                    if (_data.service_errcode === error_config_ERR_CODE.TCB_FUNCTIONS_EXEC_FAIL) {
                      var fnMsg = _data.service_errmsg || '';
                      try {
                        var lines = fnMsg.split('\n');
                        var errorLines = [];
                        for (var i = 0; i < lines.length; i++) {
                          if (lines[i].startsWith('Error: ')) {
                            errorLines.push([lines[i], i]);
                          }
                        }
                        if (errorLines.length % 2 === 1) {
                          var lineNo = errorLines[Math.floor(errorLines.length / 2)][1];
                          fnMsg = lines.slice(lineNo).join('\n');
                        }
                      } catch (e) {}
                      var error = toSDKError({
                        errCode: error_config_ERR_CODE.SDK_FUNCTIONS_CLOUD_FUNCTION_EXECUTION_ERROR,
                        errMsg: `云函数执行错误\n云端堆栈信息(error stack)(${_data.func_request_id ? `requestId ${_data.func_request_id}, ` : ''}callid ${callID}):\n${fnMsg}`
                      }, API_NAME);
                      error.stack = `Error: ${error.message}`;
                      error.requestID = _data.func_request_id;
                      return reject(error);
                    } else {
                      var _error = toSDKError({
                        errCode: error_config_ERR_CODE.SDK_FUNCTIONS_CLOUD_FUNCTION_EXECUTION_ERROR,
                        errMsg: `\n云函数调用失败(${_data.func_request_id ? `requestId ${_data.func_request_id}, ` : ''}callid ${callID}):\n${_data.service_errcode} ${_data.service_errmsg}`
                      }, API_NAME);
                      _error.stack = `Error: ${_error.message}`;
                      _error.requestID = _data.func_request_id;
                      return reject(_error);
                    }
                  } else {
                    var _result = _data.data;
                    try {
                      _result = deserialize(_result);
                    } catch (e) {
                      try {
                        _result = JSON.parse(_result);
                      } catch (e) {}
                    }
                    return resolve({
                      result: _result,
                      requestID: _data.func_request_id
                    });
                  }
                } else {
                  trace.push(newTraceEntry(`poll result expired`));
                  return reject(toSDKError({
                    errCode: error_config_ERR_CODE.SDK_FUNCTIONS_POLL_RESULT_EXPIRED,
                    errMsg: `timeout for result fetching, result cannot be fetched anymore (callId: ${callID}) (trace: ${traceStr(trace)})`
                  }, API_NAME));
                }
              } else {
                if (!_data.baseresponse) {
                  return reject(toSDKError({
                    errCode: error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_POLL_RESULT_BASE_RESP
                  }, API_NAME));
                } else if (_data.baseresponse.errcode !== 0) {
                  return reject(toSDKError({
                    errCode: error_config_ERR_CODE.SDK_FUNCTIONS_POLL_RESULT_BASE_RESP_RET_ABNORMAL,
                    errMsg: `polling base_resp.errcode ${_data.baseresponse.errcode} errmsg ${_data.baseresponse.errmsg} (callId: ${callID})`
                  }, API_NAME));
                } else {
                  return reject(toSDKError({
                    errCode: error_config_ERR_CODE.SDK_FUNCTIONS_EMPTY_POLL_RESULT_BASE_RESP,
                    errMsg: `polling base_resp ${JSON.stringify(_data.baseresponse)} (callId: ${callID})`
                  }, API_NAME));
                }
              }
            } catch (err) {
              reject(toSDKError({
                errCode: error_config_ERR_CODE.SDK_FUNCTIONS_POLL_ERROR,
                errMsg: `polling catch error: ${err} (callId: ${callID})`
              }, API_NAME));
            }
          }
        });
        return _poll.apply(this, arguments);
      }
      function monitorAppVisiblity(trace, resolve, reject) {
        var listener = event => {
          trace.push(newTraceEntry(`app ${event}`));
        };
        onAppVisibilityChange(listener);
        var _resolve = v => {
          offAppVisibilityChange(listener);
          resolve(v);
        };
        var _reject = v => {
          offAppVisibilityChange(listener);
          reject(v);
        };
        return {
          resolve: _resolve,
          reject: _reject
        };
      }
    });
    function slowCallFunctionV2(_x) {
      return _slowCallFunctionV.apply(this, arguments);
    }
    return slowCallFunctionV2;
  }();
}
;// CONCATENATED MODULE: ./src/services/functions/api/callFunction/v3.ts






function v3_getAPI(context) {
  return /*#__PURE__*/function () {
    var _callFunction_ = asyncToGenerator_default()(function* (param) {
      var _param$config;
      var reqData = {
        function_name: param.name,
        data: serialize(param.data),
        cloudid_list: []
      };
      var serializedReqData = serialize(reqData);
      var endpoint = yield context.serviceEndpoint.getEndpoint('container');
      var key = new Uint8Array(__appServiceSDK__.wx.base64ToArrayBuffer(endpoint.key));
      var outerRequestHeader = {
        'X-WX-EV': 3,
        'Content-Type': 'application/octet-stream'
      };
      var req = dist.V3.encodeRequest(key, {
        'X-WX-CALLID': `${+new Date()}-${Math.random()}`,
        'X-WX-CLOUDFUNCTION-NAME': param.name,
        'X-WX-CLOUDFUNCTION-ENV': ((_param$config = param.config) === null || _param$config === void 0 ? void 0 : _param$config.env) || context.env || ''
      }, 'POST', serializedReqData);
      var res = yield new Promise((res, rej) => appserviceSdk_getSDK()._requestSkipCheckDomain({
        url: endpoint.cloudServiceUrl,
        method: 'POST',
        header: outerRequestHeader,
        data: req.data.buffer,
        dataType: 'arraybuffer',
        responseType: 'arraybuffer',
        enableHttp2: true,
        success: res,
        fail: rej
      }));
      var decoded = dist.V3.decodeResponse(key, new Uint8Array(res.data));
      var result = decoded.body;
      if (result) {
        try {
          result = JSON.parse(result);
        } catch (err) {}
      }
      return {
        errMsg: apiSuccessMsg(API_NAME),
        result
      };
    });
    function callFunction_(_x) {
      return _callFunction_.apply(this, arguments);
    }
    return callFunction_;
  }();
}
;// CONCATENATED MODULE: ./src/utils/cdn.ts




function collect(data) {
  var cdnMap = new WeakMap();
  var cdnTasks = [];
  if (data) {
    JSON.stringify(data, (key, value) => {
      if (value && value._internalType === symbol_SYMBOL_CDN) {
        cdnTasks.push(new Promise((resolve, reject) => {
          var param = {
            appType: 301,
            fileType: 20303,
            fileKey: `file_${Math.random()}`
          };
          var cdn = value;
          switch (type_getType(cdn.target)) {
            case 'object':
              {
                if (!cdn.target.filePath) {
                  throw new Error(`filePath must be provided`);
                }
                param.filePath = cdn.target.filePath;
                break;
              }
            default:
              {
                param.fileData = cdn.target;
                break;
              }
          }
          resolve(uploadToCommonCDN(param).then(uploadResult => {
            cdnMap.set(value, uploadResult.fileUrl);
          }));
        }));
        return undefined;
      } else return value;
    });
    if (cdnTasks.length) {
      return Promise.all(cdnTasks).then(() => cdnMap);
    }
  }
  return undefined;
}
function populateAndSerialize(_x) {
  return _populateAndSerialize.apply(this, arguments);
}
function _populateAndSerialize() {
  _populateAndSerialize = _asyncToGenerator(function* (data) {
    if (data) {
      var cdnMap = yield collect(data);
      var serializedData = JSON.stringify(data, (key, value) => {
        if (value && value.symbol === SYMBOL_CDN && cdnMap !== null && cdnMap !== void 0 && cdnMap.has(value)) {
          return cdnMap.get(value);
        } else return value;
      });
      return serializedData;
    }
    return JSON.stringify(data);
  });
  return _populateAndSerialize.apply(this, arguments);
}
function uploadToCommonCDN(options) {
  return new Promise((resolve, reject) => {
    var opt = {
      ...options,
      appType: options.appType || 301,
      fileType: options.fileType || 20303,
      fileKey: options.fileKey || `file_${Math.random()}`
    };
    appserviceSdk_getSDK().uploadToCommonCDN({
      ...opt,
      success: resolve,
      fail: reject
    });
  });
}
;// CONCATENATED MODULE: ./src/externals/globals/devtools.ts



var echo = x => x;
var commonResultGetter = x => ({
  ...x,
  errMsg: undefined
});
var devtools_sleep = (ms = 0) => new Promise(res => setTimeout(res, ms));
var devtoolsNetworkLog = options => {
  try {
    if (isDevTools() && typeof __global !== 'undefined' && __global.networkLog) {
      __global.networkLog({
        ...options,
        domain: 'cloud',
        method: 'POST',
        realMethod: options.method,
        timestampMs: options.timestampMs || +new Date(),
        callFramesIgnoreLength: options.hasOwnProperty('callFramesIgnoreLength') ? options.callFramesIgnoreLength : 1
      });
    }
  } catch (err) {}
};
var autoDevtoolsNetworkLog = (promise, getOptions) => {
  try {
    if (isDevTools() && typeof __global !== 'undefined' && __global.networkLog) {
      var options = getOptions();
      var reqId = `${Math.random()}-${+new Date()}`;
      var _console = options.console || false;
      var resultGetter = options.resultGetter || commonResultGetter;
      devtoolsNetworkLog({
        reqId,
        type: 'requestWillBeSent',
        url: options.url,
        headers: options.headers || {},
        body: options.reqBody,
        console: _console,
        callFramesIgnoreLength: 2,
        timestampMs: options.timestampMs,
        method: options.method
      });
      promise.then(/*#__PURE__*/function () {
        var _ref = asyncToGenerator_default()(function* (res) {
          try {
            var body = JSON.stringify(resultGetter(res), null, 2);
            yield devtools_sleep();
            devtoolsNetworkLog({
              reqId,
              type: 'loadingFinished',
              body,
              console: _console,
              callFramesIgnoreLength: 2,
              timestampMs: Date.now()
            });
          } catch (err) {}
        });
        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }()).catch(err => {
        try {
          devtoolsNetworkLog({
            reqId,
            type: 'loadingFailed',
            errorCode: err && err.errCode || -1,
            errorMsg: isObject(err) ? err.errMsg || JSON.stringify(err) : err.toString(),
            console: _console,
            callFramesIgnoreLength: 2,
            timestampMs: Date.now()
          });
        } catch (err) {}
      });
    }
  } catch (err) {
    if (false) {}
  }
};
;// CONCATENATED MODULE: ./src/services/functions/api/callFunction.ts















var SlowCallAction = /*#__PURE__*/function (SlowCallAction) {
  SlowCallAction[SlowCallAction["CALL"] = 1] = "CALL";
  SlowCallAction[SlowCallAction["POLL"] = 2] = "POLL";
  return SlowCallAction;
}({});
var SlowCallScene = /*#__PURE__*/function (SlowCallScene) {
  SlowCallScene[SlowCallScene["INITIATE_CALL"] = 1] = "INITIATE_CALL";
  SlowCallScene[SlowCallScene["NORMAL_POLL_RETRY"] = 2] = "NORMAL_POLL_RETRY";
  SlowCallScene[SlowCallScene["SYSTEM_ERROR_RETRY"] = 3] = "SYSTEM_ERROR_RETRY";
  SlowCallScene[SlowCallScene["TIMEOUT_RETRY"] = 4] = "TIMEOUT_RETRY";
  return SlowCallScene;
}({});
var ResultStatus = /*#__PURE__*/(/* unused pure expression or super */ null && (function (ResultStatus) {
  ResultStatus[ResultStatus["PENDING"] = 0] = "PENDING";
  ResultStatus[ResultStatus["DONE"] = 1] = "DONE";
  ResultStatus[ResultStatus["TIMEOUT"] = 2] = "TIMEOUT";
  return ResultStatus;
}({})));
var API_NAME = 'cloud.callFunction';
var API_NAME_V2 = 'cloud.callFunction_real_v2';
function getCallFunctionAPI(context) {
  var slowCallFunction;
  var slowCallFunctionV2;
  var syncCallFunction;
  var callFunctionV3;
  function _getSlowCallFunction() {
    if (!slowCallFunction) {
      slowCallFunction = slow_getAPI(context);
    }
    return slowCallFunction;
  }
  function _getSlowCallFunctionV2() {
    if (!slowCallFunctionV2) {
      slowCallFunctionV2 = slow_v2_getAPI(context);
    }
    return slowCallFunctionV2;
  }
  function _getSyncCallFunction() {
    if (!syncCallFunction) {
      syncCallFunction = getAPI(context);
    }
    return syncCallFunction;
  }
  function _getCallFunctionV3() {
    if (!callFunctionV3) {
      callFunctionV3 = v3_getAPI(context);
    }
    return callFunctionV3;
  }
  return function callFunction(param) {
    var apiStartTime = +new Date();
    assertType(param, 'object');
    var _param = shallowClone(param);
    if (!_param.data) {
      _param.data = {};
    }
    _param.context = {
      tunnelTimeNoCSNetCost: 0,
      funcName: param.name,
      apiStartTime,
      warmStartTime: getWarmStartTs()
    };
    if (hasAPICallback(_param)) {
      return callFunctionCallbackStyle(_param);
    } else {
      return callFunctionPromiseStyle(_param);
    }
  };
  function checkParam(param) {
    assertType(param, {
      name: 'string'
    });
    if (param.data) {
      assertType(param.data, 'object');
    }
    if (param.config) {
      if (param.config.env) {
        assertType(param.config.env, 'string');
      }
    }
  }
  function callFunctionCallbackStyle(param) {
    wrapParamCallbacksWithTryCatch({
      apiName: API_NAME,
      param
    });
    callFunctionPromiseStyle(param).then(res => {
      invokeSuccessCompleteCallbacks(API_NAME, param, res);
    }).catch(err => {
      invokeFailCompleteCallbacks(API_NAME, param, err);
    });
  }
  function callFunctionPromiseStyle(_x) {
    return _callFunctionPromiseStyle.apply(this, arguments);
  }
  function _callFunctionPromiseStyle() {
    _callFunctionPromiseStyle = asyncToGenerator_default()(function* (param) {
      try {
        checkParam(param);
        if (true) {
          param.cdnMapPromise = collect(param.data);
          var promise;
          if (context.runtime.platform === 'sdk' && context.plugins.length) {
            promise = _getCallFunctionV3()(param);
          } else if (useCallFunctionV1()) {
            promise = _getSlowCallFunction()(param);
          } else {
            promise = _getSlowCallFunctionV2()(param);
          }
          if (isDevTools()) {
            var timestampMs = Date.now();
            autoDevtoolsNetworkLog(promise, () => {
              var _param$config;
              return {
                url: `wx.cloud.callFunction.${param.name}`,
                headers: {
                  Env: context.isInstance ? context.env : ((_param$config = param.config) === null || _param$config === void 0 ? void 0 : _param$config.env) || context.env
                },
                reqBody: serialize(param.data),
                timestampMs,
                console: context.debug
              };
            });
          }
          var result = yield promise;
          return result;
        } else { var _result; }
      } catch (err) {
        throw returnAsFinalCloudSDKError(err, API_NAME);
      } finally {
        reportAPISpeed({
          ...param.context,
          apiEndTime: +new Date(),
          apiName: useCallFunctionV1() ? API_NAME : API_NAME_V2
        });
      }
      function useCallFunctionV1() {
        return param.version === 1;
      }
    });
    return _callFunctionPromiseStyle.apply(this, arguments);
  }
}
;// CONCATENATED MODULE: ./src/services/functions/api/api.ts

function getAPIs(context) {
  return {
    callFunction: getCallFunctionAPI(context)
  };
}
;// CONCATENATED MODULE: ./src/services/functions/index.ts

var FUNCTIONS_SERVICE_NAME = 'functions';
function createFunctionsService(cloud) {
  var context = {
    name: FUNCTIONS_SERVICE_NAME,
    identifiers: cloud.identifiers,
    request: cloud.request,
    isInstance: cloud.isInstance,
    serviceEndpoint: cloud.serviceEndpoint,
    runtime: cloud.runtimeInfo,
    plugins: cloud.plugins,
    get debug() {
      return cloud.debug;
    },
    get env() {
      return cloud.getEnvForService(FUNCTIONS_SERVICE_NAME);
    },
    appConfig: {
      get maxReqDataSize() {
        return cloud.appConfig.call_function_max_req_data_size;
      },
      get maxPollRetry() {
        return cloud.appConfig.call_function_poll_max_retry;
      },
      get maxStartRetryGap() {
        return cloud.appConfig.call_function_valid_start_retry_gap;
      },
      get clientPollTimeout() {
        return cloud.appConfig.call_function_client_poll_timeout;
      }
    }
  };
  return {
    name: FUNCTIONS_SERVICE_NAME,
    context,
    getAPIs: getAPIs.bind(null, context)
  };
}
function registerService(cloud) {
  cloud.registerService(createFunctionsService(cloud));
}
;// CONCATENATED MODULE: ./src/servicemarket/cdn.ts

var CDNObjectSymbol = Symbol('CDN');
class CDN {
  constructor(options) {
    this.symbol = CDNObjectSymbol;
    this.options = void 0;
    this.options = options;
  }
}
function cdn_uploadToCommonCDN(options, sdk) {
  return new Promise((resolve, reject) => {
    (sdk || appserviceSdk_getSDK()).uploadToCommonCDN({
      ...options,
      success: resolve,
      fail: reject
    });
  });
}
;// CONCATENATED MODULE: ./src/servicemarket/operateWXData.ts

function invokeOperateWXData(options, sdk) {
  return new Promise((resolve, reject) => {
    (sdk || appserviceSdk_getSDK()).invokeOperateWXData({
      ...options,
      success: resolve,
      fail: reject
    });
  });
}
;// CONCATENATED MODULE: ./src/servicemarket/invokeService/v1.ts



var v1_API_NAME = 'invokeService';
var v1_getType = x => Object.prototype.toString.call(x).slice(8, -1);
var invokeService = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_default()(function* (options) {
    try {
      if (!options.service || !options.api) {
        throw new Error(`field 'service' and 'api' must be provided`);
      }
      var cdnMap = new WeakMap();
      var cdnTasks = [];
      if (options.data) {
        JSON.stringify(options.data, (key, value) => {
          if (value && value.symbol === CDNObjectSymbol) {
            cdnTasks.push(new Promise((resolve, reject) => {
              var param = {
                appType: 301,
                fileType: 20303,
                fileKey: `file_${Math.random()}`
              };
              var cdn = value;
              switch (v1_getType(cdn.options)) {
                case 'Object':
                  {
                    if (!cdn.options.filePath) {
                      throw new Error(`filePath must be provided`);
                    }
                    param.filePath = cdn.options.filePath;
                    break;
                  }
                default:
                  {
                    param.fileData = cdn.options;
                    break;
                  }
              }
              resolve(cdn_uploadToCommonCDN(param, options.sdk).then(uploadResult => {
                cdnMap.set(value, uploadResult.fileUrl);
              }));
            }));
            return undefined;
          } else return value;
        });
      }
      yield Promise.all(cdnTasks);
      var serializedData = JSON.stringify(options.data, (key, value) => {
        if (value && value.symbol === CDNObjectSymbol && cdnMap.has(value)) {
          return cdnMap.get(value);
        } else return value;
      });
      var {
        data: resData
      } = yield invokeOperateWXData({
        apiName: 'webapi_servicemarket_jsapi_comm',
        reqData: {
          service_id: options.service,
          api_name: options.api,
          data: serializedData,
          consume_type: options.consumeType,
          consume_appid: options.consumeAppid,
          client_msg_id: `${Math.random()}_${Date.now()}`,
          version: 1
        }
      }, options.sdk);
      var requestId;
      var data;
      var error;
      try {
        var json = resData;
        requestId = json.request_id;
        if (json.errcode === 0) {
          data = JSON.parse(json.data);
        } else {
          var errMsg = `invokeService:fail ${json.errcode} ${json.errmsg} (requestId: ${requestId})`;
          error = new Error(errMsg);
          error.errCode = json.errcode;
          error.errMsg = errMsg;
          error.requestId = requestId;
        }
      } catch (e) {
        var _errMsg = `invokeService:fail inner protocol parse failed (requestId: ${requestId || 'empty'})`;
        error = new Error(_errMsg);
        error.errCode = -1;
        error.errMsg = _errMsg;
        error.requestId = requestId;
      }
      if (error) {
        throw error;
      }
      return {
        errMsg: `invokeService:ok`,
        data,
        requestId
      };
    } catch (err) {
      var _errMsg2 = `invokeService:fail `;
      if (err && err.errMsg && err.err_code) {
        _errMsg2 += err.errMsg;
        var e = new Error(_errMsg2 + `(err_code ${err.err_code})`);
        e.errCode = err.err_code;
        throw e;
      } else if (err && err.errMsg && err.errCode) {
        throw err;
      } else {
        throw new Error(`invokeService:fail ${err}`);
      }
    }
  });
  return function invokeService(_x) {
    return _ref.apply(this, arguments);
  };
}();
;// CONCATENATED MODULE: ./src/servicemarket/types.ts
var Scene = /*#__PURE__*/function (Scene) {
  Scene[Scene["CALL"] = 1] = "CALL";
  Scene[Scene["POLL"] = 2] = "POLL";
  Scene[Scene["PreResp"] = 3] = "PreResp";
  Scene[Scene["FinalResp"] = 4] = "FinalResp";
  return Scene;
}({});
var RetryReason = /*#__PURE__*/function (RetryReason) {
  RetryReason[RetryReason["None"] = 0] = "None";
  RetryReason[RetryReason["SysErr"] = 1] = "SysErr";
  RetryReason[RetryReason["Timeout"] = 2] = "Timeout";
  return RetryReason;
}({});
var ReqType = /*#__PURE__*/function (ReqType) {
  ReqType[ReqType["Sync"] = 0] = "Sync";
  ReqType[ReqType["LongAsync"] = 2] = "LongAsync";
  return ReqType;
}({});
;// CONCATENATED MODULE: ./src/servicemarket/config.ts
var config_ERR_CODE = {
  SM_EXCEED_MAX_TIMEOUT_POLL_RETRY: 100,
  SM_EMPTY_CALL_RESULT: 101,
  SM_EXCEED_MAX_POLL_RETRY: 102,
  SM_PROVIDER_EXECUTION_ERROR: 103,
  SM_POLL_RESULT_EXPIRED: 104,
  SM_EMPTY_POLL_RESULT_BASE_RESP: 105,
  SM_POLL_RESULT_BASE_RESP_RET_ABNORMAL: 106,
  SM_UNKNOWN_SCENE: 107,
  SM_SYSTEM_ERROR: 108
};
var ERR_MSG = {
  SM_EXCEED_MAX_TIMEOUT_POLL_RETRY: 'exceed max timeout retry',
  SM_EMPTY_CALL_RESULT: 'empty call result',
  SM_EXCEED_MAX_POLL_RETRY: 'exceed max poll retry',
  SM_PROVIDER_EXECUTION_ERROR: 'provider execution error',
  SM_POLL_RESULT_EXPIRED: 'poll result expired',
  SM_EMPTY_POLL_RESULT_BASE_RESP: 'empty poll result base resp',
  SM_POLL_RESULT_BASE_RESP_RET_ABNORMAL: 'poll result base resp ret abnormal',
  SM_UNKNOWN_SCENE: 'unknown scene',
  SM_SYSTEM_ERROR: 'system error'
};
;// CONCATENATED MODULE: ./src/servicemarket/invokeService/v2.ts








var v2_API_NAME = 'invokeService';
var v2_MAX_NORMAL_POLL_RETRY = 50;
var v2_MAX_SYSTEM_ERROR_RETRY = 2;
var v2_MAX_TIMEOUT_RETRY = 2;
var MAX_START_RETRY_GAP = 60;
var v2_DEFAULT_CLIENT_ONE_TIME_POLL_TIMEOUT = 20 * 1000;
var GetAsyncResultErrCode = /*#__PURE__*/(/* unused pure expression or super */ null && (function (GetAsyncResultErrCode) {
  GetAsyncResultErrCode[GetAsyncResultErrCode["InvalidRequestId"] = 14] = "InvalidRequestId";
  return GetAsyncResultErrCode;
}(GetAsyncResultErrCode || {})));
var v2_getType = x => Object.prototype.toString.call(x).slice(8, -1);
var v2_newTraceEntry = msg => {
  var d = new Date();
  return `${d.getHours()}:${d.getMinutes()}:${d.getSeconds()} ${msg}`;
};
var v2_traceStr = trace => trace.join('->');
var v2_invokeService = /*#__PURE__*/function () {
  var _ref = asyncToGenerator_default()(function* (options) {
    try {
      if (!options.service || !options.api) {
        throw new Error(`field 'service' and 'api' must be provided`);
      }
      var cdnMap = new WeakMap();
      var cdnTasks = [];
      if (options.data) {
        JSON.stringify(options.data, (key, value) => {
          if (value && value.symbol === CDNObjectSymbol) {
            cdnTasks.push(new Promise((resolve, reject) => {
              var param = {
                appType: 301,
                fileType: 20303,
                fileKey: `file_${Math.random()}`
              };
              var cdn = value;
              switch (v2_getType(cdn.options)) {
                case 'Object':
                  {
                    if (!cdn.options.filePath) {
                      throw new Error(`filePath must be provided`);
                    }
                    param.filePath = cdn.options.filePath;
                    break;
                  }
                default:
                  {
                    param.fileData = cdn.options;
                    break;
                  }
              }
              resolve(cdn_uploadToCommonCDN(param, options.sdk).then(uploadResult => {
                cdnMap.set(value, uploadResult.fileUrl);
              }));
            }));
            return undefined;
          } else return value;
        });
      }
      yield Promise.all(cdnTasks);
      var serializedData = JSON.stringify(options.data, (key, value) => {
        if (value && value.symbol === CDNObjectSymbol && cdnMap.has(value)) {
          return cdnMap.get(value);
        } else return value;
      });
      var callID = `${Math.random()}_${Date.now()}`;
      if (!options.async) {
        var {
          result,
          requestID
        } = yield callAndWaitResult(options, serializedData, callID);
        return {
          errMsg: `invokeService:ok`,
          data: result,
          requestId: requestID
        };
      } else {
        var reqData = {
          service_id: options.service,
          api_name: options.api,
          data: serializedData,
          consume_type: options.consumeType,
          consume_appid: options.consumeAppid,
          client_msg_id: `${Math.random()}_${Date.now()}`,
          version: 2,
          call_id: callID,
          scene: Scene.CALL,
          retry_reason: RetryReason.None,
          req_type: ReqType.LongAsync
        };
        var res = yield invokeOperateWXData({
          apiName: 'webapi_servicemarket_jsapi_comm',
          reqData
        }, options.sdk);
        var data = res.data;
        if (data.scene === Scene.FinalResp && data.errcode === 0) {
          return {
            errMsg: `invokeService:ok`,
            requestId: data.request_id
          };
        } else {
          var error = returnAsFinalCloudSDKError({
            errCode: config_ERR_CODE.SM_SYSTEM_ERROR,
            errMsg: `requestID ${data.request_id}, error message ${data.errmsg || 'unknown'} (callid ${callID})`
          }, v2_API_NAME);
          error.requestID = data.request_id;
          throw error;
        }
      }
    } catch (err) {
      var errMsg = `invokeService:fail `;
      if (err && err.errMsg && err.err_code) {
        errMsg += err.errMsg;
        var e = new Error(errMsg + `(err_code ${err.err_code})`);
        e.errCode = err.err_code;
        throw e;
      } else if (err && err.errMsg && err.errCode) {
        throw err;
      } else {
        throw new Error(`invokeService:fail ${err}`);
      }
    }
    function callAndWaitResult(_x2, _x3, _x4) {
      return _callAndWaitResult.apply(this, arguments);
    }
    function _callAndWaitResult() {
      _callAndWaitResult = asyncToGenerator_default()(function* (param, data, callID) {
        return new Promise((_resolve, _reject) => {
          var trace = [v2_newTraceEntry(`start`)];
          var {
            resolve,
            reject
          } = monitorAppVisiblity(trace, _resolve, _reject);
          poll({
            param,
            data,
            callID,
            scene: Scene.CALL,
            retryReason: RetryReason.None,
            tryCount: v2_MAX_NORMAL_POLL_RETRY,
            systemErrorRetry: v2_MAX_SYSTEM_ERROR_RETRY,
            timeoutErrorRetry: v2_MAX_TIMEOUT_RETRY,
            trace,
            resolve,
            reject
          });
        });
      });
      return _callAndWaitResult.apply(this, arguments);
    }
    function poll(_x5) {
      return _poll.apply(this, arguments);
    }
    function _poll() {
      _poll = asyncToGenerator_default()(function* (pollOpts) {
        var {
          param,
          data,
          callID,
          scene,
          retryReason,
          tryCount,
          trace,
          systemErrorRetry,
          timeoutErrorRetry,
          resolve,
          reject
        } = pollOpts;
        var reqData = {
          service_id: param.service,
          api_name: param.api,
          data: scene === Scene.CALL ? data : undefined,
          consume_type: options.consumeType,
          consume_appid: options.consumeAppid,
          client_msg_id: `${Math.random()}_${Date.now()}`,
          version: 2,
          call_id: callID,
          scene,
          retry_reason: retryReason
        };
        var hasTunnelTimeout = false;
        var timeoutCleared = false;
        var clearTunnelTimeout = () => {
          clearTimeout(tunnelTimeoutId);
          timeoutCleared = true;
        };
        var startTime = +new Date();
        var tunnelTimeoutId = setTimeout(/*#__PURE__*/asyncToGenerator_default()(function* () {
          var timeout = v2_DEFAULT_CLIENT_ONE_TIME_POLL_TIMEOUT;
          if (+new Date() - startTime > timeout) {
            yield sleep();
            if (timeoutCleared) {
              return;
            }
          }
          if (!isDevTools() && +new Date() - startTime > MAX_START_RETRY_GAP) {
            trace.push(v2_newTraceEntry(`timeout, exceed max retry gap`));
            return reject(returnAsFinalCloudSDKError({
              errCode: config_ERR_CODE.SM_POLL_RESULT_EXPIRED,
              errMsg: `timeout for retry, cannot retry fetching the result anymore (callId: ${callID}) (trace: ${v2_traceStr(trace)})`
            }, v2_API_NAME));
          }
          hasTunnelTimeout = true;
          if (pollOpts.timeoutErrorRetry > 0) {
            trace.push(v2_newTraceEntry(`timeout, retry`));
            poll({
              ...pollOpts,
              scene,
              retryReason: RetryReason.Timeout,
              tryCount: tryCount - 1,
              timeoutErrorRetry: timeoutErrorRetry - 1
            });
          } else {
            trace.push(v2_newTraceEntry(`timeout, abort`));
            reject(returnAsFinalCloudSDKError({
              errCode: config_ERR_CODE.SM_EXCEED_MAX_TIMEOUT_POLL_RETRY,
              errMsg: `${ERR_MSG.SM_EXCEED_MAX_TIMEOUT_POLL_RETRY} (callId: ${callID}) (trace: ${v2_traceStr(trace)})`
            }, v2_API_NAME));
          }
        }), v2_DEFAULT_CLIENT_ONE_TIME_POLL_TIMEOUT);
        try {
          var _res = yield invokeOperateWXData({
            apiName: 'webapi_servicemarket_jsapi_comm',
            reqData
          }, options.sdk);
          try {
            if (hasTunnelTimeout) return;
            clearTunnelTimeout();
            var _data = _res.data;
            if (!_data && _res.rawData) {
              try {
                _data = JSON.parse(_res.rawData);
              } catch (e) {}
            }
            if (!_data) {
              trace.push(v2_newTraceEntry(`empty resp`));
              return reject(returnAsFinalCloudSDKError({
                errCode: config_ERR_CODE.SM_EMPTY_CALL_RESULT,
                errMsg: ERR_MSG.SM_EMPTY_CALL_RESULT
              }, v2_API_NAME));
            }
            if (_data.scene === Scene.PreResp) {
              if (tryCount >= 0) {
                trace.push(v2_newTraceEntry(`normal poll`));
                poll({
                  ...pollOpts,
                  scene: Scene.POLL,
                  retryReason: RetryReason.None,
                  tryCount: tryCount - 1
                });
              } else {
                trace.push(v2_newTraceEntry(`too many polls, abort`));
                return reject(returnAsFinalCloudSDKError({
                  errCode: config_ERR_CODE.SM_EXCEED_MAX_POLL_RETRY,
                  errMsg: `${ERR_MSG.SM_EXCEED_MAX_POLL_RETRY} (callId: ${callID}) (trace: ${v2_traceStr(trace)})`
                }, v2_API_NAME));
              }
            } else if (_data.scene === Scene.FinalResp) {
              if (_data.errcode !== 0) {
                var _error = returnAsFinalCloudSDKError({
                  errCode: config_ERR_CODE.SM_PROVIDER_EXECUTION_ERROR,
                  errMsg: `requestID ${_data.request_id}, error message ${_data.provider_errmsg || 'unknown'} (callid ${callID})`
                }, v2_API_NAME);
                _error.requestID = _data.request_id;
                return reject(_error);
              } else {
                var _result = _data.data;
                try {
                  _result = JSON.parse(_result);
                } catch (e) {}
                return resolve({
                  result: _result,
                  requestID: _data.request_id
                });
              }
            } else {
              trace.push(v2_newTraceEntry(`unexpected scene`));
              return reject(returnAsFinalCloudSDKError({
                errCode: config_ERR_CODE.SM_UNKNOWN_SCENE,
                errMsg: `unknown scene ${_data.scene} (callId: ${callID}) (trace: ${v2_traceStr(trace)})`
              }, v2_API_NAME));
            }
          } catch (err) {
            reject(returnAsFinalCloudSDKError({
              errCode: config_ERR_CODE.SM_POLL_ERROR,
              errMsg: `polling catch error: ${err} (callId: ${callID})`
            }, v2_API_NAME));
          }
        } catch (err) {
          if (hasTunnelTimeout) return;
          clearTunnelTimeout();
          var _errMsg = err instanceof Error ? err : JSON.stringify(err);
          if (err && err.operateWXDataFail && systemErrorRetry > 0) {
            trace.push(v2_newTraceEntry(`system error (${_errMsg}), retry`));
            poll({
              ...pollOpts,
              scene,
              retryReason: RetryReason.SysErr,
              tryCount: tryCount - 1,
              systemErrorRetry: systemErrorRetry - 1
            });
          } else {
            trace.push(v2_newTraceEntry(`system error (${_errMsg}), abort`));
            reject(returnAsFinalCloudSDKError(`${_errMsg} (callId: ${callID}) (trace: ${v2_traceStr(trace)})`, v2_API_NAME));
          }
        }
      });
      return _poll.apply(this, arguments);
    }
    function monitorAppVisiblity(trace, resolve, reject) {
      var listener = event => {
        trace.push(v2_newTraceEntry(`app ${event}`));
      };
      onAppVisibilityChange(listener);
      var _resolve = v => {
        offAppVisibilityChange(listener);
        resolve(v);
      };
      var _reject = v => {
        offAppVisibilityChange(listener);
        reject(v);
      };
      return {
        resolve: _resolve,
        reject: _reject
      };
    }
  });
  return function invokeService(_x) {
    return _ref.apply(this, arguments);
  };
}();
function getAsyncResult(_x6) {
  return _getAsyncResult.apply(this, arguments);
}
function _getAsyncResult() {
  _getAsyncResult = asyncToGenerator_default()(function* (options) {
    var res = yield invokeOperateWXData({
      apiName: 'webapi_servicemarket_jsapi_retrieve',
      reqData: {
        request_id: options.requestId
      }
    }, options.sdk);
    var data = res.data;
    if (data.errcode === 0) {
      if (data.provider_errmsg) {
        return {
          errCode: 0,
          errMsg: `getAsyncResult:fail provider execution error`,
          status: data.status,
          providerErrMsg: data.provider_errmsg,
          requestId: data.request_id
        };
      } else {
        return {
          errCode: 0,
          errMsg: `getAsyncResult:ok`,
          data: JSON.parse(data.data),
          status: data.status,
          requestId: data.request_id
        };
      }
    } else {
      var error = new Error(`getAsyncResult:fail requestID ${data.request_id}, error message ${data.errmsg || 'unknown'}`);
      error.errCode = data.errcode;
      error.errMsg = data.errmsg;
      throw error;
    }
  });
  return _getAsyncResult.apply(this, arguments);
}
;// CONCATENATED MODULE: ./src/servicemarket/index.ts





var servicemarket_API_NAME = 'invokeService';
var GET_ASYNC_RESULT_API_NAME = 'getAsyncResult';
var servicemarket_invokeService = options => {
  if (hasAPICallback(options)) {
    return invokeServiceCallbackStyle(options);
  } else {
    var promise = isDevTools() && !options.async ? invokeService(options) : v2_invokeService(options);
    return promise;
  }
};
var invokeServiceCallbackStyle = options => {
  var promise = isDevTools() && !options.async ? invokeService(options) : v2_invokeService(options);
  promise.then(res => {
    invokeSuccessCompleteCallbacks(servicemarket_API_NAME, options, res);
  }).catch(err => {
    invokeFailCompleteCallbacks(servicemarket_API_NAME, options, err);
  });
};
var servicemarket_getAsyncResult = options => {
  if (hasAPICallback(options)) {
    return getAsyncResultCallbackStyle(options);
  } else {
    return getAsyncResult(options);
  }
};
var getAsyncResultCallbackStyle = options => {
  var promise = getAsyncResult(options);
  promise.then(res => {
    invokeSuccessCompleteCallbacks(GET_ASYNC_RESULT_API_NAME, options, res);
  }).catch(err => {
    invokeFailCompleteCallbacks(GET_ASYNC_RESULT_API_NAME, options, err);
  });
};
function getServiceMarketAPI(options = {}) {
  var {
    sdk
  } = options;
  return {
    invokeService: options => {
      return servicemarket_invokeService({
        ...options,
        sdk
      });
    },
    getAsyncResult: options => {
      return servicemarket_getAsyncResult({
        ...options,
        sdk
      });
    },
    CDN: CDN
  };
}
;// CONCATENATED MODULE: ./src/index.ts



;// CONCATENATED MODULE: ./src/utils/userAgent.ts

var userAgent;
function getUA() {
  if (!userAgent) {
    var __appServiceSDK__ = appserviceSdk_getSDK();
    if (!__appServiceSDK__.private_getUserAgent) return userAgent;
    __appServiceSDK__.private_getUserAgent(ua => {
      userAgent = ua;
    });
  }
  return userAgent;
}
;// CONCATENATED MODULE: ./src/utils/referer.ts

function getReferer() {
  var _WXConfig$accountInfo, _WXConfig$accountInfo2, _WXConfig$accountInfo3;
  var dev = isDevTools();
  var appid = (_WXConfig$accountInfo = wxconfig.accountInfo) === null || _WXConfig$accountInfo === void 0 ? void 0 : _WXConfig$accountInfo.appId;
  var version = ((_WXConfig$accountInfo2 = wxconfig.accountInfo) === null || _WXConfig$accountInfo2 === void 0 ? void 0 : (_WXConfig$accountInfo3 = _WXConfig$accountInfo2.appVersion) === null || _WXConfig$accountInfo3 === void 0 ? void 0 : _WXConfig$accountInfo3.toString()) || '0';
  if (!appid) {
    return undefined;
  }
  if (dev) {
    version = 'devtools';
  }
  return `https://servicewechat.com/${appid}/${version}/page-frame.html`;
}
;// CONCATENATED MODULE: ./src/utils/simulate-request.ts






function urlEncodeFormData(data, needEncode = false) {
  if (typeof data !== 'object') {
    return data;
  }
  var str = '';
  for (var k in data) {
    if (Object.prototype.hasOwnProperty.call(data, k)) {
      if (needEncode) {
        try {
          str += `${encodeURIComponent(k)}=${encodeURIComponent(data[k])}&`;
        } catch (e) {
          str += `${k}=${data[k]}&`;
        }
      } else {
        str += `${k}=${data[k]}&`;
      }
    }
  }
  if (str) {
    str = str.slice(0, -1);
  }
  return str;
}
function addQueryStringToUrl(url, data) {
  var dataKeys = Object.keys(data);
  if (typeof url === 'string' && typeof data === 'object' && data !== null && dataKeys.length > 0) {
    var parts = url.split('?');
    var path = parts[0];
    var query = (parts[1] || '').split('&').reduce((pre, cur) => {
      if (typeof cur === 'string' && cur.length > 0) {
        var _parts = cur.split('=');
        var key = _parts[0];
        var value = _parts[1];
        pre[key] = value;
      }
      return pre;
    }, {});
    var encodedData = dataKeys.reduce((ret, key) => {
      if (typeof data[key] === 'object') {
        ret[encodeWithDecode(key)] = encodeWithDecode(JSON.stringify(data[key]));
      } else {
        ret[encodeWithDecode(key)] = encodeWithDecode(data[key]);
      }
      return ret;
    }, {});
    return path + '?' + urlEncodeFormData(Object.assign(query, encodedData));
  } else {
    return url;
  }
}
function processParam(param) {
  if (!param.path) {
    param.path = '';
  }
  if (!param.method) {
    param.method = 'GET';
  }
  if (!param.header) {
    param.header = {};
  }
  if (!param.dataType) {
    param.dataType = 'json';
  }
  if (!param.responseType) {
    param.responseType = 'text';
  }
  var contentType = '';
  for (var key in param.header) {
    if (key.toLowerCase() === 'content-type' && param.header) {
      contentType = param.header[key];
    }
  }
  if (!contentType) {
    contentType = 'application/json';
    param.header['content-type'] = 'application/json';
  }
  param.header['User-Agent'] = getUA() || '';
  var referer = getReferer();
  if (referer) {
    param.header.referer = referer;
  }
  if (/get/i.test(param.method || '') && param.data && isObject(param.data)) {
    param.path = addQueryStringToUrl(param.path, param.data);
    param.data = undefined;
  } else if (/post|put|patch|delete/i.test(param.method || '') && param.data) {
    if (contentType.includes('application/json')) {
      var type = type_getType(param.data);
      param.shouldSerialize = type !== 'string';
    } else if (contentType.includes('application/x-www-form-urlencoded') && isObject(param.data)) {
      var urlEncoded = '';
      for (var _key in param.data) {
        urlEncoded += `${urlEncoded.length ? '&' : ''}${encodeURIComponent(_key)}=${encodeURIComponent(param.data[_key])}`;
      }
      param.data = urlEncoded;
    }
  }
}
function is3XXResponse(code) {
  return code >= 300 && code <= 399;
}
class CommonError extends Error {
  constructor(reason, code) {
    super(reason);
    this.code = void 0;
    this.code = code;
  }
}
var redirectPromiseCount = new WeakMap();
var REDIRECT_MAX_CALL = 5;
function followRedirect(_param, _request, getRequestPromise, context, API_NAME) {
  var _param$followRedirect;
  var followRedirectParam = (_param$followRedirect = _param.followRedirect) !== null && _param$followRedirect !== void 0 ? _param$followRedirect : true;
  if (!followRedirectParam) return _request;
  function getFollowRedirectPromise(param, request) {
    return new Promise((resolve, reject) => {
      request.then(resp => {
        var _redirectPromiseCount;
        if (!is3XXResponse(resp.statusCode)) {
          resolve(resp);
          return;
        }
        var count = (_redirectPromiseCount = redirectPromiseCount.get(_request)) !== null && _redirectPromiseCount !== void 0 ? _redirectPromiseCount : 0;
        if (count >= REDIRECT_MAX_CALL) {
          reject('reach the max redirect count');
          return;
        }
        redirectPromiseCount.set(_request, count + 1);
        var location = '';
        for (var key in resp.header) {
          if (key.toLowerCase() === 'location') location = resp.header[key];
        }
        if (!location) {
          resolve(resp);
          return;
        }
        if (location.startsWith('/')) {
          var copyParams = shallowClone(param);
          param.path = location;
          var requestPromise = getRequestPromise(param);
          getFollowRedirectPromise(copyParams, requestPromise).then(resolve).catch(reject);
        } else {
          var __appServiceSDK__ = appserviceSdk_getSDK(context.identifiers);
          __appServiceSDK__.request({
            url: location,
            method: param.method,
            header: param.header,
            data: param.data,
            dataType: param.dataType,
            responseType: param.responseType,
            timeout: param.timeout,
            success: res => {
              resolve({
                ...res,
                errMsg: `${API_NAME}:ok`
              });
            },
            fail: err => {
              reject(err.errMsg.replace(/^request/, API_NAME));
            }
          });
        }
      }).catch(reject);
    });
  }
  return getFollowRedirectPromise(_param, _request);
}
function processResponse(param, rawBody, statusCode) {
  var body;
  var bodyBuffer = typeof rawBody === 'string' ? null : new Uint8Array(rawBody).buffer;
  if ((param.dataType === 'json' || !param.dataType) && !is3XXResponse(statusCode)) {
    var str = typeof rawBody === 'string' ? rawBody : arrayBufferToString(bodyBuffer);
    body = tryJSONParse(str);
  } else if (param.responseType === 'text') {
    body = typeof rawBody === 'string' ? rawBody : arrayBufferToString(bodyBuffer);
  } else if (param.responseType === 'arraybuffer') {
    body = typeof rawBody === 'string' ? stringToArrayBuffer(rawBody) : bodyBuffer;
  } else {
    body = rawBody;
  }
  return body;
}
;// CONCATENATED MODULE: ./src/services/container/api/callContainer/v1.ts











var callContainer_v1_API_NAME = 'cloud.callContainer';
function getCallContainerAPI(context) {
  return /*#__PURE__*/function () {
    var _callContainer = asyncToGenerator_default()(function* (param) {
      var endpoint = context.serviceEndpoint.getEndpointSync('container');
      var cdnMap = new WeakMap();
      if (param.cdnMapPromise || !endpoint) {
        var list = yield Promise.all([param.cdnMapPromise, autoTiming(context.serviceEndpoint.getEndpoint('container'), param.stats, 'getServiceEndpoint')]);
        if (list[0]) {
          cdnMap = list[0];
        }
        endpoint = list[1];
      } else {
        param.stats.getServiceEndpoint = 0;
      }
      if (param.shouldSerialize) {
        param.data = serialize(param.data, cdnMap);
      }
      if (endpoint.http) {
        var p = requestRunContainerPrivateHTTP(endpoint, param);
        p.then(keepAlive).catch(keepAlive);
        return p;
      }
      return requestRunContainer(endpoint.url, param);
    });
    function callContainer(_x) {
      return _callContainer.apply(this, arguments);
    }
    return callContainer;
  }();
  function requestRunContainerPrivateHTTP(endpoint, param) {
    return new Promise((resolve, reject) => {
      var _param$config, _param$method;
      param.stats.tsCallContainerImplStart = Date.now();
      var __appServiceSDK__ = appserviceSdk_getSDK(context.identifiers);
      var outerRequestHeader = {
        'X-WX-ENCRYPTION-VERSION': 2,
        'X-WX-ENCRYPTION-TIMESTAMP': endpoint.timestamp + '',
        'X-WX-COMPRESSION': 'snappy',
        'X-WX-USER-TIMEOUT': param.timeout || '',
        'X-WX-LIB-BUILD-TS': 1727594124553,
        'X-WX-RESPONSE-CONTENT-ACCEPT-ENCODING': 'PB, JSON',
        'Content-Type': 'application/octet-stream'
      };
      var callId = `${Math.random()}_${Date.now()}`;
      var header = {
        ...param.header,
        'X-WX-ENV': context.isInstance ? context.env : ((_param$config = param.config) === null || _param$config === void 0 ? void 0 : _param$config.env) || context.env,
        'X-WX-CALL-ID': callId
      };
      if (context.appid) {
        header['X-WX-RESOURCE-APPID'] = context.appid;
      }
      if (param.service) {
        header['X-WX-SERVICE'] = param.service;
      }
      var stats = param.stats;
      stats.callid = callId;
      var ts = Date.now();
      if (((_param$method = param.method) === null || _param$method === void 0 ? void 0 : _param$method.toUpperCase()) === 'GET' && param.data && isObject(param.data)) {
        var kvs = [];
        for (var _key in param.data) {
          kvs.push(`${_key}=${param.data[_key]}`);
        }
        param.path += `${param.path.includes('?') ? param.path.endsWith('&') ? '' : '&' : '?'}${kvs.join('&')}`;
        param.data = undefined;
      }
      header['X-WX-CONTAINER-PATH'] = param.path;
      var key = new Uint8Array(base64ToArrayBuffer(endpoint.key));
      var {
        data: encReq,
        contentEncoding
      } = dist.V1.encodeRequest(key, header, param.method || 'GET', param.data, callId, stats);
      outerRequestHeader['X-WX-REQUEST-CONTENT-ENCODING'] = contentEncoding;
      stats.encrypt = Date.now() - ts;
      ts = Date.now();
      var useDomain = true;
      var url = useDomain ? endpoint.url : `http://${endpoint.vip}/wxa-qbase/container_service?token=${endpoint.token}`;
      if (param.rdm) {
        url = `https://wxardm.weixin.qq.com/wxa-qbase/container_service?token=${endpoint.token}`;
      } else if (param.ecdn) {
        url = `https://cloudbase.servicewechat.com/wxa-qbase/container_service?token=${endpoint.token}`;
      }
      param.verbose && console.log(`[cloud.callContainer] url ${url}`);
      if (useDomain && endpoint.domain) {
        param.stats.domain = endpoint.domain;
      }
      stats.requestBodyBytes = encReq.byteLength;
      stats.requestStartTs = Date.now();
      if (param._fallback) {
        reject({
          errCode: -9999,
          errMsg: `${callContainer_v1_API_NAME}:fail emulated fallback`
        });
        return;
      }
      if (!limiter.allowRequest()) {
        reject(toSDKError({
          errCode: error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_SERVER_REQUEST_COUNT,
          errMsg: `error: exceed max client request count, avoid infinite loop in your code`
        }, callContainer_v1_API_NAME));
        return;
      }
      __appServiceSDK__._requestSkipCheckDomain({
        url,
        method: 'POST',
        header: outerRequestHeader,
        data: encReq.buffer,
        dataType: 'arraybuffer',
        responseType: 'arraybuffer',
        timeout: param.timeout,
        enableHttp2: useDomain,
        success: res => {
          param.stats.requestSuccessTs = Date.now();
          try {
            for (var _key2 in res.header) {
              if (_key2.toLowerCase() === 'x-nws-log-uuid') {
                param.verbose && console.log(`[cloud.callContainer] x-nws-log-uuid ${res.header[_key2]}`);
                param.stats.ecdnId = res.header[_key2];
              }
              if (_key2.toLowerCase() === 'x-edge-timing') {
                param.stats.ecdnEdgeTiming = res.header[_key2];
              }
              if (_key2.toLowerCase() === 'x-wx-system-error') {
                var code = Number(res.header[_key2]);
                if (code === 85104) {
                  endpoint.invalidate();
                }
                if (code === 102003) {
                  limiter.markServerLimitExceed();
                }
                reject({
                  errCode: code,
                  errMsg: `${callContainer_v1_API_NAME}:fail system error. code: ${code}`
                });
                return;
              }
            }
            param.verbose && console.warn('res', res);
            stats.profile = res.profile;
            stats.httpRequest = Date.now() - ts;
            if (res.statusCode === 200) {
              var resData = res.data;
              stats.responseBodyBytes = resData.byteLength;
              ts = Date.now();
              var compressed = false;
              var contentProtocol = dist/* AppProtocolV1 */.h.pb;
              for (var _key3 in res.header) {
                if (_key3.toLowerCase() === 'x-wx-compression' && res.header[_key3] === 'snappy') {
                  ts = Date.now();
                  compressed = true;
                }
                if (_key3.toLowerCase() === 'x-wx-response-content-encoding' && res.header[_key3].toLowerCase() === 'json') {
                  contentProtocol = dist/* AppProtocolV1 */.h.json;
                }
                if (_key3.toLowerCase() === 'x-wx-server-timing') {
                  var serverTiming = res.header[_key3] || '';
                  var rawNumStrs = serverTiming.split(',');
                  if (rawNumStrs.length >= 2) {
                    stats.serverStartTs = Number(rawNumStrs[0]);
                    stats.serverEndTs = Number(rawNumStrs[1]);
                  }
                }
              }
              var decrypted = dist.V1.decodeResponse(key, new Uint8Array(resData), compressed, contentProtocol, stats);
              ts = Date.now();
              var body;
              var rawBody = decrypted.body;
              if (!is3XXResponse(decrypted.statusCode)) {
                body = processResponse(param, rawBody, decrypted.statusCode);
              }
              stats.decodeBody = Date.now() - ts;
              stats.responseProcessEndTs = Date.now();
              resolve({
                statusCode: decrypted.statusCode,
                header: decrypted.header,
                data: body,
                stats,
                callID: callId,
                errMsg: `${callContainer_v1_API_NAME}:ok`
              });
            } else {
              reject({
                errCode: -9999,
                errMsg: `${callContainer_v1_API_NAME}:fail [call_id ${callId}] system conn status not 200`
              });
            }
          } catch (e) {
            reject({
              errCode: -1,
              errMsg: `${callContainer_v1_API_NAME}:fail [call_id ${callId}] error while processing internal response ${e}`
            });
          }
        },
        fail: err => {
          reject({
            ...err,
            errCode: -9999,
            errMsg: err.errMsg.replace(/^request/, callContainer_v1_API_NAME)
          });
        }
      });
    });
  }
  function requestRunContainer(_x2, _x3) {
    return _requestRunContainer.apply(this, arguments);
  }
  function _requestRunContainer() {
    _requestRunContainer = asyncToGenerator_default()(function* (url, param) {
      return new Promise((resolve, reject) => {
        var _param$config2;
        var __appServiceSDK__ = appserviceSdk_getSDK(context.identifiers);
        var header = {
          ...param.header,
          'X-WX-ENV': context.isInstance ? context.env : ((_param$config2 = param.config) === null || _param$config2 === void 0 ? void 0 : _param$config2.env) || context.env,
          'X-WX-SERVICE': param.service,
          'X-WX-CONTAINER-PATH': param.path,
          'X-WX-CALL-ID': `${Math.random()}_${Date.now()}`,
          'X-WX-USER-TIMEOUT': param.timeout
        };
        if (context.appid) {
          header['X-WX-RESOURCE-APPID'] = context.appid;
        }
        if (!limiter.allowRequest()) {
          reject(toSDKError({
            errCode: error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_SERVER_REQUEST_COUNT,
            errMsg: `error: exceed max client request count, avoid infinite loop in your code`
          }, callContainer_v1_API_NAME));
          return;
        }
        __appServiceSDK__._requestSkipCheckDomain({
          url,
          method: param.method,
          header,
          data: param.data,
          dataType: param.dataType,
          responseType: param.responseType,
          timeout: param.timeout,
          success: res => {
            resolve({
              ...res,
              errMsg: `${callContainer_v1_API_NAME}:ok`
            });
          },
          fail: err => {
            reject({
              ...err,
              errMsg: err.errMsg.replace(/^request/, callContainer_v1_API_NAME)
            });
          }
        });
      });
    });
    return _requestRunContainer.apply(this, arguments);
  }
}
function autoTiming(promise, timing, name) {
  var t = Date.now();
  promise.then(() => timing[name] = Date.now() - t).catch(() => timing[name] = Date.now() - t);
  return promise;
}
;// CONCATENATED MODULE: ./src/utils/data-pipe.ts








var Action = /*#__PURE__*/function (Action) {
  Action[Action["CALL"] = 1] = "CALL";
  Action[Action["POLL"] = 2] = "POLL";
  return Action;
}({});
var RetryType = /*#__PURE__*/function (RetryType) {
  RetryType[RetryType["None"] = 0] = "None";
  RetryType[RetryType["Error"] = 1] = "Error";
  RetryType[RetryType["Timeout"] = 2] = "Timeout";
  return RetryType;
}({});
var DataType = /*#__PURE__*/function (DataType) {
  DataType[DataType["RAW"] = 0] = "RAW";
  DataType[DataType["BASE64"] = 1] = "BASE64";
  DataType[DataType["CDN_URL"] = 2] = "CDN_URL";
  return DataType;
}({});
var data_pipe_ResultStatus = /*#__PURE__*/(/* unused pure expression or super */ null && (function (ResultStatus) {
  ResultStatus[ResultStatus["PENDING"] = 0] = "PENDING";
  ResultStatus[ResultStatus["DONE"] = 1] = "DONE";
  ResultStatus[ResultStatus["TIMEOUT"] = 2] = "TIMEOUT";
  return ResultStatus;
}({})));
var data_pipe_newTraceEntry = msg => {
  var d = new Date();
  return `${d.getHours()}:${d.getMinutes()}:${d.getSeconds()} ${msg}`;
};
var data_pipe_traceStr = trace => trace.join('->');
var data_pipe_MAX_NORMAL_POLL_RETRY = 20;
var data_pipe_MAX_SYSTEM_ERROR_RETRY = 2;
var data_pipe_MAX_TIMEOUT_RETRY = 2;
var data_pipe_DEFAULT_CLIENT_ONE_TIME_POLL_TIMEOUT = 20 * 1000;
var CDN_THRESHOLD_BYTE_LENGTH = 100 * 1000;
var DATA_PIPE_SIZE_LIMIT_ERROR = Symbol();
function processDataPipeParam(_x) {
  return _processDataPipeParam.apply(this, arguments);
}
function _processDataPipeParam() {
  _processDataPipeParam = asyncToGenerator_default()(function* (param, callID = `${+new Date()}-${Math.random()}`) {
    var _param$method;
    if (param.shouldSerialize) {
      var cdnMap = yield param.cdnMapPromise;
      param.data = serialize(param.data, cdnMap);
    }
    var tunnelReqDataType = DataType.RAW;
    param.stats.callid = callID;
    var method = ((_param$method = param.method) === null || _param$method === void 0 ? void 0 : _param$method.toUpperCase()) || 'GET';
    if (param.data && /^(POST|PUT|PATCH|DELETE)$/.test(method)) {
      var type = type_getType(param.data);
      if (type === 'object') {
        param.data = JSON.stringify(param.data);
      } else if (type === 'arraybuffer' || type === 'string') {
        var shouldUseCDN = false;
        if (type === 'string') {
          shouldUseCDN = param.data.length > CDN_THRESHOLD_BYTE_LENGTH;
        } else {
          if (param.data.byteLength > CDN_THRESHOLD_BYTE_LENGTH) {
            shouldUseCDN = true;
          } else {
            var base64 = arrayBufferToBase64(param.data);
            if (base64.length > CDN_THRESHOLD_BYTE_LENGTH) {
              shouldUseCDN = true;
            } else {
              param.data = base64;
              tunnelReqDataType = DataType.BASE64;
            }
          }
        }
        if (shouldUseCDN) {
          var error = new Error(`input data size too large (> 100KB)`);
          Object.defineProperty(error, 'type', {
            value: DATA_PIPE_SIZE_LIMIT_ERROR
          });
          throw error;
        }
      } else {
        throw new Error(`input data type is not supported: ${type}`);
      }
    } else if (method === 'GET' && param.data && isObject(param.data)) {
      var kvs = [];
      for (var key in param.data) {
        kvs.push(`${key}=${param.data[key]}`);
      }
      param.path += `${param.path.includes('?') ? param.path.endsWith('&') ? '' : '&' : '?'}${kvs.join('&')}`;
      param.data = undefined;
    } else {
      param.data = undefined;
    }
    for (var _key in param.header) {
      if (param.header[_key] !== null && param.header[_key] !== undefined) {
        param.header[_key] += '';
      }
    }
    return {
      tunnelReqDataType,
      callID
    };
  });
  return _processDataPipeParam.apply(this, arguments);
}
var API_NAME_MAP = {
  'gateway.call': 'tcbapi_call_gateway',
  'cloud.callContainer': 'tcbapi_call_container'
};
function callAndWaitResult(_x2, _x3, _x4, _x5, _x6, _x7) {
  return _callAndWaitResult.apply(this, arguments);
}
function _callAndWaitResult() {
  _callAndWaitResult = asyncToGenerator_default()(function* (API_NAME, param, data, dataType, callID, context) {
    var userTimeoutReached = false;
    var userTimeoutPromise;
    if (Object.prototype.hasOwnProperty.call(param, 'timeout')) {
      userTimeoutPromise = new Promise((resolve, reject) => {
        setTimeout(() => {
          userTimeoutReached = true;
          reject(`timeout (options.timeout == ${param.timeout})`);
        }, param.timeout);
      });
    }
    var pollPromise = new Promise((_resolve, _reject) => {
      var _context$appConfig;
      var trace = [data_pipe_newTraceEntry(`start`)];
      var {
        resolve,
        reject
      } = monitorAppVisiblity(trace, _resolve, _reject);
      poll(API_NAME, {
        param,
        data,
        dataType,
        callID,
        action: Action.CALL,
        retryType: RetryType.None,
        tryCount: (context === null || context === void 0 ? void 0 : (_context$appConfig = context.appConfig) === null || _context$appConfig === void 0 ? void 0 : _context$appConfig.maxPollRetry) || data_pipe_MAX_NORMAL_POLL_RETRY,
        systemErrorRetry: data_pipe_MAX_SYSTEM_ERROR_RETRY,
        timeoutErrorRetry: data_pipe_MAX_TIMEOUT_RETRY,
        userTimeout: {
          get reached() {
            return userTimeoutPromise ? userTimeoutReached : false;
          }
        },
        trace,
        resolve,
        reject,
        context
      });
    });
    return !userTimeoutPromise ? pollPromise : Promise.race([pollPromise, userTimeoutPromise]);
  });
  return _callAndWaitResult.apply(this, arguments);
}
function poll(_x8, _x9) {
  return _poll.apply(this, arguments);
}
function _poll() {
  _poll = asyncToGenerator_default()(function* (API_NAME, options) {
    var _context$appConfig4, _param$config;
    var {
      context,
      data,
      dataType,
      callID,
      action,
      retryType,
      tryCount,
      trace,
      systemErrorRetry,
      timeoutErrorRetry,
      userTimeout,
      resolve,
      reject,
      param
    } = options;
    var headers = [];
    for (var k in param.header) {
      headers.push({
        k,
        v: param.header[k]
      });
    }
    var reqData = action === Action.CALL ? {
      method: param.method || 'GET',
      headers,
      data: action === Action.CALL ? data : undefined,
      data_type: dataType,
      action,
      retryType,
      call_id: callID,
      user_timeout: param.timeout
    } : {
      call_id: callID,
      action,
      retryType
    };
    var serializedReqData = serialize(reqData);
    var hasTunnelTimeout = false;
    var timeoutCleared = false;
    var clearTunnelTimeout = () => {
      clearTimeout(tunnelTimeoutId);
      timeoutCleared = true;
    };
    var startTime = +new Date();
    var tunnelTimeoutId = setTimeout(/*#__PURE__*/asyncToGenerator_default()(function* () {
      var _context$appConfig2, _context$appConfig$ma, _context$appConfig3;
      var timeout = (context === null || context === void 0 ? void 0 : (_context$appConfig2 = context.appConfig) === null || _context$appConfig2 === void 0 ? void 0 : _context$appConfig2.clientPollTimeout) || data_pipe_DEFAULT_CLIENT_ONE_TIME_POLL_TIMEOUT;
      if (+new Date() - startTime > timeout) {
        yield sleep();
        if (timeoutCleared) {
          return;
        }
      }
      if (userTimeout.reached) return;
      if (!isDevTools() && +new Date() - startTime > ((_context$appConfig$ma = context === null || context === void 0 ? void 0 : (_context$appConfig3 = context.appConfig) === null || _context$appConfig3 === void 0 ? void 0 : _context$appConfig3.maxStartRetryGap) !== null && _context$appConfig$ma !== void 0 ? _context$appConfig$ma : 60 * 1000)) {
        trace.push(data_pipe_newTraceEntry(`timeout, exceed max retry gap`));
        param.stats.ret = error_config_ERR_CODE.SDK_CONTAINER_POLL_RESULT_EXPIRED;
        return reject(toSDKError({
          errCode: error_config_ERR_CODE.SDK_CONTAINER_POLL_RESULT_EXPIRED,
          errMsg: `timeout for retry, cannot retry fetching the result anymore (callId: ${callID}) (trace: ${data_pipe_traceStr(trace)})`
        }, API_NAME));
      }
      hasTunnelTimeout = true;
      if (options.timeoutErrorRetry > 0) {
        trace.push(data_pipe_newTraceEntry(`timeout, retry`));
        poll(API_NAME, {
          ...options,
          retryType: RetryType.Timeout,
          tryCount: tryCount - 1,
          timeoutErrorRetry: timeoutErrorRetry - 1
        });
      } else {
        trace.push(data_pipe_newTraceEntry(`timeout, abort`));
        param.stats.ret = error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_TIMEOUT_POLL_RETRY;
        reject(toSDKError({
          errCode: error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_TIMEOUT_POLL_RETRY,
          errMsg: `(callId: ${callID}) (trace: ${data_pipe_traceStr(trace)})`
        }, API_NAME));
      }
    }), (context === null || context === void 0 ? void 0 : (_context$appConfig4 = context.appConfig) === null || _context$appConfig4 === void 0 ? void 0 : _context$appConfig4.clientPollTimeout) || data_pipe_DEFAULT_CLIENT_ONE_TIME_POLL_TIMEOUT);
    var handleTunnelStats = res => {
      var _data$baseresponse;
      var data = res.data;
      if (data !== null && data !== void 0 && (_data$baseresponse = data.baseresponse) !== null && _data$baseresponse !== void 0 && _data$baseresponse.stat) {
        if (data.baseresponse.stat.qbase_cost_time) {
          param.context.tunnelTimeNoCSNetCost += data.baseresponse.stat.qbase_cost_time;
        }
      }
    };
    if (userTimeout.reached) return;
    param.stats.requestBodyBytes = serializedReqData.length;
    context.request({
      ...param.config,
      apiName: API_NAME_MAP[API_NAME],
      serviceName: context.name,
      serializedReqData,
      env: ((_param$config = param.config) === null || _param$config === void 0 ? void 0 : _param$config.env) || context.env
    }).then(onTunnelResult).catch(err => {
      if (hasTunnelTimeout || userTimeout.reached) return;
      clearTunnelTimeout();
      if (err !== null && err !== void 0 && err.operateWXDataFail && systemErrorRetry > 0) {
        trace.push(data_pipe_newTraceEntry(`system error (${err}), retry`));
        poll(API_NAME, {
          ...options,
          retryType: RetryType.Error,
          tryCount: tryCount - 1,
          systemErrorRetry: systemErrorRetry - 1
        });
      } else {
        trace.push(data_pipe_newTraceEntry(`system error (${err}), abort`));
        reject(toSDKError(`${err} (callId: ${callID}) (trace: ${data_pipe_traceStr(trace)})`, API_NAME));
      }
    });
    function onTunnelResult(_x10) {
      return _onTunnelResult.apply(this, arguments);
    }
    function _onTunnelResult() {
      _onTunnelResult = asyncToGenerator_default()(function* (res) {
        try {
          if (hasTunnelTimeout || userTimeout.reached) return;
          clearTunnelTimeout();
          handleTunnelStats(res);
          var _data = res.data;
          if (!_data) {
            trace.push(data_pipe_newTraceEntry(`empty resp`));
            param.stats.ret = error_config_ERR_CODE.SDK_CONTAINER_EMPTY_CALL_RESULT;
            return reject(toSDKError({
              errCode: error_config_ERR_CODE.SDK_CONTAINER_EMPTY_CALL_RESULT
            }, API_NAME));
          }
          if (_data.baseresponse && _data.baseresponse.errcode === 0) {
            if (_data.status === 0) {
              if (tryCount >= 0) {
                trace.push(data_pipe_newTraceEntry(`normal poll`));
                poll(API_NAME, {
                  ...options,
                  action: Action.POLL,
                  retryType: RetryType.None,
                  tryCount: tryCount - 1
                });
              } else {
                trace.push(data_pipe_newTraceEntry(`too many polls, abort`));
                param.stats.ret = error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_POLL_RETRY;
                return reject(toSDKError({
                  errCode: error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_POLL_RETRY,
                  errMsg: `(callId: ${callID}) (trace: ${data_pipe_traceStr(trace)})`
                }, API_NAME));
              }
            } else if (_data.status === 1) {
              var resultData;
              if (_data.data_type === DataType.BASE64) {
                resultData = base64ToArrayBuffer(_data.data);
                param.stats.responseBodyBytes = resultData.length;
                if (param.dataType === 'json') {
                  resultData = tryJSONParse(arrayBufferToString(resultData));
                } else if (param.responseType !== 'arraybuffer') {
                  resultData = arrayBufferToString(resultData);
                }
              } else if (_data.data_type === DataType.CDN_URL) {
                try {
                  var __appServiceSDK__ = appserviceSdk_getSDK(context === null || context === void 0 ? void 0 : context.identifiers);
                  var dlRes = yield new Promise((resolve, reject) => {
                    __appServiceSDK__._requestSkipCheckDomain({
                      url: _data.data,
                      dataType: param.dataType,
                      responseType: param.responseType,
                      success: res => {
                        if (res.statusCode !== 200) {
                          reject(`download response status code ${res.statusCode}`);
                        } else {
                          resolve(res);
                        }
                      },
                      fail: err => {
                        reject(err);
                      }
                    });
                  });
                  resultData = dlRes.data;
                } catch (e) {
                  return reject(toSDKError({
                    errCode: error_config_ERR_CODE.SDK_CONTAINER_DOWNLOAD_RESULT_FROM_CDN_FAIL,
                    errMsg: `error: ${e} \n (callId: ${callID}) (trace: ${data_pipe_traceStr(trace)})`
                  }, API_NAME));
                }
              } else {
                resultData = _data.data;
                if (param.responseType === 'arraybuffer') {
                  param.stats.responseBodyBytes = resultData.length;
                  resultData = stringToArrayBuffer(resultData);
                } else if (param.dataType === 'json') {
                  param.stats.responseBodyBytes = resultData.length;
                  resultData = tryJSONParse(resultData);
                }
              }
              return resolve({
                result: {
                  data: resultData,
                  statusCode: _data.http_code,
                  header: _data.headers.reduce((acc, cur) => {
                    var prev = acc[cur.k + ''];
                    acc[cur.k + ''] = prev ? prev + ',' + cur.v : cur.v + '';
                    return acc;
                  }, {})
                }
              });
            } else {
              trace.push(data_pipe_newTraceEntry(`poll result expired`));
              param.stats.ret = error_config_ERR_CODE.SDK_CONTAINER_POLL_RESULT_EXPIRED;
              return reject(toSDKError({
                errCode: error_config_ERR_CODE.SDK_CONTAINER_POLL_RESULT_EXPIRED,
                errMsg: `timeout for result fetching, result cannot be fetched anymore (callId: ${callID}) (trace: ${data_pipe_traceStr(trace)})`
              }, API_NAME));
            }
          } else {
            if (!_data.baseresponse) {
              param.stats.ret = error_config_ERR_CODE.SDK_CONTAINER_EMPTY_POLL_RESULT_BASE_RESP;
              return reject(toSDKError({
                errCode: error_config_ERR_CODE.SDK_CONTAINER_EMPTY_POLL_RESULT_BASE_RESP
              }, API_NAME));
            } else if (_data.baseresponse.errcode !== 0) {
              param.stats.ret = error_config_ERR_CODE.SDK_CONTAINER_POLL_RESULT_BASE_RESP_RET_ABNORMAL;
              return reject(toSDKError({
                errCode: error_config_ERR_CODE.SDK_CONTAINER_POLL_RESULT_BASE_RESP_RET_ABNORMAL,
                errMsg: `polling base_resp.errcode ${_data.baseresponse.errcode} errmsg ${_data.baseresponse.errmsg} (callId: ${callID})`
              }, API_NAME));
            } else {
              param.stats.ret = error_config_ERR_CODE.SDK_CONTAINER_EMPTY_POLL_RESULT_BASE_RESP;
              return reject(toSDKError({
                errCode: error_config_ERR_CODE.SDK_CONTAINER_EMPTY_POLL_RESULT_BASE_RESP,
                errMsg: `polling base_resp ${JSON.stringify(_data.baseresponse)} (callId: ${callID})`
              }, API_NAME));
            }
          }
        } catch (err) {
          param.stats.ret = error_config_ERR_CODE.SDK_CONTAINER_POLL_ERROR;
          reject(toSDKError({
            errCode: error_config_ERR_CODE.SDK_CONTAINER_POLL_ERROR,
            errMsg: `polling catch error: ${err} (callId: ${callID})`
          }, API_NAME));
        }
      });
      return _onTunnelResult.apply(this, arguments);
    }
  });
  return _poll.apply(this, arguments);
}
function monitorAppVisiblity(trace, resolve, reject) {
  var listener = event => {
    trace.push(data_pipe_newTraceEntry(`app ${event}`));
  };
  onAppVisibilityChange(listener);
  var _resolve = v => {
    offAppVisibilityChange(listener);
    resolve(v);
  };
  var _reject = v => {
    offAppVisibilityChange(listener);
    reject(v);
  };
  return {
    resolve: _resolve,
    reject: _reject
  };
}
;// CONCATENATED MODULE: ./src/services/container/api/callContainer/v2.ts



var callContainer_v2_API_NAME = 'cloud.callContainer';
function v2_getCallContainerAPI(context) {
  return /*#__PURE__*/function () {
    var _callContainer = asyncToGenerator_default()(function* (param) {
      var _param$config;
      var {
        tunnelReqDataType,
        callID
      } = yield processDataPipeParam(param);
      param.header = {
        ...param.header,
        'X-WX-ENV': context.isInstance ? context.env : ((_param$config = param.config) === null || _param$config === void 0 ? void 0 : _param$config.env) || context.env,
        'X-WX-CONTAINER-PATH': param.path
      };
      if (param.service) {
        param.header['X-WX-SERVICE'] = param.service;
      }
      param.context.tunnelStartTime = +new Date();
      var {
        result
      } = yield callAndWaitResult(callContainer_v2_API_NAME, param, param.data, tunnelReqDataType, callID, context);
      param.context.tunnelEndTime = +new Date();
      return {
        ...result,
        errMsg: apiSuccessMsg(callContainer_v2_API_NAME),
        callID
      };
    });
    function callContainer(_x) {
      return _callContainer.apply(this, arguments);
    }
    return callContainer;
  }();
}
;// CONCATENATED MODULE: ./src/services/container/api/callContainer/v3.ts








var v3_API_NAME = 'cloud.callContainer';
function v3_getCallContainerAPI(context) {
  return /*#__PURE__*/function () {
    var _callContainer = asyncToGenerator_default()(function* (param) {
      var endpoint = context.serviceEndpoint.getEndpointSync('container');
      var cdnMap = new WeakMap();
      if (param.cdnMapPromise || !endpoint) {
        var list = yield Promise.all([param.cdnMapPromise, v3_autoTiming(context.serviceEndpoint.getEndpoint('container'), param.stats, 'getServiceEndpoint')]);
        if (list[0]) {
          cdnMap = list[0];
        }
        endpoint = list[1];
      } else {
        param.stats.getServiceEndpoint = 0;
      }
      if (param.shouldSerialize) {
        param.data = serialize(param.data, cdnMap);
      }
      if (endpoint.http) {
        return requestRunContainerPrivateHTTP(endpoint, param);
      }
      return requestRunContainer(endpoint.url, param);
    });
    function callContainer(_x) {
      return _callContainer.apply(this, arguments);
    }
    return callContainer;
  }();
  function requestRunContainerPrivateHTTP(endpoint, param) {
    return new Promise((resolve, reject) => {
      var _param$config;
      param.stats.tsCallContainerImplStart = Date.now();
      var __appServiceSDK__ = appserviceSdk_getSDK(context.identifiers);
      var outerRequestHeader = {
        'X-WX-EV': 3,
        'Content-Type': 'application/octet-stream'
      };
      var callId = `${Math.random()}_${Date.now()}`;
      var header = {
        ...param.header,
        'X-WX-ENV': context.isInstance ? context.env : ((_param$config = param.config) === null || _param$config === void 0 ? void 0 : _param$config.env) || context.env,
        'X-WX-SERVICE': param.service,
        'X-WX-CONTAINER-PATH': param.path,
        'X-WX-CALL-ID': callId
      };
      if (context.appid) {
        header['X-WX-RESOURCE-APPID'] = context.appid;
      }
      var stats = param.stats;
      stats.callid = callId;
      var ts = Date.now();
      var key = new Uint8Array(__appServiceSDK__.wx.base64ToArrayBuffer(endpoint.key));
      var {
        data: encReq
      } = dist.V3.encodeRequest(key, header, param.method || 'GET', param.data);
      stats.encrypt = Date.now() - ts;
      ts = Date.now();
      var useDomain = true;
      var url = endpoint.url;
      if (param.rdm) {
        url = `https://wxardm.weixin.qq.com/wxa-qbase/container_service?token=${endpoint.token}`;
      } else if (param.ecdn) {
        url = `https://cloudbase.servicewechat.com/wxa-qbase/container_service?token=${endpoint.token}`;
      }
      param.verbose && console.log(`[cloud.callContainer] url ${url}`);
      if (useDomain && endpoint.domain) {
        param.stats.domain = endpoint.domain;
      }
      stats.requestBodyBytes = encReq.byteLength;
      stats.requestStartTs = Date.now();
      if (!limiter.allowRequest()) {
        reject(toSDKError({
          errCode: error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_SERVER_REQUEST_COUNT,
          errMsg: `error: exceed max client request count, avoid infinite loop in your code`
        }, v3_API_NAME));
        return;
      }
      __appServiceSDK__._requestSkipCheckDomain({
        url,
        method: 'POST',
        header: outerRequestHeader,
        data: encReq.buffer,
        dataType: 'arraybuffer',
        responseType: 'arraybuffer',
        timeout: param.timeout,
        enableHttp2: useDomain,
        success: res => {
          try {
            for (var _key in res.header) {
              if (_key.toLowerCase() === 'x-nws-log-uuid') {
                param.verbose && console.log(`[cloud.callContainer] x-nws-log-uuid ${res.header[_key]}`);
                param.stats.ecdnId = res.header[_key];
              }
              if (_key.toLowerCase() === 'x-edge-timing') {
                param.stats.ecdnEdgeTiming = res.header[_key];
              }
              if (_key.toLowerCase() === 'x-wx-system-error') {
                var code = Number(res.header[_key]);
                if (code === 102003) {
                  limiter.markServerLimitExceed();
                }
                reject({
                  errCode: code,
                  errMsg: `${v3_API_NAME}:fail system error. code: ${code}`
                });
                return;
              }
            }
            stats.profile = res.profile;
            stats.httpRequest = Date.now() - ts;
            if (res.statusCode === 200) {
              var resData = res.data;
              stats.responseBodyBytes = resData.byteLength;
              ts = Date.now();
              var decrypted = dist.V3.decodeResponse(key, new Uint8Array(resData));
              stats.decrypt = Date.now() - ts;
              for (var _key2 in res.header) {
                if (_key2.toLowerCase() === 'x-wx-server-timing') {
                  var serverTiming = res.header[_key2] || '';
                  var rawNumStrs = serverTiming.split(',');
                  if (rawNumStrs.length >= 2) {
                    stats.serverStartTs = Number(rawNumStrs[0]);
                    stats.serverEndTs = Number(rawNumStrs[1]);
                  }
                }
              }
              ts = Date.now();
              var body;
              var rawBody = decrypted.body;
              if (param.dataType === 'json') {
                var str = typeof rawBody === 'string' ? rawBody : arrayBufferToString(rawBody.buffer);
                body = tryJSONParse(str);
              } else if (param.responseType === 'text') {
                body = typeof rawBody === 'string' ? rawBody : arrayBufferToString(rawBody.buffer);
              } else if (param.responseType === 'arraybuffer') {
                body = typeof rawBody === 'string' ? stringToArrayBuffer(rawBody) : rawBody.buffer;
              } else {
                body = rawBody;
              }
              stats.decodeBody = Date.now() - ts;
              stats.responseProcessEndTs = Date.now();
              resolve({
                statusCode: decrypted.statusCode,
                header: decrypted.header,
                data: body,
                stats,
                callID: callId,
                errMsg: `${v3_API_NAME}:ok`
              });
            } else {
              var _code = -1;
              for (var _key3 in res.header) {
                if (_key3.toLowerCase() === 'x-wx-system-error') {
                  _code = Number(res.header[_key3]);
                }
                if (_code === 102003) {
                  limiter.markServerLimitExceed();
                }
              }
              reject({
                errCode: _code,
                errMsg: `${v3_API_NAME}:fail system error, status ${res.statusCode}. code: ${_code}`
              });
            }
          } catch (e) {
            reject({
              errCode: -1,
              errMsg: `${v3_API_NAME}:fail error while processing internal response ${e}`
            });
          }
        },
        fail: err => {
          reject({
            ...err,
            errMsg: err.errMsg.replace(/^request/, v3_API_NAME)
          });
        }
      });
    });
  }
  function requestRunContainer(_x2, _x3) {
    return _requestRunContainer.apply(this, arguments);
  }
  function _requestRunContainer() {
    _requestRunContainer = asyncToGenerator_default()(function* (url, param) {
      return new Promise((resolve, reject) => {
        var _param$config2;
        var __appServiceSDK__ = appserviceSdk_getSDK(context.identifiers);
        var header = {
          ...param.header,
          'X-WX-ENV': context.isInstance ? context.env : ((_param$config2 = param.config) === null || _param$config2 === void 0 ? void 0 : _param$config2.env) || context.env,
          'X-WX-SERVICE': param.service,
          'X-WX-CONTAINER-PATH': param.path,
          'X-WX-CALL-ID': `${Math.random()}_${Date.now()}`,
          'X-WX-USER-TIMEOUT': param.timeout
        };
        if (context.appid) {
          header['X-WX-RESOURCE-APPID'] = context.appid;
        }
        if (!limiter.allowRequest()) {
          reject(toSDKError({
            errCode: error_config_ERR_CODE.SDK_CONTAINER_EXCEED_MAX_SERVER_REQUEST_COUNT,
            errMsg: `error: exceed max client request count, avoid infinite loop in your code`
          }, v3_API_NAME));
          return;
        }
        __appServiceSDK__._requestSkipCheckDomain({
          url,
          method: param.method,
          header,
          data: param.data,
          dataType: param.dataType,
          responseType: param.responseType,
          timeout: param.timeout,
          success: res => {
            resolve({
              ...res,
              errMsg: `${v3_API_NAME}:ok`
            });
          },
          fail: err => {
            reject({
              ...err,
              errMsg: err.errMsg.replace(/^request/, v3_API_NAME)
            });
          }
        });
      });
    });
    return _requestRunContainer.apply(this, arguments);
  }
}
function v3_autoTiming(promise, timing, name) {
  var t = Date.now();
  promise.then(() => timing[name] = Date.now() - t).catch(() => timing[name] = Date.now() - t);
  return promise;
}
;// CONCATENATED MODULE: ./src/services/container/api/callContainer.ts


















var callContainer_API_NAME = 'cloud.callContainer';
var CACHE_MANAGER_STATE = {
  OFF: 0,
  ON: 1,
  UNKNOWN: 2
};
var _isFirstCall = true;
var _pendingCall = 0;
var callContainer_REDIRECT_MAX_CALL = 6;
var callContainer_redirectPromiseCount = new WeakMap();
function callContainer_getCallContainerAPI(context) {
  var versions = [undefined, getCallContainerAPI(context), v2_getCallContainerAPI(context), v3_getCallContainerAPI(context)];
  function get(v) {
    return versions[v];
  }
  return function callContainer(param) {
    var apiStartTime = +new Date();
    assertType(param, 'object');
    var _param = shallowClone(param);
    if (!_param.data) {
      _param.data = {};
    }
    if (!_param.dataType) {
      _param.dataType = 'json';
    }
    _param.context = {
      tunnelTimeNoCSNetCost: 0,
      apiStartTime,
      warmStartTime: getWarmStartTs()
    };
    _param.stats = {
      apiStartTime: apiStartTime
    };
    if (hasAPICallback(_param)) {
      return callContainerCallbackStyle(_param);
    } else {
      return callContainerPromiseStyle(_param);
    }
  };
  function checkParam(param) {
    var _param$config;
    if (!param.service) {}
    if (context.isInstance) {
      if (!context.env) {
        throw new Error(`envId must be provided`);
      }
    } else if ((_param$config = param.config) !== null && _param$config !== void 0 && _param$config.env) {
      assertType(param.config.env, 'string');
    } else if (!context.env) {
      throw new Error(`envId must be provided`);
    }
  }
  function callContainerCallbackStyle(param) {
    wrapParamCallbacksWithTryCatch({
      apiName: callContainer_API_NAME,
      param
    });
    callContainerPromiseStyle(param).then(res => {
      invokeSuccessCompleteCallbacks(callContainer_API_NAME, param, res);
    }).catch(err => {
      invokeFailCompleteCallbacks(callContainer_API_NAME, param, err);
    });
  }
  function callContainerPromiseStyle(_x) {
    return _callContainerPromiseStyle.apply(this, arguments);
  }
  function _callContainerPromiseStyle() {
    _callContainerPromiseStyle = asyncToGenerator_default()(function* (param) {
      var useV1 = false;
      try {
        _pendingCall++;
        checkParam(param);
        processParam(param);
        param.cdnMapPromise = param.shouldSerialize ? collect(param.data) : undefined;
        var timestampMs = Date.now();
        useV1 = _isFirstCall ? (_isFirstCall = false, yield shouldUseV1(param)) : shouldUseV1Sync(param);
        param.stats.tsBeforeCallContainerImpl = Date.now();
        var copyParams = shallowClone(param);
        var originalData = param.data;
        var promise = getRequestPromise(param, useV1);
        var url;
        var serviceName = param.service || param.header['X-WX-SERVICE'];
        if (serviceName) {
          url = `wx.cloud.callContainer.${serviceName}${param.path}`;
        } else {
          url = `wx.cloud.callContainer${param.path}`;
        }
        autoDevtoolsNetworkLog(promise, () => {
          var _param$config3;
          return {
            url,
            method: param.method,
            headers: {
              Env: context.isInstance ? context.env : ((_param$config3 = param.config) === null || _param$config3 === void 0 ? void 0 : _param$config3.env) || context.env,
              ...param.header
            },
            reqBody: serialize(originalData),
            timestampMs,
            console: context.debug
          };
        });
        var checkFollowRedirect = followRedirect(copyParams, promise);
        var useCachePromise = offlineCache(copyParams, checkFollowRedirect);
        var result = yield useCachePromise;
        report(param, useV1);
        deferKeepAlive();
        return result;
      } catch (err) {
        throw returnAsFinalCloudSDKError(err, callContainer_API_NAME);
      } finally {
        _pendingCall--;
        if (_pendingCall === 0) {
          (0,dist/* loadAccelerator */.e)(appserviceSdk_getSDK()._WebAssembly);
        }
      }
    });
    return _callContainerPromiseStyle.apply(this, arguments);
  }
  function shouldUseV1(_x2) {
    return _shouldUseV.apply(this, arguments);
  }
  function _shouldUseV() {
    _shouldUseV = asyncToGenerator_default()(function* (param) {
      var hasEndpoint = Boolean(context.serviceEndpoint.getEndpointSync('container'));
      if (!hasEndpoint) {
        var timeout = new Promise(r => setTimeout(r, 50));
        var endpointPromise = context.serviceEndpoint.getEndpoint('container').catch(() => {});
        yield Promise.race([timeout, endpointPromise]);
      }
      return shouldUseV1Sync(param);
    });
    return _shouldUseV.apply(this, arguments);
  }
  function shouldUseV1Sync(param) {
    if (getSystemInfo().platform === 'windows') {
      return false;
    }
    if (param.apiVersion === 1) {
      return true;
    }
    if (param.apiVersion === 2) {
      return false;
    }
    return Boolean(context.serviceEndpoint.getEndpointSync('container'));
  }
  function getRequestPromise(param, useV1) {
    var _useV;
    var promise;
    useV1 = (_useV = useV1) !== null && _useV !== void 0 ? _useV : shouldUseV1Sync(param);
    if (useV1) {
      var copyParams = {
        ...param,
        stats: {
          ...param.stats
        }
      };
      promise = get(1)(param).catch(e => {
        if ((e === null || e === void 0 ? void 0 : e.errCode) === -9999) {
          return get(2)(copyParams);
        }
        throw e;
      });
    } else {
      promise = get(2)(param);
    }
    return promise;
  }
  function report(param, useV1) {
    param.stats.protocol = useV1 ? `v1/${param.stats.backend}` : 'im';
    reportCallContainerLike(callContainer_API_NAME, param);
  }
  function offlineCache(param, request) {
    var _param$config2;
    if (context.identifiers.pluginId) return request;
    var __appServiceSDK__ = appserviceSdk_getSDK(context.identifiers);
    var isUsedCache = __appServiceSDK__.isUsedCache();
    if (!isUsedCache) return request;
    var abortableRequest = getPromiseWithAbort(request);
    var reportCallContainer = __appServiceSDK__.reportCallContainer;
    var privateCacheManager = __appServiceSDK__.privateCacheManager;
    var cacheManager = __appServiceSDK__.cacheManager;
    var start = Date.now();
    var {
      data,
      method
    } = param;
    var env = ((_param$config2 = param.config) === null || _param$config2 === void 0 ? void 0 : _param$config2.env) || context.env;
    var url = `https://wx.cloud.callContainer/${env}`;
    var serviceName = param.service;
    if (!serviceName) {
      for (var key in param.header) {
        if (key.toUpperCase() === 'X-WX-SERVICE') {
          serviceName = param.header[key];
        }
      }
    }
    if (serviceName) {
      url += `/${serviceName}${param.path}`;
    } else {
      url += param.path;
    }
    var triggerRequest = (success, fail, err) => {
      var req = () => {
        return new Promise((res, rej) => {
          request.then(res).catch(rej);
        });
      };
      var res = privateCacheManager.emit('request', {
        url,
        data,
        method,
        request: req
      });
      if (res.length) {
        var promise = res.find(item => item && typeof item.then === 'function');
        if (promise) {
          promise.then(success).catch(fail).finally(() => {
            abortableRequest.abort();
          });
        }
        return;
      }
      if (err) {
        fail(err);
      }
    };
    return new Promise((resolve, reject) => {
      var res = resp => {
        reportCallContainer({
          isSuccess: true,
          costTime: Date.now() - start,
          extra1: url
        });
        resolve(resp);
      };
      var rej = e => {
        reportCallContainer({
          isSuccess: false,
          costTime: Date.now() - start,
          extra1: url
        });
        reject(e);
      };
      var cacheAndSuccess = resp => {
        privateCacheManager.checkNeedStore(url, data, method, resp);
        res(resp);
      };
      if (cacheManager.state === CACHE_MANAGER_STATE.UNKNOWN) {
        request.then(resp => {
          cacheAndSuccess(resp);
        }).catch(e => {
          triggerRequest(res, rej, e);
        });
      } else if (cacheManager.state === CACHE_MANAGER_STATE.ON) {
        triggerRequest(res, rej);
      } else if (cacheManager.state === CACHE_MANAGER_STATE.OFF) {
        request.then(resp => {
          cacheAndSuccess(resp);
        }).catch(e => {
          rej(e);
        });
      }
    });
  }
  function getPromiseWithAbort(p) {
    var obj = {
      abort: () => {},
      promise: Promise.resolve()
    };
    var p1 = new Promise((_, reject) => {
      obj.abort = reject;
    });
    obj.promise = Promise.race([p, p1]);
    return obj;
  }
  function followRedirect(_param, _request) {
    var _param$followRedirect;
    var followRedirectParam = (_param$followRedirect = _param.followRedirect) !== null && _param$followRedirect !== void 0 ? _param$followRedirect : true;
    if (!followRedirectParam) return _request;
    function getFollowRedirectPromise(param, request) {
      return new Promise((resolve, reject) => {
        request.then(resp => {
          var _redirectPromiseCount;
          if (!is3XXResponse(resp.statusCode)) {
            resolve(resp);
            return;
          }
          var count = (_redirectPromiseCount = callContainer_redirectPromiseCount.get(_request)) !== null && _redirectPromiseCount !== void 0 ? _redirectPromiseCount : 0;
          if (count >= callContainer_REDIRECT_MAX_CALL) {
            reject('reach the max redirect count');
            return;
          }
          callContainer_redirectPromiseCount.set(_request, count + 1);
          var location = '';
          for (var key in resp.header) {
            if (key.toLowerCase() === 'location') location = resp.header[key];
          }
          if (!location) {
            resolve(resp);
            return;
          }
          if (location.startsWith('/')) {
            var copyParams = shallowClone(param);
            param.path = location;
            var requestPromise = getRequestPromise(param);
            getFollowRedirectPromise(copyParams, requestPromise).then(resolve).catch(reject);
          } else {
            var __appServiceSDK__ = appserviceSdk_getSDK(context.identifiers);
            __appServiceSDK__.request({
              url: location,
              method: param.method,
              header: param.header,
              data: param.data,
              dataType: param.dataType,
              responseType: param.responseType,
              timeout: param.timeout,
              success: res => {
                resolve({
                  ...res,
                  errMsg: `${callContainer_API_NAME}:ok`
                });
              },
              fail: err => {
                reject(err.errMsg.replace(/^request/, callContainer_API_NAME));
              }
            });
          }
        }).catch(reject);
      });
    }
    return getFollowRedirectPromise(_param, _request);
  }
}
;// CONCATENATED MODULE: ./src/services/container/api/connectContainer.ts







var connectContainer_API_NAME = 'cloud.connectContainer';
function getConnectContainerAPI(context) {
  return function connectContainer(param) {
    var _param = shallowClone(param);
    _param.timing = {
      apiStartTime: +new Date()
    };
    if (hasAPICallback(_param)) {
      return connectContainerCallbackStyle(_param);
    } else {
      var promise = connectContainerPromiseStyle(_param);
      return promise;
    }
  };
  function checkParam(param) {
    if (param.config) {
      if (param.config.env) {
        assertType(param.config.env, 'string');
      }
    }
  }
  function connectContainerCallbackStyle(param) {
    var promise = connectContainerPromiseStyle(param);
    promise.then(res => {
      invokeSuccessCompleteCallbacks(connectContainer_API_NAME, param, res);
    }).catch(err => {
      invokeFailCompleteCallbacks(connectContainer_API_NAME, param, err);
    });
  }
  function connectContainerPromiseStyle(_x) {
    return _connectContainerPromiseStyle.apply(this, arguments);
  }
  function _connectContainerPromiseStyle() {
    _connectContainerPromiseStyle = asyncToGenerator_default()(function* (param) {
      try {
        checkParam(param);
        var result = yield connectContainer_(param);
        return result;
      } catch (err) {
        throw err;
      } finally {
        reportAPISpeed({
          ...param.timing,
          apiEndTime: +new Date(),
          apiName: connectContainer_API_NAME
        });
      }
    });
    return _connectContainerPromiseStyle.apply(this, arguments);
  }
  function connectContainer_(_x2) {
    return _connectContainer_.apply(this, arguments);
  }
  function _connectContainer_() {
    _connectContainer_ = asyncToGenerator_default()(function* (param) {
      var reqData = {
        service_name: param.service
      };
      var serializedReqData = JSON.stringify(reqData);
      param.timing.tunnelStartTime = +new Date();
      var res = yield context.request({
        ...param.config,
        apiName: 'tcbapi_get_websocket_info',
        serviceName: context.name,
        serializedReqData,
        env: param.config && param.config.env || context.env
      });
      param.timing.tunnelEndTime = +new Date();
      var data = res.data;
      var {
        success,
        complete,
        ...restRawParam
      } = param;
      var socketTask = appserviceSdk_getSDK(context.identifiers)._socketSkipCheckDomainFactory().connectSocket({
        ...restRawParam,
        url: `wss://${data.host}${param.path || ''}`,
        header: {
          ...restRawParam.header,
          'content-type': 'application/json',
          'x-wx-token': data.token
        },
        perMessageDeflate: true
      });
      return {
        errMsg: apiSuccessMsg(connectContainer_API_NAME),
        socketTask
      };
    });
    return _connectContainer_.apply(this, arguments);
  }
}
;// CONCATENATED MODULE: ./src/services/container/api/api.ts


function api_getAPIs(context) {
  return {
    callContainer: callContainer_getCallContainerAPI(context),
    connectContainer: getConnectContainerAPI(context)
  };
}
;// CONCATENATED MODULE: ./src/services/container/index.ts

var CONTAINER_SERVICE_NAME = 'container';
function createContainerService(cloud) {
  var context = {
    name: CONTAINER_SERVICE_NAME,
    identifiers: cloud.identifiers,
    request: cloud.request,
    isInstance: cloud.isInstance,
    serviceEndpoint: cloud.serviceEndpoint,
    get debug() {
      return cloud.debug;
    },
    get appid() {
      return cloud.isInstance ? cloud.instanceOptions.resourceAppid : undefined;
    },
    get env() {
      return cloud.getEnvForService(CONTAINER_SERVICE_NAME);
    },
    appConfig: {
      get maxPollRetry() {
        return cloud.appConfig.call_container_poll_max_retry;
      },
      get clientPollTimeout() {
        return cloud.appConfig.call_container_client_poll_timeout;
      },
      get maxStartRetryGap() {
        return cloud.appConfig.call_container_valid_start_retry_gap;
      }
    }
  };
  return {
    name: CONTAINER_SERVICE_NAME,
    context,
    getAPIs: api_getAPIs.bind(null, context)
  };
}
function container_registerService(cloud) {
  cloud.registerService(createContainerService(cloud));
}
;// CONCATENATED MODULE: external "{}"
const external_namespaceObject = {};
;// CONCATENATED MODULE: ./src/runtime/runtime.ts
// if you want to modify the following path, you MUST also modify the webpack config (build/common.js) which excludes it from bundle

var runtime = {
  env: '',
  platform: ''
};
var getRuntimeInfo = () => runtime;
var setRuntimeInfo = platform => {
  runtime.platform = platform;
  runtime.env = 'web';
};
if (typeof __wxConfig !== 'undefined') {
  runtime.env = 'miniprogram';
  runtime.platform = __wxConfig.platform;
  if (__wxConfig.host && __wxConfig.host.env === 'SAAASDK') {
    runtime.platform = 'sdk';
  }
} else {
  runtime.env = 'web';
  if (window) {
    if (window.__wxjs_environment && window.__wxjs_environment === 'miniprogram') {
      runtime.platform = 'miniprogram';
    } else {
      var ua = window.navigator.userAgent.toLowerCase();
      if (/MicroMessenger/i.test(ua)) {
        runtime.platform = 'wxweb';
      }
    }
  }
}
;// CONCATENATED MODULE: ./src/services/storage/api/uploadFile.ts











var uploadFile_API_NAME = 'cloud.uploadFile';
var REPORT_API_NAME = 'cloud.uploadFile_v2';
function getUploadFileAPI(context) {
  return function uploadFile(param) {
    param = shallowClone(param);
    if (hasAPICallback(param)) {
      return uploadFileCallbackStyle(param);
    } else {
      var timing = {
        apiStartTime: +new Date()
      };
      return uploadFilePromiseStyle({
        ...param,
        timing
      });
    }
  };
  function uploadFileCallbackStyle(param) {
    var context = {
      aborted: false
    };
    var agent = createUploadTaskAgent(context);
    var timing = {
      apiStartTime: +new Date()
    };
    uploadFilePromiseStyle({
      ...param,
      context,
      timing,
      uploadTaskAgent: agent
    }).then(res => {
      invokeSuccessCompleteCallbacks(uploadFile_API_NAME, param, res);
    }).catch(err => {
      invokeFailCompleteCallbacks(uploadFile_API_NAME, param, err);
    });
    return agent;
  }
  function createUploadTaskAgent(context) {
    return {
      onProgressUpdate: function (fn) {
        context.onProgressUpdateUserHandler = fn;
      },
      abort: function () {
        if (context.abort) {
          context.abort();
        }
        context.aborted = true;
      }
    };
  }
  function uploadFilePromiseStyle(param) {
    return new Promise(/*#__PURE__*/function () {
      var _ref = asyncToGenerator_default()(function* (resolve, reject) {
        try {
          checkParam(param);
          if (param.context) {
            param.context.abort = function () {
              reject(returnAsFinalCloudSDKError({
                errMsg: 'abort'
              }, uploadFile_API_NAME));
            };
            if (param.context.aborted) {
              return reject(returnAsFinalCloudSDKError({
                errMsg: 'abort'
              }, uploadFile_API_NAME));
            }
          }
          var result = yield uploadFile_(param);
          resolve(result);
        } catch (err) {
          reject(returnAsFinalCloudSDKError(err, uploadFile_API_NAME));
        } finally {
          reportAPISpeed({
            ...param.timing,
            apiEndTime: +new Date(),
            apiName: REPORT_API_NAME
          });
        }
      });
      return function (_x, _x2) {
        return _ref.apply(this, arguments);
      };
    }());
  }
  function uploadFile_(_x3) {
    return _uploadFile_.apply(this, arguments);
  }
  function _uploadFile_() {
    _uploadFile_ = asyncToGenerator_default()(function* (param) {
      var __appServiceSDK__ = appserviceSdk_getSDK(context.identifiers);
      var uploadInfo = yield getUploadInfo(param);
      return new Promise((resolve, reject) => {
        if (param.context && param.context.aborted) {
          return reject(returnAsFinalCloudSDKError({
            errMsg: 'abort'
          }, uploadFile_API_NAME));
        }
        var uploadOptions;
        var uploadTask;
        var runtimeInfo = getRuntimeInfo();
        if (runtimeInfo.env === 'web') {
          var formData = new FormData();
          formData.append('key', param.cloudPath);
          formData.append('signature', uploadInfo.authorization);
          formData.append('x-cos-security-token', uploadInfo.token);
          formData.append('x-cos-meta-fileid', uploadInfo.cos_file_id);
          formData.append('file', param.file);
          uploadOptions = {
            url: uploadInfo.url,
            timeout: param.timeout,
            filePath: '',
            header: param.header,
            name: '',
            formData
          };
        } else {
          uploadOptions = {
            url: uploadInfo.url,
            timeout: param.timeout,
            filePath: param.filePath,
            header: param.header,
            name: 'file',
            formData: {
              key: param.cloudPath,
              signature: uploadInfo.authorization,
              'x-cos-security-token': uploadInfo.token,
              'x-cos-meta-fileid': uploadInfo.cos_file_id
            }
          };
        }
        uploadTask = __appServiceSDK__._uploadFileSkipCheckDomain({
          ...uploadOptions,
          success: res => {
            try {
              if (res.statusCode >= 200 && res.statusCode < 300) {
                resolve({
                  errMsg: apiSuccessMsg(uploadFile_API_NAME),
                  fileID: uploadInfo.file_id,
                  statusCode: res.statusCode
                });
              } else {
                var err = new error_CloudSDKError({
                  errMsg: `status ${res.statusCode}, error: ${res.data};`
                });
                reject(err);
              }
            } catch (err) {
              var error = new error_CloudSDKError({
                errMsg: `Error : ${res.data};`
              });
              reject(error);
            }
          },
          fail: err => {
            reject(err);
          }
        });
        if (uploadTask) {
          uploadTask.onProgressUpdate(function () {
            if (param.uploadTaskAgent && param.context && param.context.onProgressUpdateUserHandler) {
              if (isFunction(param.context.onProgressUpdateUserHandler)) {
                param.context.onProgressUpdateUserHandler.apply(__appServiceSDK__._uploadFileSkipCheckDomain, arguments);
              }
            }
          });
          if (param.context) {
            param.context.abort = uploadTask.abort.bind(uploadTask);
          }
        }
      });
    });
    return _uploadFile_.apply(this, arguments);
  }
  function checkParam(param) {
    assertType(param, {
      cloudPath: 'string'
    });
    if (getRuntimeInfo().env === 'miniprogram') {
      assertType(param, {
        filePath: 'string'
      });
    } else {
      assertRequiredParam(param, 'file', 'uploadFile');
    }
  }
  function getUploadInfo(_x4) {
    return _getUploadInfo.apply(this, arguments);
  }
  function _getUploadInfo() {
    _getUploadInfo = asyncToGenerator_default()(function* (param) {
      var serializedReqData = JSON.stringify({
        path: param.cloudPath
      });
      var tunnelStartTime = +new Date();
      var res = yield context.request({
        apiName: 'tcbapi_cos_uploadfile',
        serviceName: context.name,
        serializedReqData,
        env: param.config && param.config.env || context.env
      });
      var resData = res.data;
      if (param.timing) {
        param.timing.tunnelStartTime = tunnelStartTime;
        param.timing.tunnelEndTime = +new Date();
        param.timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
      }
      if (resData.url) {} else {
        throw new error_CloudSDKError({
          errCode: error_config_ERR_CODE.SDK_STORAGE_INTERNAL_SERVER_ERROR_EMPTY_UPLOAD_URL,
          errMsg: error_config_ERR_CODE[error_config_ERR_CODE.SDK_STORAGE_INTERNAL_SERVER_ERROR_EMPTY_UPLOAD_URL]
        });
      }
      return resData;
    });
    return _getUploadInfo.apply(this, arguments);
  }
}
;// CONCATENATED MODULE: ./src/services/storage/api/downloadFile.ts









var downloadFile_API_NAME = 'cloud.downloadFile';
function getDownloadFileAPI(context) {
  return function downloadFile(param) {
    param = shallowClone(param);
    if (hasAPICallback(param)) {
      return downloadFileCallbackStyle(param);
    } else {
      var timing = {
        apiStartTime: +new Date()
      };
      return downloadFilePromiseStyle({
        ...param,
        timing
      });
    }
  };
  function downloadFileCallbackStyle(param) {
    var context = {
      aborted: false
    };
    var agent = createDownloadTaskAgent(context);
    var timing = {
      apiStartTime: +new Date()
    };
    downloadFilePromiseStyle({
      ...param,
      context,
      timing,
      downloadTaskAgent: agent
    }).then(res => {
      invokeSuccessCompleteCallbacks(downloadFile_API_NAME, param, res);
    }).catch(err => {
      invokeFailCompleteCallbacks(downloadFile_API_NAME, param, err);
    });
    return agent;
  }
  function downloadFilePromiseStyle(_x) {
    return _downloadFilePromiseStyle.apply(this, arguments);
  }
  function _downloadFilePromiseStyle() {
    _downloadFilePromiseStyle = asyncToGenerator_default()(function* (param) {
      return new Promise(/*#__PURE__*/function () {
        var _ref = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            checkParam(param);
            if (param.context) {
              param.context.abort = function () {
                reject(returnAsFinalCloudSDKError({
                  errMsg: 'abort'
                }, downloadFile_API_NAME));
              };
              if (param.context.aborted) {
                return reject(returnAsFinalCloudSDKError({
                  errMsg: 'abort'
                }, downloadFile_API_NAME));
              }
            }
            var result = yield downloadFile_(param);
            resolve(result);
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, downloadFile_API_NAME));
          } finally {
            reportAPISpeed({
              ...param.timing,
              apiEndTime: +new Date(),
              apiName: downloadFile_API_NAME
            });
          }
        });
        return function (_x4, _x5) {
          return _ref.apply(this, arguments);
        };
      }());
    });
    return _downloadFilePromiseStyle.apply(this, arguments);
  }
  function createDownloadTaskAgent(context) {
    return {
      onProgressUpdate: function (fn) {
        context.onProgressUpdateUserHandler = fn;
      },
      abort: function () {
        if (context.abort) {
          context.abort();
        }
        context.aborted = true;
      }
    };
  }
  function checkParam(param) {
    assertType(param, {
      fileID: 'string'
    });
    if (param.config) {
      if (param.config.env) {
        assertType(param.config.env, 'string');
      }
    }
  }
  function downloadFile_(_x2) {
    return _downloadFile_.apply(this, arguments);
  }
  function _downloadFile_() {
    _downloadFile_ = asyncToGenerator_default()(function* (param) {
      var __appServiceSDK__ = appserviceSdk_getSDK(context.identifiers);
      var downloadURL = yield getDownloadURL(param);
      return new Promise((resolve, reject) => {
        if (param.context && param.context.aborted) {
          return reject(returnAsFinalCloudSDKError({
            errMsg: 'abort'
          }, downloadFile_API_NAME));
        }
        var downloadTask = __appServiceSDK__._downloadFileSkipCheckDomain({
          url: downloadURL,
          header: param.header,
          timeout: param.timeout,
          success: res => {
            resolve(res);
          },
          fail: err => {
            reject(err);
          }
        });
        if (downloadTask) {
          downloadTask.onProgressUpdate(function () {
            if (param.downloadTaskAgent && param.context && param.context.onProgressUpdateUserHandler) {
              if (isFunction(param.context.onProgressUpdateUserHandler)) {
                param.context.onProgressUpdateUserHandler.apply(__appServiceSDK__._downloadFileSkipCheckDomain, arguments);
              }
            }
          });
          if (param.context) {
            param.context.abort = downloadTask.abort.bind(downloadTask);
          }
        }
      });
    });
    return _downloadFile_.apply(this, arguments);
  }
  function getDownloadURL(_x3) {
    return _getDownloadURL.apply(this, arguments);
  }
  function _getDownloadURL() {
    _getDownloadURL = asyncToGenerator_default()(function* (param) {
      var serializedReqData = JSON.stringify({
        fileid: param.fileID
      });
      var tunnelStartTime = +new Date();
      var res = yield context.request({
        apiName: 'tcbapi_downloadfile',
        serviceName: context.name,
        serializedReqData,
        env: param.config && param.config.env || context.env
      });
      var resData = res.data;
      if (param.timing) {
        param.timing.tunnelStartTime = tunnelStartTime;
        param.timing.tunnelEndTime = +new Date();
        param.timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
      }
      if (resData.download_url) {
        if (resData.download_url.indexOf('?') > -1) {
          resData.download_url += '&skip_domain_check=true';
        } else {
          resData.download_url += '?skip_domain_check=true';
        }
      } else {
        throw new error_CloudSDKError({
          errCode: error_config_ERR_CODE.SDK_STORAGE_INTERNAL_SERVER_ERROR_EMPTY_DOWNLOAD_URL,
          errMsg: error_config_ERR_CODE[error_config_ERR_CODE.SDK_STORAGE_INTERNAL_SERVER_ERROR_EMPTY_DOWNLOAD_URL]
        });
      }
      return resData.download_url;
    });
    return _getDownloadURL.apply(this, arguments);
  }
}
;// CONCATENATED MODULE: ./src/services/storage/api/getTempFileURL.ts









var getTempFileURL_API_NAME = 'cloud.getTempFileURL';
function getGetTempFileURLAPI(context) {
  return function getTempFileURL(param) {
    var _param = shallowClone(param);
    _param.timing = {
      apiStartTime: +new Date()
    };
    if (hasAPICallback(_param)) {
      return getTempFileURLCallbackStyle(_param);
    } else {
      var promise = getTempFileURLPromiseStyle(_param);
      return promise;
    }
  };
  function checkParam(param) {
    assertType(param, {
      fileList: 'array'
    });
    if (param.config) {
      if (param.config.env) {
        assertType(param.config.env, 'string');
      }
    }
    if (context.appConfig.getTempFileURLMaxReq && param.fileList.length > context.appConfig.getTempFileURLMaxReq) {
      throw new error_CloudSDKError({
        errCode: error_config_ERR_CODE.SDK_API_PARAMETER_ERROR,
        errMsg: `parameter.fileList exceed max length ${context.appConfig.getTempFileURLMaxReq}`
      });
    }
  }
  function getTempFileURLCallbackStyle(param) {
    var promise = getTempFileURLPromiseStyle(param);
    promise.then(res => {
      invokeSuccessCompleteCallbacks(getTempFileURL_API_NAME, param, res);
    }).catch(err => {
      invokeFailCompleteCallbacks(getTempFileURL_API_NAME, param, err);
    });
  }
  function getTempFileURLPromiseStyle(_x) {
    return _getTempFileURLPromiseStyle.apply(this, arguments);
  }
  function _getTempFileURLPromiseStyle() {
    _getTempFileURLPromiseStyle = asyncToGenerator_default()(function* (param) {
      try {
        checkParam(param);
        if (!param.fileList.length) {
          return {
            errMsg: apiSuccessMsg(getTempFileURL_API_NAME),
            fileList: []
          };
        }
        var result = yield getTempFileURL_(param);
        return result;
      } catch (err) {
        throw returnAsFinalCloudSDKError(err, getTempFileURL_API_NAME);
      } finally {
        reportAPISpeed({
          ...param.timing,
          apiEndTime: +new Date(),
          apiName: getTempFileURL_API_NAME
        });
      }
    });
    return _getTempFileURLPromiseStyle.apply(this, arguments);
  }
  function getTempFileURL_(_x2) {
    return _getTempFileURL_.apply(this, arguments);
  }
  function _getTempFileURL_() {
    _getTempFileURL_ = asyncToGenerator_default()(function* (param) {
      var reqData = {
        file_list: param.fileList.map(item => {
          if (isString(item)) {
            return {
              fileid: item
            };
          } else {
            return {
              fileid: item.fileID,
              max_age: item.maxAge
            };
          }
        })
      };
      var serializedReqData = JSON.stringify(reqData);
      param.timing.tunnelStartTime = +new Date();
      var res = yield context.request({
        apiName: 'tcbapi_gettempfileurl',
        serviceName: context.name,
        serializedReqData,
        env: param.config && param.config.env || context.env
      });
      param.timing.tunnelEndTime = +new Date();
      var resData = res.data;
      param.timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
      return {
        errMsg: apiSuccessMsg(getTempFileURL_API_NAME),
        fileList: resData.download_list.map(item => {
          return {
            fileID: item.fileid,
            tempFileURL: item.download_url,
            maxAge: item.max_age,
            status: item.status,
            errMsg: item.errmsg
          };
        })
      };
    });
    return _getTempFileURL_.apply(this, arguments);
  }
}
;// CONCATENATED MODULE: ./src/services/storage/api/deleteFile.ts








var deleteFile_API_NAME = 'cloud.deleteFile';
function getDeleteFileAPI(context) {
  return function deleteFile(param) {
    var _param = shallowClone(param);
    _param.timing = {
      apiStartTime: +new Date()
    };
    if (hasAPICallback(_param)) {
      return deleteFileCallbackStyle(_param);
    } else {
      var promise = deleteFilePromiseStyle(_param);
      return promise;
    }
  };
  function checkParam(param) {
    assertType(param, {
      fileList: 'array'
    });
    if (param.config) {
      if (param.config.env) {
        assertType(param.config.env, 'string');
      }
    }
    for (var i = 0, len = param.fileList.length; i < len; i++) {
      assertType(param.fileList[i], 'string', `parameter.fileList[${i}]`);
    }
    if (context.appConfig.getTempFileURLMaxReq && param.fileList.length > context.appConfig.getTempFileURLMaxReq) {
      throw new error_CloudSDKError({
        errCode: error_config_ERR_CODE.SDK_API_PARAMETER_ERROR,
        errMsg: `parameter.fileList exceed max length ${context.appConfig.getTempFileURLMaxReq}`
      });
    }
  }
  function deleteFileCallbackStyle(param) {
    var promise = deleteFilePromiseStyle(param);
    promise.then(res => {
      invokeSuccessCompleteCallbacks(deleteFile_API_NAME, param, res);
    }).catch(err => {
      invokeFailCompleteCallbacks(deleteFile_API_NAME, param, err);
    });
  }
  function deleteFilePromiseStyle(_x) {
    return _deleteFilePromiseStyle.apply(this, arguments);
  }
  function _deleteFilePromiseStyle() {
    _deleteFilePromiseStyle = asyncToGenerator_default()(function* (param) {
      try {
        checkParam(param);
        if (!param.fileList.length) {
          return {
            errMsg: apiSuccessMsg(deleteFile_API_NAME),
            fileList: []
          };
        }
        var result = yield deleteFile_(param);
        return result;
      } catch (err) {
        throw returnAsFinalCloudSDKError(err, deleteFile_API_NAME);
      } finally {
        reportAPISpeed({
          ...param.timing,
          apiEndTime: +new Date(),
          apiName: deleteFile_API_NAME
        });
      }
    });
    return _deleteFilePromiseStyle.apply(this, arguments);
  }
  function deleteFile_(_x2) {
    return _deleteFile_.apply(this, arguments);
  }
  function _deleteFile_() {
    _deleteFile_ = asyncToGenerator_default()(function* (param) {
      var reqData = {
        fileid_list: param.fileList
      };
      var serializedReqData = JSON.stringify(reqData);
      param.timing.tunnelStartTime = +new Date();
      var res = yield context.request({
        apiName: 'tcbapi_deletefile',
        serviceName: context.name,
        serializedReqData,
        env: param.config && param.config.env || context.env
      });
      param.timing.tunnelEndTime = +new Date();
      var resData = res.data;
      param.timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
      return {
        errMsg: apiSuccessMsg(deleteFile_API_NAME),
        fileList: resData.delete_list.map(item => {
          return {
            fileID: item.fileid,
            status: item.status,
            errMsg: item.errmsg
          };
        })
      };
    });
    return _deleteFile_.apply(this, arguments);
  }
}
;// CONCATENATED MODULE: ./src/services/storage/api/api.ts




function api_api_getAPIs(context) {
  return {
    uploadFile: getUploadFileAPI(context),
    downloadFile: getDownloadFileAPI(context),
    getTempFileURL: getGetTempFileURLAPI(context),
    deleteFile: getDeleteFileAPI(context)
  };
}
;// CONCATENATED MODULE: ./src/services/storage/index.ts

var STORAGE_SERVICE_NAME = 'storage';
function createStorageService(cloud) {
  var context = {
    name: STORAGE_SERVICE_NAME,
    identifiers: cloud.identifiers,
    request: cloud.request,
    isInstance: cloud.isInstance,
    get env() {
      return cloud.getEnvForService(STORAGE_SERVICE_NAME);
    },
    get debug() {
      return cloud.debug;
    },
    appConfig: {
      get uploadMaxFileSize() {
        return cloud.appConfig.upload_max_file_size;
      },
      get getTempFileURLMaxReq() {
        return cloud.appConfig.get_temp_file_url_max_requests;
      }
    }
  };
  return {
    name: STORAGE_SERVICE_NAME,
    context,
    getAPIs: api_api_getAPIs.bind(null, context)
  };
}
function storage_registerService(cloud) {
  cloud.registerService(createStorageService(cloud));
}
;// CONCATENATED MODULE: ./src/services/database/api/database/helper/symbol.ts
var SYMBOL_UNSET_FIELD_NAME = Symbol.for('UNSET_FIELD_NAME');
var symbol_SYMBOL_AGGREGATE = Symbol.for('AGGREGATE');
var SYMBOL_AGGREGATE_PIPELINE = Symbol.for('AGGREGATE_PIPELINE');
var SYMBOL_AGGREGATE_PIPELINE_STAGE = Symbol.for('AGGREGATE_PIPELINE_STAGE');
var SYMBOL_UPDATE_COMMAND = Symbol.for('UPDATE_COMMAND');
var SYMBOL_QUERY_COMMAND = Symbol.for('QUERY_COMMAND');
var SYMBOL_LOGIC_COMMAND = Symbol.for('LOGIC_COMMAND');
var SYMBOL_AGGREGATE_COMMAND = Symbol.for('AGGREGATE_COMMAND');
var SYMBOL_PROJECT_COMMAND = Symbol.for('PROJECT_COMMAND');
var SYMBOL_GEO_POINT = Symbol.for('GEO_POINT');
var SYMBOL_GEO_LINESTRING = Symbol.for('GEO_LINESTRING');
var SYMBOL_GEO_POLYGON = Symbol.for('GEO_POLYGON');
var SYMBOL_GEO_MULTIPOINT = Symbol.for('GEO_MULTIPOINT');
var SYMBOL_GEO_MULTILINESTRING = Symbol.for('GEO_MULTILINESTRING');
var SYMBOL_GEO_MULTIPOLYGON = Symbol.for('GEO_MULTIPOLYGON');
var SYMBOL_SERVER_DATE = Symbol.for('SERVER_DATE');
var SYMBOL_REGEXP = Symbol.for('REGEXP');
;// CONCATENATED MODULE: ./src/services/database/api/database/commands/logic.ts



var LOGIC_COMMANDS_LITERAL = /*#__PURE__*/function (LOGIC_COMMANDS_LITERAL) {
  LOGIC_COMMANDS_LITERAL["AND"] = "and";
  LOGIC_COMMANDS_LITERAL["OR"] = "or";
  LOGIC_COMMANDS_LITERAL["NOT"] = "not";
  LOGIC_COMMANDS_LITERAL["NOR"] = "nor";
  return LOGIC_COMMANDS_LITERAL;
}({});
var logicCommands = [LOGIC_COMMANDS_LITERAL.AND, LOGIC_COMMANDS_LITERAL.OR, LOGIC_COMMANDS_LITERAL.NOT, LOGIC_COMMANDS_LITERAL.NOR];
var logicCommandsSet = new Set(logicCommands);
class LogicCommmand {
  constructor(operator, operands, fieldName) {
    this.fieldName = void 0;
    this.operator = void 0;
    this.operands = void 0;
    this._internalType = SYMBOL_LOGIC_COMMAND;
    this.__safe_props__ = void 0;
    Object.defineProperties(this, {
      _internalType: {
        enumerable: false,
        configurable: false
      }
    });
    this.operator = operator;
    this.operands = operands;
    this.fieldName = fieldName || SYMBOL_UNSET_FIELD_NAME;
    if (false) {}
  }
  _setFieldName(fieldName) {
    var operands = this.operands.map(operand => {
      if (operand === LOGIC_COMMANDS_LITERAL.AND || operand === LOGIC_COMMANDS_LITERAL.OR) {
        return operand._setFieldName(fieldName);
      } else {
        return operand;
      }
    });
    var command = new LogicCommmand(this.operator, operands, fieldName);
    return command;
  }
  and(...__expressions__) {
    assertRequiredParam(arguments[0], 'expressions', 'and');
    var expressions = isArray(arguments[0]) ? arguments[0] : Array.from(arguments);
    return new LogicCommmand(LOGIC_COMMANDS_LITERAL.AND, [this, ...expressions], this.fieldName);
  }
  or(...__expressions__) {
    assertRequiredParam(arguments[0], 'expressions', 'or');
    var expressions = isArray(arguments[0]) ? arguments[0] : Array.from(arguments);
    return new LogicCommmand(LOGIC_COMMANDS_LITERAL.OR, [this, ...expressions], this.fieldName);
  }
  nor(...__expressions__) {
    assertRequiredParam(arguments[0], 'expressions', 'nor');
    var expressions = isArray(arguments[0]) ? arguments[0] : Array.from(arguments);
    return new LogicCommmand(LOGIC_COMMANDS_LITERAL.NOR, [this, ...expressions], this.fieldName);
  }
  not(expression) {
    assertRequiredParam(expression, 'expression', 'not');
    return new LogicCommmand(LOGIC_COMMANDS_LITERAL.NOT, [expression], this.fieldName);
  }
  toJSON() {
    return undefined;
  }
}
function isLogicCommand(object) {
  return object && object instanceof LogicCommmand && object._internalType === SYMBOL_LOGIC_COMMAND;
}
function isKnownLogicCommand(object) {
  return isLogicCommand(object) && logicCommandsSet.has(object.operator);
}
/* harmony default export */ const logic = ((/* unused pure expression or super */ null && (LogicCommmand)));
;// CONCATENATED MODULE: ./src/services/database/api/database/commands/query.ts



var QUERY_COMMANDS_LITERAL = /*#__PURE__*/function (QUERY_COMMANDS_LITERAL) {
  QUERY_COMMANDS_LITERAL["EQ"] = "eq";
  QUERY_COMMANDS_LITERAL["NEQ"] = "neq";
  QUERY_COMMANDS_LITERAL["GT"] = "gt";
  QUERY_COMMANDS_LITERAL["GTE"] = "gte";
  QUERY_COMMANDS_LITERAL["LT"] = "lt";
  QUERY_COMMANDS_LITERAL["LTE"] = "lte";
  QUERY_COMMANDS_LITERAL["IN"] = "in";
  QUERY_COMMANDS_LITERAL["NIN"] = "nin";
  QUERY_COMMANDS_LITERAL["GEO_NEAR"] = "geoNear";
  QUERY_COMMANDS_LITERAL["GEO_WITHIN"] = "geoWithin";
  QUERY_COMMANDS_LITERAL["GEO_INTERSECTS"] = "geoIntersects";
  QUERY_COMMANDS_LITERAL["EXISTS"] = "exists";
  QUERY_COMMANDS_LITERAL["MOD"] = "mod";
  QUERY_COMMANDS_LITERAL["ALL"] = "all";
  QUERY_COMMANDS_LITERAL["ELEM_MATCH"] = "elemMatch";
  QUERY_COMMANDS_LITERAL["SIZE"] = "size";
  QUERY_COMMANDS_LITERAL["EXPR"] = "expr";
  return QUERY_COMMANDS_LITERAL;
}({});
var queryCommands = [QUERY_COMMANDS_LITERAL.EQ, QUERY_COMMANDS_LITERAL.NEQ, QUERY_COMMANDS_LITERAL.GT, QUERY_COMMANDS_LITERAL.GTE, QUERY_COMMANDS_LITERAL.LT, QUERY_COMMANDS_LITERAL.LTE, QUERY_COMMANDS_LITERAL.IN, QUERY_COMMANDS_LITERAL.NIN, QUERY_COMMANDS_LITERAL.GEO_NEAR, QUERY_COMMANDS_LITERAL.GEO_WITHIN, QUERY_COMMANDS_LITERAL.GEO_INTERSECTS, QUERY_COMMANDS_LITERAL.EXISTS, QUERY_COMMANDS_LITERAL.MOD, QUERY_COMMANDS_LITERAL.ALL, QUERY_COMMANDS_LITERAL.ELEM_MATCH, QUERY_COMMANDS_LITERAL.SIZE];
var queryCommandsSet = new Set(queryCommands);
var dbsSafeProps = new Set([...queryCommandsSet, ...logicCommandsSet]);
class QueryCommmand extends LogicCommmand {
  constructor(operator, operands, fieldName) {
    super(operator, operands, fieldName);
    this.operator = void 0;
    this.__safe_props__ = void 0;
    this.operator = operator;
    this._internalType = SYMBOL_QUERY_COMMAND;
    if (false) {}
  }
  _setFieldName(fieldName) {
    var command = new QueryCommmand(this.operator, this.operands, fieldName);
    return command;
  }
  eq(val) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.EQ, [val], this.fieldName);
    return this.and(command);
  }
  neq(val) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.NEQ, [val], this.fieldName);
    return this.and(command);
  }
  gt(val) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.GT, [val], this.fieldName);
    return this.and(command);
  }
  gte(val) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.GTE, [val], this.fieldName);
    return this.and(command);
  }
  lt(val) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.LT, [val], this.fieldName);
    return this.and(command);
  }
  lte(val) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.LTE, [val], this.fieldName);
    return this.and(command);
  }
  in(list) {
    assertType(list, 'array');
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.IN, list, this.fieldName);
    return this.and(command);
  }
  nin(list) {
    assertType(list, 'array');
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.NIN, list, this.fieldName);
    return this.and(command);
  }
  geoNear(options) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.GEO_NEAR, [options], this.fieldName);
    return this.and(command);
  }
  geoWithin(options) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.GEO_WITHIN, [options], this.fieldName);
    return this.and(command);
  }
  geoIntersects(options) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.GEO_INTERSECTS, [options], this.fieldName);
    return this.and(command);
  }
  exists(val) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.EXISTS, [val], this.fieldName);
    return this.and(command);
  }
  mod(divisor, remainder) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.MOD, [divisor, remainder], this.fieldName);
    return this.and(command);
  }
  all(val) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.ALL, val, this.fieldName);
    return this.and(command);
  }
  elemMatch(val) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.ELEM_MATCH, [val], this.fieldName);
    return this.and(command);
  }
  size(val) {
    var command = new QueryCommmand(QUERY_COMMANDS_LITERAL.SIZE, [val], this.fieldName);
    return this.and(command);
  }
}
function isQueryCommand(object) {
  return object && object instanceof QueryCommmand && object._internalType === SYMBOL_QUERY_COMMAND;
}
function isKnownQueryCommand(object) {
  return isQueryCommand(object) && queryCommandsSet.has(object.operator);
}
function isComparisonCommand(object) {
  return isQueryCommand(object);
}
/* harmony default export */ const query = ((/* unused pure expression or super */ null && (QueryCommmand)));
;// CONCATENATED MODULE: ./src/services/database/api/database/commands/update.ts

var UPDATE_COMMANDS_LITERAL = /*#__PURE__*/function (UPDATE_COMMANDS_LITERAL) {
  UPDATE_COMMANDS_LITERAL["SET"] = "set";
  UPDATE_COMMANDS_LITERAL["REMOVE"] = "remove";
  UPDATE_COMMANDS_LITERAL["INC"] = "inc";
  UPDATE_COMMANDS_LITERAL["MUL"] = "mul";
  UPDATE_COMMANDS_LITERAL["MIN"] = "min";
  UPDATE_COMMANDS_LITERAL["MAX"] = "max";
  UPDATE_COMMANDS_LITERAL["RENAME"] = "rename";
  UPDATE_COMMANDS_LITERAL["BIT"] = "bit";
  UPDATE_COMMANDS_LITERAL["PUSH"] = "push";
  UPDATE_COMMANDS_LITERAL["POP"] = "pop";
  UPDATE_COMMANDS_LITERAL["SHIFT"] = "shift";
  UPDATE_COMMANDS_LITERAL["UNSHIFT"] = "unshift";
  UPDATE_COMMANDS_LITERAL["ADD_TO_SET"] = "addToSet";
  UPDATE_COMMANDS_LITERAL["PULL"] = "pull";
  UPDATE_COMMANDS_LITERAL["PULL_ALL"] = "pullAll";
  return UPDATE_COMMANDS_LITERAL;
}({});
var updateCommandsSet = new Set([UPDATE_COMMANDS_LITERAL.SET, UPDATE_COMMANDS_LITERAL.REMOVE, UPDATE_COMMANDS_LITERAL.INC, UPDATE_COMMANDS_LITERAL.MUL, UPDATE_COMMANDS_LITERAL.MIN, UPDATE_COMMANDS_LITERAL.MAX, UPDATE_COMMANDS_LITERAL.RENAME, UPDATE_COMMANDS_LITERAL.BIT, UPDATE_COMMANDS_LITERAL.PUSH, UPDATE_COMMANDS_LITERAL.POP, UPDATE_COMMANDS_LITERAL.SHIFT, UPDATE_COMMANDS_LITERAL.UNSHIFT, UPDATE_COMMANDS_LITERAL.ADD_TO_SET, UPDATE_COMMANDS_LITERAL.PULL, UPDATE_COMMANDS_LITERAL.PULL_ALL]);
class UpdateCommand {
  constructor(operator, operands, fieldName) {
    this.fieldName = void 0;
    this.operator = void 0;
    this.operands = void 0;
    this._internalType = SYMBOL_UPDATE_COMMAND;
    Object.defineProperties(this, {
      _internalType: {
        enumerable: false,
        configurable: false
      }
    });
    this.operator = operator;
    this.operands = operands;
    this.fieldName = fieldName || SYMBOL_UNSET_FIELD_NAME;
  }
  _setFieldName(fieldName) {
    var command = new UpdateCommand(this.operator, this.operands, fieldName);
    return command;
  }
  toJSON() {
    return undefined;
  }
}
function isUpdateCommand(object) {
  return object && object instanceof UpdateCommand && object._internalType === SYMBOL_UPDATE_COMMAND;
}
function isKnownUpdateCommand(object) {
  return isUpdateCommand(object) && updateCommandsSet.has(object.operator);
}
/* harmony default export */ const update = ((/* unused pure expression or super */ null && (UpdateCommand)));
;// CONCATENATED MODULE: ./src/services/database/api/database/commands/aggregate.ts

var AGGREGATE_COMMANDS_LITERAL = /*#__PURE__*/function (AGGREGATE_COMMANDS_LITERAL) {
  AGGREGATE_COMMANDS_LITERAL["ABS"] = "abs";
  AGGREGATE_COMMANDS_LITERAL["ADD"] = "add";
  AGGREGATE_COMMANDS_LITERAL["ADDTOSET"] = "addToSet";
  AGGREGATE_COMMANDS_LITERAL["ALLELEMENTSTRUE"] = "allElementsTrue";
  AGGREGATE_COMMANDS_LITERAL["AND"] = "and";
  AGGREGATE_COMMANDS_LITERAL["ANYELEMENTTRUE"] = "anyElementTrue";
  AGGREGATE_COMMANDS_LITERAL["ARRAYELEMAT"] = "arrayElemAt";
  AGGREGATE_COMMANDS_LITERAL["ARRAYTOOBJECT"] = "arrayToObject";
  AGGREGATE_COMMANDS_LITERAL["AVG"] = "avg";
  AGGREGATE_COMMANDS_LITERAL["CEIL"] = "ceil";
  AGGREGATE_COMMANDS_LITERAL["CMP"] = "cmp";
  AGGREGATE_COMMANDS_LITERAL["CONCAT"] = "concat";
  AGGREGATE_COMMANDS_LITERAL["CONCATARRAYS"] = "concatArrays";
  AGGREGATE_COMMANDS_LITERAL["COND"] = "cond";
  AGGREGATE_COMMANDS_LITERAL["CONVERT"] = "convert";
  AGGREGATE_COMMANDS_LITERAL["DATEFROMPARTS"] = "dateFromParts";
  AGGREGATE_COMMANDS_LITERAL["DATETOPARTS"] = "dateToParts";
  AGGREGATE_COMMANDS_LITERAL["DATEFROMSTRING"] = "dateFromString";
  AGGREGATE_COMMANDS_LITERAL["DATETOSTRING"] = "dateToString";
  AGGREGATE_COMMANDS_LITERAL["DAYOFMONTH"] = "dayOfMonth";
  AGGREGATE_COMMANDS_LITERAL["DAYOFWEEK"] = "dayOfWeek";
  AGGREGATE_COMMANDS_LITERAL["DAYOFYEAR"] = "dayOfYear";
  AGGREGATE_COMMANDS_LITERAL["DIVIDE"] = "divide";
  AGGREGATE_COMMANDS_LITERAL["EQ"] = "eq";
  AGGREGATE_COMMANDS_LITERAL["EXP"] = "exp";
  AGGREGATE_COMMANDS_LITERAL["FILTER"] = "filter";
  AGGREGATE_COMMANDS_LITERAL["FIRST"] = "first";
  AGGREGATE_COMMANDS_LITERAL["FLOOR"] = "floor";
  AGGREGATE_COMMANDS_LITERAL["GT"] = "gt";
  AGGREGATE_COMMANDS_LITERAL["GTE"] = "gte";
  AGGREGATE_COMMANDS_LITERAL["HOUR"] = "hour";
  AGGREGATE_COMMANDS_LITERAL["IFNULL"] = "ifNull";
  AGGREGATE_COMMANDS_LITERAL["IN"] = "in";
  AGGREGATE_COMMANDS_LITERAL["INDEXOFARRAY"] = "indexOfArray";
  AGGREGATE_COMMANDS_LITERAL["INDEXOFBYTES"] = "indexOfBytes";
  AGGREGATE_COMMANDS_LITERAL["INDEXOFCP"] = "indexOfCP";
  AGGREGATE_COMMANDS_LITERAL["ISARRAY"] = "isArray";
  AGGREGATE_COMMANDS_LITERAL["ISODAYOFWEEK"] = "isoDayOfWeek";
  AGGREGATE_COMMANDS_LITERAL["ISOWEEK"] = "isoWeek";
  AGGREGATE_COMMANDS_LITERAL["ISOWEEKYEAR"] = "isoWeekYear";
  AGGREGATE_COMMANDS_LITERAL["LAST"] = "last";
  AGGREGATE_COMMANDS_LITERAL["LET"] = "let";
  AGGREGATE_COMMANDS_LITERAL["LITERAL"] = "literal";
  AGGREGATE_COMMANDS_LITERAL["LN"] = "ln";
  AGGREGATE_COMMANDS_LITERAL["LOG"] = "log";
  AGGREGATE_COMMANDS_LITERAL["LOG10"] = "log10";
  AGGREGATE_COMMANDS_LITERAL["LT"] = "lt";
  AGGREGATE_COMMANDS_LITERAL["LTE"] = "lte";
  AGGREGATE_COMMANDS_LITERAL["LTRIM"] = "ltrim";
  AGGREGATE_COMMANDS_LITERAL["MAP"] = "map";
  AGGREGATE_COMMANDS_LITERAL["MAX"] = "max";
  AGGREGATE_COMMANDS_LITERAL["MERGEOBJECTS"] = "mergeObjects";
  AGGREGATE_COMMANDS_LITERAL["META"] = "meta";
  AGGREGATE_COMMANDS_LITERAL["MIN"] = "min";
  AGGREGATE_COMMANDS_LITERAL["MILLISECOND"] = "millisecond";
  AGGREGATE_COMMANDS_LITERAL["MINUTE"] = "minute";
  AGGREGATE_COMMANDS_LITERAL["MOD"] = "mod";
  AGGREGATE_COMMANDS_LITERAL["MONTH"] = "month";
  AGGREGATE_COMMANDS_LITERAL["MULTIPLY"] = "multiply";
  AGGREGATE_COMMANDS_LITERAL["NEQ"] = "ne";
  AGGREGATE_COMMANDS_LITERAL["NOT"] = "not";
  AGGREGATE_COMMANDS_LITERAL["OBJECTTOARRAY"] = "objectToArray";
  AGGREGATE_COMMANDS_LITERAL["OR"] = "or";
  AGGREGATE_COMMANDS_LITERAL["POW"] = "pow";
  AGGREGATE_COMMANDS_LITERAL["PUSH"] = "push";
  AGGREGATE_COMMANDS_LITERAL["RANGE"] = "range";
  AGGREGATE_COMMANDS_LITERAL["REDUCE"] = "reduce";
  AGGREGATE_COMMANDS_LITERAL["REVERSEARRAY"] = "reverseArray";
  AGGREGATE_COMMANDS_LITERAL["RTRIM"] = "rtrim";
  AGGREGATE_COMMANDS_LITERAL["SECOND"] = "second";
  AGGREGATE_COMMANDS_LITERAL["SETDIFFERENCE"] = "setDifference";
  AGGREGATE_COMMANDS_LITERAL["SETEQUALS"] = "setEquals";
  AGGREGATE_COMMANDS_LITERAL["SETINTERSECTION"] = "setIntersection";
  AGGREGATE_COMMANDS_LITERAL["SETISSUBSET"] = "setIsSubset";
  AGGREGATE_COMMANDS_LITERAL["SETUNION"] = "setUnion";
  AGGREGATE_COMMANDS_LITERAL["SIZE"] = "size";
  AGGREGATE_COMMANDS_LITERAL["SLICE"] = "slice";
  AGGREGATE_COMMANDS_LITERAL["SPLIT"] = "split";
  AGGREGATE_COMMANDS_LITERAL["SQRT"] = "sqrt";
  AGGREGATE_COMMANDS_LITERAL["STDDEVPOP"] = "stdDevPop";
  AGGREGATE_COMMANDS_LITERAL["STDDEVSAMP"] = "stdDevSamp";
  AGGREGATE_COMMANDS_LITERAL["STRCASECMP"] = "strcasecmp";
  AGGREGATE_COMMANDS_LITERAL["STRLENBYTES"] = "strLenBytes";
  AGGREGATE_COMMANDS_LITERAL["STRLENCP"] = "strLenCP";
  AGGREGATE_COMMANDS_LITERAL["SUBSTR"] = "substr";
  AGGREGATE_COMMANDS_LITERAL["SUBSTRBYTES"] = "substrBytes";
  AGGREGATE_COMMANDS_LITERAL["SUBSTRCP"] = "substrCP";
  AGGREGATE_COMMANDS_LITERAL["SUBTRACT"] = "subtract";
  AGGREGATE_COMMANDS_LITERAL["SUM"] = "sum";
  AGGREGATE_COMMANDS_LITERAL["SWITCH"] = "switch";
  AGGREGATE_COMMANDS_LITERAL["TOBOOL"] = "toBool";
  AGGREGATE_COMMANDS_LITERAL["TODATE"] = "toDate";
  AGGREGATE_COMMANDS_LITERAL["TODECIMAL"] = "toDecimal";
  AGGREGATE_COMMANDS_LITERAL["TODOUBLE"] = "toDouble";
  AGGREGATE_COMMANDS_LITERAL["TOINT"] = "toInt";
  AGGREGATE_COMMANDS_LITERAL["TOLONG"] = "toLong";
  AGGREGATE_COMMANDS_LITERAL["TOOBJECTID"] = "toObjectId";
  AGGREGATE_COMMANDS_LITERAL["TOSTRING"] = "toString";
  AGGREGATE_COMMANDS_LITERAL["TOLOWER"] = "toLower";
  AGGREGATE_COMMANDS_LITERAL["TOUPPER"] = "toUpper";
  AGGREGATE_COMMANDS_LITERAL["TRIM"] = "trim";
  AGGREGATE_COMMANDS_LITERAL["TRUNC"] = "trunc";
  AGGREGATE_COMMANDS_LITERAL["TYPE"] = "type";
  AGGREGATE_COMMANDS_LITERAL["WEEK"] = "week";
  AGGREGATE_COMMANDS_LITERAL["YEAR"] = "year";
  AGGREGATE_COMMANDS_LITERAL["ZIP"] = "zip";
  return AGGREGATE_COMMANDS_LITERAL;
}({});
var ABS = AGGREGATE_COMMANDS_LITERAL.ABS;
var ADD = AGGREGATE_COMMANDS_LITERAL.ADD;
var ADDTOSET = AGGREGATE_COMMANDS_LITERAL.ADDTOSET;
var ALLELEMENTSTRUE = AGGREGATE_COMMANDS_LITERAL.ALLELEMENTSTRUE;
var AND = AGGREGATE_COMMANDS_LITERAL.AND;
var ANYELEMENTTRUE = AGGREGATE_COMMANDS_LITERAL.ANYELEMENTTRUE;
var ARRAYELEMAT = AGGREGATE_COMMANDS_LITERAL.ARRAYELEMAT;
var ARRAYTOOBJECT = AGGREGATE_COMMANDS_LITERAL.ARRAYTOOBJECT;
var AVG = AGGREGATE_COMMANDS_LITERAL.AVG;
var CEIL = AGGREGATE_COMMANDS_LITERAL.CEIL;
var CMP = AGGREGATE_COMMANDS_LITERAL.CMP;
var CONCAT = AGGREGATE_COMMANDS_LITERAL.CONCAT;
var CONCATARRAYS = AGGREGATE_COMMANDS_LITERAL.CONCATARRAYS;
var COND = AGGREGATE_COMMANDS_LITERAL.COND;
var CONVERT = AGGREGATE_COMMANDS_LITERAL.CONVERT;
var DATEFROMPARTS = AGGREGATE_COMMANDS_LITERAL.DATEFROMPARTS;
var DATETOPARTS = AGGREGATE_COMMANDS_LITERAL.DATETOPARTS;
var DATEFROMSTRING = AGGREGATE_COMMANDS_LITERAL.DATEFROMSTRING;
var DATETOSTRING = AGGREGATE_COMMANDS_LITERAL.DATETOSTRING;
var DAYOFMONTH = AGGREGATE_COMMANDS_LITERAL.DAYOFMONTH;
var DAYOFWEEK = AGGREGATE_COMMANDS_LITERAL.DAYOFWEEK;
var DAYOFYEAR = AGGREGATE_COMMANDS_LITERAL.DAYOFYEAR;
var DIVIDE = AGGREGATE_COMMANDS_LITERAL.DIVIDE;
var EQ = AGGREGATE_COMMANDS_LITERAL.EQ;
var EXP = AGGREGATE_COMMANDS_LITERAL.EXP;
var FILTER = AGGREGATE_COMMANDS_LITERAL.FILTER;
var FIRST = AGGREGATE_COMMANDS_LITERAL.FIRST;
var FLOOR = AGGREGATE_COMMANDS_LITERAL.FLOOR;
var GT = AGGREGATE_COMMANDS_LITERAL.GT;
var GTE = AGGREGATE_COMMANDS_LITERAL.GTE;
var HOUR = AGGREGATE_COMMANDS_LITERAL.HOUR;
var IFNULL = AGGREGATE_COMMANDS_LITERAL.IFNULL;
var IN = AGGREGATE_COMMANDS_LITERAL.IN;
var INDEXOFARRAY = AGGREGATE_COMMANDS_LITERAL.INDEXOFARRAY;
var INDEXOFBYTES = AGGREGATE_COMMANDS_LITERAL.INDEXOFBYTES;
var INDEXOFCP = AGGREGATE_COMMANDS_LITERAL.INDEXOFCP;
var ISARRAY = AGGREGATE_COMMANDS_LITERAL.ISARRAY;
var ISODAYOFWEEK = AGGREGATE_COMMANDS_LITERAL.ISODAYOFWEEK;
var ISOWEEK = AGGREGATE_COMMANDS_LITERAL.ISOWEEK;
var ISOWEEKYEAR = AGGREGATE_COMMANDS_LITERAL.ISOWEEKYEAR;
var LAST = AGGREGATE_COMMANDS_LITERAL.LAST;
var LET = AGGREGATE_COMMANDS_LITERAL.LET;
var LITERAL = AGGREGATE_COMMANDS_LITERAL.LITERAL;
var LN = AGGREGATE_COMMANDS_LITERAL.LN;
var LOG = AGGREGATE_COMMANDS_LITERAL.LOG;
var LOG10 = AGGREGATE_COMMANDS_LITERAL.LOG10;
var LT = AGGREGATE_COMMANDS_LITERAL.LT;
var LTE = AGGREGATE_COMMANDS_LITERAL.LTE;
var LTRIM = AGGREGATE_COMMANDS_LITERAL.LTRIM;
var MAP = AGGREGATE_COMMANDS_LITERAL.MAP;
var MAX = AGGREGATE_COMMANDS_LITERAL.MAX;
var MERGEOBJECTS = AGGREGATE_COMMANDS_LITERAL.MERGEOBJECTS;
var META = AGGREGATE_COMMANDS_LITERAL.META;
var MIN = AGGREGATE_COMMANDS_LITERAL.MIN;
var MILLISECOND = AGGREGATE_COMMANDS_LITERAL.MILLISECOND;
var MINUTE = AGGREGATE_COMMANDS_LITERAL.MINUTE;
var MOD = AGGREGATE_COMMANDS_LITERAL.MOD;
var MONTH = AGGREGATE_COMMANDS_LITERAL.MONTH;
var MULTIPLY = AGGREGATE_COMMANDS_LITERAL.MULTIPLY;
var NEQ = AGGREGATE_COMMANDS_LITERAL.NEQ;
var NOT = AGGREGATE_COMMANDS_LITERAL.NOT;
var OBJECTTOARRAY = AGGREGATE_COMMANDS_LITERAL.OBJECTTOARRAY;
var OR = AGGREGATE_COMMANDS_LITERAL.OR;
var POW = AGGREGATE_COMMANDS_LITERAL.POW;
var PUSH = AGGREGATE_COMMANDS_LITERAL.PUSH;
var RANGE = AGGREGATE_COMMANDS_LITERAL.RANGE;
var REDUCE = AGGREGATE_COMMANDS_LITERAL.REDUCE;
var REVERSEARRAY = AGGREGATE_COMMANDS_LITERAL.REVERSEARRAY;
var RTRIM = AGGREGATE_COMMANDS_LITERAL.RTRIM;
var SECOND = AGGREGATE_COMMANDS_LITERAL.SECOND;
var SETDIFFERENCE = AGGREGATE_COMMANDS_LITERAL.SETDIFFERENCE;
var SETEQUALS = AGGREGATE_COMMANDS_LITERAL.SETEQUALS;
var SETINTERSECTION = AGGREGATE_COMMANDS_LITERAL.SETINTERSECTION;
var SETISSUBSET = AGGREGATE_COMMANDS_LITERAL.SETISSUBSET;
var SETUNION = AGGREGATE_COMMANDS_LITERAL.SETUNION;
var SIZE = AGGREGATE_COMMANDS_LITERAL.SIZE;
var SLICE = AGGREGATE_COMMANDS_LITERAL.SLICE;
var SPLIT = AGGREGATE_COMMANDS_LITERAL.SPLIT;
var SQRT = AGGREGATE_COMMANDS_LITERAL.SQRT;
var STDDEVPOP = AGGREGATE_COMMANDS_LITERAL.STDDEVPOP;
var STDDEVSAMP = AGGREGATE_COMMANDS_LITERAL.STDDEVSAMP;
var STRCASECMP = AGGREGATE_COMMANDS_LITERAL.STRCASECMP;
var STRLENBYTES = AGGREGATE_COMMANDS_LITERAL.STRLENBYTES;
var STRLENCP = AGGREGATE_COMMANDS_LITERAL.STRLENCP;
var SUBSTR = AGGREGATE_COMMANDS_LITERAL.SUBSTR;
var SUBSTRBYTES = AGGREGATE_COMMANDS_LITERAL.SUBSTRBYTES;
var SUBSTRCP = AGGREGATE_COMMANDS_LITERAL.SUBSTRCP;
var SUBTRACT = AGGREGATE_COMMANDS_LITERAL.SUBTRACT;
var SUM = AGGREGATE_COMMANDS_LITERAL.SUM;
var SWITCH = AGGREGATE_COMMANDS_LITERAL.SWITCH;
var TOBOOL = AGGREGATE_COMMANDS_LITERAL.TOBOOL;
var TODATE = AGGREGATE_COMMANDS_LITERAL.TODATE;
var TODECIMAL = AGGREGATE_COMMANDS_LITERAL.TODECIMAL;
var TODOUBLE = AGGREGATE_COMMANDS_LITERAL.TODOUBLE;
var TOINT = AGGREGATE_COMMANDS_LITERAL.TOINT;
var TOLONG = AGGREGATE_COMMANDS_LITERAL.TOLONG;
var TOOBJECTID = AGGREGATE_COMMANDS_LITERAL.TOOBJECTID;
var TOSTRING = AGGREGATE_COMMANDS_LITERAL.TOSTRING;
var TOLOWER = AGGREGATE_COMMANDS_LITERAL.TOLOWER;
var TOUPPER = AGGREGATE_COMMANDS_LITERAL.TOUPPER;
var TRIM = AGGREGATE_COMMANDS_LITERAL.TRIM;
var TRUNC = AGGREGATE_COMMANDS_LITERAL.TRUNC;
var TYPE = AGGREGATE_COMMANDS_LITERAL.TYPE;
var WEEK = AGGREGATE_COMMANDS_LITERAL.WEEK;
var YEAR = AGGREGATE_COMMANDS_LITERAL.YEAR;
var ZIP = AGGREGATE_COMMANDS_LITERAL.ZIP;
class AggregateCommand {
  constructor(operator, operands, fieldName) {
    this.fieldName = void 0;
    this.operator = void 0;
    this.operands = void 0;
    this._internalType = SYMBOL_AGGREGATE_COMMAND;
    this.__safe_props__ = void 0;
    Object.defineProperties(this, {
      _internalType: {
        enumerable: false,
        configurable: false
      }
    });
    this.operator = operator;
    this.operands = operands;
    this.fieldName = fieldName || SYMBOL_UNSET_FIELD_NAME;
  }
  _setFieldName(fieldName) {
    var command = new AggregateCommand(this.operator, this.operands, fieldName);
    return command;
  }
}
function isAggregateCommand(object) {
  return object && object instanceof AggregateCommand && object._internalType === SYMBOL_AGGREGATE_COMMAND;
}
function isKnownAggregateCommand(object) {
  return isAggregateCommand(object) && object.operator.toUpperCase() in AGGREGATE_COMMANDS_LITERAL;
}
/* harmony default export */ const aggregate = ((/* unused pure expression or super */ null && (AggregateCommand)));
;// CONCATENATED MODULE: ./src/services/database/api/database/commands/projection.ts

var projection_SLICE = 'slice';
var PROJECTION_COMMANDS_LITERAL = /*#__PURE__*/function (PROJECTION_COMMANDS_LITERAL) {
  PROJECTION_COMMANDS_LITERAL["SLICE"] = "slice";
  return PROJECTION_COMMANDS_LITERAL;
}({});
var projectionCommandsSet = new Set([PROJECTION_COMMANDS_LITERAL.SLICE]);
class ProjectionCommmand {
  constructor(operator, operands, fieldName) {
    this.fieldName = void 0;
    this.operator = void 0;
    this.operands = void 0;
    this.__safe_props__ = void 0;
    this._internalType = SYMBOL_PROJECT_COMMAND;
    this.operator = operator;
    this.operands = operands;
    this.fieldName = fieldName || SYMBOL_UNSET_FIELD_NAME;
    if (false) {}
  }
  _setFieldName(fieldName) {
    return new ProjectionCommmand(this.operator, this.operands, fieldName);
  }
}
function isProjectionCommand(object) {
  return object && object instanceof ProjectionCommmand && object._internalType === SYMBOL_PROJECT_COMMAND;
}
/* harmony default export */ const projection = ((/* unused pure expression or super */ null && (ProjectionCommmand)));
;// CONCATENATED MODULE: ./src/services/database/internal/backend-api/backend-api.ts




var QUERY_TYPE = /*#__PURE__*/function (QUERY_TYPE) {
  QUERY_TYPE[QUERY_TYPE["WHERE"] = 0] = "WHERE";
  QUERY_TYPE[QUERY_TYPE["DOC"] = 1] = "DOC";
  return QUERY_TYPE;
}({});
var _ID_TYPE = /*#__PURE__*/function (_ID_TYPE) {
  _ID_TYPE[_ID_TYPE["STRING"] = 1] = "STRING";
  _ID_TYPE[_ID_TYPE["NUMBER"] = 2] = "NUMBER";
  return _ID_TYPE;
}({});
var ORDER_DIRECTION = /*#__PURE__*/function (ORDER_DIRECTION) {
  ORDER_DIRECTION[ORDER_DIRECTION["ASC"] = 0] = "ASC";
  ORDER_DIRECTION[ORDER_DIRECTION["DESC"] = 1] = "DESC";
  return ORDER_DIRECTION;
}({});
function addDocument(_x) {
  return _addDocument.apply(this, arguments);
}
function _addDocument() {
  _addDocument = asyncToGenerator_default()(function* (options) {
    var {
      env,
      collectionName,
      data,
      instanceContext,
      timing
    } = options;
    var dataString = JSON.stringify(data);
    assertStringLength({
      input: dataString,
      max: instanceContext.serviceContext.appConfig.docSizeLimit,
      name: 'record',
      maxWording: `${(instanceContext.serviceContext.appConfig.docSizeLimit / 1024).toFixed(0)} KB`
    });
    var reqData = {
      collection_name: collectionName,
      data: dataString
    };
    var serializedReqData = JSON.stringify(reqData);
    timing.tunnelStartTime = +new Date();
    var res = yield instanceContext.serviceContext.request({
      apiName: 'tcbapi_db_adddocument',
      serviceName: instanceContext.serviceContext.name,
      serializedReqData,
      requireDataNotEmpty: true,
      env: env || instanceContext.serviceContext.env
    });
    timing.tunnelEndTime = +new Date();
    var resData = res.data;
    timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
    return {
      _id: resData._id_type === _ID_TYPE.NUMBER ? resData._id_number : resData._id
    };
  });
  return _addDocument.apply(this, arguments);
}
function removeDocument(_x2) {
  return _removeDocument.apply(this, arguments);
}
function _removeDocument() {
  _removeDocument = asyncToGenerator_default()(function* (options) {
    var {
      collectionName,
      query,
      options: removeOptions,
      instanceContext,
      timing,
      env
    } = options;
    var explain = isDevTools() ? options.explain : undefined;
    var multi = removeOptions && removeOptions.multi;
    var serializedReqData = JSON.stringify({
      collection_name: collectionName,
      query: JSON.stringify(query),
      multi,
      query_type: multi ? QUERY_TYPE.WHERE : QUERY_TYPE.DOC,
      explain
    });
    timing.tunnelStartTime = +new Date();
    var res = yield instanceContext.serviceContext.request({
      apiName: 'tcbapi_db_deletedocument',
      serviceName: instanceContext.serviceContext.name,
      serializedReqData,
      requireDataNotEmpty: true,
      env: env || instanceContext.serviceContext.env
    });
    timing.tunnelEndTime = +new Date();
    if (explain) {
      var {
        EJSON
      } = __webpack_require__(432);
      return EJSON.deserialize(res.data);
    }
    var resData = res.data;
    timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
    return {
      removed: resData.deleted
    };
  });
  return _removeDocument.apply(this, arguments);
}
function queryDocument(_x3) {
  return _queryDocument.apply(this, arguments);
}
function _queryDocument() {
  _queryDocument = asyncToGenerator_default()(function* (options) {
    var {
      env,
      collectionName,
      query,
      options: queryOptions = {},
      instanceContext,
      timing,
      queryType
    } = options;
    var explain = isDevTools() ? options.explain : undefined;
    var data = {
      collection_name: collectionName,
      query: JSON.stringify(query),
      query_type: queryType,
      explain
    };
    if (queryOptions.offset) {
      data.offset = queryOptions.offset;
    }
    if (queryOptions.limit) {
      data.limit = queryOptions.limit;
    }
    if (queryOptions.order) {
      data.order = queryOptions.order;
    }
    if (queryOptions.projection) {
      data.projection = JSON.stringify(queryOptions.projection);
    }
    var serializedReqData = JSON.stringify(data);
    timing.tunnelStartTime = +new Date();
    var res = yield instanceContext.serviceContext.request({
      apiName: 'tcbapi_db_querydocument',
      serviceName: instanceContext.serviceContext.name,
      serializedReqData,
      requireDataNotEmpty: true,
      env: env || instanceContext.serviceContext.env
    });
    timing.tunnelEndTime = +new Date();
    if (explain) {
      var {
        EJSON
      } = __webpack_require__(432);
      return EJSON.deserialize(res.data);
    }
    var resData = res.data;
    timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
    var list = resData.data_list ? JSON.parse(resData.data_list) : [];
    list = instanceContext.engine.Decoder.decode(list);
    return {
      list,
      offset: resData.offset,
      limit: resData.limit,
      total: resData.total
    };
  });
  return _queryDocument.apply(this, arguments);
}
function updateDocument(_x4) {
  return _updateDocument.apply(this, arguments);
}
function _updateDocument() {
  _updateDocument = asyncToGenerator_default()(function* (options) {
    var {
      env,
      collectionName,
      query,
      data,
      options: updateOptions = {},
      instanceContext,
      timing,
      queryType
    } = options;
    var explain = isDevTools() ? options.explain : undefined;
    var strData = JSON.stringify(data);
    assertStringLength({
      input: strData,
      max: instanceContext.serviceContext.appConfig.docSizeLimit,
      name: 'update expression',
      maxWording: `${(instanceContext.serviceContext.appConfig.docSizeLimit / 1024).toFixed(0)} KB`
    });
    var dataToBeSent = {
      collection_name: collectionName,
      query: JSON.stringify(query),
      data: strData,
      query_type: queryType,
      explain
    };
    dataToBeSent.multi = updateOptions.multi !== false;
    dataToBeSent.merge = updateOptions.merge !== false;
    if (updateOptions.upsert) {
      dataToBeSent.upsert = updateOptions.upsert;
    }
    var serializedReqData = JSON.stringify(dataToBeSent);
    timing.tunnelStartTime = +new Date();
    var res = yield instanceContext.serviceContext.request({
      apiName: 'tcbapi_db_updatedocument',
      serviceName: instanceContext.serviceContext.name,
      serializedReqData,
      requireDataNotEmpty: true,
      env: env || instanceContext.serviceContext.env
    });
    timing.tunnelEndTime = +new Date();
    if (explain) {
      var {
        EJSON
      } = __webpack_require__(432);
      return EJSON.deserialize(res.data);
    }
    var resData = res.data;
    timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
    return {
      updated: resData.updated
    };
  });
  return _updateDocument.apply(this, arguments);
}
function setDocument(_x5) {
  return _setDocument.apply(this, arguments);
}
function _setDocument() {
  _setDocument = asyncToGenerator_default()(function* (options) {
    var {
      env,
      collectionName,
      _id,
      data,
      options: updateOptions = {},
      instanceContext,
      timing
    } = options;
    var strData = JSON.stringify(data);
    assertStringLength({
      input: strData,
      max: instanceContext.serviceContext.appConfig.docSizeLimit,
      name: 'record',
      maxWording: `${(instanceContext.serviceContext.appConfig.docSizeLimit / 1024).toFixed(0)} KB`
    });
    var isNumberId = isNumber(_id);
    var dataToBeSent = {
      collection_name: collectionName,
      _id_type: isNumberId ? _ID_TYPE.NUMBER : _ID_TYPE.STRING,
      data: strData
    };
    if (isNumberId) {
      dataToBeSent._id_number = _id;
    } else {
      dataToBeSent._id = _id;
    }
    var serializedReqData = JSON.stringify(dataToBeSent);
    timing.tunnelStartTime = +new Date();
    var res = yield instanceContext.serviceContext.request({
      apiName: 'tcbapi_db_setdocument',
      serviceName: instanceContext.serviceContext.name,
      serializedReqData,
      requireDataNotEmpty: true,
      env: env || instanceContext.serviceContext.env
    });
    timing.tunnelEndTime = +new Date();
    var resData = res.data;
    timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
    return {
      _id: resData._id_type === _ID_TYPE.NUMBER ? resData._id_number : resData._id,
      updated: resData._id ? 0 : 1,
      created: resData._id ? 1 : 0
    };
  });
  return _setDocument.apply(this, arguments);
}
function countDocument(_x6) {
  return _countDocument.apply(this, arguments);
}
function _countDocument() {
  _countDocument = asyncToGenerator_default()(function* (options) {
    var {
      env,
      collectionName,
      query,
      instanceContext,
      timing
    } = options;
    var explain = isDevTools() ? options.explain : undefined;
    var data = {
      collection_name: collectionName,
      query: JSON.stringify(query),
      query_type: QUERY_TYPE.WHERE,
      explain
    };
    var serializedReqData = JSON.stringify(data);
    timing.tunnelStartTime = +new Date();
    var res = yield instanceContext.serviceContext.request({
      apiName: 'tcbapi_db_countdocument',
      serviceName: instanceContext.serviceContext.name,
      serializedReqData,
      requireDataNotEmpty: true,
      env: env || instanceContext.serviceContext.env
    });
    timing.tunnelEndTime = +new Date();
    if (explain) {
      var {
        EJSON
      } = __webpack_require__(432);
      return EJSON.deserialize(res.data);
    }
    var resData = res.data;
    timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
    return {
      total: resData.total
    };
  });
  return _countDocument.apply(this, arguments);
}
function runAggregate(_x7) {
  return _runAggregate.apply(this, arguments);
}
function _runAggregate() {
  _runAggregate = asyncToGenerator_default()(function* (options) {
    var {
      env,
      collectionName,
      stages,
      instanceContext,
      timing
    } = options;
    var explain = isDevTools() ? options.explain : undefined;
    var data = {
      collection_name: collectionName,
      stages: stages.map(stage => {
        for (var key in stage) {
          return {
            stage_key: key,
            stage_value: JSON.stringify(stage[key])
          };
        }
        throw new Error(`empty encoded stage (${JSON.stringify(stage)})`);
      }),
      explain
    };
    var serializedReqData = JSON.stringify(data);
    timing.tunnelStartTime = +new Date();
    var res = yield instanceContext.serviceContext.request({
      apiName: 'tcbapi_db_aggregate',
      serviceName: instanceContext.serviceContext.name,
      serializedReqData,
      requireDataNotEmpty: true,
      env: env || instanceContext.serviceContext.env
    });
    timing.tunnelEndTime = +new Date();
    if (explain) {
      var {
        EJSON
      } = __webpack_require__(432);
      return EJSON.deserialize(res.data);
    }
    var resData = res.data;
    timing.tunnelTimeNoCSNetCost = resData.baseresponse.stat.qbase_cost_time;
    if (false) {} else {
      var {
        EJSON: _EJSON
      } = __webpack_require__(432);
      return {
        list: JSON.parse(resData.list).map(item => _EJSON.parse(item))
      };
    }
  });
  return _runAggregate.apply(this, arguments);
}
function getRealtimeConnectionSignature(_x8, _x9) {
  return _getRealtimeConnectionSignature.apply(this, arguments);
}
function _getRealtimeConnectionSignature() {
  _getRealtimeConnectionSignature = asyncToGenerator_default()(function* (serviceContext, envId) {
    var res = yield serviceContext.request({
      apiName: 'tcbapi_db_get_realtime_connection',
      env: envId || serviceContext.env,
      serviceName: serviceContext.name,
      serializedReqData: JSON.stringify({}),
      requireDataNotEmpty: true
    });
    var resData = res.data;
    return {
      envId: resData.env_id,
      secretVersion: resData.secret_version,
      signStr: resData.sign_str,
      wsUrl: resData.ws_url
    };
  });
  return _getRealtimeConnectionSignature.apply(this, arguments);
}
;// CONCATENATED MODULE: ./src/services/database/api/database/aggregate.ts








var getAggregateClass = instanceContext => {
  class Aggregate extends PipelineBase {
    constructor(collection, stages) {
      super(stages);
      this.collection = void 0;
      this._internalType = symbol_SYMBOL_AGGREGATE;
      this.collection = collection;
    }
    pushStage(stage, val) {
      return new Aggregate(this.collection, [...this._stages, new PipelineStage(stage, val)]);
    }
    end(options = {}) {
      var apiName = 'collection.aggregate';
      var timing = {
        apiStartTime: +new Date()
      };
      var _runAggregate = () => {
        return runAggregate({
          env: instanceContext.database.config.env,
          collectionName: this.collection.collectionName,
          stages: instanceContext.engine.AggregateSerializer.encodeStages(this._stages),
          instanceContext,
          timing,
          explain: options.explain
        });
      };
      if (false) {}
      var useCallback = hasAPICallback(options);
      var promise = new Promise(/*#__PURE__*/function () {
        var _ref = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            var aggregateResult = yield _runAggregate();
            if (options.explain && isDevTools()) {
              return resolve(aggregateResult);
            }
            resolve({
              list: aggregateResult.list,
              errMsg: apiSuccessMsg(apiName)
            });
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, apiName));
          } finally {
            reportAPISpeed({
              ...timing,
              apiEndTime: +new Date(),
              apiName: `cloud.db.${apiName}`
            });
          }
        });
        return function (_x, _x2) {
          return _ref.apply(this, arguments);
        };
      }());
      if (useCallback) {
        promise.then(res => {
          invokeSuccessCompleteCallbacks(apiName, options, res);
        }).catch(err => {
          invokeFailCompleteCallbacks(apiName, options, err);
        });
      } else return promise;
    }
  }
  return Aggregate;
};
class PipelineStage {
  constructor(stage, val) {
    this.stage = void 0;
    this.val = void 0;
    this._internalType = SYMBOL_AGGREGATE_PIPELINE_STAGE;
    this.stage = stage;
    this.val = val;
  }
}
class PipelineBase {
  constructor(stages) {
    this._stages = void 0;
    this._internalType = SYMBOL_AGGREGATE_PIPELINE;
    this.__safe_props__ = void 0;
    this._stages = stages;
    if (false) {}
  }
  pushStage(stage, val) {
    return new PipelineBase([...this._stages, new PipelineStage(stage, val)]);
  }
  addFields(val) {
    return this.pushStage('addFields', val);
  }
  bucket(val) {
    return this.pushStage('bucket', val);
  }
  bucketAuto(val) {
    return this.pushStage('bucketAuto', val);
  }
  collStats(val) {
    return this.pushStage('collStats', val);
  }
  count(val) {
    return this.pushStage('count', val);
  }
  facet(val) {
    return this.pushStage('facet', val);
  }
  geoNear(val) {
    return this.pushStage('geoNear', val);
  }
  graphLookup(val) {
    return this.pushStage('graphLookup', val);
  }
  group(val) {
    return this.pushStage('group', val);
  }
  indexStats() {
    return this.pushStage('indexStats', {});
  }
  limit(val) {
    return this.pushStage('limit', val);
  }
  lookup(val) {
    return this.pushStage('lookup', val);
  }
  match(val) {
    return this.pushStage('match', val);
  }
  out(val) {
    return this.pushStage('out', val);
  }
  project(val) {
    return this.pushStage('project', val);
  }
  redact(val) {
    return this.pushStage('redact', val);
  }
  replaceRoot(val) {
    return this.pushStage('replaceRoot', val);
  }
  sample(val) {
    return this.pushStage('sample', val);
  }
  skip(val) {
    return this.pushStage('skip', val);
  }
  sort(val) {
    return this.pushStage('sort', val);
  }
  sortByCount(val) {
    return this.pushStage('sortByCount', val);
  }
  unwind(val) {
    return this.pushStage('unwind', val);
  }
  end() {}
}
class Pipeline extends PipelineBase {
  constructor(stages, sealed = false) {
    super(stages);
    this._sealed = void 0;
    this._sealed = sealed;
  }
  pushStage(stage, val) {
    if (this._sealed) {
      throw new Error(`pushing new stage is not allowed after calling 'done()'`);
    }
    return new Pipeline([...this._stages, new PipelineStage(stage, val)]);
  }
  done() {
    return new Pipeline(this._stages, true);
  }
}
var isAggregate = x => {
  return x && x._internalType === SYMBOL_AGGREGATE;
};
var isPipeline = x => {
  return x && x._internalType === SYMBOL_AGGREGATE_PIPELINE;
};
var isPipelineStage = x => {
  return x && x._internalType === SYMBOL_AGGREGATE_PIPELINE_STAGE;
};
;// CONCATENATED MODULE: ./src/services/database/api/database/command.ts







var pushModifiers = new Set(['each', 'position', 'slice', 'sort']);
var commands = {
  eq: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.EQ, [val]),
  neq: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.NEQ, [val]),
  lt: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.LT, [val]),
  lte: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.LTE, [val]),
  gt: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.GT, [val]),
  gte: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.GTE, [val]),
  in: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.IN, val),
  nin: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.NIN, val),
  geoNear: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.GEO_NEAR, [val]),
  geoWithin: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.GEO_WITHIN, [val]),
  geoIntersects: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.GEO_INTERSECTS, [val]),
  and(...__expressions__) {
    var expressions = isArray(arguments[0]) ? arguments[0] : Array.from(arguments);
    return new LogicCommmand(LOGIC_COMMANDS_LITERAL.AND, expressions);
  },
  or(...__expressions__) {
    var expressions = isArray(arguments[0]) ? arguments[0] : Array.from(arguments);
    return new LogicCommmand(LOGIC_COMMANDS_LITERAL.OR, expressions);
  },
  nor(...__expressions__) {
    var expressions = isArray(arguments[0]) ? arguments[0] : Array.from(arguments);
    return new LogicCommmand(LOGIC_COMMANDS_LITERAL.NOR, expressions);
  },
  not: expression => new LogicCommmand(LOGIC_COMMANDS_LITERAL.NOT, [expression]),
  exists: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.EXISTS, [val]),
  mod: (divisor, remainder) => new QueryCommmand(QUERY_COMMANDS_LITERAL.MOD, [divisor, remainder]),
  all: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.ALL, val),
  elemMatch: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.ELEM_MATCH, [val]),
  size: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.SIZE, [val]),
  expr: val => new QueryCommmand(QUERY_COMMANDS_LITERAL.EXPR, [val]),
  set: val => new UpdateCommand(UPDATE_COMMANDS_LITERAL.SET, [val]),
  remove: () => new UpdateCommand(UPDATE_COMMANDS_LITERAL.REMOVE, []),
  inc: val => new UpdateCommand(UPDATE_COMMANDS_LITERAL.INC, [val]),
  mul: val => new UpdateCommand(UPDATE_COMMANDS_LITERAL.MUL, [val]),
  min: val => new UpdateCommand(UPDATE_COMMANDS_LITERAL.MIN, [val]),
  max: val => new UpdateCommand(UPDATE_COMMANDS_LITERAL.MAX, [val]),
  rename: val => new UpdateCommand(UPDATE_COMMANDS_LITERAL.RENAME, [val]),
  bit: val => new UpdateCommand(UPDATE_COMMANDS_LITERAL.BIT, [val]),
  push(val) {
    var spec = {};
    if (isArray(val)) {
      spec.each = val;
    } else if (isObject(val) && isArray(val.each)) {
      var specKeys = Object.keys(val);
      if (specKeys.length === 1) {
        spec = val;
      } else {
        var hasNonSpecKey = false;
        for (var key of specKeys) {
          if (!pushModifiers.has(key)) {
            hasNonSpecKey = true;
            break;
          }
        }
        if (hasNonSpecKey) {
          spec = [val];
        } else {
          spec = val;
        }
      }
    } else {
      spec.each = [val];
    }
    return new UpdateCommand(UPDATE_COMMANDS_LITERAL.PUSH, [spec]);
  },
  pop: () => new UpdateCommand(UPDATE_COMMANDS_LITERAL.POP, []),
  shift: () => new UpdateCommand(UPDATE_COMMANDS_LITERAL.SHIFT, []),
  unshift(...__values__) {
    var values = isArray(arguments[0]) ? arguments[0] : Array.from(arguments);
    return new UpdateCommand(UPDATE_COMMANDS_LITERAL.UNSHIFT, values);
  },
  addToSet: val => new UpdateCommand(UPDATE_COMMANDS_LITERAL.ADD_TO_SET, [val]),
  pull: val => new UpdateCommand(UPDATE_COMMANDS_LITERAL.PULL, [val]),
  pullAll: val => new UpdateCommand(UPDATE_COMMANDS_LITERAL.PULL_ALL, [val]),
  project: {
    slice: val => new ProjectionCommmand(PROJECTION_COMMANDS_LITERAL.SLICE, [val])
  },
  aggregate: {
    pipeline: () => new Pipeline([]),
    abs: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ABS, [val]),
    add: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ADD, [val]),
    addToSet: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ADDTOSET, [val]),
    allElementsTrue: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ALLELEMENTSTRUE, [val]),
    and: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.AND, [val]),
    anyElementTrue: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ANYELEMENTTRUE, [val]),
    arrayElemAt: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ARRAYELEMAT, [val]),
    arrayToObject: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ARRAYTOOBJECT, [val]),
    avg: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.AVG, [val]),
    ceil: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.CEIL, [val]),
    cmp: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.CMP, [val]),
    concat: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.CONCAT, [val]),
    concatArrays: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.CONCATARRAYS, [val]),
    cond: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.COND, [val]),
    convert: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.CONVERT, [val]),
    dateFromParts: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.DATEFROMPARTS, [val]),
    dateToParts: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.DATETOPARTS, [val]),
    dateFromString: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.DATEFROMSTRING, [val]),
    dateToString: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.DATETOSTRING, [val]),
    dayOfMonth: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.DAYOFMONTH, [val]),
    dayOfWeek: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.DAYOFWEEK, [val]),
    dayOfYear: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.DAYOFYEAR, [val]),
    divide: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.DIVIDE, [val]),
    eq: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.EQ, [val]),
    exp: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.EXP, [val]),
    filter: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.FILTER, [val]),
    first: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.FIRST, [val]),
    floor: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.FLOOR, [val]),
    gt: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.GT, [val]),
    gte: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.GTE, [val]),
    hour: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.HOUR, [val]),
    ifNull: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.IFNULL, [val]),
    in: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.IN, [val]),
    indexOfArray: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.INDEXOFARRAY, [val]),
    indexOfBytes: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.INDEXOFBYTES, [val]),
    indexOfCP: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.INDEXOFCP, [val]),
    isArray: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ISARRAY, [val]),
    isoDayOfWeek: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ISODAYOFWEEK, [val]),
    isoWeek: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ISOWEEK, [val]),
    isoWeekYear: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ISOWEEKYEAR, [val]),
    last: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.LAST, [val]),
    let: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.LET, [val]),
    literal: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.LITERAL, [val]),
    ln: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.LN, [val]),
    log: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.LOG, [val]),
    log10: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.LOG10, [val]),
    lt: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.LT, [val]),
    lte: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.LTE, [val]),
    ltrim: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.LTRIM, [val]),
    map: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.MAP, [val]),
    max: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.MAX, [val]),
    mergeObjects: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.MERGEOBJECTS, [val]),
    meta: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.META, [val]),
    min: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.MIN, [val]),
    millisecond: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.MILLISECOND, [val]),
    minute: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.MINUTE, [val]),
    mod: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.MOD, [val]),
    month: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.MONTH, [val]),
    multiply: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.MULTIPLY, [val]),
    neq: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.NEQ, [val]),
    not: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.NOT, [val]),
    objectToArray: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.OBJECTTOARRAY, [val]),
    or: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.OR, [val]),
    pow: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.POW, [val]),
    push: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.PUSH, [val]),
    range: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.RANGE, [val]),
    reduce: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.REDUCE, [val]),
    reverseArray: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.REVERSEARRAY, [val]),
    rtrim: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.RTRIM, [val]),
    second: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SECOND, [val]),
    setDifference: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SETDIFFERENCE, [val]),
    setEquals: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SETEQUALS, [val]),
    setIntersection: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SETINTERSECTION, [val]),
    setIsSubset: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SETISSUBSET, [val]),
    setUnion: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SETUNION, [val]),
    size: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SIZE, [val]),
    slice: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SLICE, [val]),
    split: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SPLIT, [val]),
    sqrt: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SQRT, [val]),
    stdDevPop: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.STDDEVPOP, [val]),
    stdDevSamp: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.STDDEVSAMP, [val]),
    strcasecmp: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.STRCASECMP, [val]),
    strLenBytes: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.STRLENBYTES, [val]),
    strLenCP: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.STRLENCP, [val]),
    substr: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SUBSTR, [val]),
    substrBytes: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SUBSTRBYTES, [val]),
    substrCP: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SUBSTRCP, [val]),
    subtract: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SUBTRACT, [val]),
    sum: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SUM, [val]),
    switch: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.SWITCH, [val]),
    toBool: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TOBOOL, [val]),
    toDate: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TODATE, [val]),
    toDecimal: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TODECIMAL, [val]),
    toDouble: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TODOUBLE, [val]),
    toInt: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TOINT, [val]),
    toLong: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TOLONG, [val]),
    toObjectId: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TOOBJECTID, [val]),
    toString: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TOSTRING, [val]),
    toLower: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TOLOWER, [val]),
    toUpper: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TOUPPER, [val]),
    trim: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TRIM, [val]),
    trunc: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TRUNC, [val]),
    type: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.TYPE, [val]),
    week: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.WEEK, [val]),
    year: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.YEAR, [val]),
    zip: val => new AggregateCommand(AGGREGATE_COMMANDS_LITERAL.ZIP, [val])
  }
};
if (false) {}
/* harmony default export */ const command = ((/* unused pure expression or super */ null && (commands)));
;// CONCATENATED MODULE: ./src/services/database/api/database/date/serverDate.ts


function serverDate(options) {
  return new ServerDate(options);
}
class ServerDate {
  constructor(options = {
    offset: 0
  }) {
    this.options = void 0;
    assertType(options, 'object', 'serverDate.options');
    this.options = options;
  }
  get _internalType() {
    return SYMBOL_SERVER_DATE;
  }
  toJSON() {
    return {
      $date: this.options
    };
  }
}
;// CONCATENATED MODULE: ./src/services/database/api/database/date.ts

;// CONCATENATED MODULE: ./src/services/database/api/database/geo/point.ts




function Point(longitude, latitude) {
  if (isGeoJSONPoint(longitude)) {
    return toPoint(longitude);
  } else {
    return new GeoPoint(longitude, latitude);
  }
}
class GeoPoint {
  constructor(longitude, latitude) {
    this.longitude = void 0;
    this.latitude = void 0;
    this._internalType = SYMBOL_GEO_POINT;
    Object.defineProperties(this, {
      _internalType: {
        enumerable: false,
        configurable: false
      }
    });
    var lng = longitude;
    var lat = latitude;
    Object.defineProperties(this, {
      longitude: {
        enumerable: true,
        configurable: false,
        get() {
          return lng;
        },
        set(val) {
          assertType(val, 'number', 'longitude');
          if (val > 180 || val < -180) {
            throw new error_CloudSDKError({
              errMsg: `longitude should be a number ranges from -180 to 180`
            });
          }
        }
      },
      latitude: {
        enumerable: true,
        configurable: false,
        get() {
          return lat;
        },
        set(val) {
          assertType(val, 'number', 'latitude');
          if (val > 90 || val < -90) {
            throw new error_CloudSDKError({
              errMsg: `latitude should be a number ranges from -90 to 90`
            });
          }
        }
      }
    });
    this.longitude = lng;
    this.latitude = lat;
  }
  toJSON() {
    return toGeoJSONPoint(this);
  }
  toString() {
    return JSON.stringify(this.toJSON());
  }
}
;// CONCATENATED MODULE: ./src/services/database/api/database/geo/multipoint.ts


function MultiPoint(points) {
  if (isGeoJSONMultiPoint(points)) {
    return toMultiPoint(points);
  } else {
    return new GeoMultiPoint(points);
  }
}
class GeoMultiPoint {
  constructor(points) {
    this.points = void 0;
    this._internalType = SYMBOL_GEO_MULTIPOINT;
    Object.defineProperties(this, {
      _internalType: {
        enumerable: false,
        configurable: false
      }
    });
    this.points = points;
  }
  toJSON() {
    return toGeoJSONMultiPoint(this);
  }
  toString() {
    return JSON.stringify(this.toJSON());
  }
}
;// CONCATENATED MODULE: ./src/services/database/api/database/geo/linestring.ts


function LineString(points) {
  if (isGeoJSONLineString(points)) {
    return toLineString(points);
  } else {
    return new GeoLineString(points);
  }
}
class GeoLineString {
  constructor(points) {
    this.points = void 0;
    this._internalType = SYMBOL_GEO_LINESTRING;
    Object.defineProperties(this, {
      _internalType: {
        enumerable: false,
        configurable: false
      }
    });
    this.points = points;
  }
  toJSON() {
    return toGeoJSONLineString(this);
  }
  toString() {
    return JSON.stringify(this.toJSON());
  }
}
;// CONCATENATED MODULE: ./src/services/database/api/database/geo/multilinestring.ts


function MultiLineString(lines) {
  if (isGeoJSONMultiLineString(lines)) {
    return toMultiLineString(lines);
  } else {
    return new GeoMultiLineString(lines);
  }
}
class GeoMultiLineString {
  constructor(lines) {
    this.lines = void 0;
    this._internalType = SYMBOL_GEO_MULTILINESTRING;
    Object.defineProperties(this, {
      _internalType: {
        enumerable: false,
        configurable: false
      }
    });
    this.lines = lines;
  }
  toJSON() {
    return toGeoJSONMultiLineString(this);
  }
  toString() {
    return JSON.stringify(this.toJSON());
  }
}
;// CONCATENATED MODULE: ./src/services/database/api/database/geo/polygon.ts


function Polygon(lines) {
  if (isGeoJSONPolygon(lines)) {
    return toPolygon(lines);
  } else {
    return new GeoPolygon(lines);
  }
}
class GeoPolygon {
  constructor(lines) {
    this.lines = void 0;
    this._internalType = SYMBOL_GEO_POLYGON;
    Object.defineProperties(this, {
      _internalType: {
        enumerable: false,
        configurable: false
      }
    });
    this.lines = lines;
  }
  toJSON() {
    return toGeoJSONPolygon(this);
  }
  toString() {
    return JSON.stringify(this.toJSON());
  }
}
;// CONCATENATED MODULE: ./src/services/database/api/database/geo/multipolygon.ts


function MultiPolygon(polygons) {
  return isGeoJSONMultiPolygon(polygons) ? toMultiPolygon(polygons) : new GeoMultiPolygon(polygons);
}
class GeoMultiPolygon {
  constructor(polygons) {
    this.polygons = void 0;
    this._internalType = SYMBOL_GEO_MULTIPOLYGON;
    Object.defineProperties(this, {
      _internalType: {
        enumerable: false,
        configurable: false
      }
    });
    this.polygons = polygons;
  }
  toJSON() {
    return toGeoJSONMultiPolygon(this);
  }
  toString() {
    return JSON.stringify(this.toJSON());
  }
}
;// CONCATENATED MODULE: ./src/services/database/api/database/geo.ts






var __holder_safe_props__ = undefined;
if (false) {}
var __safe_props__ = __holder_safe_props__;
;// CONCATENATED MODULE: ./src/services/database/api/database/helper/geojson.ts



function fromGeoJSON(geojson) {
  switch (geojson.type) {
    case 'Point':
      {
        return toPoint(geojson);
      }
    case 'MultiPoint':
      {
        return toMultiPoint(geojson);
      }
    case 'LineString':
      {
        return toLineString(geojson);
      }
    case 'MultiLineString':
      {
        return toMultiLineString(geojson);
      }
    case 'Polygon':
      {
        return toPolygon(geojson);
      }
    case 'MultiPolygon':
      {
        return toMultiPolygon(geojson);
      }
    default:
      {
        throw new CloudSDKError({
          errCode: -1,
          errMsg: `Invalid GeoJSON input`
        });
      }
  }
}
function toPoint(geojson) {
  return Point(geojson.coordinates[0], geojson.coordinates[1]);
}
function toMultiPoint(geojson) {
  return MultiPoint(geojson.coordinates.map(coordinate => Point(coordinate[0], coordinate[1])));
}
function toLineString(geojson) {
  return LineString(geojson.coordinates.map(coordinate => Point(coordinate[0], coordinate[1])));
}
function toMultiLineString(geojson) {
  return MultiLineString(geojson.coordinates.map(lines => LineString(lines.map(line => Point(line[0], line[1])))));
}
function toPolygon(geojson) {
  return Polygon(geojson.coordinates.map(lines => LineString(lines.map(line => Point(line[0], line[1])))));
}
function toMultiPolygon(geojson) {
  return MultiPolygon(geojson.coordinates.map(polygons => Polygon(polygons.map(polygon => LineString(polygon.map(line => Point(line[0], line[1])))))));
}
function toGeoJSONPoint(point) {
  return {
    type: 'Point',
    coordinates: [point.longitude, point.latitude]
  };
}
function toGeoJSONMultiPoint(multipoint) {
  return {
    type: 'MultiPoint',
    coordinates: multipoint.points.map(p => [p.longitude, p.latitude])
  };
}
function toGeoJSONLineString(linestring) {
  return {
    type: 'LineString',
    coordinates: linestring.points.map(p => [p.longitude, p.latitude])
  };
}
function toGeoJSONMultiLineString(multiLineString) {
  return {
    type: 'MultiLineString',
    coordinates: multiLineString.lines.map(line => line.points.map(p => [p.longitude, p.latitude]))
  };
}
function toGeoJSONPolygon(polygon) {
  return {
    type: 'Polygon',
    coordinates: polygon.lines.map(line => line.points.map(p => [p.longitude, p.latitude]))
  };
}
function toGeoJSONMultiPolygon(multiPolygon) {
  return {
    type: 'MultiPolygon',
    coordinates: multiPolygon.polygons.map(polygon => polygon.lines.map(line => line.points.map(p => [p.longitude, p.latitude])))
  };
}
function isGeoJSONPoint(obj) {
  return isObject(obj) && isPointCoordinates(obj.coordinates);
}
function isGeoJSONMultiPoint(obj) {
  return isObject(obj) && isMultiPointCoordinates(obj.coordinates);
}
function isGeoJSONLineString(obj) {
  return isObject(obj) && isLineStringCoordinates(obj.coordinates);
}
function isGeoJSONMultiLineString(obj) {
  return isObject(obj) && isMultiLineStringCoordinates(obj.coordinates);
}
function isGeoJSONPolygon(obj) {
  return isObject(obj) && isPolygonCoordinates(obj.coordinates);
}
function isGeoJSONMultiPolygon(obj) {
  return isObject(obj) && isMultiPolygonCoordinates(obj.coordinates);
}
function isPointCoordinates(coordinates) {
  return isArray(coordinates) && isNumber(coordinates[0]) && isNumber(coordinates[1]);
}
function isMultiPointCoordinates(coordinates) {
  return isArray(coordinates) && coordinates.every(isPointCoordinates);
}
function isLineStringCoordinates(coordinates) {
  return isMultiPointCoordinates(coordinates);
}
function isMultiLineStringCoordinates(coordinates) {
  return isArray(coordinates) && coordinates.every(isLineStringCoordinates);
}
function isPolygonCoordinates(coordinates) {
  return isMultiLineStringCoordinates(coordinates);
}
function isMultiPolygonCoordinates(coordinates) {
  return isArray(coordinates) && coordinates.every(isPolygonCoordinates);
}
;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/serializer/datatype.ts






function datatype_serialize(val) {
  return serializeHelper(val, [val]);
}
function serializeHelper(val, visited) {
  if (isInternalObject(val)) {
    switch (val._internalType) {
      case SYMBOL_GEO_POINT:
      case SYMBOL_GEO_MULTIPOINT:
      case SYMBOL_GEO_LINESTRING:
      case SYMBOL_GEO_MULTILINESTRING:
      case SYMBOL_GEO_POLYGON:
      case SYMBOL_GEO_MULTIPOLYGON:
        {
          return val.toJSON();
        }
      case SYMBOL_SERVER_DATE:
        {
          return {
            $date: val.options
          };
        }
      case SYMBOL_REGEXP:
        {
          return {
            $regex: val.regexp,
            $options: val.options
          };
        }
      default:
        {
          return val.toJSON ? val.toJSON() : val;
        }
    }
  } else if (isDate(val)) {
    return {
      $date: +val
    };
  } else if (isRegExp(val)) {
    return {
      $regex: val.source,
      $options: val.flags
    };
  } else if (isArray(val)) {
    return val.map(item => {
      if (visited.indexOf(item) > -1) {
        throw new error_CloudSDKError({
          errCode: error_config_ERR_CODE.SDK_DATABASE_CIRCULAR_REFERENCE,
          errMsg: `Cannot convert circular structure to JSON`
        });
      }
      return serializeHelper(item, [...visited, item]);
    });
  } else if (isObject(val)) {
    var ret = {
      ...val
    };
    for (var key in ret) {
      if (visited.indexOf(ret[key]) > -1) {
        throw new error_CloudSDKError({
          errCode: error_config_ERR_CODE.SDK_DATABASE_CIRCULAR_REFERENCE,
          errMsg: `Cannot convert circular structure to JSON`
        });
      }
      ret[key] = serializeHelper(ret[key], [...visited, ret[key]]);
    }
    return ret;
  } else {
    return val;
  }
}
function datatype_deserialize(object) {
  var ret = {
    ...object
  };
  for (var key in ret) {
    switch (key) {
      case '$date':
        {
          switch (type_getType(ret[key])) {
            case 'number':
              {
                return new Date(ret[key]);
              }
            case 'object':
              {
                return serverDate(ret[key]);
              }
          }
          break;
        }
      case 'type':
        {
          var coordinates = ret.coordinates;
          switch (ret.type) {
            case 'Point':
              {
                if (isGeoJSONPoint(ret)) {
                  return toPoint(ret);
                }
                break;
              }
            case 'MultiPoint':
              {
                if (isGeoJSONMultiPoint(ret)) {
                  return toMultiPoint(ret);
                }
                break;
              }
            case 'LineString':
              {
                if (isGeoJSONLineString(ret)) {
                  return toLineString(ret);
                }
                break;
              }
            case 'MultiLineString':
              {
                if (isGeoJSONMultiLineString(ret)) {
                  return toMultiLineString(ret);
                }
                break;
              }
            case 'Polygon':
              {
                if (isGeoJSONPolygon(ret)) {
                  return toPolygon(ret);
                }
                break;
              }
            case 'MultiPolygon':
              {
                if (isGeoJSONMultiPolygon(ret)) {
                  return toMultiPolygon(ret);
                }
                break;
              }
          }
          break;
        }
    }
  }
  return object;
}
;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/serializer/common.ts




function flatten(query, shouldPreserveObject, parents, visited) {
  var cloned = {
    ...query
  };
  for (var key in query) {
    if (/^\$/.test(key)) continue;
    var value = query[key];
    if (!value) continue;
    if (isObject(value) && !shouldPreserveObject(value)) {
      if (visited.indexOf(value) > -1) {
        throw new error_CloudSDKError({
          errCode: error_config_ERR_CODE.SDK_DATABASE_CIRCULAR_REFERENCE,
          errMsg: `Cannot convert circular structure to JSON`
        });
      }
      var newParents = [...parents, key];
      var newVisited = [...visited, value];
      var flattenedChild = flatten(value, shouldPreserveObject, newParents, newVisited);
      cloned[key] = flattenedChild;
      var hasKeyNotCombined = false;
      for (var childKey in flattenedChild) {
        if (!/^\$/.test(childKey)) {
          cloned[`${key}.${childKey}`] = flattenedChild[childKey];
          delete cloned[key][childKey];
        } else {
          hasKeyNotCombined = true;
        }
      }
      if (!hasKeyNotCombined) {
        delete cloned[key];
      }
    }
  }
  return cloned;
}
function flattenQueryObject(query) {
  return flatten(query, isConversionRequired, [], [query]);
}
function flattenObject(object) {
  return flatten(object, _ => false, [], [object]);
}
function mergeConditionAfterEncode(query, condition, key) {
  if (!condition[key]) {
    delete query[key];
  }
  for (var conditionKey in condition) {
    if (query[conditionKey]) {
      if (isArray(query[conditionKey])) {
        query[conditionKey].push(condition[conditionKey]);
      } else if (isObject(query[conditionKey])) {
        if (isObject(condition[conditionKey])) {
          Object.assign(query[conditionKey], condition[conditionKey]);
        } else {
          console.warn(`unmergable condition, query is object but condition is ${type_getType(condition)}, can only overwrite`, condition, key);
          query[conditionKey] = condition[conditionKey];
        }
      } else {
        console.warn(`to-merge query is of type ${type_getType(query)}, can only overwrite`, query, condition, key);
        query[conditionKey] = condition[conditionKey];
      }
    } else {
      query[conditionKey] = condition[conditionKey];
    }
  }
}
function isConversionRequired(val) {
  return isInternalObject(val) || isDate(val) || isRegExp(val);
}
function encodeInternalDataType(val) {
  return datatype_serialize(val);
}
function decodeInternalDataType(object) {
  return datatype_deserialize(object);
}
;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/extractor.ts



function extractQueryOptions(query, instanceContext) {
  return {
    limit: query._query.limit,
    offset: query._query.offset,
    order: convertOrder(query._query.order || []),
    projection: instanceContext.engine.ProjectionSerializer.encode(query._field)
  };
}
function convertOrder(order) {
  if (false) {}
  return order.map(item => ({
    field: item.fieldPath,
    direction: item.order === query_ORDER_DIRECTION.DESC ? ORDER_DIRECTION.DESC : ORDER_DIRECTION.ASC
  }));
}
function getProjectionDefinition(object) {
  var flattened = flattenObject(object);
  for (var key in flattened) {
    if (flattened[key] === true || flattened[key] === 1) {
      flattened[key] = 1;
    } else if (flattened[key] === false || flattened[key] === 0) {
      flattened[key] = 0;
    } else {
      delete flattened[key];
    }
  }
  return flattened;
}
;// CONCATENATED MODULE: ./src/services/database/api/database/realtime/fsm/ws.ts
var WSState = /*#__PURE__*/function (WSState) {
  WSState["DISCONNECTED"] = "DISCONNECTED";
  WSState["CONNECTING"] = "CONNECTING";
  WSState["CONNECTED"] = "CONNECTED";
  return WSState;
}({});
var WSEvent = /*#__PURE__*/function (WSEvent) {
  WSEvent["CONNECTION_START"] = "connectionStart";
  WSEvent["CONNECTION_SUCCESS"] = "connectionSuccess";
  WSEvent["CONNECTION_FAIL"] = "connectionFail";
  WSEvent["DISCONNECT"] = "disconnect";
  return WSEvent;
}({});
var WSStates = {
  [WSState.DISCONNECTED]: {
    transitions: [{
      accept: WSEvent.CONNECTION_START,
      to: WSState.CONNECTING
    }]
  },
  [WSState.CONNECTING]: {
    transitions: [{
      accept: WSEvent.CONNECTION_SUCCESS,
      to: WSState.CONNECTED
    }, {
      accept: WSEvent.CONNECTION_FAIL,
      to: WSState.DISCONNECTED
    }, {
      accept: WSEvent.DISCONNECT,
      to: WSState.DISCONNECTED
    }]
  },
  [WSState.CONNECTED]: {
    transitions: [{
      accept: WSEvent.DISCONNECT,
      to: WSState.DISCONNECTED
    }, {
      accept: WSEvent.CONNECTION_FAIL,
      to: WSState.DISCONNECTED
    }]
  }
};
;// CONCATENATED MODULE: ./src/utils/set.ts
function cacheStringFunction(fn) {
  var cached = new Map();
  return function (str) {
    if (!cached.has(str)) cached.set(str, fn(str));
    return cached.get(str);
  };
}
var splitPaths = cacheStringFunction(path => path.replace(/\[(\d+)\]/g, '.[$1]').split('.').map(segment => /^\[(\d+)\]$/.test(segment) ? parseInt(segment.substring(1, segment.length - 1)) : segment));
function set(obj, path, value) {
  if (!obj) return;
  if (Object.prototype.hasOwnProperty.call(obj, path)) {
    obj[path] = value;
    return;
  }
  var paths = splitPaths(path);
  var current = obj;
  for (var i = 0; i < paths.length - 1; ++i) {
    var p = paths[i];
    if (!current[p]) current[p] = typeof paths[i + 1] === 'string' ? {} : [];
    current = current[p];
  }
  current[paths[paths.length - 1]] = value;
  return obj;
}
function unset(obj, path) {
  if (!obj) return;
  if (Object.prototype.hasOwnProperty.call(obj, path)) {
    delete obj[path];
    return;
  }
  var paths = splitPaths(path);
  var current = obj;
  for (var i = 0; i < paths.length - 1; ++i) {
    var p = paths[i];
    if (!current[p]) return;
    current = current[p];
  }
  delete current[paths[paths.length - 1]];
  return obj;
}
;// CONCATENATED MODULE: ./src/services/database/api/database/realtime/fsm/vws.ts
var VWSState = /*#__PURE__*/function (VWSState) {
  VWSState["UNINIT"] = "UNINIT";
  VWSState["CLOSED"] = "CLOSED";
  VWSState["INIT_LOGGING_IN"] = "INIT_LOGGING_IN";
  VWSState["INIT_LOGGED_IN"] = "INIT_LOGGED_IN";
  VWSState["INIT_LOGIN_FAIL"] = "INIT_LOGIN_FAIL";
  VWSState["INIT_WATCH_PENDING"] = "INIT_WATCH_PENDING";
  VWSState["INIT_WATCH_FAIL"] = "INIT_WATCH_FAIL";
  VWSState["INIT_WATCH_SUCCESS"] = "INIT_WATCH_SUCCESS";
  VWSState["PAUSED"] = "PAUSED";
  VWSState["ABNORMAL_WATCH_STATUS"] = "ABNORMAL_WATCH_STATUS";
  VWSState["REBUILD_LOGGING_IN"] = "REBUILD_LOGGING_IN";
  VWSState["REBUILD_LOGGED_IN"] = "REBUILD_LOGGED_IN";
  VWSState["REBUILD_LOGIN_FAIL"] = "REBUILD_LOGIN_FAIL";
  VWSState["REBUILD_WATCH_PENDING"] = "REBUILD_WATCH_PENDING";
  VWSState["REBUILD_WATCH_FAIL"] = "REBUILD_WATCH_FAIL";
  VWSState["REBUILD_WATCH_SUCCESS"] = "REBUILD_WATCH_SUCCESS";
  return VWSState;
}({});
var VWSEvent = /*#__PURE__*/function (VWSEvent) {
  VWSEvent["CLOSE"] = "close";
  VWSEvent["LOGIN_START"] = "loginStart";
  VWSEvent["LOGIN_FAIL"] = "loginFail";
  VWSEvent["LOGIN_SUCCESS"] = "loginSuccess";
  VWSEvent["INIT_WATCH_START"] = "initWatchStart";
  VWSEvent["INIT_WATCH_FAIL"] = "initWatchFail";
  VWSEvent["INIT_WATCH_SUCCESS"] = "initWatchSuccess";
  VWSEvent["WS_DISCONNECTED"] = "wsDisconnected";
  VWSEvent["WS_CONNECTED"] = "wsConnected";
  VWSEvent["REBUILD_WATCH_START"] = "rebuildWatchStart";
  VWSEvent["REBUILD_WATCH_FAIL"] = "rebuildWatchFail";
  VWSEvent["REBUILD_WATCH_SUCCESS"] = "rebuildWatchSuccess";
  VWSEvent["NEED_REBUILD_WATCH"] = "needRebuildWatch";
  return VWSEvent;
}({});
var CLOSE_TRANSITION = {
  accept: VWSEvent.CLOSE,
  to: VWSState.CLOSED
};
var FATAL_WS_DISCONNECTED_TRANSITION = {
  accept: VWSEvent.WS_DISCONNECTED,
  to: VWSState.CLOSED
};
var RESUMABLE_WS_DISCONNECTED_TRANSITION = {
  accept: VWSEvent.WS_DISCONNECTED,
  to: VWSState.PAUSED
};
var VWSStates = {
  [VWSState.UNINIT]: {
    transitions: [{
      accept: VWSEvent.LOGIN_START,
      to: VWSState.INIT_LOGGING_IN
    }, FATAL_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.CLOSED]: {
    transitions: [CLOSE_TRANSITION]
  },
  [VWSState.INIT_LOGGING_IN]: {
    transitions: [{
      accept: VWSEvent.LOGIN_FAIL,
      to: VWSState.INIT_LOGIN_FAIL
    }, {
      accept: VWSEvent.LOGIN_SUCCESS,
      to: VWSState.INIT_LOGGED_IN
    }, FATAL_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.INIT_LOGIN_FAIL]: {
    transitions: [{
      accept: VWSEvent.LOGIN_START,
      to: VWSState.INIT_LOGGING_IN
    }, FATAL_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.INIT_LOGGED_IN]: {
    transitions: [{
      accept: VWSEvent.INIT_WATCH_START,
      to: VWSState.INIT_WATCH_PENDING
    }, FATAL_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.INIT_WATCH_PENDING]: {
    transitions: [{
      accept: VWSEvent.INIT_WATCH_FAIL,
      to: VWSState.INIT_WATCH_FAIL
    }, {
      accept: VWSEvent.INIT_WATCH_SUCCESS,
      to: VWSState.INIT_WATCH_SUCCESS
    }, FATAL_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.INIT_WATCH_FAIL]: {
    transitions: [{
      accept: VWSEvent.LOGIN_START,
      to: VWSState.INIT_LOGGING_IN
    }, FATAL_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.INIT_WATCH_SUCCESS]: {
    transitions: [{
      accept: VWSEvent.WS_DISCONNECTED,
      to: VWSState.PAUSED
    }, {
      accept: VWSEvent.NEED_REBUILD_WATCH,
      to: VWSState.ABNORMAL_WATCH_STATUS
    }, RESUMABLE_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.PAUSED]: {
    transitions: [{
      accept: VWSEvent.LOGIN_START,
      to: VWSState.REBUILD_LOGGING_IN
    }, RESUMABLE_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.ABNORMAL_WATCH_STATUS]: {
    transitions: [{
      accept: VWSEvent.LOGIN_START,
      to: VWSState.REBUILD_LOGGING_IN
    }, RESUMABLE_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.REBUILD_LOGGING_IN]: {
    transitions: [{
      accept: VWSEvent.LOGIN_FAIL,
      to: VWSState.REBUILD_LOGIN_FAIL
    }, {
      accept: VWSEvent.LOGIN_SUCCESS,
      to: VWSState.REBUILD_LOGGED_IN
    }, RESUMABLE_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.REBUILD_LOGIN_FAIL]: {
    transitions: [{
      accept: VWSEvent.LOGIN_START,
      to: VWSState.REBUILD_LOGGING_IN
    }, RESUMABLE_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.REBUILD_LOGGED_IN]: {
    transitions: [{
      accept: VWSEvent.REBUILD_WATCH_START,
      to: VWSState.REBUILD_WATCH_PENDING
    }, RESUMABLE_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.REBUILD_WATCH_PENDING]: {
    transitions: [{
      accept: VWSEvent.REBUILD_WATCH_FAIL,
      to: VWSState.REBUILD_WATCH_FAIL
    }, {
      accept: VWSEvent.REBUILD_WATCH_SUCCESS,
      to: VWSState.REBUILD_WATCH_SUCCESS
    }, RESUMABLE_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.REBUILD_WATCH_FAIL]: {
    transitions: [{
      accept: VWSEvent.LOGIN_START,
      to: VWSState.REBUILD_LOGGING_IN
    }, RESUMABLE_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  },
  [VWSState.REBUILD_WATCH_SUCCESS]: {
    transitions: [{
      accept: VWSEvent.NEED_REBUILD_WATCH,
      to: VWSState.ABNORMAL_WATCH_STATUS
    }, RESUMABLE_WS_DISCONNECTED_TRANSITION, CLOSE_TRANSITION]
  }
};
;// CONCATENATED MODULE: ./src/utils/fsm.ts
class FSM {
  constructor(opt) {
    this.currentState = void 0;
    this.states = void 0;
    this.listeners = new Set();
    this.history = void 0;
    this.currentState = opt.initialState;
    this.states = new Map();
    for (var name in opt.states) {
      this.states.set(name, {
        name,
        transitions: new Map(opt.states[name].transitions.map(({
          accept,
          to
        }) => [accept, to]))
      });
    }
    this.history = {
      options: {
        enable: false,
        limit: 100
      },
      transitions: []
    };
    if (opt.history) {
      if (typeof opt.history === 'boolean') {
        if (opt.history) {
          this.history.options.enable = true;
        }
      } else if (Boolean(opt.history.enable)) {
        if (opt.history.limit === undefined || opt.history.limit === null) {
          this.history.options = {
            enable: true,
            limit: 100
          };
        } else if (opt.history.limit > 0) {
          this.history.options = {
            enable: true,
            limit: opt.history.limit
          };
        }
      }
    }
    if (this.history.options.enable) {
      this.history.transitions.push({
        state: this.currentState
      });
    }
  }
  transition(event, expectFrom) {
    if (expectFrom && (expectFrom instanceof Set ? !expectFrom.has(this.currentState) : expectFrom !== this.currentState)) {
      throw new FSMTransitionError(`current state (${this.currentState}) != expected from state (${expectFrom instanceof Set ? JSON.stringify([...expectFrom]) : expectFrom})`, 'unexpectedFromState');
    }
    var _event = typeof event === 'string' ? {
      type: event
    } : event;
    var currentStateInfo = this.states.get(this.currentState);
    var nextState = currentStateInfo.transitions.get(_event.type);
    if (!nextState) {
      throw new FSMTransitionError(`current state (${this.currentState}) does not accept "${_event.type}"`, 'unexpectedInput');
    }
    this.currentState = nextState;
    if (this.history.options.enable) {
      this.history.transitions.push({
        event: _event.type,
        state: this.currentState
      });
      if (this.history.transitions.length > this.history.options.limit) {
        if (this.history.transitions.length === this.history.options.limit + 1) {
          this.history.transitions.shift();
        } else {
          this.history.transitions.splice(0, this.history.transitions.length - this.history.options.limit);
        }
      }
    }
    this.listeners.forEach(fn => {
      try {
        fn({
          event: _event,
          from: currentStateInfo.name,
          to: this.currentState
        });
      } catch (err) {
        console.error('FSM listener exec error: ', err);
      }
    });
  }
  canAccept(event) {
    var currentStateInfo = this.states.get(this.currentState);
    return currentStateInfo.transitions.has(event);
  }
  subscribe(listener) {
    this.listeners.add(listener);
  }
  unsubscribe(listener) {
    this.listeners.delete(listener);
  }
  getHistoryRepresentation(opt) {
    if (!this.history.options.enable) return '';
    var transitions = opt.limit ? this.history.transitions.slice(-opt.limit) : this.history.transitions;
    return `states: ${transitions.map(({
      state,
      event
    }) => `${event ? `-(${event})->` : ''}${state}`).join('')}`;
  }
}
class FSMTransitionError extends Error {
  constructor(message, subtype, payload) {
    super(message);
    this.type = 'transition';
    this.subtype = void 0;
    this.payload = void 0;
    this.generic = true;
    this.subtype = subtype;
    this.payload = payload;
  }
}
var isFSMTransitionError = e => e.type === 'transition';
;// CONCATENATED MODULE: ./src/services/database/api/database/realtime/message.ts
function genRequestId(prefix = '') {
  return `${prefix ? `${prefix}_` : ''}${+new Date()}_${Math.random()}`;
}
function isInitEventMessage(msg) {
  return msg.msgType === 'INIT_EVENT';
}
;// CONCATENATED MODULE: ./src/config/report.config.ts
var ErrorID = 1128;
var ErrorKey = {
  REALTIME_DB_INIT_WS_SUCCESS: 1,
  REALTIME_DB_INIT_WS_FAIL: 2,
  REALTIME_DB_RECONNECT_WS_SUCCESS: 3,
  REALTIME_DB_RECONNECT_WS_FAIL: 4,
  REALTIME_DB_INIT_WATCH_SUCCESS: 5,
  REALTIME_DB_INIT_WATCH_FAIL: 6,
  REALTIME_DB_REBUILD_WATCH_SUCCESS: 7,
  REALTIME_DB_REBUILD_WATCH_FAIL: 8,
  REALTIME_DB_WS_ONERROR_BEFORE_OPEN: 9,
  REALTIME_DB_WS_ONERROR_WHILE_ACTIVE: 10,
  REALTIME_DB_WS_ONCLOSE: 11,
  REALTIME_DB_WS_ONCLOSE_HEARTBEAT_PING_FAIL: 12,
  REALTIME_DB_WS_ONCLOSE_HEARTBEAT_PONG_TIMEOUT: 13,
  REALTIME_DB_WS_ONCLOSE_AB_NORMAL_CLOSURE: 14,
  REALTIME_DB_WS_ONCLOSE_SERVER_CLOSE_NO_AUTH: 15,
  REALTIME_DB_WS_ONCLOSE_UNKNOWN_ORIGIN: 16,
  REALTIME_DB_WS_TOTAL_CONNECTION_TIMEOUT: 17,
  REALTIME_DB_WS_ONCLOSE_SERVER_CLOSE_FOR_UPGRADE: 18,
  REALTIME_DB_RECV_MSG_WITH_CLOSED_WATCHID: 30,
  REALTIME_DB_RECV_MSG_WITH_UNKNOWN_WATCHID: 31,
  REALTIME_DB_RECV_MSG_WITHOUT_WATCHID: 32,
  REALTIME_DB_HANDLE_EVENT_ERROR: 33,
  REALTIME_DB_RECV_DUPLICATE_EVENT: 34,
  REALTIME_DB_RECV_DUPLICATE_EVENT_AND_EVENT_OUT_OF_ORDER: 35,
  REALTIME_DB_UNEXPECTED_EVENT_DATATYPE_UPDATE_NO_ASSOCIATED_DOC: 36,
  REALTIME_DB_UNEXPECTED_EVENT_REMOVE_NO_ASSOCIATED_DOC: 37,
  REALTIME_DB_UNEXPECTED_EVENT_DEQUEUE_NO_ASSOCIATED_DOC: 38,
  REALTIME_DB_UNEXPECTED_EVENT_QUEUETYPE_UPDATE_NO_ASSOCIATED_DOC: 39,
  REALTIME_DB_EVENT_OUT_OF_ORDER: 40,
  REALTIME_DB_INIT_WATCH_FAIL_SERVER_SIGN_ERROR: 50,
  REALTIME_DB_REBUILD_WATCH_FAIL_SERVER_SIGN_ERROR: 51,
  REALTIME_DB_INIT_WATCH_FAIL_SERVER_OTHER_ERROR: 52,
  REALTIME_DB_REBUILD_WATCH_FAIL_SERVER_OTHER_ERROR: 53,
  REALTIME_DB_INIT_WATCH_FAIL_TIMEOUT_ERROR_TOTAL_CONNECTION: 54,
  REALTIME_DB_REBUILD_WATCH_FAIL_TIMEOUT_ERROR_TOTAL_CONNECTION: 55,
  REALTIME_DB_REBUILD_WATCH_FAIL_TIMEOUT_ERROR_QUERY_EVENT_CACHE: 56,
  REALTIME_DB_INIT_WATCH_FAIL_CANCELLED_ERROR: 57,
  REALTIME_DB_REBUILD_WATCH_FAIL_CANCELLED_ERROR: 58,
  REALTIME_DB_INIT_WATCH_FAIL_UNKNOWN_ERROR: 59,
  REALTIME_DB_REBUILD_WATCH_FAIL_UNKNOWN_ERROR: 60
};
;// CONCATENATED MODULE: ./src/services/database/api/database/realtime/listener.ts
class RealtimeListener {
  constructor(options) {
    this.close = void 0;
    this.onChange = void 0;
    this.onError = void 0;
    this.close = options.close;
    this.onChange = options.onChange;
    this.onError = options.onError;
    if (options.debug) {
      Object.defineProperty(this, 'virtualClient', {
        get: () => {
          return options.virtualClient;
        }
      });
    }
  }
}
;// CONCATENATED MODULE: ./src/services/database/api/database/realtime/snapshot.ts
class Snapshot {
  constructor(options) {
    this.id = void 0;
    this.docChanges = void 0;
    this.docs = void 0;
    this.type = void 0;
    this.EJSON = void 0;
    this.requestId = void 0;
    this.watchId = void 0;
    var {
      id,
      docChanges,
      docs,
      type,
      EJSON,
      requestId,
      watchId
    } = options;
    Object.defineProperties(this, {
      id: {
        value: id,
        writable: false,
        enumerable: true
      },
      docChanges: {
        value: docChanges,
        writable: false,
        enumerable: true
      },
      docs: {
        value: docs,
        writable: false,
        enumerable: true
      },
      type: {
        value: type,
        writable: false,
        enumerable: true
      }
    });
    this.requestId = requestId;
    this.watchId = watchId;
  }
}
;// CONCATENATED MODULE: ./src/services/database/api/database/realtime/error.ts
class RealtimeErrorMessageError extends Error {
  constructor(serverErrorMsg) {
    super(`Watch Error ${JSON.stringify(serverErrorMsg.msgData)} (requestid: ${serverErrorMsg.requestId})`);
    this.isRealtimeErrorMessageError = true;
    this.payload = void 0;
    this.payload = serverErrorMsg;
  }
}
var isRealtimeErrorMessageError = e => e && e.isRealtimeErrorMessageError;
;// CONCATENATED MODULE: ./src/services/database/api/database/realtime/virtual-websocket-client.ts














var DEFAULT_MAX_AUTO_RETRY_ON_ERROR = 2;
var DEFAULT_MAX_SEND_ACK_AUTO_RETRY_ON_ERROR = 2;
var DEFAULT_SEND_ACK_DEBOUNCE_TIMEOUT = 10 * 1000;
var DEFAULT_INIT_WATCH_TIMEOUT = 10 * 1000;
var DEFAULT_REBUILD_WATCH_TIMEOUT = 10 * 1000;
var STATES_LOGGING_IN = new Set([VWSState.REBUILD_LOGGING_IN, VWSState.INIT_LOGGING_IN]);
var noopOnError = e => {
  if (false) {}
};
class VirtualWebSocketClient {
  constructor(_options) {
    var _this = this;
    this.watchId = void 0;
    this._parentFSM = void 0;
    this._fsm = void 0;
    this.envId = void 0;
    this.collectionName = void 0;
    this.query = void 0;
    this.limit = void 0;
    this.orderBy = void 0;
    this.queryType = void 0;
    this.send = void 0;
    this.login = void 0;
    this.isWSConnected = void 0;
    this.getWaitExpectedTimeoutLength = void 0;
    this.getEJSON = void 0;
    this.getServiceContext = void 0;
    this.onWatchStart = void 0;
    this.onWatchClose = void 0;
    this.timing = void 0;
    this.closeWatchInvoked = false;
    this.userOnErrorInvoked = false;
    this.debug = void 0;
    this.wsclient = void 0;
    this.listener = void 0;
    this._availableRetries = void 0;
    this._ackTimeoutId = void 0;
    this._loginInvalidated = false;
    this._errors = [];
    this._parentFSMListener = void 0;
    this._FSMListener = void 0;
    this._wsDisconnectionTS = void 0;
    this.sessionInfo = void 0;
    this._waitExpectedTimeoutId = void 0;
    this._snapshotHistory = [];
    this._login = /*#__PURE__*/function () {
      var _ref = asyncToGenerator_default()(function* (refresh) {
        _this._fsm.transition(VWSEvent.LOGIN_START);
        try {
          var loginResult = yield _this.login(_this.envId, refresh || _this._loginInvalidated, _this.timing);
          if (!_this.envId) {
            _this.envId = loginResult.envId;
          }
          _this._fsm.transition(VWSEvent.LOGIN_SUCCESS, STATES_LOGGING_IN);
          _this._loginInvalidated = false;
        } catch (e) {
          _this._errors.push(e);
          _this._loginInvalidated = true;
          try {
            _this._fsm.transition(VWSEvent.LOGIN_FAIL, STATES_LOGGING_IN);
          } catch (e) {
            console.warn('[realtime]', e);
          }
        }
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }();
    this.initWatch = /*#__PURE__*/asyncToGenerator_default()(function* () {
      var apiStartTime = Date.now();
      var requestId = genRequestId();
      try {
        _this._fsm.transition(VWSEvent.INIT_WATCH_START, VWSState.INIT_LOGGED_IN);
        var envId = _this.envId;
        var initWatchMsg = {
          watchId: _this.watchId,
          requestId,
          msgType: 'INIT_WATCH',
          msgData: {
            envId,
            collName: _this.collectionName,
            query: _this.query,
            limit: _this.limit,
            orderBy: _this.orderBy,
            queryType: _this.queryType
          }
        };
        var initEventMsg = yield _this.send({
          msg: initWatchMsg,
          waitResponse: true,
          skipOnMessage: true,
          timeout: DEFAULT_INIT_WATCH_TIMEOUT
        });
        _this.assertAsyncTaskStatus();
        var {
          events,
          currEvent
        } = initEventMsg.msgData;
        _this.sessionInfo = {
          queryID: initEventMsg.msgData.queryID,
          currentEventId: currEvent - 1,
          currentDocs: [],
          currentEventTS: Date.now()
        };
        if (events.length > 0) {
          for (var e of events) {
            e.ID = currEvent;
          }
          _this.handleServerEvents(initEventMsg);
        } else {
          _this.sessionInfo.currentEventId = currEvent;
          var snapshot = new Snapshot({
            id: currEvent,
            docChanges: [],
            docs: [],
            type: 'init',
            EJSON: _this.getEJSON(),
            requestId: initEventMsg.requestId,
            watchId: _this.watchId
          });
          reporter.surroundThirdByTryCatch(() => _this.listener.onChange(snapshot))();
          _this.scheduleSendACK();
          if (_this.debug) {
            _this._snapshotHistory.push(snapshot);
          }
        }
        _this.onWatchStart(_this, _this.sessionInfo.queryID);
        _this._availableRetries.INIT_WATCH = DEFAULT_MAX_AUTO_RETRY_ON_ERROR;
        _this._wsDisconnectionTS = undefined;
        reportIDKey(ErrorID, ErrorKey.REALTIME_DB_INIT_WATCH_SUCCESS, true);
        reportAPISpeed({
          apiName: '_realtime.initWatch(success)',
          apiStartTime,
          apiEndTime: Date.now()
        });
        _this._fsm.transition(VWSEvent.INIT_WATCH_SUCCESS);
        if (false) {}
      } catch (e) {
        reportAPISpeed({
          apiName: '_realtime.initWatch(fail)',
          apiStartTime,
          apiEndTime: Date.now()
        });
        if (false) {}
        _this.handleWatchEstablishmentError(e, {
          operationName: 'INIT_WATCH',
          requestId
        });
      }
    });
    this.rebuildWatch = /*#__PURE__*/asyncToGenerator_default()(function* () {
      var apiStartTime = Date.now();
      var requestId = genRequestId();
      try {
        _this._fsm.transition(VWSEvent.REBUILD_WATCH_START, VWSState.REBUILD_LOGGED_IN);
        var envId = _this.envId;
        if (!_this.sessionInfo) {
          throw new Error(`can not rebuildWatch without a successful initWatch (lack of sessionInfo)`);
        }
        if (_this._wsDisconnectionTS && Date.now() - _this._wsDisconnectionTS > _this.getServiceContext().appConfig.realtimeQueryEventCacheTimeout * 0.9) {
          if (false) {}
          throw new TimeoutError(`query event cache timeout, ws has been disconnected for too long, PLEASE RECONNECT manually`, {
            subtype: 'queryEventCacheClientTimeout',
            retryable: false
          });
        }
        var rebuildWatchMsg = {
          watchId: _this.watchId,
          requestId,
          msgType: 'REBUILD_WATCH',
          msgData: {
            envId,
            collName: _this.collectionName,
            queryID: _this.sessionInfo.queryID,
            eventID: _this.sessionInfo.currentEventId
          }
        };
        var nextEventMsg = yield _this.send({
          msg: rebuildWatchMsg,
          waitResponse: true,
          skipOnMessage: true,
          timeout: DEFAULT_REBUILD_WATCH_TIMEOUT
        });
        _this.assertAsyncTaskStatus();
        if (false) {}
        yield _this.handleServerEvents(nextEventMsg);
        _this._availableRetries.REBUILD_WATCH = DEFAULT_MAX_AUTO_RETRY_ON_ERROR;
        _this._wsDisconnectionTS = undefined;
        reportIDKey(ErrorID, ErrorKey.REALTIME_DB_REBUILD_WATCH_SUCCESS, true);
        reportAPISpeed({
          apiName: '_realtime.rebuildWatch(success)',
          apiStartTime,
          apiEndTime: Date.now()
        });
        _this._fsm.transition(VWSEvent.REBUILD_WATCH_SUCCESS);
        if (false) {}
      } catch (e) {
        reportAPISpeed({
          apiName: '_realtime.rebuildWatch(fail)',
          apiStartTime,
          apiEndTime: Date.now()
        });
        if (false) {}
        _this.handleWatchEstablishmentError(e, {
          operationName: 'REBUILD_WATCH',
          requestId
        });
      }
    });
    this.handleWatchEstablishmentError = /*#__PURE__*/function () {
      var _ref4 = asyncToGenerator_default()(function* (e, options) {
        var isInitWatch = options.operationName === 'INIT_WATCH';
        var abortWatch = err => {
          var errMsg = `${err || e} (${isInitWatch ? 'initWatch' : 'rebuildWatch'} requestId ${options.requestId})`;
          _this.closeWithError(new error_CloudSDKError({
            errCode: isInitWatch ? error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_INIT_WATCH_FAIL : error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_REBUILD_WATCH_FAIL,
            errMsg
          }));
          reportIDKey(ErrorID, isInitWatch ? ErrorKey.REALTIME_DB_INIT_WATCH_FAIL : ErrorKey.REALTIME_DB_REBUILD_WATCH_FAIL, true);
          if (isRealtimeErrorMessageError(e)) {
            var msg = e.payload;
            switch (msg.msgData.code) {
              case 'CHECK_LOGIN_FAILED':
              case 'SIGN_EXPIRED_ERROR':
              case 'SIGN_INVALID_ERROR':
              case 'SIGN_PARAM_INVALID':
                {
                  reportIDKey(ErrorID, isInitWatch ? ErrorKey.REALTIME_DB_INIT_WATCH_FAIL_SERVER_SIGN_ERROR : ErrorKey.REALTIME_DB_REBUILD_WATCH_FAIL_SERVER_SIGN_ERROR, true);
                  break;
                }
              default:
                {
                  reportIDKey(ErrorID, isInitWatch ? ErrorKey.REALTIME_DB_INIT_WATCH_FAIL_SERVER_OTHER_ERROR : ErrorKey.REALTIME_DB_REBUILD_WATCH_FAIL_SERVER_OTHER_ERROR, true);
                  break;
                }
            }
          } else if (isTimeoutError(e)) {
            switch (e.payload.subtype) {
              case 'totalConnectionTimeout':
                {
                  reportIDKey(ErrorID, isInitWatch ? ErrorKey.REALTIME_DB_INIT_WATCH_FAIL_TIMEOUT_ERROR_TOTAL_CONNECTION : ErrorKey.REALTIME_DB_REBUILD_WATCH_FAIL_TIMEOUT_ERROR_TOTAL_CONNECTION, true);
                  break;
                }
              case 'queryEventCacheClientTimeout':
                {
                  if (!isInitWatch) {
                    reportIDKey(ErrorID, ErrorKey.REALTIME_DB_REBUILD_WATCH_FAIL_TIMEOUT_ERROR_QUERY_EVENT_CACHE, true);
                  }
                  break;
                }
            }
            return;
          } else if (isCancelledError(e)) {
            reportIDKey(ErrorID, isInitWatch ? ErrorKey.REALTIME_DB_INIT_WATCH_FAIL_CANCELLED_ERROR : ErrorKey.REALTIME_DB_REBUILD_WATCH_FAIL_CANCELLED_ERROR, true);
            return;
          } else {
            reportIDKey(ErrorID, isInitWatch ? ErrorKey.REALTIME_DB_INIT_WATCH_FAIL_UNKNOWN_ERROR : ErrorKey.REALTIME_DB_REBUILD_WATCH_FAIL_UNKNOWN_ERROR, true);
            return;
          }
        };
        _this._errors.push(e);
        _this.handleCommonError(e, {
          onSignError: () => {
            _this._loginInvalidated = true;
            _this._fsm.transition(_this.initialized ? VWSEvent.REBUILD_WATCH_FAIL : VWSEvent.INIT_WATCH_FAIL);
          },
          onTimeoutError: e => {
            if (e.payload && !e.payload.retryable) {
              abortWatch(e);
            } else {
              _this._fsm.transition(_this.initialized ? VWSEvent.REBUILD_WATCH_FAIL : VWSEvent.INIT_WATCH_FAIL);
            }
          },
          onNotRetryableError: abortWatch,
          onCancelledError: e => {
            _this._fsm.transition(_this.initialized ? VWSEvent.REBUILD_WATCH_FAIL : VWSEvent.INIT_WATCH_FAIL);
          },
          onUnknownError: () => {
            _this._fsm.transition(_this.initialized ? VWSEvent.REBUILD_WATCH_FAIL : VWSEvent.INIT_WATCH_FAIL);
          }
        });
      });
      return function (_x2, _x3) {
        return _ref4.apply(this, arguments);
      };
    }();
    this.closeWatch = /*#__PURE__*/asyncToGenerator_default()(function* () {
      _this.closeWatchInvoked = true;
      var queryId = _this.sessionInfo ? _this.sessionInfo.queryID : '';
      if (_this._fsm.currentState === VWSState.CLOSED) return;
      try {
        _this._fsm.transition(VWSEvent.CLOSE);
        yield _this.sendCloseWatch();
      } catch (e) {
        console.warn(`[realtime] non-fatal error while closing watch: ${e}`);
      } finally {
        _this.sessionInfo = undefined;
        _this.onWatchClose(_this, queryId);
        _this._cleanup();
      }
    });
    this.sendCloseWatch = /*#__PURE__*/asyncToGenerator_default()(function* () {
      var closeWatchMsg = {
        watchId: _this.watchId,
        requestId: genRequestId(),
        msgType: 'CLOSE_WATCH',
        msgData: null
      };
      yield _this.send({
        msg: closeWatchMsg
      });
    });
    this.scheduleSendACK = () => {
      this.clearACKSchedule();
      this._ackTimeoutId = setTimeout(() => {
        if (this._waitExpectedTimeoutId) {
          this.scheduleSendACK();
        } else {
          this.sendACK();
        }
      }, DEFAULT_SEND_ACK_DEBOUNCE_TIMEOUT);
    };
    this.clearACKSchedule = () => {
      if (this._ackTimeoutId) {
        clearTimeout(this._ackTimeoutId);
      }
    };
    this.sendACK = /*#__PURE__*/asyncToGenerator_default()(function* () {
      try {
        if (_this._fsm.currentState !== VWSState.INIT_WATCH_SUCCESS && _this._fsm.currentState !== VWSState.REBUILD_WATCH_SUCCESS) {
          _this.scheduleSendACK();
          return;
        }
        if (!_this.sessionInfo) {
          console.warn(`[realtime listener] can not send ack without a successful initWatch (lack of sessionInfo)`);
          return;
        }
        var ackMsg = {
          watchId: _this.watchId,
          requestId: genRequestId(),
          msgType: 'CHECK_LAST',
          msgData: {
            queryID: _this.sessionInfo.queryID,
            eventID: _this.sessionInfo.currentEventId
          }
        };
        yield _this.send({
          msg: ackMsg
        });
        _this.scheduleSendACK();
      } catch (e) {
        if (isRealtimeErrorMessageError(e)) {
          var msg = e.payload;
          switch (msg.msgData.code) {
            case 'CHECK_LOGIN_FAILED':
            case 'SIGN_EXPIRED_ERROR':
            case 'SIGN_INVALID_ERROR':
            case 'SIGN_PARAM_INVALID':
              {
                _this._loginInvalidated = true;
                if (_this._fsm.currentState === VWSState.INIT_WATCH_SUCCESS || _this._fsm.currentState === VWSState.REBUILD_WATCH_SUCCESS) {
                  _this._fsm.transition(VWSEvent.NEED_REBUILD_WATCH);
                }
                return;
              }
            case 'QUERYID_INVALID_ERROR':
            case 'SYS_ERR':
            case 'INVALIID_ENV':
            case 'COLLECTION_PERMISSION_DENIED':
              {
                _this.closeWithError(new error_CloudSDKError({
                  errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_CHECK_LAST_FAIL,
                  errMsg: msg.msgData.code
                }));
                return;
              }
            default:
              {
                break;
              }
          }
        }
        if (_this._availableRetries.CHECK_LAST && _this._availableRetries.CHECK_LAST > 0) {
          _this._availableRetries.CHECK_LAST--;
          _this.scheduleSendACK();
        } else {
          _this.closeWithError(new error_CloudSDKError({
            errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_CHECK_LAST_FAIL,
            errMsg: e
          }));
        }
      }
    });
    this.handleCommonError = (e, options) => {
      if (isRealtimeErrorMessageError(e)) {
        var msg = e.payload;
        switch (msg.msgData.code) {
          case 'CHECK_LOGIN_FAILED':
          case 'SIGN_EXPIRED_ERROR':
          case 'SIGN_INVALID_ERROR':
          case 'SIGN_PARAM_INVALID':
            {
              options.onSignError(e);
              return;
            }
          case 'QUERYID_INVALID_ERROR':
          case 'SYS_ERR':
          case 'INVALIID_ENV':
          case 'COLLECTION_PERMISSION_DENIED':
            {
              options.onNotRetryableError(e);
              return;
            }
          default:
            {
              options.onNotRetryableError(e);
              return;
            }
        }
      } else if (isTimeoutError(e)) {
        options.onTimeoutError(e);
        return;
      } else if (isCancelledError(e)) {
        options.onCancelledError(e);
        return;
      }
      options.onUnknownError(e);
    };
    this.watchId = `watchid_${+new Date()}_${Math.random()}`;
    this._parentFSM = _options.parentFSM;
    this.envId = _options.envId;
    this.collectionName = _options.collectionName;
    this.query = _options.query;
    this.limit = _options.limit;
    this.orderBy = _options.orderBy;
    this.queryType = _options.queryType;
    this.send = _options.send;
    this.login = _options.login;
    this.isWSConnected = _options.isWSConnected;
    this.getWaitExpectedTimeoutLength = _options.getWaitExpectedTimeoutLength;
    this.getEJSON = _options.getEJSON;
    this.getServiceContext = _options.getServiceContext;
    this.onWatchStart = _options.onWatchStart;
    this.onWatchClose = _options.onWatchClose;
    this.timing = _options.timing;
    this.debug = _options.debug;
    this._availableRetries = {
      INIT_WATCH: DEFAULT_MAX_AUTO_RETRY_ON_ERROR,
      REBUILD_WATCH: DEFAULT_MAX_AUTO_RETRY_ON_ERROR,
      CHECK_LAST: DEFAULT_MAX_SEND_ACK_AUTO_RETRY_ON_ERROR
    };
    this._fsm = new FSM({
      initialState: VWSState.UNINIT,
      states: VWSStates,
      history: true
    });
    this._subscribeParentFSMEvents();
    this._subscribeFSMEvents();
    this.listener = new RealtimeListener({
      close: this.closeWatch,
      onChange: _options.onChange,
      onError: _options.onError,
      debug: this.debug,
      virtualClient: this
    });
    if (this._parentFSM.currentState === WSState.CONNECTED) {
      this._login();
    }
    if (_options.debug) {
      this.wsclient = _options.wsclient;
    }
  }
  get initialized() {
    return Boolean(this.sessionInfo);
  }
  _cleanup() {
    this._parentFSM.unsubscribe(this._parentFSMListener);
  }
  _subscribeParentFSMEvents() {
    this._parentFSMListener = e => {
      var {
        event,
        from,
        to
      } = e;
      if (this._fsm.currentState === VWSState.CLOSED) {
        return;
      }
      if (event.type === WSEvent.DISCONNECT || event.type === WSEvent.CONNECTION_FAIL) {
        switch (this._fsm.currentState) {
          case VWSState.UNINIT:
          case VWSState.INIT_LOGGING_IN:
          case VWSState.INIT_LOGIN_FAIL:
          case VWSState.INIT_LOGGED_IN:
          case VWSState.INIT_WATCH_PENDING:
          case VWSState.INIT_WATCH_FAIL:
            {
              this.closeWithError(event.error || new Error(`websocket connection fail`), false);
              break;
            }
          default:
            {
              if (event.type === WSEvent.DISCONNECT) {
                if (!this._wsDisconnectionTS) {
                  this._wsDisconnectionTS = Date.now();
                }
                this._fsm.transition(VWSEvent.WS_DISCONNECTED);
              } else {
                this.closeWithError(event.error || new Error(`websocket connection fail`), false);
              }
            }
        }
      } else if (event.type === WSEvent.CONNECTION_SUCCESS) {
        switch (this._fsm.currentState) {
          case VWSState.UNINIT:
          case VWSState.PAUSED:
            {
              this._login();
              break;
            }
          case VWSState.CLOSED:
            {
              break;
            }
          default:
            {
              console.warn(`[realtime] current state should not be ${this._fsm.currentState} (parent event ${event})`);
            }
        }
      }
    };
    this._parentFSM.subscribe(this._parentFSMListener);
  }
  _subscribeFSMEvents() {
    this._FSMListener = e => {
      var {
        event,
        from,
        to
      } = e;
      switch (event.type) {
        case VWSEvent.WS_CONNECTED:
          {
            this._login().catch(noopOnError);
            break;
          }
        case VWSEvent.LOGIN_SUCCESS:
          {
            if (from === VWSState.INIT_LOGGING_IN) {
              this.initWatch().catch(noopOnError);
            } else if (from === VWSState.REBUILD_LOGGING_IN) {
              this.rebuildWatch().catch(noopOnError);
            } else {
              this.closeWithError(new error_CloudSDKError({
                errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_UNEXPECTED_FATAL_ERROR,
                errMsg: `unexpected state: event ${event.type} from ${from}`
              }));
            }
            break;
          }
        case VWSEvent.LOGIN_FAIL:
          {
            if (from === VWSState.INIT_LOGGING_IN) {
              if (this.useRetryTicket('INIT_WATCH')) {
                this._login().catch(noopOnError);
              } else {
                this.closeWithError(new error_CloudSDKError({
                  errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_INIT_WATCH_FAIL,
                  errMsg: `login fail ${this._errors[this._errors.length - 1]}`
                }));
              }
            } else if (from === VWSState.REBUILD_LOGGING_IN) {
              if (this.useRetryTicket('REBUILD_WATCH')) {
                this._login().catch(noopOnError);
              } else {
                this.closeWithError(new error_CloudSDKError({
                  errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_REBUILD_WATCH_FAIL,
                  errMsg: `login fail ${this._errors[this._errors.length - 1]}`
                }));
              }
            } else {
              this.closeWithError(new error_CloudSDKError({
                errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_UNEXPECTED_FATAL_ERROR,
                errMsg: `unexpected state: event ${event.type} from ${from}`
              }));
            }
            break;
          }
        case VWSEvent.INIT_WATCH_SUCCESS:
          {
            this._availableRetries.INIT_WATCH = DEFAULT_MAX_AUTO_RETRY_ON_ERROR;
            this._errors = [];
            break;
          }
        case VWSEvent.INIT_WATCH_FAIL:
          {
            if (this.useRetryTicket('INIT_WATCH')) {
              this._login().catch(noopOnError);
            } else {
              this.closeWithError(new error_CloudSDKError({
                errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_INIT_WATCH_FAIL,
                errMsg: `init watch fail ${this._errors[this._errors.length - 1]}`
              }));
            }
            break;
          }
        case VWSEvent.REBUILD_WATCH_SUCCESS:
          {
            this._availableRetries.REBUILD_WATCH = DEFAULT_MAX_AUTO_RETRY_ON_ERROR;
            this._errors = [];
            break;
          }
        case VWSEvent.REBUILD_WATCH_FAIL:
          {
            if (this.useRetryTicket('REBUILD_WATCH')) {
              this._login().catch(noopOnError);
            } else {
              this.closeWithError(new error_CloudSDKError({
                errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_REBUILD_WATCH_FAIL,
                errMsg: `init watch fail ${this._errors[this._errors.length - 1]}`
              }));
            }
            break;
          }
        case VWSEvent.NEED_REBUILD_WATCH:
          {
            this._login().catch(noopOnError);
            break;
          }
      }
    };
    this._fsm.subscribe(this._FSMListener);
  }
  useRetryTicket(operationName) {
    if (this._availableRetries[operationName] && this._availableRetries[operationName] > 0) {
      this._availableRetries[operationName]--;
      if (false) {}
      return true;
    }
    return false;
  }
  assertAsyncTaskStatus() {
    if (this.closeWatchInvoked) {
      if (false) {}
      throw new CancelledError('closeWatch', {
        subtype: 'closeWatch'
      });
    }
    switch (this._fsm.currentState) {
      case VWSState.PAUSED:
        {
          if (false) {}
          throw new CancelledError('pause', {
            subtype: 'pause'
          });
        }
      case VWSState.CLOSED:
        {
          if (false) {}
          throw new CancelledError('close', {
            subtype: 'close'
          });
        }
    }
  }
  handleServerEvents(msg) {
    var _this2 = this;
    return asyncToGenerator_default()(function* () {
      try {
        _this2.scheduleSendACK();
        yield _this2._handleServerEvents(msg);
        _this2._postHandleServerEventsValidityCheck(msg);
      } catch (e) {
        if (false) {}
        reportIDKey(ErrorID, ErrorKey.REALTIME_DB_HANDLE_EVENT_ERROR, true);
        throw e;
      }
    })();
  }
  _handleServerEvents(msg) {
    var _this3 = this;
    return asyncToGenerator_default()(function* () {
      var {
        requestId
      } = msg;
      var {
        events
      } = msg.msgData;
      if (!events.length || !_this3.sessionInfo) {
        return;
      }
      var sessionInfo = _this3.sessionInfo;
      var allChangeEvents;
      try {
        allChangeEvents = events.map(getPublicEvent);
      } catch (e) {
        _this3.closeWithError(new error_CloudSDKError({
          errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_RECEIVE_INVALID_SERVER_DATA,
          errMsg: e
        }));
        return;
      }
      var docs = [...sessionInfo.currentDocs];
      var initEncountered = false;
      var _loop = function* () {
        var change = allChangeEvents[i];
        if (sessionInfo.currentEventId >= change.id) {
          if (!allChangeEvents[i - 1] || change.id > allChangeEvents[i - 1].id) {
            if (false) {}
            reportIDKey(ErrorID, ErrorKey.REALTIME_DB_RECV_DUPLICATE_EVENT, true);
          } else {
            console.error(`[realtime listener] server non-fatal error: events out of order (the latter event's id is smaller than that of the former) (requestId ${requestId})`);
            reportIDKey(ErrorID, ErrorKey.REALTIME_DB_RECV_DUPLICATE_EVENT_AND_EVENT_OUT_OF_ORDER, true);
          }
          return 1;
        } else if (sessionInfo.currentEventId === change.id - 1) {
          switch (change.dataType) {
            case 'update':
              {
                if (!change.doc) {
                  switch (change.queueType) {
                    case 'update':
                    case 'dequeue':
                      {
                        var localDoc = docs.find(doc => doc._id === change.docId);
                        if (localDoc) {
                          var doc = JSON.parse(JSON.stringify(localDoc));
                          if (change.updatedFields) {
                            for (var fieldPath in change.updatedFields) {
                              set(doc, fieldPath, change.updatedFields[fieldPath]);
                            }
                          }
                          if (change.removedFields) {
                            for (var _fieldPath of change.removedFields) {
                              unset(doc, _fieldPath);
                            }
                          }
                          change.doc = doc;
                        } else {
                          console.error(`[realtime listener] internal non-fatal server error: unexpected update dataType event where no doc is associated.`);
                          reportIDKey(ErrorID, ErrorKey.REALTIME_DB_UNEXPECTED_EVENT_DATATYPE_UPDATE_NO_ASSOCIATED_DOC, true);
                        }
                        break;
                      }
                    case 'enqueue':
                      {
                        var err = new error_CloudSDKError({
                          errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_UNEXPECTED_FATAL_ERROR,
                          errMsg: `HandleServerEvents: full doc is not provided with dataType="update" and queueType="enqueue" (requestId ${msg.requestId})`
                        });
                        _this3.closeWithError(err);
                        throw err;
                      }
                    default:
                      {
                        break;
                      }
                  }
                }
                break;
              }
            case 'limit':
              {
                if (!change.doc) {
                  switch (change.queueType) {
                    case 'dequeue':
                      {
                        var _localDoc = docs.find(doc => doc._id === change.docId);
                        if (_localDoc) {
                          change.doc = _localDoc;
                        } else {
                          console.error(`[realtime listener] internal non-fatal server error: unexpected limit dataType dequeue queueType event where no doc is associated.`);
                        }
                        break;
                      }
                  }
                }
                break;
              }
            case 'replace':
              {
                if (!change.doc) {
                  var _err = new error_CloudSDKError({
                    errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_UNEXPECTED_FATAL_ERROR,
                    errMsg: `HandleServerEvents: full doc is not provided with dataType="replace" (requestId ${msg.requestId})`
                  });
                  _this3.closeWithError(_err);
                  throw _err;
                }
                break;
              }
            case 'remove':
              {
                var _doc = docs.find(doc => doc._id === change.docId);
                if (_doc) {
                  change.doc = _doc;
                } else {
                  console.error(`[realtime listener] internal non-fatal server error: unexpected remove event where no doc is associated.`);
                  reportIDKey(ErrorID, ErrorKey.REALTIME_DB_UNEXPECTED_EVENT_REMOVE_NO_ASSOCIATED_DOC, true);
                }
                break;
              }
          }
          switch (change.queueType) {
            case 'init':
              {
                if (!initEncountered) {
                  initEncountered = true;
                  docs = [change.doc];
                } else {
                  docs.push(change.doc);
                }
                break;
              }
            case 'enqueue':
              {
                docs.push(change.doc);
                break;
              }
            case 'dequeue':
              {
                var ind = docs.findIndex(doc => doc._id === change.docId);
                if (ind > -1) {
                  docs.splice(ind, 1);
                } else {
                  console.error(`[realtime listener] internal non-fatal server error: unexpected dequeue event where no doc is associated.`);
                  reportIDKey(ErrorID, ErrorKey.REALTIME_DB_UNEXPECTED_EVENT_DEQUEUE_NO_ASSOCIATED_DOC, true);
                }
                break;
              }
            case 'update':
              {
                var _ind = docs.findIndex(doc => doc._id === change.docId);
                if (_ind > -1) {
                  docs[_ind] = change.doc;
                } else {
                  console.error(`[realtime listener] internal non-fatal server error: unexpected queueType update event where no doc is associated.`);
                  reportIDKey(ErrorID, ErrorKey.REALTIME_DB_UNEXPECTED_EVENT_QUEUETYPE_UPDATE_NO_ASSOCIATED_DOC, true);
                  if (false) {}
                }
                break;
              }
          }
          if (i === len - 1 || allChangeEvents[i + 1] && allChangeEvents[i + 1].id !== change.id) {
            var docsSnapshot = [...docs];
            var docChanges = allChangeEvents.slice(0, i + 1).filter(c => c.id === change.id);
            _this3.sessionInfo.currentEventId = change.id;
            _this3.sessionInfo.currentDocs = docs;
            _this3.sessionInfo.currentEventTS = Date.now();
            var snapshot = new Snapshot({
              id: change.id,
              type: docChanges[0].queueType === 'init' ? 'init' : undefined,
              docChanges: _this3.getEJSON().deserialize(docChanges),
              docs: _this3.getEJSON().deserialize(docsSnapshot),
              EJSON: _this3.getEJSON(),
              requestId,
              watchId: _this3.watchId
            });
            reporter.surroundThirdByTryCatch(() => _this3.listener.onChange(snapshot))();
            if (_this3.debug) {
              _this3._snapshotHistory.push(snapshot);
            }
          }
        } else {
          if (false) {}
          reportIDKey(ErrorID, ErrorKey.REALTIME_DB_EVENT_OUT_OF_ORDER, true);
          _this3._fsm.transition(VWSEvent.NEED_REBUILD_WATCH);
        }
      };
      for (var i = 0, len = allChangeEvents.length; i < len; i++) {
        if (yield* _loop()) continue;
      }
    })();
  }
  _postHandleServerEventsValidityCheck(msg) {
    if (!this.sessionInfo) {
      console.error(`[realtime listener] internal non-fatal error: sessionInfo lost after server event handling, this should never occur. (requestId ${msg.requestId})`);
      return;
    }
    if (this.sessionInfo.expectEventId && this.sessionInfo.currentEventId >= this.sessionInfo.expectEventId) {
      this.clearWaitExpectedEvent();
    }
    if (this.sessionInfo.currentEventId < msg.msgData.currEvent) {
      console.warn(`[realtime listener] internal non-fatal error: client eventId ${this.sessionInfo.currentEventId} does not match with server event id after server event handling ${msg.msgData.currEvent} (requestId ${msg.requestId})`);
      return;
    }
  }
  clearWaitExpectedEvent() {
    if (this._waitExpectedTimeoutId) {
      clearTimeout(this._waitExpectedTimeoutId);
      this._waitExpectedTimeoutId = undefined;
    }
  }
  onMessage(msg) {
    switch (this._fsm.currentState) {
      case VWSState.INIT_WATCH_SUCCESS:
      case VWSState.REBUILD_WATCH_SUCCESS:
        {
          break;
        }
      case VWSState.PAUSED:
        {
          if (msg.msgType !== 'ERROR') {
            return;
          }
          break;
        }
      default:
        {
          console.warn(`[realtime listener] internal non-fatal error: unexpected message received while state is ${this._fsm.currentState}`);
          return;
        }
    }
    if (!this.sessionInfo) {
      console.warn(`[realtime listener] internal non-fatal error: sessionInfo not found while message is received.`);
      return;
    }
    this.scheduleSendACK();
    switch (msg.msgType) {
      case 'NEXT_EVENT':
        {
          if (false) {}
          this.handleServerEvents(msg);
          break;
        }
      case 'CHECK_EVENT':
        {
          if (this.sessionInfo.currentEventId < msg.msgData.currEvent) {
            this.sessionInfo.expectEventId = msg.msgData.currEvent;
            this.clearWaitExpectedEvent();
            this._waitExpectedTimeoutId = setTimeout(() => {
              this._fsm.transition(VWSEvent.NEED_REBUILD_WATCH);
            }, this.getWaitExpectedTimeoutLength());
            if (false) {}
          }
          break;
        }
      case 'ERROR':
        {
          this.closeWithError(new error_CloudSDKError({
            errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_SERVER_ERROR_MSG,
            errMsg: `${msg.msgData.code} - ${msg.msgData.message}`
          }));
          break;
        }
      default:
        {
          if (false) {}
          break;
        }
    }
  }
  closeWithError(error, sendCloseWatch = true) {
    if (this._fsm.currentState !== VWSState.CLOSED) {
      this._fsm.transition(VWSEvent.CLOSE);
    }
    if (this.userOnErrorInvoked) {
      return;
    }
    var history = this._fsm.getHistoryRepresentation({
      limit:  false ? 0 : 20
    });
    if (isSDKError(error)) {
      error.errMsg += `\nhistory ${history}`;
      error.history = history;
    } else if (error) {
      error = new error_CloudSDKError({
        errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_UNEXPECTED_FATAL_ERROR,
        errMsg: `${error} \nhistory ${history}`
      });
      error.history = history;
    }
    this.clearACKSchedule();
    reporter.surroundThirdByTryCatch(() => this.listener.onError(error))();
    this.userOnErrorInvoked = true;
    this.onWatchClose(this, this.sessionInfo && this.sessionInfo.queryID || '');
    if (sendCloseWatch) {
      this.sendCloseWatch().catch(noopOnError);
    }
    this.sessionInfo = undefined;
    if (false) {}
  }
}
function getPublicEvent(event) {
  var e = {
    id: event.ID,
    dataType: event.DataType,
    queueType: event.QueueType,
    docId: event.DocID,
    doc: event.Doc && event.Doc !== '{}' ? JSON.parse(event.Doc) : undefined
  };
  if (event.DataType === 'update') {
    if (event.UpdatedFields) {
      e.updatedFields = JSON.parse(event.UpdatedFields);
    }
    if (event.removedFields || event.RemovedFields) {
      e.removedFields = event.removedFields ? JSON.parse(event.removedFields) : JSON.parse(event.RemovedFields);
    }
  }
  return e;
}
;// CONCATENATED MODULE: ./src/services/database/api/database/realtime/ws-event.ts


var CLOSE_EVENT_CODE_INFO = {
  1000: {
    code: 1000,
    name: 'Normal Closure',
    description: 'Normal closure; the connection successfully completed whatever purpose for which it was created.'
  },
  1001: {
    code: 1001,
    name: 'Going Away',
    description: 'The endpoint is going away, either because of a server failure or because the browser is navigating away from the page that opened the connection.'
  },
  1002: {
    code: 1002,
    name: 'Protocol Error',
    description: 'The endpoint is terminating the connection due to a protocol error.'
  },
  1003: {
    code: 1003,
    name: 'Unsupported Data',
    description: 'The connection is being terminated because the endpoint received data of a type it cannot accept (for example, a text-only endpoint received binary data).'
  },
  1005: {
    code: 1005,
    name: 'No Status Received',
    description: 'Indicates that no status code was provided even though one was expected.'
  },
  1006: {
    code: 1006,
    name: 'Abnormal Closure',
    description: 'Used to indicate that a connection was closed abnormally (that is, with no close frame being sent) when a status code is expected.'
  },
  1007: {
    code: 1007,
    name: 'Invalid frame payload data',
    description: 'The endpoint is terminating the connection because a message was received that contained inconsistent data (e.g., non-UTF-8 data within a text message).'
  },
  1008: {
    code: 1008,
    name: 'Policy Violation',
    description: 'The endpoint is terminating the connection because it received a message that violates its policy. This is a generic status code, used when codes 1003 and 1009 are not suitable.'
  },
  1009: {
    code: 1009,
    name: 'Message too big',
    description: 'The endpoint is terminating the connection because a data frame was received that is too large.'
  },
  1010: {
    code: 1010,
    name: 'Missing Extension',
    description: 'The client is terminating the connection because it expected the server to negotiate one or more extension, but the server didn\'t.'
  },
  1011: {
    code: 1011,
    name: 'Internal Error',
    description: 'The server is terminating the connection because it encountered an unexpected condition that prevented it from fulfilling the request.'
  },
  1012: {
    code: 1012,
    name: 'Service Restart',
    description: 'The server is terminating the connection because it is restarting.'
  },
  1013: {
    code: 1013,
    name: 'Try Again Later',
    description: 'The server is terminating the connection due to a temporary condition, e.g. it is overloaded and is casting off some of its clients.'
  },
  1014: {
    code: 1014,
    name: 'Bad Gateway',
    description: 'The server was acting as a gateway or proxy and received an invalid response from the upstream server. This is similar to 502 HTTP Status Code.'
  },
  1015: {
    code: 1015,
    name: 'TLS Handshake',
    description: 'Indicates that the connection was closed due to a failure to perform a TLS handshake (e.g., the server certificate can\'t be verified).'
  },
  3000: {
    code: 3000,
    name: 'Reconnect WebSocket',
    description: 'The client is terminating the connection because it wants to reconnect'
  },
  3001: {
    code: 3001,
    name: 'No Realtime Listeners',
    description: 'The client is terminating the connection because no more realtime listeners exist'
  },
  3002: {
    code: 3002,
    name: 'Heartbeat Ping Error',
    description: 'The client is terminating the connection due to its failure in sending heartbeat messages'
  },
  3003: {
    code: 3003,
    name: 'Heartbeat Pong Timeout Error',
    description: 'The client is terminating the connection because no heartbeat response is received from the server'
  },
  3004: {
    code: 3004,
    name: 'Client Reconnect on Server Upgrade',
    description: 'The client is terminating the connection in response to server upgrade'
  },
  3050: {
    code: 3050,
    name: 'Server Close Unauthenticated Idle Connection',
    description: 'The server is terminating the connection because the connection is idle and not authenticated'
  },
  3051: {
    code: 3051,
    name: 'Server Upgrade',
    description: 'The server is terminating the connection because it is upgrading'
  },
  3052: {
    code: 3052,
    name: 'Server Requires Authentication',
    description: 'The server is terminating the connection because it has not received authentication message as the connection\'s first message'
  }
};
var CLOSE_EVENT_CODE = /*#__PURE__*/function (CLOSE_EVENT_CODE) {
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["NormalClosure"] = 1000] = "NormalClosure";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["GoingAway"] = 1001] = "GoingAway";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["ProtocolError"] = 1002] = "ProtocolError";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["UnsupportedData"] = 1003] = "UnsupportedData";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["NoStatusReceived"] = 1005] = "NoStatusReceived";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["AbnormalClosure"] = 1006] = "AbnormalClosure";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["InvalidFramePayloadData"] = 1007] = "InvalidFramePayloadData";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["PolicyViolation"] = 1008] = "PolicyViolation";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["MessageTooBig"] = 1009] = "MessageTooBig";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["MissingExtension"] = 1010] = "MissingExtension";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["InternalError"] = 1011] = "InternalError";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["ServiceRestart"] = 1012] = "ServiceRestart";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["TryAgainLater"] = 1013] = "TryAgainLater";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["BadGateway"] = 1014] = "BadGateway";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["TLSHandshake"] = 1015] = "TLSHandshake";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["ReconnectWebSocket"] = 3000] = "ReconnectWebSocket";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["NoRealtimeListeners"] = 3001] = "NoRealtimeListeners";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["HeartbeatPingError"] = 3002] = "HeartbeatPingError";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["HeartbeatPongTimeoutError"] = 3003] = "HeartbeatPongTimeoutError";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["ReconnectOnServerUpgrade"] = 3004] = "ReconnectOnServerUpgrade";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["UnauthenticatedIdleConnection"] = 3050] = "UnauthenticatedIdleConnection";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["ServerUpgrade"] = 3051] = "ServerUpgrade";
  CLOSE_EVENT_CODE[CLOSE_EVENT_CODE["AuthenticationRequired"] = 3052] = "AuthenticationRequired";
  return CLOSE_EVENT_CODE;
}({});
var getWSCloseError = (code, reason) => {
  var info = CLOSE_EVENT_CODE_INFO[code];
  var errMsg = !info ? `code ${code}` : `${info.name}, code ${code}, reason ${reason || info.description}`;
  return new error_CloudSDKError({
    errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_WEBSOCKET_CONNECTION_CLOSED,
    errMsg
  });
};
;// CONCATENATED MODULE: ./src/services/database/api/database/realtime/websocket-client.ts

















var WS_READY_STATE = {
  CONNECTING: 0,
  OPEN: 1,
  CLOSING: 2,
  CLOSED: 3
};
var MAX_RTT_OBSERVED = 3;
var DEFAULT_EXPECTED_EVENT_WAIT_TIME = 5000;
var DEFAULT_UNTRUSTED_RTT_THRESHOLD = 10000;
var DEFAULT_WS_RECONNECT_MAX_VALID_INTERVAL = (/* unused pure expression or super */ null && (3 * 60 * 1000));
var DEFAULT_PING_FAIL_TOLERANCE = 2;
var DEFAULT_PONG_MISS_TOLERANCE = 2;
var DEFAULT_LOGIN_TIMEOUT = 5000;
var DEFAULT_WAIT_TIME_AFTER_ONLINE_ON_IDE = 100;
class RealtimeWebSocketClient {
  constructor(options) {
    var _this = this;
    this._fsm = void 0;
    this._virtualWSClient = new Set();
    this._queryIdClientMap = new Map();
    this._watchIdClientMap = new Map();
    this._totalConnectionTimeoutId = void 0;
    this._serviceContext = void 0;
    this._ws = void 0;
    this._lastPingSendTS = void 0;
    this._pingFailed = 0;
    this._pongMissed = 0;
    this._pingTimeoutId = void 0;
    this._pongTimeoutId = void 0;
    this._logins = new Map();
    this._signatures = new Map();
    this._wsResponseWait = new Map();
    this._rttObserved = [];
    this._closedWatches = new Set();
    this._EJSON = void 0;
    this._defaultEnvId = void 0;
    this._connectionEnvId = void 0;
    this._retryLock = false;
    this.initWebSocketConnection = /*#__PURE__*/function () {
      var _ref = asyncToGenerator_default()(function* (reconnect, availableRetries = _this._maxReconnect) {
        var ejsonInitPromise;
        if (!_this._EJSON) {
          ejsonInitPromise = initEJSON().then(EJSON => _this._EJSON = EJSON);
        }
        if (_this._fsm.currentState !== WSState.DISCONNECTED) {
          return;
        }
        _this._fsm.transition(WSEvent.CONNECTION_START);
        if (false) {}
        _this._logins = new Map();
        _this._wsResponseWait = new Map();
        var connectSuccess = false;
        var errors = [];
        var hasTotalReconnectTimedout = false;
        if (!_this._totalConnectionTimeoutId && _this._totalConnectionTimeout && _this._totalConnectionTimeout !== Infinity) {
          var totalReconnectTimeout = _this._totalConnectionTimeout;
          _this._totalConnectionTimeoutId = setTimeout(() => {
            if (false) {}
            hasTotalReconnectTimedout = true;
            if (reconnect && _this._retryLock) {
              _this._retryLock = false;
            }
            _this._totalConnectionTimeoutId = undefined;
            var totalConnectionTimeoutError = new TimeoutError(`reconnect timeout (reach totalConnectionTimeout ${totalReconnectTimeout}s)`, {
              subtype: 'totalConnectionTimeout',
              retryable: false
            });
            reportIDKey(ErrorID, ErrorKey.REALTIME_DB_WS_TOTAL_CONNECTION_TIMEOUT, true);
            _this._fsm.transition({
              type: WSEvent.CONNECTION_FAIL,
              error: totalConnectionTimeoutError
            });
          }, totalReconnectTimeout * 1000);
        }
        if (reconnect) {
          if (_this._retryLock) {
            if (false) {}
            return;
          }
          if (false) {}
          _this._retryLock = true;
        }
        var _loop = function* () {
            try {
              if (false) {}
              if (!(yield getNetworkStatus()).isConnected) {
                if (!reconnect) {
                  _this._fsm.transition({
                    type: WSEvent.CONNECTION_FAIL,
                    error: new Error(`network offline`)
                  });
                  return {
                    v: void 0
                  };
                } else {
                  yield onceNetworkOnline();
                  if (false) {}
                  if (_this._virtualWSClient.size === 0) {
                    if (false) {}
                    _this.clearTotalReconnectTimeout();
                    return {
                      v: void 0
                    };
                  }
                  if (isDevTools()) {
                    if (false) {}
                    yield sleep(DEFAULT_WAIT_TIME_AFTER_ONLINE_ON_IDE);
                  }
                }
              }
              if (hasTotalReconnectTimedout) {
                return {
                  v: void 0
                };
              }
              if (false) {}
              var signature = yield _this.getSignature(_this._connectionEnvId);
              if (hasTotalReconnectTimedout) {
                return {
                  v: void 0
                };
              }
              if (false) {}
              var connectSocketStartTime = Date.now();
              yield new Promise((success, fail) => {
                _this._ws = appserviceSdk_getSDK(_this._context.identifiers)._socketSkipCheckDomainFactory().connectSocket({
                  url: signature.wsUrl,
                  header: {
                    'content-type': 'application/json'
                  },
                  perMessageDeflate: true,
                  success,
                  fail
                });
              });
              if (hasTotalReconnectTimedout) {
                return {
                  v: void 0
                };
              }
              reportAPISpeed({
                apiName: '_realtime.connectSocket',
                apiStartTime: connectSocketStartTime,
                apiEndTime: Date.now()
              });
              if (false) {}
              yield _this.initWebSocketEvent();
              if (hasTotalReconnectTimedout) {
                return {
                  v: void 0
                };
              }
              if (ejsonInitPromise) {
                yield ejsonInitPromise;
                if (hasTotalReconnectTimedout) {
                  return {
                    v: void 0
                  };
                }
              }
              connectSuccess = true;
              return 0;
            } catch (e) {
              errors.unshift(e);
              if (false) {}
              if (e.errCode === error_config_ERR_CODE.TCB_PERMISSION_DENIED) {
                return 0;
              }
              var {
                isConnected
              } = yield getNetworkStatus();
              if (hasTotalReconnectTimedout) {
                return {
                  v: void 0
                };
              }
              if (isConnected) {
                if (false) {}
                yield sleep(_this._reconnectInterval);
                if (hasTotalReconnectTimedout) {
                  return {
                    v: void 0
                  };
                }
              }
              if (false) {}
              if (isDevTools()) {
                yield sleep(0);
                if (hasTotalReconnectTimedout) {
                  return {
                    v: void 0
                  };
                }
              }
            }
          },
          _ret;
        for (var i = _this._maxReconnect; i >= 0; i--) {
          _ret = yield* _loop();
          if (_ret === 0) break;
          if (_ret) return _ret.v;
        }
        if (reconnect && _this._retryLock) {
          if (false) {}
          _this._retryLock = false;
        }
        if (connectSuccess) {
          _this.clearTotalReconnectTimeout();
          reportIDKey(ErrorID, reconnect ? ErrorKey.REALTIME_DB_RECONNECT_WS_SUCCESS : ErrorKey.REALTIME_DB_INIT_WS_SUCCESS, true);
          _this._fsm.transition(WSEvent.CONNECTION_SUCCESS);
          if (false) {}
          return;
        }
        _this.clearTotalReconnectTimeout();
        reportIDKey(ErrorID, reconnect ? ErrorKey.REALTIME_DB_RECONNECT_WS_FAIL : ErrorKey.REALTIME_DB_INIT_WS_FAIL, true);
        if (false) {}
        if (reconnect) {
          _this._fsm.transition({
            type: WSEvent.CONNECTION_FAIL,
            error: new error_CloudSDKError({
              errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_RECONNECT_WS_FAIL,
              errMsg: `errors of each retry (latest to oldest): ${JSON.stringify(errors.map(e => e + ''))}`
            })
          });
        } else {
          _this._fsm.transition({
            type: WSEvent.CONNECTION_FAIL,
            error: new error_CloudSDKError({
              errCode: error_config_ERR_CODE.SDK_DATABASE_REALTIME_LISTENER_INIT_WS_FAIL,
              errMsg: `errors of each retry (latest to oldest): ${JSON.stringify(errors.map(e => e + ''))}`
            })
          });
        }
      });
      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }();
    this.initWebSocketEvent = () => new Promise((resolve, reject) => {
      if (!this._ws) {
        throw new Error(`can not initWebSocketEvent, ws not exists`);
      }
      var wsOpened = false;
      this._ws.onOpen(info => {
        this._context.debug && console.warn(`[realtime] ws event: open`, info);
        wsOpened = true;
        resolve();
      });
      var wsErrorEvent = null;
      this._ws.onError(error => {
        wsErrorEvent = error;
        this._logins = new Map();
        if (!wsOpened) {
          this._context.debug && console.error(`[realtime] ws open failed with ws event: error`, error);
          reject(error);
          reportIDKey(ErrorID, ErrorKey.REALTIME_DB_WS_ONERROR_BEFORE_OPEN, true);
        } else {
          this._context.debug && console.error(`[realtime] ws event: error`, error);
          this.clearHeartbeat();
          reportIDKey(ErrorID, ErrorKey.REALTIME_DB_WS_ONERROR_WHILE_ACTIVE, true);
        }
      });
      this._ws.onClose(closeEvent => {
        if (false) {}
        this._logins = new Map();
        this.clearHeartbeat();
        var error = wsErrorEvent || getWSCloseError(closeEvent.code);
        switch (closeEvent.code) {
          case CLOSE_EVENT_CODE.ReconnectOnServerUpgrade:
          case CLOSE_EVENT_CODE.ReconnectWebSocket:
            {
              this._fsm.transition({
                type: WSEvent.DISCONNECT,
                error
              });
              break;
            }
          case CLOSE_EVENT_CODE.NoRealtimeListeners:
            {
              this._fsm.transition({
                type: WSEvent.DISCONNECT,
                error
              });
              break;
            }
          case CLOSE_EVENT_CODE.HeartbeatPingError:
          case CLOSE_EVENT_CODE.HeartbeatPongTimeoutError:
          case CLOSE_EVENT_CODE.NormalClosure:
          case CLOSE_EVENT_CODE.AbnormalClosure:
            {
              if (this._maxReconnect > 0) {
                this._fsm.transition({
                  type: WSEvent.DISCONNECT,
                  error
                });
                this.initWebSocketConnection(true);
              } else {
                this._fsm.transition({
                  type: WSEvent.CONNECTION_FAIL,
                  error
                });
              }
              if (closeEvent.code === CLOSE_EVENT_CODE.HeartbeatPingError) {
                reportIDKey(ErrorID, ErrorKey.REALTIME_DB_WS_ONCLOSE_HEARTBEAT_PING_FAIL, true);
              } else if (closeEvent.code === CLOSE_EVENT_CODE.HeartbeatPongTimeoutError) {
                reportIDKey(ErrorID, ErrorKey.REALTIME_DB_WS_ONCLOSE_HEARTBEAT_PONG_TIMEOUT, true);
              } else {
                reportIDKey(ErrorID, ErrorKey.REALTIME_DB_WS_ONCLOSE_AB_NORMAL_CLOSURE, true);
              }
              break;
            }
          case CLOSE_EVENT_CODE.UnauthenticatedIdleConnection:
            {
              this._fsm.transition({
                type: WSEvent.CONNECTION_FAIL,
                error: getWSCloseError(closeEvent.code, closeEvent.reason)
              });
              reportIDKey(ErrorID, ErrorKey.REALTIME_DB_WS_ONCLOSE_SERVER_CLOSE_NO_AUTH, true);
              break;
            }
          case CLOSE_EVENT_CODE.ServerUpgrade:
            {
              this._fsm.transition({
                type: WSEvent.DISCONNECT,
                error
              });
              this.initWebSocketConnection(true);
              reportIDKey(ErrorID, ErrorKey.REALTIME_DB_WS_ONCLOSE_SERVER_CLOSE_FOR_UPGRADE, true);
              break;
            }
          default:
            {
              if (this._maxReconnect > 0) {
                this._fsm.transition({
                  type: WSEvent.DISCONNECT,
                  error
                });
                this.initWebSocketConnection(true);
              } else {
                this._fsm.transition({
                  type: WSEvent.CONNECTION_FAIL,
                  error: getWSCloseError(closeEvent.code, closeEvent.reason)
                });
              }
              reportIDKey(ErrorID, ErrorKey.REALTIME_DB_WS_ONCLOSE_UNKNOWN_ORIGIN, true);
              if (false) {}
            }
        }
        reportIDKey(ErrorID, ErrorKey.REALTIME_DB_WS_ONCLOSE, true);
      });
      var wrapTimingOptions = {
        timing: {},
        startKey: 'apiStartTime',
        endKey: 'apiEndTime',
        samplePicker: socketOnMessageSamplePicker,
        autoReport: '_realtime.onSocketMessage'
      };
      this._ws.onMessage(wrapTiming(this.onSocketMessage, wrapTimingOptions));
      this.heartbeat();
    });
    this.isWSConnected = () => {
      return Boolean(this._ws && this._ws.readyState === WS_READY_STATE.OPEN);
    };
    this.onSocketMessage = res => {
      var rawMsg = res.data;
      this.heartbeat();
      var msg;
      try {
        msg = JSON.parse(rawMsg);
      } catch (e) {
        throw new Error(`[realtime] onMessage parse res.data error: ${e}`);
      }
      this._context.debug && console.log(`[realtime] onMessage ${msg.msgType} (${new Date().toLocaleString()})`, msg);
      var responseWaitSpec = this._wsResponseWait.get(msg.requestId);
      if (responseWaitSpec) {
        try {
          if (msg.msgType === 'ERROR') {
            responseWaitSpec.reject(new RealtimeErrorMessageError(msg));
          } else {
            responseWaitSpec.resolve(msg);
          }
        } catch (e) {
          this._context.debug && console.error(`ws onMessage responseWaitSpec.resolve(msg) errored:`, e);
        } finally {
          this._wsResponseWait.delete(msg.requestId);
        }
        if (responseWaitSpec.skipOnMessage) {
          return;
        }
      }
      if (msg.msgType === 'PONG') {
        if (this._lastPingSendTS) {
          var rtt = Date.now() - this._lastPingSendTS;
          if (rtt > DEFAULT_UNTRUSTED_RTT_THRESHOLD) {
            this._context.debug && console.warn(`[realtime] untrusted rtt observed: ${rtt}`);
            return;
          }
          if (this._rttObserved.length >= MAX_RTT_OBSERVED) {
            this._rttObserved.splice(0, this._rttObserved.length - MAX_RTT_OBSERVED + 1);
          }
          this._rttObserved.push(rtt);
        }
        return;
      }
      var client = msg.watchId && this._watchIdClientMap.get(msg.watchId);
      if (client) {
        client.onMessage(msg);
      } else {
        if (msg.watchId) {
          if (this._closedWatches.has(msg.watchId)) {
            if (false) {}
            reportIDKey(ErrorID, ErrorKey.REALTIME_DB_RECV_MSG_WITH_CLOSED_WATCHID, true);
          } else {
            if (false) {}
            reportIDKey(ErrorID, ErrorKey.REALTIME_DB_RECV_MSG_WITH_UNKNOWN_WATCHID, true);
          }
        } else {
          if (false) {}
          reportIDKey(ErrorID, ErrorKey.REALTIME_DB_RECV_MSG_WITHOUT_WATCHID, true);
        }
        switch (msg.msgType) {
          case 'INIT_EVENT':
          case 'NEXT_EVENT':
          case 'CHECK_EVENT':
            {
              client = this._queryIdClientMap.get(msg.msgData.queryID);
              if (client) {
                client.onMessage(msg);
              }
              break;
            }
          default:
            {}
        }
      }
    };
    this.login = /*#__PURE__*/function () {
      var _ref2 = asyncToGenerator_default()(function* (envId, refresh, timing) {
        envId = envId || _this._context.env || _this._defaultEnvId;
        if (!refresh) {
          if (envId) {
            var _loginInfo = _this._logins.get(envId);
            if (_loginInfo) {
              if (_loginInfo.loggedIn && _loginInfo.loginResult) {
                if (false) {}
                return _loginInfo.loginResult;
              } else if (_loginInfo.loggingInPromise) {
                return _loginInfo.loggingInPromise;
              }
            }
          } else {
            var emptyEnvLoginInfo = _this._logins.get('');
            if (emptyEnvLoginInfo && emptyEnvLoginInfo.loggingInPromise) {
              return emptyEnvLoginInfo.loggingInPromise;
            }
          }
        }
        if (false) {}
        var promise = new Promise(/*#__PURE__*/function () {
          var _ref3 = asyncToGenerator_default()(function* (resolve, reject) {
            try {
              var signature = yield timing ? wrapTiming(_this.getSignature(envId, refresh), {
                timing,
                startKey: 'tunnelStartTime',
                endKey: 'tunnelEndTime',
                condition: {
                  emptyKey: true
                }
              }) : _this.getSignature(envId, refresh);
              var wxVersion = getWXVersion();
              var loginMsg = {
                watchId: undefined,
                requestId: genRequestId(),
                msgType: 'LOGIN',
                msgData: {
                  envId: signature.envId,
                  signStr: signature.signStr,
                  secretVersion: signature.secretVersion,
                  referrer: 'mp',
                  sdkVersion: wxVersion.version,
                  dataVersion: wxVersion.updateDateInDashes
                }
              };
              var loginResMsg = yield _this.send({
                msg: loginMsg,
                waitResponse: true,
                skipOnMessage: true,
                timeout: DEFAULT_LOGIN_TIMEOUT
              });
              if (!loginResMsg.msgData.code) {
                resolve({
                  envId: signature.envId
                });
              } else {
                reject(new Error(`${loginResMsg.msgData.code} ${loginResMsg.msgData.message}`));
              }
            } catch (e) {
              reject(e);
            }
          });
          return function (_x5, _x6) {
            return _ref3.apply(this, arguments);
          };
        }());
        var loginInfo = envId && _this._logins.get(envId);
        var loginStartTS = Date.now();
        if (loginInfo) {
          loginInfo.loggedIn = false;
          loginInfo.loggingInPromise = promise;
          loginInfo.loginStartTS = loginStartTS;
        } else {
          loginInfo = {
            loggedIn: false,
            loggingInPromise: promise,
            loginStartTS
          };
          _this._logins.set(envId || '', loginInfo);
        }
        try {
          var loginResult = yield promise;
          var curLoginInfo = _this._logins.get(envId || '');
          if (curLoginInfo && curLoginInfo === loginInfo && curLoginInfo.loginStartTS === loginStartTS) {
            loginInfo.loggedIn = true;
            loginInfo.loggingInPromise = undefined;
            loginInfo.loginStartTS = undefined;
            loginInfo.loginResult = loginResult;
            return loginResult;
          } else if (curLoginInfo) {
            if (curLoginInfo.loggedIn && curLoginInfo.loginResult) {
              return curLoginInfo.loginResult;
            } else if (curLoginInfo.loggingInPromise) {
              return curLoginInfo.loggingInPromise;
            } else {
              throw new Error(`ws unexpected login info`);
            }
          } else {
            throw new Error(`ws login info reset`);
          }
        } catch (e) {
          loginInfo.loggedIn = false;
          loginInfo.loggingInPromise = undefined;
          loginInfo.loginStartTS = undefined;
          loginInfo.loginResult = undefined;
          throw e;
        }
      });
      return function (_x2, _x3, _x4) {
        return _ref2.apply(this, arguments);
      };
    }();
    this.getSignature = /*#__PURE__*/function () {
      var _ref4 = asyncToGenerator_default()(function* (envId, refresh) {
        envId = envId || _this._context.env || _this._defaultEnvId;
        if (!refresh && envId && _this._signatures.has(envId)) {
          var _signature = _this._signatures.get(envId);
          if (Date.now() < _signature.expireTS) {
            if (false) {}
            return _signature;
          } else if (false) {}
        } else if (false) {}
        var expireTS = Date.now() + 60 * 1000;
        var signatureResp = yield getRealtimeConnectionSignature(_this._context, envId);
        if (Date.now() - expireTS > 60 * 1000) {
          return _this.getSignature(envId, refresh);
        }
        var signature = {
          ...signatureResp,
          expireTS
        };
        _this._signatures.set(signature.envId, signature);
        if (!envId) {
          _this._defaultEnvId = signature.envId;
        }
        return signature;
      });
      return function (_x7, _x8) {
        return _ref4.apply(this, arguments);
      };
    }();
    this.getWaitExpectedTimeoutLength = () => {
      if (!this._rttObserved.length) {
        return DEFAULT_EXPECTED_EVENT_WAIT_TIME;
      }
      return this._rttObserved.reduce((acc, cur) => acc + cur) / this._rttObserved.length * 1.5;
    };
    this.ping = /*#__PURE__*/asyncToGenerator_default()(function* () {
      var msg = {
        watchId: undefined,
        requestId: genRequestId(),
        msgType: 'PING',
        msgData: null
      };
      yield _this.send({
        msg
      });
      _this._context.debug && console.log('ping sent');
    });
    this.send = opts => new Promise(/*#__PURE__*/function () {
      var _ref6 = asyncToGenerator_default()(function* (_resolve, _reject) {
        if (_this._fsm.currentState !== WSState.CONNECTED) {
          return _reject(new Error(`websocket not connected`));
        }
        var timeoutId;
        var _hasResolved = false;
        var _hasRejected = false;
        var resolve = value => {
          _hasResolved = true;
          timeoutId && clearTimeout(timeoutId);
          _resolve(value);
        };
        var reject = error => {
          _hasRejected = true;
          timeoutId && clearTimeout(timeoutId);
          _reject(error);
        };
        if (opts.timeout) {
          timeoutId = setTimeout(/*#__PURE__*/asyncToGenerator_default()(function* () {
            if (!_hasResolved || !_hasRejected) {
              yield sleep(0);
              if (!_hasResolved || !_hasRejected) {
                if (false) {}
                reject(new TimeoutError(`wsclient.send timedout`));
              }
            }
          }), opts.timeout);
        }
        try {
          if (_this._context.debug) {
            console.log(`[realtime] ws send ${opts.msg.msgType} (${new Date().toLocaleString()}): `, opts);
          }
          if (!_this._ws) {
            reject(new Error(`invalid state: ws connection not exists, can not send message`));
            return;
          }
          if (_this._ws.readyState !== WS_READY_STATE.OPEN) {
            reject(new Error(`ws readyState invalid: ${_this._ws.readyState}, can not send message`));
            return;
          }
          if (opts.waitResponse) {
            _this._wsResponseWait.set(opts.msg.requestId, {
              resolve,
              reject,
              skipOnMessage: opts.skipOnMessage
            });
          }
          _this._ws.send({
            data: JSON.stringify(opts.msg),
            success: res => {
              if (!opts.waitResponse) {
                resolve(res);
              }
            },
            fail: e => {
              reject(e);
              if (opts.waitResponse) {
                _this._wsResponseWait.delete(opts.msg.requestId);
              }
            }
          });
        } catch (e) {
          reject(e);
        }
      });
      return function (_x9, _x10) {
        return _ref6.apply(this, arguments);
      };
    }());
    this.onWatchStart = (client, queryID) => {
      this._queryIdClientMap.set(queryID, client);
    };
    this.onWatchClose = (client, queryID) => {
      if (queryID) {
        this._queryIdClientMap.delete(queryID);
      }
      this._watchIdClientMap.delete(client.watchId);
      this._virtualWSClient.delete(client);
      this._closedWatches.add(client.watchId);
      if (!this._virtualWSClient.size) {
        this.close(CLOSE_EVENT_CODE.NoRealtimeListeners);
      }
    };
    this.getEJSON = () => {
      return this._EJSON;
    };
    this._fsm = new FSM({
      initialState: WSState.DISCONNECTED,
      states: WSStates
    });
    this._serviceContext = options.serviceContext;
  }
  get _context() {
    return this._serviceContext;
  }
  get _maxReconnect() {
    return this._context.appConfig.realtimeMaxReconnect;
  }
  get _reconnectInterval() {
    return this._context.appConfig.realtimeReconnectInterval;
  }
  get _totalConnectionTimeout() {
    return this._context.appConfig.realtimeTotalConnectionTimeout;
  }
  heartbeat(immediate) {
    var _this2 = this;
    this.clearHeartbeat();
    this._pingTimeoutId = setTimeout(/*#__PURE__*/asyncToGenerator_default()(function* () {
      try {
        if (!_this2._ws || _this2._ws.readyState !== WS_READY_STATE.OPEN) {
          return;
        }
        _this2._lastPingSendTS = Date.now();
        yield _this2.ping();
        _this2._pingFailed = 0;
        _this2._pongTimeoutId = setTimeout(() => {
          _this2._context.debug && console.error(`pong timed out`);
          if (_this2._pongMissed < DEFAULT_PONG_MISS_TOLERANCE) {
            _this2._pongMissed++;
            _this2.heartbeat(true);
          } else {
            _this2.close(CLOSE_EVENT_CODE.HeartbeatPongTimeoutError);
          }
        }, _this2._context.appConfig.realtimePongWaitTimeout);
      } catch (e) {
        if (_this2._pingFailed < DEFAULT_PING_FAIL_TOLERANCE) {
          _this2._pingFailed++;
          _this2.heartbeat();
        } else {
          _this2.close(CLOSE_EVENT_CODE.HeartbeatPingError);
        }
      }
    }), immediate ? 0 : this._context.appConfig.realtimePingInterval);
  }
  clearHeartbeat() {
    this._pingTimeoutId && clearTimeout(this._pingTimeoutId);
    this._pongTimeoutId && clearTimeout(this._pongTimeoutId);
  }
  clearTotalReconnectTimeout() {
    this._totalConnectionTimeoutId && clearTimeout(this._totalConnectionTimeoutId);
  }
  close(code) {
    this.clearHeartbeat();
    if (this._ws) {
      this._ws.close({
        code,
        reason: CLOSE_EVENT_CODE_INFO[code].name
      });
      this._ws = undefined;
    }
  }
  watch(options) {
    var timing = {
      apiStartTime: Date.now()
    };
    var timingReported = false;
    var report = () => {
      reportAPISpeed({
        ...timing,
        apiName: options.reportAPIName
      });
    };
    var _onChange = options.onChange;
    var _onError = options.onError;
    if (this._fsm.currentState === WSState.DISCONNECTED) {
      this._connectionEnvId = options.envId;
      this.initWebSocketConnection(false);
    }
    var virtualClient = new VirtualWebSocketClient({
      ...options,
      parentFSM: this._fsm,
      send: this.send,
      login: this.login,
      isWSConnected: this.isWSConnected,
      getWaitExpectedTimeoutLength: this.getWaitExpectedTimeoutLength,
      getEJSON: this.getEJSON,
      getServiceContext: () => this._context,
      onWatchStart: this.onWatchStart,
      onWatchClose: this.onWatchClose,
      timing,
      debug: this._context.debug,
      wsclient: this,
      onChange,
      onError
    });
    this._virtualWSClient.add(virtualClient);
    this._watchIdClientMap.set(virtualClient.watchId, virtualClient);
    var listener = virtualClient.listener;
    return listener;
    function onChange(...args) {
      if (!timingReported) {
        timingReported = true;
        timing.apiEndTime = Date.now();
        report();
      }
      restoreUserHandlers();
      reporter.surroundThirdByTryCatch(() => listener.onChange.apply(this, args))();
    }
    function onError(...args) {
      if (!timingReported) {
        timingReported = true;
        timing.apiEndTime = Date.now();
        report();
      }
      restoreUserHandlers();
      reporter.surroundThirdByTryCatch(() => listener.onError.apply(this, args))();
    }
    function restoreUserHandlers() {
      if (listener.onChange === onChange) {
        listener.onChange = _onChange;
      }
      if (listener.onError === onError) {
        listener.onError = _onError;
      }
    }
  }
}
function initEJSON() {
  return _initEJSON.apply(this, arguments);
}
function _initEJSON() {
  _initEJSON = asyncToGenerator_default()(function* () {
    var apiStartTime = Date.now();
    var bson = __webpack_require__(432);
    reportAPISpeed({
      apiName: '_realtime.importBSON',
      apiStartTime,
      apiEndTime: Date.now()
    });
    return bson.EJSON;
  });
  return _initEJSON.apply(this, arguments);
}
;// CONCATENATED MODULE: ./src/services/database/api/database/query.ts












var query_ORDER_DIRECTION = /*#__PURE__*/function (ORDER_DIRECTION) {
  ORDER_DIRECTION["ASC"] = "asc";
  ORDER_DIRECTION["DESC"] = "desc";
  return ORDER_DIRECTION;
}({});
var getQueryClass = instanceContext => {
  class Query {
    constructor(collectionName, condition) {
      this.collectionName = void 0;
      this._query = void 0;
      this._field = void 0;
      this.__safe_props__ = void 0;
      this.watch = options => {
        assertType(options, {
          onChange: 'function',
          onError: 'function'
        });
        if (!instanceContext.serviceContext.ws) {
          instanceContext.serviceContext.ws = new RealtimeWebSocketClient({
            serviceContext: instanceContext.serviceContext
          });
        }
        return instanceContext.serviceContext.ws.watch({
          ...options,
          envId: instanceContext.database.config.env || instanceContext.serviceContext.env,
          collectionName: this.collectionName,
          query: JSON.stringify(instanceContext.engine.QuerySerializer.encode(this._query.where || {})),
          limit: this._query.limit,
          orderBy: this._query.order ? this._query.order.reduce((acc, cur) => {
            acc[cur.fieldPath] = cur.order;
            return acc;
          }, {}) : undefined,
          queryType: QUERY_TYPE.WHERE,
          reportAPIName: 'cloud.db.collection.watch'
        });
      };
      if (!collectionName) {
        throw new error_CloudSDKError({
          errCode: error_config_ERR_CODE.SDK_API_PARAMETER_TYPE_ERROR,
          errMsg: 'collectionName must be provided'
        });
      }
      this.collectionName = collectionName;
      this._query = new InternalQuery(condition);
      Object.defineProperties(this, {
        _field: {
          enumerable: false,
          configurable: false,
          writable: true
        }
      });
      this._field = condition && condition.field || {};
      if (false) {}
    }
    field(object) {
      assertRequiredParam(object, 'object', 'field');
      return new Query(this.collectionName, {
        ...this._query.getProperties(),
        field: object
      });
    }
    where(condition) {
      assertRequiredParam(condition, 'condition', 'where');
      if (this._query.where) {
        return new Query(this.collectionName, {
          ...this._query.getProperties(),
          where: commands.and(this._query.where, condition)
        });
      } else {
        return new Query(this.collectionName, {
          ...this._query.getProperties(),
          where: condition
        });
      }
    }
    orderBy(fieldPath, order) {
      assertRequiredParam(fieldPath, 'fieldPath', 'orderBy');
      assertRequiredParam(order, 'order', 'orderBy');
      return new Query(this.collectionName, {
        ...this._query.getProperties(),
        order: [...(this._query.order || []), {
          fieldPath,
          order
        }]
      });
    }
    limit(max) {
      assertRequiredParam(max, 'max', 'limit');
      return new Query(this.collectionName, {
        ...this._query.getProperties(),
        limit: max
      });
    }
    skip(offset) {
      assertRequiredParam(offset, 'offset', 'skip');
      return new Query(this.collectionName, {
        ...this._query.getProperties(),
        offset
      });
    }
    get(options) {
      var apiName = 'collection.get';
      var timing = {
        apiStartTime: +new Date()
      };
      var _queryDocument = () => {
        return queryDocument({
          env: instanceContext.database.config.env,
          collectionName: this.collectionName,
          query: instanceContext.engine.QuerySerializer.encode(this._query.where || {}),
          queryType: QUERY_TYPE.WHERE,
          options: extractQueryOptions(this, instanceContext),
          instanceContext,
          timing,
          explain: options === null || options === void 0 ? void 0 : options.explain
        });
      };
      if (false) {}
      var useCallback = hasAPICallback(options);
      var promise = new Promise(/*#__PURE__*/function () {
        var _ref = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            var queryResult = yield _queryDocument();
            if (options !== null && options !== void 0 && options.explain && isDevTools()) {
              resolve(queryResult);
              return;
            }
            resolve({
              data: queryResult.list,
              errMsg: apiSuccessMsg(apiName)
            });
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, apiName));
          } finally {
            reportAPISpeed({
              ...timing,
              apiEndTime: +new Date(),
              apiName: `cloud.db.${apiName}`
            });
          }
        });
        return function (_x, _x2) {
          return _ref.apply(this, arguments);
        };
      }());
      if (useCallback) {
        promise.then(res => {
          invokeSuccessCompleteCallbacks(apiName, options, res);
        }).catch(err => {
          invokeFailCompleteCallbacks(apiName, options, err);
        });
      } else return promise;
    }
    update(options) {
      var apiName = 'collection.update';
      var timing = {
        apiStartTime: +new Date()
      };
      var validateInput = () => {
        assertRequiredParam(options, 'options', 'update');
        assertType(options, {
          data: 'object'
        });
        if (!this._query.where) {
          throw new error_CloudSDKError({
            errCode: -1,
            errMsg: `query condition must be provided`
          });
        }
      };
      var _updateDocument = () => {
        return updateDocument({
          env: instanceContext.database.config.env,
          collectionName: this.collectionName,
          query: instanceContext.engine.QuerySerializer.encode(this._query.where || {}),
          data: instanceContext.engine.UpdateSerializer.encode(options.data),
          queryType: QUERY_TYPE.WHERE,
          options: {
            multi: options.multi === false ? false : true,
            merge: true
          },
          instanceContext,
          timing,
          explain: options.explain
        });
      };
      if (false) {}
      var useCallback = hasAPICallback(options);
      var promise = new Promise(/*#__PURE__*/function () {
        var _ref2 = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            validateInput();
            var updateResult = yield _updateDocument();
            if (options !== null && options !== void 0 && options.explain && isDevTools()) {
              return resolve(updateResult);
            }
            resolve({
              stats: {
                updated: updateResult.updated
              },
              errMsg: apiSuccessMsg(apiName)
            });
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, apiName));
          } finally {
            reportAPISpeed({
              ...timing,
              apiEndTime: +new Date(),
              apiName: `cloud.db.${apiName}`
            });
          }
        });
        return function (_x3, _x4) {
          return _ref2.apply(this, arguments);
        };
      }());
      if (useCallback) {
        promise.then(res => {
          invokeSuccessCompleteCallbacks(apiName, options, res);
        }).catch(err => {
          invokeFailCompleteCallbacks(apiName, options, err);
        });
      } else return promise;
    }
    remove(options) {
      var apiName = 'collection.remove';
      var timing = {
        apiStartTime: +new Date()
      };
      var validateInput = () => {
        if (!this._query.where || Object.keys(this._query.where).length === 0) {
          throw new error_CloudSDKError({
            errCode: -1,
            errMsg: `query condition must be provided and not be empty`
          });
        }
      };
      var _removeDocument = () => {
        return removeDocument({
          env: instanceContext.database.config.env,
          collectionName: this.collectionName,
          query: instanceContext.engine.QuerySerializer.encode(this._query.where || {}),
          queryType: QUERY_TYPE.WHERE,
          options: {
            multi: true
          },
          instanceContext,
          timing,
          explain: options === null || options === void 0 ? void 0 : options.explain
        });
      };
      if (false) {}
      var useCallback = hasAPICallback(options);
      var promise = new Promise(/*#__PURE__*/function () {
        var _ref3 = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            validateInput();
            var removeResult = yield _removeDocument();
            if (options !== null && options !== void 0 && options.explain && isDevTools()) {
              return resolve(removeResult);
            }
            resolve({
              stats: {
                removed: removeResult.removed || 0
              },
              errMsg: apiSuccessMsg(apiName)
            });
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, apiName));
          } finally {
            reportAPISpeed({
              ...timing,
              apiEndTime: +new Date(),
              apiName: `cloud.db.${apiName}`
            });
          }
        });
        return function (_x5, _x6) {
          return _ref3.apply(this, arguments);
        };
      }());
      if (useCallback) {
        promise.then(res => {
          invokeSuccessCompleteCallbacks(apiName, options, res);
        }).catch(err => {
          invokeFailCompleteCallbacks(apiName, options, err);
        });
      } else return promise;
    }
    count(options) {
      var apiName = 'collection.count';
      var timing = {
        apiStartTime: +new Date()
      };
      var _countDocument = () => {
        return countDocument({
          env: instanceContext.database.config.env,
          collectionName: this.collectionName,
          query: instanceContext.engine.QuerySerializer.encode(this._query.where || {}),
          queryType: QUERY_TYPE.WHERE,
          instanceContext,
          timing,
          explain: options === null || options === void 0 ? void 0 : options.explain
        });
      };
      if (false) {}
      var useCallback = hasAPICallback(options);
      var promise = new Promise(/*#__PURE__*/function () {
        var _ref4 = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            var queryResult = yield _countDocument();
            if (options !== null && options !== void 0 && options.explain && isDevTools()) {
              return resolve(queryResult);
            }
            resolve({
              total: queryResult.total,
              errMsg: apiSuccessMsg(apiName)
            });
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, apiName));
          } finally {
            reportAPISpeed({
              ...timing,
              apiEndTime: +new Date(),
              apiName: `cloud.db.${apiName}`
            });
          }
        });
        return function (_x7, _x8) {
          return _ref4.apply(this, arguments);
        };
      }());
      if (useCallback) {
        promise.then(res => {
          invokeSuccessCompleteCallbacks(apiName, options, res);
        }).catch(err => {
          invokeFailCompleteCallbacks(apiName, options, err);
        });
      } else return promise;
    }
    toJSON() {
      return undefined;
    }
  }
  class InternalQuery {
    constructor(options) {
      this.where = void 0;
      this.offset = void 0;
      this.limit = void 0;
      this.order = void 0;
      this.field = void 0;
      this.where = options && options.where;
      this.offset = options && options.offset;
      this.limit = options && options.limit;
      this.order = options && options.order;
      this.field = options && options.field;
    }
    getProperties() {
      return {
        where: this.where,
        offset: this.offset,
        limit: this.limit,
        order: this.order,
        field: this.field
      };
    }
  }
  return Query;
};
;// CONCATENATED MODULE: ./src/services/database/api/database/document.ts









var GET_API_NAME = 'document.get';
var UPDATE_API_NAME = 'document.update';
var SET_API_NAME = 'document.set';
var REMOVE_API_NAME = 'document.remove';
var getDocumentReferenceClass = instanceContext => {
  return class DocumentReference {
    constructor(collection, docId) {
      this._id = void 0;
      this.collection = void 0;
      this._field = void 0;
      this.__safe_props__ = void 0;
      this.watch = options => {
        assertType(options, {
          onChange: 'function',
          onError: 'function'
        });
        if (!instanceContext.serviceContext.ws) {
          instanceContext.serviceContext.ws = new RealtimeWebSocketClient({
            serviceContext: instanceContext.serviceContext
          });
        }
        return instanceContext.serviceContext.ws.watch({
          ...options,
          envId: instanceContext.database.config.env || instanceContext.serviceContext.env,
          collectionName: this.collection.collectionName,
          query: JSON.stringify({
            _id: this._id
          }),
          queryType: QUERY_TYPE.DOC,
          reportAPIName: 'cloud.db.document.watch'
        });
      };
      this.collection = collection;
      this._id = docId;
      if (docId === null || docId === undefined) {
        throw new error_CloudSDKError({
          errCode: error_config_ERR_CODE.SDK_API_PARAMETER_TYPE_ERROR,
          errMsg: 'docId must not be null or undefined'
        });
      }
      Object.defineProperties(this, {
        _field: {
          enumerable: false,
          configurable: false,
          writable: true
        }
      });
      this._field = {};
      if (false) {}
    }
    field(object) {
      assertRequiredParam(object, 'object', 'field');
      assertType(object, 'object', 'field');
      this._field = object;
      return this;
    }
    get(options) {
      var _this = this;
      var timing = {
        apiStartTime: +new Date()
      };
      var _queryDocument = () => {
        return queryDocument({
          env: instanceContext.database.config.env,
          collectionName: this.collection.collectionName,
          query: instanceContext.engine.QuerySerializer.encode({
            _id: this._id
          }),
          options: {
            projection: instanceContext.engine.ProjectionSerializer.encode(this._field)
          },
          queryType: QUERY_TYPE.DOC,
          instanceContext,
          timing
        });
      };
      if (false) {}
      var useCallback = hasAPICallback(options);
      var promise = new Promise(/*#__PURE__*/function () {
        var _ref = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            var _id = _this._id;
            var queryResult = yield _queryDocument();
            if (!queryResult.list || !queryResult.list.length) {
              throw new Error(`cannot find document with _id ${_id}, ` + `please make sure that the document exists and you have the corresponding access permission`);
            }
            resolve({
              data: queryResult.list[0],
              errMsg: apiSuccessMsg(GET_API_NAME)
            });
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, GET_API_NAME));
          } finally {
            reportAPISpeed({
              ...timing,
              apiEndTime: +new Date(),
              apiName: `cloud.db.${GET_API_NAME}`
            });
          }
        });
        return function (_x, _x2) {
          return _ref.apply(this, arguments);
        };
      }());
      if (useCallback) {
        promise.then(res => {
          invokeSuccessCompleteCallbacks(GET_API_NAME, options, res);
        }).catch(err => {
          invokeFailCompleteCallbacks(GET_API_NAME, options, err);
        });
      } else return promise;
    }
    set(options) {
      var timing = {
        apiStartTime: +new Date()
      };
      var validateInput = () => {
        assertType(options, {
          data: 'object'
        });
        assertObjectNotEmpty({
          name: 'options.data',
          target: options.data
        });
      };
      var _setDocument = () => {
        return setDocument({
          env: instanceContext.database.config.env,
          collectionName: this.collection.collectionName,
          _id: this._id,
          data: instanceContext.engine.encodeInternalDataType(options.data),
          options: {},
          instanceContext,
          timing
        });
      };
      if (false) {}
      var useCallback = hasAPICallback(options);
      var promise = new Promise(/*#__PURE__*/function () {
        var _ref2 = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            validateInput();
            var setResult = yield _setDocument();
            resolve({
              _id: setResult._id,
              errMsg: apiSuccessMsg(SET_API_NAME),
              stats: {
                updated: setResult.updated,
                created: setResult.created
              }
            });
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, SET_API_NAME));
          } finally {
            reportAPISpeed({
              ...timing,
              apiEndTime: +new Date(),
              apiName: `cloud.db.${SET_API_NAME}`
            });
          }
        });
        return function (_x3, _x4) {
          return _ref2.apply(this, arguments);
        };
      }());
      if (useCallback) {
        promise.then(res => {
          invokeSuccessCompleteCallbacks(SET_API_NAME, options, res);
        }).catch(err => {
          invokeFailCompleteCallbacks(SET_API_NAME, options, err);
        });
      } else return promise;
    }
    update(options) {
      var timing = {
        apiStartTime: +new Date()
      };
      var validateInput = () => {
        assertType(options, {
          data: 'object'
        });
        assertObjectNotEmpty({
          name: 'options.data',
          target: options.data
        });
      };
      var _updateDocument = () => {
        return updateDocument({
          env: instanceContext.database.config.env,
          collectionName: this.collection.collectionName,
          query: instanceContext.engine.QuerySerializer.encode({
            _id: this._id
          }),
          data: instanceContext.engine.UpdateSerializer.encode(options.data),
          queryType: QUERY_TYPE.DOC,
          options: {
            multi: false,
            merge: false
          },
          instanceContext,
          timing
        });
      };
      if (false) {}
      var useCallback = hasAPICallback(options);
      var promise = new Promise(/*#__PURE__*/function () {
        var _ref3 = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            validateInput();
            var updateResult = yield _updateDocument();
            resolve({
              stats: {
                updated: updateResult.updated
              },
              errMsg: apiSuccessMsg(UPDATE_API_NAME)
            });
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, UPDATE_API_NAME));
          } finally {
            reportAPISpeed({
              ...timing,
              apiEndTime: +new Date(),
              apiName: `cloud.db.${UPDATE_API_NAME}`
            });
          }
        });
        return function (_x5, _x6) {
          return _ref3.apply(this, arguments);
        };
      }());
      if (useCallback) {
        promise.then(res => {
          invokeSuccessCompleteCallbacks(UPDATE_API_NAME, options, res);
        }).catch(err => {
          invokeFailCompleteCallbacks(UPDATE_API_NAME, options, err);
        });
      } else return promise;
    }
    remove(options) {
      var _this2 = this;
      var timing = {
        apiStartTime: +new Date()
      };
      var _removeDocument = () => {
        return removeDocument({
          env: instanceContext.database.config.env,
          collectionName: this.collection.collectionName,
          query: instanceContext.engine.QuerySerializer.encode({
            _id: this._id
          }),
          queryType: QUERY_TYPE.DOC,
          options: {},
          instanceContext,
          timing
        });
      };
      if (false) {}
      var useCallback = hasAPICallback(options);
      var promise = new Promise(/*#__PURE__*/function () {
        var _ref4 = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            var _id = _this2._id;
            var removeResult = yield _removeDocument();
            if (removeResult.removed === 0) {
              throw new Error(`cannot remove document with _id ${_id}, ` + `please make sure that the document exists and you have the corresponding Write permission`);
            }
            resolve({
              stats: {
                removed: removeResult.removed || 0
              },
              errMsg: apiSuccessMsg(REMOVE_API_NAME)
            });
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, REMOVE_API_NAME));
          } finally {
            reportAPISpeed({
              ...timing,
              apiEndTime: +new Date(),
              apiName: `cloud.db.${REMOVE_API_NAME}`
            });
          }
        });
        return function (_x7, _x8) {
          return _ref4.apply(this, arguments);
        };
      }());
      if (useCallback) {
        promise.then(res => {
          invokeSuccessCompleteCallbacks(REMOVE_API_NAME, options, res);
        }).catch(err => {
          invokeFailCompleteCallbacks(REMOVE_API_NAME, options, err);
        });
      } else return promise;
    }
    toJSON() {
      return undefined;
    }
  };
};
;// CONCATENATED MODULE: ./src/services/database/api/database/collection.ts










var getCollectionReferenceClass = instanceContext => {
  var Query = getQueryClass(instanceContext);
  var DocumentReference = getDocumentReferenceClass(instanceContext);
  var Aggregate = getAggregateClass(instanceContext);
  return class CollectionReference extends Query {
    constructor(collectionName) {
      super(collectionName);
      this.collectionName = void 0;
      this.__safe_props__ = void 0;
      this.collectionName = collectionName;
      if (false) {}
    }
    doc(docId) {
      if (docId === null || docId === undefined) {
        throw returnAsFinalCloudSDKError({
          errCode: -1,
          errMsg: 'docId must not be empty'
        }, 'collection.doc');
      }
      return new DocumentReference(this, docId);
    }
    add(options) {
      var apiName = 'collection.add';
      var timing = {
        apiStartTime: +new Date()
      };
      var validateInput = () => {
        if (true) {
          assertType(options, {
            data: 'object'
          });
        } else {}
      };
      var _addDocument = () => {
        return addDocument({
          env: instanceContext.database.config.env,
          collectionName: this.collectionName,
          data: instanceContext.engine.encodeInternalDataType(options.data),
          instanceContext,
          timing
        });
      };
      if (false) {}
      var useCallback = hasAPICallback(options);
      var promise = new Promise(/*#__PURE__*/function () {
        var _ref = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            validateInput();
            var addResult = yield _addDocument();
            resolve({
              _id: addResult._id,
              errMsg: apiSuccessMsg(apiName)
            });
          } catch (err) {
            reject(returnAsFinalCloudSDKError(err, apiName));
          } finally {
            reportAPISpeed({
              ...timing,
              apiEndTime: +new Date(),
              apiName: `cloud.db.${apiName}`
            });
          }
        });
        return function (_x, _x2) {
          return _ref.apply(this, arguments);
        };
      }());
      if (useCallback) {
        promise.then(res => {
          invokeSuccessCompleteCallbacks(apiName, options, res);
        }).catch(err => {
          invokeFailCompleteCallbacks(apiName, options, err);
        });
      } else return promise;
    }
    aggregate() {
      return new Aggregate(this, []);
    }
  };
};
;// CONCATENATED MODULE: ./src/services/database/api/database/regexp.ts


var regExp = function (options) {
  return new subpackage_index_RegExp(options);
};
class subpackage_index_RegExp {
  constructor(options) {
    this.regexp = void 0;
    this.options = void 0;
    assertType(options, {
      regexp: 'string'
    }, 'RegExp options');
    if (options.options) {
      assertType(options.options, 'string');
    }
    this.regexp = options.regexp;
    this.options = options.options || '';
  }
  get _internalType() {
    return SYMBOL_REGEXP;
  }
  toJSON() {
    return {
      $regex: this.regexp,
      $options: this.options
    };
  }
}
;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/operator-map.ts




var OperatorMap = {};
var AggregateOperatorMap = {};
for (var key in QUERY_COMMANDS_LITERAL) {
  OperatorMap[QUERY_COMMANDS_LITERAL[key]] = `$${QUERY_COMMANDS_LITERAL[key]}`;
}
for (var _key in LOGIC_COMMANDS_LITERAL) {
  OperatorMap[LOGIC_COMMANDS_LITERAL[_key]] = `$${LOGIC_COMMANDS_LITERAL[_key]}`;
}
for (var _key2 in UPDATE_COMMANDS_LITERAL) {
  OperatorMap[UPDATE_COMMANDS_LITERAL[_key2]] = `$${UPDATE_COMMANDS_LITERAL[_key2]}`;
}
for (var _key3 in AGGREGATE_COMMANDS_LITERAL) {
  if ( true && AGGREGATE_COMMANDS_LITERAL[_key3] === 'toString') {
    continue;
  }
  AggregateOperatorMap[AGGREGATE_COMMANDS_LITERAL[_key3]] = `$${AGGREGATE_COMMANDS_LITERAL[_key3]}`;
}
OperatorMap[QUERY_COMMANDS_LITERAL.NEQ] = '$ne';
OperatorMap[UPDATE_COMMANDS_LITERAL.REMOVE] = '$unset';
OperatorMap[UPDATE_COMMANDS_LITERAL.SHIFT] = '$pop';
OperatorMap[UPDATE_COMMANDS_LITERAL.UNSHIFT] = '$push';
OperatorMap[QUERY_COMMANDS_LITERAL.GEO_NEAR] = '$nearSphere';
OperatorMap[QUERY_COMMANDS_LITERAL.GEO_WITHIN] = '$geoWithin';
OperatorMap[QUERY_COMMANDS_LITERAL.GEO_INTERSECTS] = '$geoIntersects';
function operatorToString(operator) {
  return OperatorMap[operator] || `$${operator.toLowerCase()}`;
}
function aggregateOperatorToString(operator) {
  return AggregateOperatorMap[operator] || `$${operator.toLowerCase()}`;
}
;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/serializer/aggregate.ts






class AggregateSerializer {
  static encodeStages(val) {
    var encoder = new AggregateEncoder();
    return encoder.encodeStages(val);
  }
  static encode(val) {
    var encoder = new AggregateEncoder();
    return encoder.encodeAny(val);
  }
}
class AggregateEncoder {
  encodeStages(val) {
    return val.map(v => this.encodePipelineStage(v));
  }
  encodeAny(val) {
    if (isConversionRequired(val)) {
      if (isPipeline(val)) {
        return this.encodePipeline(val);
      } else if (isPipelineStage(val)) {
        return this.encodePipelineStage(val);
      } else if (isAggregateCommand(val)) {
        return this.encodeAggregateCommand(val);
      } else {
        return encodeInternalDataType(val);
      }
    } else if (isObject(val)) {
      return this.encodeObject(val);
    } else if (isArray(val)) {
      return val.map(v => this.encodeAny(v));
    }
    return val;
  }
  encodeObject(val) {
    var res = {};
    for (var key in val) {
      res[key] = this.encodeAny(val[key]);
    }
    return res;
  }
  encodePipeline(pipeline) {
    return pipeline._stages.map(stage => this.encodeAny(stage));
  }
  encodePipelineStage(stage) {
    var $stage = `$${stage.stage}`;
    switch (stage.stage) {
      case 'match':
        {
          return {
            [$stage]: QuerySerializer.encode(stage.val)
          };
        }
      default:
        {
          return {
            [$stage]: this.encodeAny(stage.val)
          };
        }
    }
  }
  encodeAggregateCommand(command) {
    var $op = aggregateOperatorToString(command.operator);
    return {
      [$op]: this.encodeAny(command.operands[0])
    };
  }
}
;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/serializer/query.ts








class QuerySerializer {
  constructor() {}
  static encode(query) {
    return encode(query);
  }
}
var encode = query => {
  if (isLogicCommand(query)) {
    return encodeLogicCommand(query);
  } else if (isQueryCommand(query)) {
    return encodeQueryCommand(query);
  } else if (isPipeline(query) || isAggregateCommand(query) || isPipelineStage(query)) {
    return AggregateSerializer.encode(query);
  } else if (isObject(query)) {
    return encodeQueryObject(query);
  } else {
    return encodeInternalDataType(query);
  }
};
var encodeQueryObject = query => {
  var flattened = flattenQueryObject(query);
  var exps = [];
  var expCount = {
    [LOGIC_COMMANDS_LITERAL.OR]: 0,
    [LOGIC_COMMANDS_LITERAL.NOR]: 0,
    [LOGIC_COMMANDS_LITERAL.AND]: 0,
    [LOGIC_COMMANDS_LITERAL.NOT]: 0
  };
  var _loop = function (key) {
    var value = flattened[key];
    if (isLogicCommand(value)) {
      switch (value.operator) {
        case LOGIC_COMMANDS_LITERAL.OR:
        case LOGIC_COMMANDS_LITERAL.NOR:
        case LOGIC_COMMANDS_LITERAL.AND:
          {
            expCount[value.operator]++;
            exps.push({
              [operatorToString(value.operator)]: value.operands.map(operand => encode({
                [key]: operand
              }))
            });
            break;
          }
        case LOGIC_COMMANDS_LITERAL.NOT:
          {
            var operand = value.operands[0];
            if (isLogicCommand(operand)) {
              switch (operand.operator) {
                case LOGIC_COMMANDS_LITERAL.AND:
                  {
                    expCount[LOGIC_COMMANDS_LITERAL.OR]++;
                    exps.push(encodeLogicCommand(new LogicCommmand(LOGIC_COMMANDS_LITERAL.OR, operand.operands.map(exp => ({
                      [key]: new LogicCommmand(LOGIC_COMMANDS_LITERAL.NOT, [exp])
                    })))));
                    break;
                  }
                case LOGIC_COMMANDS_LITERAL.OR:
                  {
                    expCount[LOGIC_COMMANDS_LITERAL.NOR]++;
                    exps.push(encodeLogicCommand(new LogicCommmand(LOGIC_COMMANDS_LITERAL.NOR, operand.operands.map(exp => ({
                      [key]: exp
                    })))));
                    break;
                  }
                case LOGIC_COMMANDS_LITERAL.NOR:
                  {
                    expCount[LOGIC_COMMANDS_LITERAL.OR]++;
                    exps.push(encodeLogicCommand(new LogicCommmand(LOGIC_COMMANDS_LITERAL.OR, operand.operands.map(exp => ({
                      [key]: exp
                    })))));
                    break;
                  }
                case LOGIC_COMMANDS_LITERAL.NOT:
                  {
                    exps.push(encode({
                      [key]: operand.operands[0]
                    }));
                    break;
                  }
              }
            } else {
              exps.push({
                [key]: encodeLogicCommand(value)
              });
            }
            break;
          }
      }
    } else if (isQueryCommand(value)) {
      exps.push({
        [key]: encodeQueryCommand(value)
      });
    } else {
      exps.push({
        [key]: encodeInternalDataType(value)
      });
    }
  };
  for (var key in flattened) {
    _loop(key);
  }
  return mergeEncodedQueries(exps);
};
var encodeLogicCommand = op => {
  switch (op.operator) {
    case LOGIC_COMMANDS_LITERAL.AND:
      {
        if (op.operands.every(operand => isQueryCommand(operand))) {
          var merged$and = {};
          for (var operand of op.operands) {
            Object.assign(merged$and, encodeQueryCommand(operand));
          }
          return merged$and;
        }
        var $op = operatorToString(op.operator);
        var subqueries = op.operands.map(encode);
        return {
          [$op]: subqueries
        };
      }
    case LOGIC_COMMANDS_LITERAL.OR:
    case LOGIC_COMMANDS_LITERAL.NOR:
      {
        var _$op = operatorToString(op.operator);
        var _subqueries = op.operands.map(encode);
        return {
          [_$op]: _subqueries
        };
      }
    case LOGIC_COMMANDS_LITERAL.NOT:
      {
        var _$op2 = operatorToString(op.operator);
        var _operand = op.operands[0];
        return {
          [_$op2]: encode(_operand)
        };
      }
    default:
      {
        var _$op3 = operatorToString(op.operator);
        var _subqueries2 = op.operands.map(encode);
        return {
          [_$op3]: _subqueries2
        };
      }
  }
};
var encodeQueryCommand = op => {
  var $op = operatorToString(op.operator);
  switch (op.operator) {
    case QUERY_COMMANDS_LITERAL.EQ:
    case QUERY_COMMANDS_LITERAL.NEQ:
    case QUERY_COMMANDS_LITERAL.LT:
    case QUERY_COMMANDS_LITERAL.LTE:
    case QUERY_COMMANDS_LITERAL.GT:
    case QUERY_COMMANDS_LITERAL.GTE:
    case QUERY_COMMANDS_LITERAL.EXISTS:
    case QUERY_COMMANDS_LITERAL.SIZE:
      {
        return {
          [$op]: encodeInternalDataType(op.operands[0])
        };
      }
    case QUERY_COMMANDS_LITERAL.IN:
    case QUERY_COMMANDS_LITERAL.NIN:
    case QUERY_COMMANDS_LITERAL.MOD:
      {
        return {
          [$op]: encodeInternalDataType(op.operands)
        };
      }
    case QUERY_COMMANDS_LITERAL.ALL:
      {
        return {
          [$op]: op.operands.map(encode)
        };
      }
    case QUERY_COMMANDS_LITERAL.ELEM_MATCH:
    case QUERY_COMMANDS_LITERAL.EXPR:
      {
        return {
          [$op]: encode(op.operands[0])
        };
      }
    case QUERY_COMMANDS_LITERAL.GEO_NEAR:
      {
        return {
          [$op]: {
            $geometry: encodeInternalDataType(op.operands[0].geometry),
            $maxDistance: op.operands[0].maxDistance,
            $minDistance: op.operands[0].minDistance
          }
        };
      }
    case QUERY_COMMANDS_LITERAL.GEO_WITHIN:
      {
        var operand = {};
        if (op.operands[0].geometry) {
          operand.$geometry = encodeInternalDataType(op.operands[0].geometry);
        }
        if (op.operands[0].centerSphere) {
          operand.$centerSphere = encodeInternalDataType(op.operands[0].centerSphere);
        }
        return {
          [$op]: operand
        };
      }
    case QUERY_COMMANDS_LITERAL.GEO_INTERSECTS:
      {
        return {
          [$op]: {
            $geometry: encodeInternalDataType(op.operands[0].geometry)
          }
        };
      }
    default:
      {
        return {
          [$op]: op.operands.length > 1 ? op.operands.map(encode) : encode(op.operands[0])
        };
      }
  }
};
var mergeEncodedQueries = queries => {
  var expCount = {
    $and: 0,
    $or: 0,
    $nor: 0
  };
  for (var query of queries) {
    if (query.$and) {
      expCount.$and++;
    }
    if (query.$or) {
      expCount.$or++;
    }
    if (query.$nor) {
      expCount.$nor++;
    }
  }
  var need$and = expCount.$and > 1 || expCount.$or > 1 || expCount.$nor > 1;
  var allIn$and = false;
  var merged = {};
  for (var _query of queries) {
    for (var key in _query) {
      var value = _query[key];
      if (!need$and) {
        merged[key] = value;
      } else {
        if (allIn$and) {
          merged.$and.push(_query);
        } else if (key === '$and' || key === '$or' || key === '$nor') {
          allIn$and = true;
          merged.$and = [_query];
        } else {
          merged[key] = value;
        }
      }
    }
  }
  return merged;
};
;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/serializer/update.ts





class UpdateSerializer {
  constructor() {}
  static encode(query) {
    return update_encode(query);
  }
}
var update_encode = query => {
  return encodeUpdateObject(query);
};
var encodeUpdateObject = query => {
  var flattened = flattenQueryObject(query);
  var encoded = {};
  for (var key in flattened) {
    var value = flattened[key];
    if (isUpdateCommand(value)) {
      var $op = operatorToString(value.operator);
      if (!encoded[$op]) {
        encoded[$op] = {};
      }
      switch (value.operator) {
        case UPDATE_COMMANDS_LITERAL.SET:
        case UPDATE_COMMANDS_LITERAL.INC:
        case UPDATE_COMMANDS_LITERAL.MUL:
        case UPDATE_COMMANDS_LITERAL.MIN:
        case UPDATE_COMMANDS_LITERAL.MAX:
        case UPDATE_COMMANDS_LITERAL.RENAME:
        case UPDATE_COMMANDS_LITERAL.BIT:
          {
            encoded[$op][key] = encodeInternalDataType(value.operands[0]);
            break;
          }
        case UPDATE_COMMANDS_LITERAL.REMOVE:
          {
            encoded[$op][key] = '';
            break;
          }
        case UPDATE_COMMANDS_LITERAL.PUSH:
          {
            var modifiers = void 0;
            if (value.operands.length === 1 && isObject(value.operands[0])) {
              modifiers = {
                $each: value.operands[0].each.map(encodeInternalDataType),
                $position: value.operands[0].position,
                $slice: value.operands[0].slice,
                $sort: value.operands[0].sort
              };
            } else {
              modifiers = {
                $each: value.operands.map(encodeInternalDataType)
              };
            }
            encoded[$op][key] = modifiers;
            break;
          }
        case UPDATE_COMMANDS_LITERAL.UNSHIFT:
          {
            var _modifiers = {
              $each: value.operands.map(encodeInternalDataType),
              $position: 0
            };
            encoded[$op][key] = _modifiers;
            break;
          }
        case UPDATE_COMMANDS_LITERAL.POP:
          {
            encoded[$op][key] = 1;
            break;
          }
        case UPDATE_COMMANDS_LITERAL.SHIFT:
          {
            encoded[$op][key] = -1;
            break;
          }
        case UPDATE_COMMANDS_LITERAL.ADD_TO_SET:
          {
            encoded[$op][key] = isObject(value.operands[0]) && value.operands[0].each ? {
              $each: value.operands[0].each
            } : value.operands[0];
            break;
          }
        case UPDATE_COMMANDS_LITERAL.PULL:
          {
            encoded[$op][key] = QuerySerializer.encode(value.operands[0]);
            break;
          }
        case UPDATE_COMMANDS_LITERAL.PULL_ALL:
          {
            encoded[$op][key] = encodeInternalDataType(value.operands[0]);
            break;
          }
        default:
          {
            encoded[$op][key] = encodeInternalDataType(value.operands[0]);
            break;
          }
      }
    } else {
      if (!encoded.$set) {
        encoded.$set = {};
      }
      encoded.$set[key] = encodeInternalDataType(value);
    }
  }
  return encoded;
};
;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/serializer/projection.ts




class ProjectionSerializer {
  constructor() {}
  static encode(query) {
    var stringifier = new ProjectionSerializer();
    return stringifier.encodeProjection(query);
  }
  encodeProjection(query) {
    if (isProjectionCommand(query)) {
      return this.encodeProjectionCommand(query);
    } else if (type_getType(query) === 'object') {
      return this.encodeProjectionObject(query);
    } else {
      return query;
    }
  }
  encodeProjectionCommand(query) {
    var $op = operatorToString(query.operator);
    switch (query.operator) {
      case PROJECTION_COMMANDS_LITERAL.SLICE:
      default:
        {
          return {
            [$op]: query.operands[0]
          };
        }
    }
  }
  encodeProjectionObject(query) {
    var flattened = flattenQueryObject(query);
    for (var key in flattened) {
      if (flattened[key] === true || flattened[key] === 1) {
        flattened[key] = 1;
      } else if (flattened[key] === false || flattened[key] === 0) {
        flattened[key] = 0;
      } else if (isProjectionCommand(flattened[key])) {
        flattened[key] = this.encodeProjectionCommand(flattened[key]);
      } else {
        delete flattened[key];
      }
    }
    return flattened;
  }
}
;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/serializer/decoder.ts


class Decoder {
  constructor() {}
  static decode(data) {
    var decoder = new Decoder();
    return decoder.decodeData(data);
  }
  decodeData(data) {
    switch (type_getType(data)) {
      case 'object':
        {
          return this.decodeObject(data);
        }
      case 'array':
        {
          return data.map(value => {
            if (isObject(value)) {
              var decoded = decodeInternalDataType(value);
              if (decoded !== value) {
                return decoded;
              }
              return this.decodeObject(value);
            } else return value;
          });
        }
      default:
        {
          return data;
        }
    }
  }
  decodeObject(data) {
    var ret = {
      ...data
    };
    for (var key in ret) {
      var value = ret[key];
      var valueType = type_getType(value);
      switch (valueType) {
        case 'object':
          {
            var decoded = decodeInternalDataType(value);
            if (decoded !== value) {
              ret[key] = decoded;
            } else {
              ret[key] = this.decodeObject(ret[key]);
            }
            break;
          }
        case 'array':
          {
            var _decoded = this.decodeData(value);
            if (_decoded !== value) {
              ret[key] = _decoded;
            }
            break;
          }
        default:
          {
            continue;
          }
      }
    }
    return ret;
  }
}
;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/serializer.ts






;// CONCATENATED MODULE: ./src/services/database/internal/grammar/default/index.ts



;// CONCATENATED MODULE: ./src/services/database/internal/grammar/engine.ts

var ENGINES = /*#__PURE__*/function (ENGINES) {
  ENGINES[ENGINES["DEFAULT"] = 0] = "DEFAULT";
  return ENGINES;
}({});
function getEngine(engine = ENGINES.DEFAULT) {
  switch (engine) {
    default:
      {
        return default_namespaceObject;
      }
  }
}
;// CONCATENATED MODULE: ./src/services/database/api/database.ts







function getDatabase(context, config) {
  var Database = getDatabaseClass(context.identifiers || {});
  return new Database({
    context,
    config
  });
}
/* harmony default export */ const database = (getDatabase);
function getDebug(db) {
  return db.debug;
}
function getQuerySerializer(ctx) {
  return getDebug(ctx.database) ? ctx.engine.QuerySerializer : undefined;
}
function getUpdateSerializer(ctx) {
  return getDebug(ctx.database) ? ctx.engine.UpdateSerializer : undefined;
}
function getProjectionSerializer(ctx) {
  return getDebug(ctx.database) ? ctx.engine.ProjectionSerializer : undefined;
}
function getAggregateSerializer(ctx) {
  return getDebug(ctx.database) ? ctx.engine.AggregateSerializer : undefined;
}
function getDecoder(ctx) {
  return getDebug(ctx.database) ? ctx.engine.Decoder : undefined;
}
var getDatabaseClass = identifiers => {
  var instanceContext;
  var CollectionReference;
  return class Database {
    constructor(options) {
      this.identifiers = void 0;
      this.config = void 0;
      this.command = void 0;
      this.Geo = void 0;
      this.serverDate = void 0;
      this.RegExp = void 0;
      this.__safe_props__ = void 0;
      var {
        config,
        context
      } = options;
      var instance = this;
      this.identifiers = identifiers;
      this.config = config || {};
      instanceContext = {
        database: this,
        serviceContext: context,
        engine: getEngine()
      };
      CollectionReference = getCollectionReferenceClass(instanceContext);
      if (config) {
        if (config.env) {
          assertType(config.env, 'string');
        }
      }
      this.command = commands;
      this.Geo = geo_namespaceObject;
      this.serverDate = serverDate;
      this.RegExp = regExp;
      if (config && config.hasOwnProperty('debug')) {
        Object.defineProperties(this, {
          debug: {
            value: true
          },
          QuerySerializer: {
            enumerable: false,
            configurable: false,
            get() {
              return getQuerySerializer(instanceContext);
            },
            set() {}
          },
          UpdateSerializer: {
            enumerable: false,
            configurable: false,
            get() {
              return getUpdateSerializer(instanceContext);
            },
            set() {}
          },
          ProjectionSerializer: {
            enumerable: false,
            configurable: false,
            get() {
              return getProjectionSerializer(instanceContext);
            },
            set() {}
          },
          AggregateSerializer: {
            enumerable: false,
            configurable: false,
            get() {
              return getAggregateSerializer(instanceContext);
            },
            set() {}
          },
          Decoder: {
            enumerable: false,
            configurable: false,
            get() {
              return getDecoder(instanceContext);
            },
            set() {}
          }
        });
      }
      if (false) {}
    }
    collection(collectionName) {
      return new CollectionReference(collectionName);
    }
    toJSON() {
      return undefined;
    }
  };
};
;// CONCATENATED MODULE: ./src/services/database/api/api.ts

function database_api_api_getAPIs(context) {
  return {
    database: database.bind(null, context)
  };
}
;// CONCATENATED MODULE: ./src/services/database/index.ts

var DATABASE_SERVICE_NAME = 'database';
function createDatabaseService(cloud) {
  var context = {
    name: DATABASE_SERVICE_NAME,
    identifiers: cloud.identifiers,
    request: cloud.request,
    isInstance: cloud.isInstance,
    get debug() {
      return cloud.debug;
    },
    get env() {
      return cloud.getEnvForService(DATABASE_SERVICE_NAME);
    },
    appConfig: {
      get docSizeLimit() {
        return cloud.appConfig.db_doc_size_limit;
      },
      get realtimePingInterval() {
        return cloud.appConfig.db_realtime_ping_interval;
      },
      get realtimePongWaitTimeout() {
        return cloud.appConfig.db_realtime_pong_wait_timeout;
      },
      get realtimeMaxReconnect() {
        return cloud.config.database.realtime.maxReconnect;
      },
      get realtimeReconnectInterval() {
        return cloud.config.database.realtime.reconnectInterval;
      },
      get realtimeTotalConnectionTimeout() {
        return cloud.config.database.realtime.totalConnectionTimeout;
      },
      get realtimeQueryEventCacheTimeout() {
        return cloud.appConfig.db_realtime_query_event_cache_timeout;
      }
    }
  };
  return {
    name: DATABASE_SERVICE_NAME,
    context,
    getAPIs: database_api_api_getAPIs.bind(null, context)
  };
}
function database_registerService(cloud) {
  cloud.registerService(createDatabaseService(cloud));
}
;// CONCATENATED MODULE: ./src/services/utils/api/CloudID.ts

function getCloudIDAPI(context) {
  class CloudID {
    constructor(cloudID) {
      this.cloudID = void 0;
      this._internalType = SYMBOL_CLOUD_ID;
      this.cloudID = cloudID;
      Object.defineProperties(this, {
        _internalType: {
          enumerable: false,
          configurable: false
        }
      });
    }
    toJSON() {
      return this.cloudID;
    }
    toString() {
      return this.cloudID;
    }
  }
  return function (cloudID) {
    return new CloudID(cloudID);
  };
}
;// CONCATENATED MODULE: ./src/services/utils/api/CDN.ts

function getCDNAPI(context) {
  class CDN {
    constructor(target) {
      this.target = void 0;
      this._internalType = symbol_SYMBOL_CDN;
      this.target = target;
      Object.defineProperties(this, {
        _internalType: {
          enumerable: false,
          configurable: false
        }
      });
    }
    toString() {
      return JSON.stringify({
        target: this.target
      });
    }
  }
  return function (target) {
    return new CDN(target);
  };
}
;// CONCATENATED MODULE: ./src/services/utils/api/api.ts


function utils_api_api_getAPIs(context) {
  return {
    CloudID: getCloudIDAPI(context),
    CDN: getCDNAPI(context)
  };
}
;// CONCATENATED MODULE: ./src/services/utils/index.ts

var UTILS_SERVICE_NAME = 'utils';
function utils_createStorageService(cloud) {
  var context = {
    name: UTILS_SERVICE_NAME,
    identifiers: cloud.identifiers,
    request: cloud.request,
    isInstance: cloud.isInstance,
    get debug() {
      return cloud.debug;
    }
  };
  return {
    name: UTILS_SERVICE_NAME,
    context,
    getAPIs: utils_api_api_getAPIs.bind(null, context)
  };
}
function utils_registerService(cloud) {
  cloud.registerService(utils_createStorageService(cloud));
}
;// CONCATENATED MODULE: ./src/services/saas/service.ts
class SaaSService {
  constructor() {}
}
;// CONCATENATED MODULE: ./src/services/saas/gateway/index.ts














var gateway_API_NAME = 'gateway.call';
var urlAlphabet = 'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict';
var nanoid = (size = 21) => {
  var id = '';
  var i = size;
  while (i--) {
    id += urlAlphabet[Math.random() * 64 | 0];
  }
  return id;
};
class GatewayError extends Error {
  constructor(reason, code) {
    super(reason);
    this.errCode = void 0;
    this.errCode = code;
  }
}
var isSecureRuntime = () => getRuntimeInfo().env === 'miniprogram';
function getGateway(context) {
  return options => {
    var gatewayInstance = new GatewayService(Object.assign({
      keepalive: false,
      prefetch: true,
      prefetchOptions: {
        concurrent: 1,
        enableHttp2: false,
        enableQuic: false
      }
    }, options));
    var host = options.domain ? options.domain : `${options.id || options.appid}.preview.wxcloudrun.com`;
    var gatewayPlugin = {
      name: 'gateway-plugin',
      host,
      getMetadata: config => ({
        ...config,
        host
      }),
      beforeRequest: req => req,
      afterRequest: res => res,
      beforeTunnelRequest: req => req,
      afterTunnelRequest: res => res,
      context,
      refreshTunnelInfo: isSecureRuntime() ? /*#__PURE__*/asyncToGenerator_default()(function* () {
        var info = getSystemInfo();
        var result = yield context.request({
          apiName: 'tcbapi_get_service_info',
          serializedReqData: JSON.stringify({
            system: info.system,
            wx_app_version: info.version,
            scene: 3,
            domain: options.domain
          })
        });
        var data = result.data;
        return data;
      }) : undefined
    };
    SaaSServiceMap.set(gatewayInstance, gatewayPlugin);
    gatewayInstance.initGateway();
    (0,dist/* loadAccelerator */.e)(appserviceSdk_getSDK()._WebAssembly);
    return gatewayInstance.exportAPI;
  };
}
class GatewayService extends SaaSService {
  constructor(options) {
    super();
    this.options = options;
    this.session = undefined;
    this.tokenManager = new TokenManager(this.refreshToken.bind(this), nextInterval => Math.max(30 * 1000, nextInterval), token => setReportToken(token, '3'));
    this.exportAPI = void 0;
    this.exportAPI = {
      refresh: this.tokenManager.updateSession.bind(this.tokenManager),
      call: this.call.bind(this)
    };
  }
  refreshToken(session) {
    this.session = session;
    var plugin = SaaSServiceMap.get(this);
    return new Promise((res, rej) => {
      if (plugin.refreshTunnelInfo) {
        plugin.refreshTunnelInfo().then(info => res(info)).catch(err => rej(err));
        return;
      }
      appserviceSdk_getSDK()._requestSkipCheckDomain({
        url: `https://${plugin.host}/__wx__/auth?devtools_ignore=true`,
        method: 'post',
        header: {
          'x-wx-accept-encryption': 3,
          'x-wx-encryption-timestamp': Date.now(),
          'x-wx-lib-build-ts': 1727594124553
        },
        data: JSON.stringify({
          session,
          fingerprint: '',
          timestamp: Date.now(),
          nonce: Math.random()
        }),
        success: ({
          data
        }) => res(data),
        fail: err => {
          rej(err);
        }
      });
    });
  }
  callV2(param) {
    var _this = this;
    return asyncToGenerator_default()(function* () {
      param.stats.protocol = `v2-gw${param.isFallback ? '-fallback' : ''}`;
      var {
        tunnelReqDataType,
        callID
      } = yield processDataPipeParam(param, `v2-${Date.now()}-${nanoid(8)}`);
      var plugin = SaaSServiceMap.get(_this);
      var host = plugin.host;
      param.stats.domain = host;
      param.header = {
        ...param.header,
        'X-WX-HTTP-HOST': host,
        'X-WX-HTTP-PATH': param.path
      };
      param.context.tunnelStartTime = +new Date();
      var {
        result
      } = yield callAndWaitResult(gateway_API_NAME, param, param.data, tunnelReqDataType, callID, plugin.context);
      processProvisionHeader(param, result.header, result.data);
      param.context.tunnelEndTime = +new Date();
      param.stats.statusCode = result.statusCode;
      return {
        ...result,
        callID,
        errMsg: `${gateway_API_NAME}:ok`
      };
    })();
  }
  callV3(param) {
    var _this2 = this;
    return asyncToGenerator_default()(function* () {
      var v3StartTime = Date.now();
      var authorization = _this2.tokenManager.getTokenSync();
      if (!authorization) {
        authorization = yield _this2.tokenManager.getToken();
      }
      param.stats.getServiceEndpoint = Date.now() - v3StartTime;
      var key = new Uint8Array(base64ToArrayBuffer(authorization.key));
      param.stats.protocol = 'v3/unknown';
      var plugin = SaaSServiceMap.get(_this2);
      var host = plugin.host;
      param.stats.domain = host;
      var req = dist.V3.encodeRequest(key, {
        ...param.header,
        'X-WX-TARGET-SERVICE': 'HTTP',
        'X-WX-HTTP-HOST': host,
        'X-WX-HTTP-PATH': param.path
      }, param.method || 'GET', param.data, param.stats);
      param.stats.requestBodyBytes = req.data.byteLength;
      param.stats.requestStartTs = Date.now();
      param.stats.callid = req.callId;
      var promise = new Promise((resolve, reject) => {
        try {
          var _param$enableHttp, _param$enableQuic;
          appserviceSdk_getSDK()._requestSkipCheckDomain({
            url: `https://${host}/__wx__/call?token=${authorization.token}&devtools_ignore=true`,
            method: 'POST',
            header: {
              'X-WX-EV': 3,
              'X-WX-RID': authorization.rid,
              'Content-Type': 'application/octet-stream'
            },
            data: req.data.buffer,
            dataType: 'arraybuffer',
            responseType: 'arraybuffer',
            enableHttp2: (_param$enableHttp = param.enableHttp2) !== null && _param$enableHttp !== void 0 ? _param$enableHttp : true,
            enableQuic: (_param$enableQuic = param.enableQuic) !== null && _param$enableQuic !== void 0 ? _param$enableQuic : true,
            timeout: param.timeout,
            success: res => {
              if (!param.stats) param.stats = {};
              param.stats.requestSuccessTs = Date.now();
              param.stats.profile = res.profile;
              param.stats.httpRequest = Date.now() - param.stats.requestStartTs;
              var handleExpiredToken = error => {
                if (!param.isRetry) {
                  authorization.invalidate().then(() => {
                    _this2.call({
                      ...param,
                      isRetry: true
                    }).then(resolve).catch(reject);
                  }).catch(reject);
                  return;
                }
                reject(error);
              };
              try {
                processProvisionHeader(param, res.header, res.data);
              } catch (error) {
                if (error.code === 85104) {
                  handleExpiredToken(error);
                } else {
                  if (error.code) {
                    param.stats.ret = error.code;
                  }
                  reject(error);
                }
                return;
              }
              if (res.statusCode && res.statusCode !== 200) {
                var _body = decodeUnknownArrayBuffer(res.data);
                reject(new GatewayError(`${gateway_API_NAME}: fail invalid status code ${_body}, status code: ${res.statusCode}, callid: ${param.stats.callid}`, res.statusCode === 404 ? 404 : -9999));
                return;
              }
              var resData = new Uint8Array(res.data);
              req.stats.responseBodyBytes = resData.byteLength;
              var {
                header: decodedHeader,
                body: decodedBody,
                statusCode
              } = dist.V3.decodeResponse(key, resData, param.stats);
              try {
                processProvisionHeader(param, decodedHeader, decodedBody);
              } catch (error) {
                if (error.code === 85104) {
                  handleExpiredToken(error);
                } else {
                  if (error.code) {
                    param.stats.ret = error.code;
                  }
                  reject(error);
                }
                return;
              }
              var body = processResponse(param, decodedBody, statusCode);
              param.stats.protocol = `v3/${param.stats.backend}`;
              param.stats.responseProcessEndTs = Date.now();
              param.stats.statusCode = statusCode;
              resolve({
                data: body,
                statusCode,
                header: decodedHeader,
                callID: req.callId,
                errMsg: `${gateway_API_NAME}:ok`,
                stats: param.stats
              });
            },
            fail: err => reject({
              ...err,
              errCode: -9999,
              errMsg: err.errMsg.replace(/^request/, gateway_API_NAME)
            })
          });
          deferKeepAlive(`${host}/__wx__/keepalive`);
        } catch (err) {
          reject({
            ...err,
            errCode: -9999,
            errMsg: err.errMsg.replace(/^request/, gateway_API_NAME)
          });
        }
      });
      return promise;
    })();
  }
  initGateway() {
    this.tokenManager.getToken();
    var plugin = SaaSServiceMap.get(this);
    var host = plugin.host;
    var keepAliveUrl = `${host}/__wx__/keepalive`;
    if (this.options.keepalive) {
      addKeepAliveHost(keepAliveUrl);
      _keepAlive(false);
    }
    if (this.options.prefetch) {
      var _this$options$prefetc, _this$options$prefetc2;
      var concurrent = (_this$options$prefetc = (_this$options$prefetc2 = this.options.prefetchOptions) === null || _this$options$prefetc2 === void 0 ? void 0 : _this$options$prefetc2.concurrent) !== null && _this$options$prefetc !== void 0 ? _this$options$prefetc : 0;
      for (var i = 0; i < concurrent; i++) {
        appserviceSdk_getSDK()._requestSkipCheckDomain({
          url: `https://${keepAliveUrl}?devtools_ignore=true`,
          ...this.options.prefetchOptions
        });
      }
    }
  }
  call(param) {
    var _this3 = this;
    return asyncToGenerator_default()(function* () {
      var startTime = Date.now();
      param.path = param.path || param.url || '';
      processParam(param);
      var plugin = SaaSServiceMap.get(_this3);
      var callParams = {
        ...param,
        stats: {
          apiStartTime: startTime
        },
        context: {
          apiStartTime: startTime
        }
      };
      var token = _this3.tokenManager.getTokenSync();
      var promise;
      if (callParams.apiVersion === 2 || callParams.apiVersion !== 3 && !token) {
        promise = _this3.callV2(callParams).catch(e => {
          if (e.type === DATA_PIPE_SIZE_LIMIT_ERROR) {
            callParams.stats.errMsg = 'V2_DATA_TOO_LARGE';
            return _this3.callV3({
              ...callParams,
              apiVersion: 3
            });
          }
          callParams.stats.errMsg = e.message || toStr(e);
          callParams.stats.errCode = 1002;
          throw e;
        });
      } else {
        promise = _this3.callV3(callParams).catch(e => {
          if ((e === null || e === void 0 ? void 0 : e.errCode) === -9999) {
            callParams.stats.errMsg = e.message || toStr(e) || '';
            return _this3.callV2({
              ...callParams,
              isFallback: true
            }).catch(e => {
              callParams.stats.errMsg += ' v2 err: ' + (e.message || toStr(e));
              callParams.stats.errCode = 1001;
              throw e;
            });
          }
          callParams.stats.errMsg = e.message || toStr(e);
          callParams.stats.errCode = 1003;
          throw e;
        });
      }
      promise = followRedirect(param, promise, _this3.call.bind(_this3), plugin.context, gateway_API_NAME);
      promise.then(() => {
        callParams.stats.errCode = 0;
        reportCallContainerLike(gateway_API_NAME, callParams);
      }).catch(err => {
        if (!callParams.stats.errCode) {
          var _err$errCode;
          callParams.stats.errCode = (_err$errCode = err.errCode) !== null && _err$errCode !== void 0 ? _err$errCode : -1;
        }
        if (!callParams.stats.errMsg) {
          var _err$message;
          callParams.stats.errMsg = (_err$message = err.message) !== null && _err$message !== void 0 ? _err$message : 'system error';
        }
        reportCallContainerLike(gateway_API_NAME, callParams);
      });
      autoDevtoolsNetworkLog(promise, () => ({
        url: `gateway.call${param.path}`,
        method: param.method,
        headers: param.header,
        reqBody: serialize(param.data),
        timestampMs: startTime
      }));
      var res = undefined;
      try {
        var _param$success;
        res = yield promise;
        (_param$success = param.success) === null || _param$success === void 0 ? void 0 : _param$success.call(param, res);
        return res;
      } catch (error) {
        res = error;
        if (param.fail) {
          var _param$fail;
          (_param$fail = param.fail) === null || _param$fail === void 0 ? void 0 : _param$fail.call(param, error);
        } else {
          throw error;
        }
      } finally {
        var _param$complete;
        (_param$complete = param.complete) === null || _param$complete === void 0 ? void 0 : _param$complete.call(param, res);
      }
    })();
  }
}
function decodeUnknownArrayBuffer(body) {
  if (body instanceof ArrayBuffer) {
    try {
      return arrayBufferToString(body);
    } catch (e) {}
  }
  if (typeof body === 'string') {
    return body;
  }
  return toStr(body);
}
function processProvisionHeader(param, header, body) {
  if (header['x-wx-system-error']) {
    var code = +header['x-wx-system-error'];
    body = decodeUnknownArrayBuffer(body);
    throw new GatewayError(`${gateway_API_NAME}: fail wx system error ${body}, code: ${code}, callid: ${param.stats.callid}`, code);
  }
  if (header['x-wx-server-timing']) {
    var serverTiming = header['x-wx-server-timing'] || '';
    var rawNumStrs = serverTiming.split(',');
    if (rawNumStrs.length >= 2) {
      param.stats.serverStartTs = Number(rawNumStrs[0]);
      param.stats.serverEndTs = Number(rawNumStrs[1]);
    }
  }
  if (header['x-envoy-upstream-service-time']) {
    var upstreamCost = +header['x-envoy-upstream-service-time'];
    if (!isNaN(upstreamCost)) {
      param.stats.upstreamCost = upstreamCost;
    }
  }
  if (header['x-wx-mesh-upstream-service-time']) {
    var _serverTiming = header['x-wx-mesh-upstream-service-time'];
    var _rawNumStrs = _serverTiming.split(',');
    if (_rawNumStrs.length >= 2) {
      param.stats.meshStartTs = Number(_rawNumStrs[0]);
      param.stats.meshEndTs = Number(_rawNumStrs[1]);
    }
  }
}
;// CONCATENATED MODULE: ./src/services/saas/api.ts

function saas_api_getAPIs(context) {
  return {
    Gateway: {
      initRequired: false,
      fn: getGateway(context)
    }
  };
}
;// CONCATENATED MODULE: ./src/services/saas/index.ts

var SAAS_SERVICE_NAME = 'services';
var SaaSServiceMap = new WeakMap();
function getContext(cloud) {
  var context = {
    name: SAAS_SERVICE_NAME,
    identifiers: cloud.identifiers,
    request: cloud.request,
    isInstance: cloud.isInstance,
    get debug() {
      return cloud.debug;
    },
    get appid() {
      return cloud.instanceOptions.appid;
    },
    appConfig: {}
  };
  return context;
}
function createSaasService(cloud) {
  var context = getContext(cloud);
  return {
    name: SAAS_SERVICE_NAME,
    context,
    getAPIs: saas_api_getAPIs.bind(null, context)
  };
}
function registerSaaSService(cloud) {
  var service = createSaasService(cloud);
  cloud.registerService(service, 'services');
}
;// CONCATENATED MODULE: ./src/services/index.ts






function registerServices(cloud) {
  registerService(cloud);
  storage_registerService(cloud);
  database_registerService(cloud);
  utils_registerService(cloud);
  container_registerService(cloud);
  registerSaaSService(cloud);
}
;// CONCATENATED MODULE: ./src/runtime/app/polyfill-sdk/utils.ts
function callbackSuccessComplete(opts, res) {
  opts.success && opts.success(res);
  opts.complete && opts.complete(res);
  opts.success = undefined;
  opts.complete = undefined;
}
function callbackFailComplete(opts, res) {
  opts.fail && opts.fail(res);
  opts.complete && opts.complete(res);
  opts.fail = undefined;
  opts.complete = undefined;
}
function formatHeader(xhr) {
  var headers = xhr.getAllResponseHeaders();
  var arr = headers.trim().split(/[\r\n]+/);
  var headerMap = {};
  arr.forEach(line => {
    var parts = line.split(': ');
    var header = parts.shift();
    var value = parts.join(': ');
    headerMap[header] = value;
  });
}
;// CONCATENATED MODULE: ./src/runtime/app/polyfill-sdk/saaaDataPipe.ts


var sendSaaADataPipeFn;
var sendSaaADataPipe = opt => {
  if (!sendSaaADataPipeFn) {
    sendSaaADataPipeFn = getSendSaaADataPipeFn();
  }
  try {
    sendSaaADataPipeFn(opt);
  } catch (err) {
     false && 0;
    callbackFailComplete(opt, err);
  }
};
function getSendSaaADataPipeFn() {
  var __AppServiceSDK__ = appserviceSdk_getSDK();
  var {
    operateSaaADataFactory
  } = __AppServiceSDK__;
  var transReqArgs = reqOpt => reqOpt.reqData;
  var transSuccessArgs = resData => ({
    data: resData,
    rawData: JSON.stringify(resData)
  });
  var transFailArgs = err => {
    if (err.errMsg) {
      err.errMsg = err.errMsg.replace('sendSaaADataPipe:fail', 'operateWXData:fail');
      return {
        errMsg: `${err.errMsg}.errCode: ${err.errCode || -1}`
      };
    }
    return err;
  };
  return operateSaaADataFactory('', 'qbase_commapi', transReqArgs, transSuccessArgs, transFailArgs);
}
;// CONCATENATED MODULE: ./src/runtime/app/patch-sdk.ts


var polyfillOperateWXData = sendSaaADataPipe;
var patch = {
  _operateWXData: polyfillOperateWXData,
  invokeOperateWXData: polyfillOperateWXData
};
function patchAppSDK() {
  patchDefaultSDK(patch);
}
;// CONCATENATED MODULE: ./src/runtime/app/index.ts


;// CONCATENATED MODULE: ./src/config/app.config.ts
var serverConfigurable = {
  db_doc_size_limit: 512 * 1024,
  db_realtime_ping_interval: 15 * 1000,
  db_realtime_pong_wait_timeout: 15 * 1000,
  db_realtime_query_event_cache_timeout: 3 * 60 * 1000,
  upload_max_file_size: 20 * 1024 * 1024,
  get_temp_file_url_max_requests: 50,
  call_function_poll_max_retry: 10,
  call_function_max_req_data_size: 5 * 1024 * 1024,
  call_function_client_poll_timeout: 15 * 1000,
  call_function_valid_start_retry_gap: 60 * 1000,
  call_container_poll_max_retry: 10,
  call_container_client_poll_timeout: 15 * 1000,
  call_container_valid_start_retry_gap: 60 * 1000,
  call_container_max_req_data_size: 5 * 1024 * 1024,
  call_container_use_private_http: 0,
  rpm_per_client_limit: 1000
};
var clientConfigDefaults = {
  REALTIME_DB_MAX_RECONNECT: 5,
  REALTIME_DB_WS_RECONNECT_INTERVAL: 5 * 1000,
  REALTIME_DB_TOTAL_CONNECTION_TIMEOUT: Infinity
};
/* harmony default export */ const app_config = (serverConfigurable);
;// CONCATENATED MODULE: ./src/services/obs/index.ts
var setup = (...args) => {
  var _appServiceSDK__;
  return (_appServiceSDK__ = __appServiceSDK__) === null || _appServiceSDK__ === void 0 ? void 0 : _appServiceSDK__.setup(...args);
};
var asyncSetup = (...args) => {
  var _appServiceSDK__2;
  return (_appServiceSDK__2 = __appServiceSDK__) === null || _appServiceSDK__2 === void 0 ? void 0 : _appServiceSDK__2.asyncSetup(...args);
};
var setAttrs = (...args) => {
  var _appServiceSDK__3;
  return (_appServiceSDK__3 = __appServiceSDK__) === null || _appServiceSDK__3 === void 0 ? void 0 : _appServiceSDK__3.setAttrs(...args);
};
var teardown = (...args) => {
  var _appServiceSDK__4;
  return (_appServiceSDK__4 = __appServiceSDK__) === null || _appServiceSDK__4 === void 0 ? void 0 : _appServiceSDK__4.teardown(...args);
};
var emitEvent = (...args) => {
  var _appServiceSDK__5;
  return (_appServiceSDK__5 = __appServiceSDK__) === null || _appServiceSDK__5 === void 0 ? void 0 : _appServiceSDK__5.emitEvent(...args);
};
var getStatus = (...args) => {
  var _appServiceSDK__6;
  return (_appServiceSDK__6 = __appServiceSDK__) === null || _appServiceSDK__6 === void 0 ? void 0 : _appServiceSDK__6.getStatus(...args);
};
/* harmony default export */ const obs = ({
  setup,
  asyncSetup,
  setAttrs,
  teardown,
  emitEvent,
  getStatus
});
// EXTERNAL MODULE: ../../node_modules/.pnpm/lodash@4.17.15/node_modules/lodash/lodash.js
var lodash = __webpack_require__(424);
;// CONCATENATED MODULE: ./src/services/saas/gateway/middleware.ts






var DEBUG = false;
function reportRequestFailWithCallID(url, err, stats) {
  DEBUG && console.log('will report fail callid', stats.callid, 'err', err);
  stats.errMsg = err === null || err === void 0 ? void 0 : err.message;
  stats.errCode = -1;
  reportWxRequest({
    stats,
    path: url
  });
}
function reportRequestSuccessWithCallID(_x, _x2, _x3) {
  return _reportRequestSuccessWithCallID.apply(this, arguments);
}
function _reportRequestSuccessWithCallID() {
  _reportRequestSuccessWithCallID = asyncToGenerator_default()(function* (url, profile, stats) {
    stats.responseProcessEndTs = Date.now();
    yield Promise.resolve();
    DEBUG && console.log('will report request callid', stats.callid, 'profile', profile);
    stats.profile = profile;
    reportWxRequest({
      stats,
      path: url
    });
  });
  return _reportRequestSuccessWithCallID.apply(this, arguments);
}
function camelCaseDeep(obj) {
  if (!(0,lodash.isPlainObject)(obj)) {
    return obj;
  }
  var processedObj = (0,lodash.mapValues)(obj, value => camelCaseDeep(value));
  return (0,lodash.mapKeys)(processedObj, (value, key) => (0,lodash.camelCase)(key));
}
function getGatewayConf(wxConfig) {
  DEBUG && console.log('cloud-sdk: we are checking gateway conf', wxConfig);
  return camelCaseDeep((0,lodash.get)(wxConfig, 'appContactInfo.wxcloud_gateway_conf') || (0,lodash.get)(wxConfig, 'appContactInfo.stablePassThroughInfo.wxcloud_gateway_conf'));
}
var __GatewayMiddlewareInstance;
var __ParsedGatewayConf;
function getRequestMiddleware(WXConfig) {
  if (!__ParsedGatewayConf) {
    __ParsedGatewayConf = getGatewayConf(WXConfig);
  }
  var gatewayConf = __ParsedGatewayConf;
  var isDevelop = WXConfig.envVersion === 'develop' || WXConfig.envVersion === 'trial';
  DEBUG && console.log('cloud-sdk: parsed gateway conf', gatewayConf);
  return param => {
    DEBUG && console.log('cloud-sdk: entered request middleware');
    DEBUG && console.log('cloud-sdk: param', param);
    var getCommonGatewayParam = param => ({
      header: {
        ...param.header,
        'X-WX-HTTP-MODE': 'REROUTE'
      },
      path: param.url,
      enableHttp2: gatewayConf === null || gatewayConf === void 0 ? void 0 : gatewayConf.enableHttp2,
      enableQuic: gatewayConf === null || gatewayConf === void 0 ? void 0 : gatewayConf.enableQuic
    });
    if (typeof gatewayConf !== 'undefined') {
      var _gatewayConf$urlPrefi;
      if (!gatewayConf.enabled) return;
      if (gatewayConf.envVersion && gatewayConf.envVersion !== 'any') {
        if (WXConfig.envVersion !== gatewayConf.envVersion) {
          return;
        }
      }
      if (!__GatewayMiddlewareInstance) {
        var cloudInstance = getCloudInstance();
        var context = getContext(cloudInstance);
        __GatewayMiddlewareInstance = saas_api_getAPIs(context).Gateway.fn({
          ...gatewayConf
        });
        isDevelop && console.log('%c [Donut 安全网关]', 'color:green', '网关配置获取成功', gatewayConf);
      }
      if ((_gatewayConf$urlPrefi = gatewayConf.urlPrefixes) !== null && _gatewayConf$urlPrefi !== void 0 && _gatewayConf$urlPrefi.some(prefix => param.url.startsWith(prefix))) {
        var userSuccess = param.success;
        var userFail = param.fail;
        var userComplete = param.complete;
        isDevelop && console.log('%c [Donut 安全网关]', 'color:green', '请求数据加密保护中', {
          header: param.header,
          data: param.data,
          url: param.url,
          dataType: param.dataType,
          method: param.method
        });
        if (gatewayConf.accessMode === 0) {
          var requestProfile;
          var stats = {};
          __GatewayMiddlewareInstance.call({
            data: param.data,
            ...param,
            ...getCommonGatewayParam(param),
            success: undefined,
            fail: undefined,
            complete: undefined
          }).then(res => {
            DEBUG && console.log('[cgw] dry-run gateway.call success at', Date.now());
            stats.callid = res.callID;
            if (requestProfile) reportRequestSuccessWithCallID(param.url, requestProfile, stats);
          }).catch(() => {
            DEBUG && console.log('[cgw] dry-run gateway.call failed at', Date.now());
            if (requestProfile) reportRequestSuccessWithCallID(param.url, requestProfile, stats);
          });
          stats.requestStartTs = Date.now();
          param.success = res => {
            stats.requestSuccessTs = Date.now();
            userSuccess === null || userSuccess === void 0 ? void 0 : userSuccess(res);
            DEBUG && console.log('[cgw] wx.request success at', Date.now());
            requestProfile = res.profile;
            if (stats.callid) reportRequestSuccessWithCallID(param.url, res.profile, stats);
          };
          param.fail = err => {
            userFail === null || userFail === void 0 ? void 0 : userFail(err);
            DEBUG && console.log('[cgw] wx.request fail, err report', err);
            reportRequestFailWithCallID(param.url, err, stats);
          };
          return;
        }
        return new Promise((res, rej) => {
          var _param$data;
          __GatewayMiddlewareInstance.call({
            data: (_param$data = param.data) !== null && _param$data !== void 0 ? _param$data : undefined,
            ...param,
            ...getCommonGatewayParam(param),
            success: undefined,
            fail: undefined,
            complete: undefined
          }).then(res => {
            DEBUG && console.log('[cgw]non dry-run: gateway call success', res);
            isDevelop && console.log('%c [Donut 安全网关] 请求成功', 'color:green', res);
            param.success = undefined;
            param.complete = undefined;
            param.fail = undefined;
            rej('cloud-sdk gateway proxy cancelled request, ignore');
            userSuccess === null || userSuccess === void 0 ? void 0 : userSuccess(res);
            userComplete === null || userComplete === void 0 ? void 0 : userComplete(res);
          }).catch(err => {
            isDevelop && console.log('%c [Donut 安全网关] %c 网关请求失败，回退至 request', 'color:green', 'color:red', (err === null || err === void 0 ? void 0 : err.message) || '未知错误');
            DEBUG && console.log('[cgw] convert request to gateway failed', err);
            return res();
          });
        });
      }
    }
    return;
  };
}
;// CONCATENATED MODULE: ./src/cloud/index.ts




















var envInited = {};
var getCloudInstance = (options = {}) => {
  var {
    sdk
  } = options;
  var identifiers = options.identifiers || {};
  if (sdk) {
    setSDK(identifiers, sdk);
  }
  var cloudInstance = new DefaultCloud(identifiers, false);
  return cloudInstance;
};
var getCloudAPI = (options = {}) => {
  return getCloudInstance(options).exportAPI;
};

var cloud_keepalive_ = false;
class DefaultCloud {
  constructor(identifiers, isInstance) {
    var _this = this;
    this.inited = false;
    this.isInstance = void 0;
    this.services = {};
    this.apiServiceMap = {};
    this.plugins = [];
    this.meta = void 0;
    this.config = void 0;
    this.identifiers = void 0;
    this.debug = false;
    this.request = void 0;
    this.exportAPI = void 0;
    this.appConfig = void 0;
    this.apiPermissions = void 0;
    this.runtimeInfo = void 0;
    this.serviceEndpoint = void 0;
    this.authStorage = void 0;
    this.testSpeed = /*#__PURE__*/asyncToGenerator_default()(function* () {
      var apiStartTime = +new Date();
      var tunnelStartTime = apiStartTime;
      var req = constructTunnelReq({
        cloud: _this,
        apiName: 'tcbapi_testspeed',
        serializedReqData: ''
      });
      return tunnel(req, {
        fireOnIdle: true,
        onFire: () => {
          apiStartTime = +new Date();
          tunnelStartTime = apiStartTime;
          if (false) {}
        }
      }).then(res => {
        if (false) {}
        reportAPISpeed({
          apiName: 'cloud.testspeed',
          apiEndTime: +new Date(),
          apiStartTime,
          tunnelEndTime: +new Date(),
          tunnelStartTime,
          tunnelTimeNoCSNetCost: res.data.baseresponse.stat.qbase_cost_time
        });
        if (false) {}
      }).catch(err => {
        if (false) {}
      });
    });
    this.identifiers = identifiers;
    this.isInstance = isInstance;
    this.runtimeInfo = getRuntimeInfo();
    this.serviceEndpoint = new ServiceEndpoint(identifiers);
    this.request = getBoundTunnelRequest({
      cloud: this
    });
    var that = this;
    this.exportAPI = {
      init: this.init.bind(this),
      obs: obs
    };
    if (!this.isInstance) {
      this.exportAPI.Cloud = function (options) {
        var instance = new InstanceCloud(identifiers, that, options);
        return instance.exportAPI;
      };
    }
    if (false) {}
    registerServices(this);
    this.meta = {
      session_id: Date.now() + ''
    };
    this.serviceEndpoint.setMetaData(this.getMetaData());
    this.serviceEndpoint.setTunnelRequest(this.request);
    this.config = {
      database: getDefaultDatabaseGlobalConfig()
    };
    this.appConfig = {
      ...app_config
    };
    this.apiPermissions = {};
    try {
      var _WXConfig$onReady;
      (_WXConfig$onReady = wxconfig.onReady) === null || _WXConfig$onReady === void 0 ? void 0 : _WXConfig$onReady.call(wxconfig, () => {
        setTimeout(() => {
          init();
        }, 2000);
        getUA();
      });
      if (false) {}
    } catch (err) {}
  }
  getMetaData() {
    var _WXConfig$appLaunchIn2;
    if (!this.meta.sdk_version) {
      var sdk = appserviceSdk_getSDK(this.identifiers);
      if (sdk) {
        var wx = sdk.wx;
        if (wx && wx.version) {
          if (this.runtimeInfo.env === 'miniprogram') {
            this.meta.sdk_version = `wx-miniprogram-sdk/${wx.version.version} (${Date.parse(`${wx.version.updateTime} GMT+0800`)} platform/${this.runtimeInfo.platform}})`;
          } else {
            this.meta.sdk_version = `wx-app-sdk/2.19.2 (20220822.0)`;
          }
        }
      }
      wxconfig.onReady(() => {
        var _WXConfig$appLaunchIn;
        this.meta.filter_user_info = ((_WXConfig$appLaunchIn = wxconfig.appLaunchInfo) === null || _WXConfig$appLaunchIn === void 0 ? void 0 : _WXConfig$appLaunchIn.mode) === 'singlePage';
      });
    }
    this.meta.filter_user_info = ((_WXConfig$appLaunchIn2 = wxconfig.appLaunchInfo) === null || _WXConfig$appLaunchIn2 === void 0 ? void 0 : _WXConfig$appLaunchIn2.mode) === 'singlePage';
    return this.meta;
  }
  getConfig() {
    return this.config;
  }
  getEnvForService(service) {
    if (this.isInstance) {
      return this.instanceOptions.resourceEnv;
    }
    var config = this.config;
    if (!config.env) return;
    switch (type_getType(config.env)) {
      case 'string':
        {
          return config.env;
        }
      case 'object':
        {
          return config.env[service];
        }
      default:
        {
          return;
        }
    }
  }
  checkAPIPermission(apiName) {
    if (this.apiPermissions.hasOwnProperty(apiName)) {
      if (this.apiPermissions[apiName] === 1) {
        return true;
      } else return false;
    } else {
      return true;
    }
  }
  init(config = {}) {
    this.inited = true;
    this.initConfig(config);
    try {
      privateGetBackgroundFetchData(500, this.identifiers);
    } catch (e) {
      _wxConsole === null || _wxConsole === void 0 ? void 0 : _wxConsole.log('privateGetBackgroundFetchData error', e);
    }
    return Promise.all([this.sendInitRequest().then(() => {
      if (Math.random() < 0.1) {
        this.testSpeed();
      }
    })]).then(() => {});
  }
  initConfig(config) {
    this.config = JSON.parse(JSON.stringify(config));
    this.plugins = (config.plugins || []).map(instance => SaaSServiceMap.get(instance)).filter(x => !!x);
    if (!this.config.database) {
      this.config.database = getDefaultDatabaseGlobalConfig();
    } else {
      this.config.database = utils_merge(this.config.database, getDefaultDatabaseGlobalConfig());
    }
    if (this.runtimeInfo.platform === 'sdk') {
      patchAppSDK();
      if (!config.appid) {
        console.warn('多端模式下使用云开发，wx.cloud.init 需要传入 appid, 具体可参考文档 https://dev.weixin.qq.com/docs/framework/dev/cloud ');
      }
    }
  }
  sendInitRequest() {
    var _this2 = this;
    return asyncToGenerator_default()(function* () {
      var env = typeof _this2.config.env === 'string' ? _this2.config.env : undefined;
      var serializedReqData = JSON.stringify({
        trace_user: _this2.config.traceUser === false ? false : true,
        env,
        region: _this2.config.region
      });
      var apiStartTime = +new Date();
      var tunnelStartTime = apiStartTime;
      try {
        var resData = envInited[env || ''];
        var hasEnvInited = Boolean(resData);
        if (!resData) {
          var res = yield _this2.request({
            ..._this2.config,
            apiName: 'tcbapi_init',
            serializedReqData,
            env
          });
          resData = res.data;
          envInited[env || ''] = resData;
        }
        var tunnelEndTime = +new Date();
        _this2.appConfig = {
          ..._this2.appConfig,
          ...resData.config
        };
        limiter.updateLimit(_this2.appConfig.rpm_per_client_limit);
        var list = resData.tcb_api_list || [];
        for (var i = 0, imax = list.length; i < imax; i++) {
          _this2.apiPermissions[list[i].apiname] = list[i].status;
        }
        if (!hasEnvInited) {
          reportAPISpeed({
            apiName: 'cloud.init',
            apiEndTime: +new Date(),
            apiStartTime,
            tunnelEndTime,
            tunnelStartTime,
            tunnelTimeNoCSNetCost: resData.baseresponse.stat.qbase_cost_time
          });
        }
      } catch (err) {
        console.error('cloud init error: ', err);
      }
    })();
  }
  registerService(service, path) {
    this.services[service.name] = service;
    var apis = service.getAPIs();
    for (var name in apis) {
      this.apiServiceMap[name] = service.name;
      if (typeof apis[name] === 'function') {
        this.registerFunction(name, true, apis[name], path);
      } else {
        var {
          initRequired,
          fn
        } = apis[name];
        this.registerFunction(name, initRequired, fn, path);
      }
    }
  }
  registerFunction(name, initRequired, func, path) {
    var instance = this;
    var target = this.exportAPI;
    if (path) {
      this.exportAPI[path] = {};
      target = this.exportAPI[path];
    }
    if (initRequired) {
      target[name] = function () {
        if (!instance.inited) {
          throw new error_CloudSDKError({
            errMsg: `Cloud API isn't enabled, please call wx.cloud.init first\n` + `请先调用 wx.cloud.init() 完成初始化后再调用其他云 API。`
          });
        }
        if (!instance.checkAPIPermission(name)) {
          throw new error_CloudSDKError({
            errCode: error_config_ERR_CODE.SDK_API_PERMISSION_DENIED,
            errMsg: error_config_ERR_CODE[error_config_ERR_CODE.SDK_API_PERMISSION_DENIED]
          });
        }
        return func.apply(instance, arguments);
      };
    } else {
      target[name] = func;
    }
  }
  toJSON() {
    return undefined;
  }
}
class InstanceCloud extends DefaultCloud {
  constructor(identifiers, defaultInstance, instanceOptions) {
    super(identifiers, true);
    this.defaultInstance = void 0;
    this.instanceOptions = void 0;
    this.webRequest = void 0;
    this._webCurrentRefreshTokenPromise = void 0;
    if (this.runtimeInfo.env === 'web') {
      if (!instanceOptions.identityless && !instanceOptions.appid) {
        throw new Error(`appid must be provided`);
      }
      if (!instanceOptions.resourceAppid) {
        throw new Error(`resourceAppid must be provided`);
      }
    }
    if (!instanceOptions.resourceEnv) {
      throw new Error(`resourceEnv must be provided`);
    }
    if (!instanceOptions.config) {
      instanceOptions.config = {};
    }
    this.defaultInstance = defaultInstance;
    this.instanceOptions = JSON.parse(JSON.stringify(instanceOptions));
    this.meta = defaultInstance.meta;
    this.apiPermissions = defaultInstance.apiPermissions;
    this.instanceOptions.config.database = utils_merge(getDefaultDatabaseGlobalConfig(), this.instanceOptions.config.database || {});
    if (this.runtimeInfo.env === 'web') {
      this.exportAPI.init = this.webInit.bind(this);
      this.webRequest = (0,external_namespaceObject.getBoundAuthRequest)(this);
      this.registerService((0,external_namespaceObject.createWebService)(this));
      if (!this.instanceOptions.identityless) {
        this.authStorage = this.defaultInstance.authStorage;
        if (!this.authStorage) {
          throw new Error(`authStorage not found`);
        }
      }
    } else {
      this.exportAPI.init = this.miniprogramInit.bind(this);
    }
    if (this.instanceOptions.resourceAppid) {
      this.exportAPI.refreshAuth = this.refreshAuth.bind(this);
    }
  }
  miniprogramInit() {
    var _superprop_getInit = () => super.init,
      _this3 = this;
    return asyncToGenerator_default()(function* () {
      if (_this3.inited) return;
      if (_this3.instanceOptions.resourceAppid) {
        var r = yield _this3.refreshAuth();
        var authInfo = r.data.env_auth_info;
        if (authInfo.errCode === 0) {
          _superprop_getInit().call(_this3);
          return {
            errCode: authInfo.errCode,
            errMsg: authInfo.errMsg,
            expireTime: authInfo.expire_time * 1000
          };
        } else {
          return {
            errCode: authInfo.errCode,
            errMsg: authInfo.errMsg
          };
        }
      }
      _superprop_getInit().call(_this3);
    })();
  }
  webInit() {
    var _superprop_getInit2 = () => super.init,
      _this4 = this;
    return asyncToGenerator_default()(function* () {
      if (_this4.inited) return;
      if (!_this4.instanceOptions.identityless) {
        var r = yield _this4.refreshAuth();
        var authInfo = r.data.env_auth_info;
        if (authInfo.errCode === 0) {
          _this4.sendInitRequest().then(() => {
            _this4.testSpeed();
          });
          _superprop_getInit2().call(_this4);
          return {
            errCode: authInfo.errCode,
            errMsg: authInfo.errMsg,
            expireTime: authInfo.expire_time * 1000
          };
        } else {
          return {
            errCode: authInfo.errCode,
            errMsg: authInfo.errMsg
          };
        }
      }
      _this4.inited = true;
    })();
  }
  webRefreshToken() {
    var _this5 = this;
    return asyncToGenerator_default()(function* () {
      if (_this5._webCurrentRefreshTokenPromise) return _this5._webCurrentRefreshTokenPromise;
      _this5._webCurrentRefreshTokenPromise = new Promise(/*#__PURE__*/function () {
        var _ref2 = asyncToGenerator_default()(function* (resolve, reject) {
          try {
            var result = yield _this5.webRequest({
              url: `/refresh_token`,
              method: 'POST',
              json: {
                appid: _this5.instanceOptions.appid,
                refresh_token: _this5.authStorage.getItem('refreshToken')
              }
            });
            var data = result.data;
            _this5.authStorage.setItem('appid', data.access_token);
            resolve();
          } catch (e) {
            reject(e);
          } finally {
            _this5._webCurrentRefreshTokenPromise = undefined;
          }
        });
        return function (_x, _x2) {
          return _ref2.apply(this, arguments);
        };
      }());
      return _this5._webCurrentRefreshTokenPromise;
    })();
  }
  refreshAuth() {
    var serializedReqData = JSON.stringify({
      resource_appid: this.instanceOptions.resourceAppid,
      resource_env: this.instanceOptions.resourceEnv
    });
    var apiStartTime = +new Date();
    var tunnelStartTime = apiStartTime;
    var promise = this.request({
      apiName: 'tcbapi_getenvauth',
      serializedReqData
    });
    promise.then(res => {
      var tunnelEndTime = +new Date();
      reportAPISpeed({
        apiName: 'cloud.refreshAuth',
        apiEndTime: +new Date(),
        apiStartTime,
        tunnelEndTime,
        tunnelStartTime
      });
    });
    return promise;
  }
}
function getDefaultDatabaseGlobalConfig() {
  return {
    realtime: {
      maxReconnect: clientConfigDefaults.REALTIME_DB_MAX_RECONNECT,
      reconnectInterval: clientConfigDefaults.REALTIME_DB_WS_RECONNECT_INTERVAL,
      totalConnectionTimeout: clientConfigDefaults.REALTIME_DB_TOTAL_CONNECTION_TIMEOUT
    }
  };
}
;// CONCATENATED MODULE: ./src/subpackage-index.ts


globalThis.__cloudSDK__ = {
  ...cloud_namespaceObject,
  ...servicemarket_namespaceObject
};
var checkProducts = () => {
  console.log('__magic_sdk_subpackge_product_check_cloud__');
};
if (IS_APP) {
  ;
  __appServiceSDK__.setCloudSDK(globalThis.__cloudSDK__);
  delete globalThis.__cloudSDK__;
  delete globalThis.getCloudSDKGlobalVar;
}
wxConsole.warn('cloud inject success');
})();

/******/ })()
;
null

})(); /* LIBRARY_CLOSURE_END () */


} catch(err) {
      console.error('catch sdkSubPackage: cloudSDK error: ', err)
    }
