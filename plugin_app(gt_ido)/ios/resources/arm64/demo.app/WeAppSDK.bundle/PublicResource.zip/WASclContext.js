this.__wxLibrary = { 
  fileName: 'WASclContext.js',
  envType: 'Service',
  contextType: 'App:SubContext:Safe',
  execStart: Date.now(), /* @snapshot-ignore Date.now */
  mayHaveSnapshot: false
};
var __WASclContextStartTime__ = this.__wxLibrary.execStart
var __libVersionInfo__ = {"updateTime":"2024.9.29 15:15:57","version":"3.2.5","features":{"pruneWxConfigByPage":true,"injectGameContextPlugin":true,"lazyCodeLoading2":true,"lazyCodeLoadingForDevTool":true,"injectAppSeparatedPlugin":true,"nativeTrans":true,"gameLive":true,"skyline":true,"supportInvokeWithAppId":true,"wkFeatureVersion":4,"delayedServiceCodeCache":true,"gameLiveInvite":true,"globalConsole":true,"earlyDispatchSubPkgReady":true,"glassEasel":1,"expt":["clicfg_appbrand_ios_native_download_new","clicfg_appbrand_native_download","clicfg_appbrand_ios_native_socket_wcwss_new","clicfg_appbrand_ios_native_readfile","clicfg_appbrand_native_readfile","clicfg_appbrand_android_tcp_buffer","clicfg_appbrand_ios_tcp_buffer","clicfg_weapp_weak_net_predict_local","clicfg_wa_ar_iosurface_switch","clicfg_appbrand_report_trace_event","clicfg_appbrand_skyline_text_style","clicfg_appbrand_ios_free_httpdns_sdk_cache","clicfg_appbrand_android_free_httpdns_sdk_cache","clicfg_appbrand_ios_inneraudio2webaudio","clicfg_appbrand_android_inneraudio2webaudio","clicfg_appbrand_ios_inneraudio2webaudio_usewebaudio","clicfg_appbrand_android_inneraudio2webaudio_usewebaudio","clicfg_appbrand_ios_allow_multi_context_worker","clicfg_appbrand_ios_allow_worker_binding_message","clicfg_appbrand_ios_game_split_multi_plugincode","clicfg_appbrand_game_split_multi_plugincode","clicfg_appbrand_ios_arkit2wevision_usewevision","clicfg_appbrand_ios_arkit2wevision_usevertialplane","clicfg_appbrand_ios_enable_async_create_request_task","clicfg_appbrand_ios_use_jsapi_args_binding","clicfg_appbrand_android_inneraudio2webaudio_stream","clicfg_appbrand_ios_inneraudio2webaudio_stream","clicfg_appbrand_webview_slow_frame","clicfg_appbrand_webview_native_intersection_observer","clicfg_appbrand_ios_control_close_condom_white","clicfg_appbrand_android_control_close_condom_white","clicfg_appbrand_android_use_game_delay_codecache","clicfg_appbrand_android_product_recommand_new","clicfg_appbrand_ios_product_recommand_new","clicfg_appbrand_android_xnet_binding","clicfg_appbrand_ios_paymentad_expose_after_click","clicfg_appbrand_android_paymentad_expose_after_click","clicfg_appbrand_ios_game_shangcheng_kefu","clicfg_ting_weapp_audio_switch","clicfg_ting_android_weapp_audio_switch"],"snapshotConfig":{"game:main":["WAGame.js"],"game:sub":["WAGameSubContext.js"]},"mayHaveSnapshot":["WAServiceMainContext.js","WASubContext.js","WARenderContext.js","WAGame.js","WAGameSubContext.js"],"pcSnapshotConfig":{"minigame":{"iframeDomain":{"mainContext":["WAGame.js"],"gameContext":["WAGameSubContext.js"]},"workerDomain":{}},"miniprogram":{"iframeDomain":{},"workerDomain":{"main_context":["WAServiceMainContext.js"],"sub_context":["WASubContext.js"]}}}},"debugOptions":{"overwriteExpt":{},"enableFPSPanel":false}};
var window = this || {};
var PromiseRejectionEvent = function () {};
var __clientsubcontext = true;
var Reporter; /* DECLARE_GLOBAL_VAR */
var BaseConsole; /* DECLARE_GLOBAL_VAR */
var wxNativeConsole; /* DECLARE_GLOBAL_VAR */
var Trace; /* DECLARE_GLOBAL_VAR */
var __useSclExparser__ = true;

var BabelRuntimeHelpers = {};/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 4094:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./applyDecoratedDescriptor": 269,
	"./asyncToGenerator": 9655,
	"./initializerDefineProperty": 8443,
	"./initializerWarningHelper": 3673,
	"./objectSpread2": 6594
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 4094;

/***/ }),

/***/ 269:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _applyDecoratedDescriptor)
/* harmony export */ });
function _applyDecoratedDescriptor(i, e, r, n, l) {
  var a = {};
  return Object.keys(n).forEach(function (i) {
    a[i] = n[i];
  }), a.enumerable = !!a.enumerable, a.configurable = !!a.configurable, ("value" in a || a.initializer) && (a.writable = !0), a = r.slice().reverse().reduce(function (r, n) {
    return n(i, e, r) || r;
  }, a), l && void 0 !== a.initializer && (a.value = a.initializer ? a.initializer.call(l) : void 0, a.initializer = void 0), void 0 === a.initializer ? (Object.defineProperty(i, e, a), null) : a;
}


/***/ }),

/***/ 9655:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _asyncToGenerator)
/* harmony export */ });
function asyncGeneratorStep(n, t, e, r, o, a, c) {
  try {
    var i = n[a](c),
      u = i.value;
  } catch (n) {
    return void e(n);
  }
  i.done ? t(u) : Promise.resolve(u).then(r, o);
}
function _asyncToGenerator(n) {
  return function () {
    var t = this,
      e = arguments;
    return new Promise(function (r, o) {
      var a = n.apply(t, e);
      function _next(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
      }
      function _throw(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
      }
      _next(void 0);
    });
  };
}


/***/ }),

/***/ 8443:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _initializerDefineProperty)
/* harmony export */ });
function _initializerDefineProperty(e, i, r, l) {
  r && Object.defineProperty(e, i, {
    enumerable: r.enumerable,
    configurable: r.configurable,
    writable: r.writable,
    value: r.initializer ? r.initializer.call(l) : void 0
  });
}


/***/ }),

/***/ 3673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _initializerWarningHelper)
/* harmony export */ });
function _initializerWarningHelper(r, e) {
  throw Error("Decorating class property failed. Please ensure that transform-class-properties is enabled and runs after the decorators transform.");
}


/***/ }),

/***/ 6594:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _objectSpread2)
});

;// CONCATENATED MODULE: ../../node_modules/.pnpm/@babel+runtime@7.25.6/node_modules/@babel/runtime/helpers/esm/typeof.js
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}

;// CONCATENATED MODULE: ../../node_modules/.pnpm/@babel+runtime@7.25.6/node_modules/@babel/runtime/helpers/esm/toPrimitive.js

function toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}

;// CONCATENATED MODULE: ../../node_modules/.pnpm/@babel+runtime@7.25.6/node_modules/@babel/runtime/helpers/esm/toPropertyKey.js


function toPropertyKey(t) {
  var i = toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}

;// CONCATENATED MODULE: ../../node_modules/.pnpm/@babel+runtime@7.25.6/node_modules/@babel/runtime/helpers/esm/defineProperty.js

function _defineProperty(e, r, t) {
  return (r = toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = t, e;
}

;// CONCATENATED MODULE: ../../node_modules/.pnpm/@babel+runtime@7.25.6/node_modules/@babel/runtime/helpers/esm/objectSpread2.js

function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function (r) {
      return Object.getOwnPropertyDescriptor(e, r).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread2(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
      _defineProperty(e, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return e;
}


/***/ }),

/***/ 2614:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var hasOwn = __webpack_require__(8697);
var isArray = __webpack_require__(7920);
var isForced = __webpack_require__(7204);
var shared = __webpack_require__(6133);
var data = isForced.data;
var normalize = isForced.normalize;
var USE_FUNCTION_CONSTRUCTOR = 'USE_FUNCTION_CONSTRUCTOR';
var ASYNC_ITERATOR_PROTOTYPE = 'AsyncIteratorPrototype';
var setAggressivenessLevel = function (object, constant) {
  if (isArray(object)) for (var i = 0; i < object.length; i++) data[normalize(object[i])] = constant;
};
module.exports = function (options) {
  if (typeof options == 'object') {
    setAggressivenessLevel(options.useNative, isForced.NATIVE);
    setAggressivenessLevel(options.usePolyfill, isForced.POLYFILL);
    setAggressivenessLevel(options.useFeatureDetection, null);
    if (hasOwn(options, USE_FUNCTION_CONSTRUCTOR)) {
      shared[USE_FUNCTION_CONSTRUCTOR] = !!options[USE_FUNCTION_CONSTRUCTOR];
    }
    if (hasOwn(options, ASYNC_ITERATOR_PROTOTYPE)) {
      shared[USE_FUNCTION_CONSTRUCTOR] = options[ASYNC_ITERATOR_PROTOTYPE];
    }
  }
};

/***/ }),

/***/ 2978:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isCallable = __webpack_require__(6509);
var tryToString = __webpack_require__(5903);
var $TypeError = TypeError;

// `Assert: IsCallable(argument) is true`
module.exports = function (argument) {
  if (isCallable(argument)) return argument;
  throw $TypeError(tryToString(argument) + ' is not a function');
};

/***/ }),

/***/ 4100:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isConstructor = __webpack_require__(4581);
var tryToString = __webpack_require__(5903);
var $TypeError = TypeError;

// `Assert: IsConstructor(argument) is true`
module.exports = function (argument) {
  if (isConstructor(argument)) return argument;
  throw $TypeError(tryToString(argument) + ' is not a constructor');
};

/***/ }),

/***/ 6346:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isCallable = __webpack_require__(6509);
var $String = String;
var $TypeError = TypeError;
module.exports = function (argument) {
  if (typeof argument == 'object' || isCallable(argument)) return argument;
  throw $TypeError("Can't set " + $String(argument) + ' as a prototype');
};

/***/ }),

/***/ 496:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var has = (__webpack_require__(8970).has);

// Perform ? RequireInternalSlot(M, [[SetData]])
module.exports = function (it) {
  has(it);
  return it;
};

/***/ }),

/***/ 1845:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var bind = __webpack_require__(3160);
var anObject = __webpack_require__(1791);
var isNullOrUndefined = __webpack_require__(2797);
var getMethod = __webpack_require__(7750);
var wellKnownSymbol = __webpack_require__(2091);
var ASYNC_DISPOSE = wellKnownSymbol('asyncDispose');
var DISPOSE = wellKnownSymbol('dispose');
var push = uncurryThis([].push);
var getDisposeMethod = function (V, hint) {
  if (hint == 'async-dispose') {
    return getMethod(V, ASYNC_DISPOSE) || getMethod(V, DISPOSE);
  }
  return getMethod(V, DISPOSE);
};

// `CreateDisposableResource` abstract operation
// https://tc39.es/proposal-explicit-resource-management/#sec-createdisposableresource
var createDisposableResource = function (V, hint, method) {
  return bind(method || getDisposeMethod(V, hint), V);
};

// `AddDisposableResource` abstract operation
// https://tc39.es/proposal-explicit-resource-management/#sec-adddisposableresource-disposable-v-hint-disposemethod
module.exports = function (disposable, V, hint, method) {
  var resource;
  if (!method) {
    if (isNullOrUndefined(V)) return;
    resource = createDisposableResource(V, hint);
  } else if (isNullOrUndefined(V)) {
    resource = createDisposableResource(undefined, hint, method);
  } else {
    resource = createDisposableResource(anObject(V), hint, method);
  }
  push(disposable.stack, resource);
};

/***/ }),

/***/ 8909:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var wellKnownSymbol = __webpack_require__(2091);
var create = __webpack_require__(8336);
var defineProperty = (__webpack_require__(6489).f);
var UNSCOPABLES = wellKnownSymbol('unscopables');
var ArrayPrototype = Array.prototype;

// Array.prototype[@@unscopables]
// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
if (ArrayPrototype[UNSCOPABLES] == undefined) {
  defineProperty(ArrayPrototype, UNSCOPABLES, {
    configurable: true,
    value: create(null)
  });
}

// add a key to Array.prototype[@@unscopables]
module.exports = function (key) {
  ArrayPrototype[UNSCOPABLES][key] = true;
};

/***/ }),

/***/ 925:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var charAt = (__webpack_require__(1663).charAt);

// `AdvanceStringIndex` abstract operation
// https://tc39.es/ecma262/#sec-advancestringindex
module.exports = function (S, index, unicode) {
  return index + (unicode ? charAt(S, index).length : 1);
};

/***/ }),

/***/ 9663:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isPrototypeOf = __webpack_require__(1649);
var $TypeError = TypeError;
module.exports = function (it, Prototype) {
  if (isPrototypeOf(Prototype, it)) return it;
  throw $TypeError('Incorrect invocation');
};

/***/ }),

/***/ 1791:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(8154);
var $String = String;
var $TypeError = TypeError;

// `Assert: Type(argument) is Object`
module.exports = function (argument) {
  if (isObject(argument)) return argument;
  throw $TypeError($String(argument) + ' is not an object');
};

/***/ }),

/***/ 8539:
/***/ ((module) => {

// eslint-disable-next-line es/no-typed-arrays -- safe
module.exports = typeof ArrayBuffer != 'undefined' && typeof DataView != 'undefined';

/***/ }),

/***/ 6924:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var NATIVE_ARRAY_BUFFER = __webpack_require__(8539);
var DESCRIPTORS = __webpack_require__(5444);
var global = __webpack_require__(6243);
var isCallable = __webpack_require__(6509);
var isObject = __webpack_require__(8154);
var hasOwn = __webpack_require__(8697);
var classof = __webpack_require__(2611);
var tryToString = __webpack_require__(5903);
var createNonEnumerableProperty = __webpack_require__(9763);
var defineBuiltIn = __webpack_require__(9264);
var defineBuiltInAccessor = __webpack_require__(8770);
var isPrototypeOf = __webpack_require__(1649);
var getPrototypeOf = __webpack_require__(5355);
var setPrototypeOf = __webpack_require__(4767);
var wellKnownSymbol = __webpack_require__(2091);
var uid = __webpack_require__(4072);
var InternalStateModule = __webpack_require__(3653);
var enforceInternalState = InternalStateModule.enforce;
var getInternalState = InternalStateModule.get;
var Int8Array = global.Int8Array;
var Int8ArrayPrototype = Int8Array && Int8Array.prototype;
var Uint8ClampedArray = global.Uint8ClampedArray;
var Uint8ClampedArrayPrototype = Uint8ClampedArray && Uint8ClampedArray.prototype;
var TypedArray = Int8Array && getPrototypeOf(Int8Array);
var TypedArrayPrototype = Int8ArrayPrototype && getPrototypeOf(Int8ArrayPrototype);
var ObjectPrototype = Object.prototype;
var TypeError = global.TypeError;
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var TYPED_ARRAY_TAG = uid('TYPED_ARRAY_TAG');
var TYPED_ARRAY_CONSTRUCTOR = 'TypedArrayConstructor';
// Fixing native typed arrays in Opera Presto crashes the browser, see #595
var NATIVE_ARRAY_BUFFER_VIEWS = NATIVE_ARRAY_BUFFER && !!setPrototypeOf && classof(global.opera) !== 'Opera';
var TYPED_ARRAY_TAG_REQUIRED = false;
var NAME, Constructor, Prototype;
var TypedArrayConstructorsList = {
  Int8Array: 1,
  Uint8Array: 1,
  Uint8ClampedArray: 1,
  Int16Array: 2,
  Uint16Array: 2,
  Int32Array: 4,
  Uint32Array: 4,
  Float32Array: 4,
  Float64Array: 8
};
var BigIntArrayConstructorsList = {
  BigInt64Array: 8,
  BigUint64Array: 8
};
var isView = function isView(it) {
  if (!isObject(it)) return false;
  var klass = classof(it);
  return klass === 'DataView' || hasOwn(TypedArrayConstructorsList, klass) || hasOwn(BigIntArrayConstructorsList, klass);
};
var getTypedArrayConstructor = function (it) {
  var proto = getPrototypeOf(it);
  if (!isObject(proto)) return;
  var state = getInternalState(proto);
  return state && hasOwn(state, TYPED_ARRAY_CONSTRUCTOR) ? state[TYPED_ARRAY_CONSTRUCTOR] : getTypedArrayConstructor(proto);
};
var isTypedArray = function (it) {
  if (!isObject(it)) return false;
  var klass = classof(it);
  return hasOwn(TypedArrayConstructorsList, klass) || hasOwn(BigIntArrayConstructorsList, klass);
};
var aTypedArray = function (it) {
  if (isTypedArray(it)) return it;
  throw TypeError('Target is not a typed array');
};
var aTypedArrayConstructor = function (C) {
  if (isCallable(C) && (!setPrototypeOf || isPrototypeOf(TypedArray, C))) return C;
  throw TypeError(tryToString(C) + ' is not a typed array constructor');
};
var exportTypedArrayMethod = function (KEY, property, forced, options) {
  if (!DESCRIPTORS) return;
  if (forced) for (var ARRAY in TypedArrayConstructorsList) {
    var TypedArrayConstructor = global[ARRAY];
    if (TypedArrayConstructor && hasOwn(TypedArrayConstructor.prototype, KEY)) try {
      delete TypedArrayConstructor.prototype[KEY];
    } catch (error) {
      // old WebKit bug - some methods are non-configurable
      try {
        TypedArrayConstructor.prototype[KEY] = property;
      } catch (error2) {/* empty */}
    }
  }
  if (!TypedArrayPrototype[KEY] || forced) {
    defineBuiltIn(TypedArrayPrototype, KEY, forced ? property : NATIVE_ARRAY_BUFFER_VIEWS && Int8ArrayPrototype[KEY] || property, options);
  }
};
var exportTypedArrayStaticMethod = function (KEY, property, forced) {
  var ARRAY, TypedArrayConstructor;
  if (!DESCRIPTORS) return;
  if (setPrototypeOf) {
    if (forced) for (ARRAY in TypedArrayConstructorsList) {
      TypedArrayConstructor = global[ARRAY];
      if (TypedArrayConstructor && hasOwn(TypedArrayConstructor, KEY)) try {
        delete TypedArrayConstructor[KEY];
      } catch (error) {/* empty */}
    }
    if (!TypedArray[KEY] || forced) {
      // V8 ~ Chrome 49-50 `%TypedArray%` methods are non-writable non-configurable
      try {
        return defineBuiltIn(TypedArray, KEY, forced ? property : NATIVE_ARRAY_BUFFER_VIEWS && TypedArray[KEY] || property);
      } catch (error) {/* empty */}
    } else return;
  }
  for (ARRAY in TypedArrayConstructorsList) {
    TypedArrayConstructor = global[ARRAY];
    if (TypedArrayConstructor && (!TypedArrayConstructor[KEY] || forced)) {
      defineBuiltIn(TypedArrayConstructor, KEY, property);
    }
  }
};
for (NAME in TypedArrayConstructorsList) {
  Constructor = global[NAME];
  Prototype = Constructor && Constructor.prototype;
  if (Prototype) enforceInternalState(Prototype)[TYPED_ARRAY_CONSTRUCTOR] = Constructor;else NATIVE_ARRAY_BUFFER_VIEWS = false;
}
for (NAME in BigIntArrayConstructorsList) {
  Constructor = global[NAME];
  Prototype = Constructor && Constructor.prototype;
  if (Prototype) enforceInternalState(Prototype)[TYPED_ARRAY_CONSTRUCTOR] = Constructor;
}

// WebKit bug - typed arrays constructors prototype is Object.prototype
if (!NATIVE_ARRAY_BUFFER_VIEWS || !isCallable(TypedArray) || TypedArray === Function.prototype) {
  // eslint-disable-next-line no-shadow -- safe
  TypedArray = function TypedArray() {
    throw TypeError('Incorrect invocation');
  };
  if (NATIVE_ARRAY_BUFFER_VIEWS) for (NAME in TypedArrayConstructorsList) {
    if (global[NAME]) setPrototypeOf(global[NAME], TypedArray);
  }
}
if (!NATIVE_ARRAY_BUFFER_VIEWS || !TypedArrayPrototype || TypedArrayPrototype === ObjectPrototype) {
  TypedArrayPrototype = TypedArray.prototype;
  if (NATIVE_ARRAY_BUFFER_VIEWS) for (NAME in TypedArrayConstructorsList) {
    if (global[NAME]) setPrototypeOf(global[NAME].prototype, TypedArrayPrototype);
  }
}

// WebKit bug - one more object in Uint8ClampedArray prototype chain
if (NATIVE_ARRAY_BUFFER_VIEWS && getPrototypeOf(Uint8ClampedArrayPrototype) !== TypedArrayPrototype) {
  setPrototypeOf(Uint8ClampedArrayPrototype, TypedArrayPrototype);
}
if (DESCRIPTORS && !hasOwn(TypedArrayPrototype, TO_STRING_TAG)) {
  TYPED_ARRAY_TAG_REQUIRED = true;
  defineBuiltInAccessor(TypedArrayPrototype, TO_STRING_TAG, {
    configurable: true,
    get: function () {
      return isObject(this) ? this[TYPED_ARRAY_TAG] : undefined;
    }
  });
  for (NAME in TypedArrayConstructorsList) if (global[NAME]) {
    createNonEnumerableProperty(global[NAME], TYPED_ARRAY_TAG, NAME);
  }
}
module.exports = {
  NATIVE_ARRAY_BUFFER_VIEWS: NATIVE_ARRAY_BUFFER_VIEWS,
  TYPED_ARRAY_TAG: TYPED_ARRAY_TAG_REQUIRED && TYPED_ARRAY_TAG,
  aTypedArray: aTypedArray,
  aTypedArrayConstructor: aTypedArrayConstructor,
  exportTypedArrayMethod: exportTypedArrayMethod,
  exportTypedArrayStaticMethod: exportTypedArrayStaticMethod,
  getTypedArrayConstructor: getTypedArrayConstructor,
  isView: isView,
  isTypedArray: isTypedArray,
  TypedArray: TypedArray,
  TypedArrayPrototype: TypedArrayPrototype
};

/***/ }),

/***/ 1666:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var global = __webpack_require__(6243);
var uncurryThis = __webpack_require__(8712);
var DESCRIPTORS = __webpack_require__(5444);
var NATIVE_ARRAY_BUFFER = __webpack_require__(8539);
var FunctionName = __webpack_require__(1158);
var createNonEnumerableProperty = __webpack_require__(9763);
var defineBuiltInAccessor = __webpack_require__(8770);
var defineBuiltIns = __webpack_require__(8575);
var fails = __webpack_require__(4631);
var anInstance = __webpack_require__(9663);
var toIntegerOrInfinity = __webpack_require__(3923);
var toLength = __webpack_require__(7590);
var toIndex = __webpack_require__(7768);
var IEEE754 = __webpack_require__(5874);
var getPrototypeOf = __webpack_require__(5355);
var setPrototypeOf = __webpack_require__(4767);
var getOwnPropertyNames = (__webpack_require__(24).f);
var arrayFill = __webpack_require__(77);
var arraySlice = __webpack_require__(4975);
var setToStringTag = __webpack_require__(7047);
var InternalStateModule = __webpack_require__(3653);
var PROPER_FUNCTION_NAME = FunctionName.PROPER;
var CONFIGURABLE_FUNCTION_NAME = FunctionName.CONFIGURABLE;
var ARRAY_BUFFER = 'ArrayBuffer';
var DATA_VIEW = 'DataView';
var PROTOTYPE = 'prototype';
var WRONG_LENGTH = 'Wrong length';
var WRONG_INDEX = 'Wrong index';
var getInternalArrayBufferState = InternalStateModule.getterFor(ARRAY_BUFFER);
var getInternalDataViewState = InternalStateModule.getterFor(DATA_VIEW);
var setInternalState = InternalStateModule.set;
var NativeArrayBuffer = global[ARRAY_BUFFER];
var $ArrayBuffer = NativeArrayBuffer;
var ArrayBufferPrototype = $ArrayBuffer && $ArrayBuffer[PROTOTYPE];
var $DataView = global[DATA_VIEW];
var DataViewPrototype = $DataView && $DataView[PROTOTYPE];
var ObjectPrototype = Object.prototype;
var Array = global.Array;
var RangeError = global.RangeError;
var fill = uncurryThis(arrayFill);
var reverse = uncurryThis([].reverse);
var packIEEE754 = IEEE754.pack;
var unpackIEEE754 = IEEE754.unpack;
var packInt8 = function (number) {
  return [number & 0xFF];
};
var packInt16 = function (number) {
  return [number & 0xFF, number >> 8 & 0xFF];
};
var packInt32 = function (number) {
  return [number & 0xFF, number >> 8 & 0xFF, number >> 16 & 0xFF, number >> 24 & 0xFF];
};
var unpackInt32 = function (buffer) {
  return buffer[3] << 24 | buffer[2] << 16 | buffer[1] << 8 | buffer[0];
};
var packFloat32 = function (number) {
  return packIEEE754(number, 23, 4);
};
var packFloat64 = function (number) {
  return packIEEE754(number, 52, 8);
};
var addGetter = function (Constructor, key, getInternalState) {
  defineBuiltInAccessor(Constructor[PROTOTYPE], key, {
    configurable: true,
    get: function () {
      return getInternalState(this)[key];
    }
  });
};
var get = function (view, count, index, isLittleEndian) {
  var intIndex = toIndex(index);
  var store = getInternalDataViewState(view);
  if (intIndex + count > store.byteLength) throw RangeError(WRONG_INDEX);
  var bytes = store.bytes;
  var start = intIndex + store.byteOffset;
  var pack = arraySlice(bytes, start, start + count);
  return isLittleEndian ? pack : reverse(pack);
};
var set = function (view, count, index, conversion, value, isLittleEndian) {
  var intIndex = toIndex(index);
  var store = getInternalDataViewState(view);
  if (intIndex + count > store.byteLength) throw RangeError(WRONG_INDEX);
  var bytes = store.bytes;
  var start = intIndex + store.byteOffset;
  var pack = conversion(+value);
  for (var i = 0; i < count; i++) bytes[start + i] = pack[isLittleEndian ? i : count - i - 1];
};
if (!NATIVE_ARRAY_BUFFER) {
  $ArrayBuffer = function ArrayBuffer(length) {
    anInstance(this, ArrayBufferPrototype);
    var byteLength = toIndex(length);
    setInternalState(this, {
      type: ARRAY_BUFFER,
      bytes: fill(Array(byteLength), 0),
      byteLength: byteLength
    });
    if (!DESCRIPTORS) {
      this.byteLength = byteLength;
      this.detached = false;
    }
  };
  ArrayBufferPrototype = $ArrayBuffer[PROTOTYPE];
  $DataView = function DataView(buffer, byteOffset, byteLength) {
    anInstance(this, DataViewPrototype);
    anInstance(buffer, ArrayBufferPrototype);
    var bufferState = getInternalArrayBufferState(buffer);
    var bufferLength = bufferState.byteLength;
    var offset = toIntegerOrInfinity(byteOffset);
    if (offset < 0 || offset > bufferLength) throw RangeError('Wrong offset');
    byteLength = byteLength === undefined ? bufferLength - offset : toLength(byteLength);
    if (offset + byteLength > bufferLength) throw RangeError(WRONG_LENGTH);
    setInternalState(this, {
      type: DATA_VIEW,
      buffer: buffer,
      byteLength: byteLength,
      byteOffset: offset,
      bytes: bufferState.bytes
    });
    if (!DESCRIPTORS) {
      this.buffer = buffer;
      this.byteLength = byteLength;
      this.byteOffset = offset;
    }
  };
  DataViewPrototype = $DataView[PROTOTYPE];
  if (DESCRIPTORS) {
    addGetter($ArrayBuffer, 'byteLength', getInternalArrayBufferState);
    addGetter($DataView, 'buffer', getInternalDataViewState);
    addGetter($DataView, 'byteLength', getInternalDataViewState);
    addGetter($DataView, 'byteOffset', getInternalDataViewState);
  }
  defineBuiltIns(DataViewPrototype, {
    getInt8: function getInt8(byteOffset) {
      return get(this, 1, byteOffset)[0] << 24 >> 24;
    },
    getUint8: function getUint8(byteOffset) {
      return get(this, 1, byteOffset)[0];
    },
    getInt16: function getInt16(byteOffset /* , littleEndian */) {
      var bytes = get(this, 2, byteOffset, arguments.length > 1 ? arguments[1] : undefined);
      return (bytes[1] << 8 | bytes[0]) << 16 >> 16;
    },
    getUint16: function getUint16(byteOffset /* , littleEndian */) {
      var bytes = get(this, 2, byteOffset, arguments.length > 1 ? arguments[1] : undefined);
      return bytes[1] << 8 | bytes[0];
    },
    getInt32: function getInt32(byteOffset /* , littleEndian */) {
      return unpackInt32(get(this, 4, byteOffset, arguments.length > 1 ? arguments[1] : undefined));
    },
    getUint32: function getUint32(byteOffset /* , littleEndian */) {
      return unpackInt32(get(this, 4, byteOffset, arguments.length > 1 ? arguments[1] : undefined)) >>> 0;
    },
    getFloat32: function getFloat32(byteOffset /* , littleEndian */) {
      return unpackIEEE754(get(this, 4, byteOffset, arguments.length > 1 ? arguments[1] : undefined), 23);
    },
    getFloat64: function getFloat64(byteOffset /* , littleEndian */) {
      return unpackIEEE754(get(this, 8, byteOffset, arguments.length > 1 ? arguments[1] : undefined), 52);
    },
    setInt8: function setInt8(byteOffset, value) {
      set(this, 1, byteOffset, packInt8, value);
    },
    setUint8: function setUint8(byteOffset, value) {
      set(this, 1, byteOffset, packInt8, value);
    },
    setInt16: function setInt16(byteOffset, value /* , littleEndian */) {
      set(this, 2, byteOffset, packInt16, value, arguments.length > 2 ? arguments[2] : undefined);
    },
    setUint16: function setUint16(byteOffset, value /* , littleEndian */) {
      set(this, 2, byteOffset, packInt16, value, arguments.length > 2 ? arguments[2] : undefined);
    },
    setInt32: function setInt32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packInt32, value, arguments.length > 2 ? arguments[2] : undefined);
    },
    setUint32: function setUint32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packInt32, value, arguments.length > 2 ? arguments[2] : undefined);
    },
    setFloat32: function setFloat32(byteOffset, value /* , littleEndian */) {
      set(this, 4, byteOffset, packFloat32, value, arguments.length > 2 ? arguments[2] : undefined);
    },
    setFloat64: function setFloat64(byteOffset, value /* , littleEndian */) {
      set(this, 8, byteOffset, packFloat64, value, arguments.length > 2 ? arguments[2] : undefined);
    }
  });
} else {
  var INCORRECT_ARRAY_BUFFER_NAME = PROPER_FUNCTION_NAME && NativeArrayBuffer.name !== ARRAY_BUFFER;
  /* eslint-disable no-new -- required for testing */
  if (!fails(function () {
    NativeArrayBuffer(1);
  }) || !fails(function () {
    new NativeArrayBuffer(-1);
  }) || fails(function () {
    new NativeArrayBuffer();
    new NativeArrayBuffer(1.5);
    new NativeArrayBuffer(NaN);
    return NativeArrayBuffer.length != 1 || INCORRECT_ARRAY_BUFFER_NAME && !CONFIGURABLE_FUNCTION_NAME;
  })) {
    /* eslint-enable no-new -- required for testing */
    $ArrayBuffer = function ArrayBuffer(length) {
      anInstance(this, ArrayBufferPrototype);
      return new NativeArrayBuffer(toIndex(length));
    };
    $ArrayBuffer[PROTOTYPE] = ArrayBufferPrototype;
    for (var keys = getOwnPropertyNames(NativeArrayBuffer), j = 0, key; keys.length > j;) {
      if (!((key = keys[j++]) in $ArrayBuffer)) {
        createNonEnumerableProperty($ArrayBuffer, key, NativeArrayBuffer[key]);
      }
    }
    ArrayBufferPrototype.constructor = $ArrayBuffer;
  } else if (INCORRECT_ARRAY_BUFFER_NAME && CONFIGURABLE_FUNCTION_NAME) {
    createNonEnumerableProperty(NativeArrayBuffer, 'name', ARRAY_BUFFER);
  }

  // WebKit bug - the same parent prototype for typed arrays and data view
  if (setPrototypeOf && getPrototypeOf(DataViewPrototype) !== ObjectPrototype) {
    setPrototypeOf(DataViewPrototype, ObjectPrototype);
  }

  // iOS Safari 7.x bug
  var testView = new $DataView(new $ArrayBuffer(2));
  var $setInt8 = uncurryThis(DataViewPrototype.setInt8);
  testView.setInt8(0, 2147483648);
  testView.setInt8(1, 2147483649);
  if (testView.getInt8(0) || !testView.getInt8(1)) defineBuiltIns(DataViewPrototype, {
    setInt8: function setInt8(byteOffset, value) {
      $setInt8(this, byteOffset, value << 24 >> 24);
    },
    setUint8: function setUint8(byteOffset, value) {
      $setInt8(this, byteOffset, value << 24 >> 24);
    }
  }, {
    unsafe: true
  });
}
setToStringTag($ArrayBuffer, ARRAY_BUFFER);
setToStringTag($DataView, DATA_VIEW);
module.exports = {
  ArrayBuffer: $ArrayBuffer,
  DataView: $DataView
};

/***/ }),

/***/ 77:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toObject = __webpack_require__(2397);
var toAbsoluteIndex = __webpack_require__(1634);
var lengthOfArrayLike = __webpack_require__(3534);

// `Array.prototype.fill` method implementation
// https://tc39.es/ecma262/#sec-array.prototype.fill
module.exports = function fill(value /* , start = 0, end = @length */) {
  var O = toObject(this);
  var length = lengthOfArrayLike(O);
  var argumentsLength = arguments.length;
  var index = toAbsoluteIndex(argumentsLength > 1 ? arguments[1] : undefined, length);
  var end = argumentsLength > 2 ? arguments[2] : undefined;
  var endPos = end === undefined ? length : toAbsoluteIndex(end, length);
  while (endPos > index) O[index++] = value;
  return O;
};

/***/ }),

/***/ 3141:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var bind = __webpack_require__(3160);
var uncurryThis = __webpack_require__(8712);
var toObject = __webpack_require__(2397);
var isConstructor = __webpack_require__(4581);
var getAsyncIterator = __webpack_require__(2742);
var getIterator = __webpack_require__(1897);
var getIteratorDirect = __webpack_require__(3791);
var getIteratorMethod = __webpack_require__(2779);
var getMethod = __webpack_require__(7750);
var getVirtual = __webpack_require__(6540);
var getBuiltIn = __webpack_require__(8463);
var wellKnownSymbol = __webpack_require__(2091);
var AsyncFromSyncIterator = __webpack_require__(3186);
var toArray = (__webpack_require__(4903).toArray);
var ASYNC_ITERATOR = wellKnownSymbol('asyncIterator');
var arrayIterator = uncurryThis(getVirtual('Array').values);
var arrayIteratorNext = uncurryThis(arrayIterator([]).next);
var safeArrayIterator = function () {
  return new SafeArrayIterator(this);
};
var SafeArrayIterator = function (O) {
  this.iterator = arrayIterator(O);
};
SafeArrayIterator.prototype.next = function () {
  return arrayIteratorNext(this.iterator);
};

// `Array.fromAsync` method implementation
// https://github.com/tc39/proposal-array-from-async
module.exports = function fromAsync(asyncItems /* , mapfn = undefined, thisArg = undefined */) {
  var C = this;
  var argumentsLength = arguments.length;
  var mapfn = argumentsLength > 1 ? arguments[1] : undefined;
  var thisArg = argumentsLength > 2 ? arguments[2] : undefined;
  return new (getBuiltIn('Promise'))(function (resolve) {
    var O = toObject(asyncItems);
    if (mapfn !== undefined) mapfn = bind(mapfn, thisArg);
    var usingAsyncIterator = getMethod(O, ASYNC_ITERATOR);
    var usingSyncIterator = usingAsyncIterator ? undefined : getIteratorMethod(O) || safeArrayIterator;
    var A = isConstructor(C) ? new C() : [];
    var iterator = usingAsyncIterator ? getAsyncIterator(O, usingAsyncIterator) : new AsyncFromSyncIterator(getIteratorDirect(getIterator(O, usingSyncIterator)));
    resolve(toArray(iterator, mapfn, A));
  });
};

/***/ }),

/***/ 9666:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var lengthOfArrayLike = __webpack_require__(3534);
module.exports = function (Constructor, list) {
  var index = 0;
  var length = lengthOfArrayLike(list);
  var result = new Constructor(length);
  while (length > index) result[index] = list[index++];
  return result;
};

/***/ }),

/***/ 9776:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var bind = __webpack_require__(3160);
var uncurryThis = __webpack_require__(8712);
var IndexedObject = __webpack_require__(3799);
var toObject = __webpack_require__(2397);
var lengthOfArrayLike = __webpack_require__(3534);
var MapHelpers = __webpack_require__(6096);
var Map = MapHelpers.Map;
var mapGet = MapHelpers.get;
var mapHas = MapHelpers.has;
var mapSet = MapHelpers.set;
var push = uncurryThis([].push);

// `Array.prototype.groupToMap` method
// https://github.com/tc39/proposal-array-grouping
module.exports = function groupToMap(callbackfn /* , thisArg */) {
  var O = toObject(this);
  var self = IndexedObject(O);
  var boundFunction = bind(callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  var map = new Map();
  var length = lengthOfArrayLike(self);
  var index = 0;
  var key, value;
  for (; length > index; index++) {
    value = self[index];
    key = boundFunction(value, index, O);
    if (mapHas(map, key)) push(mapGet(map, key), value);else mapSet(map, key, [value]);
  }
  return map;
};

/***/ }),

/***/ 6093:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var bind = __webpack_require__(3160);
var uncurryThis = __webpack_require__(8712);
var IndexedObject = __webpack_require__(3799);
var toObject = __webpack_require__(2397);
var toPropertyKey = __webpack_require__(2129);
var lengthOfArrayLike = __webpack_require__(3534);
var objectCreate = __webpack_require__(8336);
var arrayFromConstructorAndList = __webpack_require__(9666);
var $Array = Array;
var push = uncurryThis([].push);
module.exports = function ($this, callbackfn, that, specificConstructor) {
  var O = toObject($this);
  var self = IndexedObject(O);
  var boundFunction = bind(callbackfn, that);
  var target = objectCreate(null);
  var length = lengthOfArrayLike(self);
  var index = 0;
  var Constructor, key, value;
  for (; length > index; index++) {
    value = self[index];
    key = toPropertyKey(boundFunction(value, index, O));
    // in some IE10 builds, `hasOwnProperty` returns incorrect result on integer keys
    // but since it's a `null` prototype object, we can safely use `in`
    if (key in target) push(target[key], value);else target[key] = [value];
  }
  // TODO: Remove this block from `core-js@4`
  if (specificConstructor) {
    Constructor = specificConstructor(O);
    if (Constructor !== $Array) {
      for (key in target) target[key] = arrayFromConstructorAndList(Constructor, target[key]);
    }
  }
  return target;
};

/***/ }),

/***/ 1078:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toIndexedObject = __webpack_require__(2445);
var toAbsoluteIndex = __webpack_require__(1634);
var lengthOfArrayLike = __webpack_require__(3534);

// `Array.prototype.{ indexOf, includes }` methods implementation
var createMethod = function (IS_INCLUDES) {
  return function ($this, el, fromIndex) {
    var O = toIndexedObject($this);
    var length = lengthOfArrayLike(O);
    var index = toAbsoluteIndex(fromIndex, length);
    var value;
    // Array#includes uses SameValueZero equality algorithm
    // eslint-disable-next-line no-self-compare -- NaN check
    if (IS_INCLUDES && el != el) while (length > index) {
      value = O[index++];
      // eslint-disable-next-line no-self-compare -- NaN check
      if (value != value) return true;
      // Array#indexOf ignores holes, Array#includes - not
    } else for (; length > index; index++) {
      if ((IS_INCLUDES || index in O) && O[index] === el) return IS_INCLUDES || index || 0;
    }
    return !IS_INCLUDES && -1;
  };
};
module.exports = {
  // `Array.prototype.includes` method
  // https://tc39.es/ecma262/#sec-array.prototype.includes
  includes: createMethod(true),
  // `Array.prototype.indexOf` method
  // https://tc39.es/ecma262/#sec-array.prototype.indexof
  indexOf: createMethod(false)
};

/***/ }),

/***/ 5031:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var bind = __webpack_require__(3160);
var IndexedObject = __webpack_require__(3799);
var toObject = __webpack_require__(2397);
var lengthOfArrayLike = __webpack_require__(3534);

// `Array.prototype.{ findLast, findLastIndex }` methods implementation
var createMethod = function (TYPE) {
  var IS_FIND_LAST_INDEX = TYPE == 1;
  return function ($this, callbackfn, that) {
    var O = toObject($this);
    var self = IndexedObject(O);
    var boundFunction = bind(callbackfn, that);
    var index = lengthOfArrayLike(self);
    var value, result;
    while (index-- > 0) {
      value = self[index];
      result = boundFunction(value, index, O);
      if (result) switch (TYPE) {
        case 0:
          return value;
        // findLast
        case 1:
          return index;
        // findLastIndex
      }
    }
    return IS_FIND_LAST_INDEX ? -1 : undefined;
  };
};
module.exports = {
  // `Array.prototype.findLast` method
  // https://github.com/tc39/proposal-array-find-from-last
  findLast: createMethod(0),
  // `Array.prototype.findLastIndex` method
  // https://github.com/tc39/proposal-array-find-from-last
  findLastIndex: createMethod(1)
};

/***/ }),

/***/ 53:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var bind = __webpack_require__(3160);
var uncurryThis = __webpack_require__(8712);
var IndexedObject = __webpack_require__(3799);
var toObject = __webpack_require__(2397);
var lengthOfArrayLike = __webpack_require__(3534);
var arraySpeciesCreate = __webpack_require__(5749);
var push = uncurryThis([].push);

// `Array.prototype.{ forEach, map, filter, some, every, find, findIndex, filterReject }` methods implementation
var createMethod = function (TYPE) {
  var IS_MAP = TYPE == 1;
  var IS_FILTER = TYPE == 2;
  var IS_SOME = TYPE == 3;
  var IS_EVERY = TYPE == 4;
  var IS_FIND_INDEX = TYPE == 6;
  var IS_FILTER_REJECT = TYPE == 7;
  var NO_HOLES = TYPE == 5 || IS_FIND_INDEX;
  return function ($this, callbackfn, that, specificCreate) {
    var O = toObject($this);
    var self = IndexedObject(O);
    var boundFunction = bind(callbackfn, that);
    var length = lengthOfArrayLike(self);
    var index = 0;
    var create = specificCreate || arraySpeciesCreate;
    var target = IS_MAP ? create($this, length) : IS_FILTER || IS_FILTER_REJECT ? create($this, 0) : undefined;
    var value, result;
    for (; length > index; index++) if (NO_HOLES || index in self) {
      value = self[index];
      result = boundFunction(value, index, O);
      if (TYPE) {
        if (IS_MAP) target[index] = result; // map
        else if (result) switch (TYPE) {
          case 3:
            return true;
          // some
          case 5:
            return value;
          // find
          case 6:
            return index;
          // findIndex
          case 2:
            push(target, value);
          // filter
        } else switch (TYPE) {
          case 4:
            return false;
          // every
          case 7:
            push(target, value);
          // filterReject
        }
      }
    }
    return IS_FIND_INDEX ? -1 : IS_SOME || IS_EVERY ? IS_EVERY : target;
  };
};
module.exports = {
  // `Array.prototype.forEach` method
  // https://tc39.es/ecma262/#sec-array.prototype.foreach
  forEach: createMethod(0),
  // `Array.prototype.map` method
  // https://tc39.es/ecma262/#sec-array.prototype.map
  map: createMethod(1),
  // `Array.prototype.filter` method
  // https://tc39.es/ecma262/#sec-array.prototype.filter
  filter: createMethod(2),
  // `Array.prototype.some` method
  // https://tc39.es/ecma262/#sec-array.prototype.some
  some: createMethod(3),
  // `Array.prototype.every` method
  // https://tc39.es/ecma262/#sec-array.prototype.every
  every: createMethod(4),
  // `Array.prototype.find` method
  // https://tc39.es/ecma262/#sec-array.prototype.find
  find: createMethod(5),
  // `Array.prototype.findIndex` method
  // https://tc39.es/ecma262/#sec-array.prototype.findIndex
  findIndex: createMethod(6),
  // `Array.prototype.filterReject` method
  // https://github.com/tc39/proposal-array-filtering
  filterReject: createMethod(7)
};

/***/ }),

/***/ 8782:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var fails = __webpack_require__(4631);
module.exports = function (METHOD_NAME, argument) {
  var method = [][METHOD_NAME];
  return !!method && fails(function () {
    // eslint-disable-next-line no-useless-call -- required for testing
    method.call(null, argument || function () {
      return 1;
    }, 1);
  });
};

/***/ }),

/***/ 2183:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var DESCRIPTORS = __webpack_require__(5444);
var isArray = __webpack_require__(7920);
var $TypeError = TypeError;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// Safari < 13 does not throw an error in this case
var SILENT_ON_NON_WRITABLE_LENGTH_SET = DESCRIPTORS && !function () {
  // makes no sense without proper strict mode support
  if (this !== undefined) return true;
  try {
    // eslint-disable-next-line es/no-object-defineproperty -- safe
    Object.defineProperty([], 'length', {
      writable: false
    }).length = 1;
  } catch (error) {
    return error instanceof TypeError;
  }
}();
module.exports = SILENT_ON_NON_WRITABLE_LENGTH_SET ? function (O, length) {
  if (isArray(O) && !getOwnPropertyDescriptor(O, 'length').writable) {
    throw $TypeError('Cannot set read only .length');
  }
  return O.length = length;
} : function (O, length) {
  return O.length = length;
};

/***/ }),

/***/ 4975:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toAbsoluteIndex = __webpack_require__(1634);
var lengthOfArrayLike = __webpack_require__(3534);
var createProperty = __webpack_require__(2600);
var $Array = Array;
var max = Math.max;
module.exports = function (O, start, end) {
  var length = lengthOfArrayLike(O);
  var k = toAbsoluteIndex(start, length);
  var fin = toAbsoluteIndex(end === undefined ? length : end, length);
  var result = $Array(max(fin - k, 0));
  for (var n = 0; k < fin; k++, n++) createProperty(result, n, O[k]);
  result.length = n;
  return result;
};

/***/ }),

/***/ 808:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
module.exports = uncurryThis([].slice);

/***/ }),

/***/ 9760:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var arraySlice = __webpack_require__(4975);
var floor = Math.floor;
var mergeSort = function (array, comparefn) {
  var length = array.length;
  var middle = floor(length / 2);
  return length < 8 ? insertionSort(array, comparefn) : merge(array, mergeSort(arraySlice(array, 0, middle), comparefn), mergeSort(arraySlice(array, middle), comparefn), comparefn);
};
var insertionSort = function (array, comparefn) {
  var length = array.length;
  var i = 1;
  var element, j;
  while (i < length) {
    j = i;
    element = array[i];
    while (j && comparefn(array[j - 1], element) > 0) {
      array[j] = array[--j];
    }
    if (j !== i++) array[j] = element;
  }
  return array;
};
var merge = function (array, left, right, comparefn) {
  var llength = left.length;
  var rlength = right.length;
  var lindex = 0;
  var rindex = 0;
  while (lindex < llength || rindex < rlength) {
    array[lindex + rindex] = lindex < llength && rindex < rlength ? comparefn(left[lindex], right[rindex]) <= 0 ? left[lindex++] : right[rindex++] : lindex < llength ? left[lindex++] : right[rindex++];
  }
  return array;
};
module.exports = mergeSort;

/***/ }),

/***/ 977:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isArray = __webpack_require__(7920);
var isConstructor = __webpack_require__(4581);
var isObject = __webpack_require__(8154);
var wellKnownSymbol = __webpack_require__(2091);
var SPECIES = wellKnownSymbol('species');
var $Array = Array;

// a part of `ArraySpeciesCreate` abstract operation
// https://tc39.es/ecma262/#sec-arrayspeciescreate
module.exports = function (originalArray) {
  var C;
  if (isArray(originalArray)) {
    C = originalArray.constructor;
    // cross-realm fallback
    if (isConstructor(C) && (C === $Array || isArray(C.prototype))) C = undefined;else if (isObject(C)) {
      C = C[SPECIES];
      if (C === null) C = undefined;
    }
  }
  return C === undefined ? $Array : C;
};

/***/ }),

/***/ 5749:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var arraySpeciesConstructor = __webpack_require__(977);

// `ArraySpeciesCreate` abstract operation
// https://tc39.es/ecma262/#sec-arrayspeciescreate
module.exports = function (originalArray, length) {
  return new (arraySpeciesConstructor(originalArray))(length === 0 ? 0 : length);
};

/***/ }),

/***/ 228:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var lengthOfArrayLike = __webpack_require__(3534);

// https://tc39.es/proposal-change-array-by-copy/#sec-array.prototype.toReversed
// https://tc39.es/proposal-change-array-by-copy/#sec-%typedarray%.prototype.toReversed
module.exports = function (O, C) {
  var len = lengthOfArrayLike(O);
  var A = new C(len);
  var k = 0;
  for (; k < len; k++) A[k] = O[len - k - 1];
  return A;
};

/***/ }),

/***/ 864:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var lengthOfArrayLike = __webpack_require__(3534);
var toIntegerOrInfinity = __webpack_require__(3923);
var $RangeError = RangeError;

// https://tc39.es/proposal-change-array-by-copy/#sec-array.prototype.with
// https://tc39.es/proposal-change-array-by-copy/#sec-%typedarray%.prototype.with
module.exports = function (O, C, index, value) {
  var len = lengthOfArrayLike(O);
  var relativeIndex = toIntegerOrInfinity(index);
  var actualIndex = relativeIndex < 0 ? len + relativeIndex : relativeIndex;
  if (actualIndex >= len || actualIndex < 0) throw $RangeError('Incorrect index');
  var A = new C(len);
  var k = 0;
  for (; k < len; k++) A[k] = k === actualIndex ? value : O[k];
  return A;
};

/***/ }),

/***/ 3186:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(6277);
var anObject = __webpack_require__(1791);
var create = __webpack_require__(8336);
var getMethod = __webpack_require__(7750);
var defineBuiltIns = __webpack_require__(8575);
var InternalStateModule = __webpack_require__(3653);
var getBuiltIn = __webpack_require__(8463);
var AsyncIteratorPrototype = __webpack_require__(1574);
var createIterResultObject = __webpack_require__(9097);
var Promise = getBuiltIn('Promise');
var ASYNC_FROM_SYNC_ITERATOR = 'AsyncFromSyncIterator';
var setInternalState = InternalStateModule.set;
var getInternalState = InternalStateModule.getterFor(ASYNC_FROM_SYNC_ITERATOR);
var asyncFromSyncIteratorContinuation = function (result, resolve, reject) {
  var done = result.done;
  Promise.resolve(result.value).then(function (value) {
    resolve(createIterResultObject(value, done));
  }, reject);
};
var AsyncFromSyncIterator = function AsyncIterator(iteratorRecord) {
  iteratorRecord.type = ASYNC_FROM_SYNC_ITERATOR;
  setInternalState(this, iteratorRecord);
};
AsyncFromSyncIterator.prototype = defineBuiltIns(create(AsyncIteratorPrototype), {
  next: function next() {
    var state = getInternalState(this);
    return new Promise(function (resolve, reject) {
      var result = anObject(call(state.next, state.iterator));
      asyncFromSyncIteratorContinuation(result, resolve, reject);
    });
  },
  'return': function () {
    var iterator = getInternalState(this).iterator;
    return new Promise(function (resolve, reject) {
      var $return = getMethod(iterator, 'return');
      if ($return === undefined) return resolve(createIterResultObject(undefined, true));
      var result = anObject(call($return, iterator));
      asyncFromSyncIteratorContinuation(result, resolve, reject);
    });
  }
});
module.exports = AsyncFromSyncIterator;

/***/ }),

/***/ 2748:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var getBuiltIn = __webpack_require__(8463);
var getMethod = __webpack_require__(7750);
module.exports = function (iterator, method, argument, reject) {
  try {
    var returnMethod = getMethod(iterator, 'return');
    if (returnMethod) {
      return getBuiltIn('Promise').resolve(call(returnMethod, iterator)).then(function () {
        method(argument);
      }, function (error) {
        reject(error);
      });
    }
  } catch (error2) {
    return reject(error2);
  }
  method(argument);
};

/***/ }),

/***/ 4403:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(6277);
var perform = __webpack_require__(6631);
var anObject = __webpack_require__(1791);
var create = __webpack_require__(8336);
var createNonEnumerableProperty = __webpack_require__(9763);
var defineBuiltIns = __webpack_require__(8575);
var wellKnownSymbol = __webpack_require__(2091);
var InternalStateModule = __webpack_require__(3653);
var getBuiltIn = __webpack_require__(8463);
var getMethod = __webpack_require__(7750);
var AsyncIteratorPrototype = __webpack_require__(1574);
var createIterResultObject = __webpack_require__(9097);
var iteratorClose = __webpack_require__(1451);
var Promise = getBuiltIn('Promise');
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var ASYNC_ITERATOR_HELPER = 'AsyncIteratorHelper';
var WRAP_FOR_VALID_ASYNC_ITERATOR = 'WrapForValidAsyncIterator';
var setInternalState = InternalStateModule.set;
var createAsyncIteratorProxyPrototype = function (IS_ITERATOR) {
  var IS_GENERATOR = !IS_ITERATOR;
  var getInternalState = InternalStateModule.getterFor(IS_ITERATOR ? WRAP_FOR_VALID_ASYNC_ITERATOR : ASYNC_ITERATOR_HELPER);
  var getStateOrEarlyExit = function (that) {
    var stateCompletion = perform(function () {
      return getInternalState(that);
    });
    var stateError = stateCompletion.error;
    var state = stateCompletion.value;
    if (stateError || IS_GENERATOR && state.done) {
      return {
        exit: true,
        value: stateError ? Promise.reject(state) : Promise.resolve(createIterResultObject(undefined, true))
      };
    }
    return {
      exit: false,
      value: state
    };
  };
  return defineBuiltIns(create(AsyncIteratorPrototype), {
    next: function next() {
      var stateCompletion = getStateOrEarlyExit(this);
      var state = stateCompletion.value;
      if (stateCompletion.exit) return state;
      var handlerCompletion = perform(function () {
        return anObject(state.nextHandler(Promise));
      });
      var handlerError = handlerCompletion.error;
      var value = handlerCompletion.value;
      if (handlerError) state.done = true;
      return handlerError ? Promise.reject(value) : Promise.resolve(value);
    },
    'return': function () {
      var stateCompletion = getStateOrEarlyExit(this);
      var state = stateCompletion.value;
      if (stateCompletion.exit) return state;
      state.done = true;
      var iterator = state.iterator;
      var returnMethod, result;
      var completion = perform(function () {
        if (state.inner) try {
          iteratorClose(state.inner.iterator, 'normal');
        } catch (error) {
          return iteratorClose(iterator, 'throw', error);
        }
        return getMethod(iterator, 'return');
      });
      returnMethod = result = completion.value;
      if (completion.error) return Promise.reject(result);
      if (returnMethod === undefined) return Promise.resolve(createIterResultObject(undefined, true));
      completion = perform(function () {
        return call(returnMethod, iterator);
      });
      result = completion.value;
      if (completion.error) return Promise.reject(result);
      return IS_ITERATOR ? Promise.resolve(result) : Promise.resolve(result).then(function (resolved) {
        anObject(resolved);
        return createIterResultObject(undefined, true);
      });
    }
  });
};
var WrapForValidAsyncIteratorPrototype = createAsyncIteratorProxyPrototype(true);
var AsyncIteratorHelperPrototype = createAsyncIteratorProxyPrototype(false);
createNonEnumerableProperty(AsyncIteratorHelperPrototype, TO_STRING_TAG, 'Async Iterator Helper');
module.exports = function (nextHandler, IS_ITERATOR) {
  var AsyncIteratorProxy = function AsyncIterator(record, state) {
    if (state) {
      state.iterator = record.iterator;
      state.next = record.next;
    } else state = record;
    state.type = IS_ITERATOR ? WRAP_FOR_VALID_ASYNC_ITERATOR : ASYNC_ITERATOR_HELPER;
    state.nextHandler = nextHandler;
    state.counter = 0;
    state.done = false;
    setInternalState(this, state);
  };
  AsyncIteratorProxy.prototype = IS_ITERATOR ? WrapForValidAsyncIteratorPrototype : AsyncIteratorHelperPrototype;
  return AsyncIteratorProxy;
};

/***/ }),

/***/ 4903:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// https://github.com/tc39/proposal-iterator-helpers
// https://github.com/tc39/proposal-array-from-async
var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
var isObject = __webpack_require__(8154);
var doesNotExceedSafeInteger = __webpack_require__(8653);
var getBuiltIn = __webpack_require__(8463);
var getIteratorDirect = __webpack_require__(3791);
var closeAsyncIteration = __webpack_require__(2748);
var createMethod = function (TYPE) {
  var IS_TO_ARRAY = TYPE == 0;
  var IS_FOR_EACH = TYPE == 1;
  var IS_EVERY = TYPE == 2;
  var IS_SOME = TYPE == 3;
  return function (object, fn, target) {
    var record = getIteratorDirect(object);
    var Promise = getBuiltIn('Promise');
    var iterator = record.iterator;
    var next = record.next;
    var counter = 0;
    var MAPPING = fn !== undefined;
    if (MAPPING || !IS_TO_ARRAY) aCallable(fn);
    return new Promise(function (resolve, reject) {
      var ifAbruptCloseAsyncIterator = function (error) {
        closeAsyncIteration(iterator, reject, error, reject);
      };
      var loop = function () {
        try {
          if (MAPPING) try {
            doesNotExceedSafeInteger(counter);
          } catch (error5) {
            ifAbruptCloseAsyncIterator(error5);
          }
          Promise.resolve(anObject(call(next, iterator))).then(function (step) {
            try {
              if (anObject(step).done) {
                if (IS_TO_ARRAY) {
                  target.length = counter;
                  resolve(target);
                } else resolve(IS_SOME ? false : IS_EVERY || undefined);
              } else {
                var value = step.value;
                try {
                  if (MAPPING) {
                    var result = fn(value, counter);
                    var handler = function ($result) {
                      if (IS_FOR_EACH) {
                        loop();
                      } else if (IS_EVERY) {
                        $result ? loop() : closeAsyncIteration(iterator, resolve, false, reject);
                      } else if (IS_TO_ARRAY) {
                        try {
                          target[counter++] = $result;
                          loop();
                        } catch (error4) {
                          ifAbruptCloseAsyncIterator(error4);
                        }
                      } else {
                        $result ? closeAsyncIteration(iterator, resolve, IS_SOME || value, reject) : loop();
                      }
                    };
                    if (isObject(result)) Promise.resolve(result).then(handler, ifAbruptCloseAsyncIterator);else handler(result);
                  } else {
                    target[counter++] = value;
                    loop();
                  }
                } catch (error3) {
                  ifAbruptCloseAsyncIterator(error3);
                }
              }
            } catch (error2) {
              reject(error2);
            }
          }, reject);
        } catch (error) {
          reject(error);
        }
      };
      loop();
    });
  };
};
module.exports = {
  toArray: createMethod(0),
  forEach: createMethod(1),
  every: createMethod(2),
  some: createMethod(3),
  find: createMethod(4)
};

/***/ }),

/***/ 9262:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
var isObject = __webpack_require__(8154);
var getIteratorDirect = __webpack_require__(3791);
var createAsyncIteratorProxy = __webpack_require__(4403);
var createIterResultObject = __webpack_require__(9097);
var closeAsyncIteration = __webpack_require__(2748);
var AsyncIteratorProxy = createAsyncIteratorProxy(function (Promise) {
  var state = this;
  var iterator = state.iterator;
  var mapper = state.mapper;
  return new Promise(function (resolve, reject) {
    var doneAndReject = function (error) {
      state.done = true;
      reject(error);
    };
    var ifAbruptCloseAsyncIterator = function (error) {
      closeAsyncIteration(iterator, doneAndReject, error, doneAndReject);
    };
    Promise.resolve(anObject(call(state.next, iterator))).then(function (step) {
      try {
        if (anObject(step).done) {
          state.done = true;
          resolve(createIterResultObject(undefined, true));
        } else {
          var value = step.value;
          try {
            var result = mapper(value, state.counter++);
            var handler = function (mapped) {
              resolve(createIterResultObject(mapped, false));
            };
            if (isObject(result)) Promise.resolve(result).then(handler, ifAbruptCloseAsyncIterator);else handler(result);
          } catch (error2) {
            ifAbruptCloseAsyncIterator(error2);
          }
        }
      } catch (error) {
        doneAndReject(error);
      }
    }, doneAndReject);
  });
});

// `AsyncIterator.prototype.map` method
// https://github.com/tc39/proposal-iterator-helpers
module.exports = function map(mapper) {
  return new AsyncIteratorProxy(getIteratorDirect(this), {
    mapper: aCallable(mapper)
  });
};

/***/ }),

/***/ 1574:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var shared = __webpack_require__(6133);
var isCallable = __webpack_require__(6509);
var create = __webpack_require__(8336);
var getPrototypeOf = __webpack_require__(5355);
var defineBuiltIn = __webpack_require__(9264);
var wellKnownSymbol = __webpack_require__(2091);
var IS_PURE = __webpack_require__(1459);
var USE_FUNCTION_CONSTRUCTOR = 'USE_FUNCTION_CONSTRUCTOR';
var ASYNC_ITERATOR = wellKnownSymbol('asyncIterator');
var AsyncIterator = global.AsyncIterator;
var PassedAsyncIteratorPrototype = shared.AsyncIteratorPrototype;
var AsyncIteratorPrototype, prototype;
if (PassedAsyncIteratorPrototype) {
  AsyncIteratorPrototype = PassedAsyncIteratorPrototype;
} else if (isCallable(AsyncIterator)) {
  AsyncIteratorPrototype = AsyncIterator.prototype;
} else if (shared[USE_FUNCTION_CONSTRUCTOR] || global[USE_FUNCTION_CONSTRUCTOR]) {
  try {
    // eslint-disable-next-line no-new-func -- we have no alternatives without usage of modern syntax
    prototype = getPrototypeOf(getPrototypeOf(getPrototypeOf(Function('return async function*(){}()')())));
    if (getPrototypeOf(prototype) === Object.prototype) AsyncIteratorPrototype = prototype;
  } catch (error) {/* empty */}
}
if (!AsyncIteratorPrototype) AsyncIteratorPrototype = {};else if (IS_PURE) AsyncIteratorPrototype = create(AsyncIteratorPrototype);
if (!isCallable(AsyncIteratorPrototype[ASYNC_ITERATOR])) {
  defineBuiltIn(AsyncIteratorPrototype, ASYNC_ITERATOR, function () {
    return this;
  });
}
module.exports = AsyncIteratorPrototype;

/***/ }),

/***/ 3818:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var createAsyncIteratorProxy = __webpack_require__(4403);
module.exports = createAsyncIteratorProxy(function () {
  return call(this.next, this.iterator);
}, true);

/***/ }),

/***/ 4359:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var anObject = __webpack_require__(1791);
var iteratorClose = __webpack_require__(1451);

// call something on iterator step with safe closing on error
module.exports = function (iterator, fn, value, ENTRIES) {
  try {
    return ENTRIES ? fn(anObject(value)[0], value[1]) : fn(value);
  } catch (error) {
    iteratorClose(iterator, 'throw', error);
  }
};

/***/ }),

/***/ 1508:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var wellKnownSymbol = __webpack_require__(2091);
var ITERATOR = wellKnownSymbol('iterator');
var SAFE_CLOSING = false;
try {
  var called = 0;
  var iteratorWithReturn = {
    next: function () {
      return {
        done: !!called++
      };
    },
    'return': function () {
      SAFE_CLOSING = true;
    }
  };
  iteratorWithReturn[ITERATOR] = function () {
    return this;
  };
  // eslint-disable-next-line es/no-array-from, no-throw-literal -- required for testing
  Array.from(iteratorWithReturn, function () {
    throw 2;
  });
} catch (error) {/* empty */}
module.exports = function (exec, SKIP_CLOSING) {
  if (!SKIP_CLOSING && !SAFE_CLOSING) return false;
  var ITERATION_SUPPORT = false;
  try {
    var object = {};
    object[ITERATOR] = function () {
      return {
        next: function () {
          return {
            done: ITERATION_SUPPORT = true
          };
        }
      };
    };
    exec(object);
  } catch (error) {/* empty */}
  return ITERATION_SUPPORT;
};

/***/ }),

/***/ 7384:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var toString = uncurryThis({}.toString);
var stringSlice = uncurryThis(''.slice);
module.exports = function (it) {
  return stringSlice(toString(it), 8, -1);
};

/***/ }),

/***/ 2611:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var TO_STRING_TAG_SUPPORT = __webpack_require__(5396);
var isCallable = __webpack_require__(6509);
var classofRaw = __webpack_require__(7384);
var wellKnownSymbol = __webpack_require__(2091);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var $Object = Object;

// ES3 wrong here
var CORRECT_ARGUMENTS = classofRaw(function () {
  return arguments;
}()) == 'Arguments';

// fallback for IE11 Script Access Denied error
var tryGet = function (it, key) {
  try {
    return it[key];
  } catch (error) {/* empty */}
};

// getting tag from ES6+ `Object.prototype.toString`
module.exports = TO_STRING_TAG_SUPPORT ? classofRaw : function (it) {
  var O, tag, result;
  return it === undefined ? 'Undefined' : it === null ? 'Null'
  // @@toStringTag case
  : typeof (tag = tryGet(O = $Object(it), TO_STRING_TAG)) == 'string' ? tag
  // builtinTag case
  : CORRECT_ARGUMENTS ? classofRaw(O)
  // ES3 arguments fallback
  : (result = classofRaw(O)) == 'Object' && isCallable(O.callee) ? 'Arguments' : result;
};

/***/ }),

/***/ 8004:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var hasOwn = __webpack_require__(8697);
var ownKeys = __webpack_require__(4927);
var getOwnPropertyDescriptorModule = __webpack_require__(7515);
var definePropertyModule = __webpack_require__(6489);
module.exports = function (target, source, exceptions) {
  var keys = ownKeys(source);
  var defineProperty = definePropertyModule.f;
  var getOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (!hasOwn(target, key) && !(exceptions && hasOwn(exceptions, key))) {
      defineProperty(target, key, getOwnPropertyDescriptor(source, key));
    }
  }
};

/***/ }),

/***/ 1899:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(4631);
module.exports = !fails(function () {
  function F() {/* empty */}
  F.prototype.constructor = null;
  // eslint-disable-next-line es/no-object-getprototypeof -- required for testing
  return Object.getPrototypeOf(new F()) !== F.prototype;
});

/***/ }),

/***/ 9097:
/***/ ((module) => {

// `CreateIterResultObject` abstract operation
// https://tc39.es/ecma262/#sec-createiterresultobject
module.exports = function (value, done) {
  return {
    value: value,
    done: done
  };
};

/***/ }),

/***/ 9763:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(5444);
var definePropertyModule = __webpack_require__(6489);
var createPropertyDescriptor = __webpack_require__(6012);
module.exports = DESCRIPTORS ? function (object, key, value) {
  return definePropertyModule.f(object, key, createPropertyDescriptor(1, value));
} : function (object, key, value) {
  object[key] = value;
  return object;
};

/***/ }),

/***/ 6012:
/***/ ((module) => {

module.exports = function (bitmap, value) {
  return {
    enumerable: !(bitmap & 1),
    configurable: !(bitmap & 2),
    writable: !(bitmap & 4),
    value: value
  };
};

/***/ }),

/***/ 2600:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var toPropertyKey = __webpack_require__(2129);
var definePropertyModule = __webpack_require__(6489);
var createPropertyDescriptor = __webpack_require__(6012);
module.exports = function (object, key, value) {
  var propertyKey = toPropertyKey(key);
  if (propertyKey in object) definePropertyModule.f(object, propertyKey, createPropertyDescriptor(0, value));else object[propertyKey] = value;
};

/***/ }),

/***/ 8770:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var makeBuiltIn = __webpack_require__(3123);
var defineProperty = __webpack_require__(6489);
module.exports = function (target, name, descriptor) {
  if (descriptor.get) makeBuiltIn(descriptor.get, name, {
    getter: true
  });
  if (descriptor.set) makeBuiltIn(descriptor.set, name, {
    setter: true
  });
  return defineProperty.f(target, name, descriptor);
};

/***/ }),

/***/ 9264:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isCallable = __webpack_require__(6509);
var definePropertyModule = __webpack_require__(6489);
var makeBuiltIn = __webpack_require__(3123);
var defineGlobalProperty = __webpack_require__(8289);
module.exports = function (O, key, value, options) {
  if (!options) options = {};
  var simple = options.enumerable;
  var name = options.name !== undefined ? options.name : key;
  if (isCallable(value)) makeBuiltIn(value, name, options);
  if (options.global) {
    if (simple) O[key] = value;else defineGlobalProperty(key, value);
  } else {
    try {
      if (!options.unsafe) delete O[key];else if (O[key]) simple = true;
    } catch (error) {/* empty */}
    if (simple) O[key] = value;else definePropertyModule.f(O, key, {
      value: value,
      enumerable: false,
      configurable: !options.nonConfigurable,
      writable: !options.nonWritable
    });
  }
  return O;
};

/***/ }),

/***/ 8575:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var defineBuiltIn = __webpack_require__(9264);
module.exports = function (target, src, options) {
  for (var key in src) defineBuiltIn(target, key, src[key], options);
  return target;
};

/***/ }),

/***/ 8289:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);

// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;
module.exports = function (key, value) {
  try {
    defineProperty(global, key, {
      value: value,
      configurable: true,
      writable: true
    });
  } catch (error) {
    global[key] = value;
  }
  return value;
};

/***/ }),

/***/ 5334:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var tryToString = __webpack_require__(5903);
var $TypeError = TypeError;
module.exports = function (O, P) {
  if (!delete O[P]) throw $TypeError('Cannot delete property ' + tryToString(P) + ' of ' + tryToString(O));
};

/***/ }),

/***/ 5444:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(4631);

// Detect IE8's incomplete defineProperty implementation
module.exports = !fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty({}, 1, {
    get: function () {
      return 7;
    }
  })[1] != 7;
});

/***/ }),

/***/ 8339:
/***/ ((module) => {

var documentAll = typeof document == 'object' && document.all;

// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot
// eslint-disable-next-line unicorn/no-typeof-undefined -- required for testing
var IS_HTMLDDA = typeof documentAll == 'undefined' && documentAll !== undefined;
module.exports = {
  all: documentAll,
  IS_HTMLDDA: IS_HTMLDDA
};

/***/ }),

/***/ 6431:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var isObject = __webpack_require__(8154);
var document = global.document;
// typeof document.createElement is 'object' in old IE
var EXISTS = isObject(document) && isObject(document.createElement);
module.exports = function (it) {
  return EXISTS ? document.createElement(it) : {};
};

/***/ }),

/***/ 8653:
/***/ ((module) => {

var $TypeError = TypeError;
var MAX_SAFE_INTEGER = 0x1FFFFFFFFFFFFF; // 2 ** 53 - 1 == 9007199254740991

module.exports = function (it) {
  if (it > MAX_SAFE_INTEGER) throw $TypeError('Maximum allowed index exceeded');
  return it;
};

/***/ }),

/***/ 6986:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var userAgent = __webpack_require__(9368);
var firefox = userAgent.match(/firefox\/(\d+)/i);
module.exports = !!firefox && +firefox[1];

/***/ }),

/***/ 3954:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var IS_DENO = __webpack_require__(6524);
var IS_NODE = __webpack_require__(5816);
module.exports = !IS_DENO && !IS_NODE && typeof window == 'object' && typeof document == 'object';

/***/ }),

/***/ 6524:
/***/ ((module) => {

/* global Deno -- Deno case */
module.exports = typeof Deno == 'object' && Deno && typeof Deno.version == 'object';

/***/ }),

/***/ 2250:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var UA = __webpack_require__(9368);
module.exports = /MSIE|Trident/.test(UA);

/***/ }),

/***/ 9604:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var userAgent = __webpack_require__(9368);
module.exports = /ipad|iphone|ipod/i.test(userAgent) && typeof Pebble != 'undefined';

/***/ }),

/***/ 2815:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var userAgent = __webpack_require__(9368);

// eslint-disable-next-line redos/no-vulnerable -- safe
module.exports = /(?:ipad|iphone|ipod).*applewebkit/i.test(userAgent);

/***/ }),

/***/ 5816:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var classof = __webpack_require__(7384);
module.exports = typeof process != 'undefined' && classof(process) == 'process';

/***/ }),

/***/ 7093:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var userAgent = __webpack_require__(9368);
module.exports = /web0s(?!.*chrome)/i.test(userAgent);

/***/ }),

/***/ 9368:
/***/ ((module) => {

module.exports = typeof navigator != 'undefined' && String(navigator.userAgent) || '';

/***/ }),

/***/ 8820:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var userAgent = __webpack_require__(9368);
var process = global.process;
var Deno = global.Deno;
var versions = process && process.versions || Deno && Deno.version;
var v8 = versions && versions.v8;
var match, version;
if (v8) {
  match = v8.split('.');
  // in old Chrome, versions of V8 isn't V8 = Chrome / 10
  // but their correct versions are not interesting for us
  version = match[0] > 0 && match[0] < 4 ? 1 : +(match[0] + match[1]);
}

// BrowserFS NodeJS `process` polyfill incorrectly set `.v8` to `0.0`
// so check `userAgent` even if `.v8` exists, but 0
if (!version && userAgent) {
  match = userAgent.match(/Edge\/(\d+)/);
  if (!match || match[1] >= 74) {
    match = userAgent.match(/Chrome\/(\d+)/);
    if (match) version = +match[1];
  }
}
module.exports = version;

/***/ }),

/***/ 2736:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var userAgent = __webpack_require__(9368);
var webkit = userAgent.match(/AppleWebKit\/(\d+)\./);
module.exports = !!webkit && +webkit[1];

/***/ }),

/***/ 6540:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
module.exports = function (CONSTRUCTOR) {
  return global[CONSTRUCTOR].prototype;
};

/***/ }),

/***/ 9119:
/***/ ((module) => {

// IE8- don't enum bug keys
module.exports = ['constructor', 'hasOwnProperty', 'isPrototypeOf', 'propertyIsEnumerable', 'toLocaleString', 'toString', 'valueOf'];

/***/ }),

/***/ 5081:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var $Error = Error;
var replace = uncurryThis(''.replace);
var TEST = function (arg) {
  return String($Error(arg).stack);
}('zxcasd');
// eslint-disable-next-line redos/no-vulnerable -- safe
var V8_OR_CHAKRA_STACK_ENTRY = /\n\s*at [^:]*:[^\n]*/;
var IS_V8_OR_CHAKRA_STACK = V8_OR_CHAKRA_STACK_ENTRY.test(TEST);
module.exports = function (stack, dropEntries) {
  if (IS_V8_OR_CHAKRA_STACK && typeof stack == 'string' && !$Error.prepareStackTrace) {
    while (dropEntries--) stack = replace(stack, V8_OR_CHAKRA_STACK_ENTRY, '');
  }
  return stack;
};

/***/ }),

/***/ 5491:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var createNonEnumerableProperty = __webpack_require__(9763);
var clearErrorStack = __webpack_require__(5081);
var ERROR_STACK_INSTALLABLE = __webpack_require__(3083);

// non-standard V8
var captureStackTrace = Error.captureStackTrace;
module.exports = function (error, C, stack, dropEntries) {
  if (ERROR_STACK_INSTALLABLE) {
    if (captureStackTrace) captureStackTrace(error, C);else createNonEnumerableProperty(error, 'stack', clearErrorStack(stack, dropEntries));
  }
};

/***/ }),

/***/ 3083:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(4631);
var createPropertyDescriptor = __webpack_require__(6012);
module.exports = !fails(function () {
  var error = Error('a');
  if (!('stack' in error)) return true;
  // eslint-disable-next-line es/no-object-defineproperty -- safe
  Object.defineProperty(error, 'stack', createPropertyDescriptor(1, 7));
  return error.stack !== 7;
});

/***/ }),

/***/ 4334:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var getOwnPropertyDescriptor = (__webpack_require__(7515).f);
var createNonEnumerableProperty = __webpack_require__(9763);
var defineBuiltIn = __webpack_require__(9264);
var defineGlobalProperty = __webpack_require__(8289);
var copyConstructorProperties = __webpack_require__(8004);
var isForced = __webpack_require__(7204);

/*
  options.target         - name of the target object
  options.global         - target is the global object
  options.stat           - export as static methods of target
  options.proto          - export as prototype methods of target
  options.real           - real prototype method for the `pure` version
  options.forced         - export even if the native feature is available
  options.bind           - bind methods to the target, required for the `pure` version
  options.wrap           - wrap constructors to preventing global pollution, required for the `pure` version
  options.unsafe         - use the simple assignment of property instead of delete + defineProperty
  options.sham           - add a flag to not completely full polyfills
  options.enumerable     - export as enumerable property
  options.dontCallGetSet - prevent calling a getter on target
  options.name           - the .name of the function if it does not match the key
*/
module.exports = function (options, source) {
  var TARGET = options.target;
  var GLOBAL = options.global;
  var STATIC = options.stat;
  var FORCED, target, key, targetProperty, sourceProperty, descriptor;
  if (GLOBAL) {
    target = global;
  } else if (STATIC) {
    target = global[TARGET] || defineGlobalProperty(TARGET, {});
  } else {
    target = (global[TARGET] || {}).prototype;
  }
  if (target) for (key in source) {
    sourceProperty = source[key];
    if (options.dontCallGetSet) {
      descriptor = getOwnPropertyDescriptor(target, key);
      targetProperty = descriptor && descriptor.value;
    } else targetProperty = target[key];
    FORCED = isForced(GLOBAL ? key : TARGET + (STATIC ? '.' : '#') + key, options.forced);
    // contained in target
    if (!FORCED && targetProperty !== undefined) {
      if (typeof sourceProperty == typeof targetProperty) continue;
      copyConstructorProperties(sourceProperty, targetProperty);
    }
    // add a flag to not completely full polyfills
    if (options.sham || targetProperty && targetProperty.sham) {
      createNonEnumerableProperty(sourceProperty, 'sham', true);
    }
    defineBuiltIn(target, key, sourceProperty, options);
  }
};

/***/ }),

/***/ 4631:
/***/ ((module) => {

module.exports = function (exec) {
  try {
    return !!exec();
  } catch (error) {
    return true;
  }
};

/***/ }),

/***/ 2068:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4` since it's moved to entry points
__webpack_require__(9007);
var uncurryThis = __webpack_require__(4060);
var defineBuiltIn = __webpack_require__(9264);
var regexpExec = __webpack_require__(4899);
var fails = __webpack_require__(4631);
var wellKnownSymbol = __webpack_require__(2091);
var createNonEnumerableProperty = __webpack_require__(9763);
var SPECIES = wellKnownSymbol('species');
var RegExpPrototype = RegExp.prototype;
module.exports = function (KEY, exec, FORCED, SHAM) {
  var SYMBOL = wellKnownSymbol(KEY);
  var DELEGATES_TO_SYMBOL = !fails(function () {
    // String methods call symbol-named RegEp methods
    var O = {};
    O[SYMBOL] = function () {
      return 7;
    };
    return ''[KEY](O) != 7;
  });
  var DELEGATES_TO_EXEC = DELEGATES_TO_SYMBOL && !fails(function () {
    // Symbol-named RegExp methods call .exec
    var execCalled = false;
    var re = /a/;
    if (KEY === 'split') {
      // We can't use real regex here since it causes deoptimization
      // and serious performance degradation in V8
      // https://github.com/zloirock/core-js/issues/306
      re = {};
      // RegExp[@@split] doesn't call the regex's exec method, but first creates
      // a new one. We need to return the patched regex when creating the new one.
      re.constructor = {};
      re.constructor[SPECIES] = function () {
        return re;
      };
      re.flags = '';
      re[SYMBOL] = /./[SYMBOL];
    }
    re.exec = function () {
      execCalled = true;
      return null;
    };
    re[SYMBOL]('');
    return !execCalled;
  });
  if (!DELEGATES_TO_SYMBOL || !DELEGATES_TO_EXEC || FORCED) {
    var uncurriedNativeRegExpMethod = uncurryThis(/./[SYMBOL]);
    var methods = exec(SYMBOL, ''[KEY], function (nativeMethod, regexp, str, arg2, forceStringMethod) {
      var uncurriedNativeMethod = uncurryThis(nativeMethod);
      var $exec = regexp.exec;
      if ($exec === regexpExec || $exec === RegExpPrototype.exec) {
        if (DELEGATES_TO_SYMBOL && !forceStringMethod) {
          // The native String method already delegates to @@method (this
          // polyfilled function), leasing to infinite recursion.
          // We avoid it by directly calling the native @@method method.
          return {
            done: true,
            value: uncurriedNativeRegExpMethod(regexp, str, arg2)
          };
        }
        return {
          done: true,
          value: uncurriedNativeMethod(str, regexp, arg2)
        };
      }
      return {
        done: false
      };
    });
    defineBuiltIn(String.prototype, KEY, methods[0]);
    defineBuiltIn(RegExpPrototype, SYMBOL, methods[1]);
  }
  if (SHAM) createNonEnumerableProperty(RegExpPrototype[SYMBOL], 'sham', true);
};

/***/ }),

/***/ 2113:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var NATIVE_BIND = __webpack_require__(3168);
var FunctionPrototype = Function.prototype;
var apply = FunctionPrototype.apply;
var call = FunctionPrototype.call;

// eslint-disable-next-line es/no-reflect -- safe
module.exports = typeof Reflect == 'object' && Reflect.apply || (NATIVE_BIND ? call.bind(apply) : function () {
  return call.apply(apply, arguments);
});

/***/ }),

/***/ 3160:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(4060);
var aCallable = __webpack_require__(2978);
var NATIVE_BIND = __webpack_require__(3168);
var bind = uncurryThis(uncurryThis.bind);

// optional / simple context binding
module.exports = function (fn, that) {
  aCallable(fn);
  return that === undefined ? fn : NATIVE_BIND ? bind(fn, that) : function /* ...args */
  () {
    return fn.apply(that, arguments);
  };
};

/***/ }),

/***/ 3168:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(4631);
module.exports = !fails(function () {
  // eslint-disable-next-line es/no-function-prototype-bind -- safe
  var test = function () {/* empty */}.bind();
  // eslint-disable-next-line no-prototype-builtins -- safe
  return typeof test != 'function' || test.hasOwnProperty('prototype');
});

/***/ }),

/***/ 6277:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var NATIVE_BIND = __webpack_require__(3168);
var call = Function.prototype.call;
module.exports = NATIVE_BIND ? call.bind(call) : function () {
  return call.apply(call, arguments);
};

/***/ }),

/***/ 1158:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(5444);
var hasOwn = __webpack_require__(8697);
var FunctionPrototype = Function.prototype;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getDescriptor = DESCRIPTORS && Object.getOwnPropertyDescriptor;
var EXISTS = hasOwn(FunctionPrototype, 'name');
// additional protection from minified / mangled / dropped function names
var PROPER = EXISTS && function something() {/* empty */}.name === 'something';
var CONFIGURABLE = EXISTS && (!DESCRIPTORS || DESCRIPTORS && getDescriptor(FunctionPrototype, 'name').configurable);
module.exports = {
  EXISTS: EXISTS,
  PROPER: PROPER,
  CONFIGURABLE: CONFIGURABLE
};

/***/ }),

/***/ 5658:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var aCallable = __webpack_require__(2978);
module.exports = function (object, key, method) {
  try {
    // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
    return uncurryThis(aCallable(Object.getOwnPropertyDescriptor(object, key)[method]));
  } catch (error) {/* empty */}
};

/***/ }),

/***/ 4060:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var classofRaw = __webpack_require__(7384);
var uncurryThis = __webpack_require__(8712);
module.exports = function (fn) {
  // Nashorn bug:
  //   https://github.com/zloirock/core-js/issues/1128
  //   https://github.com/zloirock/core-js/issues/1130
  if (classofRaw(fn) === 'Function') return uncurryThis(fn);
};

/***/ }),

/***/ 8712:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var NATIVE_BIND = __webpack_require__(3168);
var FunctionPrototype = Function.prototype;
var call = FunctionPrototype.call;
var uncurryThisWithBind = NATIVE_BIND && FunctionPrototype.bind.bind(call, call);
module.exports = NATIVE_BIND ? uncurryThisWithBind : function (fn) {
  return function () {
    return call.apply(fn, arguments);
  };
};

/***/ }),

/***/ 8733:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var isCallable = __webpack_require__(6509);
var anObject = __webpack_require__(1791);
var getIteratorDirect = __webpack_require__(3791);
var getIteratorMethod = __webpack_require__(2779);
var getMethod = __webpack_require__(7750);
var wellKnownSymbol = __webpack_require__(2091);
var AsyncFromSyncIterator = __webpack_require__(3186);
var ASYNC_ITERATOR = wellKnownSymbol('asyncIterator');
module.exports = function from(obj) {
  var object = anObject(obj);
  var alreadyAsync = true;
  var method = getMethod(object, ASYNC_ITERATOR);
  var iterator;
  if (!isCallable(method)) {
    method = getIteratorMethod(object);
    alreadyAsync = false;
  }
  if (isCallable(method)) {
    iterator = call(method, object);
  } else {
    iterator = object;
    alreadyAsync = true;
  }
  anObject(iterator);
  return getIteratorDirect(alreadyAsync ? iterator : new AsyncFromSyncIterator(getIteratorDirect(iterator)));
};

/***/ }),

/***/ 2742:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var AsyncFromSyncIterator = __webpack_require__(3186);
var anObject = __webpack_require__(1791);
var getIterator = __webpack_require__(1897);
var getIteratorDirect = __webpack_require__(3791);
var getMethod = __webpack_require__(7750);
var wellKnownSymbol = __webpack_require__(2091);
var ASYNC_ITERATOR = wellKnownSymbol('asyncIterator');
module.exports = function (it, usingIterator) {
  var method = arguments.length < 2 ? getMethod(it, ASYNC_ITERATOR) : usingIterator;
  return method ? anObject(call(method, it)) : new AsyncFromSyncIterator(getIteratorDirect(getIterator(it)));
};

/***/ }),

/***/ 8463:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var isCallable = __webpack_require__(6509);
var aFunction = function (argument) {
  return isCallable(argument) ? argument : undefined;
};
module.exports = function (namespace, method) {
  return arguments.length < 2 ? aFunction(global[namespace]) : global[namespace] && global[namespace][method];
};

/***/ }),

/***/ 3791:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
module.exports = function (obj) {
  return {
    iterator: obj,
    next: aCallable(anObject(obj).next)
  };
};

/***/ }),

/***/ 478:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var isCallable = __webpack_require__(6509);
var anObject = __webpack_require__(1791);
var getIteratorDirect = __webpack_require__(3791);
var getIteratorMethod = __webpack_require__(2779);
module.exports = function (obj) {
  var object = anObject(obj);
  var method = getIteratorMethod(object);
  return getIteratorDirect(anObject(isCallable(method) ? call(method, object) : object));
};

/***/ }),

/***/ 2779:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var classof = __webpack_require__(2611);
var getMethod = __webpack_require__(7750);
var isNullOrUndefined = __webpack_require__(2797);
var Iterators = __webpack_require__(1941);
var wellKnownSymbol = __webpack_require__(2091);
var ITERATOR = wellKnownSymbol('iterator');
module.exports = function (it) {
  if (!isNullOrUndefined(it)) return getMethod(it, ITERATOR) || getMethod(it, '@@iterator') || Iterators[classof(it)];
};

/***/ }),

/***/ 1897:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
var tryToString = __webpack_require__(5903);
var getIteratorMethod = __webpack_require__(2779);
var $TypeError = TypeError;
module.exports = function (argument, usingIterator) {
  var iteratorMethod = arguments.length < 2 ? getIteratorMethod(argument) : usingIterator;
  if (aCallable(iteratorMethod)) return anObject(call(iteratorMethod, argument));
  throw $TypeError(tryToString(argument) + ' is not iterable');
};

/***/ }),

/***/ 7485:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var isArray = __webpack_require__(7920);
var isCallable = __webpack_require__(6509);
var classof = __webpack_require__(7384);
var toString = __webpack_require__(5479);
var push = uncurryThis([].push);
module.exports = function (replacer) {
  if (isCallable(replacer)) return replacer;
  if (!isArray(replacer)) return;
  var rawLength = replacer.length;
  var keys = [];
  for (var i = 0; i < rawLength; i++) {
    var element = replacer[i];
    if (typeof element == 'string') push(keys, element);else if (typeof element == 'number' || classof(element) == 'Number' || classof(element) == 'String') push(keys, toString(element));
  }
  var keysLength = keys.length;
  var root = true;
  return function (key, value) {
    if (root) {
      root = false;
      return value;
    }
    if (isArray(this)) return value;
    for (var j = 0; j < keysLength; j++) if (keys[j] === key) return value;
  };
};

/***/ }),

/***/ 7750:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var aCallable = __webpack_require__(2978);
var isNullOrUndefined = __webpack_require__(2797);

// `GetMethod` abstract operation
// https://tc39.es/ecma262/#sec-getmethod
module.exports = function (V, P) {
  var func = V[P];
  return isNullOrUndefined(func) ? undefined : aCallable(func);
};

/***/ }),

/***/ 1461:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
var call = __webpack_require__(6277);
var toIntegerOrInfinity = __webpack_require__(3923);
var $TypeError = TypeError;
var max = Math.max;
var SetRecord = function (set, size, has, keys) {
  this.set = set;
  this.size = size;
  this.has = has;
  this.keys = keys;
};
SetRecord.prototype = {
  getIterator: function () {
    return anObject(call(this.keys, this.set));
  },
  includes: function (it) {
    return call(this.has, this.set, it);
  }
};

// `GetSetRecord` abstract operation
// https://tc39.es/proposal-set-methods/#sec-getsetrecord
module.exports = function (obj) {
  anObject(obj);
  var numSize = +obj.size;
  // NOTE: If size is undefined, then numSize will be NaN
  // eslint-disable-next-line no-self-compare -- NaN check
  if (numSize != numSize) throw $TypeError('Invalid size');
  return new SetRecord(obj, max(toIntegerOrInfinity(numSize), 0), aCallable(obj.has), aCallable(obj.keys));
};

/***/ }),

/***/ 9990:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var toObject = __webpack_require__(2397);
var floor = Math.floor;
var charAt = uncurryThis(''.charAt);
var replace = uncurryThis(''.replace);
var stringSlice = uncurryThis(''.slice);
// eslint-disable-next-line redos/no-vulnerable -- safe
var SUBSTITUTION_SYMBOLS = /\$([$&'`]|\d{1,2}|<[^>]*>)/g;
var SUBSTITUTION_SYMBOLS_NO_NAMED = /\$([$&'`]|\d{1,2})/g;

// `GetSubstitution` abstract operation
// https://tc39.es/ecma262/#sec-getsubstitution
module.exports = function (matched, str, position, captures, namedCaptures, replacement) {
  var tailPos = position + matched.length;
  var m = captures.length;
  var symbols = SUBSTITUTION_SYMBOLS_NO_NAMED;
  if (namedCaptures !== undefined) {
    namedCaptures = toObject(namedCaptures);
    symbols = SUBSTITUTION_SYMBOLS;
  }
  return replace(replacement, symbols, function (match, ch) {
    var capture;
    switch (charAt(ch, 0)) {
      case '$':
        return '$';
      case '&':
        return matched;
      case '`':
        return stringSlice(str, 0, position);
      case "'":
        return stringSlice(str, tailPos);
      case '<':
        capture = namedCaptures[stringSlice(ch, 1, -1)];
        break;
      default:
        // \d\d?
        var n = +ch;
        if (n === 0) return match;
        if (n > m) {
          var f = floor(n / 10);
          if (f === 0) return match;
          if (f <= m) return captures[f - 1] === undefined ? charAt(ch, 1) : captures[f - 1] + charAt(ch, 1);
          return match;
        }
        capture = captures[n - 1];
    }
    return capture === undefined ? '' : capture;
  });
};

/***/ }),

/***/ 6243:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var check = function (it) {
  return it && it.Math == Math && it;
};

// https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
module.exports =
// eslint-disable-next-line es/no-global-this -- safe
check(typeof globalThis == 'object' && globalThis) || check(typeof window == 'object' && window) ||
// eslint-disable-next-line no-restricted-globals -- safe
check(typeof self == 'object' && self) || check(typeof __webpack_require__.g == 'object' && __webpack_require__.g) ||
// eslint-disable-next-line no-new-func -- fallback
function () {
  return this;
}() || Function('return this')();

/***/ }),

/***/ 8697:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var toObject = __webpack_require__(2397);
var hasOwnProperty = uncurryThis({}.hasOwnProperty);

// `HasOwnProperty` abstract operation
// https://tc39.es/ecma262/#sec-hasownproperty
// eslint-disable-next-line es/no-object-hasown -- safe
module.exports = Object.hasOwn || function hasOwn(it, key) {
  return hasOwnProperty(toObject(it), key);
};

/***/ }),

/***/ 6557:
/***/ ((module) => {

module.exports = {};

/***/ }),

/***/ 1437:
/***/ ((module) => {

module.exports = function (a, b) {
  try {
    // eslint-disable-next-line no-console -- safe
    arguments.length == 1 ? console.error(a) : console.error(a, b);
  } catch (error) {/* empty */}
};

/***/ }),

/***/ 421:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var getBuiltIn = __webpack_require__(8463);
module.exports = getBuiltIn('document', 'documentElement');

/***/ }),

/***/ 9173:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(5444);
var fails = __webpack_require__(4631);
var createElement = __webpack_require__(6431);

// Thanks to IE8 for its funny defineProperty
module.exports = !DESCRIPTORS && !fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty(createElement('div'), 'a', {
    get: function () {
      return 7;
    }
  }).a != 7;
});

/***/ }),

/***/ 5874:
/***/ ((module) => {

// IEEE754 conversions based on https://github.com/feross/ieee754
var $Array = Array;
var abs = Math.abs;
var pow = Math.pow;
var floor = Math.floor;
var log = Math.log;
var LN2 = Math.LN2;
var pack = function (number, mantissaLength, bytes) {
  var buffer = $Array(bytes);
  var exponentLength = bytes * 8 - mantissaLength - 1;
  var eMax = (1 << exponentLength) - 1;
  var eBias = eMax >> 1;
  var rt = mantissaLength === 23 ? pow(2, -24) - pow(2, -77) : 0;
  var sign = number < 0 || number === 0 && 1 / number < 0 ? 1 : 0;
  var index = 0;
  var exponent, mantissa, c;
  number = abs(number);
  // eslint-disable-next-line no-self-compare -- NaN check
  if (number != number || number === Infinity) {
    // eslint-disable-next-line no-self-compare -- NaN check
    mantissa = number != number ? 1 : 0;
    exponent = eMax;
  } else {
    exponent = floor(log(number) / LN2);
    c = pow(2, -exponent);
    if (number * c < 1) {
      exponent--;
      c *= 2;
    }
    if (exponent + eBias >= 1) {
      number += rt / c;
    } else {
      number += rt * pow(2, 1 - eBias);
    }
    if (number * c >= 2) {
      exponent++;
      c /= 2;
    }
    if (exponent + eBias >= eMax) {
      mantissa = 0;
      exponent = eMax;
    } else if (exponent + eBias >= 1) {
      mantissa = (number * c - 1) * pow(2, mantissaLength);
      exponent = exponent + eBias;
    } else {
      mantissa = number * pow(2, eBias - 1) * pow(2, mantissaLength);
      exponent = 0;
    }
  }
  while (mantissaLength >= 8) {
    buffer[index++] = mantissa & 255;
    mantissa /= 256;
    mantissaLength -= 8;
  }
  exponent = exponent << mantissaLength | mantissa;
  exponentLength += mantissaLength;
  while (exponentLength > 0) {
    buffer[index++] = exponent & 255;
    exponent /= 256;
    exponentLength -= 8;
  }
  buffer[--index] |= sign * 128;
  return buffer;
};
var unpack = function (buffer, mantissaLength) {
  var bytes = buffer.length;
  var exponentLength = bytes * 8 - mantissaLength - 1;
  var eMax = (1 << exponentLength) - 1;
  var eBias = eMax >> 1;
  var nBits = exponentLength - 7;
  var index = bytes - 1;
  var sign = buffer[index--];
  var exponent = sign & 127;
  var mantissa;
  sign >>= 7;
  while (nBits > 0) {
    exponent = exponent * 256 + buffer[index--];
    nBits -= 8;
  }
  mantissa = exponent & (1 << -nBits) - 1;
  exponent >>= -nBits;
  nBits += mantissaLength;
  while (nBits > 0) {
    mantissa = mantissa * 256 + buffer[index--];
    nBits -= 8;
  }
  if (exponent === 0) {
    exponent = 1 - eBias;
  } else if (exponent === eMax) {
    return mantissa ? NaN : sign ? -Infinity : Infinity;
  } else {
    mantissa = mantissa + pow(2, mantissaLength);
    exponent = exponent - eBias;
  }
  return (sign ? -1 : 1) * mantissa * pow(2, exponent - mantissaLength);
};
module.exports = {
  pack: pack,
  unpack: unpack
};

/***/ }),

/***/ 3799:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var fails = __webpack_require__(4631);
var classof = __webpack_require__(7384);
var $Object = Object;
var split = uncurryThis(''.split);

// fallback for non-array-like ES3 and non-enumerable old V8 strings
module.exports = fails(function () {
  // throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
  // eslint-disable-next-line no-prototype-builtins -- safe
  return !$Object('z').propertyIsEnumerable(0);
}) ? function (it) {
  return classof(it) == 'String' ? split(it, '') : $Object(it);
} : $Object;

/***/ }),

/***/ 2775:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isCallable = __webpack_require__(6509);
var isObject = __webpack_require__(8154);
var setPrototypeOf = __webpack_require__(4767);

// makes subclassing work correct for wrapped built-ins
module.exports = function ($this, dummy, Wrapper) {
  var NewTarget, NewTargetPrototype;
  if (
  // it can work only with native `setPrototypeOf`
  setPrototypeOf &&
  // we haven't completely correct pre-ES6 way for getting `new.target`, so use this
  isCallable(NewTarget = dummy.constructor) && NewTarget !== Wrapper && isObject(NewTargetPrototype = NewTarget.prototype) && NewTargetPrototype !== Wrapper.prototype) setPrototypeOf($this, NewTargetPrototype);
  return $this;
};

/***/ }),

/***/ 8418:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var isCallable = __webpack_require__(6509);
var store = __webpack_require__(6133);
var functionToString = uncurryThis(Function.toString);

// this helper broken in `core-js@3.4.1-3.4.4`, so we can't use `shared` helper
if (!isCallable(store.inspectSource)) {
  store.inspectSource = function (it) {
    return functionToString(it);
  };
}
module.exports = store.inspectSource;

/***/ }),

/***/ 1048:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(8154);
var createNonEnumerableProperty = __webpack_require__(9763);

// `InstallErrorCause` abstract operation
// https://tc39.es/proposal-error-cause/#sec-errorobjects-install-error-cause
module.exports = function (O, options) {
  if (isObject(options) && 'cause' in options) {
    createNonEnumerableProperty(O, 'cause', options.cause);
  }
};

/***/ }),

/***/ 3653:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var NATIVE_WEAK_MAP = __webpack_require__(1766);
var global = __webpack_require__(6243);
var isObject = __webpack_require__(8154);
var createNonEnumerableProperty = __webpack_require__(9763);
var hasOwn = __webpack_require__(8697);
var shared = __webpack_require__(6133);
var sharedKey = __webpack_require__(7615);
var hiddenKeys = __webpack_require__(6557);
var OBJECT_ALREADY_INITIALIZED = 'Object already initialized';
var TypeError = global.TypeError;
var WeakMap = global.WeakMap;
var set, get, has;
var enforce = function (it) {
  return has(it) ? get(it) : set(it, {});
};
var getterFor = function (TYPE) {
  return function (it) {
    var state;
    if (!isObject(it) || (state = get(it)).type !== TYPE) {
      throw TypeError('Incompatible receiver, ' + TYPE + ' required');
    }
    return state;
  };
};
if (NATIVE_WEAK_MAP || shared.state) {
  var store = shared.state || (shared.state = new WeakMap());
  /* eslint-disable no-self-assign -- prototype methods protection */
  store.get = store.get;
  store.has = store.has;
  store.set = store.set;
  /* eslint-enable no-self-assign -- prototype methods protection */
  set = function (it, metadata) {
    if (store.has(it)) throw TypeError(OBJECT_ALREADY_INITIALIZED);
    metadata.facade = it;
    store.set(it, metadata);
    return metadata;
  };
  get = function (it) {
    return store.get(it) || {};
  };
  has = function (it) {
    return store.has(it);
  };
} else {
  var STATE = sharedKey('state');
  hiddenKeys[STATE] = true;
  set = function (it, metadata) {
    if (hasOwn(it, STATE)) throw TypeError(OBJECT_ALREADY_INITIALIZED);
    metadata.facade = it;
    createNonEnumerableProperty(it, STATE, metadata);
    return metadata;
  };
  get = function (it) {
    return hasOwn(it, STATE) ? it[STATE] : {};
  };
  has = function (it) {
    return hasOwn(it, STATE);
  };
}
module.exports = {
  set: set,
  get: get,
  has: has,
  enforce: enforce,
  getterFor: getterFor
};

/***/ }),

/***/ 1449:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var wellKnownSymbol = __webpack_require__(2091);
var Iterators = __webpack_require__(1941);
var ITERATOR = wellKnownSymbol('iterator');
var ArrayPrototype = Array.prototype;

// check on default Array iterator
module.exports = function (it) {
  return it !== undefined && (Iterators.Array === it || ArrayPrototype[ITERATOR] === it);
};

/***/ }),

/***/ 7920:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var classof = __webpack_require__(7384);

// `IsArray` abstract operation
// https://tc39.es/ecma262/#sec-isarray
// eslint-disable-next-line es/no-array-isarray -- safe
module.exports = Array.isArray || function isArray(argument) {
  return classof(argument) == 'Array';
};

/***/ }),

/***/ 8367:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var classof = __webpack_require__(2611);
module.exports = function (it) {
  var klass = classof(it);
  return klass == 'BigInt64Array' || klass == 'BigUint64Array';
};

/***/ }),

/***/ 6509:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var $documentAll = __webpack_require__(8339);
var documentAll = $documentAll.all;

// `IsCallable` abstract operation
// https://tc39.es/ecma262/#sec-iscallable
module.exports = $documentAll.IS_HTMLDDA ? function (argument) {
  return typeof argument == 'function' || argument === documentAll;
} : function (argument) {
  return typeof argument == 'function';
};

/***/ }),

/***/ 4581:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var fails = __webpack_require__(4631);
var isCallable = __webpack_require__(6509);
var classof = __webpack_require__(2611);
var getBuiltIn = __webpack_require__(8463);
var inspectSource = __webpack_require__(8418);
var noop = function () {/* empty */};
var empty = [];
var construct = getBuiltIn('Reflect', 'construct');
var constructorRegExp = /^\s*(?:class|function)\b/;
var exec = uncurryThis(constructorRegExp.exec);
var INCORRECT_TO_STRING = !constructorRegExp.exec(noop);
var isConstructorModern = function isConstructor(argument) {
  if (!isCallable(argument)) return false;
  try {
    construct(noop, empty, argument);
    return true;
  } catch (error) {
    return false;
  }
};
var isConstructorLegacy = function isConstructor(argument) {
  if (!isCallable(argument)) return false;
  switch (classof(argument)) {
    case 'AsyncFunction':
    case 'GeneratorFunction':
    case 'AsyncGeneratorFunction':
      return false;
  }
  try {
    // we can't check .prototype since constructors produced by .bind haven't it
    // `Function#toString` throws on some built-it function in some legacy engines
    // (for example, `DOMQuad` and similar in FF41-)
    return INCORRECT_TO_STRING || !!exec(constructorRegExp, inspectSource(argument));
  } catch (error) {
    return true;
  }
};
isConstructorLegacy.sham = true;

// `IsConstructor` abstract operation
// https://tc39.es/ecma262/#sec-isconstructor
module.exports = !construct || fails(function () {
  var called;
  return isConstructorModern(isConstructorModern.call) || !isConstructorModern(Object) || !isConstructorModern(function () {
    called = true;
  }) || called;
}) ? isConstructorLegacy : isConstructorModern;

/***/ }),

/***/ 7204:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(4631);
var isCallable = __webpack_require__(6509);
var replacement = /#|\.prototype\./;
var isForced = function (feature, detection) {
  var value = data[normalize(feature)];
  return value == POLYFILL ? true : value == NATIVE ? false : isCallable(detection) ? fails(detection) : !!detection;
};
var normalize = isForced.normalize = function (string) {
  return String(string).replace(replacement, '.').toLowerCase();
};
var data = isForced.data = {};
var NATIVE = isForced.NATIVE = 'N';
var POLYFILL = isForced.POLYFILL = 'P';
module.exports = isForced;

/***/ }),

/***/ 4943:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(8154);
var floor = Math.floor;

// `IsIntegralNumber` abstract operation
// https://tc39.es/ecma262/#sec-isintegralnumber
// eslint-disable-next-line es/no-number-isinteger -- safe
module.exports = Number.isInteger || function isInteger(it) {
  return !isObject(it) && isFinite(it) && floor(it) === it;
};

/***/ }),

/***/ 2797:
/***/ ((module) => {

// we can't use just `it == null` since of `document.all` special case
// https://tc39.es/ecma262/#sec-IsHTMLDDA-internal-slot-aec
module.exports = function (it) {
  return it === null || it === undefined;
};

/***/ }),

/***/ 8154:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isCallable = __webpack_require__(6509);
var $documentAll = __webpack_require__(8339);
var documentAll = $documentAll.all;
module.exports = $documentAll.IS_HTMLDDA ? function (it) {
  return typeof it == 'object' ? it !== null : isCallable(it) || it === documentAll;
} : function (it) {
  return typeof it == 'object' ? it !== null : isCallable(it);
};

/***/ }),

/***/ 1459:
/***/ ((module) => {

module.exports = false;

/***/ }),

/***/ 892:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isObject = __webpack_require__(8154);
var classof = __webpack_require__(7384);
var wellKnownSymbol = __webpack_require__(2091);
var MATCH = wellKnownSymbol('match');

// `IsRegExp` abstract operation
// https://tc39.es/ecma262/#sec-isregexp
module.exports = function (it) {
  var isRegExp;
  return isObject(it) && ((isRegExp = it[MATCH]) !== undefined ? !!isRegExp : classof(it) == 'RegExp');
};

/***/ }),

/***/ 2237:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var getBuiltIn = __webpack_require__(8463);
var isCallable = __webpack_require__(6509);
var isPrototypeOf = __webpack_require__(1649);
var USE_SYMBOL_AS_UID = __webpack_require__(7880);
var $Object = Object;
module.exports = USE_SYMBOL_AS_UID ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  var $Symbol = getBuiltIn('Symbol');
  return isCallable($Symbol) && isPrototypeOf($Symbol.prototype, $Object(it));
};

/***/ }),

/***/ 8243:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
module.exports = function (iterator, fn, $next) {
  var next = $next || iterator.next;
  var step, result;
  while (!(step = call(next, iterator)).done) {
    result = fn(step.value);
    if (result !== undefined) return result;
  }
};

/***/ }),

/***/ 5716:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var bind = __webpack_require__(3160);
var call = __webpack_require__(6277);
var anObject = __webpack_require__(1791);
var tryToString = __webpack_require__(5903);
var isArrayIteratorMethod = __webpack_require__(1449);
var lengthOfArrayLike = __webpack_require__(3534);
var isPrototypeOf = __webpack_require__(1649);
var getIterator = __webpack_require__(1897);
var getIteratorMethod = __webpack_require__(2779);
var iteratorClose = __webpack_require__(1451);
var $TypeError = TypeError;
var Result = function (stopped, result) {
  this.stopped = stopped;
  this.result = result;
};
var ResultPrototype = Result.prototype;
module.exports = function (iterable, unboundFunction, options) {
  var that = options && options.that;
  var AS_ENTRIES = !!(options && options.AS_ENTRIES);
  var IS_RECORD = !!(options && options.IS_RECORD);
  var IS_ITERATOR = !!(options && options.IS_ITERATOR);
  var INTERRUPTED = !!(options && options.INTERRUPTED);
  var fn = bind(unboundFunction, that);
  var iterator, iterFn, index, length, result, next, step;
  var stop = function (condition) {
    if (iterator) iteratorClose(iterator, 'normal', condition);
    return new Result(true, condition);
  };
  var callFn = function (value) {
    if (AS_ENTRIES) {
      anObject(value);
      return INTERRUPTED ? fn(value[0], value[1], stop) : fn(value[0], value[1]);
    }
    return INTERRUPTED ? fn(value, stop) : fn(value);
  };
  if (IS_RECORD) {
    iterator = iterable.iterator;
  } else if (IS_ITERATOR) {
    iterator = iterable;
  } else {
    iterFn = getIteratorMethod(iterable);
    if (!iterFn) throw $TypeError(tryToString(iterable) + ' is not iterable');
    // optimisation for array iterators
    if (isArrayIteratorMethod(iterFn)) {
      for (index = 0, length = lengthOfArrayLike(iterable); length > index; index++) {
        result = callFn(iterable[index]);
        if (result && isPrototypeOf(ResultPrototype, result)) return result;
      }
      return new Result(false);
    }
    iterator = getIterator(iterable, iterFn);
  }
  next = IS_RECORD ? iterable.next : iterator.next;
  while (!(step = call(next, iterator)).done) {
    try {
      result = callFn(step.value);
    } catch (error) {
      iteratorClose(iterator, 'throw', error);
    }
    if (typeof result == 'object' && result && isPrototypeOf(ResultPrototype, result)) return result;
  }
  return new Result(false);
};

/***/ }),

/***/ 1451:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var anObject = __webpack_require__(1791);
var getMethod = __webpack_require__(7750);
module.exports = function (iterator, kind, value) {
  var innerResult, innerError;
  anObject(iterator);
  try {
    innerResult = getMethod(iterator, 'return');
    if (!innerResult) {
      if (kind === 'throw') throw value;
      return value;
    }
    innerResult = call(innerResult, iterator);
  } catch (error) {
    innerError = true;
    innerResult = error;
  }
  if (kind === 'throw') throw value;
  if (innerError) throw innerResult;
  anObject(innerResult);
  return value;
};

/***/ }),

/***/ 5138:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var IteratorPrototype = (__webpack_require__(7937).IteratorPrototype);
var create = __webpack_require__(8336);
var createPropertyDescriptor = __webpack_require__(6012);
var setToStringTag = __webpack_require__(7047);
var Iterators = __webpack_require__(1941);
var returnThis = function () {
  return this;
};
module.exports = function (IteratorConstructor, NAME, next, ENUMERABLE_NEXT) {
  var TO_STRING_TAG = NAME + ' Iterator';
  IteratorConstructor.prototype = create(IteratorPrototype, {
    next: createPropertyDescriptor(+!ENUMERABLE_NEXT, next)
  });
  setToStringTag(IteratorConstructor, TO_STRING_TAG, false, true);
  Iterators[TO_STRING_TAG] = returnThis;
  return IteratorConstructor;
};

/***/ }),

/***/ 6766:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(6277);
var create = __webpack_require__(8336);
var createNonEnumerableProperty = __webpack_require__(9763);
var defineBuiltIns = __webpack_require__(8575);
var wellKnownSymbol = __webpack_require__(2091);
var InternalStateModule = __webpack_require__(3653);
var getMethod = __webpack_require__(7750);
var IteratorPrototype = (__webpack_require__(7937).IteratorPrototype);
var createIterResultObject = __webpack_require__(9097);
var iteratorClose = __webpack_require__(1451);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var ITERATOR_HELPER = 'IteratorHelper';
var WRAP_FOR_VALID_ITERATOR = 'WrapForValidIterator';
var setInternalState = InternalStateModule.set;
var createIteratorProxyPrototype = function (IS_ITERATOR) {
  var getInternalState = InternalStateModule.getterFor(IS_ITERATOR ? WRAP_FOR_VALID_ITERATOR : ITERATOR_HELPER);
  return defineBuiltIns(create(IteratorPrototype), {
    next: function next() {
      var state = getInternalState(this);
      // for simplification:
      //   for `%WrapForValidIteratorPrototype%.next` our `nextHandler` returns `IterResultObject`
      //   for `%IteratorHelperPrototype%.next` - just a value
      if (IS_ITERATOR) return state.nextHandler();
      try {
        var result = state.done ? undefined : state.nextHandler();
        return createIterResultObject(result, state.done);
      } catch (error) {
        state.done = true;
        throw error;
      }
    },
    'return': function () {
      var state = getInternalState(this);
      var iterator = state.iterator;
      state.done = true;
      if (IS_ITERATOR) {
        var returnMethod = getMethod(iterator, 'return');
        return returnMethod ? call(returnMethod, iterator) : createIterResultObject(undefined, true);
      }
      if (state.inner) try {
        iteratorClose(state.inner.iterator, 'normal');
      } catch (error) {
        return iteratorClose(iterator, 'throw', error);
      }
      iteratorClose(iterator, 'normal');
      return createIterResultObject(undefined, true);
    }
  });
};
var WrapForValidIteratorPrototype = createIteratorProxyPrototype(true);
var IteratorHelperPrototype = createIteratorProxyPrototype(false);
createNonEnumerableProperty(IteratorHelperPrototype, TO_STRING_TAG, 'Iterator Helper');
module.exports = function (nextHandler, IS_ITERATOR) {
  var IteratorProxy = function Iterator(record, state) {
    if (state) {
      state.iterator = record.iterator;
      state.next = record.next;
    } else state = record;
    state.type = IS_ITERATOR ? WRAP_FOR_VALID_ITERATOR : ITERATOR_HELPER;
    state.nextHandler = nextHandler;
    state.counter = 0;
    state.done = false;
    setInternalState(this, state);
  };
  IteratorProxy.prototype = IS_ITERATOR ? WrapForValidIteratorPrototype : IteratorHelperPrototype;
  return IteratorProxy;
};

/***/ }),

/***/ 1985:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
var getIteratorDirect = __webpack_require__(3791);
var createIteratorProxy = __webpack_require__(6766);
var callWithSafeIterationClosing = __webpack_require__(4359);
var IteratorProxy = createIteratorProxy(function () {
  var iterator = this.iterator;
  var result = anObject(call(this.next, iterator));
  var done = this.done = !!result.done;
  if (!done) return callWithSafeIterationClosing(iterator, this.mapper, [result.value, this.counter++], true);
});

// `Iterator.prototype.map` method
// https://github.com/tc39/proposal-iterator-helpers
module.exports = function map(mapper) {
  return new IteratorProxy(getIteratorDirect(this), {
    mapper: aCallable(mapper)
  });
};

/***/ }),

/***/ 7937:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var fails = __webpack_require__(4631);
var isCallable = __webpack_require__(6509);
var isObject = __webpack_require__(8154);
var create = __webpack_require__(8336);
var getPrototypeOf = __webpack_require__(5355);
var defineBuiltIn = __webpack_require__(9264);
var wellKnownSymbol = __webpack_require__(2091);
var IS_PURE = __webpack_require__(1459);
var ITERATOR = wellKnownSymbol('iterator');
var BUGGY_SAFARI_ITERATORS = false;

// `%IteratorPrototype%` object
// https://tc39.es/ecma262/#sec-%iteratorprototype%-object
var IteratorPrototype, PrototypeOfArrayIteratorPrototype, arrayIterator;

/* eslint-disable es/no-array-prototype-keys -- safe */
if ([].keys) {
  arrayIterator = [].keys();
  // Safari 8 has buggy iterators w/o `next`
  if (!('next' in arrayIterator)) BUGGY_SAFARI_ITERATORS = true;else {
    PrototypeOfArrayIteratorPrototype = getPrototypeOf(getPrototypeOf(arrayIterator));
    if (PrototypeOfArrayIteratorPrototype !== Object.prototype) IteratorPrototype = PrototypeOfArrayIteratorPrototype;
  }
}
var NEW_ITERATOR_PROTOTYPE = !isObject(IteratorPrototype) || fails(function () {
  var test = {};
  // FF44- legacy iterators case
  return IteratorPrototype[ITERATOR].call(test) !== test;
});
if (NEW_ITERATOR_PROTOTYPE) IteratorPrototype = {};else if (IS_PURE) IteratorPrototype = create(IteratorPrototype);

// `%IteratorPrototype%[@@iterator]()` method
// https://tc39.es/ecma262/#sec-%iteratorprototype%-@@iterator
if (!isCallable(IteratorPrototype[ITERATOR])) {
  defineBuiltIn(IteratorPrototype, ITERATOR, function () {
    return this;
  });
}
module.exports = {
  IteratorPrototype: IteratorPrototype,
  BUGGY_SAFARI_ITERATORS: BUGGY_SAFARI_ITERATORS
};

/***/ }),

/***/ 1941:
/***/ ((module) => {

module.exports = {};

/***/ }),

/***/ 3534:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toLength = __webpack_require__(7590);

// `LengthOfArrayLike` abstract operation
// https://tc39.es/ecma262/#sec-lengthofarraylike
module.exports = function (obj) {
  return toLength(obj.length);
};

/***/ }),

/***/ 3123:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var fails = __webpack_require__(4631);
var isCallable = __webpack_require__(6509);
var hasOwn = __webpack_require__(8697);
var DESCRIPTORS = __webpack_require__(5444);
var CONFIGURABLE_FUNCTION_NAME = (__webpack_require__(1158).CONFIGURABLE);
var inspectSource = __webpack_require__(8418);
var InternalStateModule = __webpack_require__(3653);
var enforceInternalState = InternalStateModule.enforce;
var getInternalState = InternalStateModule.get;
var $String = String;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var defineProperty = Object.defineProperty;
var stringSlice = uncurryThis(''.slice);
var replace = uncurryThis(''.replace);
var join = uncurryThis([].join);
var CONFIGURABLE_LENGTH = DESCRIPTORS && !fails(function () {
  return defineProperty(function () {/* empty */}, 'length', {
    value: 8
  }).length !== 8;
});
var TEMPLATE = String(String).split('String');
var makeBuiltIn = module.exports = function (value, name, options) {
  if (stringSlice($String(name), 0, 7) === 'Symbol(') {
    name = '[' + replace($String(name), /^Symbol\(([^)]*)\)/, '$1') + ']';
  }
  if (options && options.getter) name = 'get ' + name;
  if (options && options.setter) name = 'set ' + name;
  if (!hasOwn(value, 'name') || CONFIGURABLE_FUNCTION_NAME && value.name !== name) {
    if (DESCRIPTORS) defineProperty(value, 'name', {
      value: name,
      configurable: true
    });else value.name = name;
  }
  if (CONFIGURABLE_LENGTH && options && hasOwn(options, 'arity') && value.length !== options.arity) {
    defineProperty(value, 'length', {
      value: options.arity
    });
  }
  try {
    if (options && hasOwn(options, 'constructor') && options.constructor) {
      if (DESCRIPTORS) defineProperty(value, 'prototype', {
        writable: false
      });
      // in V8 ~ Chrome 53, prototypes of some methods, like `Array.prototype.values`, are non-writable
    } else if (value.prototype) value.prototype = undefined;
  } catch (error) {/* empty */}
  var state = enforceInternalState(value);
  if (!hasOwn(state, 'source')) {
    state.source = join(TEMPLATE, typeof name == 'string' ? name : '');
  }
  return value;
};

// add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
// eslint-disable-next-line no-extend-native -- required
Function.prototype.toString = makeBuiltIn(function toString() {
  return isCallable(this) && getInternalState(this).source || inspectSource(this);
}, 'toString');

/***/ }),

/***/ 6096:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);

// eslint-disable-next-line es/no-map -- safe
var MapPrototype = Map.prototype;
module.exports = {
  // eslint-disable-next-line es/no-map -- safe
  Map: Map,
  set: uncurryThis(MapPrototype.set),
  get: uncurryThis(MapPrototype.get),
  has: uncurryThis(MapPrototype.has),
  remove: uncurryThis(MapPrototype['delete']),
  proto: MapPrototype
};

/***/ }),

/***/ 7293:
/***/ ((module) => {

var ceil = Math.ceil;
var floor = Math.floor;

// `Math.trunc` method
// https://tc39.es/ecma262/#sec-math.trunc
// eslint-disable-next-line es/no-math-trunc -- safe
module.exports = Math.trunc || function trunc(x) {
  var n = +x;
  return (n > 0 ? floor : ceil)(n);
};

/***/ }),

/***/ 1819:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var bind = __webpack_require__(3160);
var getOwnPropertyDescriptor = (__webpack_require__(7515).f);
var macrotask = (__webpack_require__(1457).set);
var Queue = __webpack_require__(9633);
var IS_IOS = __webpack_require__(2815);
var IS_IOS_PEBBLE = __webpack_require__(9604);
var IS_WEBOS_WEBKIT = __webpack_require__(7093);
var IS_NODE = __webpack_require__(5816);
var MutationObserver = global.MutationObserver || global.WebKitMutationObserver;
var document = global.document;
var process = global.process;
var Promise = global.Promise;
// Node.js 11 shows ExperimentalWarning on getting `queueMicrotask`
var queueMicrotaskDescriptor = getOwnPropertyDescriptor(global, 'queueMicrotask');
var microtask = queueMicrotaskDescriptor && queueMicrotaskDescriptor.value;
var notify, toggle, node, promise, then;

// modern engines have queueMicrotask method
if (!microtask) {
  var queue = new Queue();
  var flush = function () {
    var parent, fn;
    if (IS_NODE && (parent = process.domain)) parent.exit();
    while (fn = queue.get()) try {
      fn();
    } catch (error) {
      if (queue.head) notify();
      throw error;
    }
    if (parent) parent.enter();
  };

  // browsers with MutationObserver, except iOS - https://github.com/zloirock/core-js/issues/339
  // also except WebOS Webkit https://github.com/zloirock/core-js/issues/898
  if (!IS_IOS && !IS_NODE && !IS_WEBOS_WEBKIT && MutationObserver && document) {
    toggle = true;
    node = document.createTextNode('');
    new MutationObserver(flush).observe(node, {
      characterData: true
    });
    notify = function () {
      node.data = toggle = !toggle;
    };
    // environments with maybe non-completely correct, but existent Promise
  } else if (!IS_IOS_PEBBLE && Promise && Promise.resolve) {
    // Promise.resolve without an argument throws an error in LG WebOS 2
    promise = Promise.resolve(undefined);
    // workaround of WebKit ~ iOS Safari 10.1 bug
    promise.constructor = Promise;
    then = bind(promise.then, promise);
    notify = function () {
      then(flush);
    };
    // Node.js without promises
  } else if (IS_NODE) {
    notify = function () {
      process.nextTick(flush);
    };
    // for other environments - macrotask based on:
    // - setImmediate
    // - MessageChannel
    // - window.postMessage
    // - onreadystatechange
    // - setTimeout
  } else {
    // `webpack` dev server bug on IE global methods - use bind(fn, global)
    macrotask = bind(macrotask, global);
    notify = function () {
      macrotask(flush);
    };
  }
  microtask = function (fn) {
    if (!queue.head) notify();
    queue.add(fn);
  };
}
module.exports = microtask;

/***/ }),

/***/ 9859:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aCallable = __webpack_require__(2978);
var $TypeError = TypeError;
var PromiseCapability = function (C) {
  var resolve, reject;
  this.promise = new C(function ($$resolve, $$reject) {
    if (resolve !== undefined || reject !== undefined) throw $TypeError('Bad Promise constructor');
    resolve = $$resolve;
    reject = $$reject;
  });
  this.resolve = aCallable(resolve);
  this.reject = aCallable(reject);
};

// `NewPromiseCapability` abstract operation
// https://tc39.es/ecma262/#sec-newpromisecapability
module.exports.f = function (C) {
  return new PromiseCapability(C);
};

/***/ }),

/***/ 6851:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toString = __webpack_require__(5479);
module.exports = function (argument, $default) {
  return argument === undefined ? arguments.length < 2 ? '' : $default : toString(argument);
};

/***/ }),

/***/ 8349:
/***/ ((module) => {

var $RangeError = RangeError;
module.exports = function (it) {
  // eslint-disable-next-line no-self-compare -- NaN check
  if (it === it) return it;
  throw $RangeError('NaN is not allowed');
};

/***/ }),

/***/ 8336:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* global ActiveXObject -- old IE, WSH */
var anObject = __webpack_require__(1791);
var definePropertiesModule = __webpack_require__(4761);
var enumBugKeys = __webpack_require__(9119);
var hiddenKeys = __webpack_require__(6557);
var html = __webpack_require__(421);
var documentCreateElement = __webpack_require__(6431);
var sharedKey = __webpack_require__(7615);
var GT = '>';
var LT = '<';
var PROTOTYPE = 'prototype';
var SCRIPT = 'script';
var IE_PROTO = sharedKey('IE_PROTO');
var EmptyConstructor = function () {/* empty */};
var scriptTag = function (content) {
  return LT + SCRIPT + GT + content + LT + '/' + SCRIPT + GT;
};

// Create object with fake `null` prototype: use ActiveX Object with cleared prototype
var NullProtoObjectViaActiveX = function (activeXDocument) {
  activeXDocument.write(scriptTag(''));
  activeXDocument.close();
  var temp = activeXDocument.parentWindow.Object;
  activeXDocument = null; // avoid memory leak
  return temp;
};

// Create object with fake `null` prototype: use iframe Object with cleared prototype
var NullProtoObjectViaIFrame = function () {
  // Thrash, waste and sodomy: IE GC bug
  var iframe = documentCreateElement('iframe');
  var JS = 'java' + SCRIPT + ':';
  var iframeDocument;
  iframe.style.display = 'none';
  html.appendChild(iframe);
  // https://github.com/zloirock/core-js/issues/475
  iframe.src = String(JS);
  iframeDocument = iframe.contentWindow.document;
  iframeDocument.open();
  iframeDocument.write(scriptTag('document.F=Object'));
  iframeDocument.close();
  return iframeDocument.F;
};

// Check for document.domain and active x support
// No need to use active x approach when document.domain is not set
// see https://github.com/es-shims/es5-shim/issues/150
// variation of https://github.com/kitcambridge/es5-shim/commit/4f738ac066346
// avoid IE GC bug
var activeXDocument;
var NullProtoObject = function () {
  try {
    activeXDocument = new ActiveXObject('htmlfile');
  } catch (error) {/* ignore */}
  NullProtoObject = typeof document != 'undefined' ? document.domain && activeXDocument ? NullProtoObjectViaActiveX(activeXDocument) // old IE
  : NullProtoObjectViaIFrame() : NullProtoObjectViaActiveX(activeXDocument); // WSH
  var length = enumBugKeys.length;
  while (length--) delete NullProtoObject[PROTOTYPE][enumBugKeys[length]];
  return NullProtoObject();
};
hiddenKeys[IE_PROTO] = true;

// `Object.create` method
// https://tc39.es/ecma262/#sec-object.create
// eslint-disable-next-line es/no-object-create -- safe
module.exports = Object.create || function create(O, Properties) {
  var result;
  if (O !== null) {
    EmptyConstructor[PROTOTYPE] = anObject(O);
    result = new EmptyConstructor();
    EmptyConstructor[PROTOTYPE] = null;
    // add "__proto__" for Object.getPrototypeOf polyfill
    result[IE_PROTO] = O;
  } else result = NullProtoObject();
  return Properties === undefined ? result : definePropertiesModule.f(result, Properties);
};

/***/ }),

/***/ 4761:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(5444);
var V8_PROTOTYPE_DEFINE_BUG = __webpack_require__(726);
var definePropertyModule = __webpack_require__(6489);
var anObject = __webpack_require__(1791);
var toIndexedObject = __webpack_require__(2445);
var objectKeys = __webpack_require__(2440);

// `Object.defineProperties` method
// https://tc39.es/ecma262/#sec-object.defineproperties
// eslint-disable-next-line es/no-object-defineproperties -- safe
exports.f = DESCRIPTORS && !V8_PROTOTYPE_DEFINE_BUG ? Object.defineProperties : function defineProperties(O, Properties) {
  anObject(O);
  var props = toIndexedObject(Properties);
  var keys = objectKeys(Properties);
  var length = keys.length;
  var index = 0;
  var key;
  while (length > index) definePropertyModule.f(O, key = keys[index++], props[key]);
  return O;
};

/***/ }),

/***/ 6489:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(5444);
var IE8_DOM_DEFINE = __webpack_require__(9173);
var V8_PROTOTYPE_DEFINE_BUG = __webpack_require__(726);
var anObject = __webpack_require__(1791);
var toPropertyKey = __webpack_require__(2129);
var $TypeError = TypeError;
// eslint-disable-next-line es/no-object-defineproperty -- safe
var $defineProperty = Object.defineProperty;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var ENUMERABLE = 'enumerable';
var CONFIGURABLE = 'configurable';
var WRITABLE = 'writable';

// `Object.defineProperty` method
// https://tc39.es/ecma262/#sec-object.defineproperty
exports.f = DESCRIPTORS ? V8_PROTOTYPE_DEFINE_BUG ? function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPropertyKey(P);
  anObject(Attributes);
  if (typeof O === 'function' && P === 'prototype' && 'value' in Attributes && WRITABLE in Attributes && !Attributes[WRITABLE]) {
    var current = $getOwnPropertyDescriptor(O, P);
    if (current && current[WRITABLE]) {
      O[P] = Attributes.value;
      Attributes = {
        configurable: CONFIGURABLE in Attributes ? Attributes[CONFIGURABLE] : current[CONFIGURABLE],
        enumerable: ENUMERABLE in Attributes ? Attributes[ENUMERABLE] : current[ENUMERABLE],
        writable: false
      };
    }
  }
  return $defineProperty(O, P, Attributes);
} : $defineProperty : function defineProperty(O, P, Attributes) {
  anObject(O);
  P = toPropertyKey(P);
  anObject(Attributes);
  if (IE8_DOM_DEFINE) try {
    return $defineProperty(O, P, Attributes);
  } catch (error) {/* empty */}
  if ('get' in Attributes || 'set' in Attributes) throw $TypeError('Accessors not supported');
  if ('value' in Attributes) O[P] = Attributes.value;
  return O;
};

/***/ }),

/***/ 7515:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(5444);
var call = __webpack_require__(6277);
var propertyIsEnumerableModule = __webpack_require__(3357);
var createPropertyDescriptor = __webpack_require__(6012);
var toIndexedObject = __webpack_require__(2445);
var toPropertyKey = __webpack_require__(2129);
var hasOwn = __webpack_require__(8697);
var IE8_DOM_DEFINE = __webpack_require__(9173);

// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var $getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// `Object.getOwnPropertyDescriptor` method
// https://tc39.es/ecma262/#sec-object.getownpropertydescriptor
exports.f = DESCRIPTORS ? $getOwnPropertyDescriptor : function getOwnPropertyDescriptor(O, P) {
  O = toIndexedObject(O);
  P = toPropertyKey(P);
  if (IE8_DOM_DEFINE) try {
    return $getOwnPropertyDescriptor(O, P);
  } catch (error) {/* empty */}
  if (hasOwn(O, P)) return createPropertyDescriptor(!call(propertyIsEnumerableModule.f, O, P), O[P]);
};

/***/ }),

/***/ 24:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var internalObjectKeys = __webpack_require__(5436);
var enumBugKeys = __webpack_require__(9119);
var hiddenKeys = enumBugKeys.concat('length', 'prototype');

// `Object.getOwnPropertyNames` method
// https://tc39.es/ecma262/#sec-object.getownpropertynames
// eslint-disable-next-line es/no-object-getownpropertynames -- safe
exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return internalObjectKeys(O, hiddenKeys);
};

/***/ }),

/***/ 637:
/***/ ((__unused_webpack_module, exports) => {

// eslint-disable-next-line es/no-object-getownpropertysymbols -- safe
exports.f = Object.getOwnPropertySymbols;

/***/ }),

/***/ 5355:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var hasOwn = __webpack_require__(8697);
var isCallable = __webpack_require__(6509);
var toObject = __webpack_require__(2397);
var sharedKey = __webpack_require__(7615);
var CORRECT_PROTOTYPE_GETTER = __webpack_require__(1899);
var IE_PROTO = sharedKey('IE_PROTO');
var $Object = Object;
var ObjectPrototype = $Object.prototype;

// `Object.getPrototypeOf` method
// https://tc39.es/ecma262/#sec-object.getprototypeof
// eslint-disable-next-line es/no-object-getprototypeof -- safe
module.exports = CORRECT_PROTOTYPE_GETTER ? $Object.getPrototypeOf : function (O) {
  var object = toObject(O);
  if (hasOwn(object, IE_PROTO)) return object[IE_PROTO];
  var constructor = object.constructor;
  if (isCallable(constructor) && object instanceof constructor) {
    return constructor.prototype;
  }
  return object instanceof $Object ? ObjectPrototype : null;
};

/***/ }),

/***/ 1649:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
module.exports = uncurryThis({}.isPrototypeOf);

/***/ }),

/***/ 5436:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var hasOwn = __webpack_require__(8697);
var toIndexedObject = __webpack_require__(2445);
var indexOf = (__webpack_require__(1078).indexOf);
var hiddenKeys = __webpack_require__(6557);
var push = uncurryThis([].push);
module.exports = function (object, names) {
  var O = toIndexedObject(object);
  var i = 0;
  var result = [];
  var key;
  for (key in O) !hasOwn(hiddenKeys, key) && hasOwn(O, key) && push(result, key);
  // Don't enum bug & hidden keys
  while (names.length > i) if (hasOwn(O, key = names[i++])) {
    ~indexOf(result, key) || push(result, key);
  }
  return result;
};

/***/ }),

/***/ 2440:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var internalObjectKeys = __webpack_require__(5436);
var enumBugKeys = __webpack_require__(9119);

// `Object.keys` method
// https://tc39.es/ecma262/#sec-object.keys
// eslint-disable-next-line es/no-object-keys -- safe
module.exports = Object.keys || function keys(O) {
  return internalObjectKeys(O, enumBugKeys);
};

/***/ }),

/***/ 3357:
/***/ ((__unused_webpack_module, exports) => {

"use strict";


var $propertyIsEnumerable = {}.propertyIsEnumerable;
// eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// Nashorn ~ JDK8 bug
var NASHORN_BUG = getOwnPropertyDescriptor && !$propertyIsEnumerable.call({
  1: 2
}, 1);

// `Object.prototype.propertyIsEnumerable` method implementation
// https://tc39.es/ecma262/#sec-object.prototype.propertyisenumerable
exports.f = NASHORN_BUG ? function propertyIsEnumerable(V) {
  var descriptor = getOwnPropertyDescriptor(this, V);
  return !!descriptor && descriptor.enumerable;
} : $propertyIsEnumerable;

/***/ }),

/***/ 4767:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* eslint-disable no-proto -- safe */
var uncurryThisAccessor = __webpack_require__(5658);
var anObject = __webpack_require__(1791);
var aPossiblePrototype = __webpack_require__(6346);

// `Object.setPrototypeOf` method
// https://tc39.es/ecma262/#sec-object.setprototypeof
// Works with __proto__ only. Old v8 can't work with null proto objects.
// eslint-disable-next-line es/no-object-setprototypeof -- safe
module.exports = Object.setPrototypeOf || ('__proto__' in {} ? function () {
  var CORRECT_SETTER = false;
  var test = {};
  var setter;
  try {
    setter = uncurryThisAccessor(Object.prototype, '__proto__', 'set');
    setter(test, []);
    CORRECT_SETTER = test instanceof Array;
  } catch (error) {/* empty */}
  return function setPrototypeOf(O, proto) {
    anObject(O);
    aPossiblePrototype(proto);
    if (CORRECT_SETTER) setter(O, proto);else O.__proto__ = proto;
    return O;
  };
}() : undefined);

/***/ }),

/***/ 342:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var isCallable = __webpack_require__(6509);
var isObject = __webpack_require__(8154);
var $TypeError = TypeError;

// `OrdinaryToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-ordinarytoprimitive
module.exports = function (input, pref) {
  var fn, val;
  if (pref === 'string' && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
  if (isCallable(fn = input.valueOf) && !isObject(val = call(fn, input))) return val;
  if (pref !== 'string' && isCallable(fn = input.toString) && !isObject(val = call(fn, input))) return val;
  throw $TypeError("Can't convert object to primitive value");
};

/***/ }),

/***/ 4927:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var getBuiltIn = __webpack_require__(8463);
var uncurryThis = __webpack_require__(8712);
var getOwnPropertyNamesModule = __webpack_require__(24);
var getOwnPropertySymbolsModule = __webpack_require__(637);
var anObject = __webpack_require__(1791);
var concat = uncurryThis([].concat);

// all object keys, includes non-enumerable and symbols
module.exports = getBuiltIn('Reflect', 'ownKeys') || function ownKeys(it) {
  var keys = getOwnPropertyNamesModule.f(anObject(it));
  var getOwnPropertySymbols = getOwnPropertySymbolsModule.f;
  return getOwnPropertySymbols ? concat(keys, getOwnPropertySymbols(it)) : keys;
};

/***/ }),

/***/ 5591:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
module.exports = global;

/***/ }),

/***/ 6631:
/***/ ((module) => {

module.exports = function (exec) {
  try {
    return {
      error: false,
      value: exec()
    };
  } catch (error) {
    return {
      error: true,
      value: error
    };
  }
};

/***/ }),

/***/ 4652:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var NativePromiseConstructor = __webpack_require__(574);
var isCallable = __webpack_require__(6509);
var isForced = __webpack_require__(7204);
var inspectSource = __webpack_require__(8418);
var wellKnownSymbol = __webpack_require__(2091);
var IS_BROWSER = __webpack_require__(3954);
var IS_DENO = __webpack_require__(6524);
var IS_PURE = __webpack_require__(1459);
var V8_VERSION = __webpack_require__(8820);
var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;
var SPECIES = wellKnownSymbol('species');
var SUBCLASSING = false;
var NATIVE_PROMISE_REJECTION_EVENT = isCallable(global.PromiseRejectionEvent);
var FORCED_PROMISE_CONSTRUCTOR = isForced('Promise', function () {
  var PROMISE_CONSTRUCTOR_SOURCE = inspectSource(NativePromiseConstructor);
  var GLOBAL_CORE_JS_PROMISE = PROMISE_CONSTRUCTOR_SOURCE !== String(NativePromiseConstructor);
  // V8 6.6 (Node 10 and Chrome 66) have a bug with resolving custom thenables
  // https://bugs.chromium.org/p/chromium/issues/detail?id=830565
  // We can't detect it synchronously, so just check versions
  if (!GLOBAL_CORE_JS_PROMISE && V8_VERSION === 66) return true;
  // We need Promise#{ catch, finally } in the pure version for preventing prototype pollution
  if (IS_PURE && !(NativePromisePrototype['catch'] && NativePromisePrototype['finally'])) return true;
  // We can't use @@species feature detection in V8 since it causes
  // deoptimization and performance degradation
  // https://github.com/zloirock/core-js/issues/679
  if (!V8_VERSION || V8_VERSION < 51 || !/native code/.test(PROMISE_CONSTRUCTOR_SOURCE)) {
    // Detect correctness of subclassing with @@species support
    var promise = new NativePromiseConstructor(function (resolve) {
      resolve(1);
    });
    var FakePromise = function (exec) {
      exec(function () {/* empty */}, function () {/* empty */});
    };
    var constructor = promise.constructor = {};
    constructor[SPECIES] = FakePromise;
    SUBCLASSING = promise.then(function () {/* empty */}) instanceof FakePromise;
    if (!SUBCLASSING) return true;
    // Unhandled rejections tracking support, NodeJS Promise without it fails @@species test
  }
  return !GLOBAL_CORE_JS_PROMISE && (IS_BROWSER || IS_DENO) && !NATIVE_PROMISE_REJECTION_EVENT;
});
module.exports = {
  CONSTRUCTOR: FORCED_PROMISE_CONSTRUCTOR,
  REJECTION_EVENT: NATIVE_PROMISE_REJECTION_EVENT,
  SUBCLASSING: SUBCLASSING
};

/***/ }),

/***/ 574:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
module.exports = global.Promise;

/***/ }),

/***/ 9126:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var anObject = __webpack_require__(1791);
var isObject = __webpack_require__(8154);
var newPromiseCapability = __webpack_require__(9859);
module.exports = function (C, x) {
  anObject(C);
  if (isObject(x) && x.constructor === C) return x;
  var promiseCapability = newPromiseCapability.f(C);
  var resolve = promiseCapability.resolve;
  resolve(x);
  return promiseCapability.promise;
};

/***/ }),

/***/ 4897:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var NativePromiseConstructor = __webpack_require__(574);
var checkCorrectnessOfIteration = __webpack_require__(1508);
var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(4652).CONSTRUCTOR);
module.exports = FORCED_PROMISE_CONSTRUCTOR || !checkCorrectnessOfIteration(function (iterable) {
  NativePromiseConstructor.all(iterable).then(undefined, function () {/* empty */});
});

/***/ }),

/***/ 2200:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var defineProperty = (__webpack_require__(6489).f);
module.exports = function (Target, Source, key) {
  key in Target || defineProperty(Target, key, {
    configurable: true,
    get: function () {
      return Source[key];
    },
    set: function (it) {
      Source[key] = it;
    }
  });
};

/***/ }),

/***/ 9633:
/***/ ((module) => {

var Queue = function () {
  this.head = null;
  this.tail = null;
};
Queue.prototype = {
  add: function (item) {
    var entry = {
      item: item,
      next: null
    };
    var tail = this.tail;
    if (tail) tail.next = entry;else this.head = entry;
    this.tail = entry;
  },
  get: function () {
    var entry = this.head;
    if (entry) {
      var next = this.head = entry.next;
      if (next === null) this.tail = null;
      return entry.item;
    }
  }
};
module.exports = Queue;

/***/ }),

/***/ 9397:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var anObject = __webpack_require__(1791);
var isCallable = __webpack_require__(6509);
var classof = __webpack_require__(7384);
var regexpExec = __webpack_require__(4899);
var $TypeError = TypeError;

// `RegExpExec` abstract operation
// https://tc39.es/ecma262/#sec-regexpexec
module.exports = function (R, S) {
  var exec = R.exec;
  if (isCallable(exec)) {
    var result = call(exec, R, S);
    if (result !== null) anObject(result);
    return result;
  }
  if (classof(R) === 'RegExp') return call(regexpExec, R, S);
  throw $TypeError('RegExp#exec called on incompatible receiver');
};

/***/ }),

/***/ 4899:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


/* eslint-disable regexp/no-empty-capturing-group, regexp/no-empty-group, regexp/no-lazy-ends -- testing */
/* eslint-disable regexp/no-useless-quantifier -- testing */
var call = __webpack_require__(6277);
var uncurryThis = __webpack_require__(8712);
var toString = __webpack_require__(5479);
var regexpFlags = __webpack_require__(7939);
var stickyHelpers = __webpack_require__(5685);
var shared = __webpack_require__(3513);
var create = __webpack_require__(8336);
var getInternalState = (__webpack_require__(3653).get);
var UNSUPPORTED_DOT_ALL = __webpack_require__(8939);
var UNSUPPORTED_NCG = __webpack_require__(70);
var nativeReplace = shared('native-string-replace', String.prototype.replace);
var nativeExec = RegExp.prototype.exec;
var patchedExec = nativeExec;
var charAt = uncurryThis(''.charAt);
var indexOf = uncurryThis(''.indexOf);
var replace = uncurryThis(''.replace);
var stringSlice = uncurryThis(''.slice);
var UPDATES_LAST_INDEX_WRONG = function () {
  var re1 = /a/;
  var re2 = /b*/g;
  call(nativeExec, re1, 'a');
  call(nativeExec, re2, 'a');
  return re1.lastIndex !== 0 || re2.lastIndex !== 0;
}();
var UNSUPPORTED_Y = stickyHelpers.BROKEN_CARET;

// nonparticipating capturing group, copied from es5-shim's String#split patch.
var NPCG_INCLUDED = /()??/.exec('')[1] !== undefined;
var PATCH = UPDATES_LAST_INDEX_WRONG || NPCG_INCLUDED || UNSUPPORTED_Y || UNSUPPORTED_DOT_ALL || UNSUPPORTED_NCG;
if (PATCH) {
  patchedExec = function exec(string) {
    var re = this;
    var state = getInternalState(re);
    var str = toString(string);
    var raw = state.raw;
    var result, reCopy, lastIndex, match, i, object, group;
    if (raw) {
      raw.lastIndex = re.lastIndex;
      result = call(patchedExec, raw, str);
      re.lastIndex = raw.lastIndex;
      return result;
    }
    var groups = state.groups;
    var sticky = UNSUPPORTED_Y && re.sticky;
    var flags = call(regexpFlags, re);
    var source = re.source;
    var charsAdded = 0;
    var strCopy = str;
    if (sticky) {
      flags = replace(flags, 'y', '');
      if (indexOf(flags, 'g') === -1) {
        flags += 'g';
      }
      strCopy = stringSlice(str, re.lastIndex);
      // Support anchored sticky behavior.
      if (re.lastIndex > 0 && (!re.multiline || re.multiline && charAt(str, re.lastIndex - 1) !== '\n')) {
        source = '(?: ' + source + ')';
        strCopy = ' ' + strCopy;
        charsAdded++;
      }
      // ^(? + rx + ) is needed, in combination with some str slicing, to
      // simulate the 'y' flag.
      reCopy = new RegExp('^(?:' + source + ')', flags);
    }
    if (NPCG_INCLUDED) {
      reCopy = new RegExp('^' + source + '$(?!\\s)', flags);
    }
    if (UPDATES_LAST_INDEX_WRONG) lastIndex = re.lastIndex;
    match = call(nativeExec, sticky ? reCopy : re, strCopy);
    if (sticky) {
      if (match) {
        match.input = stringSlice(match.input, charsAdded);
        match[0] = stringSlice(match[0], charsAdded);
        match.index = re.lastIndex;
        re.lastIndex += match[0].length;
      } else re.lastIndex = 0;
    } else if (UPDATES_LAST_INDEX_WRONG && match) {
      re.lastIndex = re.global ? match.index + match[0].length : lastIndex;
    }
    if (NPCG_INCLUDED && match && match.length > 1) {
      // Fix browsers whose `exec` methods don't consistently return `undefined`
      // for NPCG, like IE8. NOTE: This doesn't work for /(.?)?/
      call(nativeReplace, match[0], reCopy, function () {
        for (i = 1; i < arguments.length - 2; i++) {
          if (arguments[i] === undefined) match[i] = undefined;
        }
      });
    }
    if (match && groups) {
      match.groups = object = create(null);
      for (i = 0; i < groups.length; i++) {
        group = groups[i];
        object[group[0]] = match[group[1]];
      }
    }
    return match;
  };
}
module.exports = patchedExec;

/***/ }),

/***/ 7939:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var anObject = __webpack_require__(1791);

// `RegExp.prototype.flags` getter implementation
// https://tc39.es/ecma262/#sec-get-regexp.prototype.flags
module.exports = function () {
  var that = anObject(this);
  var result = '';
  if (that.hasIndices) result += 'd';
  if (that.global) result += 'g';
  if (that.ignoreCase) result += 'i';
  if (that.multiline) result += 'm';
  if (that.dotAll) result += 's';
  if (that.unicode) result += 'u';
  if (that.unicodeSets) result += 'v';
  if (that.sticky) result += 'y';
  return result;
};

/***/ }),

/***/ 5650:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var hasOwn = __webpack_require__(8697);
var isPrototypeOf = __webpack_require__(1649);
var regExpFlags = __webpack_require__(7939);
var RegExpPrototype = RegExp.prototype;
module.exports = function (R) {
  var flags = R.flags;
  return flags === undefined && !('flags' in RegExpPrototype) && !hasOwn(R, 'flags') && isPrototypeOf(RegExpPrototype, R) ? call(regExpFlags, R) : flags;
};

/***/ }),

/***/ 5685:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(4631);
var global = __webpack_require__(6243);

// babel-minify and Closure Compiler transpiles RegExp('a', 'y') -> /a/y and it causes SyntaxError
var $RegExp = global.RegExp;
var UNSUPPORTED_Y = fails(function () {
  var re = $RegExp('a', 'y');
  re.lastIndex = 2;
  return re.exec('abcd') != null;
});

// UC Browser bug
// https://github.com/zloirock/core-js/issues/1008
var MISSED_STICKY = UNSUPPORTED_Y || fails(function () {
  return !$RegExp('a', 'y').sticky;
});
var BROKEN_CARET = UNSUPPORTED_Y || fails(function () {
  // https://bugzilla.mozilla.org/show_bug.cgi?id=773687
  var re = $RegExp('^r', 'gy');
  re.lastIndex = 2;
  return re.exec('str') != null;
});
module.exports = {
  BROKEN_CARET: BROKEN_CARET,
  MISSED_STICKY: MISSED_STICKY,
  UNSUPPORTED_Y: UNSUPPORTED_Y
};

/***/ }),

/***/ 8939:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(4631);
var global = __webpack_require__(6243);

// babel-minify and Closure Compiler transpiles RegExp('.', 's') -> /./s and it causes SyntaxError
var $RegExp = global.RegExp;
module.exports = fails(function () {
  var re = $RegExp('.', 's');
  return !(re.dotAll && re.exec('\n') && re.flags === 's');
});

/***/ }),

/***/ 70:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var fails = __webpack_require__(4631);
var global = __webpack_require__(6243);

// babel-minify and Closure Compiler transpiles RegExp('(?<a>b)', 'g') -> /(?<a>b)/g and it causes SyntaxError
var $RegExp = global.RegExp;
module.exports = fails(function () {
  var re = $RegExp('(?<a>b)', 'g');
  return re.exec('b').groups.a !== 'b' || 'b'.replace(re, '$<a>c') !== 'bc';
});

/***/ }),

/***/ 3662:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var isNullOrUndefined = __webpack_require__(2797);
var $TypeError = TypeError;

// `RequireObjectCoercible` abstract operation
// https://tc39.es/ecma262/#sec-requireobjectcoercible
module.exports = function (it) {
  if (isNullOrUndefined(it)) throw $TypeError("Can't call method on " + it);
  return it;
};

/***/ }),

/***/ 7406:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var SetHelpers = __webpack_require__(8970);
var iterate = __webpack_require__(1533);
var Set = SetHelpers.Set;
var add = SetHelpers.add;
module.exports = function (set) {
  var result = new Set();
  iterate(set, function (it) {
    add(result, it);
  });
  return result;
};

/***/ }),

/***/ 4392:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(496);
var SetHelpers = __webpack_require__(8970);
var clone = __webpack_require__(7406);
var size = __webpack_require__(4154);
var getSetRecord = __webpack_require__(1461);
var iterateSet = __webpack_require__(1533);
var iterateSimple = __webpack_require__(8243);
var has = SetHelpers.has;
var remove = SetHelpers.remove;

// `Set.prototype.difference` method
// https://github.com/tc39/proposal-set-methods
module.exports = function difference(other) {
  var O = aSet(this);
  var otherRec = getSetRecord(other);
  var result = clone(O);
  if (size(O) <= otherRec.size) iterateSet(O, function (e) {
    if (otherRec.includes(e)) remove(result, e);
  });else iterateSimple(otherRec.getIterator(), function (e) {
    if (has(O, e)) remove(result, e);
  });
  return result;
};

/***/ }),

/***/ 8970:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);

// eslint-disable-next-line es/no-set -- safe
var SetPrototype = Set.prototype;
module.exports = {
  // eslint-disable-next-line es/no-set -- safe
  Set: Set,
  add: uncurryThis(SetPrototype.add),
  has: uncurryThis(SetPrototype.has),
  remove: uncurryThis(SetPrototype['delete']),
  proto: SetPrototype,
  $has: SetPrototype.has,
  $keys: SetPrototype.keys
};

/***/ }),

/***/ 1398:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(496);
var SetHelpers = __webpack_require__(8970);
var size = __webpack_require__(4154);
var getSetRecord = __webpack_require__(1461);
var iterateSet = __webpack_require__(1533);
var iterateSimple = __webpack_require__(8243);
var Set = SetHelpers.Set;
var add = SetHelpers.add;
var has = SetHelpers.has;
var nativeHas = SetHelpers.$has;
var nativeKeys = SetHelpers.$keys;
var isNativeSetRecord = function (record) {
  return record.has === nativeHas && record.keys === nativeKeys;
};

// `Set.prototype.intersection` method
// https://github.com/tc39/proposal-set-methods
module.exports = function intersection(other) {
  var O = aSet(this);
  var otherRec = getSetRecord(other);
  var result = new Set();

  // observable side effects
  if (!isNativeSetRecord(otherRec) && size(O) > otherRec.size) {
    iterateSimple(otherRec.getIterator(), function (e) {
      if (has(O, e)) add(result, e);
    });
    if (size(result) < 2) return result;
    var disordered = result;
    result = new Set();
    iterateSet(O, function (e) {
      if (has(disordered, e)) add(result, e);
    });
  } else {
    iterateSet(O, function (e) {
      if (otherRec.includes(e)) add(result, e);
    });
  }
  return result;
};

/***/ }),

/***/ 2649:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(496);
var has = (__webpack_require__(8970).has);
var size = __webpack_require__(4154);
var getSetRecord = __webpack_require__(1461);
var iterateSet = __webpack_require__(1533);
var iterateSimple = __webpack_require__(8243);
var iteratorClose = __webpack_require__(1451);

// `Set.prototype.isDisjointFrom` method
// https://tc39.github.io/proposal-set-methods/#Set.prototype.isDisjointFrom
module.exports = function isDisjointFrom(other) {
  var O = aSet(this);
  var otherRec = getSetRecord(other);
  if (size(O) <= otherRec.size) return iterateSet(O, function (e) {
    if (otherRec.includes(e)) return false;
  }, true) !== false;
  var iterator = otherRec.getIterator();
  return iterateSimple(iterator, function (e) {
    if (has(O, e)) return iteratorClose(iterator, 'normal', false);
  }) !== false;
};

/***/ }),

/***/ 454:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(496);
var size = __webpack_require__(4154);
var iterate = __webpack_require__(1533);
var getSetRecord = __webpack_require__(1461);

// `Set.prototype.isSubsetOf` method
// https://tc39.github.io/proposal-set-methods/#Set.prototype.isSubsetOf
module.exports = function isSubsetOf(other) {
  var O = aSet(this);
  var otherRec = getSetRecord(other);
  if (size(O) > otherRec.size) return false;
  return iterate(O, function (e) {
    if (!otherRec.includes(e)) return false;
  }, true) !== false;
};

/***/ }),

/***/ 8599:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(496);
var has = (__webpack_require__(8970).has);
var size = __webpack_require__(4154);
var getSetRecord = __webpack_require__(1461);
var iterateSimple = __webpack_require__(8243);
var iteratorClose = __webpack_require__(1451);

// `Set.prototype.isSupersetOf` method
// https://tc39.github.io/proposal-set-methods/#Set.prototype.isSupersetOf
module.exports = function isSupersetOf(other) {
  var O = aSet(this);
  var otherRec = getSetRecord(other);
  if (size(O) < otherRec.size) return false;
  var iterator = otherRec.getIterator();
  return iterateSimple(iterator, function (e) {
    if (!has(O, e)) return iteratorClose(iterator, 'normal', false);
  }) !== false;
};

/***/ }),

/***/ 1533:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var iterateSimple = __webpack_require__(8243);
var SetHelpers = __webpack_require__(8970);
var Set = SetHelpers.Set;
var SetPrototype = SetHelpers.proto;
var forEach = uncurryThis(SetPrototype.forEach);
var keys = uncurryThis(SetPrototype.keys);
var next = keys(new Set()).next;
module.exports = function (set, fn, interruptible) {
  return interruptible ? iterateSimple(keys(set), fn, next) : forEach(set, fn);
};

/***/ }),

/***/ 5404:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var getBuiltIn = __webpack_require__(8463);
var createEmptySetLike = function () {
  return {
    size: 0,
    has: function () {
      return false;
    },
    keys: function () {
      return {
        next: function () {
          return {
            done: true
          };
        }
      };
    }
  };
};
module.exports = function (name) {
  try {
    var Set = getBuiltIn('Set');
    new Set()[name](createEmptySetLike());
    return true;
  } catch (error) {
    return false;
  }
};

/***/ }),

/***/ 4154:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThisAccessor = __webpack_require__(5658);
var SetHelpers = __webpack_require__(8970);
module.exports = uncurryThisAccessor(SetHelpers.proto, 'size', 'get') || function (set) {
  return set.size;
};

/***/ }),

/***/ 7785:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var getBuiltIn = __webpack_require__(8463);
var defineBuiltInAccessor = __webpack_require__(8770);
var wellKnownSymbol = __webpack_require__(2091);
var DESCRIPTORS = __webpack_require__(5444);
var SPECIES = wellKnownSymbol('species');
module.exports = function (CONSTRUCTOR_NAME) {
  var Constructor = getBuiltIn(CONSTRUCTOR_NAME);
  if (DESCRIPTORS && Constructor && !Constructor[SPECIES]) {
    defineBuiltInAccessor(Constructor, SPECIES, {
      configurable: true,
      get: function () {
        return this;
      }
    });
  }
};

/***/ }),

/***/ 826:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(496);
var SetHelpers = __webpack_require__(8970);
var clone = __webpack_require__(7406);
var getSetRecord = __webpack_require__(1461);
var iterateSimple = __webpack_require__(8243);
var add = SetHelpers.add;
var has = SetHelpers.has;
var remove = SetHelpers.remove;

// `Set.prototype.symmetricDifference` method
// https://github.com/tc39/proposal-set-methods
module.exports = function symmetricDifference(other) {
  var O = aSet(this);
  var keysIter = getSetRecord(other).getIterator();
  var result = clone(O);
  iterateSimple(keysIter, function (e) {
    if (has(O, e)) remove(result, e);else add(result, e);
  });
  return result;
};

/***/ }),

/***/ 7047:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var defineProperty = (__webpack_require__(6489).f);
var hasOwn = __webpack_require__(8697);
var wellKnownSymbol = __webpack_require__(2091);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
module.exports = function (target, TAG, STATIC) {
  if (target && !STATIC) target = target.prototype;
  if (target && !hasOwn(target, TO_STRING_TAG)) {
    defineProperty(target, TO_STRING_TAG, {
      configurable: true,
      value: TAG
    });
  }
};

/***/ }),

/***/ 9828:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var aSet = __webpack_require__(496);
var add = (__webpack_require__(8970).add);
var clone = __webpack_require__(7406);
var getSetRecord = __webpack_require__(1461);
var iterateSimple = __webpack_require__(8243);

// `Set.prototype.union` method
// https://github.com/tc39/proposal-set-methods
module.exports = function union(other) {
  var O = aSet(this);
  var keysIter = getSetRecord(other).getIterator();
  var result = clone(O);
  iterateSimple(keysIter, function (it) {
    add(result, it);
  });
  return result;
};

/***/ }),

/***/ 7615:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var shared = __webpack_require__(3513);
var uid = __webpack_require__(4072);
var keys = shared('keys');
module.exports = function (key) {
  return keys[key] || (keys[key] = uid(key));
};

/***/ }),

/***/ 6133:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var defineGlobalProperty = __webpack_require__(8289);
var SHARED = '__core-js_shared__';
var store = global[SHARED] || defineGlobalProperty(SHARED, {});
module.exports = store;

/***/ }),

/***/ 3513:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var IS_PURE = __webpack_require__(1459);
var store = __webpack_require__(6133);
(module.exports = function (key, value) {
  return store[key] || (store[key] = value !== undefined ? value : {});
})('versions', []).push({
  version: '3.29.0',
  mode: IS_PURE ? 'pure' : 'global',
  copyright: '© 2014-2023 Denis Pushkarev (zloirock.ru)',
  license: 'https://github.com/zloirock/core-js/blob/v3.29.0/LICENSE',
  source: 'https://github.com/zloirock/core-js'
});

/***/ }),

/***/ 1485:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var anObject = __webpack_require__(1791);
var aConstructor = __webpack_require__(4100);
var isNullOrUndefined = __webpack_require__(2797);
var wellKnownSymbol = __webpack_require__(2091);
var SPECIES = wellKnownSymbol('species');

// `SpeciesConstructor` abstract operation
// https://tc39.es/ecma262/#sec-speciesconstructor
module.exports = function (O, defaultConstructor) {
  var C = anObject(O).constructor;
  var S;
  return C === undefined || isNullOrUndefined(S = anObject(C)[SPECIES]) ? defaultConstructor : aConstructor(S);
};

/***/ }),

/***/ 1663:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var toIntegerOrInfinity = __webpack_require__(3923);
var toString = __webpack_require__(5479);
var requireObjectCoercible = __webpack_require__(3662);
var charAt = uncurryThis(''.charAt);
var charCodeAt = uncurryThis(''.charCodeAt);
var stringSlice = uncurryThis(''.slice);
var createMethod = function (CONVERT_TO_STRING) {
  return function ($this, pos) {
    var S = toString(requireObjectCoercible($this));
    var position = toIntegerOrInfinity(pos);
    var size = S.length;
    var first, second;
    if (position < 0 || position >= size) return CONVERT_TO_STRING ? '' : undefined;
    first = charCodeAt(S, position);
    return first < 0xD800 || first > 0xDBFF || position + 1 === size || (second = charCodeAt(S, position + 1)) < 0xDC00 || second > 0xDFFF ? CONVERT_TO_STRING ? charAt(S, position) : first : CONVERT_TO_STRING ? stringSlice(S, position, position + 2) : (first - 0xD800 << 10) + (second - 0xDC00) + 0x10000;
  };
};
module.exports = {
  // `String.prototype.codePointAt` method
  // https://tc39.es/ecma262/#sec-string.prototype.codepointat
  codeAt: createMethod(false),
  // `String.prototype.at` method
  // https://github.com/mathiasbynens/String.prototype.at
  charAt: createMethod(true)
};

/***/ }),

/***/ 4330:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $trimEnd = (__webpack_require__(6850).end);
var forcedStringTrimMethod = __webpack_require__(8650);

// `String.prototype.{ trimEnd, trimRight }` method
// https://tc39.es/ecma262/#sec-string.prototype.trimend
// https://tc39.es/ecma262/#String.prototype.trimright
module.exports = forcedStringTrimMethod('trimEnd') ? function trimEnd() {
  return $trimEnd(this);
  // eslint-disable-next-line es/no-string-prototype-trimstart-trimend -- safe
} : ''.trimEnd;

/***/ }),

/***/ 8650:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var PROPER_FUNCTION_NAME = (__webpack_require__(1158).PROPER);
var fails = __webpack_require__(4631);
var whitespaces = __webpack_require__(9732);
var non = '\u200B\u0085\u180E';

// check that a method works with the correct list
// of whitespaces and has a correct name
module.exports = function (METHOD_NAME) {
  return fails(function () {
    return !!whitespaces[METHOD_NAME]() || non[METHOD_NAME]() !== non || PROPER_FUNCTION_NAME && whitespaces[METHOD_NAME].name !== METHOD_NAME;
  });
};

/***/ }),

/***/ 6850:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var requireObjectCoercible = __webpack_require__(3662);
var toString = __webpack_require__(5479);
var whitespaces = __webpack_require__(9732);
var replace = uncurryThis(''.replace);
var ltrim = RegExp('^[' + whitespaces + ']+');
var rtrim = RegExp('(^|[^' + whitespaces + '])[' + whitespaces + ']+$');

// `String.prototype.{ trim, trimStart, trimEnd, trimLeft, trimRight }` methods implementation
var createMethod = function (TYPE) {
  return function ($this) {
    var string = toString(requireObjectCoercible($this));
    if (TYPE & 1) string = replace(string, ltrim, '');
    if (TYPE & 2) string = replace(string, rtrim, '$1');
    return string;
  };
};
module.exports = {
  // `String.prototype.{ trimLeft, trimStart }` methods
  // https://tc39.es/ecma262/#sec-string.prototype.trimstart
  start: createMethod(1),
  // `String.prototype.{ trimRight, trimEnd }` methods
  // https://tc39.es/ecma262/#sec-string.prototype.trimend
  end: createMethod(2),
  // `String.prototype.trim` method
  // https://tc39.es/ecma262/#sec-string.prototype.trim
  trim: createMethod(3)
};

/***/ }),

/***/ 2039:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* eslint-disable es/no-symbol -- required for testing */
var V8_VERSION = __webpack_require__(8820);
var fails = __webpack_require__(4631);

// eslint-disable-next-line es/no-object-getownpropertysymbols -- required for testing
module.exports = !!Object.getOwnPropertySymbols && !fails(function () {
  var symbol = Symbol();
  // Chrome 38 Symbol has incorrect toString conversion
  // `get-own-property-symbols` polyfill symbols converted to object are not Symbol instances
  return !String(symbol) || !(Object(symbol) instanceof Symbol) ||
  // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
  !Symbol.sham && V8_VERSION && V8_VERSION < 41;
});

/***/ }),

/***/ 1457:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var apply = __webpack_require__(2113);
var bind = __webpack_require__(3160);
var isCallable = __webpack_require__(6509);
var hasOwn = __webpack_require__(8697);
var fails = __webpack_require__(4631);
var html = __webpack_require__(421);
var arraySlice = __webpack_require__(808);
var createElement = __webpack_require__(6431);
var validateArgumentsLength = __webpack_require__(7556);
var IS_IOS = __webpack_require__(2815);
var IS_NODE = __webpack_require__(5816);
var set = global.setImmediate;
var clear = global.clearImmediate;
var process = global.process;
var Dispatch = global.Dispatch;
var Function = global.Function;
var MessageChannel = global.MessageChannel;
var String = global.String;
var counter = 0;
var queue = {};
var ONREADYSTATECHANGE = 'onreadystatechange';
var $location, defer, channel, port;
fails(function () {
  // Deno throws a ReferenceError on `location` access without `--location` flag
  $location = global.location;
});
var run = function (id) {
  if (hasOwn(queue, id)) {
    var fn = queue[id];
    delete queue[id];
    fn();
  }
};
var runner = function (id) {
  return function () {
    run(id);
  };
};
var eventListener = function (event) {
  run(event.data);
};
var globalPostMessageDefer = function (id) {
  // old engines have not location.origin
  global.postMessage(String(id), $location.protocol + '//' + $location.host);
};

// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
if (!set || !clear) {
  set = function setImmediate(handler) {
    validateArgumentsLength(arguments.length, 1);
    var fn = isCallable(handler) ? handler : Function(handler);
    var args = arraySlice(arguments, 1);
    queue[++counter] = function () {
      apply(fn, undefined, args);
    };
    defer(counter);
    return counter;
  };
  clear = function clearImmediate(id) {
    delete queue[id];
  };
  // Node.js 0.8-
  if (IS_NODE) {
    defer = function (id) {
      process.nextTick(runner(id));
    };
    // Sphere (JS game engine) Dispatch API
  } else if (Dispatch && Dispatch.now) {
    defer = function (id) {
      Dispatch.now(runner(id));
    };
    // Browsers with MessageChannel, includes WebWorkers
    // except iOS - https://github.com/zloirock/core-js/issues/624
  } else if (MessageChannel && !IS_IOS) {
    channel = new MessageChannel();
    port = channel.port2;
    channel.port1.onmessage = eventListener;
    defer = bind(port.postMessage, port);
    // Browsers with postMessage, skip WebWorkers
    // IE8 has postMessage, but it's sync & typeof its postMessage is 'object'
  } else if (global.addEventListener && isCallable(global.postMessage) && !global.importScripts && $location && $location.protocol !== 'file:' && !fails(globalPostMessageDefer)) {
    defer = globalPostMessageDefer;
    global.addEventListener('message', eventListener, false);
    // IE8-
  } else if (ONREADYSTATECHANGE in createElement('script')) {
    defer = function (id) {
      html.appendChild(createElement('script'))[ONREADYSTATECHANGE] = function () {
        html.removeChild(this);
        run(id);
      };
    };
    // Rest old browsers
  } else {
    defer = function (id) {
      setTimeout(runner(id), 0);
    };
  }
}
module.exports = {
  set: set,
  clear: clear
};

/***/ }),

/***/ 1634:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toIntegerOrInfinity = __webpack_require__(3923);
var max = Math.max;
var min = Math.min;

// Helper for a popular repeating case of the spec:
// Let integer be ? ToInteger(index).
// If integer < 0, let result be max((length + integer), 0); else let result be min(integer, length).
module.exports = function (index, length) {
  var integer = toIntegerOrInfinity(index);
  return integer < 0 ? max(integer + length, 0) : min(integer, length);
};

/***/ }),

/***/ 3926:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toPrimitive = __webpack_require__(2545);
var $TypeError = TypeError;

// `ToBigInt` abstract operation
// https://tc39.es/ecma262/#sec-tobigint
module.exports = function (argument) {
  var prim = toPrimitive(argument, 'number');
  if (typeof prim == 'number') throw $TypeError("Can't convert number to bigint");
  // eslint-disable-next-line es/no-bigint -- safe
  return BigInt(prim);
};

/***/ }),

/***/ 7768:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toIntegerOrInfinity = __webpack_require__(3923);
var toLength = __webpack_require__(7590);
var $RangeError = RangeError;

// `ToIndex` abstract operation
// https://tc39.es/ecma262/#sec-toindex
module.exports = function (it) {
  if (it === undefined) return 0;
  var number = toIntegerOrInfinity(it);
  var length = toLength(number);
  if (number !== length) throw $RangeError('Wrong length or index');
  return length;
};

/***/ }),

/***/ 2445:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// toObject with fallback for non-array-like ES3 strings
var IndexedObject = __webpack_require__(3799);
var requireObjectCoercible = __webpack_require__(3662);
module.exports = function (it) {
  return IndexedObject(requireObjectCoercible(it));
};

/***/ }),

/***/ 3923:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var trunc = __webpack_require__(7293);

// `ToIntegerOrInfinity` abstract operation
// https://tc39.es/ecma262/#sec-tointegerorinfinity
module.exports = function (argument) {
  var number = +argument;
  // eslint-disable-next-line no-self-compare -- NaN check
  return number !== number || number === 0 ? 0 : trunc(number);
};

/***/ }),

/***/ 7590:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toIntegerOrInfinity = __webpack_require__(3923);
var min = Math.min;

// `ToLength` abstract operation
// https://tc39.es/ecma262/#sec-tolength
module.exports = function (argument) {
  return argument > 0 ? min(toIntegerOrInfinity(argument), 0x1FFFFFFFFFFFFF) : 0; // 2 ** 53 - 1 == 9007199254740991
};

/***/ }),

/***/ 2397:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var requireObjectCoercible = __webpack_require__(3662);
var $Object = Object;

// `ToObject` abstract operation
// https://tc39.es/ecma262/#sec-toobject
module.exports = function (argument) {
  return $Object(requireObjectCoercible(argument));
};

/***/ }),

/***/ 5437:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toPositiveInteger = __webpack_require__(9806);
var $RangeError = RangeError;
module.exports = function (it, BYTES) {
  var offset = toPositiveInteger(it);
  if (offset % BYTES) throw $RangeError('Wrong offset');
  return offset;
};

/***/ }),

/***/ 9806:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toIntegerOrInfinity = __webpack_require__(3923);
var $RangeError = RangeError;
module.exports = function (it) {
  var result = toIntegerOrInfinity(it);
  if (result < 0) throw $RangeError("The argument can't be less than 0");
  return result;
};

/***/ }),

/***/ 2545:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var call = __webpack_require__(6277);
var isObject = __webpack_require__(8154);
var isSymbol = __webpack_require__(2237);
var getMethod = __webpack_require__(7750);
var ordinaryToPrimitive = __webpack_require__(342);
var wellKnownSymbol = __webpack_require__(2091);
var $TypeError = TypeError;
var TO_PRIMITIVE = wellKnownSymbol('toPrimitive');

// `ToPrimitive` abstract operation
// https://tc39.es/ecma262/#sec-toprimitive
module.exports = function (input, pref) {
  if (!isObject(input) || isSymbol(input)) return input;
  var exoticToPrim = getMethod(input, TO_PRIMITIVE);
  var result;
  if (exoticToPrim) {
    if (pref === undefined) pref = 'default';
    result = call(exoticToPrim, input, pref);
    if (!isObject(result) || isSymbol(result)) return result;
    throw $TypeError("Can't convert object to primitive value");
  }
  if (pref === undefined) pref = 'number';
  return ordinaryToPrimitive(input, pref);
};

/***/ }),

/***/ 2129:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var toPrimitive = __webpack_require__(2545);
var isSymbol = __webpack_require__(2237);

// `ToPropertyKey` abstract operation
// https://tc39.es/ecma262/#sec-topropertykey
module.exports = function (argument) {
  var key = toPrimitive(argument, 'string');
  return isSymbol(key) ? key : key + '';
};

/***/ }),

/***/ 5396:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var wellKnownSymbol = __webpack_require__(2091);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var test = {};
test[TO_STRING_TAG] = 'z';
module.exports = String(test) === '[object z]';

/***/ }),

/***/ 5479:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var classof = __webpack_require__(2611);
var $String = String;
module.exports = function (argument) {
  if (classof(argument) === 'Symbol') throw TypeError('Cannot convert a Symbol value to a string');
  return $String(argument);
};

/***/ }),

/***/ 5903:
/***/ ((module) => {

var $String = String;
module.exports = function (argument) {
  try {
    return $String(argument);
  } catch (error) {
    return 'Object';
  }
};

/***/ }),

/***/ 9671:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var global = __webpack_require__(6243);
var call = __webpack_require__(6277);
var DESCRIPTORS = __webpack_require__(5444);
var TYPED_ARRAYS_CONSTRUCTORS_REQUIRES_WRAPPERS = __webpack_require__(4349);
var ArrayBufferViewCore = __webpack_require__(6924);
var ArrayBufferModule = __webpack_require__(1666);
var anInstance = __webpack_require__(9663);
var createPropertyDescriptor = __webpack_require__(6012);
var createNonEnumerableProperty = __webpack_require__(9763);
var isIntegralNumber = __webpack_require__(4943);
var toLength = __webpack_require__(7590);
var toIndex = __webpack_require__(7768);
var toOffset = __webpack_require__(5437);
var toPropertyKey = __webpack_require__(2129);
var hasOwn = __webpack_require__(8697);
var classof = __webpack_require__(2611);
var isObject = __webpack_require__(8154);
var isSymbol = __webpack_require__(2237);
var create = __webpack_require__(8336);
var isPrototypeOf = __webpack_require__(1649);
var setPrototypeOf = __webpack_require__(4767);
var getOwnPropertyNames = (__webpack_require__(24).f);
var typedArrayFrom = __webpack_require__(11);
var forEach = (__webpack_require__(53).forEach);
var setSpecies = __webpack_require__(7785);
var defineBuiltInAccessor = __webpack_require__(8770);
var definePropertyModule = __webpack_require__(6489);
var getOwnPropertyDescriptorModule = __webpack_require__(7515);
var InternalStateModule = __webpack_require__(3653);
var inheritIfRequired = __webpack_require__(2775);
var getInternalState = InternalStateModule.get;
var setInternalState = InternalStateModule.set;
var enforceInternalState = InternalStateModule.enforce;
var nativeDefineProperty = definePropertyModule.f;
var nativeGetOwnPropertyDescriptor = getOwnPropertyDescriptorModule.f;
var round = Math.round;
var RangeError = global.RangeError;
var ArrayBuffer = ArrayBufferModule.ArrayBuffer;
var ArrayBufferPrototype = ArrayBuffer.prototype;
var DataView = ArrayBufferModule.DataView;
var NATIVE_ARRAY_BUFFER_VIEWS = ArrayBufferViewCore.NATIVE_ARRAY_BUFFER_VIEWS;
var TYPED_ARRAY_TAG = ArrayBufferViewCore.TYPED_ARRAY_TAG;
var TypedArray = ArrayBufferViewCore.TypedArray;
var TypedArrayPrototype = ArrayBufferViewCore.TypedArrayPrototype;
var aTypedArrayConstructor = ArrayBufferViewCore.aTypedArrayConstructor;
var isTypedArray = ArrayBufferViewCore.isTypedArray;
var BYTES_PER_ELEMENT = 'BYTES_PER_ELEMENT';
var WRONG_LENGTH = 'Wrong length';
var fromList = function (C, list) {
  aTypedArrayConstructor(C);
  var index = 0;
  var length = list.length;
  var result = new C(length);
  while (length > index) result[index] = list[index++];
  return result;
};
var addGetter = function (it, key) {
  defineBuiltInAccessor(it, key, {
    configurable: true,
    get: function () {
      return getInternalState(this)[key];
    }
  });
};
var isArrayBuffer = function (it) {
  var klass;
  return isPrototypeOf(ArrayBufferPrototype, it) || (klass = classof(it)) == 'ArrayBuffer' || klass == 'SharedArrayBuffer';
};
var isTypedArrayIndex = function (target, key) {
  return isTypedArray(target) && !isSymbol(key) && key in target && isIntegralNumber(+key) && key >= 0;
};
var wrappedGetOwnPropertyDescriptor = function getOwnPropertyDescriptor(target, key) {
  key = toPropertyKey(key);
  return isTypedArrayIndex(target, key) ? createPropertyDescriptor(2, target[key]) : nativeGetOwnPropertyDescriptor(target, key);
};
var wrappedDefineProperty = function defineProperty(target, key, descriptor) {
  key = toPropertyKey(key);
  if (isTypedArrayIndex(target, key) && isObject(descriptor) && hasOwn(descriptor, 'value') && !hasOwn(descriptor, 'get') && !hasOwn(descriptor, 'set')
  // TODO: add validation descriptor w/o calling accessors
  && !descriptor.configurable && (!hasOwn(descriptor, 'writable') || descriptor.writable) && (!hasOwn(descriptor, 'enumerable') || descriptor.enumerable)) {
    target[key] = descriptor.value;
    return target;
  }
  return nativeDefineProperty(target, key, descriptor);
};
if (DESCRIPTORS) {
  if (!NATIVE_ARRAY_BUFFER_VIEWS) {
    getOwnPropertyDescriptorModule.f = wrappedGetOwnPropertyDescriptor;
    definePropertyModule.f = wrappedDefineProperty;
    addGetter(TypedArrayPrototype, 'buffer');
    addGetter(TypedArrayPrototype, 'byteOffset');
    addGetter(TypedArrayPrototype, 'byteLength');
    addGetter(TypedArrayPrototype, 'length');
  }
  $({
    target: 'Object',
    stat: true,
    forced: !NATIVE_ARRAY_BUFFER_VIEWS
  }, {
    getOwnPropertyDescriptor: wrappedGetOwnPropertyDescriptor,
    defineProperty: wrappedDefineProperty
  });
  module.exports = function (TYPE, wrapper, CLAMPED) {
    var BYTES = TYPE.match(/\d+/)[0] / 8;
    var CONSTRUCTOR_NAME = TYPE + (CLAMPED ? 'Clamped' : '') + 'Array';
    var GETTER = 'get' + TYPE;
    var SETTER = 'set' + TYPE;
    var NativeTypedArrayConstructor = global[CONSTRUCTOR_NAME];
    var TypedArrayConstructor = NativeTypedArrayConstructor;
    var TypedArrayConstructorPrototype = TypedArrayConstructor && TypedArrayConstructor.prototype;
    var exported = {};
    var getter = function (that, index) {
      var data = getInternalState(that);
      return data.view[GETTER](index * BYTES + data.byteOffset, true);
    };
    var setter = function (that, index, value) {
      var data = getInternalState(that);
      if (CLAMPED) value = (value = round(value)) < 0 ? 0 : value > 0xFF ? 0xFF : value & 0xFF;
      data.view[SETTER](index * BYTES + data.byteOffset, value, true);
    };
    var addElement = function (that, index) {
      nativeDefineProperty(that, index, {
        get: function () {
          return getter(this, index);
        },
        set: function (value) {
          return setter(this, index, value);
        },
        enumerable: true
      });
    };
    if (!NATIVE_ARRAY_BUFFER_VIEWS) {
      TypedArrayConstructor = wrapper(function (that, data, offset, $length) {
        anInstance(that, TypedArrayConstructorPrototype);
        var index = 0;
        var byteOffset = 0;
        var buffer, byteLength, length;
        if (!isObject(data)) {
          length = toIndex(data);
          byteLength = length * BYTES;
          buffer = new ArrayBuffer(byteLength);
        } else if (isArrayBuffer(data)) {
          buffer = data;
          byteOffset = toOffset(offset, BYTES);
          var $len = data.byteLength;
          if ($length === undefined) {
            if ($len % BYTES) throw RangeError(WRONG_LENGTH);
            byteLength = $len - byteOffset;
            if (byteLength < 0) throw RangeError(WRONG_LENGTH);
          } else {
            byteLength = toLength($length) * BYTES;
            if (byteLength + byteOffset > $len) throw RangeError(WRONG_LENGTH);
          }
          length = byteLength / BYTES;
        } else if (isTypedArray(data)) {
          return fromList(TypedArrayConstructor, data);
        } else {
          return call(typedArrayFrom, TypedArrayConstructor, data);
        }
        setInternalState(that, {
          buffer: buffer,
          byteOffset: byteOffset,
          byteLength: byteLength,
          length: length,
          view: new DataView(buffer)
        });
        while (index < length) addElement(that, index++);
      });
      if (setPrototypeOf) setPrototypeOf(TypedArrayConstructor, TypedArray);
      TypedArrayConstructorPrototype = TypedArrayConstructor.prototype = create(TypedArrayPrototype);
    } else if (TYPED_ARRAYS_CONSTRUCTORS_REQUIRES_WRAPPERS) {
      TypedArrayConstructor = wrapper(function (dummy, data, typedArrayOffset, $length) {
        anInstance(dummy, TypedArrayConstructorPrototype);
        return inheritIfRequired(function () {
          if (!isObject(data)) return new NativeTypedArrayConstructor(toIndex(data));
          if (isArrayBuffer(data)) return $length !== undefined ? new NativeTypedArrayConstructor(data, toOffset(typedArrayOffset, BYTES), $length) : typedArrayOffset !== undefined ? new NativeTypedArrayConstructor(data, toOffset(typedArrayOffset, BYTES)) : new NativeTypedArrayConstructor(data);
          if (isTypedArray(data)) return fromList(TypedArrayConstructor, data);
          return call(typedArrayFrom, TypedArrayConstructor, data);
        }(), dummy, TypedArrayConstructor);
      });
      if (setPrototypeOf) setPrototypeOf(TypedArrayConstructor, TypedArray);
      forEach(getOwnPropertyNames(NativeTypedArrayConstructor), function (key) {
        if (!(key in TypedArrayConstructor)) {
          createNonEnumerableProperty(TypedArrayConstructor, key, NativeTypedArrayConstructor[key]);
        }
      });
      TypedArrayConstructor.prototype = TypedArrayConstructorPrototype;
    }
    if (TypedArrayConstructorPrototype.constructor !== TypedArrayConstructor) {
      createNonEnumerableProperty(TypedArrayConstructorPrototype, 'constructor', TypedArrayConstructor);
    }
    enforceInternalState(TypedArrayConstructorPrototype).TypedArrayConstructor = TypedArrayConstructor;
    if (TYPED_ARRAY_TAG) {
      createNonEnumerableProperty(TypedArrayConstructorPrototype, TYPED_ARRAY_TAG, CONSTRUCTOR_NAME);
    }
    var FORCED = TypedArrayConstructor != NativeTypedArrayConstructor;
    exported[CONSTRUCTOR_NAME] = TypedArrayConstructor;
    $({
      global: true,
      constructor: true,
      forced: FORCED,
      sham: !NATIVE_ARRAY_BUFFER_VIEWS
    }, exported);
    if (!(BYTES_PER_ELEMENT in TypedArrayConstructor)) {
      createNonEnumerableProperty(TypedArrayConstructor, BYTES_PER_ELEMENT, BYTES);
    }
    if (!(BYTES_PER_ELEMENT in TypedArrayConstructorPrototype)) {
      createNonEnumerableProperty(TypedArrayConstructorPrototype, BYTES_PER_ELEMENT, BYTES);
    }
    setSpecies(CONSTRUCTOR_NAME);
  };
} else module.exports = function () {/* empty */};

/***/ }),

/***/ 4349:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* eslint-disable no-new -- required for testing */
var global = __webpack_require__(6243);
var fails = __webpack_require__(4631);
var checkCorrectnessOfIteration = __webpack_require__(1508);
var NATIVE_ARRAY_BUFFER_VIEWS = (__webpack_require__(6924).NATIVE_ARRAY_BUFFER_VIEWS);
var ArrayBuffer = global.ArrayBuffer;
var Int8Array = global.Int8Array;
module.exports = !NATIVE_ARRAY_BUFFER_VIEWS || !fails(function () {
  Int8Array(1);
}) || !fails(function () {
  new Int8Array(-1);
}) || !checkCorrectnessOfIteration(function (iterable) {
  new Int8Array();
  new Int8Array(null);
  new Int8Array(1.5);
  new Int8Array(iterable);
}, true) || fails(function () {
  // Safari (11+) bug - a reason why even Safari 13 should load a typed array polyfill
  return new Int8Array(new ArrayBuffer(2), 1, undefined).length !== 1;
});

/***/ }),

/***/ 11:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var bind = __webpack_require__(3160);
var call = __webpack_require__(6277);
var aConstructor = __webpack_require__(4100);
var toObject = __webpack_require__(2397);
var lengthOfArrayLike = __webpack_require__(3534);
var getIterator = __webpack_require__(1897);
var getIteratorMethod = __webpack_require__(2779);
var isArrayIteratorMethod = __webpack_require__(1449);
var isBigIntArray = __webpack_require__(8367);
var aTypedArrayConstructor = (__webpack_require__(6924).aTypedArrayConstructor);
var toBigInt = __webpack_require__(3926);
module.exports = function from(source /* , mapfn, thisArg */) {
  var C = aConstructor(this);
  var O = toObject(source);
  var argumentsLength = arguments.length;
  var mapfn = argumentsLength > 1 ? arguments[1] : undefined;
  var mapping = mapfn !== undefined;
  var iteratorMethod = getIteratorMethod(O);
  var i, length, result, thisIsBigIntArray, value, step, iterator, next;
  if (iteratorMethod && !isArrayIteratorMethod(iteratorMethod)) {
    iterator = getIterator(O, iteratorMethod);
    next = iterator.next;
    O = [];
    while (!(step = call(next, iterator)).done) {
      O.push(step.value);
    }
  }
  if (mapping && argumentsLength > 2) {
    mapfn = bind(mapfn, arguments[2]);
  }
  length = lengthOfArrayLike(O);
  result = new (aTypedArrayConstructor(C))(length);
  thisIsBigIntArray = isBigIntArray(result);
  for (i = 0; length > i; i++) {
    value = mapping ? mapfn(O[i], i) : O[i];
    // FF30- typed arrays doesn't properly convert objects to typed array values
    result[i] = thisIsBigIntArray ? toBigInt(value) : +value;
  }
  return result;
};

/***/ }),

/***/ 4072:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var uncurryThis = __webpack_require__(8712);
var id = 0;
var postfix = Math.random();
var toString = uncurryThis(1.0.toString);
module.exports = function (key) {
  return 'Symbol(' + (key === undefined ? '' : key) + ')_' + toString(++id + postfix, 36);
};

/***/ }),

/***/ 7880:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* eslint-disable es/no-symbol -- required for testing */
var NATIVE_SYMBOL = __webpack_require__(2039);
module.exports = NATIVE_SYMBOL && !Symbol.sham && typeof Symbol.iterator == 'symbol';

/***/ }),

/***/ 726:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var DESCRIPTORS = __webpack_require__(5444);
var fails = __webpack_require__(4631);

// V8 ~ Chrome 36-
// https://bugs.chromium.org/p/v8/issues/detail?id=3334
module.exports = DESCRIPTORS && fails(function () {
  // eslint-disable-next-line es/no-object-defineproperty -- required for testing
  return Object.defineProperty(function () {/* empty */}, 'prototype', {
    value: 42,
    writable: false
  }).prototype != 42;
});

/***/ }),

/***/ 7556:
/***/ ((module) => {

var $TypeError = TypeError;
module.exports = function (passed, required) {
  if (passed < required) throw $TypeError('Not enough arguments');
  return passed;
};

/***/ }),

/***/ 1766:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var isCallable = __webpack_require__(6509);
var WeakMap = global.WeakMap;
module.exports = isCallable(WeakMap) && /native code/.test(String(WeakMap));

/***/ }),

/***/ 2695:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var path = __webpack_require__(5591);
var hasOwn = __webpack_require__(8697);
var wrappedWellKnownSymbolModule = __webpack_require__(6983);
var defineProperty = (__webpack_require__(6489).f);
module.exports = function (NAME) {
  var Symbol = path.Symbol || (path.Symbol = {});
  if (!hasOwn(Symbol, NAME)) defineProperty(Symbol, NAME, {
    value: wrappedWellKnownSymbolModule.f(NAME)
  });
};

/***/ }),

/***/ 6983:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var wellKnownSymbol = __webpack_require__(2091);
exports.f = wellKnownSymbol;

/***/ }),

/***/ 2091:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var shared = __webpack_require__(3513);
var hasOwn = __webpack_require__(8697);
var uid = __webpack_require__(4072);
var NATIVE_SYMBOL = __webpack_require__(2039);
var USE_SYMBOL_AS_UID = __webpack_require__(7880);
var Symbol = global.Symbol;
var WellKnownSymbolsStore = shared('wks');
var createWellKnownSymbol = USE_SYMBOL_AS_UID ? Symbol['for'] || Symbol : Symbol && Symbol.withoutSetter || uid;
module.exports = function (name) {
  if (!hasOwn(WellKnownSymbolsStore, name)) {
    WellKnownSymbolsStore[name] = NATIVE_SYMBOL && hasOwn(Symbol, name) ? Symbol[name] : createWellKnownSymbol('Symbol.' + name);
  }
  return WellKnownSymbolsStore[name];
};

/***/ }),

/***/ 9732:
/***/ ((module) => {

// a string of all valid unicode whitespaces
module.exports = '\u0009\u000A\u000B\u000C\u000D\u0020\u00A0\u1680\u2000\u2001\u2002' + '\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u202F\u205F\u3000\u2028\u2029\uFEFF';

/***/ }),

/***/ 561:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var getBuiltIn = __webpack_require__(8463);
var hasOwn = __webpack_require__(8697);
var createNonEnumerableProperty = __webpack_require__(9763);
var isPrototypeOf = __webpack_require__(1649);
var setPrototypeOf = __webpack_require__(4767);
var copyConstructorProperties = __webpack_require__(8004);
var proxyAccessor = __webpack_require__(2200);
var inheritIfRequired = __webpack_require__(2775);
var normalizeStringArgument = __webpack_require__(6851);
var installErrorCause = __webpack_require__(1048);
var installErrorStack = __webpack_require__(5491);
var DESCRIPTORS = __webpack_require__(5444);
var IS_PURE = __webpack_require__(1459);
module.exports = function (FULL_NAME, wrapper, FORCED, IS_AGGREGATE_ERROR) {
  var STACK_TRACE_LIMIT = 'stackTraceLimit';
  var OPTIONS_POSITION = IS_AGGREGATE_ERROR ? 2 : 1;
  var path = FULL_NAME.split('.');
  var ERROR_NAME = path[path.length - 1];
  var OriginalError = getBuiltIn.apply(null, path);
  if (!OriginalError) return;
  var OriginalErrorPrototype = OriginalError.prototype;

  // V8 9.3- bug https://bugs.chromium.org/p/v8/issues/detail?id=12006
  if (!IS_PURE && hasOwn(OriginalErrorPrototype, 'cause')) delete OriginalErrorPrototype.cause;
  if (!FORCED) return OriginalError;
  var BaseError = getBuiltIn('Error');
  var WrappedError = wrapper(function (a, b) {
    var message = normalizeStringArgument(IS_AGGREGATE_ERROR ? b : a, undefined);
    var result = IS_AGGREGATE_ERROR ? new OriginalError(a) : new OriginalError();
    if (message !== undefined) createNonEnumerableProperty(result, 'message', message);
    installErrorStack(result, WrappedError, result.stack, 2);
    if (this && isPrototypeOf(OriginalErrorPrototype, this)) inheritIfRequired(result, this, WrappedError);
    if (arguments.length > OPTIONS_POSITION) installErrorCause(result, arguments[OPTIONS_POSITION]);
    return result;
  });
  WrappedError.prototype = OriginalErrorPrototype;
  if (ERROR_NAME !== 'Error') {
    if (setPrototypeOf) setPrototypeOf(WrappedError, BaseError);else copyConstructorProperties(WrappedError, BaseError, {
      name: true
    });
  } else if (DESCRIPTORS && STACK_TRACE_LIMIT in OriginalError) {
    proxyAccessor(WrappedError, OriginalError, STACK_TRACE_LIMIT);
    proxyAccessor(WrappedError, OriginalError, 'prepareStackTrace');
  }
  copyConstructorProperties(WrappedError, OriginalError);
  if (!IS_PURE) try {
    // Safari 13- bug: WebAssembly errors does not have a proper `.name`
    if (OriginalErrorPrototype.name !== ERROR_NAME) {
      createNonEnumerableProperty(OriginalErrorPrototype, 'name', ERROR_NAME);
    }
    OriginalErrorPrototype.constructor = WrappedError;
  } catch (error) {/* empty */}
  return WrappedError;
};

/***/ }),

/***/ 4622:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var getBuiltIn = __webpack_require__(8463);
var apply = __webpack_require__(2113);
var fails = __webpack_require__(4631);
var wrapErrorConstructorWithCause = __webpack_require__(561);
var AGGREGATE_ERROR = 'AggregateError';
var $AggregateError = getBuiltIn(AGGREGATE_ERROR);
var FORCED = !fails(function () {
  return $AggregateError([1]).errors[0] !== 1;
}) && fails(function () {
  return $AggregateError([1], AGGREGATE_ERROR, {
    cause: 7
  }).cause !== 7;
});

// https://github.com/tc39/proposal-error-cause
$({
  global: true,
  constructor: true,
  arity: 2,
  forced: FORCED
}, {
  AggregateError: wrapErrorConstructorWithCause(AGGREGATE_ERROR, function (init) {
    // eslint-disable-next-line no-unused-vars -- required for functions `.length`
    return function AggregateError(errors, message) {
      return apply(init, this, arguments);
    };
  }, FORCED, true)
});

/***/ }),

/***/ 3505:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var isPrototypeOf = __webpack_require__(1649);
var getPrototypeOf = __webpack_require__(5355);
var setPrototypeOf = __webpack_require__(4767);
var copyConstructorProperties = __webpack_require__(8004);
var create = __webpack_require__(8336);
var createNonEnumerableProperty = __webpack_require__(9763);
var createPropertyDescriptor = __webpack_require__(6012);
var installErrorCause = __webpack_require__(1048);
var installErrorStack = __webpack_require__(5491);
var iterate = __webpack_require__(5716);
var normalizeStringArgument = __webpack_require__(6851);
var wellKnownSymbol = __webpack_require__(2091);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var $Error = Error;
var push = [].push;
var $AggregateError = function AggregateError(errors, message /* , options */) {
  var isInstance = isPrototypeOf(AggregateErrorPrototype, this);
  var that;
  if (setPrototypeOf) {
    that = setPrototypeOf($Error(), isInstance ? getPrototypeOf(this) : AggregateErrorPrototype);
  } else {
    that = isInstance ? this : create(AggregateErrorPrototype);
    createNonEnumerableProperty(that, TO_STRING_TAG, 'Error');
  }
  if (message !== undefined) createNonEnumerableProperty(that, 'message', normalizeStringArgument(message));
  installErrorStack(that, $AggregateError, that.stack, 1);
  if (arguments.length > 2) installErrorCause(that, arguments[2]);
  var errorsArray = [];
  iterate(errors, push, {
    that: errorsArray
  });
  createNonEnumerableProperty(that, 'errors', errorsArray);
  return that;
};
if (setPrototypeOf) setPrototypeOf($AggregateError, $Error);else copyConstructorProperties($AggregateError, $Error, {
  name: true
});
var AggregateErrorPrototype = $AggregateError.prototype = create($Error.prototype, {
  constructor: createPropertyDescriptor(1, $AggregateError),
  message: createPropertyDescriptor(1, ''),
  name: createPropertyDescriptor(1, 'AggregateError')
});

// `AggregateError` constructor
// https://tc39.es/ecma262/#sec-aggregate-error-constructor
$({
  global: true,
  constructor: true,
  arity: 2
}, {
  AggregateError: $AggregateError
});

/***/ }),

/***/ 1547:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove this module from `core-js@4` since it's replaced to module below
__webpack_require__(3505);

/***/ }),

/***/ 3033:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var uncurryThis = __webpack_require__(4060);
var fails = __webpack_require__(4631);
var ArrayBufferModule = __webpack_require__(1666);
var anObject = __webpack_require__(1791);
var toAbsoluteIndex = __webpack_require__(1634);
var toLength = __webpack_require__(7590);
var speciesConstructor = __webpack_require__(1485);
var ArrayBuffer = ArrayBufferModule.ArrayBuffer;
var DataView = ArrayBufferModule.DataView;
var DataViewPrototype = DataView.prototype;
var nativeArrayBufferSlice = uncurryThis(ArrayBuffer.prototype.slice);
var getUint8 = uncurryThis(DataViewPrototype.getUint8);
var setUint8 = uncurryThis(DataViewPrototype.setUint8);
var INCORRECT_SLICE = fails(function () {
  return !new ArrayBuffer(2).slice(1, undefined).byteLength;
});

// `ArrayBuffer.prototype.slice` method
// https://tc39.es/ecma262/#sec-arraybuffer.prototype.slice
$({
  target: 'ArrayBuffer',
  proto: true,
  unsafe: true,
  forced: INCORRECT_SLICE
}, {
  slice: function slice(start, end) {
    if (nativeArrayBufferSlice && end === undefined) {
      return nativeArrayBufferSlice(anObject(this), start); // FF fix
    }
    var length = anObject(this).byteLength;
    var first = toAbsoluteIndex(start, length);
    var fin = toAbsoluteIndex(end === undefined ? length : end, length);
    var result = new (speciesConstructor(this, ArrayBuffer))(toLength(fin - first));
    var viewSource = new DataView(this);
    var viewTarget = new DataView(result);
    var index = 0;
    while (first < fin) {
      setUint8(viewTarget, index++, getUint8(viewSource, first++));
    }
    return result;
  }
});

/***/ }),

/***/ 2419:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var toObject = __webpack_require__(2397);
var lengthOfArrayLike = __webpack_require__(3534);
var toIntegerOrInfinity = __webpack_require__(3923);
var addToUnscopables = __webpack_require__(8909);

// `Array.prototype.at` method
// https://github.com/tc39/proposal-relative-indexing-method
$({
  target: 'Array',
  proto: true
}, {
  at: function at(index) {
    var O = toObject(this);
    var len = lengthOfArrayLike(O);
    var relativeIndex = toIntegerOrInfinity(index);
    var k = relativeIndex >= 0 ? relativeIndex : len + relativeIndex;
    return k < 0 || k >= len ? undefined : O[k];
  }
});
addToUnscopables('at');

/***/ }),

/***/ 5331:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var $findLastIndex = (__webpack_require__(5031).findLastIndex);
var addToUnscopables = __webpack_require__(8909);

// `Array.prototype.findLastIndex` method
// https://github.com/tc39/proposal-array-find-from-last
$({
  target: 'Array',
  proto: true
}, {
  findLastIndex: function findLastIndex(callbackfn /* , that = undefined */) {
    return $findLastIndex(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
addToUnscopables('findLastIndex');

/***/ }),

/***/ 4142:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var $findLast = (__webpack_require__(5031).findLast);
var addToUnscopables = __webpack_require__(8909);

// `Array.prototype.findLast` method
// https://github.com/tc39/proposal-array-find-from-last
$({
  target: 'Array',
  proto: true
}, {
  findLast: function findLast(callbackfn /* , that = undefined */) {
    return $findLast(this, callbackfn, arguments.length > 1 ? arguments[1] : undefined);
  }
});
addToUnscopables('findLast');

/***/ }),

/***/ 1098:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var toObject = __webpack_require__(2397);
var lengthOfArrayLike = __webpack_require__(3534);
var setArrayLength = __webpack_require__(2183);
var doesNotExceedSafeInteger = __webpack_require__(8653);
var fails = __webpack_require__(4631);
var INCORRECT_TO_LENGTH = fails(function () {
  return [].push.call({
    length: 0x100000000
  }, 1) !== 4294967297;
});

// V8 and Safari <= 15.4, FF < 23 throws InternalError
// https://bugs.chromium.org/p/v8/issues/detail?id=12681
var properErrorOnNonWritableLength = function () {
  try {
    // eslint-disable-next-line es/no-object-defineproperty -- safe
    Object.defineProperty([], 'length', {
      writable: false
    }).push();
  } catch (error) {
    return error instanceof TypeError;
  }
};
var FORCED = INCORRECT_TO_LENGTH || !properErrorOnNonWritableLength();

// `Array.prototype.push` method
// https://tc39.es/ecma262/#sec-array.prototype.push
$({
  target: 'Array',
  proto: true,
  arity: 1,
  forced: FORCED
}, {
  // eslint-disable-next-line no-unused-vars -- required for `.length`
  push: function push(item) {
    var O = toObject(this);
    var len = lengthOfArrayLike(O);
    var argCount = arguments.length;
    doesNotExceedSafeInteger(len + argCount);
    for (var i = 0; i < argCount; i++) {
      O[len] = arguments[i];
      len++;
    }
    setArrayLength(O, len);
    return len;
  }
});

/***/ }),

/***/ 6034:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var uncurryThis = __webpack_require__(8712);
var isArray = __webpack_require__(7920);
var nativeReverse = uncurryThis([].reverse);
var test = [1, 2];

// `Array.prototype.reverse` method
// https://tc39.es/ecma262/#sec-array.prototype.reverse
// fix for Safari 12.0 bug
// https://bugs.webkit.org/show_bug.cgi?id=188794
$({
  target: 'Array',
  proto: true,
  forced: String(test) === String(test.reverse())
}, {
  reverse: function reverse() {
    // eslint-disable-next-line no-self-assign -- dirty hack
    if (isArray(this)) this.length = this.length;
    return nativeReverse(this);
  }
});

/***/ }),

/***/ 5942:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var arrayToReversed = __webpack_require__(228);
var toIndexedObject = __webpack_require__(2445);
var addToUnscopables = __webpack_require__(8909);
var $Array = Array;

// `Array.prototype.toReversed` method
// https://tc39.es/proposal-change-array-by-copy/#sec-array.prototype.toReversed
$({
  target: 'Array',
  proto: true
}, {
  toReversed: function toReversed() {
    return arrayToReversed(toIndexedObject(this), $Array);
  }
});
addToUnscopables('toReversed');

/***/ }),

/***/ 6529:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var uncurryThis = __webpack_require__(8712);
var aCallable = __webpack_require__(2978);
var toIndexedObject = __webpack_require__(2445);
var arrayFromConstructorAndList = __webpack_require__(9666);
var getVirtual = __webpack_require__(6540);
var addToUnscopables = __webpack_require__(8909);
var $Array = Array;
var sort = uncurryThis(getVirtual('Array').sort);

// `Array.prototype.toSorted` method
// https://tc39.es/proposal-change-array-by-copy/#sec-array.prototype.toSorted
$({
  target: 'Array',
  proto: true
}, {
  toSorted: function toSorted(compareFn) {
    if (compareFn !== undefined) aCallable(compareFn);
    var O = toIndexedObject(this);
    var A = arrayFromConstructorAndList($Array, O);
    return sort(A, compareFn);
  }
});
addToUnscopables('toSorted');

/***/ }),

/***/ 6786:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var addToUnscopables = __webpack_require__(8909);
var doesNotExceedSafeInteger = __webpack_require__(8653);
var lengthOfArrayLike = __webpack_require__(3534);
var toAbsoluteIndex = __webpack_require__(1634);
var toIndexedObject = __webpack_require__(2445);
var toIntegerOrInfinity = __webpack_require__(3923);
var $Array = Array;
var max = Math.max;
var min = Math.min;

// `Array.prototype.toSpliced` method
// https://tc39.es/proposal-change-array-by-copy/#sec-array.prototype.toSpliced
$({
  target: 'Array',
  proto: true
}, {
  toSpliced: function toSpliced(start, deleteCount /* , ...items */) {
    var O = toIndexedObject(this);
    var len = lengthOfArrayLike(O);
    var actualStart = toAbsoluteIndex(start, len);
    var argumentsLength = arguments.length;
    var k = 0;
    var insertCount, actualDeleteCount, newLen, A;
    if (argumentsLength === 0) {
      insertCount = actualDeleteCount = 0;
    } else if (argumentsLength === 1) {
      insertCount = 0;
      actualDeleteCount = len - actualStart;
    } else {
      insertCount = argumentsLength - 2;
      actualDeleteCount = min(max(toIntegerOrInfinity(deleteCount), 0), len - actualStart);
    }
    newLen = doesNotExceedSafeInteger(len + insertCount - actualDeleteCount);
    A = $Array(newLen);
    for (; k < actualStart; k++) A[k] = O[k];
    for (; k < actualStart + insertCount; k++) A[k] = arguments[k - actualStart + 2];
    for (; k < newLen; k++) A[k] = O[k + actualDeleteCount - insertCount];
    return A;
  }
});
addToUnscopables('toSpliced');

/***/ }),

/***/ 9973:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// this method was added to unscopables after implementation
// in popular engines, so it's moved to a separate module
var addToUnscopables = __webpack_require__(8909);

// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
addToUnscopables('flatMap');

/***/ }),

/***/ 1778:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// this method was added to unscopables after implementation
// in popular engines, so it's moved to a separate module
var addToUnscopables = __webpack_require__(8909);

// https://tc39.es/ecma262/#sec-array.prototype-@@unscopables
addToUnscopables('flat');

/***/ }),

/***/ 3537:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var toObject = __webpack_require__(2397);
var lengthOfArrayLike = __webpack_require__(3534);
var setArrayLength = __webpack_require__(2183);
var deletePropertyOrThrow = __webpack_require__(5334);
var doesNotExceedSafeInteger = __webpack_require__(8653);

// IE8-
var INCORRECT_RESULT = [].unshift(0) !== 1;

// V8 ~ Chrome < 71 and Safari <= 15.4, FF < 23 throws InternalError
var properErrorOnNonWritableLength = function () {
  try {
    // eslint-disable-next-line es/no-object-defineproperty -- safe
    Object.defineProperty([], 'length', {
      writable: false
    }).unshift();
  } catch (error) {
    return error instanceof TypeError;
  }
};
var FORCED = INCORRECT_RESULT || !properErrorOnNonWritableLength();

// `Array.prototype.unshift` method
// https://tc39.es/ecma262/#sec-array.prototype.unshift
$({
  target: 'Array',
  proto: true,
  arity: 1,
  forced: FORCED
}, {
  // eslint-disable-next-line no-unused-vars -- required for `.length`
  unshift: function unshift(item) {
    var O = toObject(this);
    var len = lengthOfArrayLike(O);
    var argCount = arguments.length;
    if (argCount) {
      doesNotExceedSafeInteger(len + argCount);
      var k = len;
      while (k--) {
        var to = k + argCount;
        if (k in O) O[to] = O[k];else deletePropertyOrThrow(O, to);
      }
      for (var j = 0; j < argCount; j++) {
        O[j] = arguments[j];
      }
    }
    return setArrayLength(O, len + argCount);
  }
});

/***/ }),

/***/ 5710:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var arrayWith = __webpack_require__(864);
var toIndexedObject = __webpack_require__(2445);
var $Array = Array;

// `Array.prototype.with` method
// https://tc39.es/proposal-change-array-by-copy/#sec-array.prototype.with
$({
  target: 'Array',
  proto: true
}, {
  'with': function (index, value) {
    return arrayWith(toIndexedObject(this), $Array, index, value);
  }
});

/***/ }),

/***/ 8768:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

/* eslint-disable no-unused-vars -- required for functions `.length` */
var $ = __webpack_require__(4334);
var global = __webpack_require__(6243);
var apply = __webpack_require__(2113);
var wrapErrorConstructorWithCause = __webpack_require__(561);
var WEB_ASSEMBLY = 'WebAssembly';
var WebAssembly = global[WEB_ASSEMBLY];
var FORCED = Error('e', {
  cause: 7
}).cause !== 7;
var exportGlobalErrorCauseWrapper = function (ERROR_NAME, wrapper) {
  var O = {};
  O[ERROR_NAME] = wrapErrorConstructorWithCause(ERROR_NAME, wrapper, FORCED);
  $({
    global: true,
    constructor: true,
    arity: 1,
    forced: FORCED
  }, O);
};
var exportWebAssemblyErrorCauseWrapper = function (ERROR_NAME, wrapper) {
  if (WebAssembly && WebAssembly[ERROR_NAME]) {
    var O = {};
    O[ERROR_NAME] = wrapErrorConstructorWithCause(WEB_ASSEMBLY + '.' + ERROR_NAME, wrapper, FORCED);
    $({
      target: WEB_ASSEMBLY,
      stat: true,
      constructor: true,
      arity: 1,
      forced: FORCED
    }, O);
  }
};

// https://tc39.es/ecma262/#sec-nativeerror
// https://github.com/tc39/proposal-error-cause
exportGlobalErrorCauseWrapper('Error', function (init) {
  return function Error(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('EvalError', function (init) {
  return function EvalError(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('RangeError', function (init) {
  return function RangeError(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('ReferenceError', function (init) {
  return function ReferenceError(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('SyntaxError', function (init) {
  return function SyntaxError(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('TypeError', function (init) {
  return function TypeError(message) {
    return apply(init, this, arguments);
  };
});
exportGlobalErrorCauseWrapper('URIError', function (init) {
  return function URIError(message) {
    return apply(init, this, arguments);
  };
});
exportWebAssemblyErrorCauseWrapper('CompileError', function (init) {
  return function CompileError(message) {
    return apply(init, this, arguments);
  };
});
exportWebAssemblyErrorCauseWrapper('LinkError', function (init) {
  return function LinkError(message) {
    return apply(init, this, arguments);
  };
});
exportWebAssemblyErrorCauseWrapper('RuntimeError', function (init) {
  return function RuntimeError(message) {
    return apply(init, this, arguments);
  };
});

/***/ }),

/***/ 993:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var global = __webpack_require__(6243);

// `globalThis` object
// https://tc39.es/ecma262/#sec-globalthis
$({
  global: true,
  forced: global.globalThis !== global
}, {
  globalThis: global
});

/***/ }),

/***/ 8302:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var getBuiltIn = __webpack_require__(8463);
var apply = __webpack_require__(2113);
var call = __webpack_require__(6277);
var uncurryThis = __webpack_require__(8712);
var fails = __webpack_require__(4631);
var isCallable = __webpack_require__(6509);
var isSymbol = __webpack_require__(2237);
var arraySlice = __webpack_require__(808);
var getReplacerFunction = __webpack_require__(7485);
var NATIVE_SYMBOL = __webpack_require__(2039);
var $String = String;
var $stringify = getBuiltIn('JSON', 'stringify');
var exec = uncurryThis(/./.exec);
var charAt = uncurryThis(''.charAt);
var charCodeAt = uncurryThis(''.charCodeAt);
var replace = uncurryThis(''.replace);
var numberToString = uncurryThis(1.0.toString);
var tester = /[\uD800-\uDFFF]/g;
var low = /^[\uD800-\uDBFF]$/;
var hi = /^[\uDC00-\uDFFF]$/;
var WRONG_SYMBOLS_CONVERSION = !NATIVE_SYMBOL || fails(function () {
  var symbol = getBuiltIn('Symbol')();
  // MS Edge converts symbol values to JSON as {}
  return $stringify([symbol]) != '[null]'
  // WebKit converts symbol values to JSON as null
  || $stringify({
    a: symbol
  }) != '{}'
  // V8 throws on boxed symbols
  || $stringify(Object(symbol)) != '{}';
});

// https://github.com/tc39/proposal-well-formed-stringify
var ILL_FORMED_UNICODE = fails(function () {
  return $stringify('\uDF06\uD834') !== '"\\udf06\\ud834"' || $stringify('\uDEAD') !== '"\\udead"';
});
var stringifyWithSymbolsFix = function (it, replacer) {
  var args = arraySlice(arguments);
  var $replacer = getReplacerFunction(replacer);
  if (!isCallable($replacer) && (it === undefined || isSymbol(it))) return; // IE8 returns string on undefined
  args[1] = function (key, value) {
    // some old implementations (like WebKit) could pass numbers as keys
    if (isCallable($replacer)) value = call($replacer, this, $String(key), value);
    if (!isSymbol(value)) return value;
  };
  return apply($stringify, null, args);
};
var fixIllFormed = function (match, offset, string) {
  var prev = charAt(string, offset - 1);
  var next = charAt(string, offset + 1);
  if (exec(low, match) && !exec(hi, next) || exec(hi, match) && !exec(low, prev)) {
    return '\\u' + numberToString(charCodeAt(match, 0), 16);
  }
  return match;
};
if ($stringify) {
  // `JSON.stringify` method
  // https://tc39.es/ecma262/#sec-json.stringify
  $({
    target: 'JSON',
    stat: true,
    arity: 3,
    forced: WRONG_SYMBOLS_CONVERSION || ILL_FORMED_UNICODE
  }, {
    // eslint-disable-next-line no-unused-vars -- required for `.length`
    stringify: function stringify(it, replacer, space) {
      var args = arraySlice(arguments);
      var result = apply(WRONG_SYMBOLS_CONVERSION ? stringifyWithSymbolsFix : $stringify, null, args);
      return ILL_FORMED_UNICODE && typeof result == 'string' ? replace(result, tester, fixIllFormed) : result;
    }
  });
}

/***/ }),

/***/ 7142:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var iterate = __webpack_require__(5716);
var createProperty = __webpack_require__(2600);

// `Object.fromEntries` method
// https://github.com/tc39/proposal-object-from-entries
$({
  target: 'Object',
  stat: true
}, {
  fromEntries: function fromEntries(iterable) {
    var obj = {};
    iterate(iterable, function (k, v) {
      createProperty(obj, k, v);
    }, {
      AS_ENTRIES: true
    });
    return obj;
  }
});

/***/ }),

/***/ 5507:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var hasOwn = __webpack_require__(8697);

// `Object.hasOwn` method
// https://github.com/tc39/proposal-accessible-object-hasownproperty
$({
  target: 'Object',
  stat: true
}, {
  hasOwn: hasOwn
});

/***/ }),

/***/ 3311:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var newPromiseCapabilityModule = __webpack_require__(9859);
var perform = __webpack_require__(6631);
var iterate = __webpack_require__(5716);
var PROMISE_STATICS_INCORRECT_ITERATION = __webpack_require__(4897);

// `Promise.allSettled` method
// https://tc39.es/ecma262/#sec-promise.allsettled
$({
  target: 'Promise',
  stat: true,
  forced: PROMISE_STATICS_INCORRECT_ITERATION
}, {
  allSettled: function allSettled(iterable) {
    var C = this;
    var capability = newPromiseCapabilityModule.f(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var promiseResolve = aCallable(C.resolve);
      var values = [];
      var counter = 0;
      var remaining = 1;
      iterate(iterable, function (promise) {
        var index = counter++;
        var alreadyCalled = false;
        remaining++;
        call(promiseResolve, C, promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[index] = {
            status: 'fulfilled',
            value: value
          };
          --remaining || resolve(values);
        }, function (error) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[index] = {
            status: 'rejected',
            reason: error
          };
          --remaining || resolve(values);
        });
      });
      --remaining || resolve(values);
    });
    if (result.error) reject(result.value);
    return capability.promise;
  }
});

/***/ }),

/***/ 9051:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var newPromiseCapabilityModule = __webpack_require__(9859);
var perform = __webpack_require__(6631);
var iterate = __webpack_require__(5716);
var PROMISE_STATICS_INCORRECT_ITERATION = __webpack_require__(4897);

// `Promise.all` method
// https://tc39.es/ecma262/#sec-promise.all
$({
  target: 'Promise',
  stat: true,
  forced: PROMISE_STATICS_INCORRECT_ITERATION
}, {
  all: function all(iterable) {
    var C = this;
    var capability = newPromiseCapabilityModule.f(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var $promiseResolve = aCallable(C.resolve);
      var values = [];
      var counter = 0;
      var remaining = 1;
      iterate(iterable, function (promise) {
        var index = counter++;
        var alreadyCalled = false;
        remaining++;
        call($promiseResolve, C, promise).then(function (value) {
          if (alreadyCalled) return;
          alreadyCalled = true;
          values[index] = value;
          --remaining || resolve(values);
        }, reject);
      });
      --remaining || resolve(values);
    });
    if (result.error) reject(result.value);
    return capability.promise;
  }
});

/***/ }),

/***/ 2006:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var getBuiltIn = __webpack_require__(8463);
var newPromiseCapabilityModule = __webpack_require__(9859);
var perform = __webpack_require__(6631);
var iterate = __webpack_require__(5716);
var PROMISE_STATICS_INCORRECT_ITERATION = __webpack_require__(4897);
var PROMISE_ANY_ERROR = 'No one promise resolved';

// `Promise.any` method
// https://tc39.es/ecma262/#sec-promise.any
$({
  target: 'Promise',
  stat: true,
  forced: PROMISE_STATICS_INCORRECT_ITERATION
}, {
  any: function any(iterable) {
    var C = this;
    var AggregateError = getBuiltIn('AggregateError');
    var capability = newPromiseCapabilityModule.f(C);
    var resolve = capability.resolve;
    var reject = capability.reject;
    var result = perform(function () {
      var promiseResolve = aCallable(C.resolve);
      var errors = [];
      var counter = 0;
      var remaining = 1;
      var alreadyResolved = false;
      iterate(iterable, function (promise) {
        var index = counter++;
        var alreadyRejected = false;
        remaining++;
        call(promiseResolve, C, promise).then(function (value) {
          if (alreadyRejected || alreadyResolved) return;
          alreadyResolved = true;
          resolve(value);
        }, function (error) {
          if (alreadyRejected || alreadyResolved) return;
          alreadyRejected = true;
          errors[index] = error;
          --remaining || reject(new AggregateError(errors, PROMISE_ANY_ERROR));
        });
      });
      --remaining || reject(new AggregateError(errors, PROMISE_ANY_ERROR));
    });
    if (result.error) reject(result.value);
    return capability.promise;
  }
});

/***/ }),

/***/ 2427:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var IS_PURE = __webpack_require__(1459);
var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(4652).CONSTRUCTOR);
var NativePromiseConstructor = __webpack_require__(574);
var getBuiltIn = __webpack_require__(8463);
var isCallable = __webpack_require__(6509);
var defineBuiltIn = __webpack_require__(9264);
var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;

// `Promise.prototype.catch` method
// https://tc39.es/ecma262/#sec-promise.prototype.catch
$({
  target: 'Promise',
  proto: true,
  forced: FORCED_PROMISE_CONSTRUCTOR,
  real: true
}, {
  'catch': function (onRejected) {
    return this.then(undefined, onRejected);
  }
});

// makes sure that native promise-based APIs `Promise#catch` properly works with patched `Promise#then`
if (!IS_PURE && isCallable(NativePromiseConstructor)) {
  var method = getBuiltIn('Promise').prototype['catch'];
  if (NativePromisePrototype['catch'] !== method) {
    defineBuiltIn(NativePromisePrototype, 'catch', method, {
      unsafe: true
    });
  }
}

/***/ }),

/***/ 6988:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var IS_PURE = __webpack_require__(1459);
var IS_NODE = __webpack_require__(5816);
var global = __webpack_require__(6243);
var call = __webpack_require__(6277);
var defineBuiltIn = __webpack_require__(9264);
var setPrototypeOf = __webpack_require__(4767);
var setToStringTag = __webpack_require__(7047);
var setSpecies = __webpack_require__(7785);
var aCallable = __webpack_require__(2978);
var isCallable = __webpack_require__(6509);
var isObject = __webpack_require__(8154);
var anInstance = __webpack_require__(9663);
var speciesConstructor = __webpack_require__(1485);
var task = (__webpack_require__(1457).set);
var microtask = __webpack_require__(1819);
var hostReportErrors = __webpack_require__(1437);
var perform = __webpack_require__(6631);
var Queue = __webpack_require__(9633);
var InternalStateModule = __webpack_require__(3653);
var NativePromiseConstructor = __webpack_require__(574);
var PromiseConstructorDetection = __webpack_require__(4652);
var newPromiseCapabilityModule = __webpack_require__(9859);
var PROMISE = 'Promise';
var FORCED_PROMISE_CONSTRUCTOR = PromiseConstructorDetection.CONSTRUCTOR;
var NATIVE_PROMISE_REJECTION_EVENT = PromiseConstructorDetection.REJECTION_EVENT;
var NATIVE_PROMISE_SUBCLASSING = PromiseConstructorDetection.SUBCLASSING;
var getInternalPromiseState = InternalStateModule.getterFor(PROMISE);
var setInternalState = InternalStateModule.set;
var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;
var PromiseConstructor = NativePromiseConstructor;
var PromisePrototype = NativePromisePrototype;
var TypeError = global.TypeError;
var document = global.document;
var process = global.process;
var newPromiseCapability = newPromiseCapabilityModule.f;
var newGenericPromiseCapability = newPromiseCapability;
var DISPATCH_EVENT = !!(document && document.createEvent && global.dispatchEvent);
var UNHANDLED_REJECTION = 'unhandledrejection';
var REJECTION_HANDLED = 'rejectionhandled';
var PENDING = 0;
var FULFILLED = 1;
var REJECTED = 2;
var HANDLED = 1;
var UNHANDLED = 2;
var Internal, OwnPromiseCapability, PromiseWrapper, nativeThen;

// helpers
var isThenable = function (it) {
  var then;
  return isObject(it) && isCallable(then = it.then) ? then : false;
};
var callReaction = function (reaction, state) {
  var value = state.value;
  var ok = state.state == FULFILLED;
  var handler = ok ? reaction.ok : reaction.fail;
  var resolve = reaction.resolve;
  var reject = reaction.reject;
  var domain = reaction.domain;
  var result, then, exited;
  try {
    if (handler) {
      if (!ok) {
        if (state.rejection === UNHANDLED) onHandleUnhandled(state);
        state.rejection = HANDLED;
      }
      if (handler === true) result = value;else {
        if (domain) domain.enter();
        result = handler(value); // can throw
        if (domain) {
          domain.exit();
          exited = true;
        }
      }
      if (result === reaction.promise) {
        reject(TypeError('Promise-chain cycle'));
      } else if (then = isThenable(result)) {
        call(then, result, resolve, reject);
      } else resolve(result);
    } else reject(value);
  } catch (error) {
    if (domain && !exited) domain.exit();
    reject(error);
  }
};
var notify = function (state, isReject) {
  if (state.notified) return;
  state.notified = true;
  microtask(function () {
    var reactions = state.reactions;
    var reaction;
    while (reaction = reactions.get()) {
      callReaction(reaction, state);
    }
    state.notified = false;
    if (isReject && !state.rejection) onUnhandled(state);
  });
};
var dispatchEvent = function (name, promise, reason) {
  var event, handler;
  if (DISPATCH_EVENT) {
    event = document.createEvent('Event');
    event.promise = promise;
    event.reason = reason;
    event.initEvent(name, false, true);
    global.dispatchEvent(event);
  } else event = {
    promise: promise,
    reason: reason
  };
  if (!NATIVE_PROMISE_REJECTION_EVENT && (handler = global['on' + name])) handler(event);else if (name === UNHANDLED_REJECTION) hostReportErrors('Unhandled promise rejection', reason);
};
var onUnhandled = function (state) {
  call(task, global, function () {
    var promise = state.facade;
    var value = state.value;
    var IS_UNHANDLED = isUnhandled(state);
    var result;
    if (IS_UNHANDLED) {
      result = perform(function () {
        if (IS_NODE) {
          process.emit('unhandledRejection', value, promise);
        } else dispatchEvent(UNHANDLED_REJECTION, promise, value);
      });
      // Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
      state.rejection = IS_NODE || isUnhandled(state) ? UNHANDLED : HANDLED;
      if (result.error) throw result.value;
    }
  });
};
var isUnhandled = function (state) {
  return state.rejection !== HANDLED && !state.parent;
};
var onHandleUnhandled = function (state) {
  call(task, global, function () {
    var promise = state.facade;
    if (IS_NODE) {
      process.emit('rejectionHandled', promise);
    } else dispatchEvent(REJECTION_HANDLED, promise, state.value);
  });
};
var bind = function (fn, state, unwrap) {
  return function (value) {
    fn(state, value, unwrap);
  };
};
var internalReject = function (state, value, unwrap) {
  if (state.done) return;
  state.done = true;
  if (unwrap) state = unwrap;
  state.value = value;
  state.state = REJECTED;
  notify(state, true);
};
var internalResolve = function (state, value, unwrap) {
  if (state.done) return;
  state.done = true;
  if (unwrap) state = unwrap;
  try {
    if (state.facade === value) throw TypeError("Promise can't be resolved itself");
    var then = isThenable(value);
    if (then) {
      microtask(function () {
        var wrapper = {
          done: false
        };
        try {
          call(then, value, bind(internalResolve, wrapper, state), bind(internalReject, wrapper, state));
        } catch (error) {
          internalReject(wrapper, error, state);
        }
      });
    } else {
      state.value = value;
      state.state = FULFILLED;
      notify(state, false);
    }
  } catch (error) {
    internalReject({
      done: false
    }, error, state);
  }
};

// constructor polyfill
if (FORCED_PROMISE_CONSTRUCTOR) {
  // 25.4.3.1 Promise(executor)
  PromiseConstructor = function Promise(executor) {
    anInstance(this, PromisePrototype);
    aCallable(executor);
    call(Internal, this);
    var state = getInternalPromiseState(this);
    try {
      executor(bind(internalResolve, state), bind(internalReject, state));
    } catch (error) {
      internalReject(state, error);
    }
  };
  PromisePrototype = PromiseConstructor.prototype;

  // eslint-disable-next-line no-unused-vars -- required for `.length`
  Internal = function Promise(executor) {
    setInternalState(this, {
      type: PROMISE,
      done: false,
      notified: false,
      parent: false,
      reactions: new Queue(),
      rejection: false,
      state: PENDING,
      value: undefined
    });
  };

  // `Promise.prototype.then` method
  // https://tc39.es/ecma262/#sec-promise.prototype.then
  Internal.prototype = defineBuiltIn(PromisePrototype, 'then', function then(onFulfilled, onRejected) {
    var state = getInternalPromiseState(this);
    var reaction = newPromiseCapability(speciesConstructor(this, PromiseConstructor));
    state.parent = true;
    reaction.ok = isCallable(onFulfilled) ? onFulfilled : true;
    reaction.fail = isCallable(onRejected) && onRejected;
    reaction.domain = IS_NODE ? process.domain : undefined;
    if (state.state == PENDING) state.reactions.add(reaction);else microtask(function () {
      callReaction(reaction, state);
    });
    return reaction.promise;
  });
  OwnPromiseCapability = function () {
    var promise = new Internal();
    var state = getInternalPromiseState(promise);
    this.promise = promise;
    this.resolve = bind(internalResolve, state);
    this.reject = bind(internalReject, state);
  };
  newPromiseCapabilityModule.f = newPromiseCapability = function (C) {
    return C === PromiseConstructor || C === PromiseWrapper ? new OwnPromiseCapability(C) : newGenericPromiseCapability(C);
  };
  if (!IS_PURE && isCallable(NativePromiseConstructor) && NativePromisePrototype !== Object.prototype) {
    nativeThen = NativePromisePrototype.then;
    if (!NATIVE_PROMISE_SUBCLASSING) {
      // make `Promise#then` return a polyfilled `Promise` for native promise-based APIs
      defineBuiltIn(NativePromisePrototype, 'then', function then(onFulfilled, onRejected) {
        var that = this;
        return new PromiseConstructor(function (resolve, reject) {
          call(nativeThen, that, resolve, reject);
        }).then(onFulfilled, onRejected);
        // https://github.com/zloirock/core-js/issues/640
      }, {
        unsafe: true
      });
    }

    // make `.constructor === Promise` work for native promise-based APIs
    try {
      delete NativePromisePrototype.constructor;
    } catch (error) {/* empty */}

    // make `instanceof Promise` work for native promise-based APIs
    if (setPrototypeOf) {
      setPrototypeOf(NativePromisePrototype, PromisePrototype);
    }
  }
}
$({
  global: true,
  constructor: true,
  wrap: true,
  forced: FORCED_PROMISE_CONSTRUCTOR
}, {
  Promise: PromiseConstructor
});
setToStringTag(PromiseConstructor, PROMISE, false, true);
setSpecies(PROMISE);

/***/ }),

/***/ 9943:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var IS_PURE = __webpack_require__(1459);
var NativePromiseConstructor = __webpack_require__(574);
var fails = __webpack_require__(4631);
var getBuiltIn = __webpack_require__(8463);
var isCallable = __webpack_require__(6509);
var speciesConstructor = __webpack_require__(1485);
var promiseResolve = __webpack_require__(9126);
var defineBuiltIn = __webpack_require__(9264);
var NativePromisePrototype = NativePromiseConstructor && NativePromiseConstructor.prototype;

// Safari bug https://bugs.webkit.org/show_bug.cgi?id=200829
var NON_GENERIC = !!NativePromiseConstructor && fails(function () {
  // eslint-disable-next-line unicorn/no-thenable -- required for testing
  NativePromisePrototype['finally'].call({
    then: function () {/* empty */}
  }, function () {/* empty */});
});

// `Promise.prototype.finally` method
// https://tc39.es/ecma262/#sec-promise.prototype.finally
$({
  target: 'Promise',
  proto: true,
  real: true,
  forced: NON_GENERIC
}, {
  'finally': function (onFinally) {
    var C = speciesConstructor(this, getBuiltIn('Promise'));
    var isFunction = isCallable(onFinally);
    return this.then(isFunction ? function (x) {
      return promiseResolve(C, onFinally()).then(function () {
        return x;
      });
    } : onFinally, isFunction ? function (e) {
      return promiseResolve(C, onFinally()).then(function () {
        throw e;
      });
    } : onFinally);
  }
});

// makes sure that native promise-based APIs `Promise#finally` properly works with patched `Promise#then`
if (!IS_PURE && isCallable(NativePromiseConstructor)) {
  var method = getBuiltIn('Promise').prototype['finally'];
  if (NativePromisePrototype['finally'] !== method) {
    defineBuiltIn(NativePromisePrototype, 'finally', method, {
      unsafe: true
    });
  }
}

/***/ }),

/***/ 2362:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove this module from `core-js@4` since it's split to modules listed below
__webpack_require__(6988);
__webpack_require__(9051);
__webpack_require__(2427);
__webpack_require__(807);
__webpack_require__(8257);
__webpack_require__(9824);

/***/ }),

/***/ 807:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var newPromiseCapabilityModule = __webpack_require__(9859);
var perform = __webpack_require__(6631);
var iterate = __webpack_require__(5716);
var PROMISE_STATICS_INCORRECT_ITERATION = __webpack_require__(4897);

// `Promise.race` method
// https://tc39.es/ecma262/#sec-promise.race
$({
  target: 'Promise',
  stat: true,
  forced: PROMISE_STATICS_INCORRECT_ITERATION
}, {
  race: function race(iterable) {
    var C = this;
    var capability = newPromiseCapabilityModule.f(C);
    var reject = capability.reject;
    var result = perform(function () {
      var $promiseResolve = aCallable(C.resolve);
      iterate(iterable, function (promise) {
        call($promiseResolve, C, promise).then(capability.resolve, reject);
      });
    });
    if (result.error) reject(result.value);
    return capability.promise;
  }
});

/***/ }),

/***/ 8257:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var newPromiseCapabilityModule = __webpack_require__(9859);
var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(4652).CONSTRUCTOR);

// `Promise.reject` method
// https://tc39.es/ecma262/#sec-promise.reject
$({
  target: 'Promise',
  stat: true,
  forced: FORCED_PROMISE_CONSTRUCTOR
}, {
  reject: function reject(r) {
    var capability = newPromiseCapabilityModule.f(this);
    call(capability.reject, undefined, r);
    return capability.promise;
  }
});

/***/ }),

/***/ 9824:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var getBuiltIn = __webpack_require__(8463);
var IS_PURE = __webpack_require__(1459);
var NativePromiseConstructor = __webpack_require__(574);
var FORCED_PROMISE_CONSTRUCTOR = (__webpack_require__(4652).CONSTRUCTOR);
var promiseResolve = __webpack_require__(9126);
var PromiseConstructorWrapper = getBuiltIn('Promise');
var CHECK_WRAPPER = IS_PURE && !FORCED_PROMISE_CONSTRUCTOR;

// `Promise.resolve` method
// https://tc39.es/ecma262/#sec-promise.resolve
$({
  target: 'Promise',
  stat: true,
  forced: IS_PURE || FORCED_PROMISE_CONSTRUCTOR
}, {
  resolve: function resolve(x) {
    return promiseResolve(CHECK_WRAPPER && this === PromiseConstructorWrapper ? NativePromiseConstructor : this, x);
  }
});

/***/ }),

/***/ 6552:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var global = __webpack_require__(6243);
var setToStringTag = __webpack_require__(7047);
$({
  global: true
}, {
  Reflect: {}
});

// Reflect[@@toStringTag] property
// https://tc39.es/ecma262/#sec-reflect-@@tostringtag
setToStringTag(global.Reflect, 'Reflect', true);

/***/ }),

/***/ 9007:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var exec = __webpack_require__(4899);

// `RegExp.prototype.exec` method
// https://tc39.es/ecma262/#sec-regexp.prototype.exec
$({
  target: 'RegExp',
  proto: true,
  forced: /./.exec !== exec
}, {
  exec: exec
});

/***/ }),

/***/ 4559:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var global = __webpack_require__(6243);
var DESCRIPTORS = __webpack_require__(5444);
var defineBuiltInAccessor = __webpack_require__(8770);
var regExpFlags = __webpack_require__(7939);
var fails = __webpack_require__(4631);

// babel-minify and Closure Compiler transpiles RegExp('.', 'd') -> /./d and it causes SyntaxError
var RegExp = global.RegExp;
var RegExpPrototype = RegExp.prototype;
var FORCED = DESCRIPTORS && fails(function () {
  var INDICES_SUPPORT = true;
  try {
    RegExp('.', 'd');
  } catch (error) {
    INDICES_SUPPORT = false;
  }
  var O = {};
  // modern V8 bug
  var calls = '';
  var expected = INDICES_SUPPORT ? 'dgimsy' : 'gimsy';
  var addGetter = function (key, chr) {
    // eslint-disable-next-line es/no-object-defineproperty -- safe
    Object.defineProperty(O, key, {
      get: function () {
        calls += chr;
        return true;
      }
    });
  };
  var pairs = {
    dotAll: 's',
    global: 'g',
    ignoreCase: 'i',
    multiline: 'm',
    sticky: 'y'
  };
  if (INDICES_SUPPORT) pairs.hasIndices = 'd';
  for (var key in pairs) addGetter(key, pairs[key]);

  // eslint-disable-next-line es/no-object-getownpropertydescriptor -- safe
  var result = Object.getOwnPropertyDescriptor(RegExpPrototype, 'flags').get.call(O);
  return result !== expected || calls !== expected;
});

// `RegExp.prototype.flags` getter
// https://tc39.es/ecma262/#sec-get-regexp.prototype.flags
if (FORCED) defineBuiltInAccessor(RegExpPrototype, 'flags', {
  configurable: true,
  get: regExpFlags
});

/***/ }),

/***/ 8453:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var uncurryThis = __webpack_require__(8712);
var requireObjectCoercible = __webpack_require__(3662);
var toIntegerOrInfinity = __webpack_require__(3923);
var toString = __webpack_require__(5479);
var fails = __webpack_require__(4631);
var charAt = uncurryThis(''.charAt);
var FORCED = fails(function () {
  // eslint-disable-next-line es/no-array-string-prototype-at -- safe
  return '𠮷'.at(-2) !== '\uD842';
});

// `String.prototype.at` method
// https://github.com/tc39/proposal-relative-indexing-method
$({
  target: 'String',
  proto: true,
  forced: FORCED
}, {
  at: function at(index) {
    var S = toString(requireObjectCoercible(this));
    var len = S.length;
    var relativeIndex = toIntegerOrInfinity(index);
    var k = relativeIndex >= 0 ? relativeIndex : len + relativeIndex;
    return k < 0 || k >= len ? undefined : charAt(S, k);
  }
});

/***/ }),

/***/ 8839:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


/* eslint-disable es/no-string-prototype-matchall -- safe */
var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var uncurryThis = __webpack_require__(4060);
var createIteratorConstructor = __webpack_require__(5138);
var createIterResultObject = __webpack_require__(9097);
var requireObjectCoercible = __webpack_require__(3662);
var toLength = __webpack_require__(7590);
var toString = __webpack_require__(5479);
var anObject = __webpack_require__(1791);
var isNullOrUndefined = __webpack_require__(2797);
var classof = __webpack_require__(7384);
var isRegExp = __webpack_require__(892);
var getRegExpFlags = __webpack_require__(5650);
var getMethod = __webpack_require__(7750);
var defineBuiltIn = __webpack_require__(9264);
var fails = __webpack_require__(4631);
var wellKnownSymbol = __webpack_require__(2091);
var speciesConstructor = __webpack_require__(1485);
var advanceStringIndex = __webpack_require__(925);
var regExpExec = __webpack_require__(9397);
var InternalStateModule = __webpack_require__(3653);
var IS_PURE = __webpack_require__(1459);
var MATCH_ALL = wellKnownSymbol('matchAll');
var REGEXP_STRING = 'RegExp String';
var REGEXP_STRING_ITERATOR = REGEXP_STRING + ' Iterator';
var setInternalState = InternalStateModule.set;
var getInternalState = InternalStateModule.getterFor(REGEXP_STRING_ITERATOR);
var RegExpPrototype = RegExp.prototype;
var $TypeError = TypeError;
var stringIndexOf = uncurryThis(''.indexOf);
var nativeMatchAll = uncurryThis(''.matchAll);
var WORKS_WITH_NON_GLOBAL_REGEX = !!nativeMatchAll && !fails(function () {
  nativeMatchAll('a', /./);
});
var $RegExpStringIterator = createIteratorConstructor(function RegExpStringIterator(regexp, string, $global, fullUnicode) {
  setInternalState(this, {
    type: REGEXP_STRING_ITERATOR,
    regexp: regexp,
    string: string,
    global: $global,
    unicode: fullUnicode,
    done: false
  });
}, REGEXP_STRING, function next() {
  var state = getInternalState(this);
  if (state.done) return createIterResultObject(undefined, true);
  var R = state.regexp;
  var S = state.string;
  var match = regExpExec(R, S);
  if (match === null) {
    state.done = true;
    return createIterResultObject(undefined, true);
  }
  if (state.global) {
    if (toString(match[0]) === '') R.lastIndex = advanceStringIndex(S, toLength(R.lastIndex), state.unicode);
    return createIterResultObject(match, false);
  }
  state.done = true;
  return createIterResultObject(match, false);
});
var $matchAll = function (string) {
  var R = anObject(this);
  var S = toString(string);
  var C = speciesConstructor(R, RegExp);
  var flags = toString(getRegExpFlags(R));
  var matcher, $global, fullUnicode;
  matcher = new C(C === RegExp ? R.source : R, flags);
  $global = !!~stringIndexOf(flags, 'g');
  fullUnicode = !!~stringIndexOf(flags, 'u');
  matcher.lastIndex = toLength(R.lastIndex);
  return new $RegExpStringIterator(matcher, S, $global, fullUnicode);
};

// `String.prototype.matchAll` method
// https://tc39.es/ecma262/#sec-string.prototype.matchall
$({
  target: 'String',
  proto: true,
  forced: WORKS_WITH_NON_GLOBAL_REGEX
}, {
  matchAll: function matchAll(regexp) {
    var O = requireObjectCoercible(this);
    var flags, S, matcher, rx;
    if (!isNullOrUndefined(regexp)) {
      if (isRegExp(regexp)) {
        flags = toString(requireObjectCoercible(getRegExpFlags(regexp)));
        if (!~stringIndexOf(flags, 'g')) throw $TypeError('`.matchAll` does not allow non-global regexes');
      }
      if (WORKS_WITH_NON_GLOBAL_REGEX) return nativeMatchAll(O, regexp);
      matcher = getMethod(regexp, MATCH_ALL);
      if (matcher === undefined && IS_PURE && classof(regexp) == 'RegExp') matcher = $matchAll;
      if (matcher) return call(matcher, regexp, O);
    } else if (WORKS_WITH_NON_GLOBAL_REGEX) return nativeMatchAll(O, regexp);
    S = toString(O);
    rx = new RegExp(regexp, 'g');
    return IS_PURE ? call($matchAll, rx, S) : rx[MATCH_ALL](S);
  }
});
IS_PURE || MATCH_ALL in RegExpPrototype || defineBuiltIn(RegExpPrototype, MATCH_ALL, $matchAll);

/***/ }),

/***/ 6658:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var uncurryThis = __webpack_require__(8712);
var requireObjectCoercible = __webpack_require__(3662);
var isCallable = __webpack_require__(6509);
var isNullOrUndefined = __webpack_require__(2797);
var isRegExp = __webpack_require__(892);
var toString = __webpack_require__(5479);
var getMethod = __webpack_require__(7750);
var getRegExpFlags = __webpack_require__(5650);
var getSubstitution = __webpack_require__(9990);
var wellKnownSymbol = __webpack_require__(2091);
var IS_PURE = __webpack_require__(1459);
var REPLACE = wellKnownSymbol('replace');
var $TypeError = TypeError;
var indexOf = uncurryThis(''.indexOf);
var replace = uncurryThis(''.replace);
var stringSlice = uncurryThis(''.slice);
var max = Math.max;
var stringIndexOf = function (string, searchValue, fromIndex) {
  if (fromIndex > string.length) return -1;
  if (searchValue === '') return fromIndex;
  return indexOf(string, searchValue, fromIndex);
};

// `String.prototype.replaceAll` method
// https://tc39.es/ecma262/#sec-string.prototype.replaceall
$({
  target: 'String',
  proto: true
}, {
  replaceAll: function replaceAll(searchValue, replaceValue) {
    var O = requireObjectCoercible(this);
    var IS_REG_EXP, flags, replacer, string, searchString, functionalReplace, searchLength, advanceBy, replacement;
    var position = 0;
    var endOfLastMatch = 0;
    var result = '';
    if (!isNullOrUndefined(searchValue)) {
      IS_REG_EXP = isRegExp(searchValue);
      if (IS_REG_EXP) {
        flags = toString(requireObjectCoercible(getRegExpFlags(searchValue)));
        if (!~indexOf(flags, 'g')) throw $TypeError('`.replaceAll` does not allow non-global regexes');
      }
      replacer = getMethod(searchValue, REPLACE);
      if (replacer) {
        return call(replacer, searchValue, O, replaceValue);
      } else if (IS_PURE && IS_REG_EXP) {
        return replace(toString(O), searchValue, replaceValue);
      }
    }
    string = toString(O);
    searchString = toString(searchValue);
    functionalReplace = isCallable(replaceValue);
    if (!functionalReplace) replaceValue = toString(replaceValue);
    searchLength = searchString.length;
    advanceBy = max(1, searchLength);
    position = stringIndexOf(string, searchString, 0);
    while (position !== -1) {
      replacement = functionalReplace ? toString(replaceValue(searchString, position, string)) : getSubstitution(searchString, string, position, [], undefined, replaceValue);
      result += stringSlice(string, endOfLastMatch, position) + replacement;
      endOfLastMatch = position + searchLength;
      position = stringIndexOf(string, searchString, position + advanceBy);
    }
    if (endOfLastMatch < string.length) {
      result += stringSlice(string, endOfLastMatch);
    }
    return result;
  }
});

/***/ }),

/***/ 1432:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var apply = __webpack_require__(2113);
var call = __webpack_require__(6277);
var uncurryThis = __webpack_require__(8712);
var fixRegExpWellKnownSymbolLogic = __webpack_require__(2068);
var fails = __webpack_require__(4631);
var anObject = __webpack_require__(1791);
var isCallable = __webpack_require__(6509);
var isNullOrUndefined = __webpack_require__(2797);
var toIntegerOrInfinity = __webpack_require__(3923);
var toLength = __webpack_require__(7590);
var toString = __webpack_require__(5479);
var requireObjectCoercible = __webpack_require__(3662);
var advanceStringIndex = __webpack_require__(925);
var getMethod = __webpack_require__(7750);
var getSubstitution = __webpack_require__(9990);
var regExpExec = __webpack_require__(9397);
var wellKnownSymbol = __webpack_require__(2091);
var REPLACE = wellKnownSymbol('replace');
var max = Math.max;
var min = Math.min;
var concat = uncurryThis([].concat);
var push = uncurryThis([].push);
var stringIndexOf = uncurryThis(''.indexOf);
var stringSlice = uncurryThis(''.slice);
var maybeToString = function (it) {
  return it === undefined ? it : String(it);
};

// IE <= 11 replaces $0 with the whole match, as if it was $&
// https://stackoverflow.com/questions/6024666/getting-ie-to-replace-a-regex-with-the-literal-string-0
var REPLACE_KEEPS_$0 = function () {
  // eslint-disable-next-line regexp/prefer-escape-replacement-dollar-char -- required for testing
  return 'a'.replace(/./, '$0') === '$0';
}();

// Safari <= 13.0.3(?) substitutes nth capture where n>m with an empty string
var REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE = function () {
  if (/./[REPLACE]) {
    return /./[REPLACE]('a', '$0') === '';
  }
  return false;
}();
var REPLACE_SUPPORTS_NAMED_GROUPS = !fails(function () {
  var re = /./;
  re.exec = function () {
    var result = [];
    result.groups = {
      a: '7'
    };
    return result;
  };
  // eslint-disable-next-line regexp/no-useless-dollar-replacements -- false positive
  return ''.replace(re, '$<a>') !== '7';
});

// @@replace logic
fixRegExpWellKnownSymbolLogic('replace', function (_, nativeReplace, maybeCallNative) {
  var UNSAFE_SUBSTITUTE = REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE ? '$' : '$0';
  return [
  // `String.prototype.replace` method
  // https://tc39.es/ecma262/#sec-string.prototype.replace
  function replace(searchValue, replaceValue) {
    var O = requireObjectCoercible(this);
    var replacer = isNullOrUndefined(searchValue) ? undefined : getMethod(searchValue, REPLACE);
    return replacer ? call(replacer, searchValue, O, replaceValue) : call(nativeReplace, toString(O), searchValue, replaceValue);
  },
  // `RegExp.prototype[@@replace]` method
  // https://tc39.es/ecma262/#sec-regexp.prototype-@@replace
  function (string, replaceValue) {
    var rx = anObject(this);
    var S = toString(string);
    if (typeof replaceValue == 'string' && stringIndexOf(replaceValue, UNSAFE_SUBSTITUTE) === -1 && stringIndexOf(replaceValue, '$<') === -1) {
      var res = maybeCallNative(nativeReplace, rx, S, replaceValue);
      if (res.done) return res.value;
    }
    var functionalReplace = isCallable(replaceValue);
    if (!functionalReplace) replaceValue = toString(replaceValue);
    var global = rx.global;
    if (global) {
      var fullUnicode = rx.unicode;
      rx.lastIndex = 0;
    }
    var results = [];
    while (true) {
      var result = regExpExec(rx, S);
      if (result === null) break;
      push(results, result);
      if (!global) break;
      var matchStr = toString(result[0]);
      if (matchStr === '') rx.lastIndex = advanceStringIndex(S, toLength(rx.lastIndex), fullUnicode);
    }
    var accumulatedResult = '';
    var nextSourcePosition = 0;
    for (var i = 0; i < results.length; i++) {
      result = results[i];
      var matched = toString(result[0]);
      var position = max(min(toIntegerOrInfinity(result.index), S.length), 0);
      var captures = [];
      // NOTE: This is equivalent to
      //   captures = result.slice(1).map(maybeToString)
      // but for some reason `nativeSlice.call(result, 1, result.length)` (called in
      // the slice polyfill when slicing native arrays) "doesn't work" in safari 9 and
      // causes a crash (https://pastebin.com/N21QzeQA) when trying to debug it.
      for (var j = 1; j < result.length; j++) push(captures, maybeToString(result[j]));
      var namedCaptures = result.groups;
      if (functionalReplace) {
        var replacerArgs = concat([matched], captures, position, S);
        if (namedCaptures !== undefined) push(replacerArgs, namedCaptures);
        var replacement = toString(apply(replaceValue, undefined, replacerArgs));
      } else {
        replacement = getSubstitution(matched, S, position, captures, namedCaptures, replaceValue);
      }
      if (position >= nextSourcePosition) {
        accumulatedResult += stringSlice(S, nextSourcePosition, position) + replacement;
        nextSourcePosition = position + matched.length;
      }
    }
    return accumulatedResult + stringSlice(S, nextSourcePosition);
  }];
}, !REPLACE_SUPPORTS_NAMED_GROUPS || !REPLACE_KEEPS_$0 || REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE);

/***/ }),

/***/ 1402:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove this line from `core-js@4`
__webpack_require__(1033);
var $ = __webpack_require__(4334);
var trimEnd = __webpack_require__(4330);

// `String.prototype.trimEnd` method
// https://tc39.es/ecma262/#sec-string.prototype.trimend
// eslint-disable-next-line es/no-string-prototype-trimstart-trimend -- safe
$({
  target: 'String',
  proto: true,
  name: 'trimEnd',
  forced: ''.trimEnd !== trimEnd
}, {
  trimEnd: trimEnd
});

/***/ }),

/***/ 1033:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var trimEnd = __webpack_require__(4330);

// `String.prototype.trimRight` method
// https://tc39.es/ecma262/#sec-string.prototype.trimend
// eslint-disable-next-line es/no-string-prototype-trimleft-trimright -- safe
$({
  target: 'String',
  proto: true,
  name: 'trimEnd',
  forced: ''.trimRight !== trimEnd
}, {
  trimRight: trimEnd
});

/***/ }),

/***/ 5826:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var $trim = (__webpack_require__(6850).trim);
var forcedStringTrimMethod = __webpack_require__(8650);

// `String.prototype.trim` method
// https://tc39.es/ecma262/#sec-string.prototype.trim
$({
  target: 'String',
  proto: true,
  forced: forcedStringTrimMethod('trim')
}, {
  trim: function trim() {
    return $trim(this);
  }
});

/***/ }),

/***/ 5951:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
// `Symbol.prototype.description` getter
// https://tc39.es/ecma262/#sec-symbol.prototype.description


var $ = __webpack_require__(4334);
var DESCRIPTORS = __webpack_require__(5444);
var global = __webpack_require__(6243);
var uncurryThis = __webpack_require__(8712);
var hasOwn = __webpack_require__(8697);
var isCallable = __webpack_require__(6509);
var isPrototypeOf = __webpack_require__(1649);
var toString = __webpack_require__(5479);
var defineBuiltInAccessor = __webpack_require__(8770);
var copyConstructorProperties = __webpack_require__(8004);
var NativeSymbol = global.Symbol;
var SymbolPrototype = NativeSymbol && NativeSymbol.prototype;
if (DESCRIPTORS && isCallable(NativeSymbol) && (!('description' in SymbolPrototype) ||
// Safari 12 bug
NativeSymbol().description !== undefined)) {
  var EmptyStringDescriptionStore = {};
  // wrap Symbol constructor for correct work with undefined description
  var SymbolWrapper = function Symbol() {
    var description = arguments.length < 1 || arguments[0] === undefined ? undefined : toString(arguments[0]);
    var result = isPrototypeOf(SymbolPrototype, this) ? new NativeSymbol(description)
    // in Edge 13, String(Symbol(undefined)) === 'Symbol(undefined)'
    : description === undefined ? NativeSymbol() : NativeSymbol(description);
    if (description === '') EmptyStringDescriptionStore[result] = true;
    return result;
  };
  copyConstructorProperties(SymbolWrapper, NativeSymbol);
  SymbolWrapper.prototype = SymbolPrototype;
  SymbolPrototype.constructor = SymbolWrapper;
  var NATIVE_SYMBOL = String(NativeSymbol('test')) == 'Symbol(test)';
  var thisSymbolValue = uncurryThis(SymbolPrototype.valueOf);
  var symbolDescriptiveString = uncurryThis(SymbolPrototype.toString);
  var regexp = /^Symbol\((.*)\)[^)]+$/;
  var replace = uncurryThis(''.replace);
  var stringSlice = uncurryThis(''.slice);
  defineBuiltInAccessor(SymbolPrototype, 'description', {
    configurable: true,
    get: function description() {
      var symbol = thisSymbolValue(this);
      if (hasOwn(EmptyStringDescriptionStore, symbol)) return '';
      var string = symbolDescriptiveString(symbol);
      var desc = NATIVE_SYMBOL ? stringSlice(string, 7, -1) : replace(string, regexp, '$1');
      return desc === '' ? undefined : desc;
    }
  });
  $({
    global: true,
    constructor: true,
    forced: true
  }, {
    Symbol: SymbolWrapper
  });
}

/***/ }),

/***/ 126:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var defineWellKnownSymbol = __webpack_require__(2695);

// `Symbol.matchAll` well-known symbol
// https://tc39.es/ecma262/#sec-symbol.matchall
defineWellKnownSymbol('matchAll');

/***/ }),

/***/ 8756:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(6924);
var lengthOfArrayLike = __webpack_require__(3534);
var toIntegerOrInfinity = __webpack_require__(3923);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;

// `%TypedArray%.prototype.at` method
// https://github.com/tc39/proposal-relative-indexing-method
exportTypedArrayMethod('at', function at(index) {
  var O = aTypedArray(this);
  var len = lengthOfArrayLike(O);
  var relativeIndex = toIntegerOrInfinity(index);
  var k = relativeIndex >= 0 ? relativeIndex : len + relativeIndex;
  return k < 0 || k >= len ? undefined : O[k];
});

/***/ }),

/***/ 2764:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(6924);
var $fill = __webpack_require__(77);
var toBigInt = __webpack_require__(3926);
var classof = __webpack_require__(2611);
var call = __webpack_require__(6277);
var uncurryThis = __webpack_require__(8712);
var fails = __webpack_require__(4631);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var slice = uncurryThis(''.slice);

// V8 ~ Chrome < 59, Safari < 14.1, FF < 55, Edge <=18
var CONVERSION_BUG = fails(function () {
  var count = 0;
  // eslint-disable-next-line es/no-typed-arrays -- safe
  new Int8Array(2).fill({
    valueOf: function () {
      return count++;
    }
  });
  return count !== 1;
});

// `%TypedArray%.prototype.fill` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.fill
exportTypedArrayMethod('fill', function fill(value /* , start, end */) {
  var length = arguments.length;
  aTypedArray(this);
  var actualValue = slice(classof(this), 0, 3) === 'Big' ? toBigInt(value) : +value;
  return call($fill, this, actualValue, length > 1 ? arguments[1] : undefined, length > 2 ? arguments[2] : undefined);
}, CONVERSION_BUG);

/***/ }),

/***/ 9654:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(6924);
var $findLastIndex = (__webpack_require__(5031).findLastIndex);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;

// `%TypedArray%.prototype.findLastIndex` method
// https://github.com/tc39/proposal-array-find-from-last
exportTypedArrayMethod('findLastIndex', function findLastIndex(predicate /* , thisArg */) {
  return $findLastIndex(aTypedArray(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
});

/***/ }),

/***/ 1271:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(6924);
var $findLast = (__webpack_require__(5031).findLast);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;

// `%TypedArray%.prototype.findLast` method
// https://github.com/tc39/proposal-array-find-from-last
exportTypedArrayMethod('findLast', function findLast(predicate /* , thisArg */) {
  return $findLast(aTypedArray(this), predicate, arguments.length > 1 ? arguments[1] : undefined);
});

/***/ }),

/***/ 6250:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var createTypedArrayConstructor = __webpack_require__(9671);

// `Float32Array` constructor
// https://tc39.es/ecma262/#sec-typedarray-objects
createTypedArrayConstructor('Float32', function (init) {
  return function Float32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ 4881:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var createTypedArrayConstructor = __webpack_require__(9671);

// `Float64Array` constructor
// https://tc39.es/ecma262/#sec-typedarray-objects
createTypedArrayConstructor('Float64', function (init) {
  return function Float64Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ 9361:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var TYPED_ARRAYS_CONSTRUCTORS_REQUIRES_WRAPPERS = __webpack_require__(4349);
var exportTypedArrayStaticMethod = (__webpack_require__(6924).exportTypedArrayStaticMethod);
var typedArrayFrom = __webpack_require__(11);

// `%TypedArray%.from` method
// https://tc39.es/ecma262/#sec-%typedarray%.from
exportTypedArrayStaticMethod('from', typedArrayFrom, TYPED_ARRAYS_CONSTRUCTORS_REQUIRES_WRAPPERS);

/***/ }),

/***/ 1715:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var createTypedArrayConstructor = __webpack_require__(9671);

// `Int16Array` constructor
// https://tc39.es/ecma262/#sec-typedarray-objects
createTypedArrayConstructor('Int16', function (init) {
  return function Int16Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ 9421:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var createTypedArrayConstructor = __webpack_require__(9671);

// `Int32Array` constructor
// https://tc39.es/ecma262/#sec-typedarray-objects
createTypedArrayConstructor('Int32', function (init) {
  return function Int32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ 5578:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var createTypedArrayConstructor = __webpack_require__(9671);

// `Int8Array` constructor
// https://tc39.es/ecma262/#sec-typedarray-objects
createTypedArrayConstructor('Int8', function (init) {
  return function Int8Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ 7216:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(6924);
var TYPED_ARRAYS_CONSTRUCTORS_REQUIRES_WRAPPERS = __webpack_require__(4349);
var aTypedArrayConstructor = ArrayBufferViewCore.aTypedArrayConstructor;
var exportTypedArrayStaticMethod = ArrayBufferViewCore.exportTypedArrayStaticMethod;

// `%TypedArray%.of` method
// https://tc39.es/ecma262/#sec-%typedarray%.of
exportTypedArrayStaticMethod('of', function of(/* ...items */
) {
  var index = 0;
  var length = arguments.length;
  var result = new (aTypedArrayConstructor(this))(length);
  while (length > index) result[index] = arguments[index++];
  return result;
}, TYPED_ARRAYS_CONSTRUCTORS_REQUIRES_WRAPPERS);

/***/ }),

/***/ 5957:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var global = __webpack_require__(6243);
var call = __webpack_require__(6277);
var ArrayBufferViewCore = __webpack_require__(6924);
var lengthOfArrayLike = __webpack_require__(3534);
var toOffset = __webpack_require__(5437);
var toIndexedObject = __webpack_require__(2397);
var fails = __webpack_require__(4631);
var RangeError = global.RangeError;
var Int8Array = global.Int8Array;
var Int8ArrayPrototype = Int8Array && Int8Array.prototype;
var $set = Int8ArrayPrototype && Int8ArrayPrototype.set;
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS = !fails(function () {
  // eslint-disable-next-line es/no-typed-arrays -- required for testing
  var array = new Uint8ClampedArray(2);
  call($set, array, {
    length: 1,
    0: 3
  }, 1);
  return array[1] !== 3;
});

// https://bugs.chromium.org/p/v8/issues/detail?id=11294 and other
var TO_OBJECT_BUG = WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS && ArrayBufferViewCore.NATIVE_ARRAY_BUFFER_VIEWS && fails(function () {
  var array = new Int8Array(2);
  array.set(1);
  array.set('2', 1);
  return array[0] !== 0 || array[1] !== 2;
});

// `%TypedArray%.prototype.set` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.set
exportTypedArrayMethod('set', function set(arrayLike /* , offset */) {
  aTypedArray(this);
  var offset = toOffset(arguments.length > 1 ? arguments[1] : undefined, 1);
  var src = toIndexedObject(arrayLike);
  if (WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS) return call($set, this, src, offset);
  var length = this.length;
  var len = lengthOfArrayLike(src);
  var index = 0;
  if (len + offset > length) throw RangeError('Wrong length');
  while (index < len) this[offset + index] = src[index++];
}, !WORKS_WITH_OBJECTS_AND_GENERIC_ON_TYPED_ARRAYS || TO_OBJECT_BUG);

/***/ }),

/***/ 9261:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var global = __webpack_require__(6243);
var uncurryThis = __webpack_require__(4060);
var fails = __webpack_require__(4631);
var aCallable = __webpack_require__(2978);
var internalSort = __webpack_require__(9760);
var ArrayBufferViewCore = __webpack_require__(6924);
var FF = __webpack_require__(6986);
var IE_OR_EDGE = __webpack_require__(2250);
var V8 = __webpack_require__(8820);
var WEBKIT = __webpack_require__(2736);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var Uint16Array = global.Uint16Array;
var nativeSort = Uint16Array && uncurryThis(Uint16Array.prototype.sort);

// WebKit
var ACCEPT_INCORRECT_ARGUMENTS = !!nativeSort && !(fails(function () {
  nativeSort(new Uint16Array(2), null);
}) && fails(function () {
  nativeSort(new Uint16Array(2), {});
}));
var STABLE_SORT = !!nativeSort && !fails(function () {
  // feature detection can be too slow, so check engines versions
  if (V8) return V8 < 74;
  if (FF) return FF < 67;
  if (IE_OR_EDGE) return true;
  if (WEBKIT) return WEBKIT < 602;
  var array = new Uint16Array(516);
  var expected = Array(516);
  var index, mod;
  for (index = 0; index < 516; index++) {
    mod = index % 4;
    array[index] = 515 - index;
    expected[index] = index - 2 * mod + 3;
  }
  nativeSort(array, function (a, b) {
    return (a / 4 | 0) - (b / 4 | 0);
  });
  for (index = 0; index < 516; index++) {
    if (array[index] !== expected[index]) return true;
  }
});
var getSortCompare = function (comparefn) {
  return function (x, y) {
    if (comparefn !== undefined) return +comparefn(x, y) || 0;
    // eslint-disable-next-line no-self-compare -- NaN check
    if (y !== y) return -1;
    // eslint-disable-next-line no-self-compare -- NaN check
    if (x !== x) return 1;
    if (x === 0 && y === 0) return 1 / x > 0 && 1 / y < 0 ? 1 : -1;
    return x > y;
  };
};

// `%TypedArray%.prototype.sort` method
// https://tc39.es/ecma262/#sec-%typedarray%.prototype.sort
exportTypedArrayMethod('sort', function sort(comparefn) {
  if (comparefn !== undefined) aCallable(comparefn);
  if (STABLE_SORT) return nativeSort(this, comparefn);
  return internalSort(aTypedArray(this), getSortCompare(comparefn));
}, !STABLE_SORT || ACCEPT_INCORRECT_ARGUMENTS);

/***/ }),

/***/ 4179:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var arrayToReversed = __webpack_require__(228);
var ArrayBufferViewCore = __webpack_require__(6924);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var getTypedArrayConstructor = ArrayBufferViewCore.getTypedArrayConstructor;

// `%TypedArray%.prototype.toReversed` method
// https://tc39.es/proposal-change-array-by-copy/#sec-%typedarray%.prototype.toReversed
exportTypedArrayMethod('toReversed', function toReversed() {
  return arrayToReversed(aTypedArray(this), getTypedArrayConstructor(this));
});

/***/ }),

/***/ 4004:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var ArrayBufferViewCore = __webpack_require__(6924);
var uncurryThis = __webpack_require__(8712);
var aCallable = __webpack_require__(2978);
var arrayFromConstructorAndList = __webpack_require__(9666);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var getTypedArrayConstructor = ArrayBufferViewCore.getTypedArrayConstructor;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var sort = uncurryThis(ArrayBufferViewCore.TypedArrayPrototype.sort);

// `%TypedArray%.prototype.toSorted` method
// https://tc39.es/proposal-change-array-by-copy/#sec-%typedarray%.prototype.toSorted
exportTypedArrayMethod('toSorted', function toSorted(compareFn) {
  if (compareFn !== undefined) aCallable(compareFn);
  var O = aTypedArray(this);
  var A = arrayFromConstructorAndList(getTypedArrayConstructor(O), O);
  return sort(A, compareFn);
});

/***/ }),

/***/ 5634:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var createTypedArrayConstructor = __webpack_require__(9671);

// `Uint16Array` constructor
// https://tc39.es/ecma262/#sec-typedarray-objects
createTypedArrayConstructor('Uint16', function (init) {
  return function Uint16Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ 9204:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var createTypedArrayConstructor = __webpack_require__(9671);

// `Uint32Array` constructor
// https://tc39.es/ecma262/#sec-typedarray-objects
createTypedArrayConstructor('Uint32', function (init) {
  return function Uint32Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ 1785:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var createTypedArrayConstructor = __webpack_require__(9671);

// `Uint8Array` constructor
// https://tc39.es/ecma262/#sec-typedarray-objects
createTypedArrayConstructor('Uint8', function (init) {
  return function Uint8Array(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
});

/***/ }),

/***/ 2766:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var createTypedArrayConstructor = __webpack_require__(9671);

// `Uint8ClampedArray` constructor
// https://tc39.es/ecma262/#sec-typedarray-objects
createTypedArrayConstructor('Uint8', function (init) {
  return function Uint8ClampedArray(data, byteOffset, length) {
    return init(this, data, byteOffset, length);
  };
}, true);

/***/ }),

/***/ 3969:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var arrayWith = __webpack_require__(864);
var ArrayBufferViewCore = __webpack_require__(6924);
var isBigIntArray = __webpack_require__(8367);
var toIntegerOrInfinity = __webpack_require__(3923);
var toBigInt = __webpack_require__(3926);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var getTypedArrayConstructor = ArrayBufferViewCore.getTypedArrayConstructor;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var PROPER_ORDER = !!function () {
  try {
    // eslint-disable-next-line no-throw-literal, es/no-typed-arrays, es/no-array-prototype-with -- required for testing
    new Int8Array(1)['with'](2, {
      valueOf: function () {
        throw 8;
      }
    });
  } catch (error) {
    // some early implementations, like WebKit, does not follow the final semantic
    // https://github.com/tc39/proposal-change-array-by-copy/pull/86
    return error === 8;
  }
}();

// `%TypedArray%.prototype.with` method
// https://tc39.es/proposal-change-array-by-copy/#sec-%typedarray%.prototype.with
exportTypedArrayMethod('with', {
  'with': function (index, value) {
    var O = aTypedArray(this);
    var relativeIndex = toIntegerOrInfinity(index);
    var actualValue = isBigIntArray(O) ? toBigInt(value) : +value;
    return arrayWith(O, getTypedArrayConstructor(O), relativeIndex, actualValue);
  }
}['with'], !PROPER_ORDER);

/***/ }),

/***/ 2214:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(1547);

/***/ }),

/***/ 3776:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(2419);

/***/ }),

/***/ 4178:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(5331);

/***/ }),

/***/ 7667:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(4142);

/***/ }),

/***/ 6588:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var fromAsync = __webpack_require__(3141);

// `Array.fromAsync` method
// https://github.com/tc39/proposal-array-from-async
$({
  target: 'Array',
  stat: true
}, {
  fromAsync: fromAsync
});

/***/ }),

/***/ 9065:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
var $ = __webpack_require__(4334);
var arrayMethodIsStrict = __webpack_require__(8782);
var addToUnscopables = __webpack_require__(8909);
var $groupToMap = __webpack_require__(9776);
var IS_PURE = __webpack_require__(1459);

// `Array.prototype.groupByToMap` method
// https://github.com/tc39/proposal-array-grouping
// https://bugs.webkit.org/show_bug.cgi?id=236541
$({
  target: 'Array',
  proto: true,
  name: 'groupToMap',
  forced: IS_PURE || !arrayMethodIsStrict('groupByToMap')
}, {
  groupByToMap: $groupToMap
});
addToUnscopables('groupByToMap');

/***/ }),

/***/ 9890:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
var $ = __webpack_require__(4334);
var $group = __webpack_require__(6093);
var arrayMethodIsStrict = __webpack_require__(8782);
var addToUnscopables = __webpack_require__(8909);

// `Array.prototype.groupBy` method
// https://github.com/tc39/proposal-array-grouping
// https://bugs.webkit.org/show_bug.cgi?id=236541
$({
  target: 'Array',
  proto: true,
  forced: !arrayMethodIsStrict('groupBy')
}, {
  groupBy: function groupBy(callbackfn /* , thisArg */) {
    var thisArg = arguments.length > 1 ? arguments[1] : undefined;
    return $group(this, callbackfn, thisArg);
  }
});
addToUnscopables('groupBy');

/***/ }),

/***/ 9561:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var addToUnscopables = __webpack_require__(8909);
var $groupToMap = __webpack_require__(9776);
var IS_PURE = __webpack_require__(1459);

// `Array.prototype.groupToMap` method
// https://github.com/tc39/proposal-array-grouping
$({
  target: 'Array',
  proto: true,
  forced: IS_PURE
}, {
  groupToMap: $groupToMap
});
addToUnscopables('groupToMap');

/***/ }),

/***/ 4159:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var $group = __webpack_require__(6093);
var addToUnscopables = __webpack_require__(8909);

// `Array.prototype.group` method
// https://github.com/tc39/proposal-array-grouping
$({
  target: 'Array',
  proto: true
}, {
  group: function group(callbackfn /* , thisArg */) {
    var thisArg = arguments.length > 1 ? arguments[1] : undefined;
    return $group(this, callbackfn, thisArg);
  }
});
addToUnscopables('group');

/***/ }),

/***/ 7903:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(5942);

/***/ }),

/***/ 4424:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(6529);

/***/ }),

/***/ 9413:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(6786);

/***/ }),

/***/ 2693:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(5710);

/***/ }),

/***/ 6587:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var anInstance = __webpack_require__(9663);
var createNonEnumerableProperty = __webpack_require__(9763);
var hasOwn = __webpack_require__(8697);
var wellKnownSymbol = __webpack_require__(2091);
var AsyncIteratorPrototype = __webpack_require__(1574);
var IS_PURE = __webpack_require__(1459);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var AsyncIteratorConstructor = function AsyncIterator() {
  anInstance(this, AsyncIteratorPrototype);
};
AsyncIteratorConstructor.prototype = AsyncIteratorPrototype;
if (!hasOwn(AsyncIteratorPrototype, TO_STRING_TAG)) {
  createNonEnumerableProperty(AsyncIteratorPrototype, TO_STRING_TAG, 'AsyncIterator');
}
if (IS_PURE || !hasOwn(AsyncIteratorPrototype, 'constructor') || AsyncIteratorPrototype.constructor === Object) {
  createNonEnumerableProperty(AsyncIteratorPrototype, 'constructor', AsyncIteratorConstructor);
}

// `AsyncIterator` constructor
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  global: true,
  constructor: true,
  forced: IS_PURE
}, {
  AsyncIterator: AsyncIteratorConstructor
});

/***/ }),

/***/ 1126:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var anObject = __webpack_require__(1791);
var getIteratorDirect = __webpack_require__(3791);
var notANaN = __webpack_require__(8349);
var toPositiveInteger = __webpack_require__(9806);
var createAsyncIteratorProxy = __webpack_require__(4403);
var createIterResultObject = __webpack_require__(9097);
var AsyncIteratorProxy = createAsyncIteratorProxy(function (Promise) {
  var state = this;
  return new Promise(function (resolve, reject) {
    var doneAndReject = function (error) {
      state.done = true;
      reject(error);
    };
    var loop = function () {
      try {
        Promise.resolve(anObject(call(state.next, state.iterator))).then(function (step) {
          try {
            if (anObject(step).done) {
              state.done = true;
              resolve(createIterResultObject(undefined, true));
            } else if (state.remaining) {
              state.remaining--;
              loop();
            } else resolve(createIterResultObject(step.value, false));
          } catch (err) {
            doneAndReject(err);
          }
        }, doneAndReject);
      } catch (error) {
        doneAndReject(error);
      }
    };
    loop();
  });
});

// `AsyncIterator.prototype.drop` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  drop: function drop(limit) {
    return new AsyncIteratorProxy(getIteratorDirect(this), {
      remaining: toPositiveInteger(notANaN(+limit))
    });
  }
});

/***/ }),

/***/ 4400:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var $every = (__webpack_require__(4903).every);

// `AsyncIterator.prototype.every` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  every: function every(predicate) {
    return $every(this, predicate);
  }
});

/***/ }),

/***/ 1357:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
var isObject = __webpack_require__(8154);
var getIteratorDirect = __webpack_require__(3791);
var createAsyncIteratorProxy = __webpack_require__(4403);
var createIterResultObject = __webpack_require__(9097);
var closeAsyncIteration = __webpack_require__(2748);
var AsyncIteratorProxy = createAsyncIteratorProxy(function (Promise) {
  var state = this;
  var iterator = state.iterator;
  var predicate = state.predicate;
  return new Promise(function (resolve, reject) {
    var doneAndReject = function (error) {
      state.done = true;
      reject(error);
    };
    var ifAbruptCloseAsyncIterator = function (error) {
      closeAsyncIteration(iterator, doneAndReject, error, doneAndReject);
    };
    var loop = function () {
      try {
        Promise.resolve(anObject(call(state.next, iterator))).then(function (step) {
          try {
            if (anObject(step).done) {
              state.done = true;
              resolve(createIterResultObject(undefined, true));
            } else {
              var value = step.value;
              try {
                var result = predicate(value, state.counter++);
                var handler = function (selected) {
                  selected ? resolve(createIterResultObject(value, false)) : loop();
                };
                if (isObject(result)) Promise.resolve(result).then(handler, ifAbruptCloseAsyncIterator);else handler(result);
              } catch (error3) {
                ifAbruptCloseAsyncIterator(error3);
              }
            }
          } catch (error2) {
            doneAndReject(error2);
          }
        }, doneAndReject);
      } catch (error) {
        doneAndReject(error);
      }
    };
    loop();
  });
});

// `AsyncIterator.prototype.filter` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  filter: function filter(predicate) {
    return new AsyncIteratorProxy(getIteratorDirect(this), {
      predicate: aCallable(predicate)
    });
  }
});

/***/ }),

/***/ 1760:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var $find = (__webpack_require__(4903).find);

// `AsyncIterator.prototype.find` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  find: function find(predicate) {
    return $find(this, predicate);
  }
});

/***/ }),

/***/ 719:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
var isObject = __webpack_require__(8154);
var getIteratorDirect = __webpack_require__(3791);
var createAsyncIteratorProxy = __webpack_require__(4403);
var createIterResultObject = __webpack_require__(9097);
var getAsyncIteratorFlattenable = __webpack_require__(8733);
var closeAsyncIteration = __webpack_require__(2748);
var AsyncIteratorProxy = createAsyncIteratorProxy(function (Promise) {
  var state = this;
  var iterator = state.iterator;
  var mapper = state.mapper;
  return new Promise(function (resolve, reject) {
    var doneAndReject = function (error) {
      state.done = true;
      reject(error);
    };
    var ifAbruptCloseAsyncIterator = function (error) {
      closeAsyncIteration(iterator, doneAndReject, error, doneAndReject);
    };
    var outerLoop = function () {
      try {
        Promise.resolve(anObject(call(state.next, iterator))).then(function (step) {
          try {
            if (anObject(step).done) {
              state.done = true;
              resolve(createIterResultObject(undefined, true));
            } else {
              var value = step.value;
              try {
                var result = mapper(value, state.counter++);
                var handler = function (mapped) {
                  try {
                    state.inner = getAsyncIteratorFlattenable(mapped);
                    innerLoop();
                  } catch (error4) {
                    ifAbruptCloseAsyncIterator(error4);
                  }
                };
                if (isObject(result)) Promise.resolve(result).then(handler, ifAbruptCloseAsyncIterator);else handler(result);
              } catch (error3) {
                ifAbruptCloseAsyncIterator(error3);
              }
            }
          } catch (error2) {
            doneAndReject(error2);
          }
        }, doneAndReject);
      } catch (error) {
        doneAndReject(error);
      }
    };
    var innerLoop = function () {
      var inner = state.inner;
      if (inner) {
        try {
          Promise.resolve(anObject(call(inner.next, inner.iterator))).then(function (result) {
            try {
              if (anObject(result).done) {
                state.inner = null;
                outerLoop();
              } else resolve(createIterResultObject(result.value, false));
            } catch (error1) {
              ifAbruptCloseAsyncIterator(error1);
            }
          }, ifAbruptCloseAsyncIterator);
        } catch (error) {
          ifAbruptCloseAsyncIterator(error);
        }
      } else outerLoop();
    };
    innerLoop();
  });
});

// `AsyncIterator.prototype.flaMap` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  flatMap: function flatMap(mapper) {
    return new AsyncIteratorProxy(getIteratorDirect(this), {
      mapper: aCallable(mapper),
      inner: null
    });
  }
});

/***/ }),

/***/ 2360:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var $forEach = (__webpack_require__(4903).forEach);

// `AsyncIterator.prototype.forEach` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  forEach: function forEach(fn) {
    return $forEach(this, fn);
  }
});

/***/ }),

/***/ 3823:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var toObject = __webpack_require__(2397);
var isPrototypeOf = __webpack_require__(1649);
var getAsyncIteratorFlattenable = __webpack_require__(8733);
var AsyncIteratorPrototype = __webpack_require__(1574);
var WrapAsyncIterator = __webpack_require__(3818);

// `AsyncIterator.from` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  stat: true
}, {
  from: function from(O) {
    var iteratorRecord = getAsyncIteratorFlattenable(typeof O == 'string' ? toObject(O) : O);
    return isPrototypeOf(AsyncIteratorPrototype, iteratorRecord.iterator) ? iteratorRecord.iterator : new WrapAsyncIterator(iteratorRecord);
  }
});

/***/ }),

/***/ 8473:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var map = __webpack_require__(9262);

// `AsyncIterator.prototype.map` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  map: map
});

/***/ }),

/***/ 7073:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
var isObject = __webpack_require__(8154);
var getBuiltIn = __webpack_require__(8463);
var getIteratorDirect = __webpack_require__(3791);
var closeAsyncIteration = __webpack_require__(2748);
var Promise = getBuiltIn('Promise');
var $TypeError = TypeError;

// `AsyncIterator.prototype.reduce` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  reduce: function reduce(reducer /* , initialValue */) {
    var record = getIteratorDirect(this);
    var iterator = record.iterator;
    var next = record.next;
    var noInitial = arguments.length < 2;
    var accumulator = noInitial ? undefined : arguments[1];
    var counter = 0;
    aCallable(reducer);
    return new Promise(function (resolve, reject) {
      var ifAbruptCloseAsyncIterator = function (error) {
        closeAsyncIteration(iterator, reject, error, reject);
      };
      var loop = function () {
        try {
          Promise.resolve(anObject(call(next, iterator))).then(function (step) {
            try {
              if (anObject(step).done) {
                noInitial ? reject($TypeError('Reduce of empty iterator with no initial value')) : resolve(accumulator);
              } else {
                var value = step.value;
                if (noInitial) {
                  noInitial = false;
                  accumulator = value;
                  loop();
                } else try {
                  var result = reducer(accumulator, value, counter);
                  var handler = function ($result) {
                    accumulator = $result;
                    loop();
                  };
                  if (isObject(result)) Promise.resolve(result).then(handler, ifAbruptCloseAsyncIterator);else handler(result);
                } catch (error3) {
                  ifAbruptCloseAsyncIterator(error3);
                }
              }
              counter++;
            } catch (error2) {
              reject(error2);
            }
          }, reject);
        } catch (error) {
          reject(error);
        }
      };
      loop();
    });
  }
});

/***/ }),

/***/ 2919:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var $some = (__webpack_require__(4903).some);

// `AsyncIterator.prototype.some` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  some: function some(predicate) {
    return $some(this, predicate);
  }
});

/***/ }),

/***/ 3920:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var anObject = __webpack_require__(1791);
var getIteratorDirect = __webpack_require__(3791);
var notANaN = __webpack_require__(8349);
var toPositiveInteger = __webpack_require__(9806);
var createAsyncIteratorProxy = __webpack_require__(4403);
var createIterResultObject = __webpack_require__(9097);
var AsyncIteratorProxy = createAsyncIteratorProxy(function (Promise) {
  var state = this;
  var iterator = state.iterator;
  var returnMethod;
  if (!state.remaining--) {
    var resultDone = createIterResultObject(undefined, true);
    state.done = true;
    returnMethod = iterator['return'];
    if (returnMethod !== undefined) {
      return Promise.resolve(call(returnMethod, iterator, undefined)).then(function () {
        return resultDone;
      });
    }
    return resultDone;
  }
  return Promise.resolve(call(state.next, iterator)).then(function (step) {
    if (anObject(step).done) {
      state.done = true;
      return createIterResultObject(undefined, true);
    }
    return createIterResultObject(step.value, false);
  }).then(null, function (error) {
    state.done = true;
    throw error;
  });
});

// `AsyncIterator.prototype.take` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  take: function take(limit) {
    return new AsyncIteratorProxy(getIteratorDirect(this), {
      remaining: toPositiveInteger(notANaN(+limit))
    });
  }
});

/***/ }),

/***/ 2266:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var $toArray = (__webpack_require__(4903).toArray);

// `AsyncIterator.prototype.toArray` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'AsyncIterator',
  proto: true,
  real: true
}, {
  toArray: function toArray() {
    return $toArray(this, undefined, []);
  }
});

/***/ }),

/***/ 101:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// https://github.com/tc39/proposal-explicit-resource-management
var $ = __webpack_require__(4334);
var DESCRIPTORS = __webpack_require__(5444);
var getBuiltIn = __webpack_require__(8463);
var aCallable = __webpack_require__(2978);
var anInstance = __webpack_require__(9663);
var defineBuiltIn = __webpack_require__(9264);
var defineBuiltIns = __webpack_require__(8575);
var defineBuiltInAccessor = __webpack_require__(8770);
var wellKnownSymbol = __webpack_require__(2091);
var InternalStateModule = __webpack_require__(3653);
var addDisposableResource = __webpack_require__(1845);
var SuppressedError = getBuiltIn('SuppressedError');
var $ReferenceError = ReferenceError;
var DISPOSE = wellKnownSymbol('dispose');
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var DISPOSABLE_STACK = 'DisposableStack';
var setInternalState = InternalStateModule.set;
var getDisposableStackInternalState = InternalStateModule.getterFor(DISPOSABLE_STACK);
var HINT = 'sync-dispose';
var DISPOSED = 'disposed';
var PENDING = 'pending';
var ALREADY_DISPOSED = DISPOSABLE_STACK + ' already disposed';
var $DisposableStack = function DisposableStack() {
  setInternalState(anInstance(this, DisposableStackPrototype), {
    type: DISPOSABLE_STACK,
    state: PENDING,
    stack: []
  });
  if (!DESCRIPTORS) this.disposed = false;
};
var DisposableStackPrototype = $DisposableStack.prototype;
defineBuiltIns(DisposableStackPrototype, {
  dispose: function dispose() {
    var internalState = getDisposableStackInternalState(this);
    if (internalState.state == DISPOSED) return;
    internalState.state = DISPOSED;
    if (!DESCRIPTORS) this.disposed = true;
    var stack = internalState.stack;
    var i = stack.length;
    var thrown = false;
    var suppressed;
    while (i) {
      var disposeMethod = stack[--i];
      stack[i] = null;
      try {
        disposeMethod();
      } catch (errorResult) {
        if (thrown) {
          suppressed = new SuppressedError(errorResult, suppressed);
        } else {
          thrown = true;
          suppressed = errorResult;
        }
      }
    }
    internalState.stack = null;
    if (thrown) throw suppressed;
  },
  use: function use(value) {
    var internalState = getDisposableStackInternalState(this);
    if (internalState.state == DISPOSED) throw $ReferenceError(ALREADY_DISPOSED);
    addDisposableResource(internalState, value, HINT);
    return value;
  },
  adopt: function adopt(value, onDispose) {
    var internalState = getDisposableStackInternalState(this);
    if (internalState.state == DISPOSED) throw $ReferenceError(ALREADY_DISPOSED);
    aCallable(onDispose);
    addDisposableResource(internalState, undefined, HINT, function () {
      onDispose(value);
    });
    return value;
  },
  defer: function defer(onDispose) {
    var internalState = getDisposableStackInternalState(this);
    if (internalState.state == DISPOSED) throw $ReferenceError(ALREADY_DISPOSED);
    aCallable(onDispose);
    addDisposableResource(internalState, undefined, HINT, onDispose);
  },
  move: function move() {
    var internalState = getDisposableStackInternalState(this);
    if (internalState.state == DISPOSED) throw $ReferenceError(ALREADY_DISPOSED);
    var newDisposableStack = new $DisposableStack();
    getDisposableStackInternalState(newDisposableStack).stack = internalState.stack;
    internalState.stack = [];
    return newDisposableStack;
  }
});
if (DESCRIPTORS) defineBuiltInAccessor(DisposableStackPrototype, 'disposed', {
  configurable: true,
  get: function disposed() {
    return getDisposableStackInternalState(this).state == DISPOSED;
  }
});
defineBuiltIn(DisposableStackPrototype, DISPOSE, DisposableStackPrototype.dispose, {
  name: 'dispose'
});
defineBuiltIn(DisposableStackPrototype, TO_STRING_TAG, DISPOSABLE_STACK, {
  nonWritable: true
});
$({
  global: true,
  constructor: true
}, {
  DisposableStack: $DisposableStack
});

/***/ }),

/***/ 2008:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(993);

/***/ }),

/***/ 984:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var global = __webpack_require__(6243);
var anInstance = __webpack_require__(9663);
var isCallable = __webpack_require__(6509);
var createNonEnumerableProperty = __webpack_require__(9763);
var fails = __webpack_require__(4631);
var hasOwn = __webpack_require__(8697);
var wellKnownSymbol = __webpack_require__(2091);
var IteratorPrototype = (__webpack_require__(7937).IteratorPrototype);
var IS_PURE = __webpack_require__(1459);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var NativeIterator = global.Iterator;

// FF56- have non-standard global helper `Iterator`
var FORCED = IS_PURE || !isCallable(NativeIterator) || NativeIterator.prototype !== IteratorPrototype
// FF44- non-standard `Iterator` passes previous tests
|| !fails(function () {
  NativeIterator({});
});
var IteratorConstructor = function Iterator() {
  anInstance(this, IteratorPrototype);
};
if (!hasOwn(IteratorPrototype, TO_STRING_TAG)) {
  createNonEnumerableProperty(IteratorPrototype, TO_STRING_TAG, 'Iterator');
}
if (FORCED || !hasOwn(IteratorPrototype, 'constructor') || IteratorPrototype.constructor === Object) {
  createNonEnumerableProperty(IteratorPrototype, 'constructor', IteratorConstructor);
}
IteratorConstructor.prototype = IteratorPrototype;

// `Iterator` constructor
// https://github.com/tc39/proposal-iterator-helpers
$({
  global: true,
  constructor: true,
  forced: FORCED
}, {
  Iterator: IteratorConstructor
});

/***/ }),

/***/ 6861:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// https://github.com/tc39/proposal-explicit-resource-management
var call = __webpack_require__(6277);
var defineBuiltIn = __webpack_require__(9264);
var getMethod = __webpack_require__(7750);
var hasOwn = __webpack_require__(8697);
var wellKnownSymbol = __webpack_require__(2091);
var IteratorPrototype = (__webpack_require__(7937).IteratorPrototype);
var DISPOSE = wellKnownSymbol('dispose');
if (!hasOwn(IteratorPrototype, DISPOSE)) {
  defineBuiltIn(IteratorPrototype, DISPOSE, function () {
    var $return = getMethod(this, 'return');
    if ($return) call($return, this);
  });
}

/***/ }),

/***/ 239:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var anObject = __webpack_require__(1791);
var getIteratorDirect = __webpack_require__(3791);
var notANaN = __webpack_require__(8349);
var toPositiveInteger = __webpack_require__(9806);
var createIteratorProxy = __webpack_require__(6766);
var IteratorProxy = createIteratorProxy(function () {
  var iterator = this.iterator;
  var next = this.next;
  var result, done;
  while (this.remaining) {
    this.remaining--;
    result = anObject(call(next, iterator));
    done = this.done = !!result.done;
    if (done) return;
  }
  result = anObject(call(next, iterator));
  done = this.done = !!result.done;
  if (!done) return result.value;
});

// `Iterator.prototype.drop` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  drop: function drop(limit) {
    return new IteratorProxy(getIteratorDirect(this), {
      remaining: toPositiveInteger(notANaN(+limit))
    });
  }
});

/***/ }),

/***/ 7831:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var iterate = __webpack_require__(5716);
var aCallable = __webpack_require__(2978);
var getIteratorDirect = __webpack_require__(3791);

// `Iterator.prototype.every` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  every: function every(predicate) {
    var record = getIteratorDirect(this);
    var counter = 0;
    aCallable(predicate);
    return !iterate(record, function (value, stop) {
      if (!predicate(value, counter++)) return stop();
    }, {
      IS_RECORD: true,
      INTERRUPTED: true
    }).stopped;
  }
});

/***/ }),

/***/ 6416:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
var getIteratorDirect = __webpack_require__(3791);
var createIteratorProxy = __webpack_require__(6766);
var callWithSafeIterationClosing = __webpack_require__(4359);
var IteratorProxy = createIteratorProxy(function () {
  var iterator = this.iterator;
  var predicate = this.predicate;
  var next = this.next;
  var result, done, value;
  while (true) {
    result = anObject(call(next, iterator));
    done = this.done = !!result.done;
    if (done) return;
    value = result.value;
    if (callWithSafeIterationClosing(iterator, predicate, [value, this.counter++], true)) return value;
  }
});

// `Iterator.prototype.filter` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  filter: function filter(predicate) {
    return new IteratorProxy(getIteratorDirect(this), {
      predicate: aCallable(predicate)
    });
  }
});

/***/ }),

/***/ 4873:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var iterate = __webpack_require__(5716);
var aCallable = __webpack_require__(2978);
var getIteratorDirect = __webpack_require__(3791);

// `Iterator.prototype.find` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  find: function find(predicate) {
    var record = getIteratorDirect(this);
    var counter = 0;
    aCallable(predicate);
    return iterate(record, function (value, stop) {
      if (predicate(value, counter++)) return stop(value);
    }, {
      IS_RECORD: true,
      INTERRUPTED: true
    }).result;
  }
});

/***/ }),

/***/ 2822:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var aCallable = __webpack_require__(2978);
var anObject = __webpack_require__(1791);
var getIteratorDirect = __webpack_require__(3791);
var getIteratorFlattenable = __webpack_require__(478);
var createIteratorProxy = __webpack_require__(6766);
var iteratorClose = __webpack_require__(1451);
var IteratorProxy = createIteratorProxy(function () {
  var iterator = this.iterator;
  var mapper = this.mapper;
  var result, inner;
  while (true) {
    if (inner = this.inner) try {
      result = anObject(call(inner.next, inner.iterator));
      if (!result.done) return result.value;
      this.inner = null;
    } catch (error) {
      iteratorClose(iterator, 'throw', error);
    }
    result = anObject(call(this.next, iterator));
    if (this.done = !!result.done) return;
    try {
      this.inner = getIteratorFlattenable(mapper(result.value, this.counter++));
    } catch (error) {
      iteratorClose(iterator, 'throw', error);
    }
  }
});

// `Iterator.prototype.flatMap` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  flatMap: function flatMap(mapper) {
    return new IteratorProxy(getIteratorDirect(this), {
      mapper: aCallable(mapper),
      inner: null
    });
  }
});

/***/ }),

/***/ 9189:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var iterate = __webpack_require__(5716);
var aCallable = __webpack_require__(2978);
var getIteratorDirect = __webpack_require__(3791);

// `Iterator.prototype.forEach` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  forEach: function forEach(fn) {
    var record = getIteratorDirect(this);
    var counter = 0;
    aCallable(fn);
    iterate(record, function (value) {
      fn(value, counter++);
    }, {
      IS_RECORD: true
    });
  }
});

/***/ }),

/***/ 6370:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var toObject = __webpack_require__(2397);
var isPrototypeOf = __webpack_require__(1649);
var IteratorPrototype = (__webpack_require__(7937).IteratorPrototype);
var createIteratorProxy = __webpack_require__(6766);
var getIteratorFlattenable = __webpack_require__(478);
var IteratorProxy = createIteratorProxy(function () {
  return call(this.next, this.iterator);
}, true);

// `Iterator.from` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  stat: true
}, {
  from: function from(O) {
    var iteratorRecord = getIteratorFlattenable(typeof O == 'string' ? toObject(O) : O);
    return isPrototypeOf(IteratorPrototype, iteratorRecord.iterator) ? iteratorRecord.iterator : new IteratorProxy(iteratorRecord);
  }
});

/***/ }),

/***/ 2390:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var map = __webpack_require__(1985);

// `Iterator.prototype.map` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  map: map
});

/***/ }),

/***/ 4320:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var iterate = __webpack_require__(5716);
var aCallable = __webpack_require__(2978);
var getIteratorDirect = __webpack_require__(3791);
var $TypeError = TypeError;

// `Iterator.prototype.reduce` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  reduce: function reduce(reducer /* , initialValue */) {
    var record = getIteratorDirect(this);
    aCallable(reducer);
    var noInitial = arguments.length < 2;
    var accumulator = noInitial ? undefined : arguments[1];
    var counter = 0;
    iterate(record, function (value) {
      if (noInitial) {
        noInitial = false;
        accumulator = value;
      } else {
        accumulator = reducer(accumulator, value, counter);
      }
      counter++;
    }, {
      IS_RECORD: true
    });
    if (noInitial) throw $TypeError('Reduce of empty iterator with no initial value');
    return accumulator;
  }
});

/***/ }),

/***/ 8774:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var iterate = __webpack_require__(5716);
var aCallable = __webpack_require__(2978);
var getIteratorDirect = __webpack_require__(3791);

// `Iterator.prototype.some` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  some: function some(predicate) {
    var record = getIteratorDirect(this);
    var counter = 0;
    aCallable(predicate);
    return iterate(record, function (value, stop) {
      if (predicate(value, counter++)) return stop();
    }, {
      IS_RECORD: true,
      INTERRUPTED: true
    }).stopped;
  }
});

/***/ }),

/***/ 3453:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var anObject = __webpack_require__(1791);
var getIteratorDirect = __webpack_require__(3791);
var notANaN = __webpack_require__(8349);
var toPositiveInteger = __webpack_require__(9806);
var createIteratorProxy = __webpack_require__(6766);
var iteratorClose = __webpack_require__(1451);
var IteratorProxy = createIteratorProxy(function () {
  var iterator = this.iterator;
  if (!this.remaining--) {
    this.done = true;
    return iteratorClose(iterator, 'normal', undefined);
  }
  var result = anObject(call(this.next, iterator));
  var done = this.done = !!result.done;
  if (!done) return result.value;
});

// `Iterator.prototype.take` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  take: function take(limit) {
    return new IteratorProxy(getIteratorDirect(this), {
      remaining: toPositiveInteger(notANaN(+limit))
    });
  }
});

/***/ }),

/***/ 3483:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var iterate = __webpack_require__(5716);
var getIteratorDirect = __webpack_require__(3791);
var push = [].push;

// `Iterator.prototype.toArray` method
// https://github.com/tc39/proposal-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  toArray: function toArray() {
    var result = [];
    iterate(getIteratorDirect(this), push, {
      that: result,
      IS_RECORD: true
    });
    return result;
  }
});

/***/ }),

/***/ 3242:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var AsyncFromSyncIterator = __webpack_require__(3186);
var WrapAsyncIterator = __webpack_require__(3818);
var getIteratorDirect = __webpack_require__(3791);

// `Iterator.prototype.toAsync` method
// https://github.com/tc39/proposal-async-iterator-helpers
$({
  target: 'Iterator',
  proto: true,
  real: true
}, {
  toAsync: function toAsync() {
    return new WrapAsyncIterator(getIteratorDirect(new AsyncFromSyncIterator(getIteratorDirect(this))));
  }
});

/***/ }),

/***/ 8216:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(5507);

/***/ }),

/***/ 2186:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(3311);

/***/ }),

/***/ 6079:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(2006);

/***/ }),

/***/ 3927:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var difference = __webpack_require__(4392);
var setMethodAcceptSetLike = __webpack_require__(5404);

// `Set.prototype.difference` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('difference')
}, {
  difference: difference
});

/***/ }),

/***/ 641:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var intersection = __webpack_require__(1398);
var setMethodAcceptSetLike = __webpack_require__(5404);

// `Set.prototype.intersection` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('intersection')
}, {
  intersection: intersection
});

/***/ }),

/***/ 5116:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var isDisjointFrom = __webpack_require__(2649);
var setMethodAcceptSetLike = __webpack_require__(5404);

// `Set.prototype.isDisjointFrom` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('isDisjointFrom')
}, {
  isDisjointFrom: isDisjointFrom
});

/***/ }),

/***/ 8897:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var isSubsetOf = __webpack_require__(454);
var setMethodAcceptSetLike = __webpack_require__(5404);

// `Set.prototype.isSubsetOf` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('isSubsetOf')
}, {
  isSubsetOf: isSubsetOf
});

/***/ }),

/***/ 7562:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var isSupersetOf = __webpack_require__(8599);
var setMethodAcceptSetLike = __webpack_require__(5404);

// `Set.prototype.isSupersetOf` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('isSupersetOf')
}, {
  isSupersetOf: isSupersetOf
});

/***/ }),

/***/ 3089:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var symmetricDifference = __webpack_require__(826);
var setMethodAcceptSetLike = __webpack_require__(5404);

// `Set.prototype.symmetricDifference` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('symmetricDifference')
}, {
  symmetricDifference: symmetricDifference
});

/***/ }),

/***/ 5725:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var $ = __webpack_require__(4334);
var union = __webpack_require__(9828);
var setMethodAcceptSetLike = __webpack_require__(5404);

// `Set.prototype.union` method
// https://github.com/tc39/proposal-set-methods
$({
  target: 'Set',
  proto: true,
  real: true,
  forced: !setMethodAcceptSetLike('union')
}, {
  union: union
});

/***/ }),

/***/ 8166:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var uncurryThis = __webpack_require__(8712);
var requireObjectCoercible = __webpack_require__(3662);
var toString = __webpack_require__(5479);
var charCodeAt = uncurryThis(''.charCodeAt);

// `String.prototype.isWellFormed` method
// https://github.com/tc39/proposal-is-usv-string
$({
  target: 'String',
  proto: true
}, {
  isWellFormed: function isWellFormed() {
    var S = toString(requireObjectCoercible(this));
    var length = S.length;
    for (var i = 0; i < length; i++) {
      var charCode = charCodeAt(S, i);
      // single UTF-16 code unit
      if ((charCode & 0xF800) != 0xD800) continue;
      // unpaired surrogate
      if (charCode >= 0xDC00 || ++i >= length || (charCodeAt(S, i) & 0xFC00) != 0xDC00) return false;
    }
    return true;
  }
});

/***/ }),

/***/ 6992:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(8839);

/***/ }),

/***/ 2977:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(6658);

/***/ }),

/***/ 2099:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var call = __webpack_require__(6277);
var uncurryThis = __webpack_require__(8712);
var requireObjectCoercible = __webpack_require__(3662);
var toString = __webpack_require__(5479);
var fails = __webpack_require__(4631);
var $Array = Array;
var charAt = uncurryThis(''.charAt);
var charCodeAt = uncurryThis(''.charCodeAt);
var join = uncurryThis([].join);
var $toWellFormed = ''.toWellFormed;
var REPLACEMENT_CHARACTER = '\uFFFD';

// Safari bug
var TO_STRING_CONVERSION_BUG = $toWellFormed && fails(function () {
  return call($toWellFormed, 1) !== '1';
});

// `String.prototype.toWellFormed` method
// https://github.com/tc39/proposal-is-usv-string
$({
  target: 'String',
  proto: true,
  forced: TO_STRING_CONVERSION_BUG
}, {
  toWellFormed: function toWellFormed() {
    var S = toString(requireObjectCoercible(this));
    if (TO_STRING_CONVERSION_BUG) return call($toWellFormed, S);
    var length = S.length;
    var result = $Array(length);
    for (var i = 0; i < length; i++) {
      var charCode = charCodeAt(S, i);
      // single UTF-16 code unit
      if ((charCode & 0xF800) != 0xD800) result[i] = charAt(S, i);
      // unpaired surrogate
      else if (charCode >= 0xDC00 || i + 1 >= length || (charCodeAt(S, i + 1) & 0xFC00) != 0xDC00) result[i] = REPLACEMENT_CHARACTER;
      // surrogate pair
      else {
        result[i] = charAt(S, i);
        result[++i] = charAt(S, i);
      }
    }
    return join(result, '');
  }
});

/***/ }),

/***/ 8703:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


var $ = __webpack_require__(4334);
var isPrototypeOf = __webpack_require__(1649);
var getPrototypeOf = __webpack_require__(5355);
var setPrototypeOf = __webpack_require__(4767);
var copyConstructorProperties = __webpack_require__(8004);
var create = __webpack_require__(8336);
var createNonEnumerableProperty = __webpack_require__(9763);
var createPropertyDescriptor = __webpack_require__(6012);
var installErrorStack = __webpack_require__(5491);
var normalizeStringArgument = __webpack_require__(6851);
var wellKnownSymbol = __webpack_require__(2091);
var TO_STRING_TAG = wellKnownSymbol('toStringTag');
var $Error = Error;
var $SuppressedError = function SuppressedError(error, suppressed, message) {
  var isInstance = isPrototypeOf(SuppressedErrorPrototype, this);
  var that;
  if (setPrototypeOf) {
    that = setPrototypeOf($Error(), isInstance ? getPrototypeOf(this) : SuppressedErrorPrototype);
  } else {
    that = isInstance ? this : create(SuppressedErrorPrototype);
    createNonEnumerableProperty(that, TO_STRING_TAG, 'Error');
  }
  if (message !== undefined) createNonEnumerableProperty(that, 'message', normalizeStringArgument(message));
  installErrorStack(that, $SuppressedError, that.stack, 1);
  createNonEnumerableProperty(that, 'error', error);
  createNonEnumerableProperty(that, 'suppressed', suppressed);
  return that;
};
if (setPrototypeOf) setPrototypeOf($SuppressedError, $Error);else copyConstructorProperties($SuppressedError, $Error, {
  name: true
});
var SuppressedErrorPrototype = $SuppressedError.prototype = create($Error.prototype, {
  constructor: createPropertyDescriptor(1, $SuppressedError),
  message: createPropertyDescriptor(1, ''),
  name: createPropertyDescriptor(1, 'SuppressedError')
});

// `SuppressedError` constructor
// https://github.com/tc39/proposal-explicit-resource-management
$({
  global: true,
  constructor: true,
  arity: 3
}, {
  SuppressedError: $SuppressedError
});

/***/ }),

/***/ 1331:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var defineWellKnownSymbol = __webpack_require__(2695);

// `Symbol.dispose` well-known symbol
// https://github.com/tc39/proposal-explicit-resource-management
defineWellKnownSymbol('dispose');

/***/ }),

/***/ 1703:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(8756);

/***/ }),

/***/ 7799:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(9654);

/***/ }),

/***/ 4866:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(1271);

/***/ }),

/***/ 2906:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(4179);

/***/ }),

/***/ 6125:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(4004);

/***/ }),

/***/ 7038:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


// TODO: Remove from `core-js@4`
var ArrayBufferViewCore = __webpack_require__(6924);
var lengthOfArrayLike = __webpack_require__(3534);
var isBigIntArray = __webpack_require__(8367);
var toAbsoluteIndex = __webpack_require__(1634);
var toBigInt = __webpack_require__(3926);
var toIntegerOrInfinity = __webpack_require__(3923);
var fails = __webpack_require__(4631);
var aTypedArray = ArrayBufferViewCore.aTypedArray;
var getTypedArrayConstructor = ArrayBufferViewCore.getTypedArrayConstructor;
var exportTypedArrayMethod = ArrayBufferViewCore.exportTypedArrayMethod;
var max = Math.max;
var min = Math.min;

// some early implementations, like WebKit, does not follow the final semantic
var PROPER_ORDER = !fails(function () {
  // eslint-disable-next-line es/no-typed-arrays -- required for testing
  var array = new Int8Array([1]);
  var spliced = array.toSpliced(1, 0, {
    valueOf: function () {
      array[0] = 2;
      return 3;
    }
  });
  return spliced[0] !== 2 || spliced[1] !== 3;
});

// `%TypedArray%.prototype.toSpliced` method
// https://tc39.es/proposal-change-array-by-copy/#sec-%typedarray%.prototype.toSpliced
exportTypedArrayMethod('toSpliced', function toSpliced(start, deleteCount /* , ...items */) {
  var O = aTypedArray(this);
  var C = getTypedArrayConstructor(O);
  var len = lengthOfArrayLike(O);
  var actualStart = toAbsoluteIndex(start, len);
  var argumentsLength = arguments.length;
  var k = 0;
  var insertCount, actualDeleteCount, thisIsBigIntArray, convertedItems, value, newLen, A;
  if (argumentsLength === 0) {
    insertCount = actualDeleteCount = 0;
  } else if (argumentsLength === 1) {
    insertCount = 0;
    actualDeleteCount = len - actualStart;
  } else {
    actualDeleteCount = min(max(toIntegerOrInfinity(deleteCount), 0), len - actualStart);
    insertCount = argumentsLength - 2;
    if (insertCount) {
      convertedItems = new C(insertCount);
      thisIsBigIntArray = isBigIntArray(convertedItems);
      for (var i = 2; i < argumentsLength; i++) {
        value = arguments[i];
        // FF30- typed arrays doesn't properly convert objects to typed array values
        convertedItems[i - 2] = thisIsBigIntArray ? toBigInt(value) : +value;
      }
    }
  }
  newLen = len + insertCount - actualDeleteCount;
  A = new C(newLen);
  for (; k < actualStart; k++) A[k] = O[k];
  for (; k < actualStart + insertCount; k++) A[k] = convertedItems[k - actualStart];
  for (; k < newLen; k++) A[k] = O[k + actualDeleteCount - insertCount];
  return A;
}, !PROPER_ORDER);

/***/ }),

/***/ 9786:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

// TODO: Remove from `core-js@4`
__webpack_require__(3969);

/***/ }),

/***/ 8217:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

var context = __webpack_require__(4094);

// 将 @babel/runtime 下的方法都写入到 BabelRuntimeHelpers
context.keys().forEach(name => {
  BabelRuntimeHelpers[name.substr(2)] = context(name);
});
var wxRunOnDebug = fn => fn();
wxRunOnDebug(() => {
  BabelRuntimeHelpers = new Proxy(BabelRuntimeHelpers, {
    get(obj, prop) {
      if (!obj[prop]) {
        console.error("\u5C1D\u8BD5\u8BFB\u53D6\u672A\u5B9A\u4E49 BabelRuntimeHelpers.".concat(prop, "\uFF0C\u8BF7\u786E\u4FDD weapp-polyfill \u4E3A\u6700\u65B0\u3002"));
        console.error('若确认最新版存在问题，则请尝试在 weapp-polyfill 下执行 node getBabelHelpers');
      }
      return obj[prop];
    }
  });
});

/***/ }),

/***/ 7858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5951);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_match_all_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(126);
/* harmony import */ var core_js_modules_es_symbol_match_all_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_match_all_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8768);
/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_aggregate_error_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1547);
/* harmony import */ var core_js_modules_es_aggregate_error_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_aggregate_error_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_aggregate_error_cause_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4622);
/* harmony import */ var core_js_modules_es_aggregate_error_cause_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_aggregate_error_cause_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_array_at_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2419);
/* harmony import */ var core_js_modules_es_array_at_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_at_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_last_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4142);
/* harmony import */ var core_js_modules_es_array_find_last_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_last_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5331);
/* harmony import */ var core_js_modules_es_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1098);
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es_array_reverse_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6034);
/* harmony import */ var core_js_modules_es_array_reverse_js__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_reverse_js__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_es_array_unscopables_flat_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1778);
/* harmony import */ var core_js_modules_es_array_unscopables_flat_js__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_unscopables_flat_js__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es_array_unscopables_flat_map_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9973);
/* harmony import */ var core_js_modules_es_array_unscopables_flat_map_js__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_unscopables_flat_map_js__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var core_js_modules_es_array_unshift_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3537);
/* harmony import */ var core_js_modules_es_array_unshift_js__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_unshift_js__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3033);
/* harmony import */ var core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_buffer_slice_js__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var core_js_modules_es_global_this_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(993);
/* harmony import */ var core_js_modules_es_global_this_js__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_global_this_js__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8302);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var core_js_modules_es_object_from_entries_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7142);
/* harmony import */ var core_js_modules_es_object_from_entries_js__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_from_entries_js__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var core_js_modules_es_object_has_own_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5507);
/* harmony import */ var core_js_modules_es_object_has_own_js__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_has_own_js__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2362);
/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(3311);
/* harmony import */ var core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var core_js_modules_es_promise_any_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(2006);
/* harmony import */ var core_js_modules_es_promise_any_js__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_any_js__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(9943);
/* harmony import */ var core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_finally_js__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var core_js_modules_es_reflect_to_string_tag_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(6552);
/* harmony import */ var core_js_modules_es_reflect_to_string_tag_js__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_reflect_to_string_tag_js__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var core_js_modules_es_regexp_flags_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(4559);
/* harmony import */ var core_js_modules_es_regexp_flags_js__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_flags_js__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var core_js_modules_es_string_at_alternative_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(8453);
/* harmony import */ var core_js_modules_es_string_at_alternative_js__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_at_alternative_js__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var core_js_modules_es_string_match_all_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(8839);
/* harmony import */ var core_js_modules_es_string_match_all_js__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_match_all_js__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(1432);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var core_js_modules_es_string_replace_all_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(6658);
/* harmony import */ var core_js_modules_es_string_replace_all_js__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_all_js__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(5826);
/* harmony import */ var core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_js__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var core_js_modules_es_string_trim_end_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(1402);
/* harmony import */ var core_js_modules_es_string_trim_end_js__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_trim_end_js__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var core_js_modules_es_typed_array_float32_array_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(6250);
/* harmony import */ var core_js_modules_es_typed_array_float32_array_js__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_float32_array_js__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var core_js_modules_es_typed_array_float64_array_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(4881);
/* harmony import */ var core_js_modules_es_typed_array_float64_array_js__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_float64_array_js__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var core_js_modules_es_typed_array_int8_array_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(5578);
/* harmony import */ var core_js_modules_es_typed_array_int8_array_js__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_int8_array_js__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var core_js_modules_es_typed_array_int16_array_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(1715);
/* harmony import */ var core_js_modules_es_typed_array_int16_array_js__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_int16_array_js__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var core_js_modules_es_typed_array_int32_array_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(9421);
/* harmony import */ var core_js_modules_es_typed_array_int32_array_js__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_int32_array_js__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(1785);
/* harmony import */ var core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_uint8_array_js__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var core_js_modules_es_typed_array_uint8_clamped_array_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(2766);
/* harmony import */ var core_js_modules_es_typed_array_uint8_clamped_array_js__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_uint8_clamped_array_js__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var core_js_modules_es_typed_array_uint16_array_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(5634);
/* harmony import */ var core_js_modules_es_typed_array_uint16_array_js__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_uint16_array_js__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var core_js_modules_es_typed_array_uint32_array_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(9204);
/* harmony import */ var core_js_modules_es_typed_array_uint32_array_js__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_uint32_array_js__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(8756);
/* harmony import */ var core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_at_js__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(2764);
/* harmony import */ var core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_fill_js__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(1271);
/* harmony import */ var core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(9654);
/* harmony import */ var core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var core_js_modules_es_typed_array_from_js__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(9361);
/* harmony import */ var core_js_modules_es_typed_array_from_js__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_from_js__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var core_js_modules_es_typed_array_of_js__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(7216);
/* harmony import */ var core_js_modules_es_typed_array_of_js__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_of_js__WEBPACK_IMPORTED_MODULE_44__);
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(5957);
/* harmony import */ var core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_45___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_set_js__WEBPACK_IMPORTED_MODULE_45__);
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(9261);
/* harmony import */ var core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_46___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_typed_array_sort_js__WEBPACK_IMPORTED_MODULE_46__);
/* harmony import */ var core_js_modules_esnext_aggregate_error_js__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(2214);
/* harmony import */ var core_js_modules_esnext_aggregate_error_js__WEBPACK_IMPORTED_MODULE_47___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_aggregate_error_js__WEBPACK_IMPORTED_MODULE_47__);
/* harmony import */ var core_js_modules_esnext_array_at_js__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(3776);
/* harmony import */ var core_js_modules_esnext_array_at_js__WEBPACK_IMPORTED_MODULE_48___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_at_js__WEBPACK_IMPORTED_MODULE_48__);
/* harmony import */ var core_js_modules_esnext_array_find_last_js__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(7667);
/* harmony import */ var core_js_modules_esnext_array_find_last_js__WEBPACK_IMPORTED_MODULE_49___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_find_last_js__WEBPACK_IMPORTED_MODULE_49__);
/* harmony import */ var core_js_modules_esnext_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(4178);
/* harmony import */ var core_js_modules_esnext_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_50___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_50__);
/* harmony import */ var core_js_modules_esnext_global_this_js__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(2008);
/* harmony import */ var core_js_modules_esnext_global_this_js__WEBPACK_IMPORTED_MODULE_51___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_global_this_js__WEBPACK_IMPORTED_MODULE_51__);
/* harmony import */ var core_js_modules_esnext_object_has_own_js__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(8216);
/* harmony import */ var core_js_modules_esnext_object_has_own_js__WEBPACK_IMPORTED_MODULE_52___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_object_has_own_js__WEBPACK_IMPORTED_MODULE_52__);
/* harmony import */ var core_js_modules_esnext_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(2186);
/* harmony import */ var core_js_modules_esnext_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_53___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_promise_all_settled_js__WEBPACK_IMPORTED_MODULE_53__);
/* harmony import */ var core_js_modules_esnext_promise_any_js__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(6079);
/* harmony import */ var core_js_modules_esnext_promise_any_js__WEBPACK_IMPORTED_MODULE_54___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_promise_any_js__WEBPACK_IMPORTED_MODULE_54__);
/* harmony import */ var core_js_modules_esnext_string_match_all_js__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(6992);
/* harmony import */ var core_js_modules_esnext_string_match_all_js__WEBPACK_IMPORTED_MODULE_55___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_string_match_all_js__WEBPACK_IMPORTED_MODULE_55__);
/* harmony import */ var core_js_modules_esnext_string_replace_all_js__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(2977);
/* harmony import */ var core_js_modules_esnext_string_replace_all_js__WEBPACK_IMPORTED_MODULE_56___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_string_replace_all_js__WEBPACK_IMPORTED_MODULE_56__);
/* harmony import */ var core_js_modules_esnext_typed_array_at_js__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(1703);
/* harmony import */ var core_js_modules_esnext_typed_array_at_js__WEBPACK_IMPORTED_MODULE_57___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_at_js__WEBPACK_IMPORTED_MODULE_57__);
/* harmony import */ var core_js_modules_esnext_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(4866);
/* harmony import */ var core_js_modules_esnext_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_58___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_find_last_js__WEBPACK_IMPORTED_MODULE_58__);
/* harmony import */ var core_js_modules_esnext_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(7799);
/* harmony import */ var core_js_modules_esnext_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_59___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_find_last_index_js__WEBPACK_IMPORTED_MODULE_59__);
/* harmony import */ var core_js_modules_esnext_suppressed_error_constructor_js__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(8703);
/* harmony import */ var core_js_modules_esnext_suppressed_error_constructor_js__WEBPACK_IMPORTED_MODULE_60___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_suppressed_error_constructor_js__WEBPACK_IMPORTED_MODULE_60__);
/* harmony import */ var core_js_modules_esnext_array_from_async_js__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(6588);
/* harmony import */ var core_js_modules_esnext_array_from_async_js__WEBPACK_IMPORTED_MODULE_61___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_from_async_js__WEBPACK_IMPORTED_MODULE_61__);
/* harmony import */ var core_js_modules_esnext_array_group_js__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(4159);
/* harmony import */ var core_js_modules_esnext_array_group_js__WEBPACK_IMPORTED_MODULE_62___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_group_js__WEBPACK_IMPORTED_MODULE_62__);
/* harmony import */ var core_js_modules_esnext_array_group_by_js__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(9890);
/* harmony import */ var core_js_modules_esnext_array_group_by_js__WEBPACK_IMPORTED_MODULE_63___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_group_by_js__WEBPACK_IMPORTED_MODULE_63__);
/* harmony import */ var core_js_modules_esnext_array_group_by_to_map_js__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(9065);
/* harmony import */ var core_js_modules_esnext_array_group_by_to_map_js__WEBPACK_IMPORTED_MODULE_64___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_group_by_to_map_js__WEBPACK_IMPORTED_MODULE_64__);
/* harmony import */ var core_js_modules_esnext_array_group_to_map_js__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(9561);
/* harmony import */ var core_js_modules_esnext_array_group_to_map_js__WEBPACK_IMPORTED_MODULE_65___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_group_to_map_js__WEBPACK_IMPORTED_MODULE_65__);
/* harmony import */ var core_js_modules_esnext_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_66__ = __webpack_require__(7903);
/* harmony import */ var core_js_modules_esnext_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_66___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_66__);
/* harmony import */ var core_js_modules_esnext_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_67__ = __webpack_require__(4424);
/* harmony import */ var core_js_modules_esnext_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_67___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_67__);
/* harmony import */ var core_js_modules_esnext_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_68__ = __webpack_require__(9413);
/* harmony import */ var core_js_modules_esnext_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_68___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_68__);
/* harmony import */ var core_js_modules_esnext_array_with_js__WEBPACK_IMPORTED_MODULE_69__ = __webpack_require__(2693);
/* harmony import */ var core_js_modules_esnext_array_with_js__WEBPACK_IMPORTED_MODULE_69___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_array_with_js__WEBPACK_IMPORTED_MODULE_69__);
/* harmony import */ var core_js_modules_esnext_async_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_70__ = __webpack_require__(6587);
/* harmony import */ var core_js_modules_esnext_async_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_70___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_70__);
/* harmony import */ var core_js_modules_esnext_async_iterator_drop_js__WEBPACK_IMPORTED_MODULE_71__ = __webpack_require__(1126);
/* harmony import */ var core_js_modules_esnext_async_iterator_drop_js__WEBPACK_IMPORTED_MODULE_71___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_drop_js__WEBPACK_IMPORTED_MODULE_71__);
/* harmony import */ var core_js_modules_esnext_async_iterator_every_js__WEBPACK_IMPORTED_MODULE_72__ = __webpack_require__(4400);
/* harmony import */ var core_js_modules_esnext_async_iterator_every_js__WEBPACK_IMPORTED_MODULE_72___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_every_js__WEBPACK_IMPORTED_MODULE_72__);
/* harmony import */ var core_js_modules_esnext_async_iterator_filter_js__WEBPACK_IMPORTED_MODULE_73__ = __webpack_require__(1357);
/* harmony import */ var core_js_modules_esnext_async_iterator_filter_js__WEBPACK_IMPORTED_MODULE_73___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_filter_js__WEBPACK_IMPORTED_MODULE_73__);
/* harmony import */ var core_js_modules_esnext_async_iterator_find_js__WEBPACK_IMPORTED_MODULE_74__ = __webpack_require__(1760);
/* harmony import */ var core_js_modules_esnext_async_iterator_find_js__WEBPACK_IMPORTED_MODULE_74___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_find_js__WEBPACK_IMPORTED_MODULE_74__);
/* harmony import */ var core_js_modules_esnext_async_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_75__ = __webpack_require__(719);
/* harmony import */ var core_js_modules_esnext_async_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_75___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_75__);
/* harmony import */ var core_js_modules_esnext_async_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_76__ = __webpack_require__(2360);
/* harmony import */ var core_js_modules_esnext_async_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_76___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_76__);
/* harmony import */ var core_js_modules_esnext_async_iterator_from_js__WEBPACK_IMPORTED_MODULE_77__ = __webpack_require__(3823);
/* harmony import */ var core_js_modules_esnext_async_iterator_from_js__WEBPACK_IMPORTED_MODULE_77___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_from_js__WEBPACK_IMPORTED_MODULE_77__);
/* harmony import */ var core_js_modules_esnext_async_iterator_map_js__WEBPACK_IMPORTED_MODULE_78__ = __webpack_require__(8473);
/* harmony import */ var core_js_modules_esnext_async_iterator_map_js__WEBPACK_IMPORTED_MODULE_78___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_map_js__WEBPACK_IMPORTED_MODULE_78__);
/* harmony import */ var core_js_modules_esnext_async_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_79__ = __webpack_require__(7073);
/* harmony import */ var core_js_modules_esnext_async_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_79___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_79__);
/* harmony import */ var core_js_modules_esnext_async_iterator_some_js__WEBPACK_IMPORTED_MODULE_80__ = __webpack_require__(2919);
/* harmony import */ var core_js_modules_esnext_async_iterator_some_js__WEBPACK_IMPORTED_MODULE_80___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_some_js__WEBPACK_IMPORTED_MODULE_80__);
/* harmony import */ var core_js_modules_esnext_async_iterator_take_js__WEBPACK_IMPORTED_MODULE_81__ = __webpack_require__(3920);
/* harmony import */ var core_js_modules_esnext_async_iterator_take_js__WEBPACK_IMPORTED_MODULE_81___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_take_js__WEBPACK_IMPORTED_MODULE_81__);
/* harmony import */ var core_js_modules_esnext_async_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_82__ = __webpack_require__(2266);
/* harmony import */ var core_js_modules_esnext_async_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_82___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_async_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_82__);
/* harmony import */ var core_js_modules_esnext_disposable_stack_constructor_js__WEBPACK_IMPORTED_MODULE_83__ = __webpack_require__(101);
/* harmony import */ var core_js_modules_esnext_disposable_stack_constructor_js__WEBPACK_IMPORTED_MODULE_83___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_disposable_stack_constructor_js__WEBPACK_IMPORTED_MODULE_83__);
/* harmony import */ var core_js_modules_esnext_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_84__ = __webpack_require__(984);
/* harmony import */ var core_js_modules_esnext_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_84___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_constructor_js__WEBPACK_IMPORTED_MODULE_84__);
/* harmony import */ var core_js_modules_esnext_iterator_dispose_js__WEBPACK_IMPORTED_MODULE_85__ = __webpack_require__(6861);
/* harmony import */ var core_js_modules_esnext_iterator_dispose_js__WEBPACK_IMPORTED_MODULE_85___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_dispose_js__WEBPACK_IMPORTED_MODULE_85__);
/* harmony import */ var core_js_modules_esnext_iterator_drop_js__WEBPACK_IMPORTED_MODULE_86__ = __webpack_require__(239);
/* harmony import */ var core_js_modules_esnext_iterator_drop_js__WEBPACK_IMPORTED_MODULE_86___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_drop_js__WEBPACK_IMPORTED_MODULE_86__);
/* harmony import */ var core_js_modules_esnext_iterator_every_js__WEBPACK_IMPORTED_MODULE_87__ = __webpack_require__(7831);
/* harmony import */ var core_js_modules_esnext_iterator_every_js__WEBPACK_IMPORTED_MODULE_87___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_every_js__WEBPACK_IMPORTED_MODULE_87__);
/* harmony import */ var core_js_modules_esnext_iterator_filter_js__WEBPACK_IMPORTED_MODULE_88__ = __webpack_require__(6416);
/* harmony import */ var core_js_modules_esnext_iterator_filter_js__WEBPACK_IMPORTED_MODULE_88___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_filter_js__WEBPACK_IMPORTED_MODULE_88__);
/* harmony import */ var core_js_modules_esnext_iterator_find_js__WEBPACK_IMPORTED_MODULE_89__ = __webpack_require__(4873);
/* harmony import */ var core_js_modules_esnext_iterator_find_js__WEBPACK_IMPORTED_MODULE_89___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_find_js__WEBPACK_IMPORTED_MODULE_89__);
/* harmony import */ var core_js_modules_esnext_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_90__ = __webpack_require__(2822);
/* harmony import */ var core_js_modules_esnext_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_90___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_flat_map_js__WEBPACK_IMPORTED_MODULE_90__);
/* harmony import */ var core_js_modules_esnext_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_91__ = __webpack_require__(9189);
/* harmony import */ var core_js_modules_esnext_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_91___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_for_each_js__WEBPACK_IMPORTED_MODULE_91__);
/* harmony import */ var core_js_modules_esnext_iterator_from_js__WEBPACK_IMPORTED_MODULE_92__ = __webpack_require__(6370);
/* harmony import */ var core_js_modules_esnext_iterator_from_js__WEBPACK_IMPORTED_MODULE_92___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_from_js__WEBPACK_IMPORTED_MODULE_92__);
/* harmony import */ var core_js_modules_esnext_iterator_map_js__WEBPACK_IMPORTED_MODULE_93__ = __webpack_require__(2390);
/* harmony import */ var core_js_modules_esnext_iterator_map_js__WEBPACK_IMPORTED_MODULE_93___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_map_js__WEBPACK_IMPORTED_MODULE_93__);
/* harmony import */ var core_js_modules_esnext_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_94__ = __webpack_require__(4320);
/* harmony import */ var core_js_modules_esnext_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_94___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_reduce_js__WEBPACK_IMPORTED_MODULE_94__);
/* harmony import */ var core_js_modules_esnext_iterator_some_js__WEBPACK_IMPORTED_MODULE_95__ = __webpack_require__(8774);
/* harmony import */ var core_js_modules_esnext_iterator_some_js__WEBPACK_IMPORTED_MODULE_95___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_some_js__WEBPACK_IMPORTED_MODULE_95__);
/* harmony import */ var core_js_modules_esnext_iterator_take_js__WEBPACK_IMPORTED_MODULE_96__ = __webpack_require__(3453);
/* harmony import */ var core_js_modules_esnext_iterator_take_js__WEBPACK_IMPORTED_MODULE_96___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_take_js__WEBPACK_IMPORTED_MODULE_96__);
/* harmony import */ var core_js_modules_esnext_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_97__ = __webpack_require__(3483);
/* harmony import */ var core_js_modules_esnext_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_97___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_to_array_js__WEBPACK_IMPORTED_MODULE_97__);
/* harmony import */ var core_js_modules_esnext_iterator_to_async_js__WEBPACK_IMPORTED_MODULE_98__ = __webpack_require__(3242);
/* harmony import */ var core_js_modules_esnext_iterator_to_async_js__WEBPACK_IMPORTED_MODULE_98___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_iterator_to_async_js__WEBPACK_IMPORTED_MODULE_98__);
/* harmony import */ var core_js_modules_esnext_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_99__ = __webpack_require__(3927);
/* harmony import */ var core_js_modules_esnext_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_99___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_difference_v2_js__WEBPACK_IMPORTED_MODULE_99__);
/* harmony import */ var core_js_modules_esnext_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_100__ = __webpack_require__(641);
/* harmony import */ var core_js_modules_esnext_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_100___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_intersection_v2_js__WEBPACK_IMPORTED_MODULE_100__);
/* harmony import */ var core_js_modules_esnext_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_101__ = __webpack_require__(5116);
/* harmony import */ var core_js_modules_esnext_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_101___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_is_disjoint_from_v2_js__WEBPACK_IMPORTED_MODULE_101__);
/* harmony import */ var core_js_modules_esnext_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_102__ = __webpack_require__(8897);
/* harmony import */ var core_js_modules_esnext_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_102___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_is_subset_of_v2_js__WEBPACK_IMPORTED_MODULE_102__);
/* harmony import */ var core_js_modules_esnext_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_103__ = __webpack_require__(7562);
/* harmony import */ var core_js_modules_esnext_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_103___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_is_superset_of_v2_js__WEBPACK_IMPORTED_MODULE_103__);
/* harmony import */ var core_js_modules_esnext_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_104__ = __webpack_require__(3089);
/* harmony import */ var core_js_modules_esnext_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_104___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_symmetric_difference_v2_js__WEBPACK_IMPORTED_MODULE_104__);
/* harmony import */ var core_js_modules_esnext_set_union_v2_js__WEBPACK_IMPORTED_MODULE_105__ = __webpack_require__(5725);
/* harmony import */ var core_js_modules_esnext_set_union_v2_js__WEBPACK_IMPORTED_MODULE_105___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_set_union_v2_js__WEBPACK_IMPORTED_MODULE_105__);
/* harmony import */ var core_js_modules_esnext_string_is_well_formed_js__WEBPACK_IMPORTED_MODULE_106__ = __webpack_require__(8166);
/* harmony import */ var core_js_modules_esnext_string_is_well_formed_js__WEBPACK_IMPORTED_MODULE_106___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_string_is_well_formed_js__WEBPACK_IMPORTED_MODULE_106__);
/* harmony import */ var core_js_modules_esnext_string_to_well_formed_js__WEBPACK_IMPORTED_MODULE_107__ = __webpack_require__(2099);
/* harmony import */ var core_js_modules_esnext_string_to_well_formed_js__WEBPACK_IMPORTED_MODULE_107___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_string_to_well_formed_js__WEBPACK_IMPORTED_MODULE_107__);
/* harmony import */ var core_js_modules_esnext_symbol_dispose_js__WEBPACK_IMPORTED_MODULE_108__ = __webpack_require__(1331);
/* harmony import */ var core_js_modules_esnext_symbol_dispose_js__WEBPACK_IMPORTED_MODULE_108___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_symbol_dispose_js__WEBPACK_IMPORTED_MODULE_108__);
/* harmony import */ var core_js_modules_esnext_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_109__ = __webpack_require__(2906);
/* harmony import */ var core_js_modules_esnext_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_109___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_to_reversed_js__WEBPACK_IMPORTED_MODULE_109__);
/* harmony import */ var core_js_modules_esnext_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_110__ = __webpack_require__(6125);
/* harmony import */ var core_js_modules_esnext_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_110___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_to_sorted_js__WEBPACK_IMPORTED_MODULE_110__);
/* harmony import */ var core_js_modules_esnext_typed_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_111__ = __webpack_require__(7038);
/* harmony import */ var core_js_modules_esnext_typed_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_111___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_to_spliced_js__WEBPACK_IMPORTED_MODULE_111__);
/* harmony import */ var core_js_modules_esnext_typed_array_with_js__WEBPACK_IMPORTED_MODULE_112__ = __webpack_require__(9786);
/* harmony import */ var core_js_modules_esnext_typed_array_with_js__WEBPACK_IMPORTED_MODULE_112___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_esnext_typed_array_with_js__WEBPACK_IMPORTED_MODULE_112__);














































 // 拆分为新文件的原因：@babel/preset-env 要求 core-js 导入语句必须在文件最顶部
// 以下 import 语句会在 @babel/preset-env 中根据 browserslist 中声明的浏览器列表，自动修改为导入需要的 polyfill


































































// 新版 core-js 会替换掉这些 TypedArray 并且被 uglify 去掉 name
// 为了对齐旧版 core-js 行为，给他们强制设置 name
var TYPED_ARRAY_NAMES = ['Int8Array', 'Uint8Array', 'Uint8ClampedArray', 'Int16Array', 'Uint16Array', 'Int32Array', 'Uint32Array', 'Float32Array', 'Float64Array'];
TYPED_ARRAY_NAMES.forEach(CONSTRUCTOR_NAME => {
  var CONSTRUCTOR = globalThis[CONSTRUCTOR_NAME];
  if (CONSTRUCTOR && CONSTRUCTOR.name !== CONSTRUCTOR_NAME) {
    Object.defineProperty(CONSTRUCTOR, 'name', {
      value: CONSTRUCTOR_NAME
    });
  }
});

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
__webpack_require__.g.__polyfill_injecting = true;

// 预加载情况下调用 getSystemInfo，客户端不会马上返回结果，因此从 __wxConfig 上取 platform 字段
var isIOS = false;
if (__webpack_require__.g.__wxConfig && typeof __webpack_require__.g.__wxConfig.platform === 'string') {
  if (__webpack_require__.g.__wxConfig.platform.toLowerCase() === 'ios') {
    isIOS = true;
  }
} else if (typeof navigator !== 'undefined' && typeof navigator.userAgent === 'string') {
  var ua = navigator.userAgent.toLowerCase();
  if (ua.indexOf('iphone') >= 0 || ua.indexOf('ipad') >= 0) {
    isIOS = true;
  }
}

// 强制 core-js 使用 polyfill 的特性列表
var usePolyfill = [];
var useNative = ['WeakMap'];

// iOS 强制使用 Promise polyfill
if (isIOS) {
  // 强制让 core-js 用 macroTask 模拟 Promise
  __webpack_require__.g.Promise = undefined; // TODO 以后改成 microTask
  usePolyfill.push('Promise');
}

// 配置 core-js
__webpack_require__(2614)({
  usePolyfill,
  useNative
});

// 引入 core-js polyfill
__webpack_require__(7858);
__webpack_require__(8217);
delete __webpack_require__.g.__polyfill_injecting;
/******/ })()
;
var __wxTest__ = false;
var wxRunOnDebug = function (fun) {fun()};
var __wxConfig;
var Foundation;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it declares 'Foundation' on top-level, which conflicts with the current library output.
(() => {

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ src_Foundation)
});

// NAMESPACE OBJECT: ./src/Foundation/errorHandler.ts
var errorHandler_namespaceObject = {};
__webpack_require__.r(errorHandler_namespaceObject);
__webpack_require__.d(errorHandler_namespaceObject, {
  convertToErrorObj: () => (convertToErrorObj),
  emitFrameworkError: () => (emitFrameworkError),
  emitUnhandledError: () => (emitUnhandledError),
  emitUnhandledRejection: () => (emitUnhandledRejection),
  onFrameworkError: () => (onFrameworkError),
  onUnhandledError: () => (onUnhandledError),
  onUnhandledRejection: () => (onUnhandledRejection)
});

;// CONCATENATED MODULE: ./src/Foundation/env.ts
var wxLibrary = __webpack_require__.g.__wxLibrary;
var wxConfig = __webpack_require__.g.__wxConfig;
var envType = wxLibrary.envType;
var contextType = wxLibrary.contextType;
var isService = envType === 'Service';
var isWebView = envType === 'WebView';
var isWorker = envType === 'Worker';
var isApp = isWebView || isService && contextType.indexOf('App:') === 0;
var isGame = isService && contextType.indexOf('Game:') === 0;
var isMagicBrushFrameEnv = contextType.indexOf('MagicBrush:') === 0;
var _isSupportIsolateContext = !!wxConfig.isIsolateContext;
var isMainContext = _isSupportIsolateContext && isService && contextType.indexOf('MainContext') >= 0;
var isSubContext = _isSupportIsolateContext && isService && contextType.indexOf('SubContext') >= 0;
var isSafeSubContext = isSubContext && contextType.indexOf('Safe') >= 0;
var isIsolateContext = isMainContext || isSubContext;
var isWXLibWorker = wxConfig.workerContentType === 'wxlib';
var isSafeEnv = isWebView || isMainContext || isSafeSubContext || isWXLibWorker;
var platform = function (_window$navigator) {
  var platform = wxConfig.platform;
  if (!platform && typeof window === 'object' && typeof ((_window$navigator = window.navigator) === null || _window$navigator === void 0 ? void 0 : _window$navigator.userAgent) === 'string') {
    var ua = window.navigator.userAgent.toLowerCase();
    if (ua.indexOf('devtools') >= 0) {
      platform = 'devtools';
    } else if (ua.indexOf('miniprogramenv/windows') >= 0) {
      platform = 'windows';
    } else if (ua.indexOf('miniprogramenv/mac') >= 0) {
      platform = 'mac';
    } else if (ua.indexOf('miniprogramenv/mina') >= 0) {
      platform = 'mina';
    } else if (ua.indexOf('iphone') >= 0 || ua.indexOf('ipad') >= 0) {
      platform = 'ios';
    } else if (ua.indexOf('android') >= 0) {
      platform = 'android';
    }
  }
  return (platform || 'unknown').toLowerCase();
}();
var libVersionInfo = __libVersionInfo__;
var SDKVersion = typeof libVersionInfo === 'undefined' || libVersionInfo.version === 'develop' ? '9.9.9' : libVersionInfo.version;
var contextName = '';
var mayHaveSnapShot = !!wxLibrary.mayHaveSnapshot;
var WK_RENDERER_H5 = /* #__PURE__ */(() => typeof __webpack_require__.g === 'object' && __webpack_require__.g && __webpack_require__.g.__wkrenderer_h5)();
/* harmony default export */ const env = ({
  platform,
  SDKVersion,
  isIsolateContext,
  isGame,
  isApp,
  isMainContext,
  isSubContext,
  isSafeEnv,
  isService,
  isWebView,
  isWorker,
  isWidget: false,
  typeStr: isSubContext ? 'SubContext' : envType,
  fileName: wxLibrary.fileName,
  isWXLibWorker,
  workerType: 'user',
  contextName,
  mayHaveSnapShot,
  isWKGame: !!WK_RENDERER_H5,
  isMagicBrushFrameEnv
});
;// CONCATENATED MODULE: ./src/Foundation/console/utils.ts

var EMPTY = () => {};
var IS_DEVTOOLS = env.platform === 'devtools';
var hasPerformance = typeof performance !== 'undefined' && typeof performance.now === 'function';
function now() {
  if (hasPerformance) {
    return performance.now() + (performance.timeOrigin || performance.timing.navigationStart);
  } else {
    return Date.now();
  }
}
function consoleFactory(props, fn = () => EMPTY) {
  return props.reduce((obj, prop) => {
    obj[prop] = fn(prop);
    return obj;
  }, {});
}
function debugEnabled() {
  var wxConfig = __wxConfig || __webpack_require__.g.__wxConfig;
  if (!wxConfig || !('debug' in wxConfig) || typeof wxConfig.debug === 'undefined') return undefined;
  return !!wxConfig.debug;
}
function sinceTimeOrigin(time) {
  var timeOrigin = __wxConfig.coldLaunchTime || 0;
  if (timeOrigin > 1000) {
    return time - timeOrigin;
  } else {
    return time % 100000;
  }
}
var noop = () => {};

;// CONCATENATED MODULE: ./src/Foundation/console/wxConsole.ts

var props = ['log', 'info', 'warn', 'error', 'debug'];
var wxConsole = (() => {
  var ret = consoleFactory(props);
  wxRunOnDebug(() => {
    var getLineNumber = function () {
      var initiator = '';
      var e = new Error();
      if (typeof e.stack === 'string') {
        var isFirst = 0;
        var lines = e.stack.split('\n');
        for (var line of lines) {
          var matches = line.match(/^\s+at\s+(.*)/);
          if (matches) {
            if (isFirst++ === 3) {
              initiator = matches[1];
              break;
            }
          }
        }
      }
      return ' --> ' + (initiator.split(' ')[1] || initiator.split(' ')[0]);
    };
    ret = consoleFactory(props, method => function (...args) {
      if (IS_DEVTOOLS) {
        args.push(getLineNumber());
      }
      console[method]('[system]', ...args);
    });
  });
  return ret;
})();
/* harmony default export */ const console_wxConsole = (wxConsole);
;// CONCATENATED MODULE: ./src/Foundation/console/wxPerfConsole.ts


var wxPerfConsole_props = ['log', 'info', 'warn', 'error', 'profile', 'profileSync', 'traceBegin', 'traceEnd'];
var config = {
  longTaskThreshold: 50,
  verboseTrace: false
};
var wxPerfConsole = (() => {
  var ret = consoleFactory(wxPerfConsole_props);
  wxRunOnDebug(() => {
    var _log = function (method) {
      return function (...args) {
        console[method]('[perf]', env.typeStr, ...args);
      };
    };
    var userTimingSupportted = typeof performance !== 'undefined' && typeof performance.mark === 'function';
    var mark = function () {};
    var measure = function () {};
    if (userTimingSupportted) {
      mark = performance.mark.bind(performance);
      measure = performance.measure.bind(performance);
    }
    var innerId = 0;
    var traceEvents = [];
    function genTraceStack() {
      return traceEvents.map(evt => `[${evt.category}] ${evt.label}`).join('\n');
    }
    var perfConsole = {
      log: _log('log'),
      info: _log('info'),
      warn: _log('warn'),
      error: _log('error'),
      traceBegin(category, label, args) {
        traceEvents.push({
          category,
          label,
          args,
          t: now()
        });
      },
      traceEnd() {
        var endTime = now();
        var evt = traceEvents.pop();
        if (!evt) {
          perfConsole.error('Must call traceBegin before traceEnd', JSON.stringify(traceEvents));
          return;
        }
        var cost = endTime - evt.t;
        var logStr = `[profile][${evt.category}] ${evt.label} cost ${cost.toFixed(0)} ms (${sinceTimeOrigin(evt.t).toFixed(0)} ~ ${sinceTimeOrigin(endTime).toFixed(0)})`;
        if (cost >= config.longTaskThreshold) {
          perfConsole.warn(logStr, evt.args || '', `\n${genTraceStack()}`);
        } else if (config.verboseTrace) {
          perfConsole.log(logStr, evt.args || '');
        }
      },
      profile(tag, fun) {
        var id = tag + innerId++;
        mark(id + '_start');
        var start = now();
        fun();
        function done() {
          var end = now();
          mark(id + '_end');
          measure(tag, id + '_start', id + '_end');
          var cost = end - start;
          return Number.isInteger(cost) ? cost : parseFloat(cost.toFixed(2));
        }
        return done;
      },
      profileSync(tag, fun) {
        var id = tag + innerId++;
        mark(id + '_start');
        var start = now();
        var ret = fun();
        var end = now();
        mark(id + '_end');
        measure(tag, id + '_start', id + '_end');
        var cost = end - start;
        return {
          ret,
          cost: Number.isInteger(cost) ? cost : parseFloat(cost.toFixed(2))
        };
      }
    };
    ret = perfConsole;
  });
  return ret;
})();
/* harmony default export */ const console_wxPerfConsole = (wxPerfConsole);
;// CONCATENATED MODULE: ./src/Foundation/EventEmitter.ts
var EVT_ERR = Symbol('error');
var EVT_SLOW = Symbol('slow');
class EventEmitter {
  constructor() {
    this.$ = Object.create(null);
    this.$$ = Object.create(null);
  }
  onInternalEvent(event, cb) {
    var listeners = this.$$[event];
    if (listeners) {
      listeners.push(cb);
    } else {
      this.$$[event] = [cb];
    }
    return this;
  }
  emitPrivate(event, ...args) {
    var listeners = this.$$[event];
    if (listeners && listeners.length > 0) {
      listeners.forEach(cb => {
        try {
          cb(...args);
        } catch (e) {
          console.error('EventEmitter error:', e);
        }
      });
      return true;
    }
    return false;
  }
  onError(cb) {
    this.onInternalEvent(EVT_ERR, cb);
    return this;
  }
  onSlow(cb) {
    this.onInternalEvent(EVT_SLOW, cb);
    return this;
  }
  _privEmit(event, eventOptions, ...args) {
    var listeners = this.$[event];
    if (listeners && listeners.length > 0) {
      var needClean = false;
      var ret;
      for (var listener of listeners) {
        if (listener.count !== 0) {
          try {
            var t1 = Date.now(); // #@snapshot-ignore Date.now
            ret = listener.cb(...args);
            var t2 = Date.now(); // #@snapshot-ignore Date.now
            if (t2 - t1 > EventEmitter.SLOW_CALLBACK_THRESHOLD) {
              this.emitPrivate(EVT_SLOW, event, t1, t2, listener.cb);
            }
          } catch (e) {
            if (!this.emitPrivate(EVT_ERR, event, e)) {
              throw e;
            }
          }
        }
        if (listener.count > 0) listener.count--;
        if (listener.count === 0) needClean = true;
        if (ret === false && eventOptions.cancelable) break;
      }
      if (needClean) {
        this.$[event] = listeners.filter(l => l.count !== 0);
      }
      return true;
    }
    return false;
  }
  emit(event, ...args) {
    return this._privEmit(event, {}, ...args);
  }
  emitCancelable(event, ...args) {
    return this._privEmit(event, {
      cancelable: true
    }, ...args);
  }
  many(event, cb, count, options = {}) {
    if (!cb) return this;
    var listener = {
      count,
      cb
    };
    var listeners = this.$[event];
    if (listeners) {
      if (options.prepend) {
        listeners.unshift(listener);
      } else {
        listeners.push(listener);
      }
    } else {
      this.$[event] = [listener];
    }
    return this;
  }
  on(event, cb, options) {
    return this.many(event, cb, -1, options);
  }
  once(event, cb, options) {
    return this.many(event, cb, 1, options);
  }
  off(event, cb) {
    var listeners = this.$[event];
    if (!listeners) return false;
    var index = listeners.findIndex(it => it.cb === cb);
    if (index < 0) return false;
    listeners.splice(index, 1);
    return true;
  }
}
EventEmitter.SLOW_CALLBACK_THRESHOLD = 50;
;// CONCATENATED MODULE: ./src/Foundation/errorHandler.ts


var errorEmitter = new EventEmitter();
var EVT_UNHANDLED_ERROR = 'unhandlederror';
var EVT_UNHANDLED_REJ = 'unhandledrejection';
var EVT_FRAMEWORK_ERROR = 'frameworkerror';
var promiseMap = new WeakMap();
function processUnhandledRejectionNextTick(event) {
  var promise = event.promise;
  if (!promise) return;
  if (!promiseMap.has(promise)) {
    setTimeout(() => {
      var event = promiseMap.get(promise);
      if ((event === null || event === void 0 ? void 0 : event.type) === 0) {
        emitUnhandledRejection(event.reason, event.promise);
      }
      promiseMap.delete(promise);
    }, 0);
  }
  promiseMap.set(promise, event);
}
var hasOwn = Object.prototype.hasOwnProperty;
function convertToErrorObj(e) {
  var _e$constructor;
  if (e && ((_e$constructor = e.constructor) === null || _e$constructor === void 0 ? void 0 : _e$constructor.name) === 'Object') {
    if (typeof e.message === 'string' && typeof e.stack === 'string') {
      var error = new Error(e.message);
      Object.assign(error, e);
      return error;
    }
  }
  return e;
}
function emitUnhandledRejection(reason, promise) {
  reason = convertToErrorObj(reason);
  lifeCycle.onLoad(() => {
    if (!errorEmitter.emit(EVT_UNHANDLED_REJ, {
      reason,
      promise
    })) {
      console.error('Uncaught (in promise)', reason);
    }
  });
}
var inFrameworkErrorHandler = false;
var inUncaughtErrorHandler = false;
function emitFrameworkError(e, messagePrefix) {
  if (e instanceof Error && messagePrefix) {
    e.message = `${messagePrefix} fail: ${e.message}`;
  }
  e = convertToErrorObj(e);
  if (__wxConfig.isSnapshoting) {
    throw e;
  }
  lifeCycle.onLoad(() => {
    if (inFrameworkErrorHandler) {
      console.error('[ErrorHandler] recursive framework error detected.', e);
      return;
    }
    inFrameworkErrorHandler = true;
    try {
      if (!errorEmitter.emit(EVT_FRAMEWORK_ERROR, e)) {
        emitUnhandledError(e);
      }
    } catch (e) {
      console.error('Framework', e);
    }
    inFrameworkErrorHandler = false;
  });
}
function emitUnhandledError(e) {
  e = convertToErrorObj(e);
  if (__wxConfig.isSnapshoting) {
    throw e;
  }
  lifeCycle.onLoad(() => {
    if (inUncaughtErrorHandler) {
      console.error('[ErrorHandler] recursive uncaught error detected.', e);
      return;
    }
    inUncaughtErrorHandler = true;
    try {
      if (!errorEmitter.emit(EVT_UNHANDLED_ERROR, e)) {
        if ((__wxConfig.platform === 'windows' || __wxConfig.platform === 'mac') && typeof WORKER_RUNTIME !== 'undefined' && WORKER_RUNTIME && __wxConfig.appType === 4) {} else {
          console.error('Uncaught', e);
        }
      }
    } catch (e) {
      console.error('Uncaught', e);
    }
    inUncaughtErrorHandler = false;
  });
}
function onUnhandledRejection(cb) {
  errorEmitter.on(EVT_UNHANDLED_REJ, cb);
}
function onFrameworkError(cb) {
  errorEmitter.on(EVT_FRAMEWORK_ERROR, cb);
}
function onUnhandledError(cb) {
  errorEmitter.on(EVT_UNHANDLED_ERROR, cb);
}
;
(function bindErrorListener(global) {
  if (typeof global === 'object' && typeof global.addEventListener === 'function') {
    global.addEventListener('unhandledrejection', e => {
      emitUnhandledRejection(e.reason, e.promise);
      if (e.reason) e.preventDefault();
    });
    global.addEventListener('error', e => {
      var _global$navigator, _global$navigator$use;
      var error = e.error || {
        message: e.message,
        stack: `${e.message}\nEmpty stack, maybe muted error. (xweb=${((_global$navigator = global.navigator) === null || _global$navigator === void 0 ? void 0 : (_global$navigator$use = _global$navigator.userAgent) === null || _global$navigator$use === void 0 ? void 0 : _global$navigator$use.toUpperCase().indexOf('XWEB')) >= 0})`
      };
      emitUnhandledError(error);
      if (e.error) e.preventDefault();
    });
  } else if (typeof global.onunhandledrejection === 'undefined') {
    Object.defineProperty(global, 'onunhandledrejection', {
      value(e = {}) {
        if (hasOwn.call(e, 'type')) {
          processUnhandledRejectionNextTick({
            type: e.type,
            reason: e.reason,
            promise: e.promise
          });
        } else {
          emitUnhandledRejection(e.reason, e.promise);
        }
      }
    });
  }
})(__webpack_require__.g);

;// CONCATENATED MODULE: ./src/Foundation/wxConfig/utils.ts
var JSONParse = JSON.parse;
var JSONStringify = JSON.stringify;
var TIMESTAMP_OF_2001 = 978278400000;
function deepCopy(obj) {
  return JSONParse(JSONStringify(obj));
}
function convertToUnixTimestamp(time) {
  if (!time) return 0;
  var currentTimeZoneOffsetInHours = new Date().getTimezoneOffset() / 60;
  return time + TIMESTAMP_OF_2001 - currentTimeZoneOffsetInHours * 3600 * 1000;
}
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/filter.ts




function filterPropertiesOnCreate(wxConfig) {
  wxConfig.platform = env.platform;
  if (!wxConfig.brand && wxConfig.platform === 'ios') wxConfig.brand = 'iPhone';
  wxConfig.sdkVersion = wxConfig.SDKVersion = env.SDKVersion;
  wxConfig.isReady = false;
  wxConfig.onReady = lifeCycle.onStart;
}
function filterPropertiesOnLoad(wxConfig) {
  var _libVersionInfo__$de;
  filterPropertiesOnCreate(wxConfig);
  if (!env.isSubContext) wxConfig.preload = wxConfig.preload === true;
  if (typeof wxConfig.pixelRatio === 'number') {
    wxConfig.devicePixelRatio = wxConfig.pixelRatio;
  } else if (typeof wxConfig.devicePixelRatio === 'number') {
    wxConfig.pixelRatio = wxConfig.devicePixelRatio;
  }
  var overwriteExpt = (_libVersionInfo__$de = __libVersionInfo__.debugOptions) === null || _libVersionInfo__$de === void 0 ? void 0 : _libVersionInfo__$de['overwriteExpt'];
  if (overwriteExpt) {
    wxConfig.expt = Object.assign(wxConfig.expt || {}, overwriteExpt);
  } else {
    wxConfig.expt = wxConfig.expt || {};
  }
}
function filterPropertiesOnStart(wxConfig) {
  filterPropertiesOnLoad(wxConfig);
  wxConfig.isReady = true;
  wxConfig.appLaunchInfo = wxConfig.appLaunchInfo || {};
  wxConfig.preloadType = wxConfig.preloadType || wxConfig.appLaunchInfo.preloadType || wxConfig.preload;
  if (wxConfig.platform === 'ios') {
    var t1 = convertToUnixTimestamp(wxConfig.appLaunchInfo.clickTimestampInMs);
    var t2 = Number.MAX_SAFE_INTEGER;
    var instanceId = wxConfig.instanceId;
    if (instanceId) {
      try {
        var tsItems = instanceId.split('&').filter(item => item.indexOf('ts=') === 0);
        if (tsItems.length > 0) {
          t2 = parseInt(tsItems[0].slice(3), 10);
        }
      } catch (e) {
        emitFrameworkError(e, 'parseInstanceId');
      }
    }
    wxConfig.coldLaunchTime = Math.min(t1, t2);
  } else {
    wxConfig.coldLaunchTime = wxConfig.appLaunchInfo.clickTimestamp || 0;
  }
}
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/features.ts
var _libVersionInfo$featu;
var features_libVersionInfo = __libVersionInfo__;
var pruneWxConfigByPage = !!((_libVersionInfo$featu = features_libVersionInfo.features) !== null && _libVersionInfo$featu !== void 0 && _libVersionInfo$featu.pruneWxConfigByPage);
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/mockGlobal.ts


var defineProperty = Object.defineProperty;
var whiteList = ['env', 'appLaunchInfo', 'ext', 'wxAppInfo', 'debug', 'entryPagePath', 'envVersion', 'tabBar', 'pages', 'page', 'accountInfo', 'global', 'platform', 'system', 'appType', 'networkTimeout', 'navigateToMiniProgramAppIdList', 'plugins', 'extAppid', 'host', 'prerender'];
function defineWxConfigProperty(obj, _obj, key, value) {
  defineProperty(obj, key, {
    configurable: true,
    enumerable: true,
    get() {
      if (key in _obj) return _obj[key];
      try {
        if (typeof value !== 'function') return value;else return value();
      } catch (e) {
        emitFrameworkError(e, `read mock wxConfig.${key}`);
        return undefined;
      }
    },
    set(v) {
      _obj[key] = v;
    }
  });
}
function mockGloablWxConfig() {
  var originWxConfig = __webpack_require__.g.__wxConfig;
  var _safeWxConfig = {};
  var safeWxConfig = {};
  var publicPage = pruneWxConfigByPage ? {} : originWxConfig.page || {};
  try {
    defineWxConfigProperty(safeWxConfig, _safeWxConfig, 'deprecated', true);
    whiteList.forEach(key => {
      if (!(key in originWxConfig)) return;
      var value = originWxConfig[key];
      switch (key) {
        case 'page':
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, publicPage);
            break;
          }
        case 'env':
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, () => {
              console.warn('[Deprecation] __wxConfig.env is deprecated, please use wx.env instead.');
              return {
                USER_DATA_PATH: value.USER_DATA_PATH
              };
            });
            break;
          }
        case 'accountInfo':
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, {
              appId: value.appId,
              icon: value.icon,
              nickname: value.nickname
            });
            break;
          }
        case 'appLaunchInfo':
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, () => {
              console.warn('[Deprecation] __wxConfig.appLaunchInfo is deprecated, please use wx.getLaunchOptionsSync() instead.');
              if (wx && typeof wx.getLaunchOptionsSync === 'function') {
                return wx.getLaunchOptionsSync();
              } else {
                return {};
              }
            });
            break;
          }
        case 'wxAppInfo':
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, {
              maxRequestConcurrent: value.maxRequestConcurrent,
              maxUploadConcurrent: value.maxUploadConcurrent,
              maxDownloadConcurrent: value.maxDownloadConcurrent,
              maxWorkerConcurrent: value.maxWorkerConcurrent,
              maxWebsocketConnect: value.maxWebsocketConnect
            });
            break;
          }
        default:
          {
            defineWxConfigProperty(safeWxConfig, _safeWxConfig, key, value);
          }
      }
    });
    __webpack_require__.g.__wxConfig = safeWxConfig;
  } catch (e) {
    emitFrameworkError(e, 'mockGloablWxConfig');
    __webpack_require__.g.__wxConfig = originWxConfig;
  }
  return publicPage;
}
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/proxy.ts




var onLoadPattern = /^(.*XWeb.*|insert.*ToWebLayer|.*Skia.*)$/;
var allowLists = /* #__PURE__ */(() => {
  var onCreateAllowList = ['platform', 'brand', 'model', 'nativeBufferEnabled', 'isIsolateContext', 'workerContentType', 'isSnapshoting', 'host', 'SDKVersion', 'sdkVersion', 'isReady', 'debug', 'toJSON', 'supportWorkerMultiContext', 'supoortWorkerMultiContext', 'exportBaseMethods'];
  var onLoadAllowList = onCreateAllowList.concat(['JSEngineName', 'clientVersion', 'pixelRatio', 'devicePixelRatio', 'system', 'version', 'language', 'snapshotMetaInfo', 'preload', 'envPreloadType', 'env', 'clientDebug', 'jitMode', 'isWK', 'wmpfDirectInvokeJs']);
  return {
    onCreate: new Set(onCreateAllowList),
    onLoad: new Set(onLoadAllowList)
  };
})();
function useAccessProxy(wxConfig) {
  var enabled = true;
  return {
    proxy: new Proxy(wxConfig, {
      get(target, prop, receiver) {
        var value = Reflect.get(target, prop, receiver);
        if (!enabled || typeof prop !== 'string' || typeof value === 'function') return value;
        var currentPhase = target.currentPhase;
        if (currentPhase !== 'onCreate' && currentPhase !== 'onLoad') return value;
        var regardPhase = env.mayHaveSnapShot ? currentPhase : 'onLoad';
        if (allowLists[regardPhase].has(prop) || regardPhase === 'onLoad' && onLoadPattern.test(prop)) {
          return value;
        }
        var err = new Error(`[${env.typeStr}](TO:基础库开发同学) 在 ${currentPhase} 阶段访问 __wxConfig.${prop} 可能取不到值`); // #@exclude-stack-frame
        if (__wxConfig.platform === 'android' && err.stack && err.stack.split('\n').length <= 2) {
          return value;
        }
        if (typeof WORKER_RUNTIME !== 'undefined' && WORKER_RUNTIME) {
          return value;
        }
        emitFrameworkError(err);
        return undefined;
      }
    }),
    setEnabled(val) {
      enabled = val;
    },
    clone(obj) {
      var ret;
      if (enabled) {
        enabled = false;
        ret = deepCopy(obj);
        enabled = true;
      } else {
        ret = deepCopy(obj);
      }
      return ret;
    }
  };
}
function useSyncProxy(wxConfig) {
  return new Proxy(wxConfig, {
    set(target, prop, value, receiver) {
      if (prop === '__siblings__') {
        return Reflect.set(target, prop, value, receiver);
      }
      var siblings = Reflect.get(target, '__siblings__', receiver);
      if (Array.isArray(siblings)) {
        if (siblings.length > 1) {
          console_wxConsole.log(`[WXConfig] write __wxConfig.${prop.toString()}, sync to all contexts.`);
        }
        siblings.forEach(obj => {
          Reflect.set(obj, prop, value);
        });
        return true;
      } else {
        return Reflect.set(target, prop, value, receiver);
      }
    }
  });
}
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/trim.ts


function trimProperties(wxConfig, updatePage) {
  var _wxConfig$tabBar;
  if (Array.isArray(wxConfig === null || wxConfig === void 0 ? void 0 : (_wxConfig$tabBar = wxConfig.tabBar) === null || _wxConfig$tabBar === void 0 ? void 0 : _wxConfig$tabBar.list)) {
    wxConfig.tabBar.list.forEach(item => {
      delete item.iconData;
      delete item.selectedIconData;
    });
  }
  delete wxConfig.permission; // #5330 移除掉这个字段

  var subPackages = wxConfig.subPackages || wxConfig.subpackages;
  if (Array.isArray(subPackages) && subPackages.length > 0) {
    subPackages.forEach(pkg => {
      delete pkg.pages;
    });
    wxConfig.subPackages = wxConfig.subpackages = subPackages;
  }
  if (wxConfig.platform === 'devtools') {
    wxConfig.__globalComponentsCount = Object.keys(wxConfig.usingComponents || {}).length;
  }
  if (pruneWxConfigByPage) {
    if (!env.isSubContext) {
      delete wxConfig.usingComponents;
      Object.values(wxConfig.page || {}).forEach(value => {
        if (value !== null && value !== void 0 && value.window) delete value.window.usingComponents;
      });
      wxConfig._preloadRule = wxConfig.preloadRule || {};
      wxConfig._page = wxConfig.page || {};
      delete wxConfig.preloadRule;
      delete wxConfig.page;
    }
    wxConfig.updatePage = function (key, value) {
      if (value !== null && value !== void 0 && value.window) delete value.window.usingComponents;
      updatePage(key, value);
    };
    wxConfig.updatePreloadRule = function (key, value) {
      wxConfig.preloadRule = wxConfig.preloadRule || {};
      wxConfig.preloadRule[key] = value;
    };
  }
  __webpack_require__.g.__wxConfig.page = __webpack_require__.g.__wxConfig.page || {};
  wxConfig.page = wxConfig.page || {};
}
;// CONCATENATED MODULE: ./src/Foundation/wxConfig/index.ts







var wxConfig_isSafeEnv = env.isSafeEnv;
var localWXConfig = Object.create(null);
var localWXConfigProxy = env.isService ? useSyncProxy(localWXConfig) : localWXConfig;
var setValidate = _val => {};
var _copyWXConfig = deepCopy;
wxRunOnDebug(() => {
  var {
    proxy,
    setEnabled,
    clone
  } = useAccessProxy(localWXConfigProxy);
  localWXConfigProxy = proxy;
  setValidate = setEnabled;
  _copyWXConfig = clone;
});
var EVT_UPDATE_PAGE = 'wxConfig:updatePage';
function handleWXConfigOnCreate(outerWxConfig) {
  localWXConfig.currentPhase = 'onCreate';
  if (typeof outerWxConfig === 'undefined') return localWXConfigProxy;
  setValidate(false);
  Object.assign(localWXConfig, wxConfig_isSafeEnv ? outerWxConfig : deepCopy(outerWxConfig));
  filterPropertiesOnCreate(localWXConfig);
  setValidate(true);
  return localWXConfigProxy;
}
function handleWXConfigOnLoad(outerWxConfig) {
  localWXConfig.currentPhase = 'onLoad';
  if (typeof outerWxConfig === 'undefined') return localWXConfigProxy;
  setValidate(false);
  Object.assign(localWXConfig, wxConfig_isSafeEnv ? outerWxConfig : deepCopy(outerWxConfig));
  localWXConfig.onPageUpdate = lifeCycle.on.bind(null, EVT_UPDATE_PAGE);
  filterPropertiesOnLoad(localWXConfig);
  setValidate(true);
  return localWXConfigProxy;
}
function handleWXConfigOnStart(outerWxConfig, useOuterWxConfig = false) {
  setValidate(false);
  localWXConfig.currentPhase = 'onStart';
  if (typeof outerWxConfig === 'undefined') return localWXConfigProxy;
  if (useOuterWxConfig) {
    Object.assign(localWXConfig, outerWxConfig);
    Object.defineProperty(localWXConfig, '__siblings__', {
      value: outerWxConfig.__siblings__,
      enumerable: false,
      writable: false,
      configurable: false
    });
  } else {
    Object.assign(localWXConfig, wxConfig_isSafeEnv ? outerWxConfig : deepCopy(outerWxConfig));
    filterPropertiesOnStart(localWXConfig);
    trimProperties(localWXConfig, (key, value) => {
      lifeCycle.emit(EVT_UPDATE_PAGE, {
        key,
        value
      });
    });
    Object.defineProperty(localWXConfig, '__siblings__', {
      value: [],
      enumerable: false,
      writable: false,
      configurable: false
    });
  }
  if (Array.isArray(localWXConfig.__siblings__)) {
    localWXConfig.__siblings__.push(localWXConfig);
  }
  var publicPage;
  localWXConfig.onPageUpdate(({
    key,
    value
  }) => {
    localWXConfig.page = localWXConfig.page || {};
    localWXConfig.page[key] = localWXConfig.page[key + '.html'] = value;
    if (publicPage) publicPage[key + '.html'] = deepCopy(value);
  });
  if (!wxConfig_isSafeEnv) {
    publicPage = mockGloablWxConfig();
  }
  return localWXConfigProxy;
}
function copyWXConfig(wxConfig) {
  return _copyWXConfig(wxConfig);
}
;// CONCATENATED MODULE: ./src/Foundation/lifeCycle.ts






var globalInnerEmitter = new EventEmitter();
var lifecycleEmitter = new EventEmitter();
var lifeCycleState = {};
var PHASE_BRIDGE_READY = 'WeixinJSBridgeReady';
var PHASE_LIBRARY_END = 'libraryEnd';
var PHASE_LIBRARY_LOAD = 'load';
var PHASE_LIBRARY_POST_LOAD = 'postLoad';
var PHASE_LIBRARY_START = 'start';
var PHASE_LIBRARY_POST_START = 'postStart';
function onLifeCycle(name, fun) {
  var doTrace = typeof Trace !== 'undefined';
  var fn = () => {
    try {
      if (doTrace) Trace.traceBegin('Framework', `LibLifeCycle.${name} @ ${env.fileName}`);
      fun(lifeCycleState[name]);
    } catch (e) {
      emitFrameworkError(e, 'LifeCycle.' + name);
    } finally {
      if (doTrace) Trace.traceEnd();
    }
  };
  if (name in lifeCycleState) fn();else lifecycleEmitter.once(name, fn);
}
function emitLifeCycle(name, data) {
  var _wxNativeConsole, _wxNativeConsole2;
  if (name in lifeCycleState) return false;
  lifeCycleState[name] = data;
  (_wxNativeConsole = wxNativeConsole) === null || _wxNativeConsole === void 0 ? void 0 : _wxNativeConsole.info(`[LifeCycle] emit ${name} for ${env.fileName}`);
  var ret = lifecycleEmitter.emit(name, data);
  (_wxNativeConsole2 = wxNativeConsole) === null || _wxNativeConsole2 === void 0 ? void 0 : _wxNativeConsole2.info(`[LifeCycle] finish ${name} for ${env.fileName}`);
  return ret;
}
var onLoad = cb => {
  if (!env.mayHaveSnapShot) {
    cb();
  } else {
    onLifeCycle(PHASE_LIBRARY_LOAD, cb);
  }
};
var lifeCycle = {
  EventEmitter: EventEmitter,
  on: globalInnerEmitter.on.bind(globalInnerEmitter),
  emit: globalInnerEmitter.emit.bind(globalInnerEmitter),
  once: globalInnerEmitter.once.bind(globalInnerEmitter),
  off: globalInnerEmitter.off.bind(globalInnerEmitter),
  getIsLoaded() {
    return PHASE_LIBRARY_LOAD in lifeCycleState;
  },
  getIsStarted() {
    return PHASE_LIBRARY_START in lifeCycleState;
  },
  onBridgeReady(cb) {
    onLifeCycle(PHASE_BRIDGE_READY, cb);
  },
  setWeixinJSBridge(WeixinJSBridge) {
    emitLifeCycle(PHASE_BRIDGE_READY, WeixinJSBridge);
  },
  onLibraryEnd: onLifeCycle.bind(null, PHASE_LIBRARY_END),
  onCreate(cb) {
    cb();
  },
  onLoadInstant: onLoad,
  onLoad,
  _onPostLoad: onLifeCycle.bind(null, PHASE_LIBRARY_POST_LOAD),
  onStart: onLifeCycle.bind(null, PHASE_LIBRARY_START),
  onPostStart: onLifeCycle.bind(null, PHASE_LIBRARY_POST_START)
};
lifecycleEmitter.onError((event, e) => {
  console_wxConsole.error(`[LifeCycle/${env.typeStr}] ${event.toString()} failed: `, e);
  emitFrameworkError(e, 'LifeCycle.' + event.toString());
}).onSlow((event, t1, t2, fun) => {
  console_wxPerfConsole.warn(`[LifeCycle/${env.typeStr}] slow ${event.toString()} callback (${t2 - t1}ms)\n${fun + ''}`);
});
__webpack_require__.g.__wxLibrary.onEnd = function () {
  emitLifeCycle(PHASE_LIBRARY_END);
  if (!env.mayHaveSnapShot) {
    emitOnLoad();
  }
};
__wxConfig = handleWXConfigOnCreate(__webpack_require__.g.__wxConfig);
var devLogWXConfig = [];
var isLoad = false;
var isStart = false;
function emitOnLoad() {
  if (!isLoad && !isStart) {
    isLoad = true;
    __wxConfig = handleWXConfigOnLoad(__webpack_require__.g.__wxConfig);
    wxRunOnDebug(() => {
      devLogWXConfig.push(['onLoad', copyWXConfig(__wxConfig)]);
    });
    emitLifeCycle(PHASE_LIBRARY_LOAD, __wxConfig);
    initOnStartEmitter();
    emitLifeCycle(PHASE_LIBRARY_POST_LOAD, __wxConfig);
  } else {
    emitFrameworkError(new Error(`LifeCycle error: undesired onLoad(${isLoad}/${isStart})`));
  }
}
function emitOnStart(outerWxConfig, useOuter = false) {
  if (isLoad && !isStart) {
    isStart = true;
    var readyStart = Date.now();
    __wxConfig = handleWXConfigOnStart(outerWxConfig, useOuter);
    if (!('onReadyStart' in __wxConfig)) {
      ;
      __wxConfig.onReadyStart = readyStart;
    }
    wxRunOnDebug(() => {
      devLogWXConfig.push(['onStart', useOuter ? '<use others>' : copyWXConfig(__wxConfig)]);
    });
    emitLifeCycle(PHASE_LIBRARY_START, __wxConfig);
    __wxConfig.onReadyEnd = Date.now();
    wxRunOnDebug(() => {
      devLogWXConfig.forEach(([tag, wxConfig]) => {
        console_wxConsole.info(`[wxConfig] ${env.typeStr}/${tag}\n`, wxConfig);
      });
      devLogWXConfig = [];
    });
    emitLifeCycle(PHASE_LIBRARY_POST_START, __wxConfig);
  } else {
    emitFrameworkError(new Error(`LifeCycle error: undesired onStart(${isLoad}/${isStart})`));
  }
}
function initOnStartEmitter() {
  if (env.isSubContext) {
    ;
    __wxConfig.__readyHandler = mainContextWxConfig => {
      emitOnStart(mainContextWxConfig, true);
    };
  } else if (__wxConfig.preload === true) {
    lifeCycle.onBridgeReady(bridge => {
      bridge.on('onWxConfigReady', () => {
        emitOnStart(__webpack_require__.g.__wxConfig);
      });
    });
  } else {
    lifeCycle.onLibraryEnd(() => {
      emitOnStart(__webpack_require__.g.__wxConfig);
    });
  }
}
if (__wxConfig.isSnapshoting) {
  if (!env.mayHaveSnapShot) {}
  ;
  __webpack_require__.g.WeixinSnapshot = {
    snapshotContextReady() {
      delete __webpack_require__.g.WeixinSnapshot;
      __wxConfig.isSnapshoting = false;
      emitOnLoad();
    }
  };
  wxRunOnDebug(() => {
    devLogWXConfig.push(['onCreate', copyWXConfig(__wxConfig)]);
  });
} else {
  if (env.mayHaveSnapShot) {
    lifeCycle.onLibraryEnd(emitOnLoad);
  }
}
;// CONCATENATED MODULE: ./src/Foundation/console/wxNativeConsole.ts




class Level {
  constructor(num, type, fn) {
    this.num = num;
    this.type = type;
    this.bindingFn = void 0;
    this.bindingFn = typeof fn === 'function' ? fn : noop;
  }
}
var LEVEL = {
  ALL: new Level(Number.MIN_VALUE, 'ALL'),
  DEBUG: new Level(5000, 'DEBUG', console.debug),
  LOG: new Level(10000, 'LOG', console.log),
  INFO: new Level(20000, 'INFO', console.info),
  WARN: new Level(30000, 'WARN', console.warn),
  ERROR: new Level(40000, 'ERROR', console.error),
  OFF: new Level(Number.MAX_VALUE, 'OFF')
};
var loggerFactory = (logFunc, category) => ({
  debug: logFunc(LEVEL.DEBUG, category),
  log: logFunc(LEVEL.LOG, category),
  info: logFunc(LEVEL.INFO, category),
  warn: logFunc(LEVEL.WARN, category),
  error: logFunc(LEVEL.ERROR, category)
});
var globalLogLevel = LEVEL.INFO;
wxRunOnDebug(() => {
  globalLogLevel = LEVEL.ALL;
});
var runOnMainContext = () => {
  var platform = env.platform;
  var LOG_INTERVAL = 4000;
  var LOG_LIMIT = 1024;
  var ENABLE_LOG_CACHE = platform !== 'android';
  var logCache = [];
  var _formatTime = function (d) {
    var M = ('0' + (d.getMonth() + 1)).slice(-2);
    var D = ('0' + d.getDate()).slice(-2);
    var h = ('0' + d.getHours()).slice(-2);
    var m = ('0' + d.getMinutes()).slice(-2);
    var s = ('0' + d.getSeconds()).slice(-2);
    var ms = ('00' + d.getMilliseconds()).slice(-3);
    var date = d.getFullYear() + '-' + M + '-' + D;
    var time = h + ':' + m + ':' + s + '.' + ms;
    if (platform === 'ios') {
      var offset = (d.getTimezoneOffset() / 6000 * -1).toFixed(4).replace(/^0\./, '+').replace(/-0\./, '-');
      return date + ' ' + time + '000' + offset;
    } else {
      var _offset = (d.getTimezoneOffset() / 60 * -1).toFixed(1).replace(/^(\d)/, '+$1');
      return date + ' ' + _offset + ' ' + time;
    }
  };
  var _systemLog = function (logs) {
    if (platform !== 'android') {
      WeixinJSBridge.invoke('systemLog', {
        dataArray: logs.map(item => ({
          message: `\n${_formatTime(item.date)} [${item.level.type[0].toUpperCase()}][wxapplib]] ${item.content}`
        }))
      });
    } else {
      logs.forEach(item => {
        item.level.bindingFn('[wxapplib]] ' + item.content);
      });
    }
  };
  var transformArg = item => {
    if (item instanceof Error) {
      return `${item.message}\n${item.stack}`;
    } else if (item && typeof item.stack === 'string' && typeof item.message === 'string') {
      return `${item.message}\n${item.stack}`;
    }
    switch (typeof item) {
      case 'bigint':
        return item.toString();
      case 'boolean':
        return item.toString();
      case 'function':
        return item.toString();
      case 'number':
        return item.toString();
      case 'string':
        return item;
      case 'symbol':
        return item.toString();
      case 'undefined':
        return 'undefined';
      case 'object':
        {
          var json;
          try {
            json = JSON.stringify(item);
          } catch (err) {
            json = '[对象含有循环引用]';
          }
          return json;
        }
      default:
        return undefined;
    }
  };
  var _log = function (level, category) {
    return function (...args) {
      if (category) {
        Array.prototype.unshift.call(args, '[' + category + ']');
      }
      if (debugEnabled() || level.num >= LEVEL.WARN.num) {
        var _level$type$toLowerCa;
        ;
        (_level$type$toLowerCa = console_wxConsole[level.type.toLowerCase()]) === null || _level$type$toLowerCa === void 0 ? void 0 : _level$type$toLowerCa.call(console_wxConsole, ...args);
      }
      if (level.num >= globalLogLevel.num) {
        var logData = Array.prototype.slice.call(args);
        var content = logData.map(transformArg).join(' ');
        if (ENABLE_LOG_CACHE) {
          var date = new Date();
          if (logCache && logCache.length > LOG_LIMIT) {
            logCache.shift();
          }
          logCache.push({
            date,
            level,
            content
          });
        } else {
          _systemLog([{
            level,
            content
          }]);
        }
      }
    };
  };
  lifeCycle.onStart(() => {
    setTimeout(function _submitLogs() {
      setTimeout(_submitLogs, LOG_INTERVAL);
      if (logCache.length === 0) {
        return;
      }
      _systemLog(logCache);
      logCache = [];
    }, LOG_INTERVAL);
  });
  function createLogger(category) {
    var cate = typeof category === 'string' ? category : 'default';
    return loggerFactory(_log, cate);
  }
  var __mergeSubContextLogs = logTasks => {
    if (!Array.isArray(logTasks)) {
      return;
    }
    logTasks.forEach(logTask => {
      var {
        level,
        logs,
        category
      } = logTask;
      _log(level, category)(...logs);
    });
  };
  return {
    ...loggerFactory(_log),
    createLogger,
    __mergeSubContextLogs,
    __isFromMainContext: true
  };
};
var runOnSubContext = () => {
  var penddingLogCache = [];
  var _penddingLog = (level, category) => (...logs) => {
    penddingLogCache.push({
      level,
      logs,
      category
    });
  };
  var createLogger = category => {
    var cate = typeof category === 'string' ? category : 'default';
    return loggerFactory(_penddingLog, cate);
  };
  var loopToMergeLogs = () => {
    var delayTime = 1000;
    var loopFunc = () => {
      var mergeLogs = wxNativeConsole.__isFromMainContext ? wxNativeConsole.__mergeSubContextLogs : null;
      if (mergeLogs) {
        mergeLogs(penddingLogCache);
        penddingLogCache = [];
      } else {
        loopToMergeLogs();
      }
    };
    setTimeout(loopFunc, delayTime);
  };
  lifeCycle.onStart(loopToMergeLogs);
  return {
    ...loggerFactory(_penddingLog),
    createLogger,
    __isFromMainContext: false
  };
};
var res = (() => {
  if (env.isWorker || env.isWidget || env.isMagicBrushFrameEnv) {
    var createLogger = function () {
      return console_wxConsole;
    };
    return Object.assign({
      createLogger
    }, console_wxConsole);
  } else if (!env.isSubContext || !env.isIsolateContext) {
    return runOnMainContext();
  } else {
    return runOnSubContext();
  }
})();
lifeCycle.onLoad(() => {
  res.info(`[BaseLibVersion] ${env.fileName}: ${__libVersionInfo__.version} (${__libVersionInfo__.updateTime})}`);
});
/* harmony default export */ const console_wxNativeConsole = (res);
;// CONCATENATED MODULE: ./src/Foundation/console/libConsole.ts

var libConsole_props = ['log', 'info', 'warn', 'error'];
var libConsole = consoleFactory(libConsole_props, method => function (...args) {
  if (!IS_DEVTOOLS && !debugEnabled()) return;
  console[method]('[system]', ...args);
});
/* harmony default export */ const console_libConsole = (libConsole);
;// CONCATENATED MODULE: ./src/Foundation/libGlobal/WebAssambly.ts

var wasm;
function getWebAssembly() {
  if (wasm) return wasm;
  if (typeof NativeGlobal !== 'undefined' && typeof NativeGlobal.WebAssembly !== 'undefined') {
    return NativeGlobal.WebAssembly;
  } else if (typeof globalThis.WebAssembly !== 'undefined') {
    return globalThis.WebAssembly;
  }
  return undefined;
}
lifeCycle.onLoad(() => {
  wasm = getWebAssembly();
});

;// CONCATENATED MODULE: ./src/Foundation/libGlobal/index.ts

var libGlobal = Object.create(null);
Object.defineProperty(libGlobal, 'WebAssembly', {
  enumerable: true,
  get: getWebAssembly
});
/* harmony default export */ const Foundation_libGlobal = (libGlobal);
;// CONCATENATED MODULE: ./src/Foundation/index.ts








var __global = __webpack_require__.g;
var Foundation = {
  env: env,
  global: __global,
  get isConfigReady() {
    return lifeCycle.getIsStarted();
  },
  get isStarted() {
    return lifeCycle.getIsStarted();
  },
  get isLoaded() {
    return lifeCycle.getIsLoaded();
  },
  ...lifeCycle,
  ...errorHandler_namespaceObject,
  wxConsole: console_wxConsole,
  wxPerfConsole: console_wxPerfConsole,
  wxNativeConsole: console_wxNativeConsole,
  libConsole: console_libConsole,
  libGlobal: Foundation_libGlobal,
  globalShare: {}
};
if (typeof __Function__ !== 'undefined') {
  ;
  Function = function () {
    if (arguments[arguments.length - 1] === 'return this') return function () {
      return __global;
    };else return new __Function__(...arguments);
  };
  Function.prototype = __Function__.prototype;
}
/* harmony default export */ const src_Foundation = (Foundation);
})();

Foundation = __webpack_exports__["default"];
/******/ })()

var wxConsole = Foundation.wxConsole;
var wxPerfConsole = Foundation.wxPerfConsole;
var wxNativeConsole = Foundation.wxNativeConsole;
var libConsole = Foundation.libConsole;
var libGlobal = Foundation.libGlobal;;
var JSContext;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ index_sub)
});

;// CONCATENATED MODULE: ./src/Utils.js
var ObjToString = Object.prototype.toString;
var ObjGetProto = Object.getPrototypeOf;
var ObjGetPropNames = Object.getOwnPropertyNames;
var ObjGetPropDesc = Object.getOwnPropertyDescriptor;
var ObjDefProp = Object.defineProperty;
var getDataType = data => ObjToString.call(data).split(' ')[1].split(']')[0];
var getAllPropertyDescs = obj => {
  var properties = [];
  var _loop = function (o) {
    var props = ObjGetPropNames(o);
    props.forEach(prop => {
      var desc = ObjGetPropDesc(o, prop);
      if (desc !== undefined) {
        desc.name = prop;
        properties.push(desc);
      }
    });
  };
  for (var o = obj; o; o = ObjGetProto(o)) {
    _loop(o);
  }
  return properties;
};
;// CONCATENATED MODULE: ./src/Context/SubJSContext.js

var subscribeCbs = {};
var jsContext;
var crossVMContext;
var subContextId;
var subscribeHandler = (token, event, result = {}) => {
  if (token === undefined || token !== jsContext) {
    return undefined;
  }
  event = event.valueOf();
  if (Array.isArray(subscribeCbs[event])) {
    if (crossVMContext) {
      setTimeout(() => {
        subscribeCbs[event].map(cb => cb(result));
      });
      return;
    }
    return subscribeCbs[event].map(cb => cb(result));
  }
  return undefined;
};
var innerContext = {
  subscribeHandler
};
Foundation.onLoadInstant(() => {
  subContextId = __webpack_require__.g.WeixinJSContextId; // #@snapshot-ignore WeixinJSContextId
});
var __init__ = (context, contextId) => {
  if (jsContext !== undefined || context === undefined) {
    return;
  }
  jsContext = context;
  jsContext.register(context, innerContext, contextId);
  crossVMContext = jsContext.crossVMContext;
};
var publish = (event, params = {}) => {
  var dataType = getDataType(params);
  if (dataType !== 'Object' && dataType !== 'Undefined') {
    throw new Error('params should be an object.');
  }
  var _event = event.valueOf();
  var _params = params || {};
  if (jsContext && typeof jsContext.subscribeHandler === 'function') {
    return jsContext.subscribeHandler(jsContext, innerContext, _event, _params);
  }
  return undefined;
};
var subscribe = (event, callback) => {
  var _jsContext, _jsContext2;
  if (!Array.isArray(subscribeCbs[event])) subscribeCbs[event] = [];
  subscribeCbs[event].push(callback);
  if ((_jsContext = jsContext) !== null && _jsContext !== void 0 && _jsContext.waitingChannel && (_jsContext2 = jsContext) !== null && _jsContext2 !== void 0 && _jsContext2.waitingChannel[subContextId]) {
    var newWaitingChannel = [];
    jsContext.waitingChannel[subContextId].forEach(ev => {
      var {
        event: e,
        params
      } = ev;
      if (e === event) {
        callback(params);
      } else {
        newWaitingChannel.push(ev);
      }
    });
    jsContext.waitingChannel[subContextId] = newWaitingChannel;
  }
};
var exportContext = {
  __init__,
  publish,
  subscribe
};
if (false) {}
/* harmony default export */ const SubJSContext = (exportContext);
;// CONCATENATED MODULE: ./src/index-sub.js

var index_sub_jsContext = SubJSContext;
Foundation.onLoad(() => {
  if (typeof WeixinJSContext === 'undefined') {
    return;
  }
  index_sub_jsContext.__init__(WeixinJSContext, __webpack_require__.g.WeixinJSContextId);
  delete index_sub_jsContext.__init__;
  delete __webpack_require__.g.WeixinJSContext;
  delete __webpack_require__.g.WeixinJSContextId;
});
/* harmony default export */ const index_sub = (index_sub_jsContext);
JSContext = __webpack_exports__["default"];
/******/ })()
;
var __webviewEngineMock__;
/******/ (() => { // webpackBootstrap
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
var mockWindow = () => {
  window = __webpack_require__.g;
  window.__rpxRecalculatingFuncs__ = [];
  window.navigator = {
    userAgent: {
      match() {
        console.warn('MiniProgram or plugin seems not compiled with proper renderer, styles may be wrong.');
        wxNativeConsole.error('[SkylineStyle] window.navigator.userAgent.match is called in jsContext, may be old version of miniprogram or plugin is injected into RenderContext. Render may not work properly.');
      }
    }
  };
  window.requestAnimationFrame = cb => {
    setTimeout(() => {
      cb(Date.now());
    }, 16);
  };
  window.CustomEvent = function (event, dict) {
    this.event = event;
    this.detail = dict ? dict.detail : undefined;
    return this;
  };
  window.fakeStyleTags = [];
  window.document = {
    head: {
      appendChild(node) {
        if (node.isStyleTag) window.fakeStyleTags.push(node);
      }
    },
    createElement(tagName) {
      var node = {
        isStyleTag: tagName === 'style',
        path: '',
        setAttribute(qualifiedName, value) {
          if (qualifiedName === 'wxss:path') node.path = value;
        },
        styleSheet: {}
      };
      if (!node.isStyleTag) {
        wxNativeConsole.error(`[SkylineStyle] createElement with tagName="${tagName}" is invalid, expected "style"`);
      }
      return node;
    }
  };
  var allListeners = {};
  window.dispatchEvent = window.document.dispatchEvent = function (c) {
    if (allListeners[c.event] === undefined) return;
    allListeners[c.event].forEach(cb => {
      cb({
        detail: c.detail
      });
    });
  };
  window.addEventListener = window.document.addEventListener = function (event, cb) {
    if (allListeners[event] === undefined) allListeners[event] = [];
    allListeners[event].push(cb);
  };
  window.removeEventListener = window.document.removeEventListener = function (event, cb) {
    if (allListeners[event] === undefined) return;
    var index = allListeners[event].indexOf(cb);
    if (index !== -1) allListeners[event].splice(index, 1);
  };
};
__wxConfig.onReady(() => {
  window.devicePixelRatio = __wxConfig.devicePixelRatio;
  window.screen = {
    width: __wxConfig.screenWidth,
    height: __wxConfig.screenHeight,
    orientation: {
      type: 'portrait'
    }
  };
});
mockWindow();
__webviewEngineMock__ = __webpack_exports__;
/******/ })()
;
var Protect;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EnvPreloadType: () => (/* binding */ EnvPreloadType),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   updateConfig: () => (/* binding */ updateConfig)
/* harmony export */ });
var EnvPreloadType = {
  None: 0,
  BeforeLaunch: 1,
  AfterLaunch: 2
};
var updateConfig = () => {
  if (WXConfig !== __wxConfig && typeof WXConfig !== 'undefined') {
    Object.assign(WXConfig, __wxConfig);
  }
};
var WXConfig = /* #__PURE__ */(() => {
  __wxConfig.onReady(updateConfig);
  return __wxConfig;
})();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WXConfig);

/***/ }),

/***/ 348:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   reportDeprecatedAPI: () => (/* binding */ reportDeprecatedAPI)
/* harmony export */ });
var reportDeprecatedAPI = name => {
  Reporter.reportKeyValue({
    key: 'DeprecatedAPI',
    value: name
  });
};


/***/ }),

/***/ 217:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var {
  reportDeprecatedAPI
} = __webpack_require__(348);
var {
  default: WXConfig
} = __webpack_require__(940);
function hijackWasm() {
  if (typeof WebAssembly !== 'undefined') {
    var FIELDS_NEED_HOOK = ['compile', 'compileStreaming', 'instantiate', 'instantiateStreaming', 'validate', 'Module'];
    FIELDS_NEED_HOOK.forEach(fieldName => {
      if (typeof WebAssembly[fieldName] === 'undefined') return;
      var ori = WebAssembly[fieldName];
      Object.defineProperty(WebAssembly, fieldName, {
        get: () => {
          reportDeprecatedAPI('globalWa');
          return ori;
        },
        set: value => {
          Object.defineProperty(WebAssembly, fieldName, {
            value,
            writable: true,
            configurable: true,
            enumerable: true
          });
        },
        configurable: true,
        enumerable: true
      });
    });
  }
}
function hijackFunction(global = globalThis) {
  if (typeof globalThis.Function !== 'function' || false) return;
  function FakeFunction() {
    if (arguments.length > 0) {
      if (arguments[arguments.length - 1] === 'return this') {
        return function () {
          return global;
        };
      }
    }
  }
  FakeFunction.prototype = globalThis.Function.prototype;
  FakeFunction.prototype.constructor = FakeFunction;
  globalThis.Function = FakeFunction;
}
function hijackEval() {
  if (typeof eval === 'undefined') return;
  if (WXConfig.platform === 'ios' && __webpack_require__.g.__isAppServiceRemoteDebugMode__) return;
  if (WXConfig.debug) return;
  globalThis.eval = undefined;
}
function hijackTimer() {
  if (typeof setTimeout === 'undefined') return;
  var _setTimeout = setTimeout;
  globalThis.setTimeout = function (func, timeout = 0) {
    if (typeof func !== 'function') {
      throw new TypeError(`setTimeout expects a function as first argument but got ${typeof func}.`);
    }
    var _fn = __errorTracer__.surroundThirdByTryCatch(func, 'at setTimeout callback function');
    var restArgs = [].slice.call(arguments, 2);
    return _setTimeout(() => {
      _fn.apply(globalThis, restArgs);
    }, timeout);
  };
  var _setInterval = setInterval;
  globalThis.setInterval = function (func, interval) {
    if (typeof func !== 'function') {
      throw new TypeError(`setInterval expects a function as first argument but got ${typeof func}.`);
    }
    var _fn = __errorTracer__.surroundThirdByTryCatch(func, 'at setInterval callback function');
    var restArgs = [].slice.call(arguments, 2);
    return _setInterval(() => {
      _fn.apply(globalThis, restArgs);
    }, interval);
  };
}
function hijack(hookTimer = true, global = globalThis) {
  hijackFunction(global);
  hijackEval();
  if (hookTimer) hijackTimer();
  hijackWasm();
}
module.exports = {
  hijack,
  hijackFunction
};

/***/ }),

/***/ 323:
/***/ (() => {

// 这个问题只在 iOS 里面处理
if (typeof navigator === 'undefined') {
  /* eslint-disable no-new-func */
  // 因为包含 esnext 语法，真机解析可能出错，所以包在 Function 里面
  try {
    new Function(
      'var GeneratorFunctionProto = Object.getPrototypeOf(function* () {});' +
        'var FakeGeneratorFunction = function () {};' +
        'FakeGeneratorFunction.prototype = GeneratorFunctionProto;' +
        'Object.defineProperty(GeneratorFunctionProto, "constructor", { value: FakeGeneratorFunction });',
    )()
  } catch (e) {
    /* empty */
  }
  try {
    new Function(
      'var AsyncFunctionProto = Object.getPrototypeOf(async function () {});' +
        'var FakeAsyncFunction = function () {};' +
        'FakeAsyncFunction.prototype = AsyncFunctionProto;' +
        'Object.defineProperty(AsyncFunctionProto, "constructor", { value: FakeAsyncFunction });',
    )()
  } catch (e) {
    /* empty */
  }
  try {
    new Function(
      'var AsyncGeneratorFunctionProto = Object.getPrototypeOf(async function* () {});' +
        'var FakeAsyncGeneratorFunction = function () {};' +
        'FakeAsyncGeneratorFunction.prototype = AsyncGeneratorFunctionProto;' +
        'Object.defineProperty(AsyncGeneratorFunctionProto, "constructor", { value: FakeAsyncGeneratorFunction });',
    )()
  } catch (e) {
    /* empty */
  }
}


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  bridgeGlobalInstanceOf: () => (/* reexport */ bridgeGlobalInstanceOf),
  deepFreezeGlobalObjs: () => (/* reexport */ deepFreezeGlobalObjs),
  deepFreezeObj: () => (/* reexport */ deepFreezeObj),
  deepFreezeObjProperty: () => (/* reexport */ deepFreezeObjProperty),
  doNotWriteGlobalObjs: () => (/* reexport */ doNotWriteGlobalObjs),
  doNotWriteObj: () => (/* reexport */ doNotWriteObj),
  doNotWriteObjProperty: () => (/* reexport */ doNotWriteObjProperty),
  globalEsHiddenObjs: () => (/* reexport */ GlobalEsHiddenObjs),
  globalEsObjs: () => (/* reexport */ GlobalEsObjs),
  hijack: () => (/* reexport */ protect_Hijack.hijack),
  hijackFunction: () => (/* reexport */ protect_Hijack.hijackFunction),
  overwriteSetPrototypeOf: () => (/* reexport */ overwriteSetPrototypeOf)
});

// EXTERNAL MODULE: ./src/protect/Hijack.es6
var Hijack = __webpack_require__(323);
;// CONCATENATED MODULE: ./src/protect/GlobalObjects.js
var RealFunction = globalThis.Function;
var GlobalEsHiddenObjs = [() => Object.getPrototypeOf(Uint8Array.prototype).constructor, () => new RealFunction('return Object.getPrototypeOf((function* () {})()).constructor')(), () => new RealFunction('return Object.getPrototypeOf(function* () {}).constructor')(), () => new RealFunction('return Object.getPrototypeOf(async function () {}).constructor')(), () => new RealFunction('return Object.getPrototypeOf(async function* () {}).constructor')()].map(func => {
  try {
    return func();
  } catch (e) {}
  return undefined;
}).filter(Boolean);
var GlobalEsObjs = ['AggregateError', 'Array', 'ArrayBuffer', 'Atomics', 'BigInt', 'BigInt64Array', 'BigUint64Array', 'Boolean', 'DataView', 'Date', 'Error', 'EvalError', 'FinalizationRegistry', 'Float32Array', 'Float64Array', 'Function', 'globalThis', 'Infinity', 'Int16Array', 'Int32Array', 'Int8Array', 'Intl', 'JSON', 'Map', 'Math', 'NaN', 'Number', 'Object', 'Promise', 'Proxy', 'RangeError', 'ReferenceError', 'Reflect', 'RegExp', 'Set', 'SharedArrayBuffer', 'String', 'Symbol', 'SyntaxError', 'TypeError', 'URIError', 'Uint16Array', 'Uint32Array', 'Uint8Array', 'Uint8ClampedArray', 'WeakMap', 'WeakSet', 'WebAssembly', 'decodeURI', 'decodeURIComponent', 'encodeURI', 'encodeURIComponent', 'escape', 'eval', 'isFinite', 'isNaN', 'null', 'parseFloat', 'parseInt', 'undefined', 'unescape', 'uneval'];
var GlobalWAObjs = ['getApp', 'getCurrentPages', 'define', 'require', 'Reporter', 'Protect', 'requirePlugin', 'definePlugin'];
var global = globalThis;
// EXTERNAL MODULE: ./src/base/WXConfig.ts
var base_WXConfig = __webpack_require__(940);
;// CONCATENATED MODULE: ./src/base/env.ts

var PLATFORM = /* #__PURE__ */(() => base_WXConfig["default"].platform)();
var IS_DEVTOOLS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'devtools')()));
var IS_ANDROID = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'android')()));
var IS_IOS = /* #__PURE__ */(() => PLATFORM === 'ios')();
var IS_WINDOWS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'windows')()));
var IS_MAC = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'mac')()));
var IS_MINA = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'mina')()));
var IS_PC = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => IS_WINDOWS || IS_MAC)()));
function debugEnabled() {
  if (!WXConfig || !('debug' in WXConfig) || typeof WXConfig.debug === 'undefined') return undefined;
  return !!WXConfig.debug;
}
var ENV = /* #__PURE__ */(/* unused pure expression or super */ null && ((_WXConfig$host => (_WXConfig$host = WXConfig.host) === null || _WXConfig$host === void 0 ? void 0 : _WXConfig$host.env)()));
var IS_HOST_SDK = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'SDK')()));
var IS_HOST_SAAA_SDK = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'SAAASDK')()));
var IS_HOST_WMPF = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'WMPF')()));
var IS_HOST_WECHAT = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'WeChat')()));
var IS_USE_NATIVE_MAP = /* #__PURE__ */(/* unused pure expression or super */ null && ((_WXConfig$host2 => ((_WXConfig$host2 = WXConfig.host) === null || _WXConfig$host2 === void 0 ? void 0 : _WXConfig$host2.forceUseNativeMap) || false)()));
var WK_RENDERER_H5 = /* #__PURE__ */(/* unused pure expression or super */ null && (function isRenderH5() {
  if (typeof WORKER_RUNTIME !== 'undefined' && WORKER_RUNTIME) {
    if (typeof self !== 'undefined') {
      return self && self.__wkrenderer_h5;
    }
  }
  return typeof window === 'object' && window && window.__wkrenderer_h5;
}()));
function isWkGameNativeRender() {
  return typeof window === 'object' && window && window.__wkrenderer_h5 && (window.__featBit & 0x2) > 0;
}
function isRemoteDebugEnabled() {
  return __webpack_require__.g.__isAppServiceRemoteDebugMode__ || typeof __initHelper !== 'undefined' && __initHelper === 1;
}
function isIn3rdApp() {
  var host = WXConfig.host;
  return host && host.env !== 'WeChat' && host.env !== 'WMPF';
}
function isReleaseBuild() {
  var release = true;
  typeof wxRunOnDebug !== 'undefined' && wxRunOnDebug(() => {
    release = false;
  });
  return release;
}
function isGame() {
  return typeof IS_WAGAME === 'boolean' ? IS_WAGAME : WXConfig.appType === 4;
}
function isAppServiceOrWebView() {
  var _Foundation;
  return  true ? true : 0;
}
var isAppService = /* #__PURE__ */(/* unused pure expression or super */ null && ((() =>  true && true)()));
function isNormalApp() {
  return WXConfig.appType === 0;
}
var thirdPartyAppType = (/* unused pure expression or super */ null && ([0, 1, 2, 3, 5, 6, 8, 9, 10, 11, 12, 13]));
function isThirdPartyApp() {
  return thirdPartyAppType.includes(WXConfig.appType);
}
function isFakeNativeApp() {
  return WXConfig.appType === 7;
}
function isPhysicalStoresApp() {
  return WXConfig.appType === 2;
}
function isWXStoreApp() {
  return WXConfig.appType === 10;
}
;// CONCATENATED MODULE: ./src/protect/errorStackParser.js

var CHROME_STACK_REGEXP = /^\s*at .*(\S+:\d+|\(native\))/m;
var SAFARI_NATIVE_CODE_REGEXP = /^(eval@)?(\[native code\])?$/;
function parseErrorStack(error, count = Infinity) {
  if (typeof error.stack !== 'string') throw new Error('Cannot parse given Error object');
  var errorStack = error.stack;
  if (IS_IOS) {
    return parseJSCErrorStack(errorStack, count);
  } else {
    return parseV8ErrorStack(errorStack, count);
  }
}
function extractLocation(urlLike) {
  var match = /(?::(\d+))?(?::(\d+))?$/.exec(urlLike);
  if (!match) {
    return {
      URI: urlLike
    };
  }
  return {
    URI: urlLike.substring(0, urlLike.length - match[0].length),
    line: match[1],
    column: match[2]
  };
}
function parseV8ErrorStack(errorStack, count) {
  var filtered = [];
  var errorStackLines = errorStack.split('\n');
  for (var i = 0, c = 0; i < errorStackLines.length && c < count; ++i) {
    var line = errorStackLines[i];
    if (CHROME_STACK_REGEXP.test(line)) {
      filtered.push(line);
      ++c;
    }
  }
  return filtered.map(line => {
    if (line.indexOf('(eval ') > -1) {
      line = line.replace(/eval code/g, 'eval').replace(/(\(eval at [^()]*)|(\),.*$)/g, '');
    }
    var sanitizedLine = line.replace(/^\s+/, '').replace(/\(eval code/g, '(');
    var location = sanitizedLine.match(/ (\((.+):(\d+):(\d+)\)$)/);
    sanitizedLine = location ? sanitizedLine.replace(location[0], '') : sanitizedLine;
    var tokens = sanitizedLine.split(/\s+/).slice(1);
    var locationParts = extractLocation(location ? location[1] : tokens.pop());
    var functionName = tokens.join(' ') || undefined;
    var fileName = ['eval', '<anonymous>'].indexOf(locationParts[0]) > -1 ? undefined : locationParts[0];
    return {
      functionName,
      fileName,
      lineNumber: locationParts[1],
      columnNumber: locationParts[2],
      source: line
    };
  });
}
function parseJSCErrorStack(errorStack, count) {
  var result = [];
  var errorStackLines = errorStack.split('\n');
  for (var i = 0, c = 0; i < errorStackLines.length && c < count; ++i) {
    var line = errorStackLines[i];
    if (SAFARI_NATIVE_CODE_REGEXP.test(line)) continue;
    ++c;
    var indexOfAt = line.indexOf('@');
    if (indexOfAt === -1) {
      var locationParts = extractLocation(line);
      result.push({
        fileName: locationParts.URI,
        lineNumber: locationParts.line,
        columnNumber: locationParts.column,
        source: line
      });
    } else {
      var functionName = line.substring(0, indexOfAt);
      var _locationParts = extractLocation(line.substr(indexOfAt + 1));
      result.push({
        functionName,
        fileName: _locationParts.URI,
        lineNumber: _locationParts.line,
        columnNumber: _locationParts.column,
        source: line
      });
    }
  }
  return result;
}
;// CONCATENATED MODULE: ./src/protect/util.js

var freeze = Object.freeze;
var setPrototypeOf = Object.setPrototypeOf;
var defineProperty = Object.defineProperty;
var getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var getOwnPropertyNames = Object.getOwnPropertyNames;
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var getPrototypeOf = Object.getPrototypeOf;
var preventExtensions = Object.preventExtensions;
function setObjectInPlace(obj, property, value) {
  try {
    if (property === '__proto__') {
      setPrototypeOf(obj, value);
    } else {
      defineProperty(obj, property, {
        value,
        writable: true,
        enumerable: true,
        configurable: true
      });
    }
  } catch (e) {}
}
var SAME_CONTEXT_FILES = [[s => !/(WAServiceMainContext|WAGame)\.js/.test(s)]];
function isSameContext(fileName1, fileName2) {
  return SAME_CONTEXT_FILES.some(fileRegexps => fileRegexps.some(exp => exp(fileName1)) && fileRegexps.some(exp => exp(fileName2)));
}
var isCallFromCurrentContextCost = 0;
var getIsCallFromCurrentContextCost = () => isCallFromCurrentContextCost;
function isCallFromCurrentContext() {
  var start = Date.now();
  var stackFrames = parseErrorStack(new Error(), 3);
  var currentFrame = stackFrames[1];
  var callerFrame = stackFrames[2];
  var result = !(currentFrame.fileName && callerFrame.fileName && callerFrame.fileName !== currentFrame.fileName && !isSameContext(callerFrame.fileName, currentFrame.fileName));
  isCallFromCurrentContextCost += Date.now() - start;
  return result;
}
function freezeObjPrototype(obj, allowSelfModify = false) {
  if (typeof obj !== 'function' && (typeof obj !== 'object' || obj === null)) return;
  var descriptor = getOwnPropertyDescriptor(obj, '__proto__');
  if (descriptor && !descriptor.configurable) return;
  if (!descriptor && !Object.isExtensible(obj)) return;
  defineProperty(obj, '__proto__', {
    get() {
      return getPrototypeOf(this);
    },
    set(newVal) {
      if (this !== obj) {
        if (typeof this !== 'function' && (typeof this !== 'object' || obj === null)) return;
        setPrototypeOf(this, newVal);
        return;
      }
      if (!allowSelfModify) return;
      if (!isCallFromCurrentContext()) return;
      setPrototypeOf(obj, newVal);
    },
    enumerable: false,
    configurable: false
  });
}
var DoNotWriteDescriptorMap = new Map();
var updateDoNotWriteDescriptor = (obj, property, descriptor) => {
  if (!DoNotWriteDescriptorMap.has(obj)) DoNotWriteDescriptorMap.set(obj, new Map());
  var objMap = DoNotWriteDescriptorMap.get(obj);
  if (objMap.has(property)) {
    Object.assign(objMap.get(property), descriptor);
  } else {
    objMap.set(property, descriptor);
  }
};
function freezeObjProperty(obj, propName, allowSelfModify = false) {
  if (typeof obj !== 'function' && (typeof obj !== 'object' || obj === null)) return false;
  try {
    var descriptor = getOwnPropertyDescriptor(obj, propName);
    if (!descriptor) return false;
    if (descriptor.configurable) {
      defineProperty(obj, propName, {
        get: descriptor.get || (() => descriptor.value),
        set(newValue) {
          if (this !== obj) {
            if (typeof this !== 'function' && typeof this !== 'object') return;
            setObjectInPlace(this, propName, newValue);
            return;
          }
          if (!allowSelfModify) return;
          if (!isCallFromCurrentContext()) return;
          if (descriptor.set) {
            descriptor.set.call(this, newValue);
          } else if (descriptor.writable) {
            descriptor.value = newValue;
          }
        },
        enumerable: descriptor.enumerable,
        configurable: false
      });
      if (allowSelfModify) updateDoNotWriteDescriptor(obj, propName, descriptor);
    }
    return !descriptor.get && (typeof descriptor.value === 'function' || typeof descriptor.value === 'object' && descriptor.value !== null);
  } catch (e) {
    wxConsole.error(propName, allowSelfModify, e.message);
    throw e;
  }
}
var FROZEN_SET = new WeakSet();
function setFrozen(obj) {
  FROZEN_SET.add(obj);
}
function isFrozen(obj) {
  return FROZEN_SET.has(obj);
}
function deepFreezeObjProperty(obj, property, preventExtension) {
  if (freezeObjProperty(obj, property)) {
    deepFreezeObj(obj[property], preventExtension);
  }
}
function deepFreezeObj(obj, preventExtension) {
  if (!obj || isFrozen(obj) || typeof obj !== 'function' && typeof obj !== 'object' || obj === globalThis) return;
  if (obj === Error) {
    if (preventExtension) {
      var deepFreezeRecursive = obj => {
        if (!obj || isFrozen(obj) || typeof obj !== 'function' && typeof obj !== 'object' || obj === globalThis) return;
        setFrozen(obj);
        freeze(obj);
        var allProps = getOwnPropertyNames(obj);
        var allSymbols = getOwnPropertySymbols(obj);
        for (var i = 0; i < allProps.length; ++i) {
          deepFreezeRecursive(obj[allProps[i]]);
        }
        for (var _i = 0; _i < allSymbols.length; ++_i) {
          deepFreezeRecursive(obj[allSymbols[_i]]);
        }
      };
      deepFreezeRecursive(Error);
    }
    return;
  }
  setFrozen(obj);
  var allProps = getOwnPropertyNames(obj);
  var allSymbols = getOwnPropertySymbols(obj);
  for (var i = 0; i < allProps.length; ++i) {
    deepFreezeObjProperty(obj, allProps[i], preventExtension);
  }
  for (var _i2 = 0; _i2 < allSymbols.length; ++_i2) {
    deepFreezeObjProperty(obj, allSymbols[_i2], preventExtension);
  }
  if (preventExtension) {
    preventExtensions(obj);
  } else {
    freezeObjPrototype(obj, false);
  }
}
function doNotWriteObjProperty(obj, property) {
  if (freezeObjProperty(obj, property, true)) {
    doNotWriteObj(obj[property]);
  }
}
var DO_NOT_WRITE_SET = new WeakSet();
function setDoNotWrite(obj) {
  DO_NOT_WRITE_SET.add(obj);
}
function isDoNotWrite(obj) {
  return DO_NOT_WRITE_SET.has(obj);
}
function doNotWriteObj(obj) {
  if (!obj || isDoNotWrite(obj) || typeof obj !== 'function' && typeof obj !== 'object' || obj === globalThis) return;
  setDoNotWrite(obj);
  var allProps = getOwnPropertyNames(obj);
  var allSymbols = getOwnPropertySymbols(obj);
  for (var i = 0; i < allProps.length; ++i) {
    doNotWriteObjProperty(obj, allProps[i]);
  }
  for (var _i3 = 0; _i3 < allSymbols.length; ++_i3) {
    doNotWriteObjProperty(obj, allSymbols[_i3]);
  }
  freezeObjPrototype(obj, true);
}
;// CONCATENATED MODULE: ./src/protect/globalRO.js


var globalRO_hasOwnProperty = Object.prototype.hasOwnProperty;
var globalRO_defineProperty = Object.defineProperty;
var defineProperties = Object.defineProperties;
var globalRO_getOwnPropertyNames = Object.getOwnPropertyNames;
var globalRO_getOwnPropertySymbols = Object.getOwnPropertySymbols;
var globalRO_getOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;
var hasOverwriteSetPrototypeOf = false;
var overwriteSetPrototypeOf = function () {
  if (hasOverwriteSetPrototypeOf) return;
  hasOverwriteSetPrototypeOf = true;
  globalRO_defineProperty(global.Object, 'setPrototypeOf', {
    value(obj, proto) {
      obj.__proto__ = proto;
      return obj;
    },
    configurable: true
  });
  globalRO_defineProperty(global.Object, 'defineProperty', {
    value(obj, property, descriptor) {
      if (!isDoNotWrite(obj)) return globalRO_defineProperty(obj, property, descriptor);
      if (!isCallFromCurrentContext()) return descriptor;
      var currentDescriptor = globalRO_getOwnPropertyDescriptor(obj, property);
      if (!currentDescriptor || currentDescriptor.configurable) {
        var result = globalRO_defineProperty(obj, property, descriptor);
        doNotWriteObjProperty(obj, property);
        return result;
      } else {
        updateDoNotWriteDescriptor(obj, property, descriptor);
        return descriptor;
      }
    },
    configurable: true
  });
  globalRO_defineProperty(global.Object, 'defineProperties', {
    value(obj, props) {
      if (!isDoNotWrite(obj)) return defineProperties(obj, props);
      if (!isCallFromCurrentContext()) return props;
      var propertyHandler = property => {
        var currentDescriptor = globalRO_getOwnPropertyDescriptor(obj, property);
        if (!currentDescriptor || currentDescriptor.configurable) {
          var result = globalRO_defineProperty(obj, property, props[property]);
          doNotWriteObjProperty(obj, property);
          return result;
        } else {
          updateDoNotWriteDescriptor(obj, property, props[property]);
          return props[property];
        }
      };
      globalRO_getOwnPropertyNames(props).forEach(propertyHandler);
      globalRO_getOwnPropertySymbols(props).forEach(propertyHandler);
      return props;
    },
    configurable: true
  });
};
var doNotWriteGlobalObjs = function (additionalGlobals = []) {
  try {
    var allGlobals = [...GlobalEsObjs, ...GlobalWAObjs, ...GlobalEsHiddenObjs, ...additionalGlobals];
    var start = Date.now();
    for (var i = 0; i < allGlobals.length; ++i) {
      var globalItem = allGlobals[i];
      var globalItemType = typeof globalItem;
      if (globalItemType === 'string') {
        if (globalRO_hasOwnProperty.call(global, globalItem)) {
          doNotWriteObjProperty(global, globalItem);
        } else {}
      } else if (globalItemType === 'function' || globalItemType === 'object') {
        doNotWriteObj(globalItem);
      }
    }
    wxConsole.log(`doNotWriteObj cost: ${Date.now() - start} ms.`);
  } catch (e) {
    wxConsole.error('doNotWriteObj got error', e);
  }
};
var deepFreezeGlobalObjs = function (additionalGlobals = [], preventExtension = false) {
  try {
    var allGlobals = [...GlobalEsObjs, ...GlobalWAObjs, ...GlobalEsHiddenObjs, ...additionalGlobals];
    var start = Date.now();
    for (var i = 0; i < allGlobals.length; ++i) {
      var globalItem = allGlobals[i];
      var globalItemType = typeof globalItem;
      if (globalItemType === 'string') {
        if (globalRO_hasOwnProperty.call(global, globalItem)) {
          deepFreezeObjProperty(global, globalItem, preventExtension);
        } else {}
      } else if (globalItemType === 'function' || globalItemType === 'object') {
        deepFreezeObj(globalItem, preventExtension);
      }
    }
    wxConsole.log(`deepFreeze cost: ${Date.now() - start} ms.`);
  } catch (e) {
    wxConsole.error('deepFreeze got error', e);
  }
};
// EXTERNAL MODULE: ./src/protect/Hijack.js
var protect_Hijack = __webpack_require__(217);
;// CONCATENATED MODULE: ./src/protect/globalHasInstance.js
var globalHasInstance_isPrototypeOf = Object.prototype.isPrototypeOf;
var globalHasInstance_defineProperty = Object.defineProperty;
var globalHasInstance_hasOwnProperty = Object.prototype.hasOwnProperty;
var SymbolHasInstance = Symbol.hasInstance;
var isInstanceOf = (obj, constructor) => globalHasInstance_isPrototypeOf.call(constructor.prototype, obj);
var originalHasInstance = function (obj) {
  if (typeof this !== 'function' || !isObject(obj)) return false;
  return isInstanceOf(obj, this);
};
var isObject = obj => typeof obj === 'object' ? obj !== null : typeof obj === 'function';
function bridgeGlobalInstanceOf(currentGlobals, remoteGlobals, propertyNames = {}) {
  var _loop = function (i) {
      var currentGlobal = currentGlobals[i];
      var remoteGlobal = remoteGlobals[i];
      if (!currentGlobal || !remoteGlobal) return 0;
      if (typeof currentGlobal !== 'function') return 0;
      var currentOriginalHasInstance = globalHasInstance_hasOwnProperty.call(currentGlobal, SymbolHasInstance) ? currentGlobal[SymbolHasInstance] : originalHasInstance;
      var remoteOriginalHasInstance = globalHasInstance_hasOwnProperty.call(remoteGlobal, SymbolHasInstance) ? remoteGlobal[SymbolHasInstance] : originalHasInstance;
      globalHasInstance_defineProperty(currentGlobal, SymbolHasInstance, {
        value(obj) {
          return currentOriginalHasInstance.call(this, obj) || remoteOriginalHasInstance.call(remoteGlobal, obj);
        },
        writable: true,
        enumerable: false,
        configurable: true
      });
      globalHasInstance_defineProperty(remoteGlobal, SymbolHasInstance, {
        value(obj) {
          if (propertyNames[i] !== undefined && propertyNames[i] === 'Object' && (obj === null || obj === void 0 ? void 0 : obj._compressed) !== undefined && (obj === null || obj === void 0 ? void 0 : obj._data) !== undefined && (obj === null || obj === void 0 ? void 0 : obj.height) !== undefined && (obj === null || obj === void 0 ? void 0 : obj.width) !== undefined) {
            return remoteOriginalHasInstance.call(this, obj);
          }
          return remoteOriginalHasInstance.call(this, obj) || currentOriginalHasInstance.call(currentGlobal, obj);
        },
        writable: true,
        enumerable: false,
        configurable: true
      });
    },
    _ret;
  for (var i = 0; i < currentGlobals.length; ++i) {
    _ret = _loop(i);
    if (_ret === 0) continue;
  }
}
;// CONCATENATED MODULE: ./src/protect/index.js






})();

Protect = __webpack_exports__;
/******/ })()
;
var __errorTracer__;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   callMiniProgramOrPluginFunction: () => (/* binding */ callMiniProgramOrPluginFunction),
/* harmony export */   callSystemFunction: () => (/* binding */ callSystemFunction),
/* harmony export */   callThirdPartyFunction: () => (/* binding */ callThirdPartyFunction),
/* harmony export */   convertStack: () => (/* binding */ convertStack),
/* harmony export */   endSystemFunctionCall: () => (/* binding */ endSystemFunctionCall),
/* harmony export */   findCurrentSource: () => (/* binding */ findCurrentSource),
/* harmony export */   startSystemFunctionCall: () => (/* binding */ startSystemFunctionCall),
/* harmony export */   surroundThirdByTryCatch: () => (/* binding */ surroundThirdByTryCatch),
/* harmony export */   wrapMiniProgramOrPluginFunction: () => (/* binding */ wrapMiniProgramOrPluginFunction),
/* harmony export */   wrapSystemFunction: () => (/* binding */ wrapSystemFunction),
/* harmony export */   wrapThirdPartyFunction: () => (/* binding */ wrapThirdPartyFunction),
/* harmony export */   wrapperStack: () => (/* binding */ wrapperStack)
/* harmony export */ });
var STACK_LINE_REGEX = /[ (@]*https?:\/\/([^/]*)\/+(.*?):(\d+):(\d+)/;
var wrapperStack = [];
function convertStack(error) {
  if (!error || error.__wxOriginalStack__) {
    return false;
  }
  var originalStack = error.stack;
  if (typeof originalStack === 'undefined') {
    return false;
  }
  var convertedStack = originalStack;
  var stackPos = wrapperStack.length - 1;
  var pos = 0;
  while (pos >= 0 && stackPos >= 0) {
    var nextPos = convertedStack.length;
    var nextLen = 0;
    for (var name in stackPositions) {
      if (!stackPositions[name]) continue;
      var nextPosIndex = convertedStack.indexOf(stackPositions[name], pos);
      if (nextPosIndex < 0 || nextPos <= nextPosIndex) continue;
      nextPos = nextPosIndex;
      nextLen = stackPositions[name].length;
    }
    if (nextPos >= convertedStack.length) break;
    var newLine = `at <${wrapperStack[stackPos--].description}>`;
    convertedStack = convertedStack.slice(0, nextPos) + newLine + convertedStack.slice(nextPos + nextLen);
    pos = nextPos + newLine.length;
  }
  Object.defineProperties(error, {
    __wxOriginalStack__: {
      value: originalStack,
      writable: true,
      configurable: true
    },
    stack: {
      value: convertedStack,
      writable: true,
      enumerable: true,
      configurable: true
    }
  });
  return true;
}
var stackPositions = {
  wrapSystemFunction: null,
  wrapMiniProgramOrPluginFunction: null
};
function detectStackPosition(name) {
  var stack = new Error().stack || '';
  var lines = stack.match(/.+/gm);
  var stackLine = '';
  var atCount = 0;
  if (lines) {
    lines.forEach(line => {
      if (STACK_LINE_REGEX.test(line)) {
        atCount += 1;
        if (atCount === 2) {
          var atMatch = line.match(/^(\s*)at /);
          var atMatchLen = atMatch ? atMatch[1].length : 0;
          stackLine = line.slice(atMatchLen);
          return false;
        }
      }
      return true;
    });
  }
  stackPositions[name] = stackLine;
}
function findCurrentSource() {
  var source = '';
  for (var i = wrapperStack.length - 1; i >= 0; i--) {
    if (wrapperStack[i].pluginAppId) {
      source = wrapperStack[i].pluginAppId;
    }
  }
  return source;
}
var startSystemFunctionCall = description => {
  if (stackPositions.wrapSystemFunction === null) {
    stackPositions.wrapSystemFunction = '';
    wrapSystemFunction('', '', detectStackPosition)('wrapSystemFunction');
  }
  wrapperStack.push({
    description
  });
};
var endSystemFunctionCall = () => {
  wrapperStack.pop();
};
function callSystemFunction(errorType, description, func, caller, args, throwOut = false) {
  if (stackPositions.wrapSystemFunction === null) {
    stackPositions.wrapSystemFunction = '';
    wrapSystemFunction('', '', detectStackPosition)('wrapSystemFunction');
  }
  wrapperStack.push({
    description
  });
  var ret;
  try {
    ret = func.apply(caller, args);
  } catch (e) {
    if (convertStack(e)) {
      if (e.type === 'AppServiceSdkKnownError') {
        wrapperStack.pop();
        throw e;
      } else if (e.type === 'ThirdScriptError') {
        var source = findCurrentSource();
        Reporter.thirdErrorReport({
          error: e,
          source,
          triggerErrorCallback: !throwOut
        });
      } else {
        Reporter.errorReport({
          key: errorType,
          error: e,
          triggerErrorCallback: !throwOut
        });
      }
    }
    if (throwOut) {
      wrapperStack.pop();
      throw e;
    }
  }
  wrapperStack.pop();
  return ret;
}
function wrapSystemFunction(errorType, description, func, throwOut = false) {
  return function callSystemFn(...args) {
    return callSystemFunction(errorType, description, func, this, args, throwOut);
  };
}
function callMiniProgramOrPluginFunction(pluginAppId, description, func, caller, args, throwOut = false) {
  if (stackPositions.wrapMiniProgramOrPluginFunction === null) {
    stackPositions.wrapMiniProgramOrPluginFunction = '';
    wrapMiniProgramOrPluginFunction('', '', detectStackPosition)('wrapMiniProgramOrPluginFunction');
  }
  wrapperStack.push({
    description,
    pluginAppId
  });
  var ret;
  try {
    ret = func.apply(caller, args);
  } catch (e) {
    if (convertStack(e)) {
      Reporter.thirdErrorReport({
        error: e,
        source: pluginAppId || '',
        triggerErrorCallback: !throwOut
      });
    }
    if (throwOut) {
      wrapperStack.pop();
      throw e;
    }
  }
  wrapperStack.pop();
  return ret;
}
function callThirdPartyFunction(description, func, caller, args, throwOut = false) {
  return callMiniProgramOrPluginFunction(findCurrentSource(), description, func, caller, args, throwOut);
}
function wrapMiniProgramOrPluginFunction(pluginAppId, description, func, throwOut = false) {
  return function callFn(...args) {
    return callMiniProgramOrPluginFunction(pluginAppId, description, func, this, args, throwOut);
  };
}
function wrapThirdPartyFunction(description, func, throwOut = false) {
  return function callFn(...args) {
    return callMiniProgramOrPluginFunction(findCurrentSource(), description, func, this, args, throwOut);
  };
}
function surroundThirdByTryCatch(fn, extend) {
  var descriptionMatch = (extend || '').match(/^\s*(?:at )?([\s\S]*)$/);
  var description = descriptionMatch ? descriptionMatch[1] : '';
  var fnNonNull = fn || function () {};
  return function callFn(...args) {
    return callMiniProgramOrPluginFunction(findCurrentSource(), description, fnNonNull, fnNonNull, args, false);
  };
}
__errorTracer__ = __webpack_exports__;
/******/ })()
;
var __subContextEngine__;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 610:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   H: () => (/* binding */ CONTEXT_NAME_PREFIX),
/* harmony export */   Q: () => (/* binding */ CONTEXT_NAME)
/* harmony export */ });
var CONTEXT_NAME = {
  APP: 'app',
  APP_RENDER: 'app_sub_render',
  APP_XRFRAME_RENDER: 'app_xrframe_render',
  APP_SCL: 'app_sub_scl',
  GAME: 'game',
  GAME_OPEN_DATA: 'gameOpenData'
};
var CONTEXT_NAME_PREFIX = {
  GAME_PLUGIN_PRELOAD: 'gamePlugin_preload_',
  GAME_PLUGIN: 'gamePlugin_',
  APP_CARDS: 'CARD_'
};

/***/ }),

/***/ 277:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   hX: () => (/* binding */ isDevtools)
/* harmony export */ });
/* unused harmony exports currentGlobal, deepFreeze, isIsolateContext, freezeGlobal, callInitFunc, handleThirdError, surroundByTryCatchFactory, executeOnlyOnce, isIOS, isAndroid, accessSync, readFileSync, isValidGameIndependentSubpackagePath, isValidGameIndependentSubpackageScene, isAsyncContext */
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(284);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);

var currentGlobal = (/* unused pure expression or super */ null && (globalThis));
function deepFreeze(o) {
  if (o === currentGlobal && isDevtools()) {
    return;
  }
  Object.freeze(o);
  Object.getOwnPropertyNames(o).forEach(prop => {
    var old;
    try {
      old = o[prop];
    } catch (e) {}
    if ((typeof old === 'object' || typeof old === 'function') && !Object.isFrozen(old)) {
      deepFreeze(old);
    }
  });
}
var isIsolateContext = function () {
  return typeof __wxConfig !== 'undefined' && __wxConfig.isIsolateContext;
};
var freezeGlobal = function () {
  Protect.deepFreezeGlobalObjs(['console'], true);
};
var callInitFunc = /*#__PURE__*/(/* unused pure expression or super */ null && (function () {
  var _ref = _asyncToGenerator(function* (func, key) {
    Reporter.reportIDKey({
      key
    });
    try {
      yield func();
    } catch (error) {
      Reporter.reportIDKey({
        key: `${key}_fail`,
        force: true
      });
      var errorKey = key.indexOf('initGame') >= 0 ? 'gameSDKScriptError' : 'appServiceSDKScriptError';
      Reporter.errorReport({
        key: errorKey,
        error,
        extend: ''
      });
      wxConsole.error(error);
    }
  });
  return function callInitFunc(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}()));
var handleThirdError = function (error, extend, promise) {
  if (promise !== undefined) {
    Reporter.thirdErrorReport({
      error,
      isUnhandledRejection: true,
      promise,
      extend
    });
  } else {
    Reporter.thirdErrorReport({
      error,
      isUnhandledRejection: false,
      extend
    });
  }
};
var surroundByTryCatchFactory = function (key, fn) {
  return function () {
    try {
      return fn.apply(fn, arguments);
    } catch (error) {
      wxConsole.error(error);
      Reporter.errorReport({
        key,
        error,
        extend: ''
      });
    }
    return undefined;
  };
};
var executeOnlyOnce = func => {
  var executed = false;
  return (...args) => {
    if (executed) return false;
    executed = true;
    return func(...args);
  };
};
var isDevtools = function () {
  return __wxConfig.platform === 'devtools';
};
var isIOS = function () {
  return __wxConfig.platform === 'ios';
};
var isAndroid = function () {
  return __wxConfig.platform === 'android';
};
var accessSync = path => {
  var errMsg;
  WeixinJSBridge.invoke('accessSync', {
    path
  }, res => {
    if (/:fail/.test(res.errMsg)) {
      errMsg = res.errMsg;
    }
  });
  if (errMsg) {
    throw new Error(errMsg);
  }
};
var readFileSync = filePath => {
  var data;
  var errMsg;
  WeixinJSBridge.invoke('readFileSync', {
    filePath,
    encoding: 'utf-8'
  }, res => {
    if (/:fail/.test(res.errMsg)) {
      errMsg = res.errMsg;
    } else {
      data = res.data;
    }
  });
  if (errMsg) {
    throw new Error(errMsg);
  } else {
    return data;
  }
};
var isValidGameIndependentSubpackagePath = (path = '', subPackages = []) => {
  var isSubpackagePath = path && typeof path === 'string' && !/^index/.test(path);
  if (isSubpackagePath) {
    var pathSplited = path.replace(/(^\/+)|(\/+$)/g, '').split('/');
    var independentSubpackage = subPackages.find(item => {
      if (item.independent) {
        var root = item.root || '';
        var alias = item.alias || '';
        var rootSplited = root.replace(/(^\/+)|(\/+$)/g, '').split('/');
        if (pathSplited.length >= rootSplited.length) {
          var isRootIndependentValid = rootSplited.every((str, idx) => str === pathSplited[idx]);
          if (isRootIndependentValid) return isRootIndependentValid;
        }
        if (alias && path.indexOf(alias) === 0) {
          return true;
        }
      }
      return false;
    });
    if (independentSubpackage) {
      return independentSubpackage;
    }
  }
  return false;
};
var isValidGameIndependentSubpackageScene = scene => {
  var validScene = [1001, 1011, 1007, 1008, 1074, 1088, 1044, 1010, 1096, 1014, 1043, 1047, 1107, 1155];
  var bool = validScene.indexOf(scene) >= 0;
  return bool;
};
var isAsyncContext = () => JSContext.isAsync();

/***/ }),

/***/ 354:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var CurrentContext = {
  name: undefined,
  secure: true,
  runningType: 'app'
};
CurrentContext.init = function (env) {
  this.name = env.contextName;
  this.secure = env.contextSecure;
  if (typeof Foundation !== 'undefined') {
    Foundation.env.contextName = env.contextName;
    Foundation.env.typeStr = `${env.contextName}_Context`;
  }
  if (this.name.startsWith('game')) {
    this.runningType = 'game';
  } else if (this.name.startsWith('app')) {
    this.runningType = 'app';
  }
  this.remoteObjectProto = env.__proto__;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CurrentContext);

/***/ }),

/***/ 592:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(717);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(989);
/* harmony import */ var _CurrentContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(354);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(700);




function onFrameWorkError(res) {
  if (typeof __wxSourceMapRetrace__ === 'function') {
    res = __wxSourceMapRetrace__(res);
  }
  wxNativeConsole.error('FrameworkError', res);
}
function onError(res) {
  res = (0,_util__WEBPACK_IMPORTED_MODULE_3__/* .formatOnErrorParam */ .i0)(res);
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.name === ___WEBPACK_IMPORTED_MODULE_2__.CONTEXT_NAME.APP_RENDER) {
    (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .handleInnerError */ .DT)(res, '');
  } else {
    (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .handleThirdError */ .I_)(res, '');
  }
}
function onUnhandledRejection(res = {}) {
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.name === ___WEBPACK_IMPORTED_MODULE_2__.CONTEXT_NAME.APP_RENDER) {
    (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .handleInnerError */ .DT)(res.reason, '', res.promise || null);
  } else {
    (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .handleThirdError */ .I_)(res.reason, '', res.promise || null);
  }
}
Foundation.onLoad(() => {
  if (typeof __webpack_require__.g.WeixinJSBridge === 'undefined') {
    __webpack_require__.g.WeixinJSBridge = {};
    __webpack_require__.g.WeixinJSBridge.subscribeHandler = function (event, res) {
      if (event === 'onError') {
        Foundation.emitUnhandledError(res);
      } else if (event === 'unhandledRejection') {
        Foundation.emitUnhandledRejection(res === null || res === void 0 ? void 0 : res.reason, res === null || res === void 0 ? void 0 : res.promise);
      }
    };
    __webpack_require__.g.WeixinJSBridge.invokeCallbackHandler = function () {};
  }
});
Foundation.onUnhandledRejection(onUnhandledRejection);
Foundation.onUnhandledError(onError);
Foundation.onFrameworkError(onFrameWorkError);

/***/ }),

/***/ 171:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var ReporterProxy = {};
var ObjKeys = Object.keys;
ReporterProxy.init = reporter => {
  Reporter = reporter;
  var keys = ObjKeys(reporter);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i];
    if (ReporterProxy[key] === undefined) {
      ReporterProxy[key] = reporter[key];
    }
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ReporterProxy);

/***/ }),

/***/ 754:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ initWxConfigReadyHandler)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(773);

var initWxConfigReadyHandler = __wxConfigMainContext => {
  __wxConfigMainContext.onReady(__newWxConfigMainContext => {
    Foundation._onPostLoad(() => {
      var __wxConfigReadyHandler = __wxConfig.__readyHandler;
      _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.__wxConfig = Object.assign({}, __newWxConfigMainContext);
      if (typeof __wxConfigReadyHandler === 'function') {
        __wxConfigReadyHandler(__newWxConfigMainContext);
      }
    });
  });
};


/***/ }),

/***/ 23:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   n: () => (/* binding */ initAppContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(773);

var checkVersionMatches = mainContextLibVersion => {
  var _libVersionInfo__;
  var subContextLibVersion = ((_libVersionInfo__ = __libVersionInfo__) === null || _libVersionInfo__ === void 0 ? void 0 : _libVersionInfo__.version) || '9.9.9';
  if (mainContextLibVersion !== subContextLibVersion) {
    wxNativeConsole.warn(`[checkVersionMatches] baselib versions between context do not match (mainContext ${mainContextLibVersion}, subContext ${subContextLibVersion})`);
    Reporter.reportIDKey({
      key: 'subContextLibVersionNotMatch'
    });
  }
};
var initAppContext = function (env) {
  if ((env.__wxConfig.platform === 'windows' || env.__wxConfig.platform === 'mac') && env.__wxConfig.host && env.__wxConfig.host.env === 'WMPF' && env.__isAppServiceRemoteDebugMode__) {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.console = __webpack_require__.g.console;
  } else if (env.__isAppServiceRemoteDebugMode__ && env.__wxConfig.platform !== 'ios') {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.console = env.originConsole;
  } else {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.console = new env.BaseConsole();
  }
  checkVersionMatches(env.wxLibVersion);
  __Function__ = env.__Function__;
  __userActionTracer__ = env.__userActionTracer__;
  __appServiceSDK__ = env.__appServiceSDK__;
  __sclEngine__ = env.__sclEngine__;
  WeixinJSBridge = env.WeixinJSBridge;
  Reporter = env.Reporter;
  wxNativeConsole = env.wxNativeConsole;
  WeixinSharedBuffer = env.WeixinSharedBuffer;
  WeixinNativePluginMgr = env.WeixinNativePluginMgr;
  BaseConsole = env.BaseConsole;
  $dbg = env.$dbg;
  __isAppServiceRemoteDebugMode__ = !!env.__isAppServiceRemoteDebugMode__;
  __remoteDebug__ = env.__remoteDebug__;
  __debuggerMessager__ = env.debuggerMessager;
  Foundation.onLibraryEnd(() => {
    env.setWxModule(__wxModule__);
  });
  __refreshEnv = env.__refreshEnv;
  __glassEaselAdapter__ = env.__glassEaselAdapter__;
  __glassEaselAdapter__.setSubContextAdapter(__glassEaselSubContextAdapter__);
  __glassEaselSubContextAdapter__.setMainContextAdapter(__glassEaselAdapter__);
  __glassEaselAdapter__.onSkylineEngineReady(skylineEngine => {
    __glassEaselSubContextAdapter__.setSkylineEngine(skylineEngine);
  });
  __subContextEngineBridge__.bridgeContext(env.__subContextEngineBridge__);
  env.__freezeLibContextGlobal__();
  Object.defineProperty(_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A, '__wxSourceMap', {
    get: __condom__.condom(env.getWxSourceMap)
  });
  if (_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.WebAssembly) {
    delete _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.WebAssembly;
  }
  Trace = env.Trace;
};


/***/ }),

/***/ 55:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ initAppRenderContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(773);

var initAppRenderContext = function (env) {
  if (env.__wxConfig.debug) console = new env.BaseConsole();
  setTimeout = env.setTimeout;
  clearTimeout = env.clearTimeout;
  setInterval = env.setInterval;
  clearInterval = env.clearInterval;
  WeixinJSBridge = env.WeixinJSBridge;
  Reporter = env.Reporter;
  NativeGlobal = env.NativeGlobal;
  WeixinCanvas = env.WeixinCanvas;
  WeixinArrayBuffer = env.WeixinArrayBuffer;
  wxNativeConsole = env.wxNativeConsole;
  BaseConsole = env.BaseConsole;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.console = new env.BaseConsole();
  __sclEngine__ = env.__sclEngine__;
  __appServiceConsole__ = env.__appServiceConsole__;
  __glassEaselAdapter__ = env.__glassEaselAdapter__;
  __glassEaselAdapter__.setSkylineEngine(__skylineEngine__);
  __skylineEngine__.RuntimeCore.setGlassEaselAdapter(__glassEaselAdapter__);
  __glassEaselAdapter__.setWebviewEngine(__webviewEngine__);
  __webviewEngine__.setGlassEaselAdapter(__glassEaselAdapter__);
  Trace = env.Trace;
  SkylineGlobal = env.SkylineGlobal;
};


/***/ }),

/***/ 431:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   x: () => (/* binding */ initAppSclContext)
/* harmony export */ });
var initAppSclContext = function (env) {
  setTimeout = env.setTimeout;
  clearTimeout = env.clearTimeout;
  setInterval = env.setInterval;
  clearInterval = env.clearInterval;
  WeixinJSBridge = env.WeixinJSBridge;
  Reporter = env.Reporter;
  NativeGlobal = env.NativeGlobal;
  WeixinCanvas = env.WeixinCanvas;
  WeixinArrayBuffer = env.WeixinArrayBuffer;
  wxNativeConsole = env.wxNativeConsole;
  __sclEngine__ = env.__sclEngine__;
  Trace = env.Trace;
};


/***/ }),

/***/ 640:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o: () => (/* binding */ initAppXRFrameRenderContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(773);

var initAppXRFrameRenderContext = function (env) {
  setTimeout = env.setTimeout;
  clearTimeout = env.clearTimeout;
  setInterval = env.setInterval;
  clearInterval = env.clearInterval;
  WeixinJSBridge = env.WeixinJSBridge;
  Reporter = env.Reporter;
  NativeGlobal = env.NativeGlobal;
  WeixinCanvas = env.WeixinCanvas;
  WeixinArrayBuffer = env.WeixinArrayBuffer;
  wxNativeConsole = env.wxNativeConsole;
  BaseConsole = env.BaseConsole;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.console = new env.BaseConsole();
  Trace = env.Trace;
  Foundation.onLibraryEnd(() => {
    env.subContextInitCallback(xrFrame);
  });
};


/***/ }),

/***/ 296:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   H: () => (/* binding */ preloadInitGameContext),
/* harmony export */   e: () => (/* binding */ initGameContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(773);


var currentGlobals;
var comdomExptJsApi = (expt, wx, condomWx) => {
  Object.keys(condomWx).forEach(apiKey => {
    if (__condom__.shouldCloseCondom(apiKey, expt)) {
      condomWx[apiKey] = wx[apiKey];
    }
  });
  return condomWx;
};
var preWx;
var initGameContext = function (env) {
  var innerAPI = env._innerAPI;
  delete env._innerAPI;
  var _createSharedCanvas = env._createSharedCanvas;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.__isAdapterInjected = false;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.console = env.console;
  Object.defineProperty(_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A, 'sharedCanvas', {
    get() {
      return _createSharedCanvas();
    },
    set() {}
  });
  if (env.__is_wk_game) {
    currentGlobals = [...Protect.globalEsObjs.map(property => globalThis[property]), ...Protect.globalEsHiddenObjs];
  } else {
    currentGlobals = [...Protect.globalEsObjs.map(property => globalThis[property]), ...Protect.globalEsHiddenObjs].filter(Boolean);
  }
  var newCondomResult = env.__ctx_bridge.condomPrototype(currentGlobals);
  __wxConfig.onReady(() => {
    if (__wxConfig.useHighPerformanceMode === true) {
      _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.wx = env.wx;
      if (env.enableGameAudits) {
        injectGameAudits(innerAPI);
      }
      return;
    }
    if (!newCondomResult) {
      var _env$__wxConfig;
      if (preWx) {
        preWx = comdomExptJsApi(__wxConfig.expt, env.wx, preWx);
        _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.wx = preWx;
        if (env.enableGameAudits) {
          injectGameAudits(innerAPI);
        }
        return;
      }
      _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.wx = __condom__.condomWX(env.wx, env.skipCondom, (_env$__wxConfig = env.__wxConfig) === null || _env$__wxConfig === void 0 ? void 0 : _env$__wxConfig.expt);
    } else {
      if (preWx) {
        preWx = comdomExptJsApi(__wxConfig.expt, env.wx, preWx);
        _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.wx = preWx;
      } else {
        var _env$__wxConfig2;
        _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.wx = __condom__.condomWX(env.wx, env.skipCondom, (_env$__wxConfig2 = env.__wxConfig) === null || _env$__wxConfig2 === void 0 ? void 0 : _env$__wxConfig2.expt);
      }
    }
    if (env.enableGameAudits) {
      injectGameAudits(innerAPI);
    }
  });
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.requirePlugin = env.requirePlugin;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.WXWebAssembly = env.WXWebAssembly;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.WXWeakRef = env.WXWeakRef;
  delete _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.WebAssembly;
  if (!_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.GameGlobal) {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.GameGlobal = _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A;
  }
  wxNativeConsole = env.wxNativeConsole;
  Object.defineProperty(_global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A, '__wxSourceMap', {
    get: __condom__.condom(env.getWxSourceMap)
  });
};
function injectGameAudits(_innerAPI) {
  JSContext.publish('injectGamePerformanceUtilsSDK', {
    success: res => {
      var sdk = res.sdk;
      var controller = sdk.controller;
      controller.init({
        request: _innerAPI.weRequest,
        uploadFile: _innerAPI.weUploadFile,
        writeFile: _innerAPI.weWriteFile,
        globalWx: _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.wx,
        gameTransfer: _innerAPI.gameTransfer,
        getGamePerformance: _innerAPI.getGamePerformance,
        coverview: _innerAPI.coverview,
        WXConfig: _innerAPI.WXConfig,
        onShow: _innerAPI.onShow,
        onHide: _innerAPI.onHide,
        offShow: _innerAPI.offShow,
        offHide: _innerAPI.offHide,
        getSystemInfoSync: _innerAPI.getSystemInfoSync,
        getNetworkType: _innerAPI.getNetworkType,
        onNetworkStatusChange: _innerAPI.onNetworkStatusChange,
        reportKeyValue: _innerAPI.reportKeyValue
      });
      wxNativeConsole.warn('audits init finish');
    }
  });
}
var preloadInitGameContext = function (env, skipCondomList, expt) {
  if (!env || !env.wx) return;
  preWx = __condom__.condomWX(env.wx, skipCondomList, expt);
};


/***/ }),

/***/ 152:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   C: () => (/* binding */ initGameOpenDataContext)
/* harmony export */ });
var initGameOpenDataContext = function (env) {
  if (env.getWxSourceMap) env.getWxSourceMap = __condom__.condom(env.getWxSourceMap);
  __gameOpenDataSDK__.init(env);
};


/***/ }),

/***/ 701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   b: () => (/* binding */ initGamePluginContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(773);

var initGamePluginContext = function (env) {
  delete _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.NativeClient;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.console = env.console;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.WXWebAssembly = env.WXWebAssembly;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.env = {};
  if (env.pluginEnv) {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.pluginEnv = env.pluginEnv;
  }
  if (env.wx) {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.wx = env.wx;
  }
};


/***/ }),

/***/ 860:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   i: () => (/* binding */ initMagicBrushFrameContext)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(773);

function bannedFunc(name) {
  return function () {
    console.warn(`function ${name} is not supported in current env`);
  };
}
function initMagicBrushFrameContext(env) {
  JSContext.publish('magicBrushFrameSubContextBridge', {
    __subContextEngineBridge__
  });
  if (!env.isRefresh) return;
  env.console.info('[MagicBrushFrame][subContext] initMagicBrushFrameContext');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.Component = env.Component;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.Behavior = env.Behavior;
  setTimeout = env.setTimeout;
  clearTimeout = env.clearTimeout;
  setInterval = env.setInterval;
  clearInterval = env.clearInterval;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.setTimeout = bannedFunc('setTimeout');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.clearTimeout = bannedFunc('clearTimeout');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.setInterval = bannedFunc('setInterval');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.clearInterval = bannedFunc('clearInterval');
  WeixinJSBridge = env.WeixinJSBridge;
  Reporter = env.Reporter;
  wxNativeConsole = env.wxNativeConsole;
  __appServiceSDK__ = env.__appServiceSDK__;
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.console = __appServiceSDK__.console;
  var wx = __appServiceSDK__.wx;
  __condom__.condomWX(wx);
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.wx = wx;
  __subContextEngineBridge__.bridgeContext(env.__subContextEngineBridge__);
  env.__freezeLibContextGlobal__();
  setTimeout(() => {
    JSContext.publish('magicBrushFrameSubContextReady', {
      frameSetInfo: env.frameSetInfo
    });
  }, 0);
}

/***/ }),

/***/ 773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   A: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var Global = function () {
  return this;
}();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Global);

/***/ }),

/***/ 700:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CONTEXT_NAME: () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_15__.Q),
/* harmony export */   CONTEXT_NAME_PREFIX: () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_15__.H),
/* harmony export */   injectEntryFile: () => (/* reexport safe */ _loadJsFiles__WEBPACK_IMPORTED_MODULE_13__.Gx),
/* harmony export */   loadJsFiles: () => (/* reexport safe */ _loadJsFiles__WEBPACK_IMPORTED_MODULE_13__.$T),
/* harmony export */   loadLibFiles: () => (/* reexport safe */ _loadJsFiles__WEBPACK_IMPORTED_MODULE_13__.l7),
/* harmony export */   onInitReady: () => (/* binding */ onInitReady),
/* harmony export */   onMainContextMessage: () => (/* binding */ onMainContextMessage),
/* harmony export */   postMessageToMainContext: () => (/* binding */ postMessageToMainContext),
/* harmony export */   postMessageToMainContextSync: () => (/* binding */ postMessageToMainContextSync),
/* harmony export */   surroundByTryCatch: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_12__.Kh),
/* harmony export */   surroundThirdByTryCatch: () => (/* reexport safe */ _utils__WEBPACK_IMPORTED_MODULE_12__.PH)
/* harmony export */ });
/* harmony import */ var _ErrorHandler__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(592);
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(773);
/* harmony import */ var _ReporterProxy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(171);
/* harmony import */ var _CurrentContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(354);
/* harmony import */ var _timer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(537);
/* harmony import */ var _WxConfigReadyHandler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(754);
/* harmony import */ var _contexts_GameContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(296);
/* harmony import */ var _contexts_GameOpenDataContext__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(152);
/* harmony import */ var _contexts_AppContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23);
/* harmony import */ var _contexts_AppXRFrameRenderContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(640);
/* harmony import */ var _contexts_AppRenderContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(55);
/* harmony import */ var _contexts_GamePluginContext__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(701);
/* harmony import */ var _contexts_AppSclContext__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(431);
/* harmony import */ var _contexts_MagicBrushFrameContext__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(860);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(717);
/* harmony import */ var _loadJsFiles__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(486);
/* harmony import */ var _libcontext_Utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(277);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(610);
/* harmony import */ var src_util__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(989);



















var EVT_INIT_READY = 'subContext:initReady';
var mainContextMessageEmitter = new Foundation.EventEmitter();
var isEmitInitReady = false;
var onInitReady = function (cb) {
  if (isEmitInitReady) cb();else Foundation.once(EVT_INIT_READY, cb);
};
function initGlobal(env) {
  __webpack_require__.g.__isAppServiceRemoteDebugMode__ = !!env.__isAppServiceRemoteDebugMode__;
}
function initAutoTestHandler(env) {
  if (env.__isAppServiceRemoteDebugMode__) {
    // #6977 真机调试2.0 自动化测试需要以下内容
    if (env.__remoteDebug__ && env.__remoteDebug__.setAutoTestHandler) {
      try {
        $eval = env.__remoteDebug__.$$eval;
        var _this;
        env.__remoteDebug__.setAutoTestHandler({
          $eval(functionStr, args, ctx = null) {
            if (!_this) {
              if (env.__wxConfig.platform === 'ios') {
                _this = globalThis;
              } else {
                _this = {
                  ...globalThis,
                  console: env.originConsole
                };
              }
            }
            var fn = $eval(functionStr, _this);
            return fn.apply(ctx, args);
          },
          setGlobalFunctions(name, fn) {
            if (!_this) {
              globalThis[name] = fn;
            } else {
              _this[name] = fn;
            }
          }
        });
      } catch (e) {
        console.error(e);
      }
    }
  }
}
JSContext.subscribe('subContextEnvReady', (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .surroundByTryCatch */ .Kh)(env => {
  _CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.init(env);
  (0,_timer__WEBPACK_IMPORTED_MODULE_4__/* .initTimer */ ._)(env);
  initGlobal(env);
  initAutoTestHandler(env);
  Protect.hijack();
  _ReporterProxy__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .A.init(env.Reporter);
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .Q.GAME) {
    (0,_contexts_GameContext__WEBPACK_IMPORTED_MODULE_6__/* .initGameContext */ .e)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .Q.GAME_OPEN_DATA) {
    (0,_contexts_GameOpenDataContext__WEBPACK_IMPORTED_MODULE_16__/* .initGameOpenDataContext */ .C)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .Q.APP) {
    (0,_contexts_AppContext__WEBPACK_IMPORTED_MODULE_7__/* .initAppContext */ .n)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .Q.APP_RENDER) {
    (0,_contexts_AppRenderContext__WEBPACK_IMPORTED_MODULE_9__/* .initAppRenderContext */ .V)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .Q.APP_XRFRAME_RENDER) {
    (0,_contexts_AppXRFrameRenderContext__WEBPACK_IMPORTED_MODULE_8__/* .initAppXRFrameRenderContext */ .o)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME */ .Q.APP_SCL) {
    (0,_contexts_AppSclContext__WEBPACK_IMPORTED_MODULE_17__/* .initAppSclContext */ .x)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name.startsWith(_constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME_PREFIX */ .H.GAME_PLUGIN)) {
    (0,_contexts_GamePluginContext__WEBPACK_IMPORTED_MODULE_10__/* .initGamePluginContext */ .b)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name.startsWith(_constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME_PREFIX */ .H.APP_CARDS)) {
    (0,_contexts_MagicBrushFrameContext__WEBPACK_IMPORTED_MODULE_11__/* .initMagicBrushFrameContext */ .i)(env);
  } else {
    throw new Error('subContextEnvReady: missing context name.');
  }
  (0,_WxConfigReadyHandler__WEBPACK_IMPORTED_MODULE_5__/* .initWxConfigReadyHandler */ .V)(env.__wxConfig);
}));
JSContext.subscribe('preloadSubContextEnvReady', (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .surroundByTryCatch */ .Kh)(env => {
  _CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.init(env);
  if (env.preHandleEnv) {
    (0,_contexts_GameContext__WEBPACK_IMPORTED_MODULE_6__/* .preloadInitGameContext */ .H)(env.preHandleEnv, env.skipCondomList, env.expt);
  }
}));
JSContext.subscribe('subContextRefreshEnv', (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .surroundByTryCatch */ .Kh)(env => {
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === 'game') {
    (0,_contexts_GameContext__WEBPACK_IMPORTED_MODULE_6__/* .initGameContext */ .e)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === 'gameOpenData') {
    (0,_contexts_GameOpenDataContext__WEBPACK_IMPORTED_MODULE_16__/* .initGameOpenDataContext */ .C)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === 'app') {
    (0,_contexts_AppContext__WEBPACK_IMPORTED_MODULE_7__/* .initAppContext */ .n)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === 'app_sub_render') {
    (0,_contexts_AppRenderContext__WEBPACK_IMPORTED_MODULE_9__/* .initAppRenderContext */ .V)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === 'app_xrframe_render') {
    (0,_contexts_AppXRFrameRenderContext__WEBPACK_IMPORTED_MODULE_8__/* .initAppXRFrameRenderContext */ .o)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === 'app_sub_scl') {
    (0,_contexts_AppSclContext__WEBPACK_IMPORTED_MODULE_17__/* .initAppSclContext */ .x)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name.startsWith('gamePlugin_')) {
    (0,_contexts_GamePluginContext__WEBPACK_IMPORTED_MODULE_10__/* .initGamePluginContext */ .b)(env);
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name.startsWith(_constants__WEBPACK_IMPORTED_MODULE_15__/* .CONTEXT_NAME_PREFIX */ .H.APP_CARDS)) {
    (0,_contexts_MagicBrushFrameContext__WEBPACK_IMPORTED_MODULE_11__/* .initMagicBrushFrameContext */ .i)(env);
  } else {
    throw new Error('subContextRefreshEnv: missing context name.');
  }
  JSContext.publish('subContextRefreshEnvReady', null, true);
}));
JSContext.subscribe('subContextRefreshWxConfig', (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .surroundByTryCatch */ .Kh)(data => {
  var {
    key,
    value
  } = data;
  if (typeof key === 'string' && value) {
    __wxConfig[key] = value;
  }
}));
JSContext.subscribe('exportGlobalRequire', (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .surroundByTryCatch */ .Kh)(data => {
  var nameTester = /^[A-Za-z]+(\.[A-Za-z]+)*$/;
  var addVariable = variable => {
    var {
      name,
      value,
      needCondom
    } = variable;
    if (typeof name !== 'string' || !nameTester.test(name)) {
      throw new Error('exportGlobalRequire: illegal variable name.');
    }
    var matchList = name.split('.');
    matchList.reduce((obj, key, idx, matchList) => {
      if (idx === matchList.length - 1) {
        if (key in obj) {
          throw new Error(`exportGlobalRequire: Variable ${name} exists.`);
        }
        obj[key] = needCondom ? __condom__.condom(value) : value;
      }
      if (!((0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .getDataType */ .h1)(obj[key]) === 'Array' || (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .getDataType */ .h1)(obj[key]) === 'Function' || (0,_utils__WEBPACK_IMPORTED_MODULE_12__/* .getDataType */ .h1)(obj[key]) === 'Object')) {
        var searchPath = matchList.slice(0, idx + 1).join('.');
        throw new Error(`exportGlobalRequire: ${searchPath} is not an Object.`);
      }
      return obj[key];
    }, _global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A);
  };
  if (Object.prototype.toString.call(data) === '[object Array]') return data.forEach(addVariable);
  return addVariable(data);
}));
JSContext.subscribe('mainContextMessage', res => {
  mainContextMessageEmitter.emit('mainContextMessage', res);
});
JSContext.subscribe('subContextDestroy', () => {});
JSContext.subscribe('readyLoadSDKSubPackage', res => {
  Object.getOwnPropertyNames(res).forEach(key => {
    _global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A[key] = res[key];
  });
  JSContext.publish('readyLoadSDKSubPackageDone');
});
var NEED_DELETE_GLOBAL_LIST = ['WeixinJSCore', 'WeixinNativeBuffer', 'WeixinWorker', 'NativeGlobal', 'lockSharedNativeBuffer', 'unlockSharedNativeBuffer', 'getNativeBufferId', 'getNativeBuffer', 'setNativeBuffer', 'setSharedNativeBuffer', 'getSharedNativeBuffer', 'WeixinArrayBuffer'];
var shouldDeferPublishSubcontextReady = typeof IS_RENDER_CTX !== 'undefined';
Foundation.onLoad(() => {
  NEED_DELETE_GLOBAL_LIST.forEach(name => {
    delete _global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A[name];
  });
  JSContext.publish('subContextReady', {
    contextGlobal: {
      get __wxSourceMap() {
        return _global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.__wxSourceMap;
      },
      get __require() {
        return _CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name === 'game' || _CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.name.startsWith('gamePlugin_') ? _global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.require : __condom__.condom(_global__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.require);
      },
      jsonParse: JSON.parse,
      jsonStringify: JSON.stringify,
      arrayBufferProto: ArrayBuffer.prototype
    }
  }, true);
}, shouldDeferPublishSubcontextReady);
var hadReadOnly = false;
var globalReadOnlyProtect = function () {
  if (hadReadOnly) return;
  hadReadOnly = true;
  Protect.overwriteSetPrototypeOf();
  Protect.deepFreezeGlobalObjs([], false);
};
Foundation.onLibraryEnd(() => {
  Foundation.onLoad(() => {
    if (_CurrentContext__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .A.secure && __wxConfig && __wxConfig.isIsolateContext) {
      globalReadOnlyProtect();
    }
    Foundation.emit(EVT_INIT_READY);
    isEmitInitReady = true;
  });
  Foundation.onStart(() => {
    if (__wxConfig.plugins) {
      Protect.hijackFunction({});
      if (!(0,_libcontext_Utils__WEBPACK_IMPORTED_MODULE_14__/* .isDevtools */ .hX)()) {
        globalReadOnlyProtect();
      }
    }
  });
});
var postMessageToMainContext = msg => {
  (0,src_util__WEBPACK_IMPORTED_MODULE_18__/* .nextMicroTask */ .Lv)(() => {
    JSContext.publish('subContextMessage', msg);
  });
};
var postMessageToMainContextSync = msg => {
  JSContext.publish('subContextMessage', msg);
};
var onMainContextMessage = fn => {
  mainContextMessageEmitter.on('mainContextMessage', fn);
};


/***/ }),

/***/ 486:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $T: () => (/* binding */ loadJsFiles),
/* harmony export */   Gx: () => (/* binding */ injectEntryFile),
/* harmony export */   l7: () => (/* binding */ loadLibFiles)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(610);
/* harmony import */ var _CurrentContext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(354);


var isApp = () => _CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_1__/* .CONTEXT_NAME */ .Q.APP;
var loadJsFiles = (paths, moduleName, options) => {
  var shouldBlock = isApp();
  if (JSContext && JSContext.publish) {
    if (shouldBlock) __wxModule__.globalRequireBlocker.block();
    var ret = JSContext.publish('loadJsFiles', {
      paths,
      options,
      moduleName,
      contextName: _CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.name
    });
    if (shouldBlock) __wxModule__.globalRequireBlocker.unblock();
    if (shouldBlock) __wxModule__.globalRequireBlocker.flushQueue();
    return ret;
  } else return 'failed';
};
var injectEntryFile = (moduleName, separatedPlugins) => {
  var shouldBlock = isApp();
  if (JSContext && JSContext.publish) {
    if (shouldBlock) __wxModule__.globalRequireBlocker.block();
    var ret = JSContext.publish('injectEntryFile', {
      moduleName,
      separatedPlugins
    });
    if (shouldBlock) __wxModule__.globalRequireBlocker.unblock();
    if (shouldBlock) __wxModule__.globalRequireBlocker.flushQueue();
    return ret;
  } else return 'failed';
};
var loadLibFiles = paths => {
  if (JSContext && JSContext.publish) {
    return JSContext.publish('loadLibFiles', {
      paths,
      contextName: _CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.name
    });
  } else return 'failed';
};


/***/ }),

/***/ 537:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ initTimer)
/* harmony export */ });
/* harmony import */ var _global__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(773);
/* harmony import */ var _CurrentContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(354);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(717);



var timerFuncFactory = function (fn, extend) {
  return function () {
    if (typeof arguments[0] === 'function') {
      arguments[0] = (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .surroundThirdByTryCatch */ .PH)(arguments[0], extend);
    }
    return fn(...arguments);
  };
};
var initTimer = env => {
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.setTimeout = timerFuncFactory(env.setTimeout, 'at setTimeout callback function');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.clearTimeout = timerFuncFactory(env.clearTimeout);
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.setInterval = timerFuncFactory(env.setInterval, 'at setInterval callback function');
  _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.clearInterval = timerFuncFactory(env.clearInterval);
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.runningType === 'game') {
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.requestAnimationFrame = timerFuncFactory(env.requestAnimationFrame, 'at requestAnimationFrame callback function');
    _global__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.cancelAnimationFrame = timerFuncFactory(env.cancelAnimationFrame);
  }
};


/***/ }),

/***/ 717:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DT: () => (/* binding */ handleInnerError),
/* harmony export */   I_: () => (/* binding */ handleThirdError),
/* harmony export */   Kh: () => (/* binding */ surroundByTryCatch),
/* harmony export */   PH: () => (/* binding */ surroundThirdByTryCatch),
/* harmony export */   h1: () => (/* binding */ getDataType)
/* harmony export */ });
/* unused harmony export deepFreeze */
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(610);
/* harmony import */ var _CurrentContext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(354);
/* harmony import */ var _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(171);



var handleThirdError = function (error, extend, promise) {
  try {
    var key;
    if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .Q.GAME) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.RunType.GAME;
    } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .Q.GAME_OPEN_DATA) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.RunType.GAME_SUBCONTEXT;
    } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .Q.APP) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.RunType.APP;
    } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.name.startsWith(_constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME_PREFIX */ .H.GAME_PLUGIN)) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.RunType.GAME_SUBCONTEXT;
    } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .Q.APP_RENDER) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.RunType.APP_SUBCONTEXT;
    } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .Q.APP_XRFRAME_RENDER) {
      key = _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.RunType.APP_SUBCONTEXT;
    } else {
      throw new Error('unknown context');
    }
    if (promise !== undefined) {
      _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.thirdErrorReport({
        key,
        error,
        extend,
        triggerErrorCallback: !_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.secure,
        isUnhandledRejection: true,
        promise
      });
    } else {
      _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.thirdErrorReport({
        key,
        error,
        extend,
        triggerErrorCallback: !_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.secure,
        isUnhandledRejection: false
      });
    }
  } catch (e) {
    console.error('[ErrorHandler] error in Report.thirdErrorReport: ', e.message);
  }
};
function surroundThirdByTryCatch(fn, extend) {
  return function () {
    var res;
    try {
      if (typeof fn === 'function') {
        res = fn.apply(fn, arguments);
      }
    } catch (error) {
      handleThirdError(error, extend);
    }
    return res;
  };
}
function handleInnerError(error, extend, promise) {
  var key = '';
  if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.name === _constants__WEBPACK_IMPORTED_MODULE_2__/* .CONTEXT_NAME */ .Q.APP_RENDER) {
    key = 'appSubContextSDKScriptError';
  } else if (_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.runningType === 'game') {
    key = 'gameSubContextSDKScriptError';
  }
  if (typeof _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.thirdErrorReport !== 'function') {
    var msg = extend ? `${error.message};${extend}` : error.message;
    var errMsg = `${key}\n${msg}\n${error.stack}`;
    if (typeof console !== 'undefined') {
      console.error(errMsg);
    }
    return;
  }
  try {
    if (promise !== undefined) {
      _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.errorReport({
        key,
        error,
        extend,
        triggerErrorCallback: !_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.secure,
        isUnhandledRejection: true,
        promise
      });
    } else {
      _ReporterProxy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A.errorReport({
        key,
        error,
        extend,
        triggerErrorCallback: !_CurrentContext__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .A.secure,
        isUnhandledRejection: false
      });
    }
  } catch (e) {
    console.error('[ErrorHandler] error in Report.errorReport: ', e.message);
  }
}
function surroundByTryCatch(fn, extend) {
  return function () {
    try {
      return fn.apply(fn, arguments);
    } catch (e) {
      wxConsole.error(e.message, e.stack);
      if (Object.prototype.toString.apply(e) === '[object Error]') {
        if (e.type === 'AppServiceSdkKnownError') {
          throw e;
        } else {
          handleInnerError(e, extend);
        }
      }
      return undefined;
    }
  };
}
function getDataType(data) {
  return Object.prototype.toString.call(data).split(' ')[1].split(']')[0];
}
function deepFreeze(o) {
  Object.freeze(o);
  Object.getOwnPropertyNames(o).forEach(prop => {
    var old;
    try {
      old = o[prop];
    } catch (e) {}
    if ((typeof old === 'object' || typeof old === 'function') && !Object.isFrozen(old)) {
      deepFreeze(old);
    }
  });
  return o;
}

/***/ }),

/***/ 989:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Lv: () => (/* binding */ nextMicroTask),
/* harmony export */   i0: () => (/* binding */ formatOnErrorParam)
/* harmony export */ });
/* unused harmony export nextMacroTask */
var formatOnErrorParam = function (res) {
  if (typeof res === 'string') {
    try {
      return JSON.parse(res.replace(/"/g, '\\"').replace(/'/g, '"').replace(/\n/g, '\\n'));
    } catch (e) {
      return {
        message: res,
        stack: ''
      };
    }
  } else {
    return res;
  }
};
var nextMacroTaskTimerId = null;
var nextMacroTaskCallbacks = (/* unused pure expression or super */ null && ([]));
var nextMacroTask = cb => {
  nextMacroTaskCallbacks.push(cb);
  if (nextMacroTaskTimerId === null) {
    nextMacroTaskTimerId = setTimeout(() => {
      nextMacroTaskTimerId = null;
      for (var i = 0; i < nextMacroTaskCallbacks.length; ++i) {
        if (typeof nextMacroTaskCallbacks[i] === 'function') {
          nextMacroTaskCallbacks[i]();
        }
      }
      nextMacroTaskCallbacks.length = 0;
    }, 0);
  }
};
var pendingMicroTask = false;
var nextMicroTaskCallbacks = [];
var nextMicroTask = cb => {
  nextMicroTaskCallbacks.push(cb);
  if (!pendingMicroTask) {
    pendingMicroTask = true;
    Promise.resolve().then(() => {
      for (var i = 0; i < nextMicroTaskCallbacks.length; ++i) {
        if (typeof nextMicroTaskCallbacks[i] === 'function') {
          try {
            nextMicroTaskCallbacks[i]();
          } catch (err) {
            wxNativeConsole.error('[system] Error: nextMicroTaskCallback occur fatal error: ', err);
            console.error('[system] Error: nextMicroTaskCallback occur fatal error: ', err);
            throw err;
          }
        }
      }
      pendingMicroTask = false;
      nextMicroTaskCallbacks.length = 0;
    });
  }
};

/***/ }),

/***/ 284:
/***/ ((module) => {

module.exports = BabelRuntimeHelpers.asyncToGenerator;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(700);
/******/ 	__subContextEngine__ = __webpack_exports__;
/******/ 	
/******/ })()
;
var __sclSDK__;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ scl)
});

;// CONCATENATED MODULE: ./src/base/WXConfig.ts
var EnvPreloadType = (/* unused pure expression or super */ null && ({
  None: 0,
  BeforeLaunch: 1,
  AfterLaunch: 2
}));
var updateConfig = () => {
  if (WXConfig_WXConfig !== __wxConfig && typeof WXConfig_WXConfig !== 'undefined') {
    Object.assign(WXConfig_WXConfig, __wxConfig);
  }
};
var WXConfig_WXConfig = /* #__PURE__ */(() => {
  __wxConfig.onReady(updateConfig);
  return __wxConfig;
})();
/* harmony default export */ const base_WXConfig = (WXConfig_WXConfig);
;// CONCATENATED MODULE: ./src/base/env.ts

var PLATFORM = /* #__PURE__ */(() => base_WXConfig.platform)();
var env_IS_DEVTOOLS = /* #__PURE__ */(() => PLATFORM === 'devtools')();
var env_IS_ANDROID = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'android')()));
var env_IS_IOS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'ios')()));
var IS_WINDOWS = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'windows')()));
var IS_MAC = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'mac')()));
var IS_MINA = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => PLATFORM === 'mina')()));
var IS_PC = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => IS_WINDOWS || IS_MAC)()));
function debugEnabled() {
  if (!base_WXConfig || !("debug" in base_WXConfig) || typeof base_WXConfig.debug === 'undefined') return undefined;
  return !!base_WXConfig.debug;
}
var ENV = /* #__PURE__ */(/* unused pure expression or super */ null && ((_WXConfig$host => (_WXConfig$host = WXConfig.host) === null || _WXConfig$host === void 0 ? void 0 : _WXConfig$host.env)()));
var IS_HOST_SDK = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'SDK')()));
var IS_HOST_SAAA_SDK = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'SAAASDK')()));
var IS_HOST_WMPF = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'WMPF')()));
var IS_HOST_WECHAT = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => ENV === 'WeChat')()));
var IS_USE_NATIVE_MAP = /* #__PURE__ */(/* unused pure expression or super */ null && ((_WXConfig$host2 => ((_WXConfig$host2 = WXConfig.host) === null || _WXConfig$host2 === void 0 ? void 0 : _WXConfig$host2.forceUseNativeMap) || false)()));
var WK_RENDERER_H5 = /* #__PURE__ */(/* unused pure expression or super */ null && (function isRenderH5() {
  if (typeof WORKER_RUNTIME !== 'undefined' && WORKER_RUNTIME) {
    if (typeof self !== 'undefined') {
      return self && self.__wkrenderer_h5;
    }
  }
  return typeof window === 'object' && window && window.__wkrenderer_h5;
}()));
function isWkGameNativeRender() {
  return typeof window === 'object' && window && window.__wkrenderer_h5 && (window.__featBit & 0x2) > 0;
}
function isRemoteDebugEnabled() {
  return __webpack_require__.g.__isAppServiceRemoteDebugMode__ || typeof __initHelper !== 'undefined' && __initHelper === 1;
}
function isIn3rdApp() {
  var host = WXConfig.host;
  return host && host.env !== 'WeChat' && host.env !== 'WMPF';
}
function isReleaseBuild() {
  var release = true;
  typeof wxRunOnDebug !== 'undefined' && wxRunOnDebug(() => {
    release = false;
  });
  return release;
}
function isGame() {
  return typeof IS_WAGAME === 'boolean' ? IS_WAGAME : WXConfig.appType === 4;
}
function isAppServiceOrWebView() {
  var _Foundation;
  return typeof IS_APP === 'boolean' ? IS_APP : (_Foundation = Foundation) === null || _Foundation === void 0 ? void 0 : _Foundation.env.isApp;
}
var isAppService = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => typeof IS_APP !== 'undefined' && IS_APP)()));
function isNormalApp() {
  return WXConfig.appType === 0;
}
var thirdPartyAppType = (/* unused pure expression or super */ null && ([0, 1, 2, 3, 5, 6, 8, 9, 10, 11, 12, 13]));
function isThirdPartyApp() {
  return thirdPartyAppType.includes(WXConfig.appType);
}
function isFakeNativeApp() {
  return WXConfig.appType === 7;
}
function isPhysicalStoresApp() {
  return WXConfig.appType === 2;
}
function isWXStoreApp() {
  return WXConfig.appType === 10;
}
;// CONCATENATED MODULE: ./src/base/genericWeixinJSBridge.js
var genericWeixinJSBridge_invokeMethod;
var genericWeixinJSBridge = {
  get invoke() {
    if (!genericWeixinJSBridge_invokeMethod) wxConsole.error('genericWeixinJSBridge.invoke not set');
    return genericWeixinJSBridge_invokeMethod;
  },
  set invoke(fn) {
    genericWeixinJSBridge_invokeMethod = fn;
  }
};
/* harmony default export */ const base_genericWeixinJSBridge = (genericWeixinJSBridge);
;// CONCATENATED MODULE: ./src/baseView/BaseMethods/bridgeMethods.js
function invoke(event, params, callback, privateArgs = {}) {
  WeixinJSBridge.invoke(event, params, callback, privateArgs);
}
function on(event, callback) {
  if (false) {} else {
    Foundation.onLoad(() => {
      WeixinJSBridge.addEventListener(event, (result, webviewId, ext) => {
        if (typeof (ext === null || ext === void 0 ? void 0 : ext.__subscribe_webviewId) === 'number') {
          callback(result, webviewId, ext);
        }
      });
    });
  }
}
function publish(event, params, webviewIds) {
  var _params = {
    data: params,
    options: {
      timestamp: Date.now()
    }
  };
  if (false) {} else {
    Foundation.onLoad(() => {
      WeixinJSBridge.publish(event, _params, webviewIds);
    });
  }
}
function subscribe(event, callback) {
  var _callback = ({
    data,
    options
  }, webviewIds, ext = {}) => {
    var startTime = options && options.timestamp || 0;
    var endTime = Date.now();
    Reporter.speedReport({
      key: 'appService2Webview',
      data: data || {},
      timeMark: {
        startTime,
        endTime,
        nativeTime: ext.nativeTime
      }
    });
    if (typeof callback === 'function') {
      callback(data, webviewIds, ext);
    }
  };
  if (false) {} else {
    Foundation.onLoad(() => {
      WeixinJSBridge.subscribe(event, _callback);
    });
  }
}
function addSubscribeListener(event, callback) {
  if (false) {} else {
    Foundation.onLoad(() => {
      WeixinJSBridge.addSubscribeListener(event, callback);
    });
  }
}
function removeSubscribeListener(event, callback) {
  if (false) {} else {
    Foundation.onLoad(() => {
      WeixinJSBridge.removeSubscribeListener(event, callback);
    });
  }
}
;// CONCATENATED MODULE: ./src/baseView/BaseMethods/contextMethods.ts
/* #__EXPORTS_SIDE_EFFECTS_FREE__ */

function contextMethods_publish(event, params) {
  __webviewEngine__.getRandomPageId(pageId => {
    publishAsPage(event, params, pageId);
  });
}
function publishAsPage(event, params, pageId) {
  __subContextEngine__.postMessageToMainContext({
    event,
    params: {
      params,
      pageId
    }
  });
}
function publishAsPageSync(event, params, pageId) {
  __subContextEngine__.postMessageToMainContextSync({
    event,
    params: {
      params,
      pageId
    }
  });
}
var GlobalListenersMap = new Map();
var PageListenersMap = new Map();
function addGlobalListener(event, callback) {
  if (!GlobalListenersMap.has(event)) GlobalListenersMap.set(event, []);
  GlobalListenersMap.get(event).push(callback);
}
function addPageListener(event, pageId, callback) {
  if (!PageListenersMap.has(pageId)) PageListenersMap.set(pageId, new Map());
  var pageListenersMap = PageListenersMap.get(pageId);
  if (!pageListenersMap.has(event)) pageListenersMap.set(event, []);
  pageListenersMap.get(event).push(callback);
}
function triggerPageListeners(event, params) {
  var pageId = params.pageId;
  if (pageId !== undefined) {
    var _PageListenersMap$get, _PageListenersMap$get2;
    (_PageListenersMap$get = PageListenersMap.get(pageId)) === null || _PageListenersMap$get === void 0 ? void 0 : (_PageListenersMap$get2 = _PageListenersMap$get.get(event)) === null || _PageListenersMap$get2 === void 0 ? void 0 : _PageListenersMap$get2.forEach(callback => {
      callback(params.params, pageId);
    });
  }
  PageListenersMap.forEach((map, pageId) => {
    var _map$get;
    (_map$get = map.get(event)) === null || _map$get === void 0 ? void 0 : _map$get.forEach(callback => {
      callback(params.params, pageId);
    });
  });
}
function triggerGlobalListeners(event, params) {
  var _GlobalListenersMap$g;
  (_GlobalListenersMap$g = GlobalListenersMap.get(event)) === null || _GlobalListenersMap$g === void 0 ? void 0 : _GlobalListenersMap$g.forEach(callback => {
    if (params.pageId !== undefined) {
      callback(params.params, params.pageId);
    } else {
      __webviewEngine__.getAllPageIds(pageIds => {
        pageIds === null || pageIds === void 0 ? void 0 : pageIds.forEach(pageId => {
          callback(params.params, pageId);
        });
      });
    }
  });
}
if (true) {
  __subContextEngine__.onMainContextMessage(res => {
    triggerGlobalListeners(res.event, res.params);
    triggerPageListeners(res.event, res.params);
  });
}
function contextMethods_subscribe(event, callback) {
  addGlobalListener(event, callback);
}
function subscribeAsPage(event, pageId, callback) {
  addPageListener(event, pageId, callback);
}
function clearGlobalListeners(event) {
  GlobalListenersMap.delete(event);
}
function clearPageListeners(pageId) {
  PageListenersMap.delete(pageId);
}
;// CONCATENATED MODULE: ./src/baseView/BaseMethods/invokeMethod.js

function mainInvokeMethod(name, args = {}, ext = {}, invokeArgs = {}) {
  var callbacks = {};
  Object.keys(args).forEach(key => {
    if (typeof args[key] === 'function') {
      callbacks[key] = args[key];
      delete args[key];
    }
  });
  var invoke = invokeAs(invokeArgs);
  invoke(name, args, res => {
    res.errMsg = res.errMsg || `${name}:ok`;
    var success = res.errMsg.indexOf(`${name}:ok`) === 0;
    var cancel = res.errMsg.indexOf(`${name}:cancel`) === 0;
    var fail = res.errMsg.indexOf(`${name}:fail`) === 0;
    typeof ext.beforeAll === 'function' && ext.beforeAll(res);
    if (success) {
      typeof ext.beforeSuccess === 'function' && ext.beforeSuccess(res);
      typeof callbacks.success === 'function' && callbacks.success(res);
      typeof ext.afterSuccess === 'function' && ext.afterSuccess(res);
    } else if (cancel) {
      typeof callbacks.cancel === 'function' && callbacks.cancel(res);
      typeof ext.cancel === 'function' && ext.cancel(res);
    } else if (fail) {
      typeof ext.beforeFail === 'function' && ext.beforeFail(res);
      typeof callbacks.fail === 'function' && callbacks.fail(res);
      typeof ext.afterFail === 'function' && ext.afterFail(res);
    }
    typeof callbacks.complete === 'function' && callbacks.complete(res);
    typeof ext.afterAll === 'function' && ext.afterAll(res);
  });
}
var invokeMethod_invokeMethod = (name, args = {}, ext = {}) => {
  mainInvokeMethod(name, args, ext);
};
var invokeMethodAs = invokeArgs => (name, args, ext) => {
  mainInvokeMethod(name, args, ext, invokeArgs);
};
;// CONCATENATED MODULE: ./src/baseView/BaseMethods/onMethod.js

function onMethod(eventName, callback) {
  on(eventName, callback);
}
;// CONCATENATED MODULE: ./src/baseView/BaseMethods/operateWXData.js


function operateWXDataFactory(name, APIName, reqData = {}, transRespData = () => {}, allowPluginId = false, isImportant = false, requestInQueue = true) {
  return args => {
    var data = reqData;
    if (typeof reqData === 'function') {
      data = reqData(args);
    }
    var reqArgs = Object.assign({}, args, {
      isImportant: isImportant === true,
      requestInQueue: requestInQueue === true,
      data: Object.assign({}, data, {
        api_name: APIName
      })
    });
    if (allowPluginId) {
      reqArgs.data.plugin_appid = args.pluginId;
      if (args.withCredentials !== undefined) {
        reqArgs.data.with_credentials = args.withCredentials;
      }
    }
    wxConsole.log(`operateWXDataFactory request. name: ${name}. args:`, reqArgs);
    invokeMethod('operateWXData', reqArgs, {
      beforeAll(res) {
        res.errMsg = res.errMsg.replace('operateWXData', name);
      },
      beforeFail(res) {
        wxConsole.log(`operateWXDataFactory failed. name: ${name}. data:`, res);
      },
      beforeSuccess(res) {
        if (IS_ANDROID && typeof res.data === 'string') {
          res.data = JSON.parse(res.data);
        }
        if (typeof res.data.data !== 'undefined') {
          res.rawData = res.data.data;
        }
        if (res.data.signature) {
          res.signature = res.data.signature;
        }
        if (res.data.encryptedData) {
          res.encryptedData = res.data.encryptedData;
          res.iv = res.data.iv;
          if (res.data.cloud_id) {
            res.cloudID = res.data.cloud_id;
          }
        }
        transRespData(res);
        wxConsole.log(`operateWXDataFactory response. name: ${name}. data:`, res);
      }
    });
  };
}
;// CONCATENATED MODULE: ./src/baseView/BaseMethods/index.js





base_genericWeixinJSBridge.invoke = invokeMethod_invokeMethod;
var {
  EventEmitter
} = Foundation;
var BaseMethods_Emitter = new EventEmitter();
var BaseMethods_publish =  false ? 0 : contextMethods_publish;
var BaseMethods_publishAsPage = pageId => {
  if (false) {}
  return function (event, params) {
    publishAsPage(event, params, pageId);
  };
};
var BaseMethods_publishAsPageSync = pageId => {
  if (false) {}
  return function (event, params) {
    publishAsPageSync(event, params, pageId);
  };
};
var BaseMethods_subscribe =  false ? 0 : contextMethods_subscribe;
var BaseMethods_subscribeAsPage = pageId => {
  if (false) {}
  return function (event, callback) {
    subscribeAsPage(event, pageId, callback);
  };
};
var BaseMethods_addSubscribeListener = addSubscribeListener;
var BaseMethods_removeSubscribeListener = removeSubscribeListener;
var fakeAttachPluginPermissionBytesQueue = [];
var attachPluginPermissionBytes = (...args) => {
  fakeAttachPluginPermissionBytesQueue.push(args);
};
var setAttachPluginPermissionBytesForInvoke = impl => {
  attachPluginPermissionBytes = impl;
  fakeAttachPluginPermissionBytesQueue.forEach(args => {
    attachPluginPermissionBytes(...args);
  });
};
var invokeSuccessCallback;
function onInvokeSuccessCallback(fn) {
  if (invokeSuccessCallback !== undefined) return;
  invokeSuccessCallback = fn;
}
function mainInvoke(method, args, pluginId, cb, privateArgs = {}) {
  var callback = res => {
    if (typeof invokeSuccessCallback === 'function' && (typeof res.errMsg !== 'string' || res.errMsg.indexOf(`${method}:ok`) === 0)) {
      invokeSuccessCallback(method, pluginId);
    }
    if (typeof cb === 'function') cb(res);
  };
  if (typeof pluginId !== 'string' || !pluginId.startsWith('wx')) {
    invoke(method, args, callback, privateArgs);
  } else if (__wxConfig.supportInvokeWithAppId) {
    privateArgs.appId = pluginId;
    invoke(method, args, callback, privateArgs);
  } else {
    attachPluginPermissionBytes(pluginId, method, args, _args => {
      invoke(method, _args, callback, privateArgs);
    });
  }
}
var allowRandomPageIdSet = new Set(['getGlobalStorage', 'setGlobalStorage', 'getGlobalStorageInfo', 'removeGlobalStorage', 'preloadWebview']);
var attachRandomPageId = (name, args, cb) => {
  var _webviewEngine__;
  if (args.__invoke_webviewId !== undefined) {
    cb(args);
    return;
  }
  if (typeof ((_webviewEngine__ = __webviewEngine__) === null || _webviewEngine__ === void 0 ? void 0 : _webviewEngine__.getRandomPageId) !== 'function') {
    wxNativeConsole.info(`__webviewEngine__.getRandomPageId not available, may be too early to call invoke, invoke with no webviewId`);
    cb(args);
    return;
  }
  __webviewEngine__.getRandomPageId(randomPageId => {
    args.__invoke_webviewId = randomPageId;
    if (!allowRandomPageIdSet.has(name)) {
      wxNativeConsole.warn(`no pageId found when invoking JsApi "${name}" from skyline render context, using ${randomPageId}. If this is expected, add "${name}" to allowRandomPageIdSet`);
    }
    cb(args);
  });
};
var BaseMethods_invoke = (method, args = {}, cb, privateArgs = {}) => {
  if (false) {}else {
    attachRandomPageId(method, args, _args => {
      mainInvoke(method, _args, '', cb, privateArgs);
    });
  }
};
var invokeAs = (invokeArgs = {}) => (method, args = {}, callback, privateArgs) => {
  if (false) {}else if (invokeArgs.pageId !== undefined) {
    args.__invoke_webviewId = invokeArgs.pageId;
    mainInvoke(method, args, invokeArgs.pluginId, callback, privateArgs);
  } else {
    attachRandomPageId(method, args, _args => {
      mainInvoke(method, _args, invokeArgs.pluginId, callback, privateArgs);
    });
  }
};







;// CONCATENATED MODULE: ./src/appservice/canvas/PredefinedColor.js
var predefinedColor = {
  aliceblue: '#f0f8ff',
  antiquewhite: '#faebd7',
  aqua: '#00ffff',
  aquamarine: '#7fffd4',
  azure: '#f0ffff',
  beige: '#f5f5dc',
  bisque: '#ffe4c4',
  black: '#000000',
  blanchedalmond: '#ffebcd',
  blue: '#0000ff',
  blueviolet: '#8a2be2',
  brown: '#a52a2a',
  burlywood: '#deb887',
  cadetblue: '#5f9ea0',
  chartreuse: '#7fff00',
  chocolate: '#d2691e',
  coral: '#ff7f50',
  cornflowerblue: '#6495ed',
  cornsilk: '#fff8dc',
  crimson: '#dc143c',
  cyan: '#00ffff',
  darkblue: '#00008b',
  darkcyan: '#008b8b',
  darkgoldenrod: '#b8860b',
  darkgray: '#a9a9a9',
  darkgrey: '#a9a9a9',
  darkgreen: '#006400',
  darkkhaki: '#bdb76b',
  darkmagenta: '#8b008b',
  darkolivegreen: '#556b2f',
  darkorange: '#ff8c00',
  darkorchid: '#9932cc',
  darkred: '#8b0000',
  darksalmon: '#e9967a',
  darkseagreen: '#8fbc8f',
  darkslateblue: '#483d8b',
  darkslategray: '#2f4f4f',
  darkslategrey: '#2f4f4f',
  darkturquoise: '#00ced1',
  darkviolet: '#9400d3',
  deeppink: '#ff1493',
  deepskyblue: '#00bfff',
  dimgray: '#696969',
  dimgrey: '#696969',
  dodgerblue: '#1e90ff',
  firebrick: '#b22222',
  floralwhite: '#fffaf0',
  forestgreen: '#228b22',
  fuchsia: '#ff00ff',
  gainsboro: '#dcdcdc',
  ghostwhite: '#f8f8ff',
  gold: '#ffd700',
  goldenrod: '#daa520',
  gray: '#808080',
  grey: '#808080',
  green: '#008000',
  greenyellow: '#adff2f',
  honeydew: '#f0fff0',
  hotpink: '#ff69b4',
  indianred: '#cd5c5c',
  indigo: '#4b0082',
  ivory: '#fffff0',
  khaki: '#f0e68c',
  lavender: '#e6e6fa',
  lavenderblush: '#fff0f5',
  lawngreen: '#7cfc00',
  lemonchiffon: '#fffacd',
  lightblue: '#add8e6',
  lightcoral: '#f08080',
  lightcyan: '#e0ffff',
  lightgoldenrodyellow: '#fafad2',
  lightgray: '#d3d3d3',
  lightgrey: '#d3d3d3',
  lightgreen: '#90ee90',
  lightpink: '#ffb6c1',
  lightsalmon: '#ffa07a',
  lightseagreen: '#20b2aa',
  lightskyblue: '#87cefa',
  lightslategray: '#778899',
  lightslategrey: '#778899',
  lightsteelblue: '#b0c4de',
  lightyellow: '#ffffe0',
  lime: '#00ff00',
  limegreen: '#32cd32',
  linen: '#faf0e6',
  magenta: '#ff00ff',
  maroon: '#800000',
  mediumaquamarine: '#66cdaa',
  mediumblue: '#0000cd',
  mediumorchid: '#ba55d3',
  mediumpurple: '#9370db',
  mediumseagreen: '#3cb371',
  mediumslateblue: '#7b68ee',
  mediumspringgreen: '#00fa9a',
  mediumturquoise: '#48d1cc',
  mediumvioletred: '#c71585',
  midnightblue: '#191970',
  mintcream: '#f5fffa',
  mistyrose: '#ffe4e1',
  moccasin: '#ffe4b5',
  navajowhite: '#ffdead',
  navy: '#000080',
  oldlace: '#fdf5e6',
  olive: '#808000',
  olivedrab: '#6b8e23',
  orange: '#ffa500',
  orangered: '#ff4500',
  orchid: '#da70d6',
  palegoldenrod: '#eee8aa',
  palegreen: '#98fb98',
  paleturquoise: '#afeeee',
  palevioletred: '#db7093',
  papayawhip: '#ffefd5',
  peachpuff: '#ffdab9',
  peru: '#cd853f',
  pink: '#ffc0cb',
  plum: '#dda0dd',
  powderblue: '#b0e0e6',
  purple: '#800080',
  rebeccapurple: '#663399',
  red: '#ff0000',
  rosybrown: '#bc8f8f',
  royalblue: '#4169e1',
  saddlebrown: '#8b4513',
  salmon: '#fa8072',
  sandybrown: '#f4a460',
  seagreen: '#2e8b57',
  seashell: '#fff5ee',
  sienna: '#a0522d',
  silver: '#c0c0c0',
  skyblue: '#87ceeb',
  slateblue: '#6a5acd',
  slategray: '#708090',
  slategrey: '#708090',
  snow: '#fffafa',
  springgreen: '#00ff7f',
  steelblue: '#4682b4',
  tan: '#d2b48c',
  teal: '#008080',
  thistle: '#d8bfd8',
  tomato: '#ff6347',
  turquoise: '#40e0d0',
  violet: '#ee82ee',
  wheat: '#f5deb3',
  white: '#ffffff',
  whitesmoke: '#f5f5f5',
  yellow: '#ffff00',
  yellowgreen: '#9acd32',
  transparent: '#00000000'
};

;// CONCATENATED MODULE: ./src/base/globals.ts
var _Foundation = (/* unused pure expression or super */ null && (Foundation));
function getReporter() {
  return Reporter;
}

;// CONCATENATED MODULE: ./src/base/performance/traceReporter.ts


function argsToString(args) {
  if (typeof args !== 'string') {
    return JSON.stringify(args || {});
  }
  return args;
}
var REPORT_DELAY = 1000;
var reportTimer = null;
var reportCache = [];
var needReportTrace = false;
var needReportApi = false;
var needTraceApi = env_IS_DEVTOOLS || !isReleaseBuild();
var needTraceApiCallbacks = [];
function doReport() {
  reportTimer = null;
  if (reportCache.length === 0) return;
  WeixinJSBridge.invoke('reportKeyValue', {
    version: 2,
    dataArray: reportCache.map(event => ({
      key: 26308,
      value: [event.category, event.name, Math.round(event.timeStamp * 1000), event.phase, encodeURIComponent(argsToString(event.args))].join(',')
    }))
  });
  reportCache = [];
}
base_WXConfig.onReady(config => {
  var _config$expt;
  var expt = (_config$expt = config.expt) === null || _config$expt === void 0 ? void 0 : _config$expt.clicfg_appbrand_report_trace_event;
  if (expt === '1') {
    needReportTrace = true;
  } else if (expt === '2') {
    needReportTrace = true;
    needReportApi = true;
  }
  needTraceApi = needTraceApi || needReportApi || !!debugEnabled();
  if (needTraceApi) {
    var _needTraceApiCallback;
    (_needTraceApiCallback = needTraceApiCallbacks) === null || _needTraceApiCallback === void 0 ? void 0 : _needTraceApiCallback.forEach(fn => fn());
  }
  needTraceApiCallbacks = null;
});
function invokeTraceEvent(phase, event) {
  var evt = {
    ...event,
    phase
  };
  evt.args = argsToString(evt.args);
  WeixinJSBridge.invoke('traceEvent', {
    events: [evt]
  });
}
function reportTraceKV(phase, event) {
  if (!needReportApi && event.category === 'API') return;
  if (!reportTimer) reportTimer = setTimeout(doReport, REPORT_DELAY);
  reportCache.push({
    ...event,
    phase
  });
}
function reportTraceIfNeeded(phase, event) {
  if (env_IS_DEVTOOLS) invokeTraceEvent(phase, event);
  if (needReportTrace) reportTraceKV(phase, event);
}
function getNeedTraceApi() {
  return needTraceApi;
}
function onNeedTraceApi(fn) {
  if (needTraceApiCallbacks === null) {
    if (needTraceApi) fn();
  } else {
    needTraceApiCallbacks.push(fn);
  }
}
;// CONCATENATED MODULE: ./src/base/performance/trace.ts


var hasPerformance = false;
function now() {
  if (hasPerformance) {
    var _performance$timing;
    return performance.now() + (performance.timeOrigin || ((_performance$timing = performance.timing) === null || _performance$timing === void 0 ? void 0 : _performance$timing.navigationStart) || 0);
  } else {
    return Date.now();
  }
}
var traceStartListeners = {};
var traceEndListeners = {};
function addTraceStartListener(category, listener) {
  traceStartListeners[category] || (traceStartListeners[category] = []);
  traceStartListeners[category].push(listener);
}
function addTraceEndListener(category, listener) {
  traceEndListeners[category] || (traceEndListeners[category] = []);
  traceEndListeners[category].push(listener);
}
function createTracer(id) {
  var tracingEvents = [];
  function traceBeginEvent(category, name, args, bindingOnly = false) {
    var _traceStartListeners$;
    Trace.traceBegin(category, name);
    if (bindingOnly) return;
    var evt = {
      category,
      name,
      timeStamp: now(),
      args: args || {}
    };
    tracingEvents.push(evt);
    if (category === 'Framework') wxNativeConsole.info(`[Trace][B] ${name} @ ${evt.timeStamp} ${evt.args.path || ''}`);
    (_traceStartListeners$ = traceStartListeners[evt.category]) === null || _traceStartListeners$ === void 0 ? void 0 : _traceStartListeners$.forEach(fn => fn(evt, id));
    reportTraceIfNeeded('B', evt);
    wxPerfConsole.traceBegin(category, name, args);
  }
  function traceEndEvent(args, bindingOnly = false) {
    var _evt$args, _traceEndListeners$ev;
    Trace.traceEnd();
    if (bindingOnly) return;
    var endT = now();
    wxPerfConsole.traceEnd();
    var evt = tracingEvents.pop();
    if (!evt) {
      wxNativeConsole.error('[Trace] Must call traceBeginEvent before traceEndEvent.');
      getReporter().assertWithIDKey(false, 6);
      getReporter().errorReport({
        key: 'appServiceSDKScriptError',
        error: new Error(`traceEndEvent mismatch, args=${JSON.stringify(args || {})}`)
      });
      return;
    }
    var startArgs = evt.args;
    var startTime = evt.timeStamp;
    evt.timeStamp = endT;
    evt.args = args || evt.args;
    if (evt.category === 'Framework') wxNativeConsole.info(`[Trace][E] ${evt.name} @ ${evt.timeStamp} ${((_evt$args = evt.args) === null || _evt$args === void 0 ? void 0 : _evt$args.path) || ''}`);
    (_traceEndListeners$ev = traceEndListeners[evt.category]) === null || _traceEndListeners$ev === void 0 ? void 0 : _traceEndListeners$ev.forEach(fn => fn(evt, startTime, startArgs, id));
    reportTraceIfNeeded('E', evt);
  }
  function useTraced(category, name, fn, perfArgs) {
    return function traceFn(...args) {
      try {
        traceBeginEvent(category, name, perfArgs);
        return fn.apply(this, args);
      } finally {
        traceEndEvent();
      }
    };
  }
  function useTracedApi(name, fn, perfArgs) {
    return function traceFn(...args) {
      try {
        traceBeginAPI(name, perfArgs);
        return fn.apply(this, args);
      } finally {
        traceEndAPI();
      }
    };
  }
  function useTracedApiEnd(fn) {
    return function traceFn(...args) {
      try {
        return fn.apply(this, args);
      } finally {
        traceEndAPI();
      }
    };
  }
  function useTracedEnd(fn) {
    return function traceFn(...args) {
      try {
        return fn(...args);
      } finally {
        traceEndEvent();
      }
    };
  }
  function traceFlag(category, name, args) {
    var _traceStartListeners$2, _traceEndListeners$ca;
    var timeStamp = now();
    var evt = {
      category,
      name,
      timeStamp,
      args: args || {}
    };
    Trace.traceInstant(category, name);
    if (category === 'Framework') wxNativeConsole.info(`[Trace][I] ${name} @ ${timeStamp}`);
    (_traceStartListeners$2 = traceStartListeners[category]) === null || _traceStartListeners$2 === void 0 ? void 0 : _traceStartListeners$2.forEach(fn => fn(evt, id));
    reportTraceIfNeeded('B', evt);
    wxPerfConsole.traceBegin(category, name, args);
    wxPerfConsole.traceEnd();
    reportTraceIfNeeded('E', evt);
    (_traceEndListeners$ca = traceEndListeners[category]) === null || _traceEndListeners$ca === void 0 ? void 0 : _traceEndListeners$ca.forEach(fn => fn(evt, timeStamp, args, id));
  }
  function traceBeginAPI(name, args) {
    traceBeginEvent('API', name, args, getNeedTraceApi());
  }
  function traceEndAPI() {
    traceEndEvent(undefined, getNeedTraceApi());
  }
  return {
    traceBeginEvent,
    traceEndEvent,
    traceBeginAPI,
    traceEndAPI,
    useTraced,
    useTracedEnd,
    traceFlag,
    useTracedApi,
    useTracedApiEnd
  };
}
var DEFAULT_TRACER_ID = Infinity;
/* harmony default export */ const trace = (createTracer(DEFAULT_TRACER_ID));
;// CONCATENATED MODULE: ./src/baseView/resize.js

var latestResizeInfo = null;
var resizeTimeoutObj = false;
var preloadChecked = false;
var SCHEDULE_RESIZE = 'scheduleResize';
var scheduleResize = info => {
  latestResizeInfo = info;
  if (resizeTimeoutObj) return;
  resizeTimeoutObj = true;
  var invoked = false;
  var fn = () => {
    if (invoked) return;
    invoked = true;
    resizeTimeoutObj = false;
    if (typeof beforeWindowResizeFunc === 'function') {
      beforeWindowResizeFunc(latestResizeInfo);
    }
    BaseMethods_Emitter.emit(SCHEDULE_RESIZE, latestResizeInfo);
  };
  setTimeout(fn, 16);
  requestAnimationFrame(fn);
};
var resizeEventCb = (info, force) => {
  var preloadChecking = !preloadChecked;
  preloadChecked = true;
  if (!force && info.pageOrientation) {
    var originalPageOrientation = info.pageOrientation.originalPageOrientation;
    if (preloadChecking && originalPageOrientation === 'landscape' && info.size.windowWidth > info.size.windowHeight) {} else if (preloadChecking && (originalPageOrientation || 'portrait') === 'portrait' && info.size.windowWidth < info.size.windowHeight) {} else if (originalPageOrientation === 'auto' || info.pageOrientation.setPageOrientation) {} else {
      return;
    }
  }
  scheduleResize(info);
};
onMethod('onViewDidResize', info => {
  resizeEventCb(info, false);
});
onMethod('onAppRouteResized', info => {
  resizeEventCb(info, true);
});
var _simulateWindowResize = (width, height) => {
  scheduleResize({
    size: {
      windowWidth: width,
      windowHeight: height
    }
  });
};
var beforeWindowResizeFunc;
var beforeWindowResize = func => {
  beforeWindowResizeFunc = func;
};
var onWindowResize = func => {
  BaseMethods_Emitter.on(SCHEDULE_RESIZE, func);
};
var offWindowResize = func => {
  Emitter.off(SCHEDULE_RESIZE, func);
};
var getPageOrientation = () => {
  var info = latestResizeInfo;
  if (!info) return null;
  var pageOrientation = latestResizeInfo.deviceOrientation;
  var screenWidth = latestResizeInfo.size.windowWidth;
  var screenHeight = latestResizeInfo.size.windowHeight;
  return pageOrientation || (screenWidth > screenHeight ? 'landscape' : 'portrait');
};
;// CONCATENATED MODULE: ./src/base/type.js
var Object$$toString = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Object.prototype.toString)()));
var TO_STRING = /* #__PURE__ */(/* unused pure expression or super */ null && (Function.prototype.call.bind(Object$$toString)));
function getDataType(data) {
  return TO_STRING(data).slice(8, -1);
}
function safeInstanceOf(x, constructor) {
  if (x == null) return false;
  return x instanceof constructor || x.constructor != null && x.constructor.name === constructor.name;
}
var isString = x => getDataType(x) === 'String';
var isNumber = x => getDataType(x) === 'Number';
var isBoolean = x => x === true || x === false || getDataType(x) === 'Boolean';
var isUndefined = x => x === undefined;
var isNull = x => x === null;
var type_isNaN = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Number.isNaN || (x => x !== x))()));
var type_isFinite = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Number.isFinite || (x => isNumber(x) && __webpack_require__.g.isFinite(x)))()));
var isInfinity = x => isNumber(x) && Math.abs(x) === Infinity;
var isInteger = value => type_isFinite(value) && Math.floor(value) === value;
var isBasicValue = x => ['string', 'number', 'boolean', 'undefined'].includes(typeof x);
var type_isObject = x => getDataType(x) === 'Object';
var isNonNullObject = x => type_isObject(x) && !isNull(x);
var isJustObject = x => getDataType(x) === 'Object';
var isArray = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Array.isArray || (x => getDataType(x) === 'Array'))()));
var isFunction = x => typeof x === 'function';
var isDate = x => getDataType(x) === 'Date';
var isRegExp = x => getDataType(x) === 'RegExp';
var isError = x => getDataType(x) === 'Error';
var isSymbol = x => getDataType(x) === 'Symbol';
var isMap = x => getDataType(x) === 'Map';
var isWeakMap = x => getDataType(x) === 'WeakMap';
var isSet = x => getDataType(x) === 'Set';
var isWeakSet = x => getDataType(x) === 'WeakSet';
var isPromise = x => getDataType(x) === 'Promise';
var isEmptyObject = x => {
  for (var p in x) return false;
  return true;
};
var isArrayBuffer = x => getDataType(x) === 'ArrayBuffer';
var isDataView = x => getDataType(x) === 'DataView';
var isTypedArray = x => ArrayBuffer.isView(x) && !isDataView(x);
var isVirtualNode = x => x && x.type === 'WxVirtualNode';
var isVirtualText = x => x && x.type === 'WxVirtualText';
function paramCheck(value, expect, dept = 'parameter') {
  var type = getDataType(expect);
  var valueType = getDataType(value);
  if (valueType !== type) {
    return `${dept} should be ${type} instead of ${valueType};`;
  }
  var result = '';
  switch (type) {
    case 'Object':
      Object.keys(expect).forEach(key => {
        result += paramCheck(value[key], expect[key], `${dept}.${key}`);
      });
      break;
    case 'Array':
      if (value.length < expect.length) {
        return `${dept} should have at least ${expect.length} item;`;
      }
      for (var i = 0; i < expect.length; ++i) {
        result += paramCheck(value[i], expect[i], `${dept}[${i}]`);
      }
      break;
    case 'String':
      if (expect.length > 0 && value.length === 0) {
        return `${dept} should be not empty string`;
      }
      break;
    default:
      break;
  }
  return result;
}
function safelyToString(value) {
  try {
    return JSON.stringify(value);
  } catch (e) {
    wxConsole.error(`safelyToString fail: '${e.message}'`);
    return '';
  }
}
function noop() {}
;// CONCATENATED MODULE: ./src/baseView/invokeAppServiceMethod.ts



var callbackId = 0;
var callbackList = [];
var invokeHooksList = [];
var invokeAppServiceMethod = ({
  type = 'wx',
  name,
  args = {},
  ext = {},
  pluginId = ''
}) => {
  callbackList[callbackId] = {
    success: args.success || noop,
    fail: args.fail || noop,
    complete: args.complete || noop
  };
  invokeHooksList[callbackId] = {
    beforeAll: ext.beforeAll || noop,
    beforeSuccess: ext.beforeSuccess || noop,
    afterSuccess: ext.afterSuccess || noop,
    beforeFail: ext.beforeFail || noop,
    afterFail: ext.afterFail || noop,
    afterAll: ext.afterAll || noop
  };
  BaseMethods_publish('invokeAppServiceMethod', {
    name,
    type,
    args,
    callbackId,
    pluginId
  });
  callbackId += 1;
};
var invokeAppServiceMethodAsync = ({
  type = 'wx',
  name,
  args = {},
  ext = {}
}) => invoke2Async(args => invokeAppServiceMethod({
  type,
  name,
  args: args,
  ext
}))(args);
BaseMethods_subscribe('callbackAppServiceMethod', ({
  res,
  isSuccess,
  callbackId
}) => {
  var callbacks = callbackList[callbackId];
  var invokeHooks = invokeHooksList[callbackId];
  invokeHooks === null || invokeHooks === void 0 ? void 0 : invokeHooks.beforeAll(res);
  if (isSuccess) {
    invokeHooks === null || invokeHooks === void 0 ? void 0 : invokeHooks.beforeSuccess(res);
    callbacks.success(res);
    invokeHooks === null || invokeHooks === void 0 ? void 0 : invokeHooks.afterSuccess(res);
  } else {
    invokeHooks === null || invokeHooks === void 0 ? void 0 : invokeHooks.beforeFail(res);
    callbacks.fail(res);
    invokeHooks === null || invokeHooks === void 0 ? void 0 : invokeHooks.afterFail(res);
  }
  callbacks.complete(res);
  invokeHooks === null || invokeHooks === void 0 ? void 0 : invokeHooks.afterAll(res);
});

;// CONCATENATED MODULE: ./src/webview/utils.js

function getRealRoute(lastRoute = '', relativeRoute = '') {
  var res;
  if (relativeRoute.indexOf('/') === 0) {
    res = relativeRoute.substr(1);
  } else if (relativeRoute.indexOf('./') === 0) {
    res = getRealRoute(lastRoute, relativeRoute.substr(2));
  } else {
    var relativeRouteParts = relativeRoute.split('/');
    var i;
    var len;
    for (i = 0, len = relativeRouteParts.length; i < len; i++) {
      if (relativeRouteParts[i] !== '..') {
        break;
      }
    }
    relativeRouteParts.splice(0, i);
    relativeRoute = relativeRouteParts.join('/');
    var lastRouteParts = lastRoute.length > 0 ? lastRoute.split('/') : [];
    lastRouteParts.splice(lastRouteParts.length - i - 1, i + 1);
    var finalRouteParts = lastRouteParts.concat(relativeRouteParts);
    var finalRoute = finalRouteParts.join('/');
    res = finalRoute;
  }
  return res;
}
function formatLengthArg(value) {
  if (typeof value === 'number') {
    return `${value}px`;
  } else {
    return value;
  }
}
function formatAngleArg(value) {
  return `${value}deg`;
}
function animationToStyle({
  animates,
  option = {}
}) {
  var {
    transformOrigin,
    transition
  } = option;
  if (typeof transition === 'undefined' || typeof animates === 'undefined') {
    return {
      transformOrigin: '',
      transform: '',
      transition: ''
    };
  }
  var transform = animates.filter(({
    type
  }) => type !== 'style').map(({
    type,
    args
  }) => {
    switch (type) {
      case 'matrix':
        return `matrix(${args.join(',')})`;
      case 'matrix3d':
        return `matrix3d(${args.join(',')})`;
      case 'rotate':
        args = args.map(formatAngleArg);
        return `rotate(${args[0]})`;
      case 'rotate3d':
        args[3] = formatAngleArg(args[3]);
        return `rotate3d(${args.join(',')})`;
      case 'rotateX':
        args = args.map(formatAngleArg);
        return `rotateX(${args[0]})`;
      case 'rotateY':
        args = args.map(formatAngleArg);
        return `rotateY(${args[0]})`;
      case 'rotateZ':
        args = args.map(formatAngleArg);
        return `rotateZ(${args[0]})`;
      case 'scale':
        return `scale(${args.join(',')})`;
      case 'scale3d':
        return `scale3d(${args.join(',')})`;
      case 'scaleX':
        return `scaleX(${args[0]})`;
      case 'scaleY':
        return `scaleY(${args[0]})`;
      case 'scaleZ':
        return `scaleZ(${args[0]})`;
      case 'translate':
        args = args.map(formatLengthArg);
        return `translate(${args.join(',')})`;
      case 'translate3d':
        args = args.map(formatLengthArg);
        return `translate3d(${args.join(',')})`;
      case 'translateX':
        args = args.map(formatLengthArg);
        return `translateX(${args[0]})`;
      case 'translateY':
        args = args.map(formatLengthArg);
        return `translateY(${args[0]})`;
      case 'translateZ':
        args = args.map(formatLengthArg);
        return `translateZ(${args[0]})`;
      case 'skew':
        args = args.map(formatAngleArg);
        return `skew(${args.join(',')})`;
      case 'skewX':
        args = args.map(formatAngleArg);
        return `skewX(${args[0]})`;
      case 'skewY':
        args = args.map(formatAngleArg);
        return `skewY(${args[0]})`;
      default:
        return '';
    }
  }).join(' ');
  var style = animates.filter(({
    type
  }) => type === 'style').reduce((pre, cur) => {
    pre[cur.args[0]] = cur.args[1];
    return pre;
  }, {});
  var transitionProperty = ['transform', ...Object.keys(style)].join(',');
  return {
    style,
    transformOrigin,
    transform,
    transitionProperty,
    transition: `${transition.duration}ms ${transition.timingFunction} ${transition.delay}ms`
  };
}
function isiOS8() {
  if (typeof window === 'undefined' || typeof window.navigator === 'undefined') return false;
  var userAgent = window.navigator.userAgent;
  return (/OS 8_/.test(userAgent) || /Version\/8/.test(userAgent)) && IS_IOS;
}
function parseErrMsg(str) {
  var matches = str.match(/(.+?):([-_a-z0-9]+)(?= |:|$)/i);
  if (!matches) {
    return {
      methods: '',
      state: '',
      detail: ''
    };
  }
  var method = matches[1];
  var state = matches[2];
  var detail = str.slice(matches[0].length + 1);
  return {
    method,
    state,
    detail
  };
}
class WebviewSdkKnownError extends Error {
  constructor(msg) {
    super(`Webview-SDK:${msg}`);
    this.type = 'WebviewSdkKnownError';
  }
}
var getWxmlVersionTag = fieldName => {
  var wxmlVersionInfo = window.__wcc_version_info__;
  if (!wxmlVersionInfo) return undefined;
  return wxmlVersionInfo[fieldName];
};
var getDOMContent = type => {
  if (type === 1) return document.body.innerText;else if (type === 2) return document.body.innerHTML;else if (type === 3) return document.body.textContent;
  return false;
};
var loadLibFilesToWebview = files => {
  if (!Array.isArray(files)) {
    files = [files];
  }
  return new Promise((r, rj) => {
    __webpack_require__.g.WeixinJSBridge.invoke('loadLibFiles', {
      paths: files
    }, res => {
      r();
    });
  });
};
;// CONCATENATED MODULE: ./src/baseView/invokeViewMethod.ts

var viewMethods = Object.create(null);
var invokeViewMethod = (name, args, callback) => {
  var func = viewMethods[name];
  if (typeof func !== 'function') {
    wxNativeConsole.error(`No such viewMethod "${name}" found. Ignored.`);
    return;
  }
  func(args, res => {
    callback(res);
  });
};
BaseMethods_subscribe('invokeWebviewMethod', ({
  name,
  args,
  callbackId
}) => {
  invokeViewMethod(name, args, res => {
    BaseMethods_publish('callbackWebviewMethod', {
      res,
      callbackId
    });
  });
});
var registerViewMethod = (name, func, force = false) => {
  if (!force && viewMethods[name]) {
    wxNativeConsole.warn(`viewMethod '${name}' is registered. If it meets expectations, please ignore this warning.`);
  }
  viewMethods[name] = func;
};
;// CONCATENATED MODULE: ./src/baseView/utils.ts
function utils_parseErrMsg(str) {
  var matches = str.match(/(.+?):([-_a-z0-9]+)(?= |:|$)/i);
  if (!matches) {
    return {
      methods: '',
      state: '',
      detail: ''
    };
  }
  var method = matches[1];
  var state = matches[2];
  var detail = str.slice(matches[0].length + 1);
  return {
    method,
    state,
    detail
  };
}
;// CONCATENATED MODULE: ./src/baseView/GlobalStorage/namespaces.js
var GLOBAL_STORAGE_NAMESPACES = {
  '': '',
  EXIT_STATE: 'exitState',
  PLUGIN_PERMISSION_BYTES: 'pluginPermissionBytes',
  COOKIES: 'cookies',
  SUBJECT_CHANGE: 'subjectChange',
  RISK_WARNING: 'riskWarning',
  REQUEST_PAYMENT: 'requestPayment',
  PATCH_WRONG_QUERY: 'patchWrongQuery',
  REQUEST_SUBSCRIBE_DEVICE_MESSAGE: 'requestSubscribeDeviceMessage',
  COMMON_EXPT_CONFIG: 'commonExptConfig'
};
;// CONCATENATED MODULE: ./src/baseView/GlobalStorage/index.js



var STORAGE_HARD_LIMIT = 16 * 1024 * 1024;
var STORAGE_SOFT_LIMIT = 64 * 1024;
var STORAGE_CHECK_INTERVAL = 86400 * 1000;
var STORAGE_DEFAULT_TIMEOUT = 14 * 86400 * 1000;
var defaultCallback = () => {};
var approximateSize = 0;
var tryJsonParse = (str, defaultValue) => {
  try {
    return JSON.parse(str);
  } catch (e) {
    return defaultValue;
  }
};
var reportFailing = (msg, extend) => {
  wxNativeConsole.error(msg, extend, new Error().stack);
  Reporter.errorReport({
    key:  false ? 0 : 'appSubContextSDKScriptError',
    error: new Error(`${msg};${extend}`)
  });
};
var getGlobalStorage = (args, cb) => {
  BaseMethods_invoke('getGlobalStorage', args, cb || defaultCallback);
};
var setGlobalStorage = (args, cb) => {
  BaseMethods_invoke('setGlobalStorage', args, cb || defaultCallback);
};
var getGlobalStorageInfo = cb => {
  BaseMethods_invoke('getGlobalStorageInfo', {}, cb || defaultCallback);
};
var removeGlobalStorage = (args, cb) => {
  BaseMethods_invoke('removeGlobalStorage', args, cb || defaultCallback);
};
var getGlobalStorageBatch = (map, cb) => {
  cb = cb || defaultCallback;
  var keys = Object.keys(map);
  var i = 0;
  var next = () => {
    if (i === keys.length) {
      return cb();
    }
    var key = keys[i];
    getGlobalStorage({
      key
    }, res => {
      var errMsgInfo = utils_parseErrMsg(res.errMsg);
      if (errMsgInfo.state !== 'ok') {
        if (errMsgInfo.detail !== 'data not found') reportFailing('Failed get storage item while gabbage collection', res.errMsg);
      } else {
        map[key] = res.data;
      }
      i++;
      next();
    });
    return null;
  };
  next();
};
var removeGlobalStorageBatch = (keys, cb) => {
  cb = cb || defaultCallback;
  var i = 0;
  var next = () => {
    if (i === keys.length) {
      return cb();
    }
    removeGlobalStorage({
      key: keys[i]
    }, res => {
      var errMsgInfo = utils_parseErrMsg(res.errMsg);
      if (errMsgInfo.state !== 'ok') {
        reportFailing('Failed remove storage item while gabbage collection', res.errMsg);
      }
      i++;
      next();
    });
    return null;
  };
  next();
};
var globalStorageManager = {
  createOrGetStorageGroup(namespace, name, expireTime, cb) {
    var sg = new StorageGroup(namespace + ':' + name, expireTime);
    sg._prepare(cb || defaultCallback);
  },
  _setMetadata(data, cb) {
    setGlobalStorage({
      key: ':~',
      data: JSON.stringify(data)
    }, res => {
      var errMsgInfo = utils_parseErrMsg(res.errMsg);
      if (errMsgInfo.state !== 'ok') {
        reportFailing('Failed set storage metadata', res.errMsg);
      }
      cb(null, this);
    });
  },
  _logGlobalStorageInfo() {
    getGlobalStorageInfo(res => {
      wxConsole.log('GlobalStorageInfo', res);
    });
  },
  gabbageCollectCheck(cb) {
    wxConsole.log('checking global storage gabbage collection needed or not');
    getGlobalStorage({
      key: ':~'
    }, res => {
      var data = {
        lastGabbageCollectionCheckUnixTimestamp: 0
      };
      var errMsgInfo = utils_parseErrMsg(res.errMsg);
      if (errMsgInfo.state !== 'ok') {
        if (errMsgInfo.detail !== 'data not found') reportFailing('Failed get storage metadata while gabbage collection', res.errMsg);
      } else {
        data = tryJsonParse(res.data, data);
      }
      if (!(data.lastGabbageCollectionCheckUnixTimestamp * 1000 + STORAGE_CHECK_INTERVAL >= Date.now())) {
        data.lastGabbageCollectionCheckUnixTimestamp = Math.floor(Date.now() / 1000);
        globalStorageManager._setMetadata(data, () => {
          globalStorageManager.gabbageCollect(cb);
        });
      } else {
        return cb();
      }
      return null;
    });
  },
  gabbageCollect(cb) {
    wxConsole.log('triggering global storage gabbage collection');
    getGlobalStorageInfo(res => {
      var errMsgInfo = utils_parseErrMsg(res.errMsg);
      if (errMsgInfo.state !== 'ok') {
        reportFailing('Failed listing storage keys while gabbage collection', res.errMsg);
        return;
      }
      var deleteAll = false;
      if (res.currentSize * 1024 >= STORAGE_HARD_LIMIT) {
        reportFailing('Detected hard limit while gabbage collection', 'At size ' + res.currentSize);
        deleteAll = true;
      }
      var ts = Math.floor(Date.now() / 1000);
      var keys = res.keys || [];
      var keysToDel = [];
      var keyGroups = {};
      var groupMetadata = {};
      keys.forEach(wholeKey => {
        if (wholeKey === ':~') return;
        var [name] = wholeKey.split('::', 2);
        if (name === wholeKey) {
          var k = name;
          if (k.slice(-2) === ':~') groupMetadata[k] = '{}';else keysToDel.push(k);
        } else if (!keyGroups[name]) keyGroups[name] = [wholeKey];else keyGroups[name].push(wholeKey);
      });
      getGlobalStorageBatch(groupMetadata, () => {
        for (var k in groupMetadata) {
          var name = k.slice(0, -2);
          var expireUnixTimestamp = tryJsonParse(groupMetadata[k], {}).expireUnixTimestamp;
          if (deleteAll || !(expireUnixTimestamp > ts)) {
            var keyGroup = keyGroups[name];
            keysToDel.push(k);
            if (keyGroup) keysToDel.push(...keyGroup);
          }
        }
        for (var _name in keyGroups) {
          var _k = _name + ':~';
          if (groupMetadata[_k] === null || groupMetadata[_k] === undefined) {
            var _keyGroup = keyGroups[_name];
            if (_keyGroup) keysToDel.push(..._keyGroup);
          }
        }
        removeGlobalStorageBatch(keysToDel, cb);
      });
    });
  }
};
class StorageGroup {
  constructor(name, expireTime) {
    this._name = name;
    this._needUpdateExpireTime = !!expireTime;
    this._expireUnixTimestamp = Math.ceil((expireTime || Date.now() + STORAGE_DEFAULT_TIMEOUT) / 1000);
  }
  _prepare(cb) {
    getGlobalStorage({
      key: this._name + ':~'
    }, res => {
      var errMsgInfo = utils_parseErrMsg(res.errMsg);
      if (errMsgInfo.state !== 'ok') {
        if (errMsgInfo.detail !== 'data not found') reportFailing('Failed get storage group metadata', res.errMsg);
        this._setMetadata({
          expireUnixTimestamp: this._expireUnixTimestamp
        }, cb);
        return null;
      }
      var data = tryJsonParse(res.data, {
        expireUnixTimestamp: 0
      });
      if (data.expireUnixTimestamp <= Math.floor(Date.now() / 1000)) {
        globalStorageManager.gabbageCollect(() => {
          this._setMetadata({
            expireUnixTimestamp: this._expireUnixTimestamp
          }, cb);
        });
        return null;
      }
      if (this._needUpdateExpireTime) {
        this._setMetadata({
          expireUnixTimestamp: this._expireUnixTimestamp
        }, cb);
        return null;
      }
      return cb(null, this);
    });
  }
  _setMetadata(data, cb) {
    setGlobalStorage({
      key: this._name + ':~',
      data: JSON.stringify(data)
    }, () => {
      cb(null, this);
    });
  }
  get(key, cb) {
    cb = cb || defaultCallback;
    getGlobalStorage({
      key: this._name + '::' + key
    }, res => {
      var errMsgInfo = utils_parseErrMsg(res.errMsg);
      if (errMsgInfo.state !== 'ok') {
        if (errMsgInfo.detail === 'data not found') {
          return cb(null, undefined);
        }
        reportFailing('Failed get storage group data', res.errMsg);
        return cb(res.errMsg);
      }
      return cb(null, tryJsonParse(res.data, undefined));
    });
  }
  set(key, data, cb) {
    cb = cb || defaultCallback;
    var value = JSON.stringify(data);
    var doSetStorage = () => {
      setGlobalStorage({
        key: this._name + '::' + key,
        data: String(value)
      }, res => {
        var errMsgInfo = utils_parseErrMsg(res.errMsg);
        if (errMsgInfo.state !== 'ok') {
          reportFailing('Failed set storage group data', res.errMsg);
          return cb(res.errMsg);
        }
        return cb(null);
      });
    };
    approximateSize += value.length;
    if (approximateSize === value.length || approximateSize > STORAGE_SOFT_LIMIT) {
      globalStorageManager.gabbageCollectCheck(doSetStorage);
    } else {
      doSetStorage();
    }
  }
  delete(key, cb) {
    cb = cb || defaultCallback;
    removeGlobalStorage({
      key: this._name + '::' + key
    }, res => {
      var errMsgInfo = utils_parseErrMsg(res.errMsg);
      if (errMsgInfo.state !== 'ok') {
        reportFailing('Failed delete storage group data', res.errMsg);
        return cb(res.errMsg);
      }
      return cb(null);
    });
  }
}
;// CONCATENATED MODULE: ./src/baseView/Methods/cookie.js



var STORAGE_EXPIRE_TIME = 90 * 24 * 3600 * 1000;
var storageGroup = null;
var getPassCookieString = callback => {
  invokeAppServiceMethod({
    type: 'custom',
    name: 'getPassCookieString',
    args: {
      success: callback
    }
  });
};
var setToStorage = (args, cb) => {
  if (storageGroup) {
    storageGroup.set('cookies', args.cookies, err => {
      cb(err);
    });
  } else {
    globalStorageManager.createOrGetStorageGroup(GLOBAL_STORAGE_NAMESPACES.COOKIES, args.appId, Date.now() + STORAGE_EXPIRE_TIME, (err, sg) => {
      if (sg) {
        storageGroup = sg;
        setToStorage(args, cb);
      } else {
        cb(err);
      }
    });
  }
};
var getFromStorage = (args, cb) => {
  if (storageGroup) {
    storageGroup.get('cookies', (err, data) => {
      cb(data);
    });
  } else {
    globalStorageManager.createOrGetStorageGroup(GLOBAL_STORAGE_NAMESPACES.COOKIES, args.appId, Date.now() + STORAGE_EXPIRE_TIME, (err, sg) => {
      if (sg) {
        storageGroup = sg;
        getFromStorage(args, cb);
      } else {
        cb();
      }
    });
  }
};
registerViewMethod('setCookiesToGlobalStorage', (args, cb) => {
  setToStorage(args, cb);
});
registerViewMethod('getCookiesFromGlobalStorage', (args, cb) => {
  getFromStorage(args, cb);
});
;// CONCATENATED MODULE: ./src/webview/Methods/navigateToMiniProgram.js


var _doNavigateToMiniProgram = (args, privateArgs) => {
  var finalArgs = {
    ...args,
    ...privateArgs
  };
  var path;
  if (typeof finalArgs.path === 'string' && finalArgs.path.trim().length > 0) {
    path = (finalArgs.path || '').trim().replace(/(\?|$)/, '.html$1');
  }
  getPassCookieString(data => {
    var cookies = data.cookies;
    if (cookies) {
      finalArgs.privateExtraData = finalArgs.privateExtraData || {};
      finalArgs.privateExtraData.cookies = cookies;
    } else if (finalArgs.privateExtraData) {
      delete finalArgs.privateExtraData.cookies;
    }
    invokeAppServiceMethod({
      name: 'navigateToMiniProgram',
      type: 'bridge',
      args: {
        ...finalArgs,
        path
      },
      ext: {
        beforeSuccess() {
          invokeAppServiceMethod({
            type: 'custom',
            name: 'reportRecycledAPI',
            args: {
              name: 'navigateToMiniProgram',
              scene: 1
            }
          });
        }
      }
    });
  });
};
var navigateToMiniProgram = (args = {}) => {
  if (args.__noCheckBeforeNavigateToMiniProgram) {
    _doNavigateToMiniProgram(args);
    return;
  }
  invokeAppServiceMethod({
    name: '_checkBeforeNavigateToMiniProgram',
    type: 'custom',
    args: {
      appId: args.appId,
      path: args.path,
      shortLink: args.shortLink,
      success(res) {
        _doNavigateToMiniProgram(args, {
          appId: res.appId,
          path: res.path,
          sourcetype: res.sourcetype
        });
      },
      fail(res) {
        typeof args.fail === 'function' && args.fail(res);
        typeof args.complete === 'function' && args.complete(res);
      }
    }
  });
};

;// CONCATENATED MODULE: ./src/tunnel/VirtualDOM.js
var VDTunnelFactory = (publish, subscribe) => ({
  vdSync(data, viewIds) {
    publish('vdSync', data, viewIds);
  },
  vdSyncBatch(data, viewIds) {
    publish('vdSyncBatch', data, viewIds);
  },
  onVdSync(cb) {
    subscribe('vdSync', cb);
  },
  onVdSyncBatch(cb) {
    subscribe('vdSyncBatch', cb);
  }
});
;// CONCATENATED MODULE: ./src/scl/utils.ts
var {
  EventEmitter: utils_EventEmitter
} = Foundation;
var utils_Emitter = new utils_EventEmitter();
var listened = {};
var multicastSubscribe = subscribe => filter => (event, callback) => {
  if (!listened[event]) {
    subscribe(event, (res, pageId) => {
      utils_Emitter.emit(event, {
        res,
        pageId
      });
    });
    listened[event] = true;
  }
  utils_Emitter.on(event, ({
    res,
    pageId
  }) => {
    if (filter(res, pageId) === true) callback(res, pageId);
  });
};
;// CONCATENATED MODULE: ./src/base/util/object.js

function object_assign(...objects) {
  return objects.reduce((pre, cur) => {
    for (var key in cur) {
      pre[key] = cur[key];
    }
    return pre;
  }, {});
}
function extend(to, from) {
  for (var key in from) {
    to[key] = from[key];
  }
  return to;
}
var _hasOwnProperty = Object.prototype.hasOwnProperty;
function object_hasOwnProperty(obj, prop) {
  return _hasOwnProperty.call(obj, prop);
}
function renameProperty(object, oldName, newName) {
  if (isObject(object) === false || oldName === newName) {
    return;
  }
  if (object_hasOwnProperty(object, oldName)) {
    object[newName] = object[oldName];
    delete object[oldName];
  }
}
;// CONCATENATED MODULE: ./src/base/util/urls.js


function removeHtmlSuffixFromUrl(url) {
  if (typeof url === 'string') {
    if (url.indexOf('?') !== -1) {
      return url.replace(/\.html\?/, '?');
    } else {
      return url.replace(/\.html$/, '');
    }
  } else {
    return url;
  }
}
function transWxmlToHtml(url) {
  if (typeof url !== 'string') {
    return url;
  } else {
    var path = url.split('?')[0];
    var query = url.split('?')[1];
    path += '.html';
    if (typeof query !== 'undefined') {
      return `${path}?${query}`;
    } else {
      return path;
    }
  }
}
function parseUrl(url) {
  var urlObj = {
    protocol: /^(.+):\/\//,
    host: /:\/\/(.+?)[?#\s/]/,
    path: /\w(\/.*?)[?#\s]/,
    query: /\?(.+?)[#/\s]/,
    hash: /#(\w+)\s$/
  };
  url += ' ';
  function formatQuery(str) {
    return str.split('&').reduce((a, b) => {
      var arr = b.split('=');
      a[arr[0]] = arr[1];
      return a;
    }, {});
  }
  Object.keys(urlObj).forEach(key => {
    var pattern = urlObj[key];
    urlObj[key] = key === 'query' ? pattern.exec(url) && formatQuery(pattern.exec(url)[1]) : pattern.exec(url) && pattern.exec(url)[1];
  });
  return urlObj;
}
var deleteURLQuery = url => {
  if (typeof url === 'string') {
    var paramsIndex = url.indexOf('?');
    if (paramsIndex !== -1) return url.slice(0, paramsIndex);
  }
  return url;
};
function urlEncodeFormData(data, needEncode = false) {
  if (typeof data !== 'object') {
    return data;
  }
  var str = '';
  for (var k in data) {
    if (hasOwnProperty(data, k)) {
      if (needEncode) {
        try {
          str += `${encodeURIComponent(k)}=${encodeURIComponent(data[k])}&`;
        } catch (e) {
          str += `${k}=${data[k]}&`;
        }
      } else {
        str += `${k}=${data[k]}&`;
      }
    }
  }
  if (str) {
    str = str.slice(0, -1);
  }
  return str;
}
function getQueryString(url) {
  var obj = {};
  if (url.indexOf('?') > -1) {
    var start = url.indexOf('?') + 1;
    var str = url.substring(start);
    if (str.indexOf('#') > -1) {
      str = str.substring(0, str.indexOf('#'));
    }
    if (!str) return obj;
    var arr = str.split('&');
    for (var i = 0; i < arr.length; i++) {
      var arr2 = arr[i].split('=');
      obj[arr2[0]] = arr2[1];
    }
  }
  return obj;
}
var MagicNumber = (/* unused pure expression or super */ null && (-1928373));
function addQueryStringToUrl2(url, data) {
  var dataKeys = Object.keys(data);
  var startQuery = false;
  var querying = false;
  var curReplaceValue = MagicNumber;
  if (typeof url === 'string' && typeof data === 'object' && data !== null && dataKeys.length > 0) {
    var newUrl = '';
    var p;
    for (var i = 0; i < url.length; i++) {
      var c = url[i];
      if (!querying && startQuery) {
        if (curReplaceValue === MagicNumber) {
          newUrl += c;
          continue;
        }
        continue;
      }
      newUrl += c;
      if (c === '?' && !startQuery) {
        startQuery = true;
        querying = true;
        p = Array(dataKeys.length).fill(0);
        continue;
      }
      if (c === '&' && startQuery) {
        if (curReplaceValue !== MagicNumber) {
          newUrl += encodeURIComponent(curReplaceValue);
        } else curReplaceValue = MagicNumber;
        p = Array(dataKeys.length).fill(0);
        querying = true;
        continue;
      }
      if (startQuery && c === '=') {
        querying = false;
        for (var _i = 0; _i < p.length; _i++) {
          if (p[_i] !== false && p[_i] === dataKeys[_i].length) {
            curReplaceValue = data[dataKeys[_i]];
          }
        }
        continue;
      }
      if (querying) {
        var c1 = void 0;
        for (var _i2 = 0; _i2 < p.length; _i2++) {
          if (p[_i2] !== false) {
            c1 = true;
            var k = dataKeys[_i2];
            if (k[p[_i2]] !== c) p[_i2] = false;else p[_i2]++;
          }
        }
        if (!c1) p = [];
      }
    }
    if (!startQuery) newUrl += '?';else newUrl += '&';
    for (var _i3 = 0; _i3 < dataKeys.length; _i3++) {
      var key = dataKeys[_i3];
      newUrl += key + '=';
      newUrl += encodeURIComponent(data[key]);
    }
    return newUrl;
  }
  return url;
}
function addQueryStringToUrl(url, data) {
  var dataKeys = Object.keys(data);
  if (typeof url === 'string' && typeof data === 'object' && data !== null && dataKeys.length > 0) {
    var parts = url.split('?');
    var path = parts[0];
    var query = (parts[1] || '').split('&').reduce((pre, cur) => {
      if (typeof cur === 'string' && cur.length > 0) {
        var _parts = cur.split('=');
        var key = _parts[0];
        var value = _parts[1];
        pre[key] = value;
      }
      return pre;
    }, {});
    var encodedData = dataKeys.reduce((ret, key) => {
      if (typeof data[key] === 'object') {
        ret[encodeURIComponent(key)] = encodeURIComponent(JSON.stringify(data[key]));
      } else {
        ret[encodeURIComponent(key)] = encodeURIComponent(data[key]);
      }
      return ret;
    }, {});
    return path + '?' + urlEncodeFormData(assign(query, encodedData));
  } else {
    return url;
  }
}
function validateUrl(url, type = 'http') {
  if (type === 'http') {
    return /^(http|https):\/\/.*/i.test(url);
  } else if (type === 'websocket') {
    return /^(ws|wss):\/\/.*/i.test(url);
  }
  return undefined;
}
function encodeUrlQuery(url) {
  if (typeof url === 'string') {
    var parts = url.split('?');
    var path = parts[0];
    var query = (parts[1] || '').split('&').reduce((pre, cur) => {
      if (typeof cur === 'string' && cur.length > 0) {
        var _parts2 = cur.split('=');
        var key = _parts2[0];
        var value = _parts2[1];
        pre[key] = value;
      }
      return pre;
    }, {});
    var queryArray = [];
    for (var k in query) {
      if (hasOwnProperty(query, k)) {
        queryArray.push(`${k}=${encodeURIComponent(query[k])}`);
      }
    }
    if (queryArray.length > 0) {
      return `${path}?${queryArray.join('&')}`;
    } else {
      return url;
    }
  } else {
    return url;
  }
}
function hideInnerRequest(url) {
  if (!IS_DEVTOOLS || typeof url !== 'string') return url;
  if (/^https?:\/\//.test(url)) {
    var parts = url.split('?');
    var query = parts[1] || '';
    var sep = query.length > 0 ? '&' : '';
    url = `${parts[0]}?${query}${sep}devtools_ignore=true`;
  }
  return url;
}
;// CONCATENATED MODULE: ./src/webview/Methods/Contact.js




function insertContactButton(args) {
  invokeMethod('insertContactButton', args);
}
function updateContactButton(args) {
  invokeMethod('updateContactButton', args);
}
function removeContactButton(args) {
  invokeMethod('removeContactButton', args);
}
function invokeEnterContact(args, invokeArgs = {}) {
  invokeMethodAs(invokeArgs)('enterContact', args, {
    beforeSuccess(res) {
      if (res.path) {
        res.path = `/${removeHtmlSuffixFromUrl(res.path)}`;
      }
    }
  });
}
var getCurrentRoute = () => new Promise((resolve, reject) => {
  invokeAppServiceMethod({
    name: 'getCurrentRoute',
    type: 'custom',
    args: {
      success: ({
        currentRoute
      }) => {
        resolve(currentRoute);
      },
      fail: res => {
        reject(res);
      }
    }
  });
});
var getRealRouteWithProtocol = (lastRoute, relativeRoute, needTrans = true) => new Promise((resolve, reject) => {
  invokeAppServiceMethod({
    name: 'getRealRouteWithProtocol',
    type: 'custom',
    args: {
      lastRoute,
      relativeRoute,
      needTrans,
      success: ({
        route
      }) => {
        resolve(route);
      },
      fail: res => {
        reject(res);
      }
    }
  });
});
function enterContact(args = {}, invokeArgs = {}) {
  if (args.showMessageCard && (args.sendMessagePath || args.sendMessageImg)) {
    var currentRoute;
    var realArgs = Object.assign({}, args);
    getCurrentRoute().then(_currentRoute => {
      currentRoute = _currentRoute;
      if (args.sendMessagePath) return getRealRouteWithProtocol(currentRoute, args.sendMessagePath, true);else return undefined;
    }).then(realSendMessagePath => {
      realArgs.sendMessagePath = realSendMessagePath;
      if (args.sendMessageImg && !/^(http|https|wxfile):\/\//.test(args.sendMessageImg)) {
        return getRealRouteWithProtocol(currentRoute, args.sendMessageImg, false);
      } else {
        return args.sendMessageImg;
      }
    }).then(realSendMessageImg => {
      realArgs.sendMessageImg = realSendMessageImg;
      invokeEnterContact(realArgs, invokeArgs);
    }).catch(res => {
      typeof args.fail === 'function' && args.fail(res);
    });
  } else if (args.privateEnterContact) {
    invokeMethodAs(invokeArgs)('privateEnterContact', args);
  } else {
    invokeEnterContact(args, invokeArgs);
  }
}
registerViewMethod('appServiceEnterContact', (args, cb) => {
  args.complete = function (res) {
    cb && cb(res);
  };
  var newargs = Object.assign({
    sessionFrom: 'wxapp',
    businessId: '',
    sendMessageImg: '',
    sendMessageTitle: '',
    showMessageCard: false,
    sendMessagePath: ''
  }, args);
  enterContact(newargs);
});
registerViewMethod('quicklyAddBrandContact', (args, cb) => {
  args.complete = function (res) {
    if (res.errMsg) res.errMsg = res.errMsg.replace(/^private_/, '');
    cb && cb(res);
  };
  invokeMethod_invokeMethod('private_quicklyAddBrandContact', args);
});
;// CONCATENATED MODULE: ./src/scl/index.ts












var exportApi = {};
var wx = {
  invoke: BaseMethods_invoke,
  invokeAs: invokeAs,
  on: on,
  publish: BaseMethods_publish,
  publishAsPage: BaseMethods_publishAsPage,
  subscribe: BaseMethods_subscribe,
  subscribeAsPage: BaseMethods_subscribeAsPage,
  mainContext: {
    publish(...args) {
      Foundation.onLoad(() => {
        JSContext.publish(...args);
      });
    },
    subscribe(...args) {
      Foundation.onLoad(() => {
        JSContext.subscribe(...args);
      });
    }
  },
  onAppDataChange: callback => {
    registerViewMethod('appDataChange', (args, cb) => {
      callback(args, cb);
    });
  },
  transformRpx: style => style,
  traceBeginEvent: trace.traceBeginEvent,
  traceEndEvent: trace.traceEndEvent,
  useTraced: trace.useTraced,
  useTracedEnd: trace.useTracedEnd,
  traceFlag: trace.traceFlag,
  createTracer: createTracer,
  onWindowResize: onWindowResize,
  publishPageEvent: (eventName, data, nodeId, pageId) => {
    BaseMethods_publishAsPage(pageId)('PAGE_EVENT', {
      eventName,
      data,
      nodeId
    });
  },
  getRealRoute: getRealRoute,
  navigateToMiniProgram: navigateToMiniProgram,
  enterContact: enterContact,
  triggerPageReRender() {},
  onPageReRender(fn) {},
  offPageReRender(fn) {}
};
var directInvokeMethods = ['showDatePickerView', 'insertMap', 'removeMap', 'updateMapCovers', 'insertVideoPlayer', 'removeVideoPlayer', 'insertShareButton', 'updateShareButton', 'removeShareButton', 'setNavigationBarTitle', 'setNavigationBarColor', 'showNavigationBarLoading', 'hideNavigationBarLoading', 'setBackgroundTextStyle', 'setBackgroundColor', 'updatePerfData', 'traceEvent', 'webViewReadyToTerminate', 'saveInitialRenderingCache', 'navigateBackMiniProgram', 'setNavigationBarRightButton'];
directInvokeMethods.forEach(name => {
  wx[name] = (args, pageId) => {
    invokeMethodAs({
      pageId
    })(name, args);
  };
});
var appServiceMethods = {
  wx: ['login', 'getSetting', 'clearStorage', 'getSystemInfo', 'startCustomFacialRecognitionVerify', 'startCustomFacialRecognitionVerifyAndUploadVideo', 'saveImageToPhotosAlbum', 'setWxInterfaceDisabled'],
  bridge: ['getPermissionBytes', 'authorize', 'launchApplication', 'navigateBackApplication', 'navigateBackNative', 'operateVideoPlayer', 'operateLivePlayer', 'getLocation', 'downloadAppInternal', 'getInstallState', 'addDownloadTaskStraight', 'queryDownloadTask', 'installDownloadTask', 'pauseDownloadTask', 'resumeDownloadTask', 'cancelDownloadTask', 'writeCommData', 'getNetworkType', 'batchGetContact', 'showToast', 'hideToast', 'exitMiniProgram', 'openADCanvas', 'showActionSheet', 'preloadMiniProgramEnv', 'hideHomeButton', 'predownloadMiniProgramPackage', 'setTabBarStyle', 'batchPreloadMiniProgram', 'showModal'],
  custom: ['checkPermission', 'redirectTo', 'navigateTo', 'navigateToWithRelatedInfo', 'switchTab', 'reLaunch', 'navigateBack', 'shareImageMessage', 'setPrivateExtraData', 'chooseInvoice', 'chooseInvoiceTitle', 'getCurrentWebviewId']
};
Object.keys(appServiceMethods).forEach(type => {
  appServiceMethods[type].forEach(name => {
    wx[name] = args => {
      invokeAppServiceMethod({
        type: type,
        name,
        args
      });
    };
  });
});
function errorReport(e, extend) {
  if (Object.prototype.toString.apply(e) === '[object Error]') {
    Foundation.onLoad(() => {
      Reporter.errorReport({
        key: 'appSubContextThirdScriptError',
        error: e,
        extend
      });
    });
  } else {
    Reporter.errorReport({
      key: 'appSubContextThirdScriptError',
      error: e,
      extend
    });
  }
}
function surroundByTryCatch(key) {
  if (env_IS_DEVTOOLS) {
    exportApi[key] = wx[key];
    return;
  }
  Object.defineProperty(exportApi, key, {
    get() {
      if (typeof wx[key] !== 'function') {
        return wx[key];
      }
      return (...args) => {
        try {
          return wx[key](...args);
        } catch (e) {
          errorReport(e);
          return undefined;
        }
      };
    },
    enumerable: true,
    configurable: true
  });
}
Object.keys(wx).forEach(key => {
  surroundByTryCatch(key);
});
var subscribeForVd = multicastSubscribe(BaseMethods_subscribe);
var _exports = {
  wx: exportApi,
  createVDTunnel: pageId => VDTunnelFactory(BaseMethods_publishAsPageSync(pageId), subscribeForVd((res, _pageId) => _pageId === pageId)),
  traceBeginEvent: trace.traceBeginEvent,
  traceEndEvent: trace.traceEndEvent,
  predefinedColor: predefinedColor
};
/* harmony default export */ const scl = (_exports);
__sclSDK__ = __webpack_exports__["default"];
/******/ })()

var wx=__sclSDK__.wx;;
var __userActionTracer__;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  convertClassList: () => (/* reexport */ convertClassList),
  getTextContentMaxLayer: () => (/* reexport */ getTextContentMaxLayer),
  getTextContentMaxLength: () => (/* reexport */ getTextContentMaxLength),
  limitContent: () => (/* reexport */ limitContent),
  setActionChainReportTypes: () => (/* reexport */ setActionChainReportTypes),
  shouldReportEvent: () => (/* reexport */ shouldReportEvent)
});

;// CONCATENATED MODULE: ./src/userActionTrace/utils/vd/convert.js
var convertClassList = classList => {
  try {
    if (Object.prototype.toString.call(classList) !== '[object Array]') return [];
    return classList.join(',');
  } catch (err) {
    return '';
  }
};
var limitContent = (content, textContentMaxLength) => {
  if (typeof content !== 'string') return null;
  if (content.length > 30) content = content.slice(0, textContentMaxLength);
  return content;
};

;// CONCATENATED MODULE: ./src/userActionTrace/utils/vd/variable.js
var actionChainReportTypes = {};
var textContentMaxLayer = 3;
var textContentMaxLength = 30;
var setActionChainReportTypes = data => {
  if (data && typeof data === 'object') {
    actionChainReportTypes = data.eventType || {};
    textContentMaxLayer = data.textContentMaxLayer !== undefined ? data.textContentMaxLayer : 3;
    textContentMaxLength = data.textContentMaxLength !== undefined ? data.textContentMaxLength : 30;
  }
};
var getTextContentMaxLayer = () => textContentMaxLayer;
var getTextContentMaxLength = () => textContentMaxLength;
var shouldReportEvent = type => actionChainReportTypes[type];

;// CONCATENATED MODULE: ./src/userActionTrace/webview-index.js


__userActionTracer__ = __webpack_exports__;
/******/ })()
;
var __virtualDOM__;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  SKYLINE_TABBAR_VIEW_ID: () => (/* reexport */ SKYLINE_TABBAR_VIEW_ID),
  addIntersectionObserver: () => (/* reexport */ addIntersectionObserver),
  addMediaQueryObserver: () => (/* reexport */ addMediaQueryObserver),
  applyInitialRenderingCache: () => (/* reexport */ applyInitialRenderingCache),
  beginTapMark: () => (/* reexport */ beginTapMark),
  callRestoredLifeTimes: () => (/* reexport */ callRestoredLifeTimes),
  callSavedLifeTimes: () => (/* reexport */ callSavedLifeTimes),
  checkTapMark: () => (/* reexport */ checkTapMark),
  customComponentMode: () => (/* binding */ customComponentMode),
  dispatchViewRoute: () => (/* reexport */ dispatchViewRoute),
  enableUpdateWxAppCode: () => (/* reexport */ enableUpdateWxAppCode),
  endTapMark: () => (/* reexport */ endTapMark),
  getComponentCount: () => (/* reexport */ getComponentCount),
  getDomTreeByPageId: () => (/* reexport */ getDomTreeByPageId),
  getEntryFile: () => (/* reexport */ getEntryFile),
  getMergeDataFunc: () => (/* binding */ getMergeDataFunc),
  getNodeById: () => (/* reexport */ getNodeById),
  getNodeId: () => (/* reexport */ getNodeId),
  getPageId: () => (/* reexport */ getPageId),
  getPluginRoutePrefix: () => (/* reexport */ getPluginRoutePrefix),
  getRestoreState: () => (/* binding */ getRestoreState),
  getRootCompName: () => (/* reexport */ getRootCompName),
  getRootNode: () => (/* reexport */ getRootNode),
  getRootNodeId: () => (/* reexport */ getRootNodeId),
  getSubPackagePlugin: () => (/* reexport */ getSubPackagePlugin),
  getWorkletIdByName: () => (/* reexport */ getWorkletIdByName),
  isPageExist: () => (/* binding */ isPageExist),
  isShowCustomTabBarByConfig: () => (/* reexport */ isShowCustomTabBarByConfig),
  isSubPackageIndependent: () => (/* reexport */ isSubPackageIndependent),
  matchSubPackageName: () => (/* reexport */ matchSubPackageName),
  newPage: () => (/* reexport */ newPage),
  newTabBar: () => (/* reexport */ newTabBar),
  prepareInitRender: () => (/* binding */ prepareInitRender),
  prepareSubPackagesStyle: () => (/* reexport */ prepareSubPackagesStyle),
  removeIntersectionObserver: () => (/* reexport */ removeIntersectionObserver),
  removeMediaQueryObserver: () => (/* reexport */ removeMediaQueryObserver),
  setEventHandlerChangeListener: () => (/* reexport */ setEventHandlerChangeListener),
  setModelValueData: () => (/* reexport */ setModelValueData),
  setPageType: () => (/* reexport */ setPageType),
  spreadScopeDataToDOMNode: () => (/* reexport */ spreadScopeDataToDOMNode),
  startInitRender: () => (/* binding */ startInitRender),
  updateWxAppCode: () => (/* reexport */ updateWxAppCode),
  viewThreadHideTabBar: () => (/* reexport */ viewThreadHideTabBar),
  viewThreadShowTabBar: () => (/* reexport */ viewThreadShowTabBar),
  wrapTapMark: () => (/* reexport */ wrapTapMark)
});

;// CONCATENATED MODULE: ./src/global.js
var __exparser = typeof exparser !== 'undefined' ? exparser : {};
var renderBackend =  false ? 0 : 'webview';
if (typeof __useSclExparser__ !== 'undefined' && __useSclExparser__ && typeof __sclEngine__ !== 'undefined') {
  renderBackend = 'scl';
}
if (typeof __skylineEngine__ !== 'undefined') {
  renderBackend = 'skyline';
}
if (typeof xrFrame !== 'undefined') {
  renderBackend = 'xr-frame';
}
if (renderBackend === 'scl') {
  __exparser = __sclEngine__.exparser || __exparser || {};
} else if (renderBackend === 'skyline') {
  __exparser = __skylineEngine__.getRuntime().getExparser() || __exparser || {};
} else if (renderBackend === 'xr-frame') {
  __exparser = xrFrame.getExparser() || __exparser || {};
}
var getExparser = () => __exparser;
var getSkylineRuntime = () => __skylineEngine__.getRuntime();
var getSkylineRuntimeCore = () => __skylineEngine__.RuntimeCore;
var currentRenderBackend = () => renderBackend;
var tracer;
var setTracer = t => tracer = t;
var traceInstant = (c, e) => {
  var _tracer, _tracer2;
  if (!tracer) return;
  (_tracer = tracer) === null || _tracer === void 0 ? void 0 : _tracer.traceBeginEvent(c, e);
  (_tracer2 = tracer) === null || _tracer2 === void 0 ? void 0 : _tracer2.traceEndEvent();
};
var getSDK = () => {
  if (false) {} else if (typeof __webViewSDK__ !== 'undefined') {
    return __webViewSDK__;
  } else if (typeof __sclSDK__ !== 'undefined') {
    return __sclSDK__;
  } else if (typeof __skylineSDK__ !== 'undefined') {
    return __skylineSDK__;
  } else if (typeof __xrFrameSDK__ !== 'undefined') {
    return __xrFrameSDK__;
  }
};
var getGlassEaselAdapter = () => __glassEaselAdapter__;
var getSubContextEngine = () => __subContextEngine__;
var getAppServiceSDK = () => __appServiceSDK__;
var getWeixinJSBridge = () => WeixinJSBridge;
;// CONCATENATED MODULE: ./src/utils/utils.js

var utils_exparser = getExparser();
var PROTOCOL = /^[-+a-z]+:\/\//i;
var utils_pathRelative = function (base, name) {
  if (PROTOCOL.test(name)) return name;
  var protocolMatch = base.match(PROTOCOL);
  var protocol = '';
  if (protocolMatch) {
    protocol = protocolMatch[0];
    base = base.slice(protocol.length);
  }
  if (name.indexOf('/') === 0) base = '';
  var baseSlices = base.split('/');
  baseSlices.pop();
  var slices = name.split('/');
  while (slices.length) {
    var slice = slices.shift();
    if (slice === '' || slice === '.') continue;
    if (slice === '..') {
      baseSlices.pop();
      continue;
    }
    baseSlices.push(slice);
  }
  return protocol + baseSlices.join('/');
};
var isObject = x => typeof x === 'object' && x !== null;
var isEmptyObject = x => {
  for (var p in x) {
    return false;
  }
  return true;
};
var isUndefined = x => Object.prototype.toString.call(x) === '[object Undefined]';
var isNull = x => Object.prototype.toString.call(x) === '[object Null]';
var isString = x => Object.prototype.toString.call(x) === '[object String]';
var isArray = x => {
  if (Array.isArray) {
    return Array.isArray(x);
  } else {
    return Object.prototype.toString.call(x) === '[object Array]';
  }
};
var getPrototype = value => {
  if (Object.getPrototypeOf) {
    return Object.getPrototypeOf(value);
  } else if (value.constructor) {
    return value.constructor.prototype;
  } else {
    return undefined;
  }
};
var getDataType = data => Object.prototype.toString.call(data).split(' ')[1].split(']')[0];
var getWxmlVersionTag = fieldName => {
  var wxmlVersionInfo = (typeof window === 'undefined' ? __webpack_require__.g : window).__wcc_version_info__;
  if (!wxmlVersionInfo) return undefined;
  return wxmlVersionInfo[fieldName];
};
var utils_guid = () => Math.floor((1 + Math.random()) * 0x100000000).toString(16).slice(1);
var utils_objectValues = obj => Object.keys(obj).map(k => obj[k]);
var utils_dfsComponents = (node, shadowRootOrder, cb) => {
  if (node instanceof utils_exparser.Component) {
    if (shadowRootOrder > 0) cb(node);
    if (shadowRootOrder && node.shadowRoot instanceof utils_exparser.Element) {
      utils_dfsComponents(node.shadowRoot, shadowRootOrder, cb);
    }
    if (shadowRootOrder < 0) cb(node);
  }
  var children = node.childNodes;
  for (var i = 0; i < children.length; i++) {
    if (children[i] instanceof utils_exparser.Element) utils_dfsComponents(children[i], shadowRootOrder, cb);
  }
};
var speedReport = (key, start, end, data) => {
  Reporter.speedReport({
    key,
    timeMark: {
      startTime: start,
      endTime: end
    },
    force: key !== 'reRenderTime',
    data
  });
};
var utils_deepCopySerializable = x => {
  if (x === null || x === undefined) return x;
  var type = typeof x;
  if (type === 'string' || type === 'number' || type === 'boolean') return x;
  if (Array.isArray(x)) {
    var arr = Array(x.length);
    for (var i = 0; i < x.length; ++i) {
      arr[i] = utils_deepCopySerializable(x[i]);
      if (arr[i] === undefined) arr[i] = null;
    }
    return arr;
  }
  if (type === 'object') {
    var obj = {};
    var keys = Object.keys(x);
    for (var _i = 0; _i < keys.length; ++_i) {
      obj[keys[_i]] = utils_deepCopySerializable(x[keys[_i]]);
      if (obj[keys[_i]] === undefined) delete obj[keys[_i]];
    }
    return obj;
  }
  return undefined;
};
var createPublishSubscribe = tags => {
  var status = {};
  tags.forEach(tag => {
    status[tag] = {
      ok: false,
      callbacks: []
    };
  });
  return {
    notify(tag) {
      if (!status[tag]) return;
      status[tag].ok = true;
      status[tag].callbacks.forEach(cb => cb());
      status[tag].callbacks = [];
    },
    on(tag, cb) {
      if (!status[tag]) return;
      if (status[tag].ok) cb();else status[tag].callbacks.push(cb);
    },
    isNotified(tag) {
      return status[tag] && status[tag].ok;
    }
  };
};
var unique = arr => Array.from(new Set(arr));
;// CONCATENATED MODULE: ./src/comp_api/node_id.js


var node_id_exparser = getExparser();
class nodeIdManager {
  constructor() {
    this._idNodeMap = {};
  }
  getAll() {
    return this._idNodeMap;
  }
  getNodeById(id) {
    return this._idNodeMap[id];
  }
  getNodeId(node) {
    return node.__wxTmplId;
  }
  allocNodeId(node, assignId) {
    var id = assignId || utils_guid();
    node.__wxTmplId = id;
    this._idNodeMap[node.__wxTmplId] = node;
    return id;
  }
  addNode() {}
  removeNode(node) {
    if (node.__wxTmplId) delete this._idNodeMap[node.__wxTmplId];
    if (node.childNodes) {
      for (var i = 0; i < node.childNodes.length; i++) {
        this.removeNode(node.childNodes[i]);
      }
    }
    if (node.shadowRoot instanceof node_id_exparser.Element) this.removeNode(node.shadowRoot);
  }
}
/* harmony default export */ const node_id = (nodeIdManager);
;// CONCATENATED MODULE: external ["BabelRuntimeHelpers","asyncToGenerator"]
const external_BabelRuntimeHelpers_asyncToGenerator_namespaceObject = BabelRuntimeHelpers.asyncToGenerator;
var external_BabelRuntimeHelpers_asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(external_BabelRuntimeHelpers_asyncToGenerator_namespaceObject);
;// CONCATENATED MODULE: ./src/constants/constants.js
var RPX_RATE = 20;
var BASE_DEVICE_WIDTH = 750;
var constants_SYNC_EVENT_NAME = {
  WX_EVENT: 11,
  REQUEST_SAVE: 12,
  COMPONENT_DEF: 21,
  SAVE_STATE: 22,
  RESTORE_STATE: 23,
  FLOW_INITIAL_RENDERING_CACHE: 24,
  FLOW_CLEAR_INITIAL_RENDERING_CACHE: 25,
  FLOW_SET_SUBPACKAGE_LOADED: 26,
  SET_DATA_CALLBACK: 32,
  FLOW_SET_DATA: 33,
  FLUSH_BLOCKED: 43,
  FLOW_GROUP: 41,
  FLOW_GROUP_END: 42,
  FLOW_DEPTH: 2,
  FLOW_INITIAL_CREATION: 3,
  FLOW_UPDATE: 6,
  FLOW_DATA_OBSERVER: 8,
  FLOW_APPLY_PROPERTY: 4,
  FLOW_MINIPULATE_CHILD: 7,
  FLOW_CREATE_NODE: 5,
  FLOW_REPEAT: 9,
  FLOW_VIEW_INFO: 63,
  REQUEST_TAB: 51,
  COMPONENT_DEF_TAB: 52,
  FLOW_CREATE_TAB: 53,
  DESTROY_TAB: 54,
  FLOW_DESTROY_PAGE: 55,
  SHOW_TAB: 56,
  HIDE_TAB: 57,
  SCL_CONTEXT_READY: 58,
  REQUEST_BROADCAST_VIEW_ID: 61,
  RESPONSE_BROADCAST_VIEW_ID: 62,
  BANNING_MAP: 90,
  CALL_METHOD_FROM_WXS: 50,
  RESPONSE_VIEW_INFO: 64,
  MODEL_VALUE_CHANGE: 65,
  FLOW_SET_NODE_ANIMATION_INFO: 100,
  ANIMATION_TRANSITION_END: 101,
  FLOW_CLEAR_NODE_ANIMATION_INFO: 102,
  CLEAR_ANIMATION_COMPLETE: 103,
  FLOW_SET_NODE_NEXT_ANIMATION_INFO: 104,
  LOAD_COMPONENT_DEF: 110,
  FLOW_WAIT_COMPONENT: 112,
  FLOW_REPLACE_PLACEHOLDER: 113,
  FLOW_PEND_PLACEHOLDER_REPLACEMENT: 114,
  FLOW_COMPONENT_DEF_ADD: 120,
  FLOW_INJECT_SUBPACKAGE: 121,
  FLOW_INJECT_COMPONENT: 122,
  FLOW_HOT_UPDATE: 900,
  FLOW_HOT_UPDATE_CHILD: 901,
  FLOW_HOT_UPDATE_RESET: 902,
  UPDATE_COMPONENT_DEF: 903,
  UPDATE_PERFORMANCE_STAT: 800,
  ENABLE_UPDATE_PERFORMANCE_STAT: 801,
  DISABLE_UPDATE_PERFORMANCE_STAT: 802,
  ENABLE_GLOBAL_UPDATE_PERFORMANCE_STAT: 803,
  REQUEST_WORKLET_METHOD: 200,
  RESPONSE_WORKLET_METHOD: 201,
  FLOW_SET_NODE_ANIMATED_STYLE: 202,
  FLOW_CLEAR_NODE_ANIMATED_STYLE: 203,
  APPLY_NODE_ANIMATED_STYLE_END: 204,
  CLEAR_NODE_ANIMATED_STYLE_END: 205,
  XR_FRAME_CANVAS_CREATED: 300,
  XR_FRAME_CANVAS_READY: 301,
  FLOW_SET_ROOT_PROPERTIES: 302,
  XR_FRAME_COMP_OPTIONS: 303
};
var SYNC_EVENT_NAME_REVERSE_MAP = {};
Object.keys(constants_SYNC_EVENT_NAME).forEach(ev => {
  SYNC_EVENT_NAME_REVERSE_MAP[constants_SYNC_EVENT_NAME[ev]] = ev;
});
var getEvName = ev => SYNC_EVENT_NAME_REVERSE_MAP[ev] || `UNKNOWN_EVENT_${ev}`;
var STYLE_SEGMENT_INDEX = {
  ATTR: 0,
  ANIMATION: 1,
  WXS_STYLE: 2
};
;// CONCATENATED MODULE: ./src/tabbar_manager.ts
var _CustomTabBarManager;



var SKYLINE_TABBAR_VIEW_ID = 4294967297;
var SCL_TABBAR_VIEW_ID = 4294967298;
var TABBAR_COMP_NAME = 'custom-tab-bar/index';
class CustomTabBarManager {
  constructor() {
    this.__instances = void 0;
    this.__instances = new Map();
  }
  add(pageId, renderType, tabBarTreeManager) {
    this.__instances.set(pageId, {
      tm: tabBarTreeManager,
      renderType
    });
  }
  get(pageId) {
    var ret = this.__instances.get(pageId);
    if (!ret) {
      wxNativeConsole.warn(`[customTabBarManager] pageId: ${pageId} TabBar is not exists`);
    }
    return ret;
  }
  remove(pageId) {
    this.__instances.delete(pageId);
  }
  has(pageId) {
    return this.__instances.has(pageId);
  }
  getRenderType(pageId) {
    var _this$__instances$get;
    return ((_this$__instances$get = this.__instances.get(pageId)) === null || _this$__instances$get === void 0 ? void 0 : _this$__instances$get.renderType) || 'webview';
  }
}
_CustomTabBarManager = CustomTabBarManager;
CustomTabBarManager.MANAGER = void 0;
var getCustomTabBarManager = () => {
  if (!CustomTabBarManager.MANAGER) {
    CustomTabBarManager.MANAGER = new CustomTabBarManager();
  }
  return CustomTabBarManager.MANAGER;
};
var destroyCustomTabBarManager = () => {
  CustomTabBarManager.MANAGER = null;
};
var getCustomTabBarRendererByPageId = pageId => {
  var renderer = getPageType(pageId);
  return renderer;
};
var getCustomTabBarRendererByConfig = pagePath => {
  var _wxConfig, _wxConfig$tabBar, _wxConfig2, _wxConfig2$tabBar;
  var renderer = ((_wxConfig = __wxConfig) === null || _wxConfig === void 0 ? void 0 : (_wxConfig$tabBar = _wxConfig.tabBar) === null || _wxConfig$tabBar === void 0 ? void 0 : _wxConfig$tabBar.renderer) || 'webview';
  if (Array.isArray((_wxConfig2 = __wxConfig) === null || _wxConfig2 === void 0 ? void 0 : (_wxConfig2$tabBar = _wxConfig2.tabBar) === null || _wxConfig2$tabBar === void 0 ? void 0 : _wxConfig2$tabBar.list)) {
    var list = __wxConfig.tabBar.list;
    for (var i = 0; i < list.length; i++) {
      var item = list[i];
      if (item.pagePath === `${pagePath}.html`) {
        if (typeof item.renderer === 'string') renderer = item.renderer;
        break;
      }
    }
  }
  wxNativeConsole.info(`[CustomTabBar] getCustomTabBarRenderer pagePath: ${pagePath}, renderer: ${renderer}`);
  if (renderer === 'cover-view') return 'scl';
  return renderer || 'webview';
};
var isShowCustomTabBarByConfig = pagePath => {
  var _wxConfig3, _wxConfig3$tabBar;
  if (Array.isArray((_wxConfig3 = __wxConfig) === null || _wxConfig3 === void 0 ? void 0 : (_wxConfig3$tabBar = _wxConfig3.tabBar) === null || _wxConfig3$tabBar === void 0 ? void 0 : _wxConfig3$tabBar.list)) {
    var list = __wxConfig.tabBar.list;
    for (var i = 0; i < list.length; i++) {
      var item = list[i];
      if (item.pagePath === `${pagePath}.html`) {
        if (item.hide) return false;
        return true;
      }
    }
  }
  return false;
};
var useCustomTabBar = () => {
  var _wxConfig4, _wxConfig4$tabBar;
  return !!((_wxConfig4 = __wxConfig) !== null && _wxConfig4 !== void 0 && (_wxConfig4$tabBar = _wxConfig4.tabBar) !== null && _wxConfig4$tabBar !== void 0 && _wxConfig4$tabBar.custom);
};
var tabbar_manager_checkPageIncludingTabBar = (tm, rootCompName, viewId) => {
  var _wxConfig5, _wxConfig5$tabBar;
  var needRemove = true;
  var list = (_wxConfig5 = __wxConfig) === null || _wxConfig5 === void 0 ? void 0 : (_wxConfig5$tabBar = _wxConfig5.tabBar) === null || _wxConfig5$tabBar === void 0 ? void 0 : _wxConfig5$tabBar.list;
  if (Array.isArray(list)) {
    var names = list.map(item => item === null || item === void 0 ? void 0 : item.pagePath).filter(item => !!item);
    if (names.indexOf(`${rootCompName}.html`) >= 0) {
      needRemove = false;
    }
  }
  wxNativeConsole.info(`[checkPageIncludingTabBar] rootCompName=${rootCompName}, viewId=${viewId}, needRemove=${needRemove}`);
  if (needRemove && bridge_getPageType(`${viewId}`) !== 'skyline') {
    tm.tabDestroyed = true;
    hideTabBar(viewId);
  }
};
var viewThreadShowTabBar = () => {
  var renderer = currentRenderBackend();
  if (renderer === 'skyline') {
    var _TAB_BAR__, _TAB_BAR__$__domEleme;
    ;
    (_TAB_BAR__ = window.__TAB_BAR__) === null || _TAB_BAR__ === void 0 ? void 0 : (_TAB_BAR__$__domEleme = _TAB_BAR__.__domElement) === null || _TAB_BAR__$__domEleme === void 0 ? void 0 : _TAB_BAR__$__domEleme.setStyle('pointer-events: none; display: flex;');
  } else if (renderer === 'scl') {
    __sclEngine__.showTabBarContainer();
  }
};
var viewThreadHideTabBar = () => {
  var renderer = currentRenderBackend();
  if (renderer === 'skyline') {
    var _TAB_BAR__2, _TAB_BAR__2$__domElem;
    ;
    (_TAB_BAR__2 = window.__TAB_BAR__) === null || _TAB_BAR__2 === void 0 ? void 0 : (_TAB_BAR__2$__domElem = _TAB_BAR__2.__domElement) === null || _TAB_BAR__2$__domElem === void 0 ? void 0 : _TAB_BAR__2$__domElem.setStyle('pointer-events: none; display: none;');
  } else if (renderer === 'scl') {
    __sclEngine__.hideTabBarContainer();
  } else if (renderer === 'webview') {
    if (window.__TAB_BAR__) window.__TAB_BAR__.parentNode.removeChild(window.__TAB_BAR__);
  }
};
var showTabBar = pageId => {
  var manager = getCustomTabBarManager();
  var instance = manager.get(pageId);
  var renderType = instance === null || instance === void 0 ? void 0 : instance.renderType;
  var id = (() => {
    if (renderType === 'skyline') {
      return SKYLINE_TABBAR_VIEW_ID;
    } else if (renderType === 'scl') {
      return SCL_TABBAR_VIEW_ID;
    }
    return pageId;
  })();
  sendData(SYNC_EVENT_NAME.SHOW_TAB, {}, id);
};
var hideTabBar = pageId => {
  var manager = getCustomTabBarManager();
  var instance = manager.get(pageId);
  var renderType = instance === null || instance === void 0 ? void 0 : instance.renderType;
  if (renderType === 'webview') {
    bridge_sendData(constants_SYNC_EVENT_NAME.DESTROY_TAB, [], pageId);
    return;
  }
  var id = (() => {
    if (renderType === 'skyline') {
      return SKYLINE_TABBAR_VIEW_ID;
    } else if (renderType === 'scl') {
      return SCL_TABBAR_VIEW_ID;
    }
    return pageId;
  })();
  bridge_sendData(constants_SYNC_EVENT_NAME.HIDE_TAB, {}, id);
};
var showTabBarByRenderer = renderType => {
  var id = (() => {
    if (renderType === 'skyline') {
      return SKYLINE_TABBAR_VIEW_ID;
    } else if (renderType === 'scl') {
      return SCL_TABBAR_VIEW_ID;
    }
    return null;
  })();
  if (id === null) return;
  sendData(SYNC_EVENT_NAME.SHOW_TAB, {}, id);
};
;// CONCATENATED MODULE: ./src/bridge.js



var funcs = {};
var bootstrapReceived = -1;
var bootstrapFunc = null;
var isInDevtoolsWebview = false;
var isDataThread = () => false;
var inDevtoolsWebview = () => isInDevtoolsWebview;
var setInDevtoolsWebView = () => {
  isInDevtoolsWebview = true;
};
var SPLIT_TIME = 15;
var vdSyncBuffer = [];
var bufferViewId = null;
var timer = null;
var isBuffer = false;
var pageType = {
  [SKYLINE_TABBAR_VIEW_ID]: 'skyline',
  [SCL_TABBAR_VIEW_ID]: 'scl'
};
var tunnels = {};
var pageListeners = {};
var bridge_destroyedPage = new Set();
var recvData = (_data, pageId) => {
  var data = (() => {
    if (!isDataThread() && currentRenderBackend() === 'webview' || isDataThread() && pageType[pageId] === 'webview' || !isDataThread() && currentRenderBackend() === 'scl' || isDataThread() && pageType[pageId] === 'scl') return _data;
    if (!isDataThread() && currentRenderBackend() === 'xr-frame' || isDataThread() && pageType[pageId] === 'xr-frame') return [..._data];
    return _data.map(x => utils_deepCopySerializable(x));
  })();
  var ev = data.shift();
  if (ev === '') {
    bootstrapReceived = pageId;
    if (bootstrapFunc) bootstrapFunc(pageId);
    return;
  }
  pageId = pageId || 0;
  if (currentRenderBackend() === 'webview') pageId = 0;
  triggerListenerFunc(pageId, ev, data);
};
var triggerListenerFunc = (pageId, ev, data) => {
  var _pageListeners$pageId;
  var func = null;
  if (funcs[pageId]) func = funcs[pageId][ev];
  if (!func && funcs.$GLOBAL) {
    if (isDataThread() && bridge_destroyedPage.has(pageId)) {
      return;
    }
    func = funcs.$GLOBAL[ev];
  }
  if (!func && currentRenderBackend() === 'skyline' && !((_pageListeners$pageId = pageListeners[pageId]) !== null && _pageListeners$pageId !== void 0 && _pageListeners$pageId.isReady)) {
    if (!pageListeners[pageId]) {
      pageListeners[pageId] = {
        queue: [],
        isReady: false
      };
    }
    pageListeners[pageId].queue.push({
      ev,
      data
    });
    return;
  }
  if (func) func(data, ev, pageId);else wxNativeConsole.error(`[VD] recvData no handler for event=${ev}, pageId=${pageId}`);
};
var flushDataBuffer = () => {
  if (timer) timer = clearTimeout(timer);
  if (vdSyncBuffer.length) {
    tunnels[bufferViewId].vdSyncBatch(vdSyncBuffer, bufferViewId && [bufferViewId]);
  }
  bufferViewId = null;
  vdSyncBuffer = [];
  isBuffer = false;
};
var bridge_sendData = (ev, data, pageId, isForce) => {
  data = [ev].concat(data);
  if (pageType[pageId] !== 'webview') {
    if (!tunnels[pageId]) {
      wxNativeConsole.warn(`pageId: ${pageId}, ev: ${ev}. Ignore sendData cause Page is removed. `);
      return;
    }
    tunnels[pageId].vdSync(data, pageId && [pageId]);
    return;
  } else if (pageType[pageId] === 'webview' && !isDataThread()) {
    pageId = 0;
  }
  if (!isBuffer || isForce) {
    flushDataBuffer();
    isBuffer = true;
    tunnels[pageId].vdSync(data, pageId && [pageId]);
    return;
  }
  if (bufferViewId !== pageId) {
    flushDataBuffer();
  }
  bufferViewId = pageId;
  vdSyncBuffer.push(data);
  isBuffer = true;
  if (timer) return;
  timer = setTimeout(() => {
    timer = null;
    flushDataBuffer();
  }, SPLIT_TIME);
};
var registerTunnel = tunnel => {
  if (tunnel.__registered) return;
  tunnel.__registered = true;
  tunnel.onVdSync((queue, pageId) => {
    if (pageType[pageId] === undefined) setPageType(pageId, 'webview');
    recvData(queue, pageId);
  });
  tunnel.onVdSyncBatch((queue, pageId) => {
    if (pageType[pageId] === undefined) setPageType(pageId, 'webview');
    for (var i = 0; i < queue.length; i++) {
      recvData(queue[i], pageId);
    }
  });
};
var setTunnel = () => {
  registerTunnel(getSDK()._virtualDOMTunnel);
};
if (isDataThread()) {
  if (typeof __clientsubcontext !== 'undefined' && __clientsubcontext) {
    __subContextEngine__.onInitReady(setTunnel);
  } else {
    setTunnel();
  }
}
var setPageType = (pageId, type) => {
  var _tunnels$pageId;
  if ((_tunnels$pageId = tunnels[pageId]) !== null && _tunnels$pageId !== void 0 && _tunnels$pageId.__registered && pageType[pageId] === type) return;
  pageType[pageId] = type;
  if (isDataThread()) {
    tunnels[pageId] = getSDK()._virtualDOMTunnel;
  } else {
    if (type === 'webview') tunnels[pageId] = getSDK()._virtualDOMTunnel;else tunnels[pageId] = getSDK().createVDTunnel(pageId);
    registerTunnel(tunnels[pageId]);
  }
};
var bridge_getPageType = pageId => pageType[pageId];
var removeTunnels = pageId => {
  delete pageType[pageId];
  delete tunnels[pageId];
};
var setDataListener = (ev, func, pageId) => {
  if (isDataThread() && pageId === undefined) return;
  if (ev === '') {
    bootstrapFunc = func;
    if (bootstrapReceived >= 0) bootstrapFunc(bootstrapReceived);
    return;
  }
  pageId = pageId || 0;
  if (!funcs[pageId]) funcs[pageId] = {};
  funcs[pageId][ev] = func;
};
var bridge_removeDataListeners = pageId => {
  delete funcs[pageId];
};
var viewThreadListeners = {};
var setListenerOnNewPage = (ev, fn) => {
  viewThreadListeners[ev] = fn;
};
var setListenersForNewPage = pageId => {
  Object.keys(viewThreadListeners).forEach(ev => {
    setDataListener(ev, viewThreadListeners[ev], pageId);
  });
  if (pageListeners[pageId]) {
    pageListeners[pageId].isReady = true;
    pageListeners[pageId].queue.forEach(({
      ev,
      data
    }) => {
      triggerListenerFunc(pageId, ev, data);
    });
    pageListeners[pageId].queue = [];
  }
};
;// CONCATENATED MODULE: ./src/utils/resize.js

var resize_exparser = getExparser();
var resizerNodes = {};
var resizerNodeArrIdInc = 1;
var initResizerNode = node => {
  var resizerNodeArrId = resizerNodeArrIdInc++;
  resizerNodes[resizerNodeArrId] = node;
  var observer = resize_exparser.Observer.create(e => {
    if (e.status === 'detached') {
      delete resizerNodes[resizerNodeArrId];
    }
  });
  observer.observe(node, {
    attachStatus: true
  });
};
var registerResizer = (node, resizerIndex, func) => {
  if (node.__resizers !== undefined) {
    node.__resizers[resizerIndex] = func;
    return;
  }
  node.__resizers = [];
  initResizerNode(node);
  node.__resizers[resizerIndex] = func;
};
var unregisterResizer = (node, resizerIndex) => {
  if (node.__resizers === undefined) return;
  node.__resizers[resizerIndex] = undefined;
};
var registerResizeListener = () => {
  wx.onWindowResize(({
    size
  }) => {
    var args = {
      width: size.windowWidth,
      height: size.windowHeight
    };
    if (window.__rpxRecalculatingFuncs__) {
      window.__rpxRecalculatingFuncs__.forEach(func => {
        func(args);
      });
      if (currentRenderBackend() === 'webview') {
        var styles = document.getElementsByTagName('style');
        for (var i = 0; i < styles.length; i++) {
          if (typeof styles[i].getAttribute('wxss:path') === 'string') {
            styles[i].innerHTML = styles[i].innerHTML + '.wx-trigger-chrome-media-query-update { height: ' + Math.random() + 'px; }';
          }
        }
      }
    }
    for (var _i of Object.keys(resizerNodes)) {
      var node = resizerNodes[_i];
      node.__resizers.forEach(func => {
        if (func) func(args);
      });
    }
  });
};
;// CONCATENATED MODULE: ./src/ban.js




var ban_exparser = getExparser();
var bannedPluginInfoMap = null;
var bannedCompDef = null;
var initBannedMap = map => {
  if (Object.keys(map).length === 0) return;
  bannedPluginInfoMap = map;
  TreeManager.listViewId().forEach(viewId => {
    sendData(SYNC_EVENT_NAME.BANNING_MAP, [map], viewId);
  });
};
var ban_sendBannedMap = viewId => {
  if (!bannedPluginInfoMap) return;
  sendData(SYNC_EVENT_NAME.BANNING_MAP, [bannedPluginInfoMap], viewId);
};
var banComponentNode = node => {
  node.$$.style.display = 'none';
};
var appendShadowBannedHint = (shadowRoot, info) => {
  if (!bannedCompDef) {
    bannedCompDef = ban_exparser.registerElement({
      options: {
        renderingMode: 'native'
      }
    });
  }
  var elem = shadowRoot.createComponent('wx-hint', bannedCompDef);
  var div = document.createElement('div');
  div.innerText = info.hint;
  elem.$$.appendChild(div);
  shadowRoot.appendChild(elem, shadowRoot.childNodes[0]);
};
var banNode = node => {
  var dfsChildren = node => {
    if (node instanceof ban_exparser.Component) {
      banComponentNode(node);
    } else if (node instanceof ban_exparser.VirtualNode) {
      node.childNodes.forEach(node => {
        dfsChildren(node);
      });
    } else if (node instanceof ban_exparser.TextNode) {
      node.textContent = '';
    }
    node.__banned = true;
  };
  dfsChildren(node);
};
var banShadowRoot = (shadowRoot, info) => {
  banNode(shadowRoot);
  appendShadowBannedHint(shadowRoot, info);
};
var checkAndBanComponent = node => {
  if (!bannedPluginInfoMap) return;
  var domain = ban_exparser.Component.getComponentOptions(node).domain;
  var pluginId = domain.split('/', 1)[0];
  var shadowRoot = node.shadowRoot;
  if (bannedPluginInfoMap[pluginId]) {
    banShadowRoot(shadowRoot, bannedPluginInfoMap[pluginId]);
  }
};
var receivedBannedMap = map => {
  if (bannedPluginInfoMap) return;
  bannedPluginInfoMap = map;
  var dfsNodes = root => {
    if (root instanceof ban_exparser.Component) {
      var domain = ban_exparser.Component.getComponentOptions(root).domain;
      if (domain !== '//') {
        var pluginId = domain.split('/', 1)[0];
        var shadowRoot = root.shadowRoot;
        if (bannedPluginInfoMap[pluginId]) {
          banShadowRoot(shadowRoot, bannedPluginInfoMap[pluginId]);
        } else {
          dfsNodes(shadowRoot);
        }
      }
    }
    if (root instanceof ban_exparser.Element) {
      root.childNodes.forEach(node => {
        dfsNodes(node);
      });
    }
  };
  dfsNodes(window.__DOMTree__);
};
var initBannedListener = () => {
  setDataListener(constants_SYNC_EVENT_NAME.BANNING_MAP, ([map]) => {
    receivedBannedMap(map);
  });
};
;// CONCATENATED MODULE: ./src/data_manager/merger.js

var merger_exparser = getExparser();
var merger_hasOwnProperty = Object.prototype.hasOwnProperty;
var deepCopy = merger_exparser.dataUtils.deepCopy;
var mergeData = (data, changes, changedValues, withDeepCopy) => {
  for (var i = 0; i < changes.length; i++) {
    var changeInfo = changes[i];
    var path = changeInfo[0];
    var newData = changeInfo[1];
    var curData = data;
    var curSlice = path[0];
    for (var j = 1; j < path.length; j++) {
      var nextSlice = path[j];
      if (typeof nextSlice === 'number' && Math.isFinite(nextSlice)) {
        if (!merger_hasOwnProperty.call(curData, curSlice) || !(curData[curSlice] instanceof Array)) {
          curData[curSlice] = [];
        }
      } else if (!merger_hasOwnProperty.call(curData, curSlice) || curData[curSlice] === null || typeof curData[curSlice] !== 'object' || curData[curSlice] instanceof Array) {
        curData[curSlice] = {};
      }
      curData = curData[curSlice];
      curSlice = nextSlice;
    }
    var oldData = curData[curSlice];
    curData[curSlice] = withDeepCopy ? deepCopy(newData) : newData;
    changedValues[i] = [curData[curSlice], oldData];
  }
};
var mergeDataWithSpec = (data, changes, useSpecField, withDeepCopy, deepCopyRoot) => {
  var root = deepCopyRoot ? deepCopy(data) : data;
  for (var i = 0; i < changes.length; i++) {
    var changeInfo = changes[i];
    var path = changeInfo[0];
    var value = changeInfo[1];
    var specValue = changeInfo[2];
    if (value === undefined) continue;
    var node = root;
    var field = path[0];
    for (var j = 1; j < path.length; j++) {
      node = node[field];
      if (node != null && node.__wxspec__) node = node.__value__;
      field = path[j];
      if (node != null && !merger_hasOwnProperty.call(node, field)) {
        node = null;
        break;
      }
    }
    if (node != null && merger_hasOwnProperty.call(node, field)) {
      if (useSpecField) {
        if (specValue != null && typeof value === 'object' && value instanceof Array === specValue instanceof Array) {
          node[field] = {
            __value__: specValue,
            __wxspec__: true
          };
        } else if (node[field] == null || !node[field].__wxspec__) {
          node[field] = {
            __value__: node[field],
            __wxspec__: true
          };
        }
      } else {
        node[field] = withDeepCopy ? deepCopy(value, false) : value;
      }
    }
  }
  return root;
};
;// CONCATENATED MODULE: ./src/save_restore_view_states.js
var states = {
  restoring: null,
  idDataMap: null,
  compIdArr: null,
  compExtraDataMap: null,
  compIdArrIndex: 0,
  onReady: () => {}
};
/* harmony default export */ const save_restore_view_states = (states);
;// CONCATENATED MODULE: ./src/utils/report.js


var report_exparser = getExparser();
var domainAppearedInPage = {};
var report_reportPluginNodeCreation = (node, tm) => {
  var domain = report_exparser.Component.getComponentOptions(node).domain;
  if (domain === '/' || domain === '//' || !domain) return;
  var pluginId = domain.split('/', 1)[0];
  var viewId = tm.viewId;
  if (!domainAppearedInPage[viewId]) domainAppearedInPage[viewId] = {};
  if (domainAppearedInPage[viewId][pluginId]) return;
  domainAppearedInPage[viewId][pluginId] = true;
  var version = __appServiceSDK__.pluginInfos[pluginId].version;
  var value = [pluginId, version, tm.rootCompName, __appServiceSDK__.getLaunchOptionsSync().sessionid || __appServiceSDK__.getLaunchOptionsSync().sessionId || '', 0, ''].map(encodeURIComponent).join(',');
  if (typeof Reporter === 'undefined') return;
  Reporter.reportKeyValue({
    key: 'PluginDisplay',
    value,
    force: true
  });
  Reporter.reportIDKey({
    key: 'pluginDisplayInPage',
    force: true
  });
};
var flowCount = 0;
var genFuncCount = 0;
var genFuncTime = 0;
var addFlowCount = () => {
  flowCount += 1;
};
var addGenFuncTime = time => {
  genFuncCount += 1;
  genFuncTime += time;
};
var reportFlow = (startTs, flowStartTs, flowEndTs, flowType) => {
  var rootFlowCount = 1;
  var rootFlowTime = flowEndTs - flowStartTs;
  var rootFlowCallbackTime = flowEndTs - startTs;
  var genFuncAvgTime = Math.ceil(genFuncTime / (genFuncCount || 1));
  var value = [flowCount, rootFlowCount, rootFlowTime, genFuncCount, genFuncAvgTime, isDataThread() ? 1 : 2, rootFlowCallbackTime, flowType].map(encodeURIComponent).join(',');
  flowCount = 0;
  genFuncCount = 0;
  genFuncTime = 0;
  if (typeof Reporter === 'undefined') return;
  Reporter.reportKeyValue({
    key: 'SetDataPerf',
    value,
    force: true
  });
};
var combinedFlowCount = 0;
var combinedRootFlowCount = 0;
var combinedRootFlowTime = 0;
var combinedGenFuncCount = 0;
var combinedGenFuncTime = 0;
var combinedRootFlowCallbackTime = 0;
var reportFlowCombined = (startTs, flowStartTs, flowEndTs) => {
  combinedFlowCount += flowCount;
  combinedRootFlowCount += 1;
  combinedRootFlowTime += flowEndTs - flowStartTs;
  combinedGenFuncCount += genFuncCount;
  combinedGenFuncTime += genFuncTime;
  combinedRootFlowCallbackTime += flowEndTs - startTs;
  flowCount = 0;
  genFuncCount = 0;
  genFuncTime = 0;
  return combinedRootFlowCount;
};
var reportFlowFlushCombined = flowType => {
  var rootFlowAvgTime = Math.ceil(combinedRootFlowTime / (combinedRootFlowCount || 1));
  var genFuncAvgTime = Math.ceil(combinedGenFuncTime / (combinedGenFuncCount || 1));
  var combinedRootFlowCallbackAvgTime = Math.ceil(combinedRootFlowCallbackTime / (combinedRootFlowCount || 1));
  var value = [combinedFlowCount, combinedRootFlowCount, rootFlowAvgTime, combinedGenFuncCount, genFuncAvgTime, isDataThread() ? 1 : 2, combinedRootFlowCallbackAvgTime, flowType].map(encodeURIComponent).join(',');
  if (typeof Reporter === 'undefined') return;
  Reporter.reportKeyValue({
    key: 'SetDataPerf',
    value,
    force: true
  });
};
var createLazyLoadReport = () => {
  var requiredFields = ['libVersion', 'isFirstPage', 'isWebview', 'totalComps', 'loadedComps', 'lazyedComps', 'loadTime', 'lazyLoadTime'];
  var requiredSet = new Set(requiredFields);
  var data = {};
  var reported = false;
  var doReport = () => {
    if (typeof Reporter === 'undefined') return;
    var value = requiredFields.map(key => encodeURIComponent(data[key])).join(',');
    Reporter.reportKeyValue({
      key: 'LazyCodeLoading',
      value,
      immediately: true
    });
  };
  var set = (key, value) => {
    if (reported) return;
    data[key] = value;
    if (requiredSet.has(key)) requiredSet.delete(key);
    if (requiredSet.size === 0) {
      doReport();
      reported = true;
    }
  };
  set('libVersion', wx.version.version);
  set('isWebview', !isDataThread());
  set('lazyedComps', 0);
  set('lazyLoadTime', 0);
  return {
    set
  };
};
;// CONCATENATED MODULE: ./src/utils/case_map.js
var cache = fn => {
  var _cache = {};
  return param => {
    if (_cache[param]) return _cache[param];
    _cache[param] = fn(param);
    return _cache[param];
  };
};
var rx = {
  dashToCamel: /-[a-z]/g,
  camelToDash: /([A-Z])/g
};
var dashToCamelCase = cache(dash => {
  var ret = dash.indexOf('-') <= 0 ? dash : dash.replace(rx.dashToCamel, s => s[1].toUpperCase());
  return ret;
});
var camelToDashCase = cache(camel => {
  var ret = camel.replace(rx.camelToDash, '-$1').toLowerCase();
  return ret;
});
;// CONCATENATED MODULE: ./src/vendor/anime.js

var defaultInstanceSettings = {
  update: null,
  begin: null,
  loopBegin: null,
  changeBegin: null,
  change: null,
  changeComplete: null,
  loopComplete: null,
  complete: null,
  loop: 1,
  direction: 'normal',
  autoplay: true,
  timelineOffset: 0
};
var defaultTweenSettings = {
  duration: 1000,
  delay: 0,
  endDelay: 0,
  easing: 'easeOutElastic(1, .5)',
  round: 0
};
var validTransforms = ['translateX', 'translateY', 'translateZ', 'rotate', 'rotateX', 'rotateY', 'rotateZ', 'scale', 'scaleX', 'scaleY', 'scaleZ', 'skew', 'skewX', 'skewY', 'perspective'];
var anime_cache = {
  CSS: {},
  springs: {}
};
function minMax(val, min, max) {
  return Math.min(Math.max(val, min), max);
}
function stringContains(str, text) {
  return str.indexOf(text) > -1;
}
function applyArguments(func, args) {
  return func.apply(null, args);
}
var is = {
  arr: function (a) {
    return Array.isArray(a);
  },
  obj: function (a) {
    return stringContains(Object.prototype.toString.call(a), 'Object');
  },
  pth: function (a) {
    return is.obj(a) && a.hasOwnProperty('totalLength');
  },
  svg: function (a) {
    return a instanceof SVGElement;
  },
  inp: function (a) {
    return a instanceof HTMLInputElement;
  },
  dom: function (a) {
    return a.nodeType || is.svg(a) || a.$$;
  },
  str: function (a) {
    return typeof a === 'string';
  },
  fnc: function (a) {
    return typeof a === 'function';
  },
  und: function (a) {
    return typeof a === 'undefined';
  },
  hex: function (a) {
    return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(a);
  },
  rgb: function (a) {
    return /^rgb/.test(a);
  },
  hsl: function (a) {
    return /^hsl/.test(a);
  },
  col: function (a) {
    return is.hex(a) || is.rgb(a) || is.hsl(a);
  },
  key: function (a) {
    return !defaultInstanceSettings.hasOwnProperty(a) && !defaultTweenSettings.hasOwnProperty(a) && a !== 'targets' && a !== 'keyframes';
  }
};
function parseEasingParameters(string) {
  var match = /\(([^)]+)\)/.exec(string);
  return match ? match[1].split(',').map(function (p) {
    return parseFloat(p);
  }) : [];
}
function spring(string, duration) {
  var params = parseEasingParameters(string);
  var mass = minMax(is.und(params[0]) ? 1 : params[0], .1, 100);
  var stiffness = minMax(is.und(params[1]) ? 100 : params[1], .1, 100);
  var damping = minMax(is.und(params[2]) ? 10 : params[2], .1, 100);
  var velocity = minMax(is.und(params[3]) ? 0 : params[3], .1, 100);
  var w0 = Math.sqrt(stiffness / mass);
  var zeta = damping / (2 * Math.sqrt(stiffness * mass));
  var wd = zeta < 1 ? w0 * Math.sqrt(1 - zeta * zeta) : 0;
  var a = 1;
  var b = zeta < 1 ? (zeta * w0 + -velocity) / wd : -velocity + w0;
  function solver(t) {
    var progress = duration ? duration * t / 1000 : t;
    if (zeta < 1) {
      progress = Math.exp(-progress * zeta * w0) * (a * Math.cos(wd * progress) + b * Math.sin(wd * progress));
    } else {
      progress = (a + b * progress) * Math.exp(-progress * w0);
    }
    if (t === 0 || t === 1) {
      return t;
    }
    return 1 - progress;
  }
  function getDuration() {
    var cached = anime_cache.springs[string];
    if (cached) {
      return cached;
    }
    var frame = 1 / 6;
    var elapsed = 0;
    var rest = 0;
    while (true) {
      elapsed += frame;
      if (solver(elapsed) === 1) {
        rest++;
        if (rest >= 16) {
          break;
        }
      } else {
        rest = 0;
      }
    }
    var duration = elapsed * frame * 1000;
    anime_cache.springs[string] = duration;
    return duration;
  }
  return duration ? solver : getDuration;
}
function steps(steps) {
  if (steps === void 0) steps = 10;
  return function (t) {
    return Math.round(t * steps) * (1 / steps);
  };
}
var bezier = function () {
  var kSplineTableSize = 11;
  var kSampleStepSize = 1.0 / (kSplineTableSize - 1.0);
  function A(aA1, aA2) {
    return 1.0 - 3.0 * aA2 + 3.0 * aA1;
  }
  function B(aA1, aA2) {
    return 3.0 * aA2 - 6.0 * aA1;
  }
  function C(aA1) {
    return 3.0 * aA1;
  }
  function calcBezier(aT, aA1, aA2) {
    return ((A(aA1, aA2) * aT + B(aA1, aA2)) * aT + C(aA1)) * aT;
  }
  function getSlope(aT, aA1, aA2) {
    return 3.0 * A(aA1, aA2) * aT * aT + 2.0 * B(aA1, aA2) * aT + C(aA1);
  }
  function binarySubdivide(aX, aA, aB, mX1, mX2) {
    var currentX,
      currentT,
      i = 0;
    do {
      currentT = aA + (aB - aA) / 2.0;
      currentX = calcBezier(currentT, mX1, mX2) - aX;
      if (currentX > 0.0) {
        aB = currentT;
      } else {
        aA = currentT;
      }
    } while (Math.abs(currentX) > 0.0000001 && ++i < 10);
    return currentT;
  }
  function newtonRaphsonIterate(aX, aGuessT, mX1, mX2) {
    for (var i = 0; i < 4; ++i) {
      var currentSlope = getSlope(aGuessT, mX1, mX2);
      if (currentSlope === 0.0) {
        return aGuessT;
      }
      var currentX = calcBezier(aGuessT, mX1, mX2) - aX;
      aGuessT -= currentX / currentSlope;
    }
    return aGuessT;
  }
  function bezier(mX1, mY1, mX2, mY2) {
    if (!(0 <= mX1 && mX1 <= 1 && 0 <= mX2 && mX2 <= 1)) {
      return;
    }
    var sampleValues = new Float32Array(kSplineTableSize);
    if (mX1 !== mY1 || mX2 !== mY2) {
      for (var i = 0; i < kSplineTableSize; ++i) {
        sampleValues[i] = calcBezier(i * kSampleStepSize, mX1, mX2);
      }
    }
    function getTForX(aX) {
      var intervalStart = 0;
      var currentSample = 1;
      var lastSample = kSplineTableSize - 1;
      for (; currentSample !== lastSample && sampleValues[currentSample] <= aX; ++currentSample) {
        intervalStart += kSampleStepSize;
      }
      --currentSample;
      var dist = (aX - sampleValues[currentSample]) / (sampleValues[currentSample + 1] - sampleValues[currentSample]);
      var guessForT = intervalStart + dist * kSampleStepSize;
      var initialSlope = getSlope(guessForT, mX1, mX2);
      if (initialSlope >= 0.001) {
        return newtonRaphsonIterate(aX, guessForT, mX1, mX2);
      } else if (initialSlope === 0.0) {
        return guessForT;
      } else {
        return binarySubdivide(aX, intervalStart, intervalStart + kSampleStepSize, mX1, mX2);
      }
    }
    return function (x) {
      if (mX1 === mY1 && mX2 === mY2) {
        return x;
      }
      if (x === 0 || x === 1) {
        return x;
      }
      return calcBezier(getTForX(x), mY1, mY2);
    };
  }
  return bezier;
}();
var penner = function () {
  var eases = {
    linear: function () {
      return function (t) {
        return t;
      };
    }
  };
  var functionEasings = {
    Sine: function () {
      return function (t) {
        return 1 - Math.cos(t * Math.PI / 2);
      };
    },
    Circ: function () {
      return function (t) {
        return 1 - Math.sqrt(1 - t * t);
      };
    },
    Back: function () {
      return function (t) {
        return t * t * (3 * t - 2);
      };
    },
    Bounce: function () {
      return function (t) {
        var pow2,
          b = 4;
        while (t < ((pow2 = Math.pow(2, --b)) - 1) / 11) {}
        return 1 / Math.pow(4, 3 - b) - 7.5625 * Math.pow((pow2 * 3 - 2) / 22 - t, 2);
      };
    },
    Elastic: function (amplitude, period) {
      if (amplitude === void 0) amplitude = 1;
      if (period === void 0) period = .5;
      var a = minMax(amplitude, 1, 10);
      var p = minMax(period, .1, 2);
      return function (t) {
        return t === 0 || t === 1 ? t : -a * Math.pow(2, 10 * (t - 1)) * Math.sin((t - 1 - p / (Math.PI * 2) * Math.asin(1 / a)) * (Math.PI * 2) / p);
      };
    }
  };
  var baseEasings = ['Quad', 'Cubic', 'Quart', 'Quint', 'Expo'];
  baseEasings.forEach(function (name, i) {
    functionEasings[name] = function () {
      return function (t) {
        return Math.pow(t, i + 2);
      };
    };
  });
  Object.keys(functionEasings).forEach(function (name) {
    var easeIn = functionEasings[name];
    eases['easeIn' + name] = easeIn;
    eases['easeOut' + name] = function (a, b) {
      return function (t) {
        return 1 - easeIn(a, b)(1 - t);
      };
    };
    eases['easeInOut' + name] = function (a, b) {
      return function (t) {
        return t < 0.5 ? easeIn(a, b)(t * 2) / 2 : 1 - easeIn(a, b)(t * -2 + 2) / 2;
      };
    };
  });
  return eases;
}();
function parseEasings(easing, duration) {
  if (is.fnc(easing)) {
    return easing;
  }
  var name = easing.split('(')[0];
  var ease = penner[name];
  var args = parseEasingParameters(easing);
  switch (name) {
    case 'spring':
      return spring(easing, duration);
    case 'cubicBezier':
      return applyArguments(bezier, args);
    case 'steps':
      return applyArguments(steps, args);
    default:
      return applyArguments(ease, args);
  }
}
function selectString(str) {
  try {
    var nodes = document.querySelectorAll(str);
    return nodes;
  } catch (e) {
    return;
  }
}
function filterArray(arr, callback) {
  var len = arr.length;
  var thisArg = arguments.length >= 2 ? arguments[1] : void 0;
  var result = [];
  for (var i = 0; i < len; i++) {
    if (i in arr) {
      var val = arr[i];
      if (callback.call(thisArg, val, i, arr)) {
        result.push(val);
      }
    }
  }
  return result;
}
function flattenArray(arr) {
  return arr.reduce(function (a, b) {
    return a.concat(is.arr(b) ? flattenArray(b) : b);
  }, []);
}
function toArray(o) {
  if (is.arr(o)) {
    return o;
  }
  if (is.str(o)) {
    o = selectString(o) || o;
  }
  if (o instanceof NodeList || o instanceof HTMLCollection) {
    return [].slice.call(o);
  }
  return [o];
}
function arrayContains(arr, val) {
  return arr.some(function (a) {
    return a === val;
  });
}
function cloneObject(o) {
  var clone = {};
  for (var p in o) {
    clone[p] = o[p];
  }
  return clone;
}
function replaceObjectProps(o1, o2) {
  var o = cloneObject(o1);
  for (var p in o1) {
    o[p] = o2.hasOwnProperty(p) ? o2[p] : o1[p];
  }
  return o;
}
function mergeObjects(o1, o2) {
  var o = cloneObject(o1);
  for (var p in o2) {
    o[p] = is.und(o1[p]) ? o2[p] : o1[p];
  }
  return o;
}
function rgbToRgba(rgbValue) {
  var rgb = /rgb\((\d+,\s*[\d]+,\s*[\d]+)\)/g.exec(rgbValue);
  return rgb ? "rgba(" + rgb[1] + ",1)" : rgbValue;
}
function hexToRgba(hexValue) {
  var rgx = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
  var hex = hexValue.replace(rgx, function (m, r, g, b) {
    return r + r + g + g + b + b;
  });
  var rgb = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  var r = parseInt(rgb[1], 16);
  var g = parseInt(rgb[2], 16);
  var b = parseInt(rgb[3], 16);
  return "rgba(" + r + "," + g + "," + b + ",1)";
}
function hslToRgba(hslValue) {
  var hsl = /hsl\((\d+),\s*([\d.]+)%,\s*([\d.]+)%\)/g.exec(hslValue) || /hsla\((\d+),\s*([\d.]+)%,\s*([\d.]+)%,\s*([\d.]+)\)/g.exec(hslValue);
  var h = parseInt(hsl[1], 10) / 360;
  var s = parseInt(hsl[2], 10) / 100;
  var l = parseInt(hsl[3], 10) / 100;
  var a = hsl[4] || 1;
  function hue2rgb(p, q, t) {
    if (t < 0) {
      t += 1;
    }
    if (t > 1) {
      t -= 1;
    }
    if (t < 1 / 6) {
      return p + (q - p) * 6 * t;
    }
    if (t < 1 / 2) {
      return q;
    }
    if (t < 2 / 3) {
      return p + (q - p) * (2 / 3 - t) * 6;
    }
    return p;
  }
  var r, g, b;
  if (s == 0) {
    r = g = b = l;
  } else {
    var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    var p = 2 * l - q;
    r = hue2rgb(p, q, h + 1 / 3);
    g = hue2rgb(p, q, h);
    b = hue2rgb(p, q, h - 1 / 3);
  }
  return "rgba(" + r * 255 + "," + g * 255 + "," + b * 255 + "," + a + ")";
}
function colorToRgb(val) {
  if (is.rgb(val)) {
    return rgbToRgba(val);
  }
  if (is.hex(val)) {
    return hexToRgba(val);
  }
  if (is.hsl(val)) {
    return hslToRgba(val);
  }
}
function getUnit(val) {
  var split = /[+-]?\d*\.?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?(%|px|pt|em|rem|in|cm|mm|ex|ch|pc|vw|vh|vmin|vmax|deg|rad|turn)?$/.exec(val);
  if (split) {
    return split[1];
  }
}
function getTransformUnit(propName) {
  if (stringContains(propName, 'translate') || propName === 'perspective') {
    return 'px';
  }
  if (stringContains(propName, 'rotate') || stringContains(propName, 'skew')) {
    return 'deg';
  }
}
function getFunctionValue(val, animatable) {
  if (!is.fnc(val)) {
    return val;
  }
  return val(animatable.target, animatable.id, animatable.total);
}
function getAttribute(el, prop) {
  return el.getAttribute(prop);
}
function convertPxToUnit(el, value, unit) {
  el = el.$$ || el;
  var valueUnit = getUnit(value);
  if (arrayContains([unit, 'deg', 'rad', 'turn'], valueUnit)) {
    return value;
  }
  var cached = anime_cache.CSS[value + unit];
  if (!is.und(cached)) {
    return cached;
  }
  var baseline = 100;
  var tempEl = document.createElement(el.tagName);
  var parentEl = el.parentNode && el.parentNode !== document ? el.parentNode : document.body;
  parentEl.appendChild(tempEl);
  tempEl.style.position = 'absolute';
  tempEl.style.width = baseline + unit;
  var factor = baseline / tempEl.offsetWidth;
  parentEl.removeChild(tempEl);
  var convertedUnit = factor * parseFloat(value);
  anime_cache.CSS[value + unit] = convertedUnit;
  return convertedUnit;
}
function getCSSValue(el, prop, unit) {
  if (prop in el.style) {
    var uppercasePropName = prop.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
    var value = el.style[prop] || getComputedStyle(el.$$ || el).getPropertyValue(uppercasePropName) || '0';
    return unit ? convertPxToUnit(el, value, unit) : value;
  }
}
function getAnimationType(el, prop) {
  if (is.dom(el) && !is.inp(el) && (getAttribute(el, prop) || is.svg(el) && el[prop])) {
    return 'attribute';
  }
  if (is.dom(el) && arrayContains(validTransforms, prop)) {
    return 'transform';
  }
  if (is.dom(el) && prop !== 'transform' && getCSSValue(el, prop)) {
    return 'css';
  }
  if (el[prop] != null) {
    return 'object';
  }
}
function getElementTransforms(el) {
  if (!is.dom(el)) {
    return;
  }
  var str = el.style.transform || '';
  var reg = /(\w+)\(([^)]*)\)/g;
  var transforms = new Map();
  var m;
  while (m = reg.exec(str)) {
    transforms.set(m[1], m[2]);
  }
  return transforms;
}
function getTransformValue(el, propName, animatable, unit) {
  var defaultVal = stringContains(propName, 'scale') ? 1 : 0 + getTransformUnit(propName);
  var value = getElementTransforms(el).get(propName) || defaultVal;
  if (animatable) {
    animatable.transforms.list.set(propName, value);
    animatable.transforms['last'] = propName;
  }
  return unit ? convertPxToUnit(el, value, unit) : value;
}
function getOriginalTargetValue(target, propName, unit, animatable) {
  switch (getAnimationType(target, propName)) {
    case 'transform':
      return getTransformValue(target, propName, animatable, unit);
    case 'css':
      return getCSSValue(target, propName, unit);
    case 'attribute':
      return getAttribute(target, propName);
    default:
      return target[propName] || 0;
  }
}
function getRelativeValue(to, from) {
  var operator = /^(\*=|\+=|-=)/.exec(to);
  if (!operator) {
    return to;
  }
  var u = getUnit(to) || 0;
  var x = parseFloat(from);
  var y = parseFloat(to.replace(operator[0], ''));
  switch (operator[0][0]) {
    case '+':
      return x + y + u;
    case '-':
      return x - y + u;
    case '*':
      return x * y + u;
  }
}
function validateValue(val, unit) {
  if (is.col(val)) {
    return colorToRgb(val);
  }
  if (/\s/g.test(val)) {
    return val;
  }
  var originalUnit = getUnit(val);
  var unitLess = originalUnit ? val.substr(0, val.length - originalUnit.length) : val;
  if (unit) {
    return unitLess + unit;
  }
  return unitLess;
}
function getDistance(p1, p2) {
  return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
}
function getCircleLength(el) {
  return Math.PI * 2 * getAttribute(el, 'r');
}
function getRectLength(el) {
  return getAttribute(el, 'width') * 2 + getAttribute(el, 'height') * 2;
}
function getLineLength(el) {
  return getDistance({
    x: getAttribute(el, 'x1'),
    y: getAttribute(el, 'y1')
  }, {
    x: getAttribute(el, 'x2'),
    y: getAttribute(el, 'y2')
  });
}
function getPolylineLength(el) {
  var points = el.points;
  var totalLength = 0;
  var previousPos;
  for (var i = 0; i < points.numberOfItems; i++) {
    var currentPos = points.getItem(i);
    if (i > 0) {
      totalLength += getDistance(previousPos, currentPos);
    }
    previousPos = currentPos;
  }
  return totalLength;
}
function getPolygonLength(el) {
  var points = el.points;
  return getPolylineLength(el) + getDistance(points.getItem(points.numberOfItems - 1), points.getItem(0));
}
function getTotalLength(el) {
  if (el.getTotalLength) {
    return el.getTotalLength();
  }
  switch (el.tagName.toLowerCase()) {
    case 'circle':
      return getCircleLength(el);
    case 'rect':
      return getRectLength(el);
    case 'line':
      return getLineLength(el);
    case 'polyline':
      return getPolylineLength(el);
    case 'polygon':
      return getPolygonLength(el);
  }
}
function setDashoffset(el) {
  var pathLength = getTotalLength(el);
  el.setAttribute('stroke-dasharray', pathLength);
  return pathLength;
}
function getParentSvgEl(el) {
  var parentEl = el.parentNode;
  while (is.svg(parentEl)) {
    if (!is.svg(parentEl.parentNode)) {
      break;
    }
    parentEl = parentEl.parentNode;
  }
  return parentEl;
}
function getParentSvg(pathEl, svgData) {
  var svg = svgData || {};
  var parentSvgEl = svg.el || getParentSvgEl(pathEl);
  var rect = parentSvgEl.getBoundingClientRect();
  var viewBoxAttr = getAttribute(parentSvgEl, 'viewBox');
  var width = rect.width;
  var height = rect.height;
  var viewBox = svg.viewBox || (viewBoxAttr ? viewBoxAttr.split(' ') : [0, 0, width, height]);
  return {
    el: parentSvgEl,
    viewBox: viewBox,
    x: viewBox[0] / 1,
    y: viewBox[1] / 1,
    w: width / viewBox[2],
    h: height / viewBox[3]
  };
}
function getPath(path, percent) {
  var pathEl = is.str(path) ? selectString(path)[0] : path;
  var p = percent || 100;
  return function (property) {
    return {
      property: property,
      el: pathEl,
      svg: getParentSvg(pathEl),
      totalLength: getTotalLength(pathEl) * (p / 100)
    };
  };
}
function getPathProgress(path, progress) {
  function point(offset) {
    if (offset === void 0) offset = 0;
    var l = progress + offset >= 1 ? progress + offset : 0;
    return path.el.getPointAtLength(l);
  }
  var svg = getParentSvg(path.el, path.svg);
  var p = point();
  var p0 = point(-1);
  var p1 = point(+1);
  switch (path.property) {
    case 'x':
      return (p.x - svg.x) * svg.w;
    case 'y':
      return (p.y - svg.y) * svg.h;
    case 'angle':
      return Math.atan2(p1.y - p0.y, p1.x - p0.x) * 180 / Math.PI;
  }
}
function decomposeValue(val, unit) {
  var rgx = /[+-]?\d*\.?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g;
  var value = validateValue(is.pth(val) ? val.totalLength : val, unit) + '';
  return {
    original: value,
    numbers: value.match(rgx) ? value.match(rgx).map(Number) : [0],
    strings: is.str(val) || unit ? value.split(rgx) : []
  };
}
function parseTargets(targets) {
  var targetsArray = targets ? flattenArray(is.arr(targets) ? targets.map(toArray) : toArray(targets)) : [];
  return filterArray(targetsArray, function (item, pos, self) {
    return self.indexOf(item) === pos;
  });
}
function getAnimatables(targets) {
  var parsed = parseTargets(targets);
  return parsed.map(function (t, i) {
    return {
      target: t,
      id: i,
      total: parsed.length,
      transforms: {
        list: getElementTransforms(t)
      }
    };
  });
}
function normalizePropertyTweens(prop, tweenSettings) {
  var settings = cloneObject(tweenSettings);
  if (/^spring/.test(settings.easing)) {
    settings.duration = spring(settings.easing);
  }
  if (is.arr(prop)) {
    var l = prop.length;
    var isFromTo = l === 2 && !is.obj(prop[0]);
    if (!isFromTo) {
      if (!is.fnc(tweenSettings.duration)) {
        settings.duration = tweenSettings.duration / l;
      }
    } else {
      prop = {
        value: prop
      };
    }
  }
  var propArray = is.arr(prop) ? prop : [prop];
  return propArray.map(function (v, i) {
    var obj = is.obj(v) && !is.pth(v) ? v : {
      value: v
    };
    if (is.und(obj.delay)) {
      obj.delay = !i ? tweenSettings.delay : 0;
    }
    if (is.und(obj.endDelay)) {
      obj.endDelay = i === propArray.length - 1 ? tweenSettings.endDelay : 0;
    }
    return obj;
  }).map(function (k) {
    return mergeObjects(k, settings);
  });
}
function flattenKeyframes(keyframes) {
  var propertyNames = filterArray(flattenArray(keyframes.map(function (key) {
    return Object.keys(key);
  })), function (p) {
    return is.key(p);
  }).reduce(function (a, b) {
    if (a.indexOf(b) < 0) {
      a.push(b);
    }
    return a;
  }, []);
  var properties = {};
  var loop = function (i) {
    var propName = propertyNames[i];
    properties[propName] = keyframes.map(function (key) {
      var newKey = {};
      for (var p in key) {
        if (is.key(p)) {
          if (p == propName) {
            newKey.value = key[p];
          }
        } else {
          newKey[p] = key[p];
        }
      }
      return newKey;
    });
  };
  for (var i = 0; i < propertyNames.length; i++) loop(i);
  return properties;
}
function getProperties(tweenSettings, params) {
  var properties = [];
  var keyframes = params.keyframes;
  if (keyframes) {
    params = mergeObjects(flattenKeyframes(keyframes), params);
  }
  for (var p in params) {
    if (is.key(p)) {
      properties.push({
        name: p,
        tweens: normalizePropertyTweens(params[p], tweenSettings)
      });
    }
  }
  return properties;
}
function normalizeTweenValues(tween, animatable) {
  var t = {};
  for (var p in tween) {
    var value = getFunctionValue(tween[p], animatable);
    if (is.arr(value)) {
      value = value.map(function (v) {
        return getFunctionValue(v, animatable);
      });
      if (value.length === 1) {
        value = value[0];
      }
    }
    t[p] = value;
  }
  t.duration = parseFloat(t.duration);
  t.delay = parseFloat(t.delay);
  return t;
}
function normalizeTweens(prop, animatable) {
  var previousTween;
  return prop.tweens.map(function (t) {
    var tween = normalizeTweenValues(t, animatable);
    var tweenValue = tween.value;
    var to = is.arr(tweenValue) ? tweenValue[1] : tweenValue;
    var toUnit = getUnit(to);
    var originalValue = getOriginalTargetValue(animatable.target, prop.name, toUnit, animatable);
    var previousValue = previousTween ? previousTween.to.original : originalValue;
    var from = is.arr(tweenValue) ? tweenValue[0] : previousValue;
    var fromUnit = getUnit(from) || getUnit(originalValue);
    var unit = toUnit || fromUnit;
    if (is.und(to)) {
      to = previousValue;
    }
    tween.from = decomposeValue(from, unit);
    tween.to = decomposeValue(getRelativeValue(to, from), unit);
    tween.start = previousTween ? previousTween.end : 0;
    tween.end = tween.start + tween.delay + tween.duration + tween.endDelay;
    tween.easing = parseEasings(tween.easing, tween.duration);
    tween.isPath = is.pth(tweenValue);
    tween.isColor = is.col(tween.from.original);
    if (tween.isColor) {
      tween.round = 1;
    }
    previousTween = tween;
    return tween;
  });
}
var setProgressValue = {
  css: function (t, p, v) {
    if (t.$$) {
      return `${p.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase()}:${wx.transformRpx(' ' + v)};`;
    }
    t.style[p] = v;
  },
  attribute: function (t, p, v) {
    return t.setAttribute(p, v);
  },
  object: function (t, p, v) {
    return t[p] = v;
  },
  transform: function (t, p, v, transforms, manual) {
    transforms.list.set(p, v);
    if (p === transforms.last || manual) {
      var str = '';
      transforms.list.forEach(function (value, prop) {
        str += prop + "(" + value + ") ";
      });
      if (t.$$) {
        return `transform:${wx.transformRpx(' ' + str)};`;
      }
      t.style.transform = str;
    }
    return '';
  }
};
function setTargetsValue(targets, properties) {
  var animatables = getAnimatables(targets);
  animatables.forEach(function (animatable) {
    for (var property in properties) {
      var value = getFunctionValue(properties[property], animatable);
      var target = animatable.target;
      var valueUnit = getUnit(value);
      var originalValue = getOriginalTargetValue(target, property, valueUnit, animatable);
      var unit = valueUnit || getUnit(originalValue);
      var to = getRelativeValue(validateValue(value, unit), originalValue);
      var animType = getAnimationType(target, property);
      setProgressValue[animType](target, property, to, animatable.transforms, true);
    }
  });
}
function createAnimation(animatable, prop) {
  var animType = getAnimationType(animatable.target, prop.name);
  if (animType) {
    var tweens = normalizeTweens(prop, animatable);
    var lastTween = tweens[tweens.length - 1];
    return {
      type: animType,
      property: prop.name,
      animatable: animatable,
      tweens: tweens,
      duration: lastTween.end,
      delay: tweens[0].delay,
      endDelay: lastTween.endDelay
    };
  }
}
function getAnimations(animatables, properties) {
  return filterArray(flattenArray(animatables.map(function (animatable) {
    return properties.map(function (prop) {
      return createAnimation(animatable, prop);
    });
  })), function (a) {
    return !is.und(a);
  });
}
function getInstanceTimings(animations, tweenSettings) {
  var animLength = animations.length;
  var getTlOffset = function (anim) {
    return anim.timelineOffset ? anim.timelineOffset : 0;
  };
  var timings = {};
  timings.duration = animLength ? Math.max.apply(Math, animations.map(function (anim) {
    return getTlOffset(anim) + anim.duration;
  })) : tweenSettings.duration;
  timings.delay = animLength ? Math.min.apply(Math, animations.map(function (anim) {
    return getTlOffset(anim) + anim.delay;
  })) : tweenSettings.delay;
  timings.endDelay = animLength ? timings.duration - Math.max.apply(Math, animations.map(function (anim) {
    return getTlOffset(anim) + anim.duration - anim.endDelay;
  })) : tweenSettings.endDelay;
  return timings;
}
var instanceID = 0;
function createNewInstance(params) {
  var instanceSettings = replaceObjectProps(defaultInstanceSettings, params);
  var tweenSettings = replaceObjectProps(defaultTweenSettings, params);
  var properties = getProperties(tweenSettings, params);
  var animatables = getAnimatables(params.targets);
  var animations = getAnimations(animatables, properties);
  var timings = getInstanceTimings(animations, tweenSettings);
  var id = instanceID;
  instanceID++;
  return mergeObjects(instanceSettings, {
    id: id,
    children: [],
    animatables: animatables,
    animations: animations,
    duration: timings.duration,
    delay: timings.delay,
    endDelay: timings.endDelay
  });
}
var activeInstances = [];
var pausedInstances = (/* unused pure expression or super */ null && ([]));
var raf;
var engine = function () {
  function play() {
    raf = requestAnimationFrame(step);
  }
  function step(t) {
    var activeInstancesLength = activeInstances.length;
    if (activeInstancesLength) {
      var i = 0;
      while (i < activeInstancesLength) {
        var activeInstance = activeInstances[i];
        if (!activeInstance.paused) {
          activeInstance.tick(t);
        } else {
          var instanceIndex = activeInstances.indexOf(activeInstance);
          if (instanceIndex > -1) {
            activeInstances.splice(instanceIndex, 1);
            activeInstancesLength = activeInstances.length;
          }
        }
        i++;
      }
      play();
    } else {
      raf = cancelAnimationFrame(raf);
    }
  }
  return play;
}();
function anime(params) {
  if (params === void 0) params = {};
  var startTime = 0,
    lastTime = 0,
    now = 0;
  var children,
    childrenLength = 0;
  var resolve = null;
  function makePromise(instance) {
    var promise = window.Promise && new Promise(function (_resolve) {
      return resolve = _resolve;
    });
    instance.finished = promise;
    return promise;
  }
  var instance = createNewInstance(params);
  var promise = makePromise(instance);
  function toggleInstanceDirection() {
    var direction = instance.direction;
    if (direction !== 'alternate') {
      instance.direction = direction !== 'normal' ? 'normal' : 'reverse';
    }
    instance.reversed = !instance.reversed;
    children.forEach(function (child) {
      return child.reversed = instance.reversed;
    });
  }
  function adjustTime(time) {
    return instance.reversed ? instance.duration - time : time;
  }
  function resetTime() {
    startTime = 0;
    lastTime = adjustTime(instance.currentTime) * (1 / anime.speed);
  }
  function seekChild(time, child) {
    if (child) {
      child.seek(time - child.timelineOffset);
    }
  }
  function syncInstanceChildren(time) {
    if (!instance.reversePlayback) {
      for (var i = 0; i < childrenLength; i++) {
        seekChild(time, children[i]);
      }
    } else {
      for (var i$1 = childrenLength; i$1--;) {
        seekChild(time, children[i$1]);
      }
    }
  }
  function setAnimationsProgress(insTime) {
    var i = 0;
    var animations = instance.animations;
    var animationsLength = animations.length;
    var styles = [];
    while (i < animationsLength) {
      var anim = animations[i];
      var animatable = anim.animatable;
      var tweens = anim.tweens;
      var tweenLength = tweens.length - 1;
      var tween = tweens[tweenLength];
      if (tweenLength) {
        tween = filterArray(tweens, function (t) {
          return insTime < t.end;
        })[0] || tween;
      }
      var elapsed = minMax(insTime - tween.start - tween.delay, 0, tween.duration) / tween.duration;
      var eased = isNaN(elapsed) ? 1 : tween.easing(elapsed);
      var strings = tween.to.strings;
      var round = tween.round;
      var numbers = [];
      var toNumbersLength = tween.to.numbers.length;
      var progress = void 0;
      for (var n = 0; n < toNumbersLength; n++) {
        var value = void 0;
        var toNumber = tween.to.numbers[n];
        var fromNumber = tween.from.numbers[n] || 0;
        if (!tween.isPath) {
          value = fromNumber + eased * (toNumber - fromNumber);
        } else {
          value = getPathProgress(tween.value, eased * toNumber);
        }
        if (round) {
          if (!(tween.isColor && n > 2)) {
            value = Math.round(value * round) / round;
          }
        }
        numbers.push(value);
      }
      var stringsLength = strings.length;
      if (!stringsLength) {
        progress = numbers[0];
      } else {
        progress = strings[0];
        for (var s = 0; s < stringsLength; s++) {
          var a = strings[s];
          var b = strings[s + 1];
          var n$1 = numbers[s];
          if (!isNaN(n$1)) {
            if (!b) {
              progress += n$1 + ' ';
            } else {
              progress += n$1 + b;
            }
          }
        }
      }
      var style = setProgressValue[anim.type](animatable.target, anim.property, progress, animatable.transforms);
      styles.push(style);
      anim.currentValue = progress;
      i++;
    }
    if (instance.animatables.length === 1 && instance.animatables[0].target.$$) {
      instance.animatables[0].target.setNodeStyle(styles.join(' '), STYLE_SEGMENT_INDEX.ANIMATION);
    }
  }
  function setCallback(cb) {
    if (instance[cb] && !instance.passThrough) {
      instance[cb](instance);
    }
  }
  function countIteration() {
    if (instance.remaining && instance.remaining !== true) {
      instance.remaining--;
    }
  }
  function setInstanceProgress(engineTime) {
    var insDuration = instance.duration;
    var insDelay = instance.delay;
    var insEndDelay = insDuration - instance.endDelay;
    var insTime = adjustTime(engineTime);
    instance.progress = minMax(insTime / insDuration * 100, 0, 100);
    instance.reversePlayback = insTime < instance.currentTime;
    if (children) {
      syncInstanceChildren(insTime);
    }
    if (!instance.began && instance.currentTime > 0) {
      instance.began = true;
      setCallback('begin');
    }
    if (!instance.loopBegan && instance.currentTime > 0) {
      instance.loopBegan = true;
      setCallback('loopBegin');
    }
    if (insTime <= insDelay && instance.currentTime !== 0) {
      setAnimationsProgress(0);
    }
    if (insTime >= insEndDelay && instance.currentTime !== insDuration || !insDuration) {
      setAnimationsProgress(insDuration);
    }
    if (insTime > insDelay && insTime < insEndDelay) {
      if (!instance.changeBegan) {
        instance.changeBegan = true;
        instance.changeCompleted = false;
        setCallback('changeBegin');
      }
      setCallback('change');
      setAnimationsProgress(insTime);
    } else {
      if (instance.changeBegan) {
        instance.changeCompleted = true;
        instance.changeBegan = false;
        setCallback('changeComplete');
      }
    }
    instance.currentTime = minMax(insTime, 0, insDuration);
    if (instance.began) {
      setCallback('update');
    }
    if (engineTime >= insDuration) {
      lastTime = 0;
      countIteration();
      if (!instance.remaining) {
        instance.paused = true;
        if (!instance.completed) {
          instance.completed = true;
          setCallback('loopComplete');
          setCallback('complete');
          if (!instance.passThrough && 'Promise' in window) {
            resolve();
            promise = makePromise(instance);
          }
        }
      } else {
        startTime = now;
        setCallback('loopComplete');
        instance.loopBegan = false;
        if (instance.direction === 'alternate') {
          toggleInstanceDirection();
        }
      }
    }
  }
  instance.reset = function () {
    var direction = instance.direction;
    instance.passThrough = false;
    instance.currentTime = 0;
    instance.progress = 0;
    instance.paused = true;
    instance.began = false;
    instance.loopBegan = false;
    instance.changeBegan = false;
    instance.completed = false;
    instance.changeCompleted = false;
    instance.reversePlayback = false;
    instance.reversed = direction === 'reverse';
    instance.remaining = instance.loop;
    children = instance.children;
    childrenLength = children.length;
    for (var i = childrenLength; i--;) {
      instance.children[i].reset();
    }
    if (instance.reversed && instance.loop !== true || direction === 'alternate' && instance.loop === 1) {
      instance.remaining++;
    }
    setAnimationsProgress(instance.reversed ? instance.duration : 0);
  };
  instance.set = function (targets, properties) {
    setTargetsValue(targets, properties);
    return instance;
  };
  instance.tick = function (t) {
    now = t;
    if (!startTime) {
      startTime = now;
    }
    setInstanceProgress((now + (lastTime - startTime)) * anime.speed);
  };
  instance.seek = function (time) {
    setInstanceProgress(adjustTime(time));
  };
  instance.pause = function () {
    instance.paused = true;
    resetTime();
  };
  instance.play = function () {
    if (!instance.paused) {
      return;
    }
    if (instance.completed) {
      instance.reset();
    }
    instance.paused = false;
    activeInstances.push(instance);
    resetTime();
    if (!raf) {
      engine();
    }
  };
  instance.reverse = function () {
    toggleInstanceDirection();
    resetTime();
  };
  instance.restart = function () {
    instance.reset();
    instance.play();
  };
  instance.reset();
  if (instance.autoplay) {
    instance.play();
  }
  return instance;
}
function removeTargetsFromAnimations(targetsArray, animations) {
  for (var a = animations.length; a--;) {
    if (arrayContains(targetsArray, animations[a].animatable.target)) {
      animations.splice(a, 1);
    }
  }
}
function removeTargets(targets) {
  var targetsArray = parseTargets(targets);
  for (var i = activeInstances.length; i--;) {
    var instance = activeInstances[i];
    var animations = instance.animations;
    var children = instance.children;
    removeTargetsFromAnimations(targetsArray, animations);
    for (var c = children.length; c--;) {
      var child = children[c];
      var childAnimations = child.animations;
      removeTargetsFromAnimations(targetsArray, childAnimations);
      if (!childAnimations.length && !child.children.length) {
        children.splice(c, 1);
      }
    }
    if (!animations.length && !children.length) {
      instance.pause();
    }
  }
}
function stagger(val, params) {
  if (params === void 0) params = {};
  var direction = params.direction || 'normal';
  var easing = params.easing ? parseEasings(params.easing) : null;
  var grid = params.grid;
  var axis = params.axis;
  var fromIndex = params.from || 0;
  var fromFirst = fromIndex === 'first';
  var fromCenter = fromIndex === 'center';
  var fromLast = fromIndex === 'last';
  var isRange = is.arr(val);
  var val1 = isRange ? parseFloat(val[0]) : parseFloat(val);
  var val2 = isRange ? parseFloat(val[1]) : 0;
  var unit = getUnit(isRange ? val[1] : val) || 0;
  var start = params.start || 0 + (isRange ? val1 : 0);
  var values = [];
  var maxValue = 0;
  return function (el, i, t) {
    if (fromFirst) {
      fromIndex = 0;
    }
    if (fromCenter) {
      fromIndex = (t - 1) / 2;
    }
    if (fromLast) {
      fromIndex = t - 1;
    }
    if (!values.length) {
      for (var index = 0; index < t; index++) {
        if (!grid) {
          values.push(Math.abs(fromIndex - index));
        } else {
          var fromX = !fromCenter ? fromIndex % grid[0] : (grid[0] - 1) / 2;
          var fromY = !fromCenter ? Math.floor(fromIndex / grid[0]) : (grid[1] - 1) / 2;
          var toX = index % grid[0];
          var toY = Math.floor(index / grid[0]);
          var distanceX = fromX - toX;
          var distanceY = fromY - toY;
          var value = Math.sqrt(distanceX * distanceX + distanceY * distanceY);
          if (axis === 'x') {
            value = -distanceX;
          }
          if (axis === 'y') {
            value = -distanceY;
          }
          values.push(value);
        }
        maxValue = Math.max.apply(Math, values);
      }
      if (easing) {
        values = values.map(function (val) {
          return easing(val / maxValue) * maxValue;
        });
      }
      if (direction === 'reverse') {
        values = values.map(function (val) {
          return axis ? val < 0 ? val * -1 : -val : Math.abs(maxValue - val);
        });
      }
    }
    var spacing = isRange ? (val2 - val1) / maxValue : val1;
    return start + spacing * (Math.round(values[i] * 100) / 100) + unit;
  };
}
function timeline(params) {
  if (params === void 0) params = {};
  var tl = anime(params);
  tl.duration = 0;
  tl.add = function (instanceParams, timelineOffset) {
    var tlIndex = activeInstances.indexOf(tl);
    var children = tl.children;
    if (tlIndex > -1) {
      activeInstances.splice(tlIndex, 1);
    }
    function passThrough(ins) {
      ins.passThrough = true;
    }
    for (var i = 0; i < children.length; i++) {
      passThrough(children[i]);
    }
    var insParams = mergeObjects(instanceParams, replaceObjectProps(defaultTweenSettings, params));
    insParams.targets = insParams.targets || params.targets;
    var tlDuration = tl.duration;
    insParams.autoplay = false;
    insParams.direction = tl.direction;
    insParams.timelineOffset = is.und(timelineOffset) ? tlDuration : getRelativeValue(timelineOffset, tlDuration);
    passThrough(tl);
    tl.seek(insParams.timelineOffset);
    var ins = anime(insParams);
    passThrough(ins);
    children.push(ins);
    var timings = getInstanceTimings(children, params);
    tl.delay = timings.delay;
    tl.endDelay = timings.endDelay;
    tl.duration = timings.duration;
    tl.seek(0);
    tl.reset();
    if (tl.autoplay) {
      tl.play();
    }
    return tl;
  };
  return tl;
}
anime.version = '3.1.0';
anime.speed = 1;
anime.running = activeInstances;
anime.remove = removeTargets;
anime.get = getOriginalTargetValue;
anime.set = setTargetsValue;
anime.convertPx = convertPxToUnit;
anime.path = getPath;
anime.setDashoffset = setDashoffset;
anime.stagger = stagger;
anime.timeline = timeline;
anime.easing = parseEasings;
anime.penner = penner;
anime.random = function (min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};
/* harmony default export */ const vendor_anime = (anime);
;// CONCATENATED MODULE: ./src/utils/animationConsts.js
var allowCSSProperties = ['height', 'left', 'matrix', 'matrix3d', 'opacity', 'right', 'rotate', 'rotate3d', 'rotateX', 'rotateY', 'rotateZ', 'scale', 'scale3d', 'scaleX', 'scaleY', 'scaleZ', 'skew', 'skewX', 'skewY', 'top', 'translate', 'translate3d', 'translateX', 'translateY', 'translateZ', 'width', 'backgroundColor', 'bottom', 'borderRadius'];
var extraParameters = ['duration', 'direction', 'loop', 'delay', 'endDelay', 'easing', 'keyframes', 'value', 'round'];
var acceptParameters = [...allowCSSProperties, ...extraParameters];
var easeWithAnimeJS = ['easeInElastic', 'easeOutElastic', 'easeInOutElastic', 'easeSpringElastic'];
;// CONCATENATED MODULE: ./src/utils/animation.js




var _assign = Object.assign;
var _objKeys = Object.keys;
var _excludeKeyframes = ['translateX', 'translateY', 'translateZ', 'rotate', 'rotateX', 'rotateY', 'rotateZ', 'scale', 'scaleX', 'scaleY', 'scaleZ', 'skew', 'skewX', 'skewY', 'perspective', 'delay', 'duration', 'offset', 'easing'];
var _validEasingFunc = ['linear', 'ease', 'ease-in', 'ease-out', 'ease-in-out', 'cubic-bezier', 'steps'];
var _normalizeValue = (val, isSameOffset) => {
  var _getSDK;
  val = ((_getSDK = getSDK()) === null || _getSDK === void 0 ? void 0 : _getSDK.predefinedColor[val]) || val;
  return isSameOffset ? [val, val] : val;
};
var _parseTransform = (string, isSameOffset) => {
  string = string.toLowerCase().trim();
  if (string === 'none') {
    return {};
  }
  var result = {};
  var supportedTransforms = _excludeKeyframes.map(item => item.toLowerCase());
  var seperatedTransforms = {
    scale3d: 'AAA',
    translate: 'Aa',
    translate3d: 'AAA',
    rotate3d: 'AAAA',
    matrix3d: 'AAAAAA',
    matrix: 'AAAAAAAAAAAAAAAA'
  };
  var unsupportedTransforms = ['rotate3d', 'matrix', 'matrix3d'];
  var transformRegExp = /\s*(\w+)\(([^)]*)\)/g;
  var match;
  var prevLastIndex = 0;
  while (match = transformRegExp.exec(string)) {
    if (match.index !== prevLastIndex) {
      return {};
    }
    prevLastIndex = match.index + match[0].length;
    var functionName = match[1];
    var args = match[2].split(',');
    if (supportedTransforms.indexOf(functionName) > -1) {
      result[functionName.replace(/(x|y|z)$/, ch => ch.toUpperCase())] = _normalizeValue(args.join(' '), isSameOffset);
    } else if (_objKeys(seperatedTransforms).indexOf(functionName) > -1) {
      var argTypes = seperatedTransforms[functionName];
      if (args.length > argTypes.length) {
        return {};
      }
      for (var i = argTypes.length - 1; i >= 0; i--) {
        var type = argTypes[i];
        if (type === 'a' && !args[i]) {
          continue;
        }
        if (type === 'A' && !args[i]) {
          return {};
        }
        if (unsupportedTransforms.indexOf(functionName) === -1) {
          result[functionName.replace('3d', '') + String.fromCharCode(88 + i)] = _normalizeValue(args[i].trim(), isSameOffset);
        }
      }
    } else return {};
  }
  return result;
};
var _normalizeKeyframes = (keyframes, duration) => {
  var numKeyframes = keyframes.length;
  var previousOffset = 0;
  return keyframes.map((keyframe, i) => {
    var _keyframe = {};
    var offset;
    if ('offset' in keyframe) {
      offset = keyframe.offset;
    } else if (numKeyframes === 1) {
      offset = 1.0;
    } else {
      offset = i / (numKeyframes - 1.0);
    }
    var isSameOffset = previousOffset === offset;
    _objKeys(keyframe).forEach(key => {
      if (_excludeKeyframes.indexOf(key) > -1) {
        return;
      }
      if (key === 'transform') {
        _assign(_keyframe, _parseTransform(keyframe[key], isSameOffset));
        return;
      }
      _keyframe[key] = _normalizeValue(keyframe[key], isSameOffset);
    });
    if (isSameOffset) {
      _keyframe.duration = 0;
    } else {
      _keyframe.duration = (offset - previousOffset) * duration;
      previousOffset = offset;
    }
    return _keyframe;
  });
};
var _normalizeEasing = string => {
  var i = 0;
  for (; i < _validEasingFunc.length; i++) {
    if (string.indexOf(_validEasingFunc[i]) === 0) {
      break;
    }
  }
  if (i === _validEasingFunc.length) {
    return 'linear';
  }
  switch (string) {
    case 'ease':
      return 'cubicBezier(0.25, 0.1, 0.25, 1)';
    case 'ease-in':
      return 'cubicBezier(0.42, 0, 1, 1)';
    case 'ease-out':
      return 'cubicBezier(0, 0, 0.58, 1)';
    case 'ease-in-out':
      return 'cubicBezier(0.42, 0, 0.58, 1)';
    default:
      return string.replace(/^cubic-bezier/, 'cubicBezier');
  }
};
var _flattenEasingToKeyframeSet = (keyframeSet, keyframeOptions) => {
  var easing = keyframeOptions.easing;
  delete keyframeOptions.easing;
  return keyframeSet.map(item => {
    item.easing = easing;
    return item;
  });
};
class Animation {
  constructor(effect, timeline) {
    this._nativeSupported = typeof HTMLElement.prototype.animate === 'function';
    var options = effect.keyframeOptions;
    var drct = this.direction = options.direction;
    this.timeline = timeline;
    if (this._nativeSupported) {
      var keyframeSet = _flattenEasingToKeyframeSet(effect.keyframeSet, options);
      this._inst = effect.element.$$.animate(keyframeSet, _assign(options, {
        fill: 'both'
      }));
      this._inst.pause();
    } else {
      this._inst = vendor_anime({
        targets: effect.element,
        keyframes: _normalizeKeyframes(effect.keyframeSet, options.duration),
        autoplay: false,
        loop: options.iterations === Infinity || options.iterations,
        easing: _normalizeEasing(options.easing),
        direction: 'normal',
        delay: drct === 'reverse' ? options.endDelay : options.delay,
        endDelay: drct === 'reverse' ? options.delay : options.endDelay
      });
    }
    timeline._driven(this);
  }
  set currentTime(time) {
    if (isNaN(time)) {
      return;
    }
    var _inst = this._inst;
    if (this._nativeSupported) {
      _inst.currentTime = time;
    } else {
      if (this.direction === 'reverse') {
        _inst.seek(_inst.duration - time);
      } else {
        _inst.seek(time);
      }
    }
  }
  cancel() {
    if (this._nativeSupported) {
      this._inst.cancel();
    } else {
      this._inst.reset();
    }
    this.timeline._destroy();
    this._inst = null;
  }
}
class ScrollTimeline {
  constructor(shadowTree, options) {
    if (options.scrollSource) {
      this._scrollNode = window.__DOMTree__.shadowRoot.querySelector(options.scrollSource);
      if (!this._scrollNode) {
        this._scrollNode = shadowTree && shadowTree.querySelector(options.scrollSource);
      }
      if (!this._scrollNode) {
        throw new Error(`Cannot find scroll source by ${options.scrollSource} selector.`);
      }
    } else {
      this._scrollNode = window.__DOMTree__;
    }
    this.orientation = options.orientation || 'vertical';
    this.startScrollOffset = options.startScrollOffset;
    this.endScrollOffset = options.endScrollOffset;
    this.timeRange = options.timeRange;
    this.fill = options.fill || 'both';
    this._scroll = this._scroll.bind(this);
  }
  _calcCurrentTime(detail, target) {
    var startScrollOffset = this.startScrollOffset;
    var endScrollOffset = this.endScrollOffset;
    var fill = this.fill;
    var timeRange = this.timeRange;
    var currentScrollOffset = detail.scrollTop;
    var maxScrollOffset = detail.scrollHeight - target.$$.offsetHeight;
    if (this.orientation === 'horizontal') {
      currentScrollOffset = detail.scrollLeft;
      maxScrollOffset = detail.scrollWidth - target.$$.offsetWidth;
    }
    if (currentScrollOffset < startScrollOffset) {
      if (fill === 'none' || fill === 'forwards') {
        return NaN;
      }
      return 0;
    }
    if (currentScrollOffset >= endScrollOffset) {
      if (endScrollOffset < maxScrollOffset && (fill === 'none' || fill === 'backwards')) {
        return NaN;
      }
      return timeRange;
    }
    if (startScrollOffset >= endScrollOffset) {
      return NaN;
    }
    return (currentScrollOffset - startScrollOffset) / (endScrollOffset - startScrollOffset) * timeRange;
  }
  _scroll() {
    var currentTime = this._calcCurrentTime(this._scrollNode === window.__DOMTree__ ? window.__DOMTree__.$$ : this._scrollNode.getScrollPosition(), this._scrollNode);
    this._animation.currentTime = currentTime;
  }
  _driven(animation) {
    this._animation = animation;
    if (this._scrollNode === window.__DOMTree__) {
      document.addEventListener('scroll', this._scroll, {
        capture: true,
        passive: true
      });
    } else {
      this._scrollNode.$$.addEventListener('scroll', this._scroll, {
        capture: true,
        passive: true
      });
    }
    this._scroll();
  }
  _destroy() {
    if (this._scrollNode === window.__DOMTree__) {
      document.removeEventListener('scroll', this._scroll, {
        capture: true,
        passive: true
      });
    } else {
      this._scrollNode.$$.removeEventListener('scroll', this._scroll, {
        capture: true,
        passive: true
      });
    }
  }
}
var _bindScrollAnimation = (shadowTree, node, originalKeyframeSet, animation, timeline) => {
  var keyframeSet = originalKeyframeSet.map(frame => {
    var ret = {};
    Object.entries(frame).forEach(([k, v]) => {
      ret[k] = normalizeAnimationStyle(v);
    });
    return ret;
  });
  var _effect = {
    element: node,
    keyframeSet,
    keyframeOptions: {
      delay: animation.delay || 0,
      direction: animation.direction || 'normal',
      duration: animation.duration || 0,
      easing: animation.easing || 'linear',
      endDelay: animation.endDelay || 0,
      iterations: 1
    }
  };
  var _scrollTimeline = new ScrollTimeline(shadowTree, timeline);
  node.__scrollAnimations = node.__scrollAnimations || [];
  node.__scrollAnimations.push(new Animation(_effect, _scrollTimeline));
};
var bindScrollAnimations = ({
  nodeId,
  selector,
  options,
  duration,
  timeline
}, tm) => {
  var shadowTree = tm.nodeId.getNodeById(nodeId);
  if (shadowTree) {
    shadowTree = shadowTree.shadowRoot;
  } else {
    shadowTree = window.__DOMTree__ ? window.__DOMTree__.shadowRoot : null;
  }
  var nodes = shadowTree ? shadowTree.querySelectorAll(selector) : [];
  for (var i = 0; i < nodes.length; i++) {
    _bindScrollAnimation(shadowTree, nodes[i], options, {
      duration
    }, timeline);
  }
};
var unbindScrollAnimation = node => {
  ;
  (node.__scrollAnimations || []).forEach(animation => {
    animation.cancel();
  });
  node.__scrollAnimations = [];
};
var animationOptionHandler = (options, duration) => {
  var _options = [];
  for (var i = 0; i < options.length; ++i) {
    _options.push(Object.assign({}, options[i]));
  }
  _options[0].offset = 0;
  _options[_options.length - 1].offset = 1;
  var getOffset = function (index, _options) {
    if (typeof _options[index].offset === 'number') return _options[index].offset;
    for (var _i = index + 1; _i < _options.length; ++_i) {
      if (_options[_i].offset) {
        return (_options[_i].offset - _options[index - 1].offset) / (_i - index + 1) + _options[index - 1].offset;
      }
    }
    return 0;
  };
  var _loop = function (_i2) {
    _options[_i2].offset = getOffset(_i2, _options);
    if (_i2 === 0) _options[_i2].duration = 0;else _options[_i2].duration = (_options[_i2].offset - _options[_i2 - 1].offset) * duration;
    var shouldTriggerWithAnimeJS = easeWithAnimeJS.some(funcName => _options[_i2].ease && _options[_i2].ease.startsWith(funcName));
    if (shouldTriggerWithAnimeJS) {
      _options[_i2].type = 'animeJS';
    }
  };
  for (var _i2 = 0; _i2 < _options.length; ++_i2) {
    _loop(_i2);
  }
  return _options;
};
;// CONCATENATED MODULE: ./src/utils/tap_mark.js
var currentTapMark = 0;
var timeoutQueue = [];
var timeout = (...args) => {
  timeoutQueue.push(args);
};
Foundation.onLoad(() => {
  timeout = setTimeout;
  timeoutQueue.forEach(args => {
    setTimeout(...args);
  });
  timeoutQueue.length = 0;
});
var endTapMark = function (tapMark) {
  if (currentTapMark === tapMark) {
    currentTapMark = 0;
  }
};
var beginTapMark = function () {
  currentTapMark = Date.now() + Math.random();
  return currentTapMark;
};
var wrapTapMark = function (func) {
  var tapMark = beginTapMark();
  var ret;
  try {
    ret = func(tapMark);
  } catch (e) {
    timeout(() => {
      endTapMark(tapMark);
    }, 0);
    throw e;
  }
  timeout(() => {
    endTapMark(tapMark);
  }, 0);
  return ret;
};
var checkTapMark = function () {
  return !!currentTapMark;
};
;// CONCATENATED MODULE: ./src/wxs/index.js









var wxs_exparser = getExparser();
var wxs_hasOwnProperty = Object.prototype.hasOwnProperty;
var isUsingComponent = false;
var $gdcPrefix = 'nv_';
var $gdc = null;
var setWxsGdc = gdc => {
  if (typeof gdc !== 'function') return;
  $gdc = gdc;
};
var getWxsGdc = () => {
  if (typeof $gdc === 'function') return $gdc;
  return null;
};
var wxsDeepCopy = (obj, withFunc) => {
  if (!$gdc) return obj;
  return $gdc(obj, $gdcPrefix, withFunc ? 2 : undefined);
};
var wxsDeepDecopy = (obj, withFunc = false) => {
  if (!$gdc) return obj;
  return $gdc(obj, undefined, withFunc ? 2 : undefined);
};
var joinClassOrStyle = (seperate, style, wxsStyle) => {
  if (!style) return wxsStyle || '';
  if (!wxsStyle) return style || '';
  return style + seperate + wxsStyle;
};
var triggerEventCount = 0;
var mustReRenderInNextFrame = false;
var triggerPageRerender = () => {
  if (!isDataThread() && mustReRenderInNextFrame && triggerEventCount === 0) {
    mustReRenderInNextFrame = false;
    wx.triggerPageReRender();
  }
};
var getComponentDomain = comp => comp instanceof wxs_exparser.Component && wxs_exparser.Component.getComponentOptions(comp).domain;
var isWxComponent = comp => comp instanceof wxs_exparser.Component && wxs_exparser.Component.getComponentOptions(comp).domain === '//';
var nextAnimationFrameId = null;
var animationFrameCallback = [];
var registerAnimationFrameCallback = cb => {
  if (isDataThread() || typeof cb !== 'function') return;
  animationFrameCallback.push(cb);
  if (!nextAnimationFrameId) {
    nextAnimationFrameId = window.requestAnimationFrame(() => {
      nextAnimationFrameId = null;
      var tmpCallbackList = animationFrameCallback;
      animationFrameCallback = [];
      tmpCallbackList.forEach(callbackItem => {
        callbackItem();
        triggerPageRerender();
      });
    });
  }
};
var timerIDs = {};
var _getWxsHandlerInstance = (shadowTree, rootDomain) => {
  var hostNode = shadowTree;
  var nodeDomain = getComponentDomain(hostNode);
  var iswxComp = isWxComponent(hostNode);
  var tm = tree_manager.getByNode(hostNode);
  var instance = {
    selectAllComponents(selector) {
      if (rootDomain !== nodeDomain) {
        return [];
      }
      var queryResult = isUsingComponent ? shadowTree.shadowRoot.querySelectorAll(selector) : shadowTree.querySelectorAll(selector);
      var wxsInstances = [];
      queryResult.forEach(item => {
        wxsInstances.push(wxsDeepCopy(_getWxsHandlerInstance(item, rootDomain), true));
      });
      return wxsInstances;
    },
    selectComponent(selector) {
      if (rootDomain !== nodeDomain) {
        return null;
      }
      var queryResult = isUsingComponent ? shadowTree.shadowRoot.querySelector(selector) : shadowTree.querySelector(selector);
      if (queryResult) {
        return wxsDeepCopy(_getWxsHandlerInstance(queryResult, rootDomain), true);
      }
      return null;
    },
    removeClass(...args) {
      if (isDataThread() || !hostNode || !args.length) return this;
      var currentWxsClass = hostNode.__wxsClass ? hostNode.__wxsClass.split(/\s+/) : [];
      var removeClassList = [];
      args.forEach(className => {
        className = className.replace(/^\s+|\s+$/g, '');
        if (!className) return;
        if (hostNode.classList.contains(className)) {
          hostNode.classList.toggle(className);
          mustReRenderInNextFrame = true;
          removeClassList.push(className);
        }
      });
      removeClassList.forEach(className => {
        currentWxsClass.forEach((currentClassName, idx) => {
          if (currentClassName === className) {
            currentWxsClass.splice(idx, 1);
            return false;
          }
          return true;
        });
      });
      hostNode.__wxsClass = currentWxsClass.join(' ');
      return this;
    },
    addClass(...args) {
      if (isDataThread() || !hostNode || !args.length) return this;
      var currentWxsClass = hostNode.__wxsClass || '';
      var addClassList = [];
      args.forEach(className => {
        className = className.replace(/^\s+|\s+$/g, '');
        if (!className) return;
        if (!hostNode.classList.contains(className)) {
          hostNode.classList.toggle(className);
          addClassList.push(className);
          mustReRenderInNextFrame = true;
        }
      });
      hostNode.__wxsClass = currentWxsClass + (currentWxsClass ? ' ' : '') + addClassList.join(' ');
      return this;
    },
    hasClass(className) {
      if (isDataThread() || !hostNode) return false;
      return hostNode.classList.contains(className);
    },
    setStyle(style) {
      if (isDataThread() || !hostNode) return this;
      if (style === hostNode.__wxsStyle) {
        return this;
      }
      var styleStr = [];
      if (typeof style === 'object') {
        style = style ? wxsDeepDecopy(style) : {};
        for (var k of Object.keys(style)) {
          styleStr.push(`${k}:${style[k]}`);
        }
      } else {
        styleStr = [String(style)];
      }
      hostNode.__wxsStyle = styleStr.join(';');
      var applyStyle = () => {
        var transformedStyleStr = window.wx.transformRpx(hostNode.__wxsStyle, true);
        hostNode.setNodeStyle(transformedStyleStr, STYLE_SEGMENT_INDEX.WXS_STYLE);
      };
      applyStyle();
      registerResizer(hostNode, STYLE_SEGMENT_INDEX.WXS_STYLE, applyStyle);
      mustReRenderInNextFrame = true;
      if (currentRenderBackend() === 'skyline') {
        var skylineRuntime = getSkylineRuntime();
        wxNativeConsole.info(`[Skyline] call startRender on id ${tm.viewId}, reason: wxs setStyle`);
        skylineRuntime.getContext(tm.viewId).startRender();
      }
      return this;
    },
    getDataset() {
      if (!hostNode) return null;
      return wxsDeepCopy(hostNode.dataset);
    },
    getState() {
      if (!hostNode) return null;
      hostNode.__wxsState = hostNode.__wxsState || (typeof __wxCodeSpace__ !== 'undefined' && typeof __wxCodeSpace__.createWxsStateObject === 'function' ? __wxCodeSpace__.createWxsStateObject() : {});
      return hostNode.__wxsState;
    },
    triggerEvent(eventName, detail, option) {
      if (iswxComp || !shadowTree) return this;
      detail = detail ? wxsDeepDecopy(detail) : detail;
      option = option ? wxsDeepDecopy(option) : option;
      triggerEventCount++;
      hostNode.triggerEvent(eventName, detail, option);
      triggerEventCount--;
      return this;
    },
    callMethod(funcName, args = {}) {
      if (isDataThread() || !funcName) return this;
      args = wxsDeepDecopy(args);
      if (!isUsingComponent) {
        callMethodFromWxs(tm, shadowTree, funcName, args);
      } else {
        var caller = shadowTree;
        if (!shadowTree || !shadowTree.__wxTmplId) {
          console.error('Call method on a non-custom-component node is invalid. Call on the owner component or page instead. To avoid this error hint, try not to call method on `event.instance` , but on `ownerInstance` instead.');
          var n = caller.ownerShadowRoot ? caller.ownerShadowRoot.__wxHost : tm.root;
          caller = n;
        }
        callMethodFromWxs(tm, caller, funcName, args);
      }
      return this;
    },
    requestAnimationFrame(func) {
      if (isDataThread() || typeof func !== 'function') return this;
      registerAnimationFrameCallback(func);
      return this;
    },
    getComputedStyle(fields) {
      if (!Array.isArray(fields)) fields = [];
      var args = {
        computedStyle: fields.filter(key => typeof key === 'string')
      };
      return wxsDeepCopy(getNodeInfo(hostNode, args));
    },
    setTimeout(func, delay, ...args) {
      if (isDataThread() || typeof func !== 'function') {
        return undefined;
      }
      var timerId = window.setTimeout(() => {
        func(...args);
        delete timerIDs[timerId];
      }, delay);
      timerIDs[timerId] = true;
      return timerId;
    },
    clearTimeout(timerId) {
      if (isDataThread()) {
        return;
      }
      var isValid = timerIDs[timerId];
      if (!isValid) {
        return;
      }
      window.clearTimeout(timerId);
      delete timerIDs[timerId];
    },
    getBoundingClientRect() {
      if (isDataThread()) {
        return {};
      }
      var rect = hostNode.$$ && hostNode.$$.getBoundingClientRect();
      if (!rect) {
        return {};
      }
      return wxsDeepCopy({
        x: rect.x,
        y: rect.y,
        width: rect.width,
        height: rect.height,
        top: rect.top,
        right: rect.right,
        bottom: rect.bottom,
        left: rect.left
      });
    },
    animate(options, duration, callback) {
      options = wxsDeepDecopy(options);
      var _options = animationOptionHandler(options, duration);
      for (var i = 0; i < _options.length; ++i) {
        var reqId = `${Math.random()}-${+new Date()}`;
        var shouldTriggerWithAnimeJS = _options[i].type === 'animeJS';
        delete _options[i].type;
        var basicData = {
          nodeId: hostNode.getNodeId(),
          webviewId: tm.viewId,
          options: _options[i],
          selector: `#${hostNode.$$.id}`,
          reqId,
          type: shouldTriggerWithAnimeJS ? 'animeJS' : undefined,
          fromWxs: true
        };
        if (i === _options.length - 1) {
          basicData.hasCallback = typeof callback === 'function';
          if (typeof callback === 'function') {
            tm.applyAnimationCbMap[reqId] = callback;
          }
          basicData.isLastAnimation = true;
          setNodeAnimationInfo(basicData);
        } else {
          basicData.hasCallback = false;
          basicData.isLastAnimation = false;
          setNodeAnimationInfo(basicData);
        }
      }
    },
    clearAnimation(options, callback) {
      var reqId = `${Math.random()}-${+new Date()}`;
      var hasCallback = false;
      if (typeof callback === 'function') {
        options = wxsDeepDecopy(options);
        tm.clearAnimationCbMap[reqId] = callback;
        hasCallback = true;
      } else if (typeof options === 'function') {
        tm.clearAnimationCbMap[reqId] = options;
        hasCallback = true;
      }
      var basicData = {
        nodeId: hostNode.getNodeId(),
        webviewId: tm.viewId,
        options,
        selector: `#${hostNode.$$.id}`,
        reqId,
        fromWxs: true,
        hasCallback
      };
      clearNodeAnimationInfo(basicData);
    }
  };
  Object.freeze(instance);
  return instance;
};
var getWxsHandlerInstance = (node, isOwner) => {
  var host = node.ownerShadowRoot ? node.ownerShadowRoot.__wxHost : window.__DOMTree__;
  var shadowTree = isOwner ? host : node;
  isUsingComponent = !!node.ownerShadowRoot;
  var instance = _getWxsHandlerInstance(shadowTree, getComponentDomain(shadowTree));
  return instance;
};
var animationId = null;
var wxsObserverList = [];
var _triggerWxsObserver = (node, props) => {
  for (var propName in node.wxsObserver) {
    if (wxs_hasOwnProperty.call(props, propName) && node.wxsObserver[propName] && typeof node.wxsObserver[propName].observer === 'function') {
      var oldValue = node.wxsObserver[propName].value;
      wxs_exparser.safeCallback('WXS Observer', node.wxsObserver[propName].observer, null, [wxsDeepCopy(props[propName]), wxsDeepCopy(oldValue), wxsDeepCopy(getWxsHandlerInstance(node, true), true), wxsDeepCopy(getWxsHandlerInstance(node), true)], node.ownerShadowRoot ? node.ownerShadowRoot.__wxHost : undefined);
      node.wxsObserver[propName].value = props[propName];
    }
  }
};
var triggerWxsObserver = (node, props) => {
  if (!node.wxsObserver || isDataThread() || save_restore_view_states.restoring) return;
  wxsObserverList.push({
    node,
    props
  });
  if (!animationId) {
    animationId = window.requestAnimationFrame(() => {
      animationId = null;
      var tmpWxsObserverList = wxsObserverList;
      wxsObserverList = [];
      tmpWxsObserverList.forEach(item => {
        _triggerWxsObserver(item.node, item.props);
      });
    });
  }
};
var callMethodFromWxs = (tm, exparserNode, funcName, args) => {
  bridge_sendData(constants_SYNC_EVENT_NAME.CALL_METHOD_FROM_WXS, [exparserNode && exparserNode.__wxTmplId || 0, funcName, args, checkTapMark()], tm.viewId);
};
var callMethodFromWxsCallback = ([compId, name, args, needWrapUserTap], webviewId) => {
  args || (args = {});
  if (compId) {
    var tm = tree_manager.get(webviewId);
    if (!tm) return;
    var node = tm.nodeId.getNodeById(compId);
    if (!node) return;
    var caller = wxs_exparser.Element.getMethodCaller(node);
    if (caller && typeof caller[name] === 'function') {
      if (needWrapUserTap) {
        wrapTapMark(() => {
          caller[name](args);
        });
      } else {
        caller[name](args);
      }
    }
  } else {
    var pages = __appServiceEngine__.getCurrentPagesByDomain('');
    if (!pages.length) return;
    var page = pages[pages.length - 1];
    if (page && typeof page[name] === 'function') {
      if (needWrapUserTap) {
        wrapTapMark(() => {
          page[name](args);
        });
      } else {
        page[name](args);
      }
    }
  }
};
var restoreExtraData = (node, extraData) => {
  node.__wxsStyle = extraData.wxsStyle;
  node.__wxsClass = extraData.wxsClass;
  node.__wxsState = wxsDeepCopy(extraData.wxsState);
  if (extraData.wxsStyle) {
    var applyStyle = () => {
      var transformedStyleStr = window.wx.transformRpx(node.__wxsStyle, true);
      node.setNodeStyle(transformedStyleStr, STYLE_SEGMENT_INDEX.WXS_STYLE);
    };
    applyStyle();
    registerResizer(node, STYLE_SEGMENT_INDEX.WXS_STYLE, applyStyle);
  }
  if (extraData.wxsClass) {
    node.class = joinClassOrStyle(' ', node.class, extraData.wxsClass);
  }
};
var saveNodeExtraData = (extraDataMap, node, nodeIndex) => {
  if (node.__wxsStyle || node.__wxsClass) {
    var extraData = {
      wxsStyle: node.__wxsStyle,
      wxsClass: node.__wxsClass,
      index: nodeIndex,
      wxsState: wxsDeepDecopy(node.__wxsState)
    };
    if (node.ownerShadowRoot) {
      var tm = tree_manager.getByNode(node);
      var hostId = tm.nodeId.getNodeId(node.ownerShadowRoot.__wxHost);
      extraDataMap._custom = extraDataMap._custom || {};
      extraDataMap = extraDataMap._custom;
      extraDataMap[hostId] = extraDataMap[hostId] || {};
      extraDataMap = extraDataMap[hostId];
    }
    extraDataMap[node.is] = extraDataMap[node.is] || [];
    extraDataMap[node.is].push(extraData);
  }
};
var restoreNodeExtraData = (extraDataMap, node, nodeIndex) => {
  if (!extraDataMap) return;
  var extraData = null;
  if (node.ownerShadowRoot && extraDataMap._custom) {
    var tm = tree_manager.getByNode(node);
    var hostId = tm.nodeId.getNodeId(node.ownerShadowRoot.__wxHost);
    extraDataMap = extraDataMap._custom;
    if (!extraDataMap[hostId]) return;
    extraDataMap = extraDataMap[hostId];
  }
  if (extraDataMap[node.is] && extraDataMap[node.is].length) {
    if (extraDataMap[node.is][0] && extraDataMap[node.is][0].index === nodeIndex) {
      extraData = extraDataMap[node.is].shift();
    }
  }
  if (!extraData) return;
  restoreExtraData(node, extraData);
};
var saveRootExtraData = extraData => {
  if (isDataThread() || !extraData) return;
  var rootNode = isUsingComponent ? tree_manager.get(0).nodeId.getNodeById(tree_manager.get(0).rootNodeId) : window.__DOMTree__;
  if (rootNode) {
    extraData.wxsPageState = rootNode.__wxsState;
  }
};
var restoreRootExtraData = extraData => {
  if (isDataThread() || !extraData) return;
  var rootNode = isUsingComponent ? tree_manager.get(0).nodeId.getNodeById(tree_manager.get(0).rootNodeId) : window.__DOMTree__;
  if (rootNode) {
    rootNode.__wxsState = extraData.wxsPageState;
  }
};
var saveTabRootExtraData = extraData => {
  if (isDataThread() || !extraData) return;
  var rootNode = window.__TAB_BAR__;
  if (rootNode) {
    extraData.wxsTabRootState = wxsDeepDecopy(rootNode.__wxsState);
  }
};
var restoreTabRootExtraData = extraData => {
  if (isDataThread() || !extraData) return;
  var rootNode = window.__TAB_BAR__;
  if (rootNode) {
    rootNode.__wxsState = wxsDeepCopy(extraData.wxsTabRootState);
  }
};
;// CONCATENATED MODULE: ./src/tmpl/dom_path.js
class Step {
  constructor(value, optimized) {
    this.value = value;
    this.optimized = optimized || false;
  }
  toString() {
    return this.value;
  }
}
function getParentWXMLNode(target) {
  var _target$tagName;
  if (target === null || target !== null && target !== void 0 && (_target$tagName = target.tagName) !== null && _target$tagName !== void 0 && _target$tagName.startsWith('WX-')) {
    return target;
  }
  return getParentWXMLNode(target.parentElement);
}
function getParentNode(node) {
  var _node$__wxElement;
  if (!(node !== null && node !== void 0 && (_node$__wxElement = node.__wxElement) !== null && _node$__wxElement !== void 0 && _node$__wxElement.parentNode)) {
    return null;
  }
  return getParentWXMLNode(node.parentElement);
}
var _xPathIndex = function (node) {
  function areNodesSimilar(left, right) {
    if (left === right) {
      return true;
    }
    if (left.nodeType === Node.ELEMENT_NODE && right.nodeType === Node.ELEMENT_NODE) {
      return left.localName === right.localName;
    }
    if (left.nodeType === right.nodeType) {
      return true;
    }
    var leftType = left.nodeType === Node.CDATA_SECTION_NODE ? Node.TEXT_NODE : left.nodeType;
    var rightType = right.nodeType === Node.CDATA_SECTION_NODE ? Node.TEXT_NODE : right.nodeType;
    return leftType === rightType;
  }
  var siblings = node.parentNode ? node.parentNode.children : null;
  if (!siblings) {
    return 0;
  }
  var hasSameNamedElements;
  var ownIndex = 1;
  for (var i = 0; i < siblings.length; ++i) {
    if (siblings[i] === node) {
      if (hasSameNamedElements) {
        return ownIndex;
      } else {
        return 0;
      }
    }
    if (areNodesSimilar(node, siblings[i])) {
      hasSameNamedElements = true;
      ownIndex += 1;
    }
  }
  return -1;
};
var _xPathValue = (node, optimized) => {
  var ownValue;
  var ownIndex = _xPathIndex(node);
  if (ownIndex === -1) {
    return null;
  }
  switch (node.nodeType) {
    case Node.ELEMENT_NODE:
      if (optimized && node.getAttribute('id')) {
        return new Step(`//*[@id="${node.getAttribute('id')}"]`, true);
      }
      ownValue = node.localName.replace('wx-', '');
      break;
    case Node.ATTRIBUTE_NODE:
      ownValue = `@${node.nodeName}`;
      break;
    case Node.TEXT_NODE:
    case Node.CDATA_SECTION_NODE:
      ownValue = 'text()';
      break;
    case Node.PROCESSING_INSTRUCTION_NODE:
      ownValue = 'processing-instruction()';
      break;
    case Node.COMMENT_NODE:
      ownValue = 'comment()';
      break;
    case Node.DOCUMENT_NODE:
      ownValue = '';
      break;
    default:
      ownValue = '';
      break;
  }
  if (ownIndex > 0) {
    ownValue += `[${ownIndex}]`;
  }
  return new Step(ownValue, node.nodeType === Node.DOCUMENT_NODE);
};
var xPathGen = (node, optimized) => {
  var steps = [];
  var contextNode = node;
  while (contextNode) {
    var step = _xPathValue(contextNode, optimized);
    if (!step) {
      break;
    }
    steps.push(step);
    if (step.optimized) {
      break;
    }
    if (!contextNode.__wxElement) {
      break;
    }
    contextNode = getParentNode(contextNode);
  }
  steps.reverse();
  return (steps.length && steps[0].optimized ? '' : '/') + steps.join('/');
};
;// CONCATENATED MODULE: ./src/utils/temp_whitelist.js
var tempWhiteListForXpathFeature = ['wx0cb2b558740023ad', 'wx4aedf8c9edf9fd72', 'wx34345ae5855f892d'];
/* harmony default export */ const temp_whitelist = (tempWhiteListForXpathFeature);
;// CONCATENATED MODULE: ./src/tmpl/props.js












var props_exparser = getExparser();
var getComponentOptions = props_exparser.Component.getComponentOptions;
var getExparserNode = caller => {
  if (isDataThread() && caller instanceof props_exparser.Component) {
    return tree_manager.get(caller.__wxWebviewId__).nodeId.getNodeById(caller.__wxExparserNodeId__);
  }
  return caller;
};
var isTextElement = ele => ele instanceof props_exparser.TextNode;
var getTextContentByDFSSpecialLayerFromExparserNode = (root, layer) => {
  var text = '';
  var helper = (root, layer, curLayer) => {
    if (curLayer > layer) return;
    if (!root) return;
    if (isTextElement(root)) text += root.$$.textContent;else if (Array.isArray(root.childNodes)) {
      root.childNodes.forEach(child => helper(child, layer, curLayer + 1));
    }
  };
  helper(root, layer, 1);
  return text;
};
var convertEventTargetWithUserAction = (targetCaller, originEvent, type) => {
  if (typeof __userActionTracer__ === 'undefined') return originEvent;
  if (!__userActionTracer__.shouldReportEvent(type)) return originEvent;
  var exparserNode = getExparserNode(targetCaller);
  try {
    var _exparserNode$classLi;
    var userActionTrace = {
      text: __userActionTracer__.limitContent(getTextContentByDFSSpecialLayerFromExparserNode(exparserNode, __userActionTracer__.getTextContentMaxLayer())),
      id: targetCaller.id,
      classname: __userActionTracer__.convertClassList(exparserNode === null || exparserNode === void 0 ? void 0 : (_exparserNode$classLi = exparserNode.classList) === null || _exparserNode$classLi === void 0 ? void 0 : _exparserNode$classLi._rawNames),
      tag: exparserNode.$$.tagName,
      opentype: exparserNode.openType
    };
    return {
      ...originEvent,
      __extra: userActionTrace
    };
  } catch (e) {
    return originEvent;
  }
};
var convertEventTargetWithPos = (targetCaller, inWriteOnly, currentTargetCaller) => {
  var target = getExparserNode(targetCaller);
  if (currentTargetCaller && target instanceof props_exparser.VirtualNode) {
    if (!target.id && !Object.getOwnPropertyNames(target.dataset).length) {
      target = getExparserNode(currentTargetCaller);
    }
  }
  return {
    id: inWriteOnly ? '' : target.id,
    offsetLeft: target.$$ && !inWriteOnly ? target.$$.offsetLeft : 0,
    offsetTop: target.$$ && !inWriteOnly ? target.$$.offsetTop : 0,
    dataset: inWriteOnly ? {} : target.dataset
  };
};
var convertEventTarget = (targetCaller, inWriteOnly, currentTargetCaller) => {
  var target = getExparserNode(targetCaller);
  if (currentTargetCaller && target instanceof props_exparser.VirtualNode) {
    if (!target.id && !Object.getOwnPropertyNames(target.dataset).length) {
      target = getExparserNode(currentTargetCaller);
    }
  }
  return {
    id: inWriteOnly ? '' : target.id,
    dataset: inWriteOnly ? {} : target.dataset
  };
};
var convertTouches = touches => {
  if (touches) {
    var r = [];
    for (var i = 0; i < touches.length; i++) {
      var touch = touches[i];
      r.push({
        identifier: touch.identifier,
        pageX: touch.pageX,
        pageY: touch.pageY,
        clientX: touch.clientX,
        clientY: touch.clientY,
        x: touch.x,
        y: touch.y,
        force: touch.force || 0
      });
    }
    return r;
  }
  return undefined;
};
var setEventHandlerChangeListener = (node, func) => {
  node.__eventHandlerChangeListener__ = func;
};
var bindEvent = (tm, node, bindName, value, noBubble, capture, isWxsHandler, mutated) => {
  var evNameField = capture ? '__wxEventCaptureHandleName' : '__wxEventHandleName';
  if (!node[evNameField]) {
    node[evNameField] = Object.create(null);
  }
  if (node[evNameField][bindName] === undefined) {
    node.addListener(bindName, function (e) {
      var funcName = node[evNameField][bindName];
      var mutatedMarked = e.mutatedMarked();
      if (mutated && e.mutatedMarked()) return;
      if (mutated) e.markMutated();
      if (!funcName) return;
      e._hasListeners = true;
      var shadowRoot = node.ownerShadowRoot;
      if (shadowRoot) {
        var host = shadowRoot.getHostNode();
        var inWriteOnly = props_exparser.Component.getComponentOptions(host).writeOnly;
        if (!inWriteOnly || e._allowWriteOnly) {
          if (isDataThread()) {
            if (isWxsHandler && typeof funcName === 'function') {
              console.warn('Cannot use wxs function to handle custom event "' + e.type + '".');
              return;
            }
            var caller = props_exparser.Element.getMethodCaller(host);
            if (typeof caller[funcName] !== 'function') {
              console.warn('Component "' + host.is + '" does not have a method "' + funcName + '" to handle event "' + e.type + '".');
            } else {
              caller[funcName]({
                type: e.type,
                timeStamp: e.timeStamp,
                target: convertEventTarget(e.target, inWriteOnly, this),
                currentTarget: convertEventTarget(this, inWriteOnly, null),
                mark: e.mark,
                detail: e.detail,
                touches: e.touches,
                changedTouches: e.changedTouches,
                mut: mutatedMarked,
                _requireActive: e._requireActive
              });
            }
          } else {
            if (isWxsHandler) {
              if (typeof funcName === 'function' && getWxsGdc()) {
                var evObj = {
                  type: e.type,
                  timeStamp: e.timeStamp,
                  target: convertEventTargetWithPos(e.target, inWriteOnly, this),
                  currentTarget: convertEventTargetWithPos(this, inWriteOnly, null),
                  mark: e.mark,
                  detail: e.detail,
                  touches: convertTouches(e.touches),
                  changedTouches: convertTouches(e.changedTouches),
                  mut: mutatedMarked
                };
                evObj.instance = getWxsHandlerInstance(node);
                var wxsBubble = funcName(wxsDeepCopy(evObj, true), wxsDeepCopy(getWxsHandlerInstance(node, true), true));
                triggerPageRerender();
                if (wxsBubble === false) {
                  return wxsBubble;
                }
              } else {
                console.warn('Component "' + host.is + '" does not have a wxs function to handle event "' + e.type + '".');
              }
            } else {
              var isTapAction = checkTapMark(e._userTap);
              var _evObj = {
                type: e.type,
                timeStamp: e.timeStamp,
                target: convertEventTargetWithUserAction(e.target, convertEventTargetWithPos(e.target, inWriteOnly, this), e.type),
                currentTarget: convertEventTargetWithUserAction(this, convertEventTargetWithPos(this, inWriteOnly, null), e.type),
                mark: e.mark,
                detail: e.detail,
                touches: convertTouches(e.touches),
                changedTouches: convertTouches(e.changedTouches),
                mut: mutatedMarked,
                _requireActive: e._requireActive,
                _relatedInfo: e._relatedInfo,
                _userTap: isTapAction
              };
              if (isTapAction) {
                try {
                  var pluginAppId = props_exparser.Component.getComponentOptions(host).domain.split('/', 1)[0];
                  var hostAppId = __wxConfig.accountInfo.appId;
                  var inXpathWhitelist = temp_whitelist.includes(pluginAppId) || temp_whitelist.includes(hostAppId);
                  if (inXpathWhitelist) {
                    var startTs = Date.now();
                    _evObj._xpath = xPathGen(node.$$);
                    _evObj._xpathCost = Date.now() - startTs;
                  }
                } catch (e) {}
              }
              bridge_sendData(constants_SYNC_EVENT_NAME.WX_EVENT, [tm.nodeId.getNodeId(host), funcName, _evObj], tm.viewId, e._requireActive ? true : undefined);
            }
          }
        }
      }
      if (noBubble) {
        return false;
      }
    }, {
      capture
    });
  }
  if (isWxsHandler) {
    node[evNameField][bindName] = value;
    if (currentRenderBackend() === 'skyline' && node.__eventHandlerChangeListener__) {
      node.__eventHandlerChangeListener__(bindName, node[evNameField][bindName], capture);
    }
  } else {
    node[evNameField][bindName] = value == null ? '' : String(value);
    if (node.__eventHandlerChangeListener__) {
      node.__eventHandlerChangeListener__(bindName, node[evNameField][bindName], capture);
    }
    if (currentRenderBackend() !== 'webview' && node.__domElement && typeof node.__domElement.setListenerOption === 'function' && (currentRenderBackend() !== 'skyline' || bindName === 'touchstart')) {
      node.__domElement.setListenerOption(bindName, !noBubble, Boolean(capture));
    }
  }
};
var applyProperties = (node, props, specProps, rawAttr) => {
  var tm = tree_manager.getByNode(node);
  if (node.__component__ && !save_restore_view_states.restoring && node.__isXrFrame__ && isDataThread()) {
    tm.operationFlow.start();
    tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_SET_ROOT_PROPERTIES, props_exparser.dataUtils.deepCopy(props), props_exparser.dataUtils.deepCopy(specProps), props_exparser.dataUtils.deepCopy(rawAttr)]);
  }
  node.dataset = node.dataset || {};
  var delayedPropsCount = 0;
  var needDoUpdates = false;
  var pendingModelBindings = [];
  var isComponentNode = node instanceof props_exparser.Component;
  var isWxComp = isComponentNode && getComponentOptions(node).domain === '//';
  var nodeDataProxy = props_exparser.Component.getDataProxy(node);
  var _loop = function () {
      var propValue = props[propName];
      var matches = null;
      if (node.is === 'slot' && node instanceof props_exparser.VirtualNode && propName === 'name') {
        props_exparser.Element.setSlotName(node, propValue);
        return 0;
      }
      if (propName === 'id') {
        node.id = propValue == undefined ? '' : propValue;
        return 0;
      }
      if (propName === 'slot') {
        node.slot = propValue == undefined ? '' : propValue;
        return 0;
      }
      if (propName === 'class') {
        if (isComponentNode) {
          node.class = node.__wxsClass ? joinClassOrStyle(' ', propValue == undefined ? '' : propValue, node.__wxsClass) : propValue == undefined ? '' : propValue;
          var _hasExternalClass = isComponentNode && node.hasExternalClass('class');
          if (_hasExternalClass) {
            node.setExternalClass('class', propValue);
          }
        } else {
          node.class = propValue;
        }
        return 0;
      }
      if (propName === 'style') {
        if (isComponentNode && node.$$) {
          var transformedPropValue = wx.transformRpx(propValue, true);
          node.setNodeStyle(transformedPropValue, STYLE_SEGMENT_INDEX.ATTR);
          if (transformedPropValue !== propValue) {
            registerResizer(node, STYLE_SEGMENT_INDEX.ATTR, () => {
              var transformedPropValue = wx.transformRpx(propValue, true);
              node.setNodeStyle(transformedPropValue, STYLE_SEGMENT_INDEX.ATTR);
              node.__transformedPropValue = transformedPropValue;
            });
          } else {
            unregisterResizer(node, STYLE_SEGMENT_INDEX.ATTR);
          }
          if (node.__banned) {
            banComponentNode(node);
          }
        } else if (node.$$) {
          node.setNodeStyle(propValue, STYLE_SEGMENT_INDEX.ATTR);
        }
      }
      if (currentRenderBackend() === 'skyline' && propName.startsWith('worklet:')) {
        propName = `worklet:${dashToCamelCase(propName.slice(8))}`;
      }
      var hasProperty = isComponentNode && props_exparser.Component.hasPublicProperty(node, propName);
      if (hasProperty) {
        if (isWxComp || !save_restore_view_states.restoring) {
          nodeDataProxy.scheduleReplace([propName], propValue, specProps != null ? specProps[propName] : null);
          if (isWxComp) {
            nodeDataProxy.doUpdates(undefined, true);
          } else {
            needDoUpdates = true;
            if (!node.isInnerDataExcluded(propName)) delayedPropsCount++;
          }
        }
        var rawValue = rawAttr && rawAttr['model:' + camelToDashCase(propName)];
        if (rawValue) {
          var _matches = rawValue.match(/^\{\{(.*?)\}\}$/);
          if (!_matches) {
            console.warn(`For developer:"${rawValue}" is not an assignable expression. This two-way binding is ignored.`);
          } else {
            var fieldNameMatches = _matches[1].match(/^\s*([_a-zA-Z$][_a-zA-Z0-9$]+)\s*$/);
            if (!fieldNameMatches) {
              console.warn('For developer:Two-way binding does not support complex data paths currently. This two-way binding is ignored.');
            } else {
              var fieldName = fieldNameMatches[1];
              node.__modelValueName = Object.assign(node.__modelValueName || {}, {
                [propName]: fieldName
              });
              pendingModelBindings.push(propName);
            }
          }
        }
        return 0;
      }
      if (propName === 'style') {
        return 0;
      }
      if (propName.startsWith('data-')) {
        var setName = dashToCamelCase(propName.slice(5).toLowerCase());
        node.dataset[setName] = propValue;
        node.setAttribute(propName, propValue);
        if (node.__componentOptions && node.__componentOptions.domain === '//') {
          var methodCaller = props_exparser.Element.getMethodCaller(node);
          var f = methodCaller.onPropertyUpdate;
          if (typeof f === 'function') {
            f.call(methodCaller, 'dataset', setName, propValue);
          }
        }
        return 0;
      }
      if (propName === '$gdc') {
        setWxsGdc(propValue);
        return 0;
      }
      if ((matches = propName.match(/^\$wxs:(capture-)?(mut-)?(bind|catch):?(.+)$/)) && (typeof propValue === 'function' || !propValue)) {
        bindEvent(tm, node, matches[4], propValue, matches[3] === 'catch', matches[1], true, matches[2]);
        if (inDevtoolsWebview() && !isDataThread()) node.setAttribute('exparser:info-attr-' + propName.slice(4), propValue.name);
        return 0;
      }
      if (matches = propName.match(/^(capture-)?(mut-)?(bind|catch):?(.+)$/)) {
        bindEvent(tm, node, matches[4], propValue, matches[3] === 'catch', matches[1], false, matches[2]);
        if (inDevtoolsWebview() && !isDataThread()) node.setAttribute('exparser:info-attr-' + propName, propValue);
        return 0;
      }
      if (propName.slice(0, 2) === 'on') {
        bindEvent(tm, node, propName.slice(2), propValue, false, false, false);
        return 0;
      }
      if (propName === 'animation') {
        if (isComponentNode && node.$$ && propValue !== null && typeof propValue === 'object' && propValue.actions && propValue.actions.length > 0) {
          var index = 0;
          var actions = propValue.actions;
          var length = propValue.actions.length;
          node.addListener('transitionend', () => {
            index += 1;
            step();
          });
          step();
          function step() {
            if (index < length) {
              var {
                transition,
                transitionProperty,
                transform,
                transformOrigin,
                style
              } = wx.animationToStyle(actions[index]);
              var styleObj = node.__styleObj ? Object.assign({}, node.__styleObj, {
                transition,
                transform,
                transitionProperty,
                transformOrigin
              }) : {
                transition,
                transform,
                transitionProperty,
                transformOrigin
              };
              styleObj['-webkit-transition'] = styleObj.transition;
              styleObj['-webkit-transform'] = styleObj.transform;
              styleObj['-webkit-transition-property'] = styleObj.transitionProperty;
              styleObj['-webkit-transform-origin'] = styleObj.transformOrigin;
              for (var key of Object.keys(style || {})) {
                styleObj[key] = style[key];
              }
              node.__styleObj = styleObj;
              if (styleObj.transform !== '') {
                node.__transformNoneEnabled = true;
              }
              var animationStyleStr = Object.keys(styleObj).filter(key => {
                if (key.toLowerCase().includes('transition') && styleObj[key] === '' || key.trim() === '' || styleObj[key] === undefined || !key.toLowerCase().includes('transform') && styleObj[key] === '' || !isNaN(parseInt(key, 10))) {
                  return false;
                }
                if (key.toLowerCase().includes('transform') && styleObj[key] === '' && node.__transformNoneEnabled) {
                  styleObj[key] = 'none';
                }
                return true;
              }).map(key => {
                var newKey = key.replace(/([A-Z]{1})/g, v => `-${v.toLowerCase()}`);
                return `${newKey}:${styleObj[key]}`;
              }).join(';');
              var applyStyle = () => {
                node.setNodeStyle(wx.transformRpx(animationStyleStr, true), STYLE_SEGMENT_INDEX.ANIMATION);
              };
              applyStyle();
              registerResizer(node, STYLE_SEGMENT_INDEX.ANIMATION, applyStyle);
              if (node.__banned) {
                banComponentNode(node);
              }
            }
          }
        }
        return 0;
      }
      if (matches = propName.match(/^\$wxs:change:(.+)$/)) {
        node.wxsObserver = node.wxsObserver || {};
        node.wxsObserver[matches[1]] = node.wxsObserver[matches[1]] || {};
        node.wxsObserver[matches[1]].observer = propValue;
        return 0;
      }
      if (matches = propName.match(/^mark:(.+)$/)) {
        node.setMark(matches[1], propValue);
        return 0;
      }
      var dashPropName = camelToDashCase(propName);
      var hasExternalClass = isComponentNode && node.hasExternalClass(dashPropName);
      if (hasExternalClass) {
        node.setExternalClass(dashPropName, propValue);
        return 0;
      }
      if (currentRenderBackend() !== 'webview' && node instanceof props_exparser.NativeNode) {
        var convertedPropName = currentRenderBackend() === 'skyline' ? dashToCamelCase(propName) : camelToDashCase(propName);
        if (node.__extraAttributeFilters !== undefined && typeof node.__extraAttributeFilters[convertedPropName] === 'function') {
          try {
            node.__extraAttributeFilters[convertedPropName](node, convertedPropName, propValue, newPropValue => {
              node.setAttribute(convertedPropName, newPropValue);
            });
          } catch (e) {
            wxNativeConsole.error(`[Skyline] attribute filter error, on node <${node.is}>, attr [${convertedPropName}], msg: ${e.message}`);
            node.setAttribute(convertedPropName, propValue);
          }
        } else {
          node.setAttribute(convertedPropName, propValue);
        }
      }
    },
    _ret;
  for (var propName of Object.keys(props || {})) {
    _ret = _loop();
    if (_ret === 0) continue;
  }
  if (needDoUpdates) {
    nodeDataProxy.doUpdates(delayedPropsCount, !isDataThread());
  }
  var _loop2 = function () {
    var propName = pendingModelBindings[i];
    if (!node.__wxPropertyListener__ || !node.__wxPropertyListener__[propName]) {
      node.setPropertyChangeListener(propName, value => {
        var shadowRoot = node.ownerShadowRoot;
        var host = shadowRoot.getHostNode();
        if (!isDataThread()) {
          var nodeId = tm.nodeId.getNodeId(host);
          bridge_sendData(constants_SYNC_EVENT_NAME.MODEL_VALUE_CHANGE, {
            data: value,
            modelValueName: node.__modelValueName && node.__modelValueName[propName],
            nodeId
          }, tm.viewId);
        } else {
          host.setData({
            [node.__modelValueName[propName]]: value
          });
        }
      });
      node.__wxPropertyListener__ = node.__wxPropertyListener__ || {};
      node.__wxPropertyListener__[propName] = true;
    }
  };
  for (var i = 0; i < pendingModelBindings.length; i++) {
    _loop2();
  }
  if (!isDataThread() && node.wxsObserver && getWxsGdc()) {
    triggerWxsObserver(node, props);
  }
  if (node.__component__ && !save_restore_view_states.restoring) {
    if (isDataThread()) {
      tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_APPLY_PROPERTY]);
      if (node.__isXrFrame__) {
        tm.operationFlow.end();
      }
    } else {
      var operationIterator = tm.operationFlow.iterator;
      var step = operationIterator.nextStep();
      if (step[0] !== constants_SYNC_EVENT_NAME.FLOW_APPLY_PROPERTY) throw new Error('Framework inner error (expect FLOW_APPLY_PROPERTY but get another)');
    }
  }
};
;// CONCATENATED MODULE: ./src/hot_update.js
var updateListener = Object.create(null);
var enabled = false;
var hot_update_updatedWxAppCode = {};
var hot_update_addUpdateListener = function (path, listener) {
  if (!enabled) return;
  updateListener[path] = listener;
};
var enableUpdateListener = function () {
  enabled = true;
};
var hot_update_isUpdateListenerEnabled = function () {
  return enabled;
};
;// CONCATENATED MODULE: ./src/comp_api/xr_options.ts


var __xrCustomOptions = {};
var __aliases = {};
var getXrCustomOption = comp => __xrCustomOptions[comp] || __xrCustomOptions[__aliases[comp]];
var xr_options_setXrCustomOption = (comp, option) => {
  if (option.isXrComp || option.xrFrameTouchEventBubble) {
    __xrCustomOptions[comp] = option;
  }
};
var aliasXrCustomOption = (alias, compPath) => {
  __aliases[alias] = compPath;
};
var xr_options_publishXrCustomOptions = pageId => {
  if (Object.keys(__xrCustomOptions).length > 0) {
    bridge_sendData(constants_SYNC_EVENT_NAME.XR_FRAME_COMP_OPTIONS, [__xrCustomOptions, __aliases], pageId);
  }
};
if (!isDataThread()) {
  setListenerOnNewPage(constants_SYNC_EVENT_NAME.XR_FRAME_COMP_OPTIONS, data => {
    var options = data[0];
    Object.keys(options).forEach(comp => {
      __xrCustomOptions[comp] = options[comp];
    });
    var aliases = data[1];
    Object.keys(aliases).forEach(alias => {
      __aliases[alias] = aliases[alias];
    });
  });
}
;// CONCATENATED MODULE: ./src/tmpl/virtual_tree.js











var virtual_tree_exparser = getExparser();
var virtual_tree_deepCopy = virtual_tree_exparser.dataUtils.deepCopy;
var DEFAULT_VIRTUAL_TREE = {
  tag: 'shadow',
  children: []
};
var generateVirtualTree = (func, data) => {
  var ts = Date.now();
  var vtObj = func ? func(data, null, __webpack_require__.g) : DEFAULT_VIRTUAL_TREE;
  addGenFuncTime(Date.now() - ts);
  vtObj.tag = 'shadow';
  return vtObj;
};
var dumpVirtualTreeToString = (vtObj, depth = 0) => {
  var str = '';
  for (var i = 0; i < depth; i++) {
    str += '--';
  }
  if (typeof vtObj === 'string') {
    return str + vtObj + '\n';
  }
  str += '<' + vtObj.tag + '>\n';
  if (vtObj.children) {
    vtObj.children.forEach(child => {
      str += dumpVirtualTreeToString(child, depth + 1);
    });
  }
  return str;
};
var virtual_tree_resetComponentNode = (oldNode, tm) => {
  if (!hot_update_isUpdateListenerEnabled()) return;
  if (isDataThread()) {
    tm.operationFlow.start(Date.now());
    tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_HOT_UPDATE_RESET, tm.nodeId.getNodeId(oldNode)]);
  }
  var rootTagName = '';
  if (oldNode === tm.root) rootTagName = 'body';else if (oldNode === tm.tabRoot) rootTagName = 'tab-bar';
  var vtObj = oldNode.__vtObj;
  var newNode = oldNode.ownerShadowRoot ? oldNode.ownerShadowRoot.createComponent(vtObj.tag, undefined, vtObj.generics, tm) : virtual_tree_exparser.createElement(rootTagName, virtual_tree_exparser.Component._list[oldNode.is], tm);
  if (isDataThread()) {
    tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_HOT_UPDATE_RESET]);
  } else {
    var operationIterator = tm.operationFlow.iterator;
    var step = operationIterator.nextStep();
    if (step[0] !== constants_SYNC_EVENT_NAME.FLOW_HOT_UPDATE_RESET) {
      throw new Error('Expect FLOW_HOT_UPDATE_RESET but get another');
    }
  }
  var nodeId = tm.nodeId.getNodeId(oldNode);
  tm.nodeId.removeNode(oldNode);
  tm.nodeId.allocNodeId(newNode, nodeId);
  if (oldNode === tm.root) {
    virtual_tree_exparser.Element.pretendDetached(oldNode);
    tm.root = newNode;
    if (isDataThread()) {
      var caller = virtual_tree_exparser.Element.getMethodCaller(newNode);
      caller.__wxExparserNodeId__ = nodeId;
    } else {
      window.__DOMTree__ = newNode;
      document.body = newNode.$$;
    }
    virtual_tree_exparser.Element.pretendAttached(newNode);
    if (isDataThread()) {
      var initProp = {};
      var needSetPropData = false;
      Object.keys(tm.initialRootData).forEach(k => {
        if (virtual_tree_exparser.Component.hasProperty(newNode, k)) {
          initProp[k] = tm.initialRootData[k];
          needSetPropData = true;
        }
      });
      if (needSetPropData) tm.root.setData(initProp);
    }
  } else if (oldNode === tm.tabRoot) {
    tm.tabRoot = newNode;
    if (isDataThread()) {
      var _caller = virtual_tree_exparser.Element.getMethodCaller(newNode);
      _caller.__wxExparserNodeId__ = nodeId;
    } else {
      window.__TAB_BAR__ = newNode;
      oldNode.parentNode.replaceChild(newNode, oldNode);
    }
  } else {
    newNode.__vtObj = vtObj;
    var props = vtObj.attr;
    applyProperties(newNode, props, vtObj.raw, vtObj.rawAttr);
    while (oldNode.childNodes.length) {
      newNode.appendChild(oldNode.childNodes[0]);
    }
    oldNode.parentNode.replaceChild(newNode, oldNode);
  }
  if (isDataThread()) {
    tm.operationFlow.end();
  }
};
var createComponent = (compName, vtObj, shadowRoot, tm) => {
  var xrCustomOptions = getXrCustomOption(compName) || {};
  var domNode = null;
  var shouldCreateAsXrFrame = xrCustomOptions.isXrComp && bridge_getPageType(tm.viewId) !== 'xr-frame';
  if (!shouldCreateAsXrFrame || currentRenderBackend() === 'xr-frame') {
    domNode = shadowRoot.createComponent(vtObj.tag, undefined, vtObj.generics, tm);
  } else {
    wxNativeConsole.info(`[VirtualTreeCreate] <${vtObj.tag}>[${compName}] will be created as xr-frame`);
    if (isDataThread()) {
      domNode = __appServiceSDK__.xrFrame.createXrFrame(compName, shadowRoot, vtObj.generics, tm.viewId);
    } else {
      domNode = shadowRoot.createComponent('wx-xr-frame', undefined, vtObj.generics, tm);
      domNode.xrFrameTouchEventBubble = xrCustomOptions.xrFrameTouchEventBubble;
    }
    domNode.__isXrFrame__ = true;
  }
  if (isDataThread()) {
    report_reportPluginNodeCreation(domNode, tm);
  }
  return domNode;
};
var virtualTreeToExparserNode = (vtObj, shadowRootHost, shadowRoot, tm, deepCopyProps) => {
  var domNode = null;
  if (!isDataThread() && !tm) tm = tree_manager.getByNode(shadowRootHost);
  if (vtObj.tag === 'shadow' && shadowRootHost) {
    shadowRoot = domNode = virtual_tree_exparser.ShadowRoot.create(shadowRootHost);
  } else if (vtObj.tag === 'virtual' || vtObj.tag === 'shadow') {
    var virtualTagName = 'virtual';
    if (vtObj.wxXCkey === 1 || vtObj.wxXCkey === 3) virtualTagName = 'wx:if';else if (vtObj.wxXCkey === 2 || vtObj.wxXCkey === 4) virtualTagName = 'wx:for';
    domNode = shadowRoot.createVirtualNode(virtualTagName);
    virtual_tree_exparser.Element.setInheritSlots(domNode);
    if (isDataThread()) domNode.__treeManager__ = tm;else domNode.__wxVkey__ = vtObj.wxVkey;
  } else if (vtObj.tag === 'wx-slot') {
    domNode = shadowRoot.createVirtualNode('slot');
    virtual_tree_exparser.Element.setSlotName(domNode, '');
  } else {
    var isCustomComp = shadowRoot.tagNameUsed(vtObj.tag);
    if (!isCustomComp) {
      if (isDataThread()) {
        domNode = shadowRoot.createVirtualNode(vtObj.tag);
        domNode.__treeManager__ = tm;
      } else {
        domNode = shadowRoot.createComponent(vtObj.tag, undefined, vtObj.generics, tm);
      }
    } else {
      var host = shadowRoot.getHostNode();
      var compName = shadowRoot.getCompDefByTagName(vtObj.tag);
      if (typeof compName.is === 'string') compName = compName.is;
      var lazyPlaceholder = host.getPlaceholder(vtObj.tag);
      var usePlaceholder = tm.compManager.shouldUsePlaceholder(compName) && !!lazyPlaceholder;
      if (!usePlaceholder) {
        domNode = createComponent(compName, vtObj, shadowRoot, tm);
      } else {
        domNode = shadowRoot.createComponent(vtObj.tag, lazyPlaceholder, vtObj.generics, tm);
        domNode.__placeholder__ = true;
        tm.compManager.arrangePlaceholderReplace(compName, () => {
          var currentVtObj = domNode.__vtObj;
          var newNode = createComponent(compName, currentVtObj, shadowRoot, tm);
          afterCreate(currentVtObj, newNode, tm, deepCopyProps);
          var children = [...domNode.childNodes];
          if (domNode.parentNode) domNode.parentNode.insertBefore(newNode, domNode);
          children.forEach(child => {
            newNode.appendChild(child);
          });
          if (domNode.parentNode) domNode.parentNode.removeChild(domNode);
        });
      }
    }
  }
  afterCreate(vtObj, domNode, tm, deepCopyProps);
  var children = vtObj.children;
  if (children) {
    for (var i = 0; i < children.length; i++) {
      var child = children[i];
      if (child == null) continue;
      if (typeof child === 'object') {
        var childNode = virtualTreeToExparserNode(child, null, shadowRoot, tm, deepCopyProps);
        domNode.appendChild(childNode);
      } else {
        var _childNode = shadowRoot.createTextNode(child);
        domNode.appendChild(_childNode);
      }
    }
  }
  return domNode;
};
var afterCreate = (vtObj, domNode, tm, deepCopyProps) => {
  if (hot_update_isUpdateListenerEnabled() || domNode.__placeholder__ === true) domNode.__vtObj = vtObj;
  if (vtObj.wxXCkey === 3 || vtObj.wxXCkey === 4) {
    if (isDataThread() || window.__customComponentMode__) {
      domNode.__wxDynamicSync__ = vtObj.wxXCkey === 4 ? 'wx:for' : 'wx:if';
    }
  }
  if (!isDataThread()) {
    if (vtObj.extraAttr) {
      for (var k of Object.keys(vtObj.extraAttr)) {
        domNode.setAttribute(k, vtObj.extraAttr[k]);
      }
    }
    if (vtObj.wxScopeData !== undefined) {
      domNode.__wxScopeData__ = vtObj.wxScopeData;
    }
  }
  var isCustomComp = domNode.__component__;
  var isPlaceholder = domNode.__placeholder__;
  var isXrFrame = domNode.__isXrFrame__;
  if (isCustomComp || isPlaceholder || isXrFrame) {
    if (isDataThread()) {
      var nodeId = tm.nodeId.allocNodeId(domNode, tm.nodeId.getNodeId(domNode));
      virtual_tree_exparser.Element.getMethodCaller(domNode).__wxExparserNodeId__ = nodeId;
      tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_CREATE_NODE, nodeId]);
    } else {
      if (save_restore_view_states.restoring) {
        var statesData = save_restore_view_states.idDataMap[tm.nodeId.getNodeId(domNode)];
        virtual_tree_exparser.Component.replaceWholeData(domNode, statesData, null);
      } else {
        var operationIterator = tm.operationFlow.iterator;
        var step = operationIterator.nextStep();
        if (step[0] !== constants_SYNC_EVENT_NAME.FLOW_CREATE_NODE) throw new Error('Framework inner error (expect FLOW_CREATE_NODE but get another)');
        tm.nodeId.allocNodeId(domNode, step[1]);
      }
      if (inDevtoolsWebview() && !isPlaceholder) domNode.setAttribute('exparser:info-custom-component', domNode.__componentInstanceId);
      checkAndBanComponent(domNode);
      domNode.setAttribute('is', domNode.is);
    }
  }
  var props = deepCopyProps ? virtual_tree_deepCopy(vtObj.attr) : vtObj.attr;
  applyProperties(domNode, props, vtObj.raw, vtObj.rawAttr);
  if (domNode.__isXrFrame__ && !isDataThread()) {
    var canvasInfo = getNodeInfo(domNode.$.canvas, {
      node: true
    });
    var _nodeId = tm.nodeId.getNodeId(domNode);
    bridge_sendData(constants_SYNC_EVENT_NAME.XR_FRAME_CANVAS_CREATED, [canvasInfo, _nodeId], tm.viewId);
  }
};
;// CONCATENATED MODULE: ./src/tmpl/utils.js


var syncChildManipulation = tm => {
  if (isDataThread()) {
    tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_MINIPULATE_CHILD]);
  } else {
    var operationIterator = tm.operationFlow.iterator;
    var step = operationIterator.nextStep();
    if (step[0] !== constants_SYNC_EVENT_NAME.FLOW_MINIPULATE_CHILD) {
      throw new Error('Expect FLOW_MINIPULATE_CHILD but get another');
    }
  }
};
;// CONCATENATED MODULE: ./src/tmpl/list_diff.js




var list_diff_hasOwnProperty = Object.prototype.hasOwnProperty;
var mathIsNaN = num => {
  if (typeof num !== 'number') return false;
  return isNaN(num);
};
var collectKeys = list => {
  var keyIndexes = {};
  for (var index = 0; index < list.length; ++index) {
    var item = list[index];
    var itemKey = item && item.wxKey;
    if (!itemKey) {
      if (mathIsNaN(itemKey)) {
        item.wxKey = undefined;
      }
    } else if (list_diff_hasOwnProperty.call(keyIndexes, itemKey)) {
      item.wxKey = undefined;
    } else {
      keyIndexes[itemKey] = index;
    }
  }
  return keyIndexes;
};
var collectKeysAndFreeIndexes = list => {
  var keyIndexes = {};
  var freeIndexes = [];
  for (var index = 0; index < list.length; ++index) {
    var item = list[index];
    var itemKey = item && item.wxKey;
    if (!itemKey) {
      if (mathIsNaN(itemKey)) {
        item.wxKey = undefined;
      }
      freeIndexes.push(index);
    } else if (list_diff_hasOwnProperty.call(keyIndexes, itemKey)) {
      console.warn(`For developer:Do not set same key "${itemKey}" in wx:key.`);
      item.wxKey = undefined;
      freeIndexes.push(index);
    } else {
      keyIndexes[itemKey] = index;
    }
  }
  return [keyIndexes, freeIndexes];
};
var listDiff = (oldList, newList) => {
  var oldKeyIndexes = collectKeys(oldList);
  var [newKeyIndexes, newFreeIndexes] = collectKeysAndFreeIndexes(newList);
  var children = [];
  var removes = [];
  var inserts = [];
  var freeIndex = 0;
  var deletedItemCount = 0;
  for (var i = 0; i < oldList.length; ++i) {
    var item = oldList[i];
    var itemKey = item.wxKey;
    if (itemKey) {
      if (list_diff_hasOwnProperty.call(newKeyIndexes, itemKey)) {
        var itemIndex = newKeyIndexes[itemKey];
        children.push(newList[itemIndex]);
      } else {
        removes.push(i - deletedItemCount);
        ++deletedItemCount;
        children.push(null);
      }
    } else {
      if (freeIndex < newFreeIndexes.length) {
        var _itemIndex = newFreeIndexes[freeIndex];
        children.push(newList[_itemIndex]);
        ++freeIndex;
      } else {
        removes.push(i - deletedItemCount);
        ++deletedItemCount;
        children.push(null);
      }
    }
  }
  var currentList = children;
  var currentIndex = 0;
  var stables = [];
  for (var newIndex = 0; newIndex < newList.length;) {
    var newItem = newList[newIndex];
    var newItemKey = newItem && newItem.wxKey;
    var currentItem = currentList[currentIndex];
    var currentItemKey = currentItem && currentItem.wxKey;
    while (currentItem === null) {
      ++currentIndex;
      currentItem = currentList[currentIndex];
      currentItemKey = currentItem && currentItem.wxKey;
    }
    if (currentIndex >= currentList.length) {
      inserts.push({
        oldIndex: oldKeyIndexes[newItemKey],
        index: newIndex,
        pos: -1
      });
      ++currentIndex;
      ++newIndex;
    } else if (currentItemKey === newItemKey) {
      stables.push(currentIndex);
      ++currentIndex;
      ++newIndex;
    } else if (newItemKey) {
      if (currentItemKey) {
        if (newKeyIndexes[currentItemKey] === newIndex + 1) {
          inserts.push({
            oldIndex: oldKeyIndexes[newItemKey],
            index: newIndex,
            pos: currentIndex
          });
        } else {
          ++currentIndex;
          currentItem = currentList[currentIndex];
          if (currentItem && currentItem.wxKey === newItemKey) {
            stables.push(currentIndex);
            ++currentIndex;
          } else {
            --currentIndex;
            inserts.push({
              oldIndex: oldKeyIndexes[newItemKey],
              index: newIndex,
              pos: currentIndex
            });
          }
        }
      } else {
        inserts.push({
          oldIndex: oldKeyIndexes[newItemKey],
          index: newIndex,
          pos: currentIndex
        });
      }
      ++newIndex;
    } else {
      ++currentIndex;
    }
  }
  var stableIndex = 0;
  for (var _i = 0; _i < inserts.length; _i++) {
    var _currentIndex = inserts[_i].pos;
    if (_currentIndex === -1) break;
    while (stableIndex < stables.length && _currentIndex > stables[stableIndex]) {
      stableIndex++;
    }
    if (stableIndex >= stables.length) {
      inserts[_i].pos = -1;
    } else {
      inserts[_i].pos = stables[stableIndex];
    }
  }
  return {
    children,
    removes,
    inserts
  };
};
var applyListDiff = (removes, inserts, exparserNode, newChildren) => {
  var tm = tree_manager.getByNode(exparserNode);
  var exparserChildren = exparserNode.childNodes;
  var insertNodes = [];
  for (var i = 0; i < inserts.length; i++) {
    var insert = inserts[i];
    insertNodes.push({
      node: insert.oldIndex !== undefined ? exparserChildren[insert.oldIndex] : null,
      before: insert.pos >= 0 ? exparserChildren[insert.pos] : undefined,
      index: insert.index
    });
  }
  for (var _i2 = 0; _i2 < removes.length; _i2++) {
    var index = removes[_i2];
    var node = exparserChildren[index];
    exparserNode.removeChild(node);
    if (exparserChildren.__wxDynamicSync__ === 'wx:for') {
      syncChildManipulation(tm);
      tm.nodeId.removeNode(node);
    }
  }
  for (var _i3 = 0; _i3 < insertNodes.length; _i3++) {
    var {
      before,
      index: _index
    } = insertNodes[_i3];
    var _node = insertNodes[_i3].node;
    if (_node === null) {
      _node = virtualTreeToExparserNode(newChildren[_index], null, exparserNode.ownerShadowRoot, tm, false);
    }
    if (exparserNode.__wxDynamicSync__ === 'wx:for') {
      tm.nodeId.addNode(_node);
      exparserNode.insertBefore(_node, before);
      syncChildManipulation(tm);
    } else {
      exparserNode.insertBefore(_node, before);
    }
  }
  if (exparserNode.__banned) {
    banNode(exparserNode);
  }
};
;// CONCATENATED MODULE: ./src/tmpl/diff.js







var diff = (oldNode, newNode, exparserNode) => {
  if (oldNode === newNode) {
    return;
  }
  if (oldNode && !exparserNode) {
    return;
  }
  if (newNode == null) {
    exparserNode.parentNode.removeChild(exparserNode);
  } else if (typeof newNode === 'object') {
    if (typeof oldNode === 'object' && oldNode !== null && oldNode.tag === newNode.tag && String(oldNode.wxKey) === String(newNode.wxKey) && !(oldNode.tag === 'virtual' && oldNode.wxVkey !== newNode.wxVkey)) {
      if (newNode.n && newNode.n.length) {
        var newPropNames = newNode.n;
        var props = newNode.attr;
        var newProps = {};
        for (var i = 0; i < newPropNames.length; i++) {
          var name = newPropNames[i];
          newProps[name] = props[name];
        }
        applyProperties(exparserNode, newProps, newNode.raw, newNode.rawAttr);
      }
      if (newNode.wxScopeData !== undefined) {
        exparserNode.__wxScopeData__ = newNode.wxScopeData;
      }
      if (exparserNode.__vtObj !== undefined) {
        exparserNode.__vtObj = newNode;
      }
      diffChildren(oldNode, newNode, exparserNode);
    } else {
      var tm = tree_manager.getByNode(exparserNode);
      var parentNode = exparserNode.parentNode;
      var newExparserNode = virtualTreeToExparserNode(newNode, null, parentNode.ownerShadowRoot, tm, false);
      if (parentNode) {
        if (parentNode.__wxDynamicSync__ === 'wx:for' || exparserNode.__wxDynamicSync__ === 'wx:if') {
          tm.nodeId.addNode(newExparserNode);
          parentNode.replaceChild(newExparserNode, exparserNode);
          syncChildManipulation(tm);
          tm.nodeId.removeNode(exparserNode);
        } else {
          parentNode.replaceChild(newExparserNode, exparserNode);
        }
        if (exparserNode.__banned) {
          banNode(newExparserNode);
        }
      }
    }
  } else {
    if (typeof oldNode === 'string') {
      if (newNode !== oldNode) {
        exparserNode.textContent = newNode;
      }
    } else {
      var _newExparserNode = exparserNode.ownerShadowRoot.createTextNode(newNode);
      exparserNode.parentNode.replaceChild(_newExparserNode, exparserNode);
    }
  }
};
var diffChildren = (oldTree, newTree, exparserNode) => {
  var wxmlCustomCompMode = !!getWxmlVersionTag('customComponents');
  var oldChildren = oldTree.children;
  var newChildren = newTree.children;
  var needOrderDiff = oldTree.tag === 'virtual' && (oldTree.wxXCkey === 2 || oldTree.wxXCkey === 4 || oldTree.wxXCkey === undefined) || !wxmlCustomCompMode && oldChildren.length !== newChildren.length;
  var removes = null;
  var inserts = null;
  if (needOrderDiff) {
    var diffs = listDiff(oldChildren, newTree.children);
    newChildren = diffs.children;
    removes = diffs.removes;
    inserts = diffs.inserts;
  }
  var exparserChildren = exparserNode.childNodes;
  for (var i = 0; i < oldChildren.length; i++) {
    var oldChild = oldChildren[i];
    var newChild = newChildren[i];
    if (newChild || !needOrderDiff) {
      diff(oldChild, newChild, exparserChildren[i]);
    }
  }
  if (needOrderDiff) {
    applyListDiff(removes, inserts, exparserNode, newTree.children);
  }
};
;// CONCATENATED MODULE: ./src/comp_api/update_perf_stat.js



var update_perf_stat_exparser = getExparser();
var globalPerformanceListener = null;
var performanceListeners = {};
var flowIdInc = 1;
var flowIdStack = [];
var updateProcess = cb => {
  var flowId = flowIdInc++;
  flowIdStack.push(flowId);
  try {
    cb(flowId);
  } catch (e) {
    flowIdStack.pop();
    throw e;
  }
  flowIdStack.pop();
};
var generateUpdatePerformanceStat = (nodeId, dataCb) => {
  if (performanceListeners[nodeId] || globalPerformanceListener !== null) {
    var config = performanceListeners[nodeId] || globalPerformanceListener;
    var flowId = flowIdStack[flowIdStack.length - 1];
    var parentFlowId = flowIdStack[flowIdStack.length - 2];
    var {
      isMergedUpdate,
      dataPaths,
      pendingStartTimestamp,
      updateStartTimestamp,
      updateEndTimestamp,
      pageId
    } = dataCb(config);
    bridge_sendData(constants_SYNC_EVENT_NAME.UPDATE_PERFORMANCE_STAT, [nodeId, {
      isMergedUpdate,
      dataPaths,
      updateProcessId: flowId,
      parentUpdateProcessId: parentFlowId,
      pendingStartTimestamp,
      updateStartTimestamp,
      updateEndTimestamp
    }], pageId);
  }
};
var __globalUpdatePerformanceListener__ = null;
var __globalUpdatePerformanceListenerConfig__ = null;
var setGlobalUpdatePerformanceListener = (config, cb) => {
  __globalUpdatePerformanceListener__ = cb;
  __globalUpdatePerformanceListenerConfig__ = config;
};
var update_perf_stat_enabledGlobalUpdatePerformanceListener = tm => {
  if (typeof __globalUpdatePerformanceListener__ !== 'function') return;
  tm.operationFlow.push([SYNC_EVENT_NAME.ENABLE_GLOBAL_UPDATE_PERFORMANCE_STAT, __globalUpdatePerformanceListenerConfig__]);
};
if (!isDataThread()) {
  setDataListener(constants_SYNC_EVENT_NAME.ENABLE_UPDATE_PERFORMANCE_STAT, data => {
    var [nodeId, config] = data;
    performanceListeners[nodeId] = config;
  });
  setDataListener(constants_SYNC_EVENT_NAME.DISABLE_UPDATE_PERFORMANCE_STAT, data => {
    var [nodeId] = data;
    delete performanceListeners[nodeId];
  });
  setDataListener(constants_SYNC_EVENT_NAME.ENABLE_GLOBAL_UPDATE_PERFORMANCE_STAT, data => {
    var [config] = data;
    globalPerformanceListener = config;
  });
}
var registerUpdatePerformanceListeners = (viewId, tm) => {
  setDataListener(constants_SYNC_EVENT_NAME.UPDATE_PERFORMANCE_STAT, data => {
    var [nodeId, res] = data;
    var node = tm.nodeId.getNodeById(nodeId);
    if (node && node.__updatePerformanceListener__) {
      var caller = update_perf_stat_exparser.Element.getMethodCaller(node);
      update_perf_stat_exparser.safeCallback('Update Performance Listener', node.__updatePerformanceListener__, caller, [res], node);
    }
    if (node && typeof __globalUpdatePerformanceListener__ === 'function') {
      __globalUpdatePerformanceListener__(res, node, viewId);
    }
  }, viewId);
};
;// CONCATENATED MODULE: ./src/tmpl/index.js












var tmpl_exparser = getExparser();
var tmpl_deepCopy = tmpl_exparser.dataUtils.deepCopy;
var handleDelayedGwx = info => {
  if (typeof info !== 'object' || !info) {
    if (!isDataThread() && typeof window !== 'undefined') {
      window.__usingDelayedGwx__ = (window.__usingDelayedGwx__ || 0) | 1;
    }
    return info;
  }
  if (!isDataThread() && typeof window !== 'undefined') {
    window.__usingDelayedGwx__ = (window.__usingDelayedGwx__ || 0) | 2;
  }
  var arr = info.slice();
  var func = arr.shift();
  return func(...arr);
};
var createTmpl = function (behavior, data, initValues, componentOptions) {
  var tmpl = new tmpl_Tmpl();
  tmpl._initValues = initValues;
  tmpl._data = data;
  var behaviorTemplate = behavior.template;
  tmpl._generateFunc = handleDelayedGwx(behaviorTemplate.func);
  tmpl._virtualTree = generateVirtualTree(tmpl._generateFunc, tmpl._initValues);
  tmpl._isSimpleComponent = componentOptions.domain.slice(0, 9) === 'simple://';
  hot_update_addUpdateListener(behaviorTemplate.path, func => {
    behaviorTemplate.func = func;
    tmpl.updateGenerateFunc(func);
  });
  return tmpl;
};
var collectIdMapAndSlots = function (node, idMap, slots) {
  var children = node.childNodes;
  for (var i = 0; i < children.length; i++) {
    var child = children[i];
    if (child instanceof tmpl_exparser.TextNode) continue;
    if (child.__id) idMap[child.__id] = child;
    if (child.__slotName !== undefined) slots[child.__slotName] = child;
    collectIdMapAndSlots(child, idMap, slots);
  }
};
class tmpl_Tmpl {
  createInstance(elem, customArgs) {
    var inst = new TmplInstance();
    var tm = customArgs;
    if (!isDataThread()) {
      tm = tree_manager.getByNode(elem);
    }
    inst._template = this;
    inst._generateFunc = this._generateFunc;
    inst.data = tmpl_deepCopy(this._data);
    inst.idMap = Object.create(null);
    inst.slots = Object.create(null);
    if (save_restore_view_states.restoring) {
      if (save_restore_view_states.compIdArrIndex >= save_restore_view_states.compIdArr.length) throw new Error('Component count unmatched while page recovering');
      tm.nodeId.allocNodeId(elem, save_restore_view_states.compIdArr[save_restore_view_states.compIdArrIndex++]);
      var statesData = save_restore_view_states.idDataMap[tm.nodeId.getNodeId(elem)];
      inst._virtualTree = generateVirtualTree(this._generateFunc, statesData);
    } else {
      inst._virtualTree = this._virtualTree;
    }
    inst.shadowRoot = virtualTreeToExparserNode(inst._virtualTree, elem, null, customArgs, true);
    collectIdMapAndSlots(inst.shadowRoot, inst.idMap, inst.slots);
    inst.listeners = [];
    if (!this._isSimpleComponent) elem.__component__ = true;
    if (isDataThread()) {
      elem.__treeManager__ = tm;
      inst.shadowRoot.__treeManager__ = tm;
      tm.operationFlow.registerSetDataCallback(() => {
        elem.triggerLifeTime('ready');
      });
    }
    inst._delayedUpdateValues = null;
    return inst;
  }
  updateGenerateFunc(func) {
    this._generateFunc = handleDelayedGwx(func);
    this._virtualTree = generateVirtualTree(this._generateFunc, this._initValues);
    tree_manager.list().forEach(tm => {
      ;
      [tm.root, tm.tabRoot].forEach(root => {
        if (!root) return;
        utils_dfsComponents(root, 1, elem => {
          if (elem instanceof tmpl_exparser.Component && elem.__templateInstance._template === this) {
            elem.__templateInstance._generateFunc = func;
            if (isDataThread()) {
              elem.__templateInstance._resetShadowChildren(elem, elem.data, tm);
            }
          }
        });
      });
    });
  }
}
tmpl_Tmpl.create = createTmpl;
class TmplInstance {
  beforeMergeValues(changes, innerExcluded, inferredDataCount) {
    if (isDataThread()) {
      var isSetDataUpdate = typeof inferredDataCount !== 'number';
      if (isSetDataUpdate) {
        changes.forEach((item, i) => {
          if (item[1] !== undefined) {
            innerExcluded[i] = false;
          } else {
            innerExcluded[i] = true;
            console.warn('Setting data field "' + item[0].join('.') + '" to undefined is invalid.');
          }
        });
      } else {
        for (var i = 0; i < inferredDataCount; i++) innerExcluded[i] = false;
        for (var _i = inferredDataCount; _i < changes.length; _i++) {
          var item = changes[_i];
          if (item[1] !== undefined) {
            innerExcluded[_i] = false;
          } else {
            innerExcluded[_i] = true;
            console.warn('Setting data field "' + item[0].join('.') + '" to undefined is invalid.');
          }
        }
      }
    }
  }
  beforeUpdateValues(node, data, inferredDataCount) {
    if (!isDataThread()) {
      var isSetDataUpdate = typeof inferredDataCount !== 'number';
      if (!isSetDataUpdate) {
        var tm = tree_manager.getByNode(node);
        var operationIterator = tm.operationFlow.iterator;
        var step = operationIterator.nextStepIf(constants_SYNC_EVENT_NAME.FLOW_DATA_OBSERVER);
        if (step) {
          var changes = step[1];
          if (node && changes.length) {
            generateUpdatePerformanceStat(tm.nodeId.getNodeId(node), config => {
              var dataPaths = config.withDataPaths ? changes.map(x => x[0]) : undefined;
              return {
                isMergedUpdate: true,
                dataPaths,
                pageId: tm.viewId
              };
            });
            var nodeDataProxy = tmpl_exparser.Component.getDataProxy(node);
            nodeDataProxy.setChanges(changes);
            nodeDataProxy.doUpdates(undefined, !isDataThread());
          }
        }
      }
    }
  }
  updateValues(node, data, changedPaths, changedValues, changes, inferredDataCount) {
    if (save_restore_view_states.restoring) return;
    var tm = null;
    var isSetDataUpdate = typeof inferredDataCount !== 'number';
    if (isDataThread()) {
      tm = node.__treeManager__;
      if (isSetDataUpdate) {
        tm.operationFlow.start(Date.now());
        var filteredChanges = [];
        changes.forEach(item => {
          if (item[1] !== undefined) filteredChanges.push(item);
        });
        tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_UPDATE, tm.nodeId.getNodeId(node), tmpl_deepCopy(filteredChanges)]);
      } else {
        var _filteredChanges = [];
        for (var i = inferredDataCount; i < changes.length; i++) {
          var item = changes[i];
          if (item[1] !== undefined) _filteredChanges.push(item);
        }
        tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_DATA_OBSERVER, tmpl_deepCopy(_filteredChanges)]);
      }
    }
    if (this._delayedUpdateValues) {
      this._delayedUpdateValues.push([tmpl_deepCopy(data), changedPaths, changedValues, changes, inferredDataCount]);
    } else {
      this._delayedUpdateValues = [];
      try {
        this._updateValues(node, data, changedPaths, changedValues, changes, inferredDataCount);
        var delayed = this._delayedUpdateValues;
        this._delayedUpdateValues = null;
        for (var _i2 = 0; _i2 < delayed.length; _i2++) {
          var args = delayed[_i2];
          this._updateValues(node, args[0], args[1], args[2], args[3], args[4]);
        }
      } catch (e) {
        this._delayedUpdateValues = null;
        throw e;
      }
    }
    if (isSetDataUpdate && isDataThread()) {
      tm.operationFlow.end();
    }
  }
  _updateValues(node, data, changedPaths, changedValues, changes, inferredDataCount) {
    var isSetDataUpdate = typeof inferredDataCount !== 'number';
    var needClonedData = !getWxmlVersionTag('propValueDeepCopy');
    var mergedData = mergeDataWithSpec(data, changes, true, false, needClonedData);
    var newVirtualTree = generateVirtualTree(this._generateFunc, mergedData);
    mergeDataWithSpec(data, changes, false, isSetDataUpdate, false);
    var oldVirtualTree = this._virtualTree;
    this._virtualTree = newVirtualTree;
    diff(oldVirtualTree, newVirtualTree, this.shadowRoot);
  }
  _resetShadowChildren(node, data, tm) {
    var step = () => {
      if (isDataThread()) {
        tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_HOT_UPDATE_CHILD]);
      } else {
        var operationIterator = tm.operationFlow.iterator;
        var _step = operationIterator.nextStep();
        if (_step[0] !== constants_SYNC_EVENT_NAME.FLOW_HOT_UPDATE_CHILD) {
          throw new Error('Expect FLOW_HOT_UPDATE_CHILD but get another');
        }
      }
    };
    if (isDataThread()) {
      tm.operationFlow.start(Date.now());
      tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_HOT_UPDATE, tm.nodeId.getNodeId(node)]);
    }
    var shadowRoot = this.shadowRoot;
    var oldChildrenCount = (this._virtualTree.children || []).length;
    for (var i = 0; i < oldChildrenCount; i++) {
      shadowRoot.removeChild(shadowRoot.childNodes[0]);
    }
    step();
    var newVirtualTree = generateVirtualTree(this._generateFunc, data);
    step();
    this._virtualTree = newVirtualTree;
    var newRoot = virtualTreeToExparserNode(newVirtualTree, null, node.shadowRoot, tm, true);
    var newChildren = newRoot.childNodes;
    var newChildrenCount = newChildren.length;
    for (var _i3 = 0; _i3 < newChildrenCount; _i3++) {
      shadowRoot.insertBefore(newChildren[0], shadowRoot.childNodes[_i3]);
    }
    if (isDataThread()) {
      tm.operationFlow.end();
    }
  }
}
;// CONCATENATED MODULE: ./src/route_utils.js




var route_utils_exparser = getExparser();
var pluginSubPackagePrefix = null;
var initPluginSubPackagePrefix = () => {
  pluginSubPackagePrefix = {};
  var plugins = null;
  if (__wxConfig && __wxConfig.plugins) {
    plugins = __wxConfig.plugins;
  } else if (typeof window !== 'undefined' && window && window.__wxConfigAppService__ && window.__wxConfigAppService__.plugins) {
    plugins = window.__wxConfigAppService__.plugins;
  }
  var found = false;
  if (plugins) {
    for (var alias of Object.keys(plugins)) {
      var appid = plugins[alias].provider;
      var subpackage = plugins[alias].subpackage;
      if (typeof subpackage !== 'undefined') {
        found = true;
        var prefix = subpackage || '';
        if (prefix === '__APP__') {
          prefix = '';
        }
        if (prefix[0] === '/') {
          prefix = prefix.slice(1);
        }
        if (prefix && prefix.slice(-1) !== '/') {
          prefix += '/';
        }
        pluginSubPackagePrefix[appid] = prefix;
      }
    }
  }
  if (found) {
    return;
  }
  var subPackages;
  if (!!__wxConfig && !!__wxConfig.subPackages) {
    subPackages = __wxConfig.subPackages;
  } else if (typeof window !== 'undefined' && !!window && !!window.__subPackages) {
    subPackages = window.__subPackages;
  } else {
    return;
  }
  if (subPackages.length) {
    subPackages.forEach(item => {
      if (!item) {
        return;
      }
      var prefix = item.root || '';
      if (prefix && prefix.slice(-1) !== '/') {
        prefix += '/';
      }
      if (item.plugins) {
        for (var k of Object.keys(item.plugins)) {
          var _appid = item.plugins[k] && item.plugins[k].provider;
          if (_appid) {
            pluginSubPackagePrefix[_appid] = prefix;
          }
        }
      }
    });
  }
};
var route_utils_convertRouteToComponentAlias = route => {
  var matches = route.match(/(?:^|\/)__(wx|plugin)__\/(.*)$/);
  if (!matches) {
    return route;
  }
  if (matches[1] === 'wx') {
    return 'wx://' + matches[2];
  }
  return 'plugin-private://' + matches[2];
};
var convertComponentAliasToRoute = alias => {
  if (!pluginSubPackagePrefix) {
    initPluginSubPackagePrefix();
  }
  var normalizedAlias = route_utils_exparser.Component._list[alias] ? route_utils_exparser.Component._list[alias].is || alias : alias;
  var ret = normalizedAlias.replace(/^plugin-private:\/\/([0-9a-zA-Z]+)\//, (match, appid) => (pluginSubPackagePrefix[appid] || '') + '__plugin__/' + appid + '/').replace(/^wx:\/\//, '__wx__/');
  return ret;
};
var getAllPluginSubPackagePrefix = () => {
  if (!pluginSubPackagePrefix) {
    initPluginSubPackagePrefix();
  }
  return pluginSubPackagePrefix;
};
var getPluginSubPackagePrefix = appid => {
  if (!pluginSubPackagePrefix) {
    initPluginSubPackagePrefix();
  }
  return pluginSubPackagePrefix[appid] || '';
};
var getPluginRoutePrefix = appid => {
  if (!pluginSubPackagePrefix) {
    initPluginSubPackagePrefix();
  }
  return (pluginSubPackagePrefix[appid] || '') + '__plugin__/' + appid + '/';
};
var matchSubPackage = route => {
  if (!pluginSubPackagePrefix) initPluginSubPackagePrefix();
  var m = route.match(/^plugin:\/\/(.+?)\//);
  if (m) return matchSubPackage(pluginSubPackagePrefix[m[1]] || '');
  m = route.match(/^plugin-private:\/\/([0-9a-zA-Z]+)\//);
  if (m) return matchSubPackage(pluginSubPackagePrefix[m[1]] || '');
  var subPackages;
  if (isDataThread()) {
    var _wxConfig$subPackage, _wxConfig;
    subPackages = (_wxConfig$subPackage = (_wxConfig = __wxConfig) === null || _wxConfig === void 0 ? void 0 : _wxConfig.subPackages) !== null && _wxConfig$subPackage !== void 0 ? _wxConfig$subPackage : [];
  } else {
    var _ref, _wxConfig$subPackage2, _wxConfig2, _window;
    subPackages = (_ref = (_wxConfig$subPackage2 = (_wxConfig2 = __wxConfig) === null || _wxConfig2 === void 0 ? void 0 : _wxConfig2.subPackages) !== null && _wxConfig$subPackage2 !== void 0 ? _wxConfig$subPackage2 : (_window = window) === null || _window === void 0 ? void 0 : _window.__subPackages) !== null && _ref !== void 0 ? _ref : [];
  }
  for (var i = 0; i < subPackages.length; ++i) {
    var prefix = subPackages[i].root || '';
    if (prefix && prefix.slice(-1) !== '/') {
      prefix += '/';
    }
    if (route.slice(0, prefix.length) === prefix) {
      return subPackages[i];
    }
  }
  return null;
};
var matchSubPackageName = route => {
  var subPackage = matchSubPackage(route);
  if (!subPackage) return '__APP__';
  var prefix = subPackage.root || '';
  return prefix.slice(-1) === '/' ? prefix : prefix + '/';
};
var isSubPackageIndependent = route => {
  var subPackage = matchSubPackage(route);
  if (!subPackage) return false;
  return subPackage.independent;
};
var ENTRY_FILE = (() => {
  if (isDataThread()) {
    return {
      main: 'app-service.js',
      sub: 'app-service.js',
      lazyCommon: 'common.app.js',
      lazyApp: 'appservice.app.js',
      plugin: 'appservice.js'
    };
  } else {
    return {
      main: 'app-wxss.js',
      sub: 'page-frame.js',
      lazyCommon: 'common.app.js',
      lazyApp: 'webview.app.js',
      plugin: 'pageframe.js'
    };
  }
})();
var extendedLibs = ['wx0354ba48aadc0ab2', 'wxfa43a4a7041a84de'];
var normalizeSubPackageName = subPkg => {
  if (subPkg === '__APP__') return subPkg;
  if (subPkg[0] !== '/') subPkg = '/' + subPkg;
  if (subPkg[subPkg.length - 1] !== '/') subPkg += '/';
  return subPkg;
};
var subPackagePlugins = {};
var addSubPackagePlugin = (subPkg, plugin) => {
  subPkg = normalizeSubPackageName(subPkg);
  if (typeof plugin.subpackage !== 'string') {
    plugin.subpackage = subPkg;
  }
  if (subPackagePlugins[subPkg] === undefined) {
    subPackagePlugins[subPkg] = [plugin];
  } else {
    subPackagePlugins[subPkg].push(plugin);
  }
};
var subPackagePluginNotifier = createPublishSubscribe(['ready']);
var getSubPackagePlugin = (subPackage, cb) => {
  subPackagePluginNotifier.on('ready', () => {
    cb(subPackagePlugins[subPackage] || []);
  });
};
__wxConfig.onReady(() => {
  var unknownPlugins = new Set();
  var unknownPluginConfigs = {};
  Object.keys(__wxConfig.plugins || {}).forEach(alias => {
    var plugin = __wxConfig.plugins[alias];
    if (typeof plugin.subpackage === 'string') {
      addSubPackagePlugin(plugin.subpackage, plugin);
    } else {
      unknownPlugins.add(plugin.provider);
      unknownPluginConfigs[plugin.provider] = plugin;
    }
  });
  (__wxConfig.subpackages || []).forEach(subpackage => {
    Object.keys(subpackage.plugins || {}).forEach(alias => {
      var plugin = subpackage.plugins[alias];
      var pluginId = plugin.provider;
      if (unknownPlugins.has(pluginId)) {
        unknownPlugins.delete(pluginId);
        delete unknownPluginConfigs[pluginId];
        addSubPackagePlugin(subpackage.root, plugin);
      }
    });
  });
  Array.from(unknownPlugins).forEach(pluginId => {
    addSubPackagePlugin('__APP__', unknownPluginConfigs[pluginId]);
  });
  subPackagePluginNotifier.notify('ready');
});
var getEntryFile = (moduleName, log) => {
  log(`isLazyLoad: ${isLazyLoad()}`);
  log(`moduleName: ${moduleName}`);
  var separatedPlugins = __wxConfig.platform === 'devtools' ? [] : (subPackagePlugins[normalizeSubPackageName(moduleName)] || []).map(p => {
    var pluginId = p.provider;
    var prefix = `__plugin__/${pluginId}`;
    return {
      plugin_id: pluginId,
      prefix_path: extendedLibs.includes(pluginId) ? null : prefix
    };
  });
  log(`separatedPlugins: ${JSON.stringify(separatedPlugins)}`);
  var isMainPackage = moduleName === '__APP__';
  var modulePrefix = isMainPackage ? '' : moduleName;
  if (isLazyLoad()) {
    var jsFiles = [];
    separatedPlugins.forEach(plugin => {
      var prePath = (modulePrefix + plugin.prefix_path + '/').replace(/\/\/$/, '/');
      if (!plugin.prefix_path) {
        prePath += `__extended__/${plugin.plugin_id}/`;
      }
      jsFiles.push(prePath + ENTRY_FILE.plugin);
    });
    jsFiles.push(modulePrefix + ENTRY_FILE.lazyCommon, modulePrefix + ENTRY_FILE.lazyApp);
    log(`all files to inject: ${JSON.stringify(jsFiles)}`);
    return jsFiles;
  } else {
    var _jsFiles = separatedPlugins.map(plugin => {
      var prePath = (modulePrefix + plugin.prefix_path + '/').replace(/\/\/$/, '/');
      if (!plugin.prefix_path) {
        prePath += `__extended__/${plugin.plugin_id}/`;
      }
      return prePath + ENTRY_FILE.plugin;
    });
    if (isMainPackage) {
      _jsFiles.push(modulePrefix + ENTRY_FILE.main);
    } else {
      _jsFiles.push(modulePrefix + ENTRY_FILE.sub);
    }
    log(`all files to inject: ${JSON.stringify(_jsFiles)}`);
    return _jsFiles;
  }
};
;// CONCATENATED MODULE: ./src/loadJsFiles.ts


var loadJsFileToSubContext = tag => (paths, options = {}) => {
  if (paths.length === 0) return {
    cost: 0,
    res: 'ok'
  };
  var subContextEngine = getSubContextEngine();
  wxNativeConsole.info(`[Lazyload] loadJsFileTo${tag}`);
  var begin = Date.now();
  var res = subContextEngine.loadJsFiles(paths, null, {
    reportKey: undefined,
    isPageInitialScript: options.isPageInitialScript
  });
  var end = Date.now();
  wxNativeConsole.info(`[Lazyload] loadJsFileTo${tag} done, cost: ${end - begin}ms`);
  return {
    cost: end - begin,
    res
  };
};
var loadJsFileToDataThread = loadJsFileToSubContext('AppService');
var loadJsFileToRenderContext = loadJsFileToSubContext('RenderContext');
var webviewInjectedFiles = new Set();
var loadJsFilesToWebviewOnTheFly = false;
var pendingWebviewLoadJsFiles = [];
var loadJsFileToSclContext = loadJsFileToSubContext('SclContext');
var loadJsFileToWebview = (paths, callback, force = false) => {
  if (loadJsFilesToWebviewOnTheFly) {
    pendingWebviewLoadJsFiles.push([paths, callback, force]);
    return;
  }
  var alreadyInjected = paths.filter(p => webviewInjectedFiles.has(p));
  var needToInject = force ? paths : paths.filter(p => !webviewInjectedFiles.has(p));
  if (alreadyInjected.length > 0) {
    wxNativeConsole.info('[VD] loadJsFileToWebview ignored loaded: ' + alreadyInjected.join(','));
  }
  if (needToInject.length === 0) {
    wxNativeConsole.info('[VD] loadJsFileToWebview no files to load, return');
    callback(0);
    return;
  }
  needToInject.forEach(p => webviewInjectedFiles.add(p));
  var args = {
    paths: needToInject
  };
  var reportKey = undefined;
  if (__wxConfig.platform === 'android') {
    args.key = reportKey;
  } else {
    args.options = {
      reportKey
    };
  }
  loadJsFilesToWebviewOnTheFly = true;
  var WeixinJSBridge = getWeixinJSBridge();
  var begin = Date.now();
  WeixinJSBridge.invoke('loadJsFiles', args, () => {
    var end = Date.now();
    callback(end - begin);
    loadJsFilesToWebviewOnTheFly = false;
    if (pendingWebviewLoadJsFiles.length > 0) {
      var _args = pendingWebviewLoadJsFiles.shift();
      loadJsFileToWebview(..._args);
    }
  });
};
var devtoolLoadedComponents = new Set();
var loadComponentsInDevTool = (comps, callback) => {
  var alreadyInjected = comps.filter(p => devtoolLoadedComponents.has(p));
  var needToInject = comps.filter(p => !devtoolLoadedComponents.has(p));
  if (alreadyInjected.length > 0) {
    wxNativeConsole.info(`[loadComponentsInDevTool] ignored loaded: [${alreadyInjected.length} comps]`);
  }
  if (needToInject.length === 0) {
    wxNativeConsole.info('[loadComponentsInDevTool] no comps to load, return');
    if (!isDataThread()) callback(0);
    return 0;
  }
  needToInject.forEach(p => devtoolLoadedComponents.add(p));
  var WeixinJSBridge = getWeixinJSBridge();
  var wait = isDataThread() ? cb => cb() : cb => {
    Foundation.onStart(() => {
      cb();
    });
  };
  return wait(() => {
    var begin = Date.now();
    WeixinJSBridge.invoke('loadComponents', {
      comps: needToInject
    }, () => {
      if (!isDataThread()) {
        var webviewEnd = Date.now();
        callback(webviewEnd - begin);
      }
    });
    var serviceEnd = Date.now();
    return serviceEnd - begin;
  });
};
var lazyLoadTimeout = 5000;
var setLazyLoadTimeout = timeout => {
  lazyLoadTimeout = timeout;
};
var getLazyLoadTimeout = () => lazyLoadTimeout;
var lazyLoadErrorCb = () => {};
var triggerLazyLoadError = res => {
  lazyLoadErrorCb(res);
};
var onLazyLoadError = callback => {
  lazyLoadErrorCb = callback;
};
;// CONCATENATED MODULE: ./src/loadSubPackage.ts

var loadSubPackage = (subPackage, callback) => {
  var appServiceSDK = getAppServiceSDK();
  var begin = Date.now();
  appServiceSDK.loadSubpackage({
    name: subPackage,
    success() {
      var end = Date.now();
      callback({
        cost: end - begin,
        res: 'ok',
        pkg: subPackage
      });
      wxNativeConsole.info(`[VD] loadSubPackage ${subPackage} success, cost ${end - begin}`);
    },
    fail() {
      var end = Date.now();
      callback({
        cost: end - begin,
        res: 'fail',
        pkg: subPackage
      });
      wxNativeConsole.info(`[VD] loadSubPackage ${subPackage} fail, cost ${end - begin}`);
    }
  });
};
var batchLoadSubPackage = (subPackages, callback) => {
  var appServiceSDK = getAppServiceSDK();
  var begin = Date.now();
  var packages = subPackages.map(p => ({
    name: p
  }));
  appServiceSDK.batchLoadSubpackage({
    packages,
    success() {
      var end = Date.now();
      callback({
        cost: end - begin,
        res: 'ok',
        pkg: subPackages
      });
      wxNativeConsole.info(`[VD] batchLoadSubPackage ${subPackages} success, cost ${end - begin}`);
    },
    fail() {
      var end = Date.now();
      callback({
        cost: end - begin,
        res: 'fail',
        pkg: subPackages
      });
      wxNativeConsole.info(`[VD] batchLoadSubPackage ${subPackages} fail, cost ${end - begin}`);
    }
  });
};
var injectSubPackagesInDevTool = (subPackages, callback) => {
  var WeixinJSBridge = getWeixinJSBridge();
  wxNativeConsole.info('[VD] injectSubPackages: ' + subPackages.join(', '));
  WeixinJSBridge.invoke('injectSubPackages', {
    subPackages
  }, callback);
};
;// CONCATENATED MODULE: ./src/utils/tips.js
var lazyLoadModePrinted = false;
var printLazyLoadMode = () => {
  if (lazyLoadModePrinted) return;
  lazyLoadModePrinted = true;
  var lazyCodeLoadingMode = 'disabled';
  if (__wxConfig.isLazyLoad) {
    lazyCodeLoadingMode = typeof __LAZY_CODE_LOADING_CHUNK_MAP__ !== 'undefined' ? 'requiredComponentChunks' : 'requiredComponents';
  }
  wxNativeConsole.info(`LazyCodeLoading: ${lazyCodeLoadingMode}`);
};
;// CONCATENATED MODULE: ./src/utils/plugin.js

var plugin_exparser = getExparser();
var getPluginComponents = pluginInfo => {
  var provider = pluginInfo.provider;
  var compList = plugin_exparser.Component._list;
  var components = Object.keys(compList).filter(comp => comp.indexOf(`plugin-private://${provider}/`) === 0);
  return components;
};
var getPluginProviderByAlias = alias => {
  var plugins = __wxConfig.plugins || {};
  if (plugins[alias]) {
    return plugins[alias].provider;
  }
  return null;
};
;// CONCATENATED MODULE: ./src/comp_api/comp_manager.ts











var comp_manager_hasOwnProperty = Object.prototype.hasOwnProperty;
var isDevTool = () => __wxConfig.platform === 'devtools' || __wxConfig.serviceRuntime === 'devtool';
var isLazyLoadChunks = () => typeof __LAZY_CODE_LOADING_CHUNK_MAP__ !== 'undefined';
var _isFirstPage = true;
class ComponentManager {
  constructor(viewId, treeManager) {
    this.__viewId = void 0;
    this.__treeManager = void 0;
    this.__loadedSubPackage = new Set();
    this.__injectedSubPackage = new Set();
    this.__logPrefix = void 0;
    this.__log = void 0;
    this.__ensureComponentNotifier = {};
    this.__placeholderReplacement = null;
    this.__pendingReplacement = new Map();
    this.__injectedComponents = new Set();
    this.__restoreInjectNotifier = null;
    this.__pageReady = false;
    this.__shouldDoPlaceholderReplaceOnReady = false;
    this.__viewId = viewId;
    this.__treeManager = treeManager;
    this.__logPrefix = `[CompMgr] [${isDataThread() ? 'data' : currentRenderBackend()}] $[${this.__viewId}]`;
    this.__log = msg => {
      wxNativeConsole.info(`${this.__logPrefix} ${msg}`);
    };
  }
  get treeManager() {
    return this.__treeManager;
  }
  getRestoredData() {
    return [Array.from(this.__loadedSubPackage), Array.from(this.__injectedSubPackage), Object.fromEntries(ComponentManager.__classPrefixMap), Array.from(this.__injectedComponents), this.__treeManager.rootCompName];
  }
  getRestoreInjectNotifier() {
    if (!this.__restoreInjectNotifier) {
      this.__restoreInjectNotifier = createPublishSubscribe(['inject']);
    }
    return this.__restoreInjectNotifier;
  }
  restore(data) {
    var [loadedSubPackage, injectedSubPackage, classPrefixMap, injectedComponents, rootCompName] = data;
    var done = () => {
      injectWxss(rootCompName);
      triggerGenerateFuncReady(rootCompName);
      this.getRestoreInjectNotifier().notify('inject');
    };
    this.setSubPackageLoaded(loadedSubPackage);
    this.batchInjectSubPackages(injectedSubPackage, () => {
      if (isLazyLoad()) {
        this.batchInjectComponents(injectedComponents, done);
      } else {
        done();
      }
    });
    ComponentManager.__usedClassPrefix = new Set(Object.values(classPrefixMap));
    ComponentManager.__classPrefixMap = new Map(Object.entries(classPrefixMap));
  }
  onRestoreInjectDone(cb) {
    this.getRestoreInjectNotifier().on('inject', cb);
  }
  recurseUsingComponents(compNames) {
    if (!isLazyLoad()) return compNames;
    var codeMap = __wxAppCode__;
    var wxmlDependencies = typeof __WXML_DEP__ !== 'undefined' ? __WXML_DEP__ || {} : {};
    var visitedComponents = new Set();
    var usedComponentSet = new Set();
    var getUsing = comp => {
      if (visitedComponents.has(comp)) return;
      visitedComponents.add(comp);
      if (comp_manager_hasOwnProperty.call(codeMap, comp + '.json')) {
        usedComponentSet.add(comp);
        var using = getUsingByPath(comp, codeMap);
        var generics = getGenericsByPath(comp, codeMap);
        var placeholder = getPlaceholderByPath(comp, codeMap);
        for (var usedComp of Object.keys(using)) {
          if (comp_manager_hasOwnProperty.call(placeholder, usedComp)) {
            if (comp_manager_hasOwnProperty.call(using, placeholder[usedComp])) {
              getUsing(using[placeholder[usedComp]]);
            } else {}
          } else getUsing(using[usedComp]);
        }
        for (var k of Object.keys(generics)) {
          var genericConfig = generics[k];
          if (typeof genericConfig.default !== 'string') continue;
          getUsing(genericConfig.default);
        }
      }
      var wxmlDeps = wxmlDependencies['./' + comp + '.wxml'] || [];
      wxmlDeps.forEach(wxml => {
        var compName = wxml.substr(2, wxml.length - 7);
        getUsing(compName);
      });
    };
    compNames.forEach(compName => {
      getUsing(compName);
    });
    var components = Array.from(usedComponentSet);
    this.__log(`recurseUsingComponents(${JSON.stringify(compNames)}) => [${components.length} components]`);
    return components;
  }
  batchLoadSubPackages(subPackages, cb) {
    this.__log('batchLoadSubPackages begin: ' + subPackages.join(', '));
    var timeout = true;
    setTimeout(() => {
      if (timeout) {
        triggerLazyLoadError({
          type: 'subpackage',
          errMsg: 'batchLoadSubpackage: timeout',
          subpackage: subPackages
        });
      }
    }, getLazyLoadTimeout());
    var totCost = 0;
    var flag = false;
    if (flag) {
      batchLoadSubPackage(subPackages, loadRes => {
        timeout = false;
        var loadedSubPackages = [];
        var {
          res,
          pkg,
          cost
        } = loadRes;
        if (res === 'fail') {
          triggerLazyLoadError({
            type: 'subpackage',
            subpackage: pkg,
            errMsg: 'batchLoadSubpackage: fail'
          });
        } else {
          loadedSubPackages = pkg;
        }
        totCost += cost;
        this.__log(`batchLoadSubPackages end: ${subPackages.join(', ')}, cost: ${totCost}`);
        this.setSubPackageLoaded(loadedSubPackages);
        this.__treeManager.operationFlow.sendInIndividualFlow([constants_SYNC_EVENT_NAME.FLOW_SET_SUBPACKAGE_LOADED, loadedSubPackages]);
        cb(loadedSubPackages);
      });
    } else {
      Promise.all(subPackages.map(subPackage => new Promise(resolve => {
        loadSubPackage(subPackage, resolve);
      }))).then(res => {
        timeout = false;
        var loadedSubPackages = [];
        var unloadSubPackages = [];
        res.forEach(loadRes => {
          var {
            res,
            pkg,
            cost
          } = loadRes;
          if (res === 'fail') {
            unloadSubPackages.push(pkg);
          } else {
            loadedSubPackages.push(pkg);
          }
          totCost += cost;
        });
        if (unloadSubPackages.length) {
          triggerLazyLoadError({
            type: 'subpackage',
            subpackage: unloadSubPackages,
            errMsg: 'loadSubpackage: fail'
          });
        }
        this.__log(`loadSubPackages end: ${subPackages.join(', ')}, cost: ${totCost}`);
        this.setSubPackageLoaded(loadedSubPackages);
        this.__treeManager.operationFlow.sendInIndividualFlow([constants_SYNC_EVENT_NAME.FLOW_SET_SUBPACKAGE_LOADED, loadedSubPackages]);
        cb(loadedSubPackages);
      });
    }
  }
  setSubPackageLoaded(subPackages) {
    this.__log('setSubPackageLoaded: ' + subPackages.join(', '));
    subPackages.forEach(subPackage => {
      this.__loadedSubPackage.add(subPackage);
    });
  }
  batchInjectSubPackages(subPackages, cb) {
    this.__log('injectSubPackages: ' + subPackages.join(', '));
    var routes = subPackages.filter(subPackage => !this.__injectedSubPackage.has(subPackage)).map(subPackage => {
      if (subPackage === '__APP__') return subPackage;
      if (subPackage.slice(-1) === '/') return subPackage;
      return subPackage + '/';
    });
    if (isDevTool()) {
      if (isDataThread()) {
        injectSubPackagesInDevTool(routes);
        this.setSubPackageInjected(routes);
      } else if (currentRenderBackend() === 'webview') {
        injectSubPackagesInDevTool(routes, () => {
          this.setSubPackageInjected(routes);
          cb();
        });
      } else if (currentRenderBackend() === 'skyline') {
        var jsFiles = Array.prototype.concat(...routes.map(r => getEntryFile(r, s => {
          this.__log(`getEntryFile ${r}: ${s}`);
        })));
        loadJsFileToRenderContext(jsFiles);
        this.setSubPackageInjected(routes);
        prepareSubPackagesStyle(this.__viewId, subPackages);
        cb();
      }
    } else {
      var _jsFiles = [];
      routes.forEach(r => {
        _jsFiles.push(...getEntryFile(r, s => {
          this.__log(`getEntryFile ${r}: ${s}`);
        }));
      });
      if (isDataThread()) {
        loadJsFileToDataThread(_jsFiles);
        this.setSubPackageInjected(routes);
      } else if (currentRenderBackend() === 'webview') {
        loadJsFileToWebview(_jsFiles, () => {
          this.setSubPackageInjected(routes);
          cb();
        });
      } else if (currentRenderBackend() === 'skyline' || currentRenderBackend() === 'xr-frame') {
        loadJsFileToRenderContext(_jsFiles);
        this.setSubPackageInjected(routes);
        prepareSubPackagesStyle(this.__viewId, subPackages);
        cb();
      } else if (currentRenderBackend() === 'scl') {
        loadJsFileToSclContext(_jsFiles);
        this.setSubPackageInjected(routes);
        cb();
      } else {
        throw new Error('unknown render backend: ' + currentRenderBackend());
      }
    }
  }
  batchInjectComponents(compNames, cb, isPageInitialScript = false) {
    if (!isLazyLoad()) {
      if (!isDataThread()) cb(0);
      return -1;
    }
    var _compNames = compNames.map(compName => convertComponentAliasToRoute(compName)).filter(compName => !this.__injectedComponents.has(compName)).filter(compName => !compName.includes('://'));
    this.__log(`injectComponents: [${_compNames.length} components]`);
    if (isDataThread()) {
      var doLoading = () => {
        if (!isDevTool()) {
          var allFiles = [];
          if (isLazyLoadChunks()) {
            var allChunks = new Set(_compNames.map(c => __LAZY_CODE_LOADING_CHUNK_MAP__[c] || c));
            Array.from(allChunks).forEach(c => {
              allFiles.push(`${c}.common.js`, `${c}.appservice.js`);
            });
          } else {
            _compNames.forEach(c => {
              allFiles.push(`${c}.common.js`, `${c}.appservice.js`);
            });
          }
          var {
            res,
            cost
          } = loadJsFileToDataThread(allFiles, {
            isPageInitialScript
          });
          if (res === 'failed') {
            triggerLazyLoadError({
              type: 'components',
              components: _compNames,
              errMsg: 'loadComponents: fail'
            });
          }
          return cost;
        } else return loadComponentsInDevTool(_compNames);
      };
      var timeCost = doLoading();
      _compNames.forEach(compName => {
        this.__injectedComponents.add(compName);
      });
      return timeCost;
    } else {
      var allFiles = [];
      if (isLazyLoadChunks()) {
        var allChunks = new Set(_compNames.map(c => __LAZY_CODE_LOADING_CHUNK_MAP__[c] || c));
        Array.from(allChunks).forEach(c => {
          allFiles.push(`${c}.common.js`, `${c}.webview.js`);
        });
      } else {
        _compNames.forEach(c => {
          allFiles.push(`${c}.common.js`, `${c}.webview.js`);
        });
      }
      if (currentRenderBackend() === 'webview') {
        var _doLoading = cb => {
          if (!isDevTool()) {
            var injectCommonApp = new Promise(resolve => {
              // #6830
              if (!__wxAppCode__) {
                loadJsFileToWebview(['common.app.js'], resolve);
              } else {
                resolve(0);
              }
            });
            injectCommonApp.then(() => {
              loadJsFileToWebview(allFiles, cb);
            });
          } else loadComponentsInDevTool(_compNames, cb);
        };
        _doLoading(timeCost => {
          _compNames.forEach(compName => {
            this.__injectedComponents.add(compName);
          });
          cb(timeCost);
        });
        return -1;
      } else if (currentRenderBackend() === 'skyline' || currentRenderBackend() === 'xr-frame') {
        var {
          cost
        } = loadJsFileToRenderContext(allFiles);
        _compNames.forEach(compName => {
          this.__injectedComponents.add(compName);
        });
        cb(cost);
        return cost;
      } else if (currentRenderBackend() === 'scl') {
        var {
          cost: _cost
        } = loadJsFileToSclContext(allFiles);
        _compNames.forEach(compName => {
          this.__injectedComponents.add(compName);
        });
        cb(_cost);
        return _cost;
      } else {
        throw new Error('unknown render backend: ' + currentRenderBackend());
      }
    }
  }
  setSubPackageInjected(subPackages) {
    this.__log('setSubPackageInjected: ' + subPackages.join(', '));
    if (isDataThread()) {
      subPackages.forEach(pkg => {
        if (pkg !== '__APP__' && pkg.indexOf('/') !== 0) {
          pkg = `/${pkg}`;
        }
        getSubPackagePlugin(pkg, plugins => {
          Object.keys(plugins).forEach(key => {
            var pluginInfo = plugins[key];
            var comps = getPluginComponents(pluginInfo);
            comps.forEach(comp => {
              var compName = convertComponentAliasToRoute(comp);
              this.__injectedComponents.add(compName);
            });
          });
        });
      });
    }
    subPackages.forEach(subPackage => {
      this.__injectedSubPackage.add(subPackage);
    });
  }
  setInitialSubPackage(rootCompPath) {
    var subPackages = [matchSubPackageName(rootCompPath)];
    if (!isSubPackageIndependent(rootCompPath) && !subPackages.includes('__APP__')) {
      subPackages.push('__APP__');
    }
    this.setSubPackageLoaded(subPackages);
    this.setSubPackageInjected(subPackages);
    if (isDataThread()) printLazyLoadMode();
  }
  shouldUsePlaceholder(compName) {
    var _compName = convertComponentAliasToRoute(compName);
    var subPackage = matchSubPackageName(_compName);
    var isCompReady = this.__loadedSubPackage.has(subPackage);
    if (isLazyLoad()) isCompReady = isCompReady && this.__injectedComponents.has(_compName);
    return !isCompReady;
  }
  doLazyLoadReport(loadedComps, timeCost) {
    var report = createLazyLoadReport();
    var isFirstPage = Boolean(isDataThread() ? _isFirstPage : __wxConfig.isFirstPage);
    _isFirstPage = false;
    var totalComps = Object.keys(__wxAppCode__).filter(k => k.endsWith('.json')).length;
    report.set('isFirstPage', isFirstPage);
    report.set('totalComps', totalComps);
    report.set('loadedComps', loadedComps);
    report.set('loadTime', timeCost);
  }
  injectComponentsRecursively(compNames, cb, shouldDoReport = false, isPageInitialScript = false) {
    if (!isLazyLoad()) {
      if (!isDataThread()) cb();
      return;
    }
    var components = this.recurseUsingComponents(compNames);
    var timeCost = this.batchInjectComponents(components, timeCost => {
      if (!isDataThread()) {
        if (shouldDoReport) {
          this.doLazyLoadReport(components.length, timeCost);
        }
        cb();
      }
    }, isPageInitialScript);
    if (isDataThread() && shouldDoReport) {
      this.doLazyLoadReport(components.length, timeCost);
    }
  }
  ensureComponents(compNames, loadId, callback) {
    var subPackages = compNames.map(compName => matchSubPackageName(compName));
    subPackages = unique(subPackages);
    if (subPackages.some(p => !isSubPackageIndependent(p)) && !subPackages.includes('__APP__')) {
      subPackages.unshift('__APP__');
    }
    subPackages = subPackages.filter(subPackage => !this.__loadedSubPackage.has(subPackage));
    this.batchLoadSubPackages(subPackages, loadedSubPackages => {
      this.__treeManager.operationFlow.sendInIndividualFlow([constants_SYNC_EVENT_NAME.FLOW_INJECT_SUBPACKAGE, loadId, loadedSubPackages]);
      if (isLazyLoad()) {
        this.__treeManager.operationFlow.sendInIndividualFlow([constants_SYNC_EVENT_NAME.FLOW_INJECT_COMPONENT, loadId, compNames]);
      }
      this.batchInjectSubPackages(loadedSubPackages);
      var env = getGlassEaselAdapter().getEnv();
      env.codeManager.prepareSubPackagesStyle(loadedSubPackages);
      env.afterPackageCommonEvaluation();
      env.codeManager.wrapComponentsInjection(() => {
        this.injectComponentsRecursively(compNames);
      });
      callback();
    });
  }
  pendPlaceholderReplacement(loadId) {
    var replacement = this.getPlaceholderReplaceData();
    this.finishPlaceholderReplacement();
    if (replacement !== null) {
      this.__pendingReplacement.set(loadId, replacement);
      this.__log(`set [${loadId}] as pending placeholder replacements (${replacement.replacers.length} replacers)`);
    }
  }
  getAndClearPendingPlaceholderReplacement(loadId) {
    var replacement = this.__pendingReplacement.get(loadId);
    this.__pendingReplacement.delete(loadId);
    return replacement;
  }
  getEnsureComponentsNotifier(loadId) {
    if (!this.__ensureComponentNotifier[loadId]) {
      var events = ['inject', 'def'];
      if (isLazyLoad()) events.push('inject-common');
      this.__ensureComponentNotifier[loadId] = createPublishSubscribe(events);
    }
    return this.__ensureComponentNotifier[loadId];
  }
  destructEnsureComponentsNotifier(loadId) {
    if (this.__ensureComponentNotifier[loadId]) {
      delete this.__ensureComponentNotifier[loadId];
    }
  }
  injectSubPackageOnReady(loadId, subPackages) {
    this.batchInjectSubPackages(subPackages, () => {
      var event = isLazyLoad() ? 'inject-common' : 'inject';
      this.getEnsureComponentsNotifier(loadId).notify(event);
    });
  }
  injectComponentsOnReady(loadId, compNames) {
    if (!isLazyLoad()) return;
    this.getEnsureComponentsNotifier(loadId).on('inject-common', () => {
      this.injectComponentsRecursively(compNames, () => {
        this.getEnsureComponentsNotifier(loadId).notify('inject');
      });
    });
  }
  appendComponentDef(loadId, compDef) {
    this.getEnsureComponentsNotifier(loadId).on('inject', () => {
      onComponentDef(compDef, false, this.__viewId);
      this.getEnsureComponentsNotifier(loadId).notify('def');
    });
  }
  waitComponentEnsuring(loadId, callback) {
    this.getEnsureComponentsNotifier(loadId).on('def', () => {
      callback(() => {
        this.destructEnsureComponentsNotifier(loadId);
      });
    });
  }
  setPageReady() {
    this.__pageReady = true;
    if (this.__shouldDoPlaceholderReplaceOnReady) {
      this.__shouldDoPlaceholderReplaceOnReady = false;
      this.doPlaceholderReplaceOnReady();
    }
  }
  doPlaceholderReplace() {
    var loadId = utils_guid();
    var tm = this.__treeManager;
    var replacement = this.getPlaceholderReplaceData();
    this.finishPlaceholderReplacement();
    if (replacement !== null) {
      var compNames = Array.from(replacement.compNames);
      this.__treeManager.operationFlow.sendInIndividualFlow([constants_SYNC_EVENT_NAME.FLOW_PEND_PLACEHOLDER_REPLACEMENT, loadId]);
      this.__log(`doPlaceholderReplace(${loadId}) for ${replacement.replacers.length} placeholder replacements`);
      this.ensureComponents(compNames, loadId, () => {
        doDataThreadReplacePlaceholder(tm, tm.rootCompName, replacement, loadId);
      });
    }
  }
  doPlaceholderReplaceOnReady() {
    if (this.__pageReady) {
      this.__placeholderReplacement.timer = setTimeout(() => {
        this.doPlaceholderReplace();
      }, 50);
    } else this.__shouldDoPlaceholderReplaceOnReady = true;
  }
  arrangePlaceholderReplace(compName, replacer) {
    if (this.__placeholderReplacement === null) {
      this.__placeholderReplacement = {
        compNames: new Set(),
        replacers: [],
        timer: undefined
      };
    } else if (isDataThread()) {
      clearTimeout(this.__placeholderReplacement.timer);
    }
    this.__placeholderReplacement.compNames.add(compName);
    this.__placeholderReplacement.replacers.push(replacer);
    if (isDataThread()) this.doPlaceholderReplaceOnReady();
  }
  getPlaceholderReplaceData() {
    return this.__placeholderReplacement;
  }
  finishPlaceholderReplacement() {
    this.__placeholderReplacement = null;
  }
  static getComponentClassPrefix(compName) {
    if (ComponentManager.__classPrefixMap.has(compName)) {
      return ComponentManager.__classPrefixMap.get(compName);
    }
    var slices = compName.split(/[^a-z0-9]+/i);
    var name = '';
    var len = 0;
    var extraIndex = 0;
    do {
      if (len < slices.length) len += 1;else extraIndex += 1;
      name = slices.slice(-len).join('-');
      if (extraIndex > 0) name += '-' + extraIndex;
      if (Number(name[0]) >= 0) name = 'x-' + name;
    } while (ComponentManager.__usedClassPrefix.has(name));
    ComponentManager.__classPrefixMap.set(compName, name);
    ComponentManager.__usedClassPrefix.add(name);
    return name;
  }
}
ComponentManager.__classPrefixMap = new Map();
ComponentManager.__usedClassPrefix = new Set();
var comp_manager_viewThreadListeners = {
  [constants_SYNC_EVENT_NAME.FLOW_PEND_PLACEHOLDER_REPLACEMENT](cm, data) {
    var loadId = data[0];
    cm.pendPlaceholderReplacement(loadId);
  },
  [constants_SYNC_EVENT_NAME.FLOW_COMPONENT_DEF_ADD](cm, data) {
    var loadId = data[0];
    var compDef = data[1];
    cm.appendComponentDef(loadId, compDef);
  },
  [constants_SYNC_EVENT_NAME.FLOW_INJECT_SUBPACKAGE](cm, data) {
    var loadId = data[0];
    var subPackages = data[1];
    cm.injectSubPackageOnReady(loadId, subPackages);
  },
  [constants_SYNC_EVENT_NAME.FLOW_INJECT_COMPONENT](cm, data) {
    var loadId = data[0];
    var compNames = data[1];
    cm.injectComponentsOnReady(loadId, compNames);
  },
  [constants_SYNC_EVENT_NAME.FLOW_SET_SUBPACKAGE_LOADED](cm, data) {
    var subPackages = data[0];
    cm.setSubPackageLoaded(subPackages);
  },
  [constants_SYNC_EVENT_NAME.FLOW_WAIT_COMPONENT](cm, data) {
    var loadId = data[0];
    cm.treeManager.operationFlow.block();
    cm.waitComponentEnsuring(loadId, done => {
      cm.treeManager.operationFlow.unblock();
      done();
    });
  }
};
;// CONCATENATED MODULE: ./src/utils/calc.js

var calc_exparser = getExparser();
var dfs = (elem, countMap, isRoot) => {
  if (elem instanceof calc_exparser.Component) {
    if (elem !== window.__DOMTree__) {
      countMap.compCount++;
      if (elem.hasBehavior('wx-base')) {
        if (isRoot) countMap.rootInternalCompCount++;
        if (elem.hasBehavior('wx-native')) countMap.nativeCompCount++;
      } else {
        if (isRoot) countMap.rootCustomCompCount++;
      }
    }
    var passIsRoot = elem === window.__DOMTree__ ? isRoot : false;
    if (elem.shadowRoot instanceof calc_exparser.Element) dfs(elem.shadowRoot, countMap, passIsRoot);
  }
  var children = elem.childNodes;
  for (var i = 0, len = children.length; i < len; i++) {
    var _passIsRoot = children[i] instanceof calc_exparser.VirtualNode || elem === window.__DOMTree__ || elem === window.__DOMTree__.shadowRoot ? isRoot : false;
    if (children[i] instanceof calc_exparser.Element) dfs(children[i], countMap, _passIsRoot);
  }
};
var getComponentCount = () => {
  var countMap = {
    compCount: 0,
    customCompCount: 0,
    nativeCompCount: 0,
    rootCustomCompCount: 0,
    rootInternalCompCount: 0
  };
  try {
    dfs(window.__DOMTree__, countMap, true);
  } catch (err) {}
  var {
    compCount,
    customCompCount,
    nativeCompCount,
    rootCustomCompCount,
    rootInternalCompCount
  } = countMap;
  var rootCompCount = rootCustomCompCount + rootInternalCompCount;
  var rootCustomCompRatio = rootCompCount ? Math.floor(rootCustomCompCount * 100 / rootCompCount) : 0;
  return {
    compCount,
    customCompCount,
    nativeCompCount,
    rootCompCount,
    rootCustomCompCount,
    rootCustomCompRatio,
    rootInternalCompCount
  };
};
;// CONCATENATED MODULE: ./src/save_restore_view.js







var splitData = {
  id: null,
  prev: null,
  data: []
};
setDataListener(constants_SYNC_EVENT_NAME.SAVE_STATE, () => {});
setDataListener(constants_SYNC_EVENT_NAME.RESTORE_STATE, ([statesData, idDataMap, compIdArr, compManagerData], ev, pageId) => {
  if (statesData && statesData.isSplitData) {
    var {
      id,
      index,
      total,
      data
    } = statesData.splitInfo;
    if (index !== 1 && (index !== splitData.prev + 1 || id !== splitData.id)) {
      splitData.id = null;
      splitData.prev = null;
      splitData.data = [];
      return;
    } else if (index === total) {
      splitData.data.push(data);
      var restoredData = splitData.data.join('');
      try {
        restoredData = JSON.parse(restoredData);
      } catch (err) {
        console.error('Expected parse completed data with split data but got error');
        Reporter.errorReport({
          key: 'webviewScriptError',
          error: new Error('Expected parse completed data with split data but got error')
        });
        restoredData = null;
      }
      splitData.id = null;
      splitData.prev = null;
      splitData.data = [];
      if (!restoredData) return;
      statesData = restoredData[0];
      idDataMap = restoredData[1];
      compIdArr = restoredData[2];
      compManagerData = restoredData[3];
    } else {
      splitData.id = id;
      splitData.prev = index;
      splitData.data.push(data);
      return;
    }
  }
  save_restore_view_states.restoring = statesData || {};
  save_restore_view_states.idDataMap = idDataMap;
  save_restore_view_states.compIdArr = compIdArr;
  save_restore_view_states.compIdArrIndex = 0;
  var cm = tree_manager.get(pageId).compManager;
  cm.restore(compManagerData);
  save_restore_view_states.onReady = cm.onRestoreInjectDone.bind(cm);
});
var savePageState = statesData => {
  var scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
  statesData.__page__ = {
    scrollTop
  };
};
var restorePageState = statesData => {
  var state = statesData.__page__;
  if (state) {
    var scrollTop = parseInt(state.scrollTop, 10);
    requestAnimationFrame(() => {
      document.body.scrollTop = document.documentElement.scrollTop = scrollTop;
    });
  }
};
var callSavedLifeTimes = statesData => {
  savePageState(statesData);
  statesData.compExtraDataMap = {};
  var nodeIndex = 0;
  if (window.__TAB_BAR__) {
    utils_dfsComponents(window.__TAB_BAR__, 1, node => {
      node.triggerLifeTime('saved', [statesData]);
      saveNodeExtraData(statesData.compExtraDataMap, node, nodeIndex++);
    });
    saveTabRootExtraData(statesData.compExtraDataMap);
  }
  utils_dfsComponents(window.__DOMTree__, 1, node => {
    node.triggerLifeTime('saved', [statesData]);
    saveNodeExtraData(statesData.compExtraDataMap, node, nodeIndex++);
  });
  saveRootExtraData(statesData.compExtraDataMap);
};
var callRestoredLifeTimes = statesData => {
  restorePageState(statesData);
  var nodeIndex = 0;
  if (window.__TAB_BAR__) {
    utils_dfsComponents(window.__TAB_BAR__, 1, node => {
      node.triggerLifeTime('restored', [statesData]);
      restoreNodeExtraData(statesData.compExtraDataMap, node, nodeIndex++);
    });
    restoreTabRootExtraData(statesData.compExtraDataMap);
  }
  utils_dfsComponents(window.__DOMTree__, 1, node => {
    node.triggerLifeTime('restored', [statesData]);
    restoreNodeExtraData(statesData.compExtraDataMap, node, nodeIndex++);
  });
  restoreRootExtraData(statesData.compExtraDataMap);
};
var saveStates = () => {
  __webViewSDK__.publish('recycleStatistics', getComponentCount());
  var statesData = {};
  callSavedLifeTimes(statesData);
  bridge_sendData(constants_SYNC_EVENT_NAME.REQUEST_SAVE, statesData, 0, true);
  flushDataBuffer();
  if (typeof wx.webViewReadyToTerminate === 'function') wx.webViewReadyToTerminate({});
};
var registerSavingListener = () => {
  window.__forceSaveStates__ = saveStates;
  if (typeof wx.onWebViewWillManuallyTerminate === 'function') wx.onWebViewWillManuallyTerminate(saveStates);
};
;// CONCATENATED MODULE: ./src/save_restore_data.js





var save_restore_data_exparser = getExparser();
var splitLimit = (/* unused pure expression or super */ null && (1024 * 256));
var splitId = Date.now();
var saveView = (viewId, statesData) => {
  var tm = tree_manager.get(viewId);
  if (!tm) return;
  tm.statesData = statesData;
  if (tm.tabRoot) {
    utils_dfsComponents(tm.tabRoot, 1, node => {
      node.triggerLifeTime('saved');
    });
  }
  utils_dfsComponents(tm.root, 1, node => {
    node.triggerLifeTime('saved');
  });
  bridge_sendData(constants_SYNC_EVENT_NAME.SAVE_STATE, [], viewId);
};
var restoreView = viewId => {
  var tm = TreeManager.get(viewId);
  if (!tm) return;
  var idNodeMap = tm.nodeId.getAll();
  var idDataMap = {};
  var compIdArr = [];
  var collectMap = node => {
    var compId = tm.nodeId.getNodeId(node);
    if (compId !== undefined) {
      compIdArr.push(compId);
      idDataMap[compId] = save_restore_data_exparser.Component.getInnerData(idNodeMap[compId]);
    }
  };
  if (tm.tabRoot && !tm.tabDestroyed) {
    dfsComponents(tm.tabRoot, 1, collectMap);
  }
  dfsComponents(tm.root, 1, collectMap);
  var compManagerData = tm.compManager.getRestoredData();
  var restoredData = [tm.statesData || {}, idDataMap, compIdArr, compManagerData];
  var dataString = JSON.stringify(restoredData);
  var totalLength = dataString.length;
  if (totalLength > splitLimit) {
    var splitList = [];
    var beginIndex = 0;
    while (totalLength > beginIndex) {
      splitList.push(dataString.substr(beginIndex, splitLimit));
      beginIndex += splitLimit;
    }
    var id = ++splitId;
    for (var i = 0, len = splitList.length; i < len; i++) {
      sendData(SYNC_EVENT_NAME.RESTORE_STATE, [{
        isSplitData: true,
        splitInfo: {
          id,
          index: i + 1,
          total: len,
          data: splitList[i]
        }
      }], viewId);
    }
  } else {
    sendData(SYNC_EVENT_NAME.RESTORE_STATE, restoredData, viewId);
  }
  tm.statesData = undefined;
  if (!tm.tabDestroyed && tm.tabRoot) {
    sendData(SYNC_EVENT_NAME.COMPONENT_DEF_TAB, tm.tabUsedDef, viewId);
    var tabRoot = tm.tabRoot;
    tm.operationFlow.start();
    tm.operationFlow.push([SYNC_EVENT_NAME.FLOW_CREATE_TAB, tabRoot.is, tm.nodeId.getNodeId(tabRoot)]);
    tm.operationFlow.push([SYNC_EVENT_NAME.FLOW_CREATE_TAB]);
    tm.operationFlow.end();
  }
  sendData(SYNC_EVENT_NAME.COMPONENT_DEF, tm.usedDef, viewId);
  var root = tm.root;
  tm.operationFlow.start();
  tm.operationFlow.push([SYNC_EVENT_NAME.FLOW_INITIAL_CREATION, root.is, tm.nodeId.getNodeId(root), {}]);
  tm.operationFlow.push([SYNC_EVENT_NAME.FLOW_INITIAL_CREATION]);
  tm.operationFlow.end();
  if (tm.tabRoot) {
    dfsComponents(tm.tabRoot, 1, node => {
      node.triggerLifeTime('restored');
    });
  }
  dfsComponents(tm.root, 1, node => {
    node.triggerLifeTime('restored');
  });
};
;// CONCATENATED MODULE: ./src/comp_api/domain.js



var domain_exparser = getExparser();
var domain_componentAliases = {};
var componentPathToAlias = {};
var getDomainByPluginId = function (pluginId, pluginVersion) {
  return pluginId + '/' + pluginVersion;
};
var publishDomainComponent = function (domain, compPath, alias, domainCheck = true) {
  var pluginInfo = compPath.match(/^plugin-private:\/\/(.*?)\//);
  if (!pluginInfo) return false;
  var pluginId = pluginInfo[1];
  var pluginVersion = '0';
  if (domainCheck && getDomainByPluginId(pluginId, pluginVersion) !== domain) return false;
  var aliasInfo = alias.match(/^plugin:\/\/(.*?)\//);
  if (!aliasInfo) return false;
  var aliasPluginId = aliasInfo[1];
  var aliasVersion = '0';
  if (domainCheck && getDomainByPluginId(aliasPluginId, aliasVersion) !== domain) return false;
  if (domain_exparser.Component._list[alias]) {
    console.error('"' + alias + '" has been used as another component or page. Please do not register multiple components or pages with the same alias.');
    return false;
  }
  aliasXrCustomOption(alias, compPath);
  domain_exparser.Component._list[alias] = domain_exparser.Component._list[compPath];
  domain_componentAliases[alias] = compPath;
  componentPathToAlias[compPath] = alias;
  return true;
};
var publishDomainComponents = function (domain, compMap) {
  for (var k in compMap) publishDomainComponent(domain, compMap[k], k);
};
var publishDomainComponentsWithoutCheck = compMap => {
  for (var k in compMap) publishDomainComponent('', compMap[k], k, false);
};
if (!isDataThread()) {
  window.publishDomainComponents = compMap => publishDomainComponentsWithoutCheck(compMap);
}
;// CONCATENATED MODULE: ./src/comp_api/initial-rendering-cache.js

var initial_rendering_cache_exparser = getExparser();
var DEFAULT_INITIAL_RENDERING_CACHE = '';
var initialRenderingCacheApplyTs = 0;
function initialRenderingCacheMode(path) {
  if (path && path.slice(5) !== '.html') path += '.html';
  var initialRenderingCache = DEFAULT_INITIAL_RENDERING_CACHE;
  if (__wxConfigWindow__ && __wxConfigWindow__.initialRenderingCache) {
    initialRenderingCache = String(__wxConfigWindow__.initialRenderingCache);
  }
  return initialRenderingCache;
}
function save(root, data) {
  var st = Date.now();
  var compWxssPath = {};
  var allCompWxssPath = {};
  var tags = document.head.querySelectorAll('style') || [];
  var styleList = [];
  var unusedStyleLength = 0;
  initial_rendering_cache_exparser.ElementIterator.create(root, 'composed-descendants-root-first', initial_rendering_cache_exparser.Component).forEach(comp => {
    if (!comp.hasBehavior('wx-base')) {
      compWxssPath['./' + comp.is + '.wxss'] = true;
    }
  });
  Object.keys(initial_rendering_cache_exparser.Component._list).forEach(key => {
    allCompWxssPath['./' + key + '.wxss'] = true;
  });
  for (var i = 0; i < tags.length; i++) {
    var tag = tags[i];
    var wxssPath = tag.getAttribute('wxss:path');
    if (wxssPath === undefined || wxssPath === null) continue;
    if (allCompWxssPath[wxssPath] && !compWxssPath[wxssPath]) {
      unusedStyleLength += tag.innerHTML.length + 15;
      continue;
    }
    styleList.push('<style>' + tag.innerHTML + '</style>');
  }
  var cssString = styleList.join('');
  var html = cssString + root.$$.innerHTML;
  wx.saveInitialRenderingCache({
    content: html,
    appserviceData: data
  });
  var costTime = Date.now() - st;
  wxConsole.log(`Initial rendering cache saved (cost time ${costTime}, total length ${html.length}, css length ${cssString.length}, dropped css length ${unusedStyleLength}, droppedRatio ${unusedStyleLength / (unusedStyleLength + html.length)})`);
}
function clear() {
  wx.saveInitialRenderingCache({
    content: ''
  });
  wxConsole.log('Initial rendering cache cleared');
}
function saveStaticInitialRenderingCache(root) {
  if (initialRenderingCacheApplyTs) {
    wxConsole.log(`initialRenderingCache applied (boost time ${Date.now() - initialRenderingCacheApplyTs})`);
  }
  var mode = initialRenderingCacheMode(window.__route__);
  if (mode !== 'static') {
    if (mode !== 'dynamic') {
      var envVersion = __wxConfig.envVersion;
      if (envVersion === 'develop' || envVersion === 'trial') {
        clear();
      }
    }
    return false;
  }
  save(root);
  return true;
}
function saveDynamicInitialRenderingCache(root, dynamicData) {
  if (initialRenderingCacheMode(window.__route__) !== 'dynamic') {
    console.error('An initial rendering cache state is ignored, because initialRenderingCache mode is not "dynamic".');
    return false;
  }
  if (!root) {
    clear();
  } else {
    save(root, dynamicData);
  }
  return true;
}
function applyInitialRenderingCache({
  content
}) {
  if (!content) return false;
  document.body.innerHTML = content;
  initialRenderingCacheApplyTs = Date.now();
  return true;
}
;// CONCATENATED MODULE: ./src/comp_api/animation.js



var animation_exparser = getExparser();
var applyAnimation = function (exparserNode, tm, viewId, selector, options, animeJS, callback, isLastAnimation) {
  var reqId = `${Math.random()}-${+new Date()}`;
  if (typeof callback === 'function') tm.applyAnimationCbMap[reqId] = callback;
  tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_SET_NODE_ANIMATION_INFO, {
    hasCallback: typeof callback === 'function',
    reqId,
    nodeId: tm.nodeId.getNodeId(exparserNode),
    webviewId: viewId,
    selector,
    options,
    type: animeJS ? 'animeJS' : undefined,
    isLastAnimation
  }]);
};
var clearAnimation = function (exparserNode, tm, viewId, selector, options, callback) {
  var reqId = `${Math.random()}-${+new Date()}`;
  if (typeof callback === 'function') tm.clearAnimationCbMap[reqId] = callback;else if (typeof options === 'function') tm.clearAnimationCbMap[reqId] = options;
  tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_CLEAR_NODE_ANIMATION_INFO, {
    hasCallback: typeof tm.clearAnimationCbMap[reqId] === 'function',
    reqId,
    nodeId: tm.nodeId.getNodeId(exparserNode),
    webviewId: viewId,
    selector,
    options
  }]);
};
var registerAnimationListeners = function (viewId, tm) {
  setDataListener(constants_SYNC_EVENT_NAME.ANIMATION_TRANSITION_END, res => {
    if (res && res[0] && res[0].reqId) {
      var callback = tm.applyAnimationCbMap[res[0].reqId];
      if (typeof callback === 'function') {
        delete tm.applyAnimationCbMap[res[0].reqId];
        animation_exparser.safeCallback('Animation', callback, null, []);
      }
      var args = JSON.parse(res[0].args);
      tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_SET_NODE_NEXT_ANIMATION_INFO, args]);
    }
  }, viewId);
  setDataListener(constants_SYNC_EVENT_NAME.CLEAR_ANIMATION_COMPLETE, res => {
    if (res && res[0] && res[0].reqId) {
      var callback = tm.clearAnimationCbMap[res[0].reqId];
      if (typeof callback === 'function') {
        delete tm.clearAnimationCbMap[res[0].reqId];
        animation_exparser.safeCallback('Clear Animation', callback, null, []);
      }
    }
  }, viewId);
};
;// CONCATENATED MODULE: ./src/comp_api/view_info.js



var requestViewInfo = (type, data, viewId, func) => {
  var reqId = `${Math.random()}-${+new Date()}`;
  var tm = TreeManager.get(viewId);
  if (!tm) return undefined;
  tm.operationFlow.push([SYNC_EVENT_NAME.FLOW_VIEW_INFO, type, data, reqId]);
  if (typeof func === 'function') {
    tm.viewInfoCbMap[reqId] = func;
  }
  return reqId;
};
var endViewInfoCallback = (viewId, reqId) => {
  var tm = TreeManager.get(viewId);
  if (!tm) return;
  delete tm.viewInfoCbMap[reqId];
};
var registerViewInfoListeners = function (viewId, tm) {
  setDataListener(constants_SYNC_EVENT_NAME.RESPONSE_VIEW_INFO, ([data, reqId]) => {
    if (reqId) {
      var cb = tm.viewInfoCbMap[reqId];
      if (cb) {
        cb(data);
      }
    }
  }, viewId);
};
;// CONCATENATED MODULE: ./src/comp_api/worklet_animation.js



var worklet_animation_exparser = getExparser();
var applyAnimatedStyle = function (exparserNode, tm, pageId, selector, callback, data) {
  var reqId = `${Math.random()}-${+new Date()}`;
  var hasCallback = typeof callback === 'function';
  if (hasCallback) tm.animatedStyleCbMap[reqId] = callback;
  tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_SET_NODE_ANIMATED_STYLE, {
    hasCallback,
    reqId,
    nodeId: tm.nodeId.getNodeId(exparserNode),
    pageId,
    selector,
    data
  }]);
};
var clearAnimatedStyle = function (exparserNode, tm, pageId, selector, renderer, styleIds, callback) {
  var reqId = `${Math.random()}-${+new Date()}`;
  var hasCallback = typeof callback === 'function';
  if (hasCallback) tm.animatedStyleCbMap[reqId] = callback;
  tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_CLEAR_NODE_ANIMATED_STYLE, {
    hasCallback,
    reqId,
    nodeId: tm.nodeId.getNodeId(exparserNode),
    pageId,
    selector,
    renderer,
    styleIds
  }]);
};
var registerAnimatedStyleListeners = function (viewId, tm) {
  setDataListener(constants_SYNC_EVENT_NAME.APPLY_NODE_ANIMATED_STYLE_END, res => {
    if (res && res[0] && res[0].reqId) {
      var styleId = res[0].styleId;
      var callback = tm.animatedStyleCbMap[res[0].reqId];
      if (typeof callback === 'function') {
        delete tm.animatedStyleCbMap[res[0].reqId];
        worklet_animation_exparser.safeCallback('AnimaedStyle', callback, null, [{
          styleId
        }]);
      }
    }
  }, viewId);
  setDataListener(constants_SYNC_EVENT_NAME.CLEAR_NODE_ANIMATED_STYLE_END, res => {
    if (res && res[0] && res[0].reqId) {
      var callback = tm.animatedStyleCbMap[res[0].reqId];
      if (typeof callback === 'function') {
        delete tm.animatedStyleCbMap[res[0].reqId];
        worklet_animation_exparser.safeCallback('Clear AnimaedStyle', callback, null, []);
      }
    }
  }, viewId);
};
;// CONCATENATED MODULE: ./src/comp_api/definition.js





























var definition_exparser = getExparser();

var MPFRNotifiers = {};
var onMainPageFrameReady = (pageId, func) => {
  if (MPFRNotifiers[pageId] === undefined) {
    MPFRNotifiers[pageId] = createPublishSubscribe(['ready']);
  }
  MPFRNotifiers[pageId].on('ready', func);
};
if (!isDataThread()) {
  var dispatch = pageId => {
    if (pageId === undefined && currentRenderBackend() === 'webview') {
      pageId = 0;
    }
    if (MPFRNotifiers[pageId] === undefined) {
      MPFRNotifiers[pageId] = createPublishSubscribe(['ready']);
    }
    var isReady = MPFRNotifiers[pageId].isNotified('ready');
    wxNativeConsole.info(`[mainPageFrameReady] dispatch __mainPageFrameReady__, current=${isReady}, pageId=${pageId}`);
    if (isReady) return;
    MPFRNotifiers[pageId].notify('ready');
  };
  var pageFrameInjected = typeof __wxAppCode__ !== 'undefined' && Object.keys(__wxAppCode__).length > 0;
  if (pageFrameInjected) dispatch();else window.__mainPageFrameReady__ = dispatch;
}
var dispatchViewRoute = (path, pageId) => {
  wx.traceBeginEvent('Framework', 'dispatchViewRoute');
  if (currentRenderBackend() !== 'webview' && !isLazyLoad()) {
    var pathComp = path.replace(/\.html$/, '').replace(/^\//, '');
    wx.traceBeginEvent('Framework', 'injectWxss');
    injectWxss(pathComp);
    wx.traceEndEvent();
    wx.traceBeginEvent('Framework', 'triggerGenerateFuncReady');
    triggerGenerateFuncReady(pathComp, pageId);
    wx.traceEndEvent();
  }
  wx.traceEndEvent();
};
var definition_deepCopy = definition_exparser.dataUtils.deepCopy;
var BEHAVIOR_OPTIONS = {
  lazyRegistration: true,
  publicProperties: true
};
var COMPONENT_OPTIONS = (/* unused pure expression or super */ null && ({
  domain: '/',
  writeOnly: false,
  allowInWriteOnly: false,
  lazyRegistration: true,
  classPrefix: '',
  templateEngine: Tmpl,
  renderingMode: 'full',
  multipleSlots: false,
  publicProperties: true,
  reflectToAttributes: false,
  writeFieldsToNode: false,
  writeIdToDOM: false,
  idPrefixGenerator: null,
  separateInnerData: true,
  innerDataExclude: null,
  randomizeTagName: false,
  virtualHost: false
}));
var COMPONENT_OPTIONS_VIEW = {
  domain: '/',
  writeOnly: false,
  allowInWriteOnly: false,
  lazyRegistration: true,
  classPrefix: '',
  renderingMode: 'full',
  templateEngine: tmpl_Tmpl,
  multipleSlots: false,
  publicProperties: true,
  reflectToAttributes: false,
  writeFieldsToNode: false,
  writeIdToDOM: true,
  idPrefixGenerator: null,
  separateInnerData: false,
  innerDataExclude: null,
  randomizeTagName: false,
  virtualHost: false
};
var callerExparserNodeMap = typeof WeakMap !== 'undefined' ? new WeakMap() : {};
var extractedComponentDef = {};
var extractedBehaviorDef = {};
var extractedUsing = {};
var extractedGenerics = {};
var extractedBehaviorImports = {};
var extractedPlaceholder = {};
var behaviorIdInc = 1;
var definition_hasOwnProperty = Object.prototype.hasOwnProperty;
var regExpFromString = s => {
  if (!s) return null;
  var splitPos = s.lastIndexOf('/');
  var body = s.slice(1, splitPos);
  var modifiers = s.slice(splitPos + 1);
  return new RegExp(body, modifiers);
};
var CUSTOM_COMPONENT_PREFIX = 'wx-';
var getUsingByPath = (path, codeMap) => {
  var pageConfig = codeMap[path + '.json'] || {};
  var ret = {};
  var usingDef = pageConfig.usingComponents || {};
  for (var k of Object.keys(usingDef)) ret[CUSTOM_COMPONENT_PREFIX + k] = utils_pathRelative(path, String(usingDef[k]));
  return ret;
};
var processRelationPaths = (path, relations) => {
  var newRelations = {};
  for (var k in relations) {
    var relation = {
      ...relations[k]
    };
    relation.target = relation.target != null ? String(relation.target) : pathRelative(path, String(k));
    newRelations[k] = relation;
  }
  return newRelations;
};
var getGenericsByPath = (path, codeMap) => {
  var pageConfig = codeMap[path + '.json'] || {};
  var ret = {};
  var genericsDef = pageConfig.componentGenerics || {};
  for (var k of Object.keys(genericsDef)) {
    var genericConfig = genericsDef[k];
    if (typeof genericConfig === 'object') {
      ret[CUSTOM_COMPONENT_PREFIX + k] = {
        default: utils_pathRelative(path, String(genericConfig.default || ''))
      };
    } else if (genericConfig != null) {
      ret[CUSTOM_COMPONENT_PREFIX + k] = {};
    }
  }
  return ret;
};
var getPlaceholderByPath = (path, codeMap) => {
  var pageConfig = codeMap[path + '.json'] || {};
  var ret = {};
  var placeholderDef = pageConfig.componentPlaceholder || {};
  Object.keys(placeholderDef).forEach(k => {
    ret[CUSTOM_COMPONENT_PREFIX + k] = CUSTOM_COMPONENT_PREFIX + String(placeholderDef[k]);
  });
  return ret;
};
var getRendererByPath = (path, codeMap) => {
  var pageConfig = codeMap[path + '.json'] || {};
  return pageConfig.renderer;
};
var getXrFrameTouchEventBubbleByPath = (path, codeMap) => {
  var pageConfig = codeMap[path + '.json'] || {};
  return pageConfig.xrFrameTouchEventBubble;
};
var setModelValueData = (data, modelValueName, webviewId, nodeId) => {
  var tm = tree_manager.get(webviewId);
  var node = tm.nodeId.getNodeById(nodeId, webviewId);
  if (node && modelValueName) {
    definition_exparser.Element.getMethodCaller(node).setData({
      [modelValueName]: data
    });
  }
};
var isLazyLoad = () => __wxConfig.isLazyLoad;
var compPathToAlias = comp => {
  var pluginPrefix = '__plugin__/';
  var index = comp.indexOf(pluginPrefix);
  if (index === -1) return comp;
  return 'plugin-private://' + comp.slice(index + pluginPrefix.length);
};
var pluginAliasToPath = comp => {
  if (comp.indexOf('plugin://') === -1) return comp;
  var pluginAlias = comp.match(/\w+\//);
  if (!pluginAlias) return comp;
  pluginAlias = pluginAlias[0].slice(0, pluginAlias[0].length - 1);
  var provider = getPluginProviderByAlias(pluginAlias);
  if (!provider) return comp;
  var ret = comp.replace(pluginAlias, provider);
  if (domain_componentAliases[ret]) {
    return domain_componentAliases[ret];
  }
  return ret;
};
var triggerGenerateFuncReady = (_comp, pageId) => {
  var comp = compPathToAlias(_comp);
  wxNativeConsole.info(`[triggerGenerateFuncReady] dispatch generateFuncReady from vd, comp=${comp}`);
  var codeMap = typeof __wxAppCode__ !== 'undefined' ? __wxAppCode__ : {};
  var func = codeMap[comp + '.wxml'];
  if (Array.isArray(func)) func = func[0][func[1]];
  if (window.__wxAppCodeReadyCallback__) {
    window.__wxAppCodeReadyCallback__(func);
  } else {
    window.document.dispatchEvent(new CustomEvent('generateFuncReady', {
      detail: {
        generateFunc: func,
        pageId
      }
    }));
  }
};
var injectWxss = _comp => {
  var renderer = currentRenderBackend();
  if (renderer !== 'webview') {
    wxNativeConsole.info(`[injectWxss] current renderer is ${renderer}, handle root wxss by priority`);
    return;
  }
  var comp = compPathToAlias(_comp);
  wxNativeConsole.info(`[injectWxss] inject page wxss from vd, comp=${comp}`);
  var codeMap = typeof __wxAppCode__ !== 'undefined' ? __wxAppCode__ : {};
  var wxss = codeMap[comp + '.wxss'];
  if (wxss === undefined || typeof wxss !== 'function') {
    wxNativeConsole.warn(`codeMap does not contain valid wxss ${comp + '.wxss'}`);
    wxss = () => {};
  }
  window.__setCssStartTime__ = Date.now();
  wxss();
  window.__setCssEndTime__ = Date.now();
};
var doDataThreadReplacePlaceholder = (tm, rootCompName, replacement, loadId) => {
  xr_options_publishXrCustomOptions(tm.viewId);
  var usedDef = [[], [], rootCompName, domain_componentAliases];
  recurseUsedComponents(usedDef, rootCompName, Object.create(null), '', tm);
  var usedBehaviors = new Set(tm.usedDef[0].map(def => def.is));
  var usedComponents = new Set(tm.usedDef[0].map(def => def.is));
  var newUsedBehaviors = [];
  var newUsedComponents = [];
  usedDef[0].forEach(def => {
    if (!usedBehaviors.has(def.is)) {
      newUsedBehaviors.push(def);
      usedBehaviors.add(def.is);
    }
  });
  usedDef[1].forEach(def => {
    if (!usedComponents.has(def.is)) {
      newUsedComponents.push(def);
      usedComponents.add(def.is);
    }
  });
  usedDef[0] = newUsedBehaviors;
  usedDef[1] = newUsedComponents;
  tm.usedDef[0].push(...usedDef[0]);
  tm.usedDef[1].push(...usedDef[1]);
  tm.operationFlow.sendInIndividualFlow([constants_SYNC_EVENT_NAME.FLOW_COMPONENT_DEF_ADD, loadId, usedDef]);
  tm.operationFlow.sendInIndividualFlow([constants_SYNC_EVENT_NAME.FLOW_WAIT_COMPONENT, loadId]);
  tm.operationFlow.start(Date.now());
  tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_REPLACE_PLACEHOLDER, loadId]);
  replacement.replacers.forEach(replacer => {
    replacer();
  });
  tm.operationFlow.end();
};
var getOwnerPluginAppId = comp => {
  var exparserNode = definition_getExparserNode(comp);
  if (!exparserNode) return '';
  return getExparserNodePluginId(exparserNode);
};
var processPluginPageGenerics = pageName => {
  var privatePath = route_utils_convertRouteToComponentAlias(pageName);
  var alias = componentPathToAlias[privatePath];
  if (!alias) return {};
  var aliasInfo = alias.match(/^plugin:\/\/(wx[0-9a-f]{16})\/(.+)$/);
  if (!aliasInfo) return {};
  var pluginId = aliasInfo[1];
  var pageAlias = aliasInfo[2];
  var pluginConfig = utils_objectValues(__wxConfig.plugins).find(p => p.provider === pluginId);
  if (!pluginConfig) return {};
  if (!pluginConfig.genericsImplementation) return {};
  var genericsImpl = pluginConfig.genericsImplementation[pageAlias] || {};
  var ret = {};
  var subPackagePath = getPluginSubPackagePrefix(pluginId);
  Object.keys(genericsImpl).forEach(tag => {
    ret[CUSTOM_COMPONENT_PREFIX + tag] = utils_pathRelative(subPackagePath, String(genericsImpl[tag]));
  });
  return ret;
};
var checkBehaviorExistence = behaviors => {
  if (!behaviors) return false;
  if (behaviors instanceof Array) {
    for (var i = 0; i < behaviors.length; i++) {
      var compName = String(behaviors[i]);
      if (compName.slice(0, 5) === 'wx://') continue;
      if (!extractedBehaviorDef[compName]) {
        console.warn('"behaviors" list contains non-behavior items. The whole list is ignored.');
        return false;
      }
    }
    return true;
  }
  return false;
};
var recurseUsedBehaviors = (ret, compName, compFounded) => {
  if (compName.slice(0, 5) === 'wx://') return;
  var def = extractedBehaviorDef[compName];
  if (!def) throw new Error('"' + compName + '" is not a behavior registered by Behavior()');
  ret[0].unshift(def);
  compFounded[compName] = true;
  var behKeys = extractedBehaviorImports[def.is];
  if (behKeys) {
    for (var i = 0; i < behKeys.length; i++) {
      var beh = behKeys[i];
      if (!compFounded[beh]) recurseUsedBehaviors(ret, beh, compFounded);
    }
  }
};
var recurseUsedComponents = (ret, compName, compFounded, usingBy, tm, allowPlaceholder = false) => {
  if (definition_hasOwnProperty.call(domain_componentAliases, compName)) compName = domain_componentAliases[compName];
  var def = extractedComponentDef[compName];
  if (tm.compManager.shouldUsePlaceholder(compName) && allowPlaceholder) return;else if (!def) {
    console.error(`Component is not found in path "${compName}"${usingBy ? ` (using by "${usingBy}")` : ''}`);
    return;
  }
  var placeholder = extractedPlaceholder[compName];
  if (compName.slice(0, 5) !== 'wx://') ret[1].unshift(def);
  compFounded[compName] = true;
  var using = extractedUsing[def.is];
  var generics = extractedGenerics[def.is];
  for (var k of Object.keys(using || {})) {
    var comp = using[k];
    if (!compFounded[comp]) {
      recurseUsedComponents(ret, comp, compFounded, compName, tm, !!placeholder[k]);
    }
  }
  for (var _k of Object.keys(generics || {})) {
    var _comp2 = generics[_k].default;
    if (!_comp2) continue;
    if (!compFounded[_comp2]) {
      recurseUsedComponents(ret, _comp2, compFounded, compName, tm, !!placeholder[_k]);
    }
  }
  var behKeys = extractedBehaviorImports[def.is];
  if (behKeys) {
    for (var i = 0; i < behKeys.length; i++) {
      var beh = behKeys[i];
      if (!compFounded[beh]) recurseUsedBehaviors(ret, beh, compFounded);
    }
  }
};
var extractCompDef = (def, tmplPath) => {
  var props = {};
  for (var k in def.properties) {
    var prop = def.properties[k];
    if (prop === null) {
      props[k] = {
        type: null
      };
    } else if (prop === Number || prop === String || prop === Boolean || prop === Object || prop === Array) {
      props[k] = {
        type: prop.name
      };
    } else if (prop.public === undefined || prop.public) {
      var ty = prop.type;
      var typeName = null;
      if (ty === Number || ty === String || ty === Boolean || ty === Object || ty === Array) {
        typeName = ty.name;
      }
      var optionalTypes = undefined;
      if (prop.optionalTypes) {
        optionalTypes = [];
        for (var i = 0; i < prop.optionalTypes.length; i += 1) {
          var _ty = prop.optionalTypes[i];
          if (_ty === Number || _ty === String || _ty === Boolean || _ty === Object || _ty === Array) {
            optionalTypes.push(_ty.name);
          }
        }
      }
      props[k] = {
        type: typeName,
        optionalTypes,
        value: prop.value
      };
    }
  }
  var innerDataExclude = def.options.innerDataExclude;
  return {
    is: def.is,
    using: def.using,
    generics: def.generics,
    placeholder: def.placeholder,
    behaviors: def.behaviors,
    data: def.data,
    properties: props,
    externalClasses: def.externalClasses,
    template: tmplPath,
    options: {
      domain: def.options.domain,
      writeOnly: def.options.writeOnly || undefined,
      multipleSlots: def.options.multipleSlots || undefined,
      writeIdToDOM: def.options.writeIdToDOM || undefined,
      styleIsolation: def.options.styleIsolation || undefined,
      addGlobalClass: def.options.addGlobalClass || undefined,
      hasObservers: !!def.observers,
      innerDataExcludeString: innerDataExclude ? innerDataExclude.toString() : null,
      virtualHost: def.options.virtualHost || undefined
    }
  };
};
var filterBehaviors = function (def) {
  if (!def.behaviors) {
    def.behaviors = null;
  } else {
    var behaviors = [];
    for (var j = 0; j < def.behaviors.length; j++) {
      var behaviorName = String(def.behaviors[j]);
      if (behaviorName[0] !== '/' && behaviorName.slice(0, 5) !== 'wx://') throw new Error('Behaviors should be constructed with Behavior()');
      behaviors.push(behaviorName);
    }
    def.behaviors = behaviors;
    extractedBehaviorImports[def.is] = behaviors;
  }
};
var Behavior = function (def) {
  var is = '/' + behaviorIdInc++ + '/' + guid();
  var behDef = {};
  for (var k in def) {
    if (k === 'data') behDef[k] = definition_deepCopy(def[k]);else behDef[k] = def[k];
  }
  behDef.is = is;
  filterBehaviors(behDef);
  behDef.options = BEHAVIOR_OPTIONS;
  checkPropertyFilterUsage(behDef);
  extractedBehaviorDef[is] = extractCompDef(behDef);
  behDef.definitionFilter = definition_exparser.Behavior.callDefinitionFilter(behDef);
  definition_exparser.registerBehavior(behDef);
  return behDef.is;
};
var getExparserNodePluginId = node => definition_exparser.Component.getComponentOptions(node).domain.split('/', 1)[0];
var definition_getExparserNode = caller => callerExparserNodeMap.get(caller);
var getSelectComponentResult = (hostDomain, selected, caller) => {
  var selectedDomain = definition_exparser.Component.getComponentOptions(selected).domain;
  var selectedFilter = definition_exparser.Component.getMethod(selected, '__export__');
  var defaultResult = selectedDomain === hostDomain ? definition_exparser.Element.getMethodCaller(selected) : null;
  if (selectedFilter) {
    var arg = selectedDomain === hostDomain ? caller : null;
    var res = selectedFilter.call(definition_exparser.Element.getMethodCaller(selected), arg);
    return res === undefined ? defaultResult : res;
  }
  return defaultResult;
};
var selectOwnerComponent = caller => {
  var node = definition_getExparserNode(caller);
  var selfDomain = definition_exparser.Component.getComponentOptions(node).domain;
  var ownerShadowRoot = node.ownerShadowRoot;
  if (!(ownerShadowRoot instanceof definition_exparser.ShadowRoot)) return null;
  var selected = ownerShadowRoot.getHostNode();
  if (!selected) return null;
  return getSelectComponentResult(selfDomain, selected, caller);
};
var selectComponent = (caller, selector, multi) => {
  var host = definition_getExparserNode(caller);
  var hostDomain = definition_exparser.Component.getComponentOptions(host).domain;
  var node = host.shadowRoot;
  if (multi) {
    var _selected = node.querySelectorAll(selector);
    return _selected.map(n => getSelectComponentResult(hostDomain, n, caller));
  }
  var selected = node.querySelector(selector);
  if (!selected) return null;
  return getSelectComponentResult(hostDomain, selected, caller);
};
var getPageRootComponent = exparserNode => {
  var node = exparserNode;
  for (;;) {
    var ownerShadowRoot = node.ownerShadowRoot;
    if (!ownerShadowRoot) break;
    if (!(ownerShadowRoot instanceof definition_exparser.ShadowRoot)) return null;
    var selected = ownerShadowRoot.getHostNode();
    if (!selected) return null;
    node = selected;
  }
  return node;
};
var getPageRootComponentWithDomainMatching = caller => {
  var node = definition_getExparserNode(caller);
  var selfDomain = definition_exparser.Component.getComponentOptions(node).domain;
  for (;;) {
    var ownerShadowRoot = node.ownerShadowRoot;
    if (!ownerShadowRoot) break;
    if (!(ownerShadowRoot instanceof definition_exparser.ShadowRoot)) return null;
    var selected = ownerShadowRoot.getHostNode();
    if (!selected) return null;
    var selectedDomain = definition_exparser.Component.getComponentOptions(selected).domain;
    if (selectedDomain !== selfDomain) return null;
    node = selected;
  }
  return node;
};
var getRelationNodes = (caller, relationKey) => {
  var node = definition_getExparserNode(caller);
  var res = node.getRelationNodes(relationKey);
  if (res === null) return null;
  return res.map(n => definition_exparser.Element.getMethodCaller(n));
};
var writeComponentInstanceField = (obj, name, value) => {
  if (obj === ComponentPrototype) return;
  Object.defineProperty(obj, name, {
    value,
    writable: true,
    enumerable: true,
    configurable: true
  });
};
function CustomComponent() {}
var ComponentPrototype = CustomComponent.prototype = Object.create(Object.prototype, {
  is: {
    get() {
      return definition_getExparserNode(this).is;
    },
    set(val) {
      writeComponentInstanceField(this, 'is', val);
    }
  },
  id: {
    get() {
      var node = definition_getExparserNode(this);
      if (definition_exparser.Component.getComponentOptions(node).writeOnly) return '';
      return node.id;
    },
    set(val) {
      writeComponentInstanceField(this, 'id', val);
    }
  },
  getPageId: {
    get() {
      return function () {
        var exparserNode = definition_getExparserNode(this);
        var tm = exparserNode.__treeManager__;
        return 'pageId:' + tm.viewId;
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'getPageId', val);
    }
  },
  router: {
    get() {
      return definition_getExparserNode(this).__pageRouter__;
    },
    set(val) {
      writeComponentInstanceField(this, 'router', val);
    }
  },
  pageRouter: {
    get() {
      var pageRoot = getPageRootComponentWithDomainMatching(this);
      return pageRoot.__pageRouter__;
    },
    set(val) {
      writeComponentInstanceField(this, 'pageRouter', val);
    }
  },
  renderer: {
    get() {
      var exparserNode = definition_getExparserNode(this);
      var tm = exparserNode.__treeManager__;
      return bridge_getPageType(tm.viewId);
    },
    set(val) {
      writeComponentInstanceField(this, 'renderer', val);
    }
  },
  dataset: {
    get() {
      var node = definition_getExparserNode(this);
      if (definition_exparser.Component.getComponentOptions(node).writeOnly) return null;
      return node.dataset;
    },
    set(val) {
      writeComponentInstanceField(this, 'dataset', val);
    }
  },
  properties: {
    get() {
      return this.__data__;
    },
    set(val) {
      writeComponentInstanceField(this, 'properties', val);
    }
  },
  data: {
    get() {
      return this.__data__;
    },
    set(val) {
      writeComponentInstanceField(this, 'data', val);
    }
  },
  setData: {
    get() {
      return __appServiceSDK__.useTracedApiEnd(function (newData, callback) {
        var exparserNode = definition_getExparserNode(this);
        var tm = exparserNode.__treeManager__;
        __appServiceSDK__.traceBeginAPI('setData', {
          is: this.is,
          viewId: tm.viewId
        });
        if (typeof callback === 'function') {
          tm.operationFlow.registerSetDataCallback(callback, this, exparserNode);
        }
        return exparserNode.setData(newData);
      });
    },
    set(val) {
      writeComponentInstanceField(this, 'setData', val);
    }
  },
  groupSetData: {
    get() {
      return function (func) {
        var exparserNode = definition_getExparserNode(this);
        var tm = exparserNode.__treeManager__;
        tm.operationFlow.start(Date.now());
        tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_GROUP]);
        var err = null;
        try {
          func.call(this);
        } catch (e) {
          err = e;
        }
        tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_GROUP_END]);
        tm.operationFlow.end();
        if (err) throw err;
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'setData', val);
    }
  },
  replaceDataOnPath: {
    get() {
      return (path, newData) => definition_getExparserNode(this).replaceDataOnPath(path, newData);
    },
    set(val) {
      writeComponentInstanceField(this, 'replaceDataOnPath', val);
    }
  },
  mergeDataOnPath: {
    get() {
      return (path, newData) => definition_getExparserNode(this).mergeDataOnPath(path, newData);
    },
    set(val) {
      writeComponentInstanceField(this, 'mergeDataOnPath', val);
    }
  },
  applyDataUpdates: {
    get() {
      return () => definition_getExparserNode(this).applyDataUpdates();
    },
    set(val) {
      writeComponentInstanceField(this, 'applyDataUpdates', val);
    }
  },
  hasBehavior: {
    get() {
      return behavior => definition_getExparserNode(this).hasBehavior(behavior);
    },
    set(val) {
      writeComponentInstanceField(this, 'hasBehavior', val);
    }
  },
  triggerEvent: {
    get() {
      return (name, detail, options) => definition_getExparserNode(this).triggerEvent(name, detail, options);
    },
    set(val) {
      writeComponentInstanceField(this, 'triggerEvent', val);
    }
  },
  createSelectorQuery: {
    get() {
      return () => __appServiceSDK__._createSelectorQuery({}, getExparserNodePluginId(definition_getExparserNode(this))).in(this);
    },
    set(val) {
      writeComponentInstanceField(this, 'createSelectorQuery', val);
    }
  },
  createIntersectionObserver: {
    get() {
      return options => __appServiceSDK__._createIntersectionObserver(this, options, getExparserNodePluginId(definition_getExparserNode(this)));
    },
    set(val) {
      writeComponentInstanceField(this, 'createIntersectionObserver', val);
    }
  },
  createMediaQueryObserver: {
    get() {
      return options => __appServiceSDK__._createMediaQueryObserver(this, options, getExparserNodePluginId(definition_getExparserNode(this)));
    },
    set(val) {
      writeComponentInstanceField(this, 'createMediaQueryObserver', val);
    }
  },
  getOpenerEventChannel: {
    get() {
      return () => __appServiceSDK__._getPageOpenerEventChannel(this);
    },
    set(val) {
      writeComponentInstanceField(this, 'getOpenerEventChannel', val);
    }
  },
  applyAnimation: {
    get() {
      return (selector, options, animeJS, callback, isLastAnimation) => {
        var exparserNode = definition_getExparserNode(this);
        var tm = exparserNode.__treeManager__;
        applyAnimation(exparserNode, tm, this.__wxWebviewId__, selector, options, animeJS, callback, isLastAnimation);
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'applyAnimation', val);
    }
  },
  clearAnimation: {
    get() {
      return (selector, options, callback) => {
        var exparserNode = definition_getExparserNode(this);
        var tm = exparserNode.__treeManager__;
        clearAnimation(exparserNode, tm, this.__wxWebviewId__, selector, options, callback);
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'clearAnimation', val);
    }
  },
  animate: {
    get() {
      return (selector, options, duration, timeline, callback) => {
        if (typeof timeline === 'function') {
          callback = timeline;
        } else if (typeof timeline !== 'undefined') {
          var exparserNode = definition_getExparserNode(this);
          var tm = exparserNode.__treeManager__;
          tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_SET_NODE_ANIMATION_INFO, {
            type: 'scrollTimeline',
            nodeId: tm.nodeId.getNodeId(exparserNode),
            selector,
            options,
            duration,
            timeline
          }]);
          return;
        }
        var _options = animationOptionHandler(options, duration);
        for (var i = 0; i < _options.length; ++i) {
          var shouldTriggerWithAnimeJS = _options[i].type === 'animeJS';
          delete _options[i].type;
          if (i === _options.length - 1) {
            this.applyAnimation(selector, _options[i], shouldTriggerWithAnimeJS, callback, true);
          } else {
            this.applyAnimation(selector, _options[i], shouldTriggerWithAnimeJS);
          }
        }
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'animate', val);
    }
  },
  applyAnimatedStyle: {
    get() {
      return (selector, updater, userConfig, callback) => {
        var exparserNode = definition_getExparserNode(this);
        var tm = exparserNode.__treeManager__;
        var pageId = tm.viewId;
        var renderer = this.renderer;
        var {
          registerJsValue,
          createAnimatedStyleForWeb,
          checkWorkletFunc
        } = __appServiceSDK__.workletSDK;
        if (!checkWorkletFunc(updater)) {
          console.warn('The updater parameter of applyAnimatedStyle should be a worklet function');
        }
        if (renderer === 'skyline') {
          applyAnimatedStyle(exparserNode, tm, pageId, selector, callback, {
            renderer,
            styleInfo: {
              userConfig,
              updaterId: registerJsValue(updater)
            }
          });
        } else if (renderer === 'webview') {
          var mapperId = undefined;
          var styleChangeHandler = updateStyle => {
            applyAnimatedStyle(exparserNode, tm, pageId, selector, undefined, {
              renderer,
              styleInfo: {
                shouldAttach: false,
                mapperId,
                updateStyle
              }
            });
          };
          var animatedStyle = createAnimatedStyleForWeb(updater, userConfig, styleChangeHandler);
          mapperId = animatedStyle.mapperId;
          applyAnimatedStyle(exparserNode, tm, pageId, selector, callback, {
            renderer,
            styleInfo: {
              shouldAttach: true,
              mapperId: animatedStyle.mapperId,
              updateStyle: animatedStyle.initialStyle
            }
          });
        }
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'applyAnimatedStyle', val);
    }
  },
  clearAnimatedStyle: {
    get() {
      return (selector, styleIds, callback) => {
        var exparserNode = definition_getExparserNode(this);
        var tm = exparserNode.__treeManager__;
        var pageId = tm.viewId;
        var renderer = this.renderer;
        clearAnimatedStyle(exparserNode, tm, pageId, selector, renderer, styleIds, callback);
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'clearAnimatedStyle', val);
    }
  },
  selectOwnerComponent: {
    get() {
      return selector => {
        var node = definition_getExparserNode(this);
        if (definition_exparser.Component.getComponentOptions(node).writeOnly) return null;
        return selectOwnerComponent(this, selector);
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'selectOwnerComponent', val);
    }
  },
  selectComponent: {
    get() {
      return selector => {
        var node = definition_getExparserNode(this);
        if (definition_exparser.Component.getComponentOptions(node).writeOnly) return null;
        return selectComponent(this, selector, false);
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'selectComponent', val);
    }
  },
  selectAllComponents: {
    get() {
      return selector => {
        var node = definition_getExparserNode(this);
        if (definition_exparser.Component.getComponentOptions(node).writeOnly) return [];
        return selectComponent(this, selector, true);
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'selectAllComponents', val);
    }
  },
  getRelationNodes: {
    get() {
      return relationKey => getRelationNodes(this, relationKey);
    },
    set(val) {
      writeComponentInstanceField(this, 'getRelationNodes', val);
    }
  },
  getTabBar: {
    get() {
      return function (asyncCb) {
        var exparserNode = definition_getExparserNode(this);
        var tm = exparserNode.__treeManager__;
        if (typeof asyncCb === 'function') {
          if (!tm.tabRoot) {
            dataThreadTabbarCreated(tm.viewId).then(() => {
              if (tm.tabDestroyed || !tm.tabRoot) return;
              asyncCb(definition_exparser.Element.getMethodCaller(tm.tabRoot));
            });
            return null;
          }
          asyncCb(definition_exparser.Element.getMethodCaller(tm.tabRoot));
          return definition_exparser.Element.getMethodCaller(tm.tabRoot);
        } else {
          if (tm.tabDestroyed || !tm.tabRoot) return null;
          return definition_exparser.Element.getMethodCaller(tm.tabRoot);
        }
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'getTabBar', val);
    }
  },
  exitState: {
    get() {
      return this.__exitState__;
    },
    set(val) {
      writeComponentInstanceField(this, 'exitState', val);
    }
  },
  setInitialRenderingCache: {
    get() {
      return function (dynamicData) {
        var exparserNode = definition_getExparserNode(this);
        var tm = exparserNode.__treeManager__;
        if (dynamicData === null) {
          clearInitialRenderingCache(tm);
        } else {
          generateInitialRenderingCache(tm, dynamicData);
        }
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'exitState', val);
    }
  },
  setUpdatePerformanceListener: {
    get() {
      return function (config, cb) {
        var exparserNode = definition_getExparserNode(this);
        var tm = exparserNode.__treeManager__;
        var nodeId = tm.nodeId.getNodeId(exparserNode);
        if (typeof cb === 'function') {
          exparserNode.__updatePerformanceListener__ = cb;
          tm.operationFlow.push([constants_SYNC_EVENT_NAME.ENABLE_UPDATE_PERFORMANCE_STAT, nodeId, config]);
        } else {
          exparserNode.__updatePerformanceListener__ = null;
          tm.operationFlow.push([constants_SYNC_EVENT_NAME.DISABLE_UPDATE_PERFORMANCE_STAT, nodeId]);
        }
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'exitState', val);
    }
  },
  getPassiveEvent: {
    get() {
      return function (cb) {
        wx.getPassiveEvent(this.__wxWebviewId__, cb);
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'exitState', val);
    }
  },
  setPassiveEvent: {
    get() {
      return function (config) {
        wx.setPassiveEvent(this.__wxWebviewId__, config);
      };
    },
    set(val) {
      writeComponentInstanceField(this, 'exitState', val);
    }
  }
});
var mergeJsonConfig = function (def, codeMap, is) {
  var pageConfig = codeMap[is + '.json'] || {};
  if (pageConfig.styleIsolation !== undefined) {
    if (!def.options) def.options = {};
    def.options.styleIsolation = pageConfig.styleIsolation;
  }
  if (pageConfig.pureDataPattern !== undefined) {
    if (!def.options) def.options = {};
    def.options.pureDataPattern = new RegExp(pageConfig.pureDataPattern);
  }
};
var registerSimpleComponent = function (def, is, json, domain, codeMap) {
  mergeJsonConfig(def, codeMap, is);
  var compDef = {
    is,
    using: getUsingByPath(is, codeMap),
    properties: def.properties,
    externalClasses: def.externalClasses,
    options: COMPONENT_OPTIONS
  };
  var userOptions = def.options || {};
  compDef.options = COMPONENT_OPTIONS;
  compDef.options.multipleSlots = userOptions.multipleSlots || false;
  compDef.options.writeOnly = true;
  compDef.options.writeIdToDOM = false;
  compDef.options.domain = 'simple://' + (domain || '/');
  compDef.options.styleIsolation = userOptions.styleIsolation || '';
  compDef.options.addGlobalClass = userOptions.addGlobalClass || false;
  compDef.options.innerDataExclude = null;
  compDef.options.virtualHost = false;
  extractedComponentDef[is] = extractCompDef(compDef, is + '.wxml');
  return compDef.is;
};
var resetComponent = is => {
  var def = extractedComponentDef[is];
  TreeManager.list().forEach(tm => {
    sendData(SYNC_EVENT_NAME.UPDATE_COMPONENT_DEF, [def], tm.viewId);
    [tm.root, tm.tabRoot].forEach(root => {
      if (!root) return;
      dfsComponents(root, 1, elem => {
        if (elem instanceof definition_exparser.Component && elem.is === is) {
          var isPageRoot = elem === tm.root;
          if (isPageRoot && tm.lifetimeListener) tm.lifetimeListener.call(tm.root, 'onUnload');
          resetComponentNode(elem, tm);
          if (isPageRoot && tm.lifetimeListener) {
            tm.lifetimeListener.call(tm.root, 'onLoad');
            tm.lifetimeListener.call(tm.root, 'onShow');
          }
        }
      });
    });
  });
};
var registerByDef = function (def, codeMap) {
  def.using = extractedUsing[def.is] = getUsingByPath(def.is, codeMap);
  def.generics = extractedGenerics[def.is] = getGenericsByPath(def.is, codeMap);
  def.placeholder = extractedPlaceholder[def.is] = getPlaceholderByPath(def.is, codeMap);
  setXrCustomOption(def.is, {
    isXrComp: getRendererByPath(def.is, codeMap) === 'xr-frame',
    xrFrameTouchEventBubble: getXrFrameTouchEventBubbleByPath(def.is, codeMap)
  });
  filterBehaviors(def);
  var wxmlPath = def.is + '.wxml';
  var template = {
    path: wxmlPath,
    func: updatedWxAppCode[wxmlPath] || codeMap[wxmlPath] || null
  };
  def.template = template;
  if (def.template.func === null) {
    wxNativeConsole.warn(`[componentRegistration] Generate function of ${def.is} not found in data thread`);
  }
  extractedComponentDef[def.is] = extractCompDef(def, wxmlPath);
  var compDef = definition_exparser.registerElement(def);
  var ret = Object.create(ComponentPrototype, {
    constructor: {
      value: CustomComponent,
      writable: true,
      configurable: true
    }
  });
  definition_exparser.Behavior.prepare(compDef.behavior);
  var defMethods = compDef.behavior.methods;
  for (var k in defMethods) {
    ret[k] = defMethods[k];
  }
  var updater = func => {
    func();
    resetComponent(def.is);
  };
  addUpdateListener(def.is + '.js', updater);
  return ret;
};
var Component = function (def, domain, wxAppCode, wxAppCurrentFile) {
  var filePath = wxAppCurrentFile || __wxAppCurrentFile__;
  var codeMap = wxAppCode || __wxAppCode__;
  var json = codeMap[filePath + 'on'];
  if (!filePath || !json) {
    console.error('Component constructors should be called while initialization. A constructor call has been ignored.');
    return '';
  }
  checkPropertyFilterUsage(def);
  var is = filePath.slice(0, -3);
  if (json.component && json.component.type === 'simple') {
    registerSimpleComponent(def, is, json, domain, codeMap);
    return is;
  }
  mergeJsonConfig(def, codeMap, is);
  trimAndRegisterWorkletFactories(is, def.methods);
  var definitionFilter = definition_exparser.Behavior.callDefinitionFilter(def);
  var compDef = {
    is,
    properties: def.properties,
    data: definition_deepCopy(def.data),
    methods: def.methods,
    behaviors: def.behaviors,
    lifetimes: def.lifetimes,
    pageLifetimes: def.pageLifetimes,
    created: def.created,
    attached: def.attached,
    ready: def.ready,
    moved: def.moved,
    detached: def.detached,
    saved: def.saved,
    restored: def.restored,
    relations: def.relations ? processRelationPaths(filePath, def.relations) : undefined,
    externalClasses: def.externalClasses,
    observers: def.observers,
    definitionFilter,
    options: COMPONENT_OPTIONS,
    initiator() {
      this.__customConstructor__ = Component;
      this.__pageRouter__ = __appServiceSDK__.createRouter(is, this.__treeManager__.viewId);
      var compCaller = Object.create(compCallerProto);
      callerExparserNodeMap.set(compCaller, this);
      definition_exparser.Element.setMethodCaller(this, compCaller);
      Object.defineProperties(compCaller, {
        __data__: {
          value: this.data,
          writable: true,
          enumerable: false
        },
        __wxWebviewId__: {
          value: this.__treeManager__.viewId,
          writable: true,
          enumerable: false
        }
      });
    }
  };
  var userOptions = def.options || {};
  compDef.options = COMPONENT_OPTIONS;
  compDef.options.multipleSlots = userOptions.multipleSlots || false;
  compDef.options.writeOnly = userOptions.writeOnly || false;
  compDef.options.writeIdToDOM = false;
  compDef.options.domain = (userOptions.writeOnly ? 'wo://' : '') + (domain || '/');
  compDef.options.styleIsolation = userOptions.styleIsolation || '';
  compDef.options.addGlobalClass = userOptions.addGlobalClass || false;
  compDef.options.innerDataExclude = userOptions.pureDataPattern || null;
  compDef.options.virtualHost = userOptions.virtualHost || false;
  var compCallerProto = registerByDef(compDef, codeMap, Component);
  return compDef.is;
};
var Page = function (def, domain, wxAppCode, wxAppCurrentFile) {
  var filePath = wxAppCurrentFile || __wxAppCurrentFile__;
  if (!filePath) {
    console.error('Page constructors should be called while initialization. A constructor call has been ignored.');
    return '';
  }
  var codeMap = wxAppCode || (typeof __wxAppCode__ !== 'undefined' ? __wxAppCode__ || {} : {});
  var customFields = Object.create(null);
  var compDefToFilter = {
    methods: {}
  };
  for (var k in def) {
    if (k === 'data') {
      compDefToFilter.data = def.data;
    } else if (typeof def[k] === 'function') {
      compDefToFilter.methods[k] = def[k];
    } else if (k === 'methods') {
      customFields.methods = def.methods;
    } else {
      compDefToFilter[k] = def[k];
    }
  }
  var hasBehaviors = checkBehaviorExistence(compDefToFilter.behaviors);
  var is = filePath.slice(0, -3);
  mergeJsonConfig(compDefToFilter, codeMap, is);
  if (hasBehaviors) definition_exparser.Behavior.callDefinitionFilter(compDefToFilter);
  for (var _k2 of Object.keys(compDefToFilter)) {
    if (_k2 === 'data' || _k2 === 'methods') continue;
    customFields[_k2] = compDefToFilter[_k2];
  }
  trimAndRegisterWorkletFactories(is, compDefToFilter.methods);
  checkPropertyFilterUsage(def);
  var compDef = {
    is,
    behaviors: hasBehaviors ? compDefToFilter.behaviors : undefined,
    data: definition_deepCopy(compDefToFilter.data),
    methods: compDefToFilter.methods,
    properties: typeof def.properties === 'undefined' ? compDefToFilter.properties : undefined,
    lifetimes: typeof def.lifetimes === 'undefined' ? compDefToFilter.lifetimes : undefined,
    pageLifetimes: typeof def.pageLifetimes === 'undefined' ? compDefToFilter.pageLifetimes : undefined,
    created: typeof def.created === 'undefined' ? compDefToFilter.created : undefined,
    attached: typeof def.attached === 'undefined' ? compDefToFilter.attached : undefined,
    ready: typeof def.ready === 'undefined' ? compDefToFilter.ready : undefined,
    moved: typeof def.moved === 'undefined' ? compDefToFilter.moved : undefined,
    detached: typeof def.detached === 'undefined' ? compDefToFilter.detached : undefined,
    saved: typeof def.saved === 'undefined' ? compDefToFilter.saved : undefined,
    restored: typeof def.restored === 'undefined' ? compDefToFilter.restored : undefined,
    relations: typeof def.relations === 'undefined' && compDefToFilter.relations ? processRelationPaths(filePath, compDefToFilter.relations) : undefined,
    externalClasses: typeof def.externalClasses === 'undefined' ? compDefToFilter.externalClasses : undefined,
    observers: typeof def.observers === 'undefined' ? compDefToFilter.observers : undefined,
    options: COMPONENT_OPTIONS,
    initiator() {
      this.__customConstructor__ = Page;
      this.__pageRouter__ = __appServiceSDK__.createRouter(is, this.__treeManager__.viewId);
      var compCaller = Object.create(compCallerProto);
      callerExparserNodeMap.set(compCaller, this);
      definition_exparser.Element.setMethodCaller(this, compCaller);
      Object.defineProperties(compCaller, {
        __data__: {
          value: this.data,
          writable: true,
          enumerable: false
        },
        __wxWebviewId__: {
          value: this.__treeManager__.viewId,
          writable: true,
          enumerable: false
        }
      });
    }
  };
  var userOptions = compDefToFilter.options || {};
  compDef.options.multipleSlots = false;
  compDef.options.writeOnly = false;
  compDef.options.writeIdToDOM = true;
  compDef.options.domain = domain || '/';
  compDef.options.styleIsolation = userOptions.styleIsolation || 'shared';
  compDef.options.addGlobalClass = false;
  compDef.options.innerDataExclude = userOptions.pureDataPattern || null;
  compDef.options.virtualHost = userOptions.virtualHost || false;
  var compCallerProto = registerByDef(compDef, codeMap, Page);
  compCallerProto.__freeData__ = customFields;
  return compDef.is;
};
var WORKLET_FACTORY_PREFIX = '_';
var WORKLET_FACTORY_SUFFIX = '_worklet_factory_';
var workletFactories = {};
var trimAndRegisterWorkletFactories = (is, methods) => {
  workletFactories[is] = {};
  Object.keys(methods || {}).forEach(methodName => {
    if (methodName.startsWith(WORKLET_FACTORY_PREFIX) && methodName.endsWith(WORKLET_FACTORY_SUFFIX)) {
      var name = methodName.slice(WORKLET_FACTORY_PREFIX.length, -WORKLET_FACTORY_SUFFIX.length);
      workletFactories[is][name] = methods[methodName];
    }
  });
};
var requestWorkletId = 0;
var requestWorkletCallbacks = {};
var getWorkletIdByName = (node, methodName, pageId) => new Promise(resolve => {
  var tm = tree_manager.get(pageId);
  var nodeId = tm.nodeId.getNodeId(node);
  requestWorkletCallbacks[requestWorkletId] = resolve;
  bridge_sendData(constants_SYNC_EVENT_NAME.REQUEST_WORKLET_METHOD, {
    methodName,
    nodeId,
    reqId: requestWorkletId
  }, pageId);
  requestWorkletId++;
});
setListenerOnNewPage(constants_SYNC_EVENT_NAME.RESPONSE_WORKLET_METHOD, res => {
  var requestWorkletId = res[0].reqId;
  var callback = requestWorkletCallbacks[requestWorkletId];
  if (typeof callback === 'function') {
    delete requestWorkletCallbacks[requestWorkletId];
    callback(res[0].workletId);
  }
});
var reportFlowCombinedEnabled = true;
var flowUpdateWrapper = tm => {
  updateProcess(() => {
    flowUpdate(tm);
  });
};
var flowUpdate = tm => {
  addFlowCount();
  var ts = Date.now();
  var operationIterator = tm.operationFlow.iterator;
  var startTs = operationIterator.expectStart();
  var nextStepType = operationIterator.nextStepType();
  if (nextStepType === constants_SYNC_EVENT_NAME.FLOW_INITIAL_CREATION) {
    flowInit(tm, constants_SYNC_EVENT_NAME.FLOW_INITIAL_CREATION);
    reportFlow(startTs, ts, Date.now(), 2);
  } else if (nextStepType === constants_SYNC_EVENT_NAME.FLOW_INITIAL_RENDERING_CACHE) {
    flowInit(tm, constants_SYNC_EVENT_NAME.FLOW_INITIAL_RENDERING_CACHE);
  } else if (nextStepType === constants_SYNC_EVENT_NAME.FLOW_CREATE_TAB) {
    flowInit(tm, constants_SYNC_EVENT_NAME.FLOW_CREATE_TAB);
    reportFlow(startTs, ts, Date.now(), 3);
  } else if (nextStepType === constants_SYNC_EVENT_NAME.FLOW_SET_ROOT_PROPERTIES) {
    var step = operationIterator.nextStep();
    applyProperties(tm.root, step[1], step[2], step[3]);
  } else if (nextStepType === constants_SYNC_EVENT_NAME.FLOW_DESTROY_PAGE) {
    operationIterator.nextStep();
    destroyPage(tm);
  } else if (definition_hasOwnProperty.call(comp_manager_viewThreadListeners, operationIterator.nextStepType())) {
    var handler = comp_manager_viewThreadListeners[operationIterator.nextStepType()];
    var data = operationIterator.nextStep().slice(1);
    handler(tm.compManager, data);
  } else {
    var renderStart = Date.now();
    var _step = operationIterator.nextStep();
    if (_step[0] === constants_SYNC_EVENT_NAME.FLOW_UPDATE) {
      var nodeId = _step[1];
      var node = tm.nodeId.getNodeById(nodeId);
      var changes = _step[2];
      if (!node) {
        wxNativeConsole.warn(`[flowUpdate] node ${_step[1]} not found`);
        operationIterator.skipToEnd();
      } else if (changes.length) {
        var nodeDataProxy = definition_exparser.Component.getDataProxy(node);
        nodeDataProxy.setChanges(changes);
        nodeDataProxy.doUpdates(undefined, !isDataThread());
        generateUpdatePerformanceStat(nodeId, config => {
          var dataPaths = config.withDataPaths ? changes.map(x => x[0]) : undefined;
          return {
            isMergedUpdate: false,
            dataPaths,
            pendingStartTimestamp: startTs,
            updateStartTimestamp: ts,
            updateEndTimestamp: Date.now(),
            pageId: tm.viewId
          };
        });
      }
    } else if (_step[0] === constants_SYNC_EVENT_NAME.FLOW_GROUP) {
      var _step2 = operationIterator.nextStep();
      if (_step2[0] !== constants_SYNC_EVENT_NAME.FLOW_GROUP_END) {
        throw new Error(`Framework inner error (expect FLOW_GROUP_END but get ${getEvName(_step2[0])})`);
      }
    } else if (_step[0] === constants_SYNC_EVENT_NAME.FLOW_REPLACE_PLACEHOLDER) {
      var loadId = _step[1];
      var replacement = tm.compManager.getAndClearPendingPlaceholderReplacement(loadId);
      replacement.replacers.forEach(replacer => {
        replacer();
      });
    } else if (_step[0] === constants_SYNC_EVENT_NAME.FLOW_HOT_UPDATE) {
      var _node = tm.nodeId.getNodeById(_step[1]);
      if (!_node) {
        operationIterator.skipToEnd();
      } else {
        _node.__templateInstance._resetShadowChildren(_node, _node.data, tm);
      }
    } else if (_step[0] === constants_SYNC_EVENT_NAME.FLOW_HOT_UPDATE_RESET) {
      var _node2 = tm.nodeId.getNodeById(_step[1]);
      virtual_tree_resetComponentNode(_node2, tm);
    } else {
      throw new Error(`Framework inner error (expect an update event but get ${getEvName(_step[0])})`);
    }
    speedReport('reRenderTime', renderStart, Date.now());
    if (reportFlowCombinedEnabled && reportFlowCombined(startTs, ts, Date.now()) === 5) {
      reportFlowCombinedEnabled = false;
      reportFlowFlushCombined(1);
    }
  }
  operationIterator.expectEnd();
};
var flowInit = (tm, flowType) => {
  wxNativeConsole.info(`[OperationFlow] executing init flow with type ${getEvName(flowType)}`);
  var isTabBarInit = flowType === constants_SYNC_EVENT_NAME.FLOW_CREATE_TAB;
  var isInitialRenderingCache = flowType === constants_SYNC_EVENT_NAME.FLOW_INITIAL_RENDERING_CACHE;
  var operationIterator = tm.operationFlow.iterator;
  var step = operationIterator.nextStep();
  var tagName = step[1];
  var nodeId = step[2];
  var renderer = currentRenderBackend();
  var root = null;
  var renderContext;
  if (renderer === 'skyline') {
    renderContext = getSkylineRuntime().getContext(tm.viewId);
  } else if (renderer === 'scl') {
    var sclTabBarContainer = __sclEngine__.getTabBarContainer();
    renderContext = {
      mainRoot: sclTabBarContainer
    };
  } else if (renderer === 'xr-frame') {
    renderContext = xrFrame.getOrCreateContext(tm.viewId);
  }
  if (isTabBarInit) {
    tm.tabNodeId = nodeId;
    wxNativeConsole.info(`[OperationFlow] creating tab bar comp <${tagName}> ok, pageId=${tm.viewId}`);
    if (renderer === 'skyline') {
      var tabBarContext = getSkylineRuntime().getTabBarContext();
      tm.tabRoot = root = window.__TAB_BAR__ = definition_exparser.Component.createWithContext('tab-bar', definition_exparser.Component._list[tagName], tabBarContext, tm);
      if (typeof root.__domElement.setStyleScope === 'function') {
        root.__domElement.setStyleScope(definition_exparser.getStyleScopeId(definition_exparser.Component._list[tagName].options.classPrefix));
      }
    } else if (renderer === 'scl') {
      tm.tabRoot = root = window.__TAB_BAR__ = definition_exparser.createElement('tab-bar', definition_exparser.Component._list[tagName]);
    } else if (renderer === 'xr-frame') {
      wxNativeConsole.info(`[OperationFlow] unexpected xr-frame tabb bar, pageId=${tm.viewId}`);
    } else {
      tm.tabRoot = root = window.__TAB_BAR__ = definition_exparser.createElement('tab-bar', definition_exparser.Component._list[tagName]);
    }
    wxNativeConsole.info(`[OperationFlow] create tab bar comp ok, pageId=${tm.viewId}`);
  } else if (isInitialRenderingCache) {
    if (!tagName) {
      saveDynamicInitialRenderingCache(null);
      return;
    }
    root = definition_exparser.createElement('initial-rendering-cache', definition_exparser.Component._list[tagName]);
  } else {
    var genericsImpl = step[3] || {};
    tm.rootNodeId = nodeId;
    wxNativeConsole.info(`[OperationFlow] creating root component on view thread, pageId=${tm.viewId}`);
    wx.traceBeginEvent('Framework', 'createRootComponent');
    if (renderer === 'skyline') {
      tm.root = root = window.__DOMTree__ = definition_exparser.Component.createWithGenericsAndContext('wx-page', definition_exparser.Component._list[tagName], genericsImpl, renderContext, tm);
      if (typeof root.__domElement.setStyleScope === 'function') {
        root.__domElement.setStyleScope(definition_exparser.getStyleScopeId(definition_exparser.Component._list[tagName].options.classPrefix));
      }
    } else if (currentRenderBackend() === 'xr-frame') {
      tm.root = root = window.__DOMTree__ = definition_exparser.Component.createWithGenericsAndContext('wx-xr-element', definition_exparser.Component._list[tagName], genericsImpl, renderContext, tm);
    } else {
      tm.root = root = window.__DOMTree__ = definition_exparser.Component.createWithGenerics('body', definition_exparser.Component._list[tagName], genericsImpl, tm);
    }
    wx.traceEndEvent();
    wxNativeConsole.info(`[OperationFlow] create root component on view thread ok, pageId=${tm.viewId}`);
  }
  tm.nodeId.allocNodeId(root, nodeId);
  root.setAttribute('is', tagName);
  if (save_restore_view_states.restoring && !isTabBarInit) {
    var statesData = save_restore_view_states.idDataMap[tm.nodeId.getNodeId(root)];
    definition_exparser.Component.replaceWholeData(root, statesData, null);
    callRestoredLifeTimes(save_restore_view_states.restoring);
    save_restore_view_states.restoring = null;
    save_restore_view_states.idDataMap = null;
  }
  step = operationIterator.nextStep();
  if (step[0] !== flowType) {
    throw new Error(`Framework inner error (expect ${getEvName(flowType)} end but get ${getEvName(step[0])})`);
  }
  tm.nodeId.addNode(root);
  if (isTabBarInit) {
    if (renderer === 'skyline') {
      wxNativeConsole.info('[OperationFlow] attaching tabBar to skyline');
      var skylineRuntime = getSkylineRuntime();
      var _tabBarContext = skylineRuntime.getTabBarContext();
      root.__domElement.setStyle('pointer-events: none;');
      _tabBarContext.attach(root.__domElement);
      definition_exparser.Element.pretendAttached(root);
      skylineRuntime.insertToInspecteeRoots(root);
      tm.__attached = true;
      wxNativeConsole.info('[OperationFlow] attach tabBar to skyline done');
    } else if (renderer === 'scl') {
      wxNativeConsole.info('[OperationFlow] attaching tabBar to scl');
      renderContext.mainRoot.appendChild(root);
      wxNativeConsole.info('[OperationFlow] attaching tabBar to scl');
    } else {
      var tabBarWrapper = definition_exparser.createElement('wx-tab-bar-wrapper', definition_exparser.Component._list['wx://tab-bar-wrapper']);
      tabBarWrapper.appendChild(root);
      document.documentElement.insertBefore(tabBarWrapper.$$, document.body);
      definition_exparser.Element.pretendAttached(tabBarWrapper);
      if (tm.tabDestroyed) tabBarWrapper.removeChild(root);
    }
  } else if (isInitialRenderingCache) {
    var initialRenderingCacheWrapper = document.createElement('wx-initial-rendering-cache-wrapper');
    initialRenderingCacheWrapper.setAttribute('style', 'height: 0; overflow: hidden');
    initialRenderingCacheWrapper.appendChild(root.$$);
    document.documentElement.insertBefore(initialRenderingCacheWrapper, document.body);
    step = operationIterator.nextStep();
    if (step[0] !== constants_SYNC_EVENT_NAME.FLOW_INITIAL_RENDERING_CACHE) {
      throw new Error('Framework inner error (expect initial rendering end but get another)');
    }
    utils_dfsComponents(root, 1, comp => {
      comp.triggerLifeTime('cacheAttached');
    });
    saveDynamicInitialRenderingCache(root, step[1]);
    tm.nodeId.removeNode(root);
    document.documentElement.removeChild(initialRenderingCacheWrapper);
  } else {
    if (renderer === 'skyline') {
      wxNativeConsole.info(`[WABaseLib.Critical] attach root element to skyline, pageId=${tm.viewId}`);
      var _skylineRuntime = getSkylineRuntime();
      var hostNode = renderContext.createElement('empty', 'host');
      var presetStyle = ['opacity: 0.999999', 'border-radius: 0%', 'filter: blur(0px)', 'backdrop-filter: blur(0px)'];
      hostNode.setStyle(presetStyle.join('; '));
      hostNode.appendChild(root.__domElement);
      root.__domElement.forceDetached();
      renderContext.attach(root.__domElement, hostNode);
      _skylineRuntime.setCustomRouteConfigIfNeeded(tm.viewId, hostNode);
      _skylineRuntime.insertToInspecteeRoots(root);
      tm.__attached = true;
    } else if (currentRenderBackend() === 'webview') {
      document.body = root.$$;
    }
    utils_dfsComponents(root, 1, comp => {
      comp.triggerLifeTime('cacheAttached');
    });
    if (renderer === 'webview') {
      saveStaticInitialRenderingCache(root);
    }
    definition_exparser.Element.pretendAttached(root);
  }
  wxNativeConsole.info(`[OperationFlow] init flow type ${getEvName(flowType)} execution ok`);
};
var tabBarReadyNotifier = {};
var initViewThread = () => {
  operation_flow.setStartOperation(flowUpdateWrapper);
};
var renderThreadTabbarIsCreated = false;
var newTabBar = (options = {}) => {
  var renderer = currentRenderBackend();
  var tabBarViewId = renderer === 'skyline' ? SKYLINE_TABBAR_VIEW_ID : SCL_TABBAR_VIEW_ID;
  setPageType(tabBarViewId, renderer);
  if (options.openType === 'reLaunch' || options.openType === 'autoReLaunch') {
    destroyTabBar(tabBarViewId);
    renderThreadTabbarIsCreated = false;
  }
  if (renderThreadTabbarIsCreated) return;
  renderThreadTabbarIsCreated = true;
  wxNativeConsole.info(`[VD] newTabBar, tabBarViewId=${tabBarViewId}`);
  isGenerateFuncReady[tabBarViewId] = true;
  tree_manager.create(tabBarViewId);
  setListenersForNewPage(tabBarViewId);
  var tm = tree_manager.get(tabBarViewId);
  tm.operationFlow.unblock();
  if (renderer === 'skyline') {
    var tabBarContext = getSkylineRuntime().getTabBarContext();
    var tabBarStyleSheetManager = __webviewEngine__.getStyleSheetManager(tabBarViewId);
    tabBarStyleSheetManager.registerBackendContext(tabBarContext);
  }
  if (renderer === 'scl') {
    var cm = tm.compManager;
    cm.injectComponentsRecursively([TABBAR_COMP_NAME], () => {
      bridge_sendData(constants_SYNC_EVENT_NAME.SCL_CONTEXT_READY, {}, tabBarViewId);
    });
  }
};
var viewStartRenderSet = new Set();
var newPage = (pageId, ext) => {
  if (tree_manager.get(pageId)) return;
  wxNativeConsole.info(`[VD] newPage, pageId=${pageId}`);
  setPageType(pageId, currentRenderBackend());
  var tm = tree_manager.create(pageId);
  var cm = tm.compManager;
  isGenerateFuncReady[pageId] = false;
  pendingComponentDefData[pageId] = [];
  pendingTabComponentDefData[pageId] = [];
  setListenersForNewPage(pageId);
  onMainPageFrameReady(pageId, () => {
    wxNativeConsole.info(`[WebviewInjectFirstPage] onMainPageFrameReady, isLazyLoad=${isLazyLoad()}, pageId=${pageId}, isFirstPage=${__wxConfig.isFirstPage}`);
    if (isLazyLoad() && __wxConfig.isFirstPage && currentRenderBackend() === 'webview') {
      var entryPath = __wxConfig.appLaunchInfo.path;
      var rootCompPath = entryPath.replace(/\.html$/, '').replace(/^\//, '');
      rootCompPath = pluginAliasToPath(rootCompPath);
      wxNativeConsole.info(`[WebviewInjectFirstPage] entryPath=${entryPath}, pageId=${pageId}, rootCompPath=${rootCompPath}`);
      var _cm = tree_manager.get(pageId).compManager;
      setTimeout(() => {
        rootCompPath = pluginAliasToPath(rootCompPath);
        var pluginPageGenericsImpl = processPluginPageGenerics(rootCompPath);
        var allRootComps = [rootCompPath, ...utils_objectValues(pluginPageGenericsImpl)];
        _cm.setInitialSubPackage(rootCompPath);
        _cm.injectComponentsRecursively(allRootComps, () => {
          tabBarReadyNotifier[pageId].on('inject', () => {
            injectWxss(rootCompPath);
            triggerGenerateFuncReady(rootCompPath);
          });
        }, true);
      });
    }
    if (currentRenderBackend() === 'skyline') {
      getSkylineRuntime().procGenPolyfilled(typeof __wxCodeSpace__ !== 'undefined');
    }
  });
  tabBarReadyNotifier[pageId] = createPublishSubscribe(['inject']);
  tabBarReadyNotifier[pageId].on('inject', () => {
    if (currentRenderBackend() === 'webview') {
      sendTabBarCreationRequest(pageId);
    }
  });
  __wxConfig.onReady(() => {
    if (!isLazyLoad() || !useCustomTabBar()) {
      tabBarReadyNotifier[pageId].notify('inject');
    } else {
      onMainPageFrameReady(pageId, () => {
        if (currentRenderBackend() === 'skyline') {
          cm.injectComponentsRecursively([TABBAR_COMP_NAME], () => {
            getSkylineRuntime().onPageReady(pageId, () => {
              var rebuild = ext.openType === 'autoReLaunch' || ext.openType === 'reLaunch';
              if (ext.isTabPage) {
                if (isShowCustomTabBarByConfig(ext.path)) {
                  sendTabBarCreationRequest(pageId, rebuild);
                  viewThreadShowTabBar();
                } else {
                  viewThreadHideTabBar();
                }
              }
              tabBarReadyNotifier[pageId].notify('inject');
            });
          });
        } else {
          cm.injectComponentsRecursively([TABBAR_COMP_NAME], () => {
            tabBarReadyNotifier[pageId].notify('inject');
          });
        }
      });
    }
  });
  if (currentRenderBackend() === 'skyline') {
    var pluginPrefixes = getAllPluginSubPackagePrefix();
    __webviewEngine__.styleSheetRuntime.addIndexGroup('');
    Object.keys(pluginPrefixes).forEach(pluginId => {
      var subPackagePrefix = pluginPrefixes[pluginId];
      var prefix = `${subPackagePrefix}__plugin__/${pluginId}/`;
      __webviewEngine__.styleSheetRuntime.addIndexGroup(prefix);
    });
    getSkylineRuntime().onPageReady(pageId, context => {
      var pageStyleSheetManager = __webviewEngine__.getStyleSheetManager(pageId);
      pageStyleSheetManager.registerBackendContext(context);
      if (ext.isTabPage) {
        if (isShowCustomTabBarByConfig(ext.path)) {
          var _window, _window$__TAB_BAR__, _window$__TAB_BAR__$_;
          newTabBar(ext);
          (_window = window) === null || _window === void 0 ? void 0 : (_window$__TAB_BAR__ = _window.__TAB_BAR__) === null || _window$__TAB_BAR__ === void 0 ? void 0 : (_window$__TAB_BAR__$_ = _window$__TAB_BAR__.__domElement) === null || _window$__TAB_BAR__$_ === void 0 ? void 0 : _window$__TAB_BAR__$_.setStyle('display: flex; pointer-events: none;');
        } else {
          var _window2, _window2$__TAB_BAR__, _window2$__TAB_BAR__$;
          (_window2 = window) === null || _window2 === void 0 ? void 0 : (_window2$__TAB_BAR__ = _window2.__TAB_BAR__) === null || _window2$__TAB_BAR__ === void 0 ? void 0 : (_window2$__TAB_BAR__$ = _window2$__TAB_BAR__.__domElement) === null || _window2$__TAB_BAR__$ === void 0 ? void 0 : _window2$__TAB_BAR__$.setStyle('display: none; pointer-events: none;');
        }
      }
    });
  }
};
var getDomTreeByPageId = pageId => {
  var tm = tree_manager.get(pageId);
  wxNativeConsole.info('[skyline] getDomTreeByPageId tm: ', typeof tm);
  if (tm !== undefined && tm.root !== undefined) {
    return tm.root;
  }
  return undefined;
};
var destroyPage = tm => {
  if (currentRenderBackend() === 'webview') return;
  var pageId = tm.viewId;
  wxNativeConsole.info(`[destroyPage] pageId=${pageId}`);
  definition_exparser.Element.pretendDetached(tm.root);
  tree_manager.destroy(pageId);
  setDomTree(null);
  delete isGenerateFuncReady[pageId];
  delete pendingComponentDefData[pageId];
  delete pendingTabComponentDefData[pageId];
  delete tabBarReadyNotifier[pageId];
  bridge_removeDataListeners(pageId);
  removeTunnels(pageId);
  viewStartRenderSet.delete(pageId);
  if (currentRenderBackend() === 'skyline') {
    var skylineRuntime = getSkylineRuntime();
    skylineRuntime.markDestroyContext(pageId);
    skylineRuntime.removeFromInspecteeRoots(tm.root);
    __webviewEngine__.removeStyleSheetManager(pageId);
    Foundation.emit('SKYLINE_DESTROY_PAGE', pageId);
  } else if (currentRenderBackend() === 'xr-frame') {
    xrFrame.getOrCreateContext(pageId).destroy();
    delete window.__DOMTree__;
  }
};
var destroyTabBar = pageId => {
  if (currentRenderBackend() === 'webview') return;
  wxNativeConsole.info(`[CustomTabBar] destroyTabBar pageId=${pageId}`);
  var tm = tree_manager.get(pageId);
  if (!tm) return;
  if (tm !== null && tm !== void 0 && tm.tabRoot) definition_exparser.Element.pretendDetached(tm.tabRoot);
  tree_manager.destroy(pageId);
  delete isGenerateFuncReady[pageId];
  delete pendingComponentDefData[pageId];
  delete pendingTabComponentDefData[pageId];
  delete tabBarReadyNotifier[pageId];
  if (currentRenderBackend() === 'skyline') {
    __webviewEngine__.removeStyleSheetManager(pageId);
    getSkylineRuntime().removeFromInspecteeRoots(tm.root);
  }
};
var setDomTree = pageId => {
  var _TreeManager$get;
  if (pageId === null) {
    window.__DOMTree__ = null;
    return;
  }
  window.__DOMTree__ = (_TreeManager$get = tree_manager.get(pageId)) === null || _TreeManager$get === void 0 ? void 0 : _TreeManager$get.root;
};
if (currentRenderBackend() === 'skyline') {
  wx.subscribe('onAppRouteDone', res => {
    setDomTree(res.webviewId);
  });
}
var TYPE_STRING_NAME = {
  String,
  Number,
  Boolean,
  Object,
  Array,
  null: null
};
var updateComponentDef = (def, isRootComp) => {
  for (var k in def.properties) {
    var p = def.properties[k];
    p.type = TYPE_STRING_NAME[p.type];
    if (p.optionalTypes) p.optionalTypes = p.optionalTypes.map(x => TYPE_STRING_NAME[x]);
  }
  var classPrefix = '';
  if (!isRootComp) {
    classPrefix = ComponentManager.getComponentClassPrefix(def.is);
  }
  var options = def.options;
  var workAsOldPage = !!(options.writeIdToDOM || isRootComp);
  def.options = COMPONENT_OPTIONS_VIEW;
  def.options.multipleSlots = options.multipleSlots || false;
  def.options.writeOnly = options.writeOnly || false;
  if (workAsOldPage || currentRenderBackend() === 'xr-frame') def.options.idPrefixGenerator = null;else def.options.idPrefixGenerator = utils_guid;
  def.options.domain = options.domain;
  def.options.randomizeTagName = false;
  def.options.innerDataExclude = regExpFromString(options.innerDataExcludeString);
  def.options.virtualHost = options.virtualHost;
  var disableAppWxss = false;
  if (options.styleIsolation) {
    var styleIsolation = options.styleIsolation;
    if (styleIsolation.slice(0, 5) === 'page-') {
      disableAppWxss = true;
      styleIsolation = styleIsolation.slice(5);
    }
    if (styleIsolation === 'isolated') {
      classPrefix = ComponentManager.getComponentClassPrefix(def.is);
      def.options.addGlobalClass = false;
    } else if (styleIsolation === 'strong-isolated') {
      classPrefix = ComponentManager.getComponentClassPrefix(def.is);
      def.options.addGlobalClass = false;
      def.options.randomizeTagName = true;
    } else if (styleIsolation === 'apply-shared') {
      classPrefix = ComponentManager.getComponentClassPrefix(def.is);
      def.options.addGlobalClass = true;
    } else if (styleIsolation === 'shared' && options.domain === '/') {
      classPrefix = '';
      def.options.addGlobalClass = false;
    } else {
      disableAppWxss = false;
    }
  } else {
    def.options.addGlobalClass = options.addGlobalClass || false;
  }
  def.options.classPrefix = classPrefix;
  if (options.hasObservers) {
    def.observers = {
      '**'() {}
    };
  }
  if (inDevtoolsWebview()) {
    def.observers = {
      ...(def.observers || {}),
      '**'(data) {
        // #7723 notify devtools component data changed
        WeixinJSBridge.invoke('componentDataChanged', {
          nodeId: this.__wxTmplId,
          data
        });
      }
    };
  }
  window.__customComponentMode__ = typeof __wxAppCode__ !== 'undefined' && __wxAppCode__[def.template];
  var generateFunc = window.__generateFunc__;
  if (typeof __wxAppCode__ === 'undefined' || !__wxAppCode__[def.template]) {
    wxNativeConsole.warn(`[componentRegistration] Generate function of ${def.is} not found in view thread`);
  } else generateFunc = __wxAppCode__[def.template];
  def.template = {
    path: def.is + '.wxml',
    func: generateFunc
  };
  definition_exparser.registerElement(def);
  return {
    disableAppWxss,
    classPrefix
  };
};
var prepareSubPackagesStyle = (pageId, subPackages) => {
  var styleSheetManager = __webviewEngine__.getStyleSheetManager(pageId, subPackages);
  subPackages.forEach(subpackage => {
    var prefix = subpackage === '__APP__' ? '' : subpackage;
    styleSheetManager.setIndex(prefix + 'app.fpiib');
    getSubPackagePlugin(subpackage, plugins => {
      plugins.forEach(p => {
        styleSheetManager.setIndex(`${prefix}__plugin__/${p.provider}/app.fpiib`);
      });
    });
  });
};
var onComponentDef = (_data, isTab, pageId) => {
  var data = currentRenderBackend() === 'xr-frame' ? utils_deepCopySerializable(_data) : _data;
  var renderer = currentRenderBackend();
  if (!isTab) registerSavingListener();
  var [behDefs, compDefs, rootCompName, compAliases] = data;
  var tm = tree_manager.get(pageId);
  if (!isTab) tm.rootCompName = rootCompName;
  for (var i = 0; i < behDefs.length; i++) {
    var def = behDefs[i];
    if (def.options.hasObservers) {
      def.observers = {
        '**'() {}
      };
    }
    def.options = BEHAVIOR_OPTIONS;
    definition_exparser.registerBehavior(def);
  }
  var styleSheetManager;
  if (renderer === 'skyline') {
    styleSheetManager = __webviewEngine__.getStyleSheetManager(pageId);
    styleSheetManager.preventUpdate();
    styleSheetManager.setStyleSheet('app', definition_exparser.getStyleScopeId(''), 2);
  } else if (renderer === 'webview') {
    styleSheetManager = window.__styleSheetManager2__;
    styleSheetManager.preventUpdate();
  }
  var _loop = function () {
    var def = compDefs[_i];
    var compRoute = convertComponentAliasToRoute(def.is);
    if (compRoute.startsWith('plugin-private://') && !tm.compManager.__injectedComponents.has(compRoute)) {
      tm.compManager.__injectedComponents.add(compRoute);
    }
    var isRootComp = def.is === rootCompName && !isTab;
    if (renderer === 'scl' && isTab) {
      isRootComp = true;
    }
    var {
      disableAppWxss,
      classPrefix
    } = updateComponentDef(def, isRootComp, tm);
    if (disableAppWxss && def.is === rootCompName && !isTab) {
      if (renderer === 'webview') {
        __webviewEngine__.disableStyleElement('app.wxss');
      } else if (renderer === 'skyline') {
        styleSheetManager.disableStyleSheet('app');
      }
    }
    var wxssPath = def.is + '.wxss';
    var insertWxss = typeof __wxAppCode__ === 'undefined' ? null : __wxAppCode__[wxssPath];
    if (renderer === 'skyline') {
      if (insertWxss && !styleSheetManager.usePreCompiled) {
        insertWxss('', {
          allowIllegalSelector: true
        });
      }
      var styleScope = 0;
      if (typeof definition_exparser.getStyleScopeId === 'function') {
        styleScope = definition_exparser.getStyleScopeId(classPrefix);
      }
      var priority = def.is === rootCompName ? 1 : 0;
      styleSheetManager.setStyleSheet(compRoute, styleScope, priority);
    } else if (renderer === 'scl') {
      __sclEngine__.loadStyleBincode(`${compRoute}.fpcssb`);
    } else if (renderer === 'webview') {
      if (disableAppWxss && def.is === rootCompName && !isTab) {
        __webviewEngine__.disableStyleElement('app.wxss');
      }
      if (insertWxss) {
        if (def.is !== rootCompName || isTab) {
          insertWxss(classPrefix && classPrefix + '--', {
            allowIllegalSelector: true
          });
        }
        hot_update_addUpdateListener(wxssPath, func => {
          if (func) func(classPrefix && classPrefix + '--', {
            allowIllegalSelector: true
          });else window.__styleSheetManager__.setCss('./' + wxssPath, '');
          wx.triggerPageReRender();
        });
      }
    }
  };
  for (var _i = 0; _i < compDefs.length; _i++) {
    _loop();
  }
  hot_update_addUpdateListener('app.wxss', func => {
    if (func) func('', {
      allowIllegalSelector: true
    });else window.__styleSheetManager__.setCss('./app.wxss', '');
    wx.triggerPageReRender();
  });
  if (renderer === 'webview' || renderer === 'skyline') {
    styleSheetManager.allowUpdate();
    styleSheetManager.requestUpdate();
  }
  for (var k in compAliases) {
    if (definition_hasOwnProperty.call(definition_exparser.Component._list, compAliases[k])) {
      definition_exparser.Component._list[k] = definition_exparser.Component._list[compAliases[k]];
    }
  }
};
setListenerOnNewPage(constants_SYNC_EVENT_NAME.LOAD_COMPONENT_DEF, (data, ev, pageId) => {
  var _exparser$Component$_;
  wxNativeConsole.info(`[loadComponentDef] isFirstPage=${__wxConfig.isFirstPage}, isLazyLoad=${isLazyLoad()}`);
  var allRootComps = data[0];
  var rootCompName = allRootComps[0];
  if (((_exparser$Component$_ = definition_exparser.Component._list[rootCompName]) === null || _exparser$Component$_ === void 0 ? void 0 : _exparser$Component$_.options.domain) === '//') {
    triggerGenerateFuncReady(rootCompName, pageId);
  }
  if (!isLazyLoad() || currentRenderBackend() === 'webview' && __wxConfig.isFirstPage) return;
  var cm = tree_manager.get(pageId).compManager;
  cm.setInitialSubPackage(rootCompName);
  onMainPageFrameReady(pageId, () => {
    cm.injectComponentsRecursively(allRootComps, () => {
      tabBarReadyNotifier[pageId].on('inject', () => {
        injectWxss(rootCompName);
        triggerGenerateFuncReady(rootCompName, pageId);
      });
    }, true);
  });
});
var isGenerateFuncReady = {};
var pendingComponentDefData = {};
var pendingTabComponentDefData = {};
setListenerOnNewPage(constants_SYNC_EVENT_NAME.COMPONENT_DEF, (data, ev, pageId) => {
  if (!isGenerateFuncReady[pageId]) {
    pendingComponentDefData[pageId].push(data);
  } else {
    onComponentDef(data, false, pageId);
  }
  tree_manager.get(pageId).compManager.setInitialSubPackage(data[2]);
});
setListenerOnNewPage(constants_SYNC_EVENT_NAME.COMPONENT_DEF_TAB, (data, ev, pageId) => {
  if (!isGenerateFuncReady[pageId]) {
    pendingTabComponentDefData[pageId].push(data);
  } else {
    if (currentRenderBackend() !== 'webview') {
      onComponentDef(data, true, pageId);
    } else if (currentRenderBackend() === 'scl') {
      onComponentDef(data, true, pageId);
    } else {
      tabBarReadyNotifier[pageId].on('inject', () => {
        onComponentDef(data, true, pageId);
      });
    }
  }
});
var runComponentDef = pageId => {
  isGenerateFuncReady[pageId] = true;
  if (currentRenderBackend() === 'webview') sendTabBarCreationRequest(pageId);
  pendingComponentDefData[pageId].forEach(data => {
    onComponentDef(data, false, pageId);
  });
  pendingComponentDefData[pageId] = [];
  pendingTabComponentDefData[pageId].forEach(data => {
    tabBarReadyNotifier[pageId].on('inject', () => {
      onComponentDef(data, true, pageId);
    });
  });
  pendingTabComponentDefData[pageId] = [];
};
var doDataThreadInitCreation = (viewId, tm, rootCompName, shadowRoot, genericsImpl) => {
  __appServiceSDK__.traceBeginEvent('Framework', 'doDataThreadInitCreation');
  rootCompName = convertRouteToComponentAlias(rootCompName);
  var usedDef = [[], [], rootCompName, componentAliases];
  var compFounded = Object.create(null);
  recurseUsedComponents(usedDef, rootCompName, compFounded, '', tm);
  objectValues(genericsImpl).forEach(genericImpl => {
    recurseUsedComponents(usedDef, genericImpl, compFounded, '', tm);
  });
  wxNativeConsole.info(`[doDataThreadInitCreation] sending component def to view, viewId=${viewId}, rootCompName=${rootCompName}`);
  publishXrCustomOptions(viewId);
  sendData(SYNC_EVENT_NAME.COMPONENT_DEF, usedDef, viewId);
  sendBannedMap(viewId);
  tm.rootCompName = rootCompName;
  tm.rootNodeId = guid();
  wxNativeConsole.info(`[OperationFlow] creating root component on data thread, use different shadowRoot=${typeof shadowRoot !== 'undefined'}, viewId=${viewId}`);
  tm.operationFlow.start();
  tm.operationFlow.push([SYNC_EVENT_NAME.FLOW_INITIAL_CREATION, rootCompName, tm.rootNodeId, genericsImpl]);
  var root = typeof shadowRoot === 'undefined' ? definition_exparser.Component.createWithGenerics('body', definition_exparser.Component._list[rootCompName], genericsImpl, tm) : shadowRoot.createComponent('body', definition_exparser.Component._list[rootCompName], genericsImpl, tm);
  reportPluginNodeCreation(root, tm);
  tm.root = root;
  // #7434
  tm.usedDef = getPageType(viewId) === 'skyline' ? deepCopySerializable(usedDef) : usedDef;
  var caller = definition_exparser.Element.getMethodCaller(root);
  caller.__wxExparserNodeId__ = tm.nodeId.allocNodeId(root, tm.rootNodeId);
  tm.operationFlow.push([SYNC_EVENT_NAME.FLOW_INITIAL_CREATION]);
  tm.nodeId.addNode(root);
  __appServiceSDK__.traceEndEvent();
  wxNativeConsole.info(`[OperationFlow] create root component on data thread ok, viewId=${viewId}`);
  return root;
};
setListenerOnNewPage(constants_SYNC_EVENT_NAME.UPDATE_COMPONENT_DEF, (data, ev, pageId) => {
  var [def] = data;
  var tm = tree_manager.get(pageId);
  if (definition_exparser.Component._list[def.is]) {
    updateComponentDef(def, tm.rootCompName === def.is, tm);
  }
});
var checkActive = viewId => {
  var currentPages = __appServiceEngine__.getCurrentPagesByDomain('');
  var requireActivePage = currentPages[currentPages.length - 1];
  if (requireActivePage.__wxWebviewId__ === viewId || viewId === SKYLINE_TABBAR_VIEW_ID) return true;
  return false;
};
var registerUserEventListeners = (viewId, tm) => {
  setDataListener(constants_SYNC_EVENT_NAME.WX_EVENT, data => {
    var e = data[2];
    var funcName = data[1];
    var host = tm.nodeId.getNodeById(data[0]);
    if (!host) return;
    var caller = definition_exparser.Element.getMethodCaller(host);
    var needWrapUserTap = e._userTap;
    if (e._requireActive && !__appServiceEngine__.isFramesetMode()) {
      if (!checkActive(viewId)) return;
      delete e._requireActive;
    }
    if (e._relatedInfo) {
      __appServiceEngine__.DisplayReporter.setEventRelatedInfo(e._relatedInfo);
      delete e._relatedInfo;
    }
    if (typeof caller[funcName] !== 'function') {
      console.warn('Component "' + host.is + '" does not have a method "' + funcName + '" to handle event "' + e.type + '".');
    } else if (needWrapUserTap) {
      wrapTapMark(() => {
        var eventId = __userActionTracer__.startTraceHandler(e);
        __appServiceSDK__.setWxInterfaceIsInvokeInTap(e.type);
        definition_exparser.safeCallback('Event Handler', caller[funcName], caller, [e], host);
        __appServiceSDK__.unsetWxInterfaceIsInvokeInTap();
        __userActionTracer__.endTraceHandler(eventId);
      });
    } else {
      var eventId = __userActionTracer__.startTraceHandler(e);
      definition_exparser.safeCallback('Event Handler', caller[funcName], caller, [e], host);
      __userActionTracer__.endTraceHandler(eventId);
    }
  }, viewId);
  setDataListener(constants_SYNC_EVENT_NAME.MODEL_VALUE_CHANGE, (res, ev, webviewId) => {
    var {
      data,
      modelValueName,
      nodeId
    } = res[0];
    setModelValueData(data, modelValueName, webviewId, nodeId);
  }, viewId);
};
var registerDataEventListener = (viewId, tm) => {
  if (tm.listenerInited) return;
  tm.listenerInited = true;
  registerUserEventListeners(viewId, tm);
  setDataListener(constants_SYNC_EVENT_NAME.REQUEST_SAVE, ([statesData]) => {
    saveView(viewId, statesData);
  }, viewId);
  setDataListener(constants_SYNC_EVENT_NAME.CALL_METHOD_FROM_WXS, args => {
    callMethodFromWxsCallback(args, viewId);
  }, viewId);
  registerAnimationListeners(viewId, tm);
  registerAnimatedStyleListeners(viewId, tm);
  registerViewInfoListeners(viewId, tm);
  registerUpdatePerformanceListeners(viewId, tm);
  setDataListener(constants_SYNC_EVENT_NAME.REQUEST_WORKLET_METHOD, (res, ev, pageId) => {
    var _workletFactories$nod, _workletFactories$nod2;
    var {
      methodName,
      nodeId,
      reqId
    } = res[0];
    var response = workletId => bridge_sendData(constants_SYNC_EVENT_NAME.RESPONSE_WORKLET_METHOD, {
      reqId,
      workletId
    }, pageId);
    var tm = tree_manager.get(pageId);
    var node = tm.nodeId.getNodeById(nodeId);
    var workletFactory = (_workletFactories$nod = workletFactories === null || workletFactories === void 0 ? void 0 : (_workletFactories$nod2 = workletFactories[node.is]) === null || _workletFactories$nod2 === void 0 ? void 0 : _workletFactories$nod2[methodName]) !== null && _workletFactories$nod !== void 0 ? _workletFactories$nod : null;
    if (typeof workletFactory === 'function') {
      var compInst = definition_exparser.Element.getMethodCaller(node);
      var worklet = workletFactory.call(compInst);
      if (typeof worklet === 'function') {
        var workletId = __appServiceSDK__.workletSDK.registerJsValue(worklet);
        response(workletId);
        return;
      }
    }
    response(null);
  }, viewId);
};
var generateInitialRenderingCache = (tm, dynamicData) => {
  var rootCompName = route_utils_convertRouteToComponentAlias(tm.rootCompName);
  var cacheNodeId = utils_guid();
  tm.operationFlow.start();
  tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_INITIAL_RENDERING_CACHE, rootCompName, cacheNodeId]);
  var root = definition_exparser.createElement('initial-rendering-cache', definition_exparser.Component._list[rootCompName], tm);
  var caller = definition_exparser.Element.getMethodCaller(root);
  caller.__wxExparserNodeId__ = tm.nodeId.allocNodeId(root, cacheNodeId);
  tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_INITIAL_RENDERING_CACHE]);
  tm.nodeId.addNode(root);
  root.setData(dynamicData);
  tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_INITIAL_RENDERING_CACHE, dynamicData]);
  tm.operationFlow.end();
  tm.nodeId.removeNode(root);
  return root;
};
var clearInitialRenderingCache = tm => {
  tm.operationFlow.start();
  tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_INITIAL_RENDERING_CACHE, '', null]);
  tm.operationFlow.end();
};
var tabBarCreationRequestSent = {};
var sendTabBarCreationRequest = (pageId, rebuild = false) => {
  if (__wxAppCode__[TABBAR_COMP_NAME + '.wxml'] === undefined) {
    wxNativeConsole.info(`[CustomTabBar] no ${TABBAR_COMP_NAME} def, ignore requestTab`);
    return;
  }
  if (tabBarCreationRequestSent[pageId]) return;
  tabBarCreationRequestSent[pageId] = true;
  wxNativeConsole.info(`[CustomTabBar] sendTabBarCreationRequest pageId=${pageId}`);
  bridge_sendData(constants_SYNC_EVENT_NAME.REQUEST_TAB, [rebuild], pageId);
};
setListenerOnNewPage(constants_SYNC_EVENT_NAME.DESTROY_TAB, (data, ev, pageId) => {
  wxNativeConsole.info(`[CustomTabBar] destroyTabBar pageId=${pageId}`);
  tree_manager.get(pageId).tabDestroyed = true;
  viewThreadHideTabBar();
});
setListenerOnNewPage(constants_SYNC_EVENT_NAME.HIDE_TAB, (data, ev, pageId) => {
  wxNativeConsole.info(`[CustomTabBar] hideTabBar pageId=${pageId}`);
  viewThreadHideTabBar();
});
setListenerOnNewPage(constants_SYNC_EVENT_NAME.SHOW_TAB, (data, ev, pageId) => {
  wxNativeConsole.info(`[CustomTabBar] showTabBar pageId=${pageId}`);
  tree_manager.get(pageId).tabDestroyed = false;
  viewThreadShowTabBar();
});
var dataThreadTabbarCreatedResolve = {};
var dataThreadTabbarCreated = pageId => new Promise(resolve => {
  dataThreadTabbarCreatedResolve[pageId] = resolve;
});
var doDataThreadTabbarCreation = (viewId, tm, tabCompName, renderer) => {
  wxNativeConsole.info(`doDataThreadTabbarCreation viewId: ${viewId}, tabCompName: ${tabCompName}, renderer: ${renderer}`);
  if (renderer !== 'webview') {
    var customTabBarManager = getCustomTabBarManager();
    var tabBarViewId;
    if (renderer === 'skyline') {
      tabBarViewId = SKYLINE_TABBAR_VIEW_ID;
    } else if (renderer === 'scl') {
      tabBarViewId = SCL_TABBAR_VIEW_ID;
    } else {
      throw Error(`[CustomTabBar] renderer: ${renderer} not support`);
    }
    var tabBarTm;
    var isInitialized = customTabBarManager.has(tabBarViewId);
    if (isInitialized) {
      tabBarTm = customTabBarManager.get(tabBarViewId).tm;
      customTabBarManager.add(viewId, renderer, tabBarTm);
      tm.tabCompName = tabBarTm.tabCompName;
      tm.tabNodeId = tabBarTm.tabNodeId;
      tm.tabRoot = tabBarTm.tabRoot;
      tm.tabUsedDef = tabBarTm.tabUsedDef;
    } else {
      setPageType(tabBarViewId, renderer);
      tabCompName = route_utils_convertRouteToComponentAlias(tabCompName);
      var tabUsedDef = [[], [], tabCompName, {}];
      tabBarTm = tree_manager.create(tabBarViewId);
      recurseUsedComponents(tabUsedDef, tabCompName, Object.create(null), '', tabBarTm);
      registerDataEventListener(tabBarViewId, tabBarTm);
      bridge_sendData(constants_SYNC_EVENT_NAME.COMPONENT_DEF_TAB, tabUsedDef, tabBarViewId);
      var tabNodeId = utils_guid();
      tm.tabCompName = tabBarTm.tabCompName = tabCompName;
      tm.tabNodeId = tabBarTm.tabNodeId = tabNodeId;
      customTabBarManager.add(tabBarViewId, renderer, tabBarTm);
      customTabBarManager.add(viewId, renderer, tabBarTm);
      tabBarTm.operationFlow.start();
      tabBarTm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_CREATE_TAB, tabCompName, tabNodeId]);
      var tabRoot = definition_exparser.createElement('tab-bar', definition_exparser.Component._list[tabCompName], tabBarTm);
      tm.tabRoot = tabBarTm.tabRoot = tabRoot;
      tm.tabUsedDef = tabBarTm.tabUsedDef = tabUsedDef;
      var caller = definition_exparser.Element.getMethodCaller(tabRoot);
      caller.__wxExparserNodeId__ = tabBarTm.nodeId.allocNodeId(tabRoot, tabBarTm.tabNodeId);
      tabBarTm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_CREATE_TAB]);
      tabBarTm.nodeId.addNode(tabRoot);
      definition_exparser.Element.pretendAttached(tabRoot);
    }
    tm.nodeId.addNode(tm.tabRoot);
    !isInitialized && tabBarTm.operationFlow.end();
    typeof dataThreadTabbarCreatedResolve[viewId] === 'function' && dataThreadTabbarCreatedResolve[viewId]();
  } else {
    var _customTabBarManager = getCustomTabBarManager();
    _customTabBarManager.add(viewId, renderer, tm);
    tabCompName = route_utils_convertRouteToComponentAlias(tabCompName);
    var _tabUsedDef = [[], [], tabCompName, {}];
    recurseUsedComponents(_tabUsedDef, tabCompName, Object.create(null), '', tm);
    bridge_sendData(constants_SYNC_EVENT_NAME.COMPONENT_DEF_TAB, _tabUsedDef, viewId);
    tm.tabCompName = tabCompName;
    tm.tabNodeId = utils_guid();
    tm.operationFlow.start();
    tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_CREATE_TAB, tabCompName, tm.tabNodeId]);
    var _tabRoot = definition_exparser.createElement('tab-bar', definition_exparser.Component._list[tabCompName], tm);
    tm.tabRoot = _tabRoot;
    tm.tabUsedDef = _tabUsedDef;
    var _caller = definition_exparser.Element.getMethodCaller(_tabRoot);
    _caller.__wxExparserNodeId__ = tm.nodeId.allocNodeId(_tabRoot, tm.tabNodeId);
    tm.operationFlow.push([constants_SYNC_EVENT_NAME.FLOW_CREATE_TAB]);
    tm.nodeId.addNode(_tabRoot);
    definition_exparser.Element.pretendAttached(tm.tabRoot);
    tm.operationFlow.end();
  }
};
var isNeedRenderCustomTabBar = () => {
  var _wxConfig, _wxConfig$appLaunchIn;
  var needRenderCustomTabBar = useCustomTabBar();
  if (!componentExists(TABBAR_COMP_NAME)) needRenderCustomTabBar = false;
  if (((_wxConfig = __wxConfig) === null || _wxConfig === void 0 ? void 0 : (_wxConfig$appLaunchIn = _wxConfig.appLaunchInfo) === null || _wxConfig$appLaunchIn === void 0 ? void 0 : _wxConfig$appLaunchIn.mode) === 'singlePage') needRenderCustomTabBar = false;
  return needRenderCustomTabBar;
};
var checkAndExecuteTabbarCreation = (viewId, isGeneratorFunctionReady) => {
  var needRenderCustomTabBar = isNeedRenderCustomTabBar();
  var rootCompPath = pageRootCompPath[viewId];
  if (typeof rootCompPath === 'string' && isSubPackageIndependent(rootCompPath)) {
    wxNativeConsole.info(`[CustomTabBar] "${rootCompPath}" is in independent subPackage, ignore`);
    return;
  }
  var renderer = getCustomTabBarRendererByConfig(rootCompPath);
  var rendererByPageId = bridge_getPageType(viewId) || 'webview';
  if (renderer !== 'scl' && rendererByPageId !== renderer) renderer = rendererByPageId;
  wxNativeConsole.info(`[checkAndExecuteTabbarCreation] viewId=${viewId}, isGeneratorFunctionReady=${isGeneratorFunctionReady}, needRenderCustomTabBar=${needRenderCustomTabBar}, renderer=${renderer}`);
  if (!needRenderCustomTabBar) return;
  if (renderer === 'scl' && !isGeneratorFunctionReady) return;
  var tm = tree_manager.get(viewId) || tree_manager.create(viewId);
  registerDataEventListener(viewId, tm);
  if (tm.tabRoot || tm.tabDestroyed) {
    return;
  }
  tm.compManager.injectComponentsRecursively([TABBAR_COMP_NAME]);
  doDataThreadTabbarCreation(viewId, tm, TABBAR_COMP_NAME, renderer);
  if (isGeneratorFunctionReady) {
    if (renderer === 'skyline') {
      bridge_sendData(constants_SYNC_EVENT_NAME.FLUSH_BLOCKED, [], SKYLINE_TABBAR_VIEW_ID);
    } else if (renderer === 'scl') {
      bridge_sendData(constants_SYNC_EVENT_NAME.FLUSH_BLOCKED, [], SCL_TABBAR_VIEW_ID);
    } else {
      bridge_sendData(constants_SYNC_EVENT_NAME.FLUSH_BLOCKED, [], viewId);
    }
  }
  if (tm.rootCompName) {
    tabbar_manager_checkPageIncludingTabBar(tm, tm.rootCompName, viewId);
  }
};
var sclContextReady = false;
var sclPendingTabBarCreation = [];
var pendingTabBarCreation = [];
__wxConfig.onReady(() => {
  pendingTabBarCreation.forEach(viewId => {
    if (bridge_getPageType(viewId) !== 'skyline') {
      checkAndExecuteTabbarCreation(viewId, true);
    }
  });
  pendingTabBarCreation = null;
});
if (isDataThread()) {
  setDataListener(constants_SYNC_EVENT_NAME.REQUEST_TAB, (data, _ev, viewId) => {
    if (data[0]) {
      destroyDataThreadTabBar(viewId, true);
    }
    if (getCustomTabBarRendererByConfig(pageRootCompPath[viewId]) === 'scl' && !sclContextReady) sclPendingTabBarCreation.push(viewId);else if (bridge_getPageType(viewId) === 'skyline') checkAndExecuteTabbarCreation(viewId, true);else if (pendingTabBarCreation !== null) pendingTabBarCreation.push(viewId);else checkAndExecuteTabbarCreation(viewId, true);
  }, '$GLOBAL');
  setDataListener(constants_SYNC_EVENT_NAME.SCL_CONTEXT_READY, (_data, _ev, _viewId) => {
    sclContextReady = true;
    sclPendingTabBarCreation.forEach(viewId => {
      checkAndExecuteTabbarCreation(viewId, true);
    });
  }, SCL_TABBAR_VIEW_ID);
}
setListenerOnNewPage(constants_SYNC_EVENT_NAME.FLUSH_BLOCKED, (data, ev, pageId) => {
  wxNativeConsole.info(`[flushBlocked] pageId=${pageId}`);
  tree_manager.get(pageId).operationFlow.flushBlocked();
});
var componentExists = compName => {
  compName = route_utils_convertRouteToComponentAlias(compName);
  if (definition_hasOwnProperty.call(domain_componentAliases, compName)) compName = domain_componentAliases[compName];
  return extractedComponentDef[compName];
};
var pageRootCompPath = {};
var setPageRootCompPath = (pageId, rootCompPath) => {
  pageRootCompPath[pageId] = rootCompPath;
};
var addView = (viewId, rootCompPath, lifetimeListener, shadowRoot, genericsImpl) => {
  wxNativeConsole.info(`[addView] viewId=${viewId}, rootCompPath=${rootCompPath}`);
  __appServiceSDK__.traceBeginEvent('Framework', 'addView');
  setPageRootCompPath(viewId, rootCompPath);
  var tm = TreeManager.get(viewId) || TreeManager.create(viewId);
  tm.lifetimeListener = lifetimeListener;
  tm.operationFlow.unblock();
  try {
    if (getPageType(viewId) === 'webview') {
      checkAndExecuteTabbarCreation(viewId, false);
    }
  } catch (err) {
    Reporter.thirdErrorReport({
      error: err
    });
  }
  tm.compManager.setInitialSubPackage(rootCompPath);
  checkPageIncludingTabBar(tm, rootCompPath, viewId);
  enabledGlobalUpdatePerformanceListener(tm);
  registerDataEventListener(viewId, tm);
  rootCompPath = convertRouteToComponentAlias(rootCompPath);
  var pluginPageGenericsImpl = processPluginPageGenerics(rootCompPath);
  var finalGenericsImpl = genericsImpl || pluginPageGenericsImpl;
  var allRootComps = [rootCompPath, ...objectValues(finalGenericsImpl)];
  var subPackages = (__wxConfig.subPackages || []).filter(pkg => !!pkg.allExtendedComponents);
  sendData(SYNC_EVENT_NAME.LOAD_COMPONENT_DEF, [allRootComps, subPackages], viewId);
  tm.compManager.injectComponentsRecursively(allRootComps, null, true, true);
  if (!componentExists(rootCompPath)) {
    wxNativeConsole.error(`[addView] viewId=${viewId} rootCompPath=${rootCompPath} not found`);
    rootCompPath = 'wx://not-found';
  }
  var ret = doDataThreadInitCreation(viewId, tm, rootCompPath, shadowRoot, finalGenericsImpl);
  __appServiceSDK__.traceEndEvent();
  return ret;
};
var attachView = (viewId, initData, shouldCallElementAttached = true) => {
  wxNativeConsole.info(`[attachView] viewId=${viewId}`);
  var tm = TreeManager.get(viewId);
  if (!tm) return;
  var exparserNode = tm.root;
  var needSetPropData = false;
  var initProp = {};
  if (exparserNode.is.indexOf('wx://inner-page') === 0) {
    initProp = initData;
    needSetPropData = true;
  } else {
    Object.keys(initData).forEach(k => {
      if (definition_exparser.Component.hasProperty(exparserNode, k)) {
        initProp[k] = initData[k];
        needSetPropData = true;
      }
    });
  }
  if (needSetPropData) tm.root.setData(initProp);
  if (isUpdateListenerEnabled()) tm.initialRootData = initData;
  if (shouldCallElementAttached) {
    definition_exparser.Element.pretendAttached(exparserNode);
  }
  tm.root.__treeManager__.operationFlow.end();
};
var removeView = (viewId, shouldCallElementDetached = true) => {
  wxNativeConsole.info(`[removeView] viewId=${viewId}`);
  var tm = TreeManager.get(viewId);
  if (!tm) return;
  if (shouldCallElementDetached) {
    definition_exparser.Element.pretendDetached(tm.root);
  }
  TreeManager.destroy(viewId);
  removeDataListeners(viewId);
  destroyedPage.add(viewId);
  __appServiceSDK__.workletSDK.removeRouteContext(viewId);
  tm.operationFlow.sendInIndividualFlow([SYNC_EVENT_NAME.FLOW_DESTROY_PAGE]);
};
var destroyDataThreadTabBar = (viewId, force = false) => {
  var tabbarManager = getCustomTabBarManager();
  if (force) {
    tabbarManager.remove(viewId);
    tabbarManager.remove(SKYLINE_TABBAR_VIEW_ID);
    pendingTabBarCreation = null;
  }
  if (tabbarManager.has(viewId)) {
    var renderer = tabbarManager.getRenderType(viewId);
    tabbarManager.remove(viewId);
    if (renderer === 'skyline') {
      tabbarManager.remove(SKYLINE_TABBAR_VIEW_ID);
    }
    pendingTabBarCreation = null;
  }
};
var isViewAttached = viewId => {
  var tm = TreeManager.get(viewId);
  if (!tm) return false;
  var exparserNode = tm.root;
  if (!exparserNode) return false;
  return definition_exparser.Element.isAttached(exparserNode);
};
var xrFrameTouchEventNegotiators = new WeakMap();
var xrFrameTouchEvent = (/* unused pure expression or super */ null && ({
  onNegotiation: (compInstance, negotiator, wxAppCode) => {
    var codeMap = wxAppCode || __wxAppCode__;
    var exparserNode = definition_getExparserNode(compInstance);
    if (!exparserNode.__isXrFrame__) throw new Error('component is not a xr-frame component');
    var rootNode = getPageRootComponent(exparserNode);
    if (getPageType(rootNode.__treeManager__.viewId) !== 'skyline') {
      throw new Error('component is not in a skyline page');
    }
    var compConfig = codeMap[exparserNode.is + '.json'] || {};
    if (compConfig.xrFrameTouchEventBubble !== true) {
      throw new Error('component should set "xrFrameTouchEventBubble" to true in configuration');
    }
    xrFrameTouchEventNegotiators.set(exparserNode, negotiator);
  },
  negotiate: (exparserNode, evt, cb) => {
    var negotiator = xrFrameTouchEventNegotiators.get(exparserNode);
    if (typeof negotiator === 'function') {
      negotiator(evt, cb);
    } else cb(true, true);
  }
}));
var setPageReady = pageId => {
  TreeManager.get(pageId).compManager.setPageReady();
};
;// CONCATENATED MODULE: ./src/comp_api/index.js






var getNodeById = function (id, webviewId) {
  if (!isDataThread() && currentRenderBackend() === 'webview') webviewId = 0;
  if (webviewId === null || webviewId === undefined) {
    var tms = tree_manager.list();
    for (var i = 0; i < tms.length; ++i) {
      if (tms[i].nodeId.getNodeById(id) !== undefined) return tms[i].nodeId.getNodeById(id);
    }
    return null;
  }
  var tm = tree_manager.get(webviewId);
  return tm ? tm.nodeId.getNodeById(id) : null;
};
var getNodeId = function (node, webviewId) {
  if (!isDataThread() && currentRenderBackend() === 'webview') webviewId = 0;
  var tm = webviewId !== undefined ? tree_manager.get(webviewId) : tree_manager.getByNode(node);
  return tm ? tm.nodeId.getNodeId(node) : '';
};
var getRootNode = function (webviewId) {
  if (!isDataThread() && currentRenderBackend() === 'webview') webviewId = 0;
  var tm = tree_manager.get(webviewId);
  if (!tm) return '';
  return tm.root;
};
var getRootNodeId = function (webviewId) {
  if (!isDataThread() && currentRenderBackend() === 'webview') webviewId = 0;
  var tm = tree_manager.get(webviewId);
  if (!tm) return '';
  return tm.rootNodeId;
};
var getRootCompName = function (webviewId) {
  if (!isDataThread() && currentRenderBackend() === 'webview') webviewId = 0;
  var tm = tree_manager.get(webviewId);
  if (!tm) return '';
  return tm.rootCompName;
};
var getPageId = function (node) {
  var tm = tree_manager.getByNode(node);
  return tm ? tm.viewId : 0;
};
;// CONCATENATED MODULE: ./src/utils/fetch_info.js











var fetch_info_exparser = getExparser();
var animationNodeListCountMap = {};
var clearAnimationNodeListCountMap = {};
var STATUS = {
  FREE: 0,
  ANIMATING: 1,
  WAITING: 2
};
var getViewportInfo = (fields, tm) => {
  var res = {};
  var getProperty = name => currentRenderBackend() === 'webview' ? document.documentElement[name] || document.body[name] : tm.root.getBackendContext()[name];
  if (fields.id) {
    res.id = '';
  }
  if (fields.dataset) {
    res.dataset = {};
  }
  if (fields.mark) {
    res.mark = {};
  }
  if (fields.rect) {
    res.left = 0;
    res.right = 0;
    res.top = 0;
    res.bottom = 0;
  }
  if (fields.size) {
    res.width = getProperty('clientWidth');
    res.height = getProperty('clientHeight');
  }
  if (fields.scrollOffset) {
    res.scrollLeft = getProperty('scrollLeft');
    res.scrollTop = getProperty('scrollTop');
    res.scrollWidth = getProperty('scrollWidth');
    res.scrollHeight = getProperty('scrollHeight');
  }
  return res;
};
var getAnimationStyleStr = function (styleObj) {
  return Object.keys(styleObj).filter(key => {
    var lowerKey = key.toLocaleLowerCase();
    if ((lowerKey.includes('transform') || lowerKey.includes('transition')) && styleObj[key] === '' || key.trim() === '' || styleObj[key] === undefined || styleObj[key] === '' || !isNaN(parseInt(key, 10))) {
      return false;
    }
    return true;
  }).map(key => {
    var newKey = key.replace(/([A-Z]{1})/g, v => `-${v.toLowerCase()}`);
    return `${newKey}:${styleObj[key]}`;
  }).join(';');
};
var clearNodeAnimationInfo = (args, _node) => {
  var {
    nodeId,
    webviewId,
    options,
    selector,
    reqId,
    hasCallback,
    fromWxs
  } = args;
  var host = getNodeById(nodeId, webviewId);
  if (!host) return;
  var shadowTree = host.shadowRoot;
  var node = _node || shadowTree.querySelectorAll(selector);
  if (!_node) {
    clearAnimationNodeListCountMap[reqId] = node.length;
    for (var i = 0; i < node.length; ++i) {
      clearNodeAnimationInfo(args, node[i]);
    }
    return;
  }
  var sendFinishCallback = () => {
    var tm = tree_manager.getByNode(_node);
    if (fromWxs) {
      var callback = tm.clearAnimationCbMap[reqId];
      if (typeof callback === 'function') {
        delete tm.clearAnimationCbMap[reqId];
        fetch_info_exparser.safeCallback('Clear Animation', callback, null, []);
      }
    } else {
      bridge_sendData(constants_SYNC_EVENT_NAME.CLEAR_ANIMATION_COMPLETE, {
        reqId
      }, tm.viewId);
    }
  };
  unbindScrollAnimation(node);
  if (!options || typeof options === 'function' || !node.__styleObj) {
    if (node.__animeOptions) {
      node.__animeOptions.forEach(item => typeof item.reset === 'function' && item.reset());
      node.__animeOptions = [];
    }
    node.setNodeStyle('', STYLE_SEGMENT_INDEX.ANIMATION);
    unregisterResizer(node, STYLE_SEGMENT_INDEX.ANIMATION);
    node.__styleObj = null;
    node.__animateStatus = STATUS.FREE;
    node.__animationPendingQueue = [];
    sendFinishCallback();
    return;
  }
  var transformArr = node.__styleObj.transform.split(' ');
  for (var key of Object.keys(options)) {
    if (options[key]) {
      if (node.__styleObj[key === 'backgroundColor' ? 'background-color' : key]) {
        delete node.__styleObj[key === 'backgroundColor' ? 'background-color' : key];
      } else {
        for (var _i = 0; _i < transformArr.length; ++_i) {
          if (transformArr[_i].indexOf(key) >= 0) {
            transformArr.splice(_i, 1);
          }
        }
      }
    }
  }
  node.__styleObj.transform = transformArr.join(' ');
  node.__styleObj['-webkit-transform'] = transformArr.join(' ');
  node.__styleObj.transition = 'unset';
  node.__styleObj.transitionProperty = 'unset';
  node.__styleObj['-webkit-transition'] = 'unset';
  node.__styleObj['-webkit-transition-property'] = 'unset';
  var animationStyleStr = getAnimationStyleStr(node.__styleObj);
  var applyStyle = animationStyleStr => {
    node.setNodeStyle(wx.transformRpx(animationStyleStr, true), STYLE_SEGMENT_INDEX.ANIMATION);
  };
  applyStyle(animationStyleStr);
  registerResizer(node, STYLE_SEGMENT_INDEX.ANIMATION, applyStyle);
  node.__animateStatus = STATUS.FREE;
  --clearAnimationNodeListCountMap[reqId];
  if (clearAnimationNodeListCountMap[reqId] === 0 && hasCallback) {
    sendFinishCallback();
  }
};
var setNodeNextAnimationInfo = (args, _node) => {
  var {
    nodeId,
    webviewId,
    selector
  } = args;
  var host = getNodeById(nodeId, webviewId);
  if (!host) return;
  var shadowTree = host.shadowRoot;
  var node = _node || shadowTree.querySelectorAll(selector);
  if (!_node) {
    for (var i = 0; i < node.length; ++i) {
      setNodeNextAnimationInfo(JSON.parse(JSON.stringify(args)), node[i]);
    }
    return;
  }
  if (node.__animationPendingQueue && node.__animationPendingQueue.length > 0) {
    node.__animateStatus = STATUS.WAITING;
    setTimeout(() => {
      setNodeAnimationInfo(node.__animationPendingQueue.shift(), node, true);
    }, 32);
  }
};
var normalizeAnimationStyle = val => {
  if (typeof val === 'string') {
    val = wx.transformRpx(val, true);
  } else if (typeof val === 'object' && typeof val.value === 'string') {
    val.value = wx.transformRpx(val.value, true);
  } else if (Array.isArray(val)) {
    val.map(item => {
      if (typeof item.value === 'string') {
        item.value = wx.transformRpx(item.value, true);
      } else if (typeof item === 'string') {
        return wx.transformRpx(item, true);
      }
      return item;
    });
  }
  return val;
};
var wrapAnimationOptions = options => {
  Object.keys(options).forEach(key => {
    if (allowCSSProperties.includes(key)) {
      options[key] = normalizeAnimationStyle(options[key]);
    }
  });
};
var setNodeAnimationInfo = (args, _node, fromWaiting) => {
  wx.nextTick(() => {
    var {
      nodeId,
      webviewId,
      options,
      selector,
      reqId,
      hasCallback,
      type,
      isLastAnimation,
      fromWxs
    } = args;
    var host = getNodeById(nodeId, webviewId);
    if (!host) return;
    var shadowTree = host.shadowRoot;
    var node = _node || shadowTree.querySelectorAll(selector);
    if (!_node) {
      animationNodeListCountMap[reqId] = node.length;
      for (var i = 0; i < node.length; ++i) {
        setNodeAnimationInfo(JSON.parse(JSON.stringify(args)), node[i]);
      }
      return;
    }
    if (node.__animateStatus === STATUS.ANIMATING || node.__animateStatus === STATUS.WAITING && !fromWaiting) {
      if (!node.__animationPendingQueue) {
        node.__animationPendingQueue = [];
      }
      node.__animationPendingQueue.push(JSON.parse(JSON.stringify(args)));
      return;
    }
    node.__hasCallback = hasCallback;
    node.__reqId = reqId;
    node.__args = JSON.stringify(args);
    var props = ['height', 'left', 'matrix', 'matrix3d', 'opacity', 'right', 'rotate', 'rotate3d', 'rotateX', 'rotateY', 'rotateZ', 'scale', 'scale3d', 'scaleX', 'scaleY', 'scaleZ', 'skew', 'skewX', 'skewY', 'top', 'translate', 'translate3d', 'translateX', 'translateY', 'translateZ', 'width', 'backgroundColor', 'bottom'];
    var styleProps = ['opacity', 'backgroundColor', 'width', 'height', 'left', 'top', 'bottom'];
    var singleParamProps = ['rotate', 'rotateX', 'rotateY', 'rotateZ', 'scaleX', 'scaleY', 'scaleZ', 'skewX', 'skewY', 'translateX', 'translateY', 'translateZ'];
    var shouldTriggerWithAnimeJS = type === 'animeJS';
    var animationCompleteCallback = (applyCurStyle, isLastAnimation = true) => {
      if (node.__animateStatus === STATUS.ANIMATING) {
        --animationNodeListCountMap[node.__reqId];
        if (node.__animationPendingQueue && node.__animationPendingQueue.length > 0 && !node.__hasCallback) {
          node.__animateStatus = STATUS.WAITING;
          setNodeAnimationInfo(node.__animationPendingQueue.shift(), node, true);
        } else {
          node.__animateStatus = STATUS.FREE;
        }
        if (typeof applyCurStyle === 'function') {
          node.__styleObj.transition = 'unset';
          node.__styleObj.transitionProperty = 'unset';
          node.__styleObj['-webkit-transition'] = 'unset';
          node.__styleObj['-webkit-transition-property'] = 'unset';
          var animationStyleStr = getAnimationStyleStr(node.__styleObj);
          applyCurStyle(animationStyleStr);
        }
        if (animationNodeListCountMap[node.__reqId] === 0 && node.__hasCallback && isLastAnimation) {
          var tm = tree_manager.getByNode(_node);
          if (fromWxs) {
            var callback = tm.applyAnimationCbMap[node.__reqId];
            if (typeof callback === 'function') {
              delete tm.applyAnimationCbMap[node.__reqId];
              fetch_info_exparser.safeCallback('Animation', callback, null, []);
            }
            setNodeNextAnimationInfo(args);
          } else {
            bridge_sendData(constants_SYNC_EVENT_NAME.ANIMATION_TRANSITION_END, {
              reqId: node.__reqId,
              args: node.__args
            }, tm.viewId);
          }
        }
      }
    };
    var animates = [];
    for (var key of Object.keys(options)) {
      if (props.indexOf(key) >= 0) {
        if (styleProps.indexOf(key) >= 0) {
          animates.push({
            type: 'style',
            args: [key === 'backgroundColor' ? 'background-color' : key, options[key]]
          });
        } else if (singleParamProps.indexOf(key) >= 0) {
          animates.push({
            type: key,
            args: [options[key]]
          });
        } else {
          animates.push({
            type: key,
            args: options[key]
          });
        }
      }
    }
    var option = {
      transition: {
        delay: options.delay || 0,
        duration: options.duration || 0,
        timingFunction: options.ease || 'linear'
      },
      transformOrigin: options.transformOrigin || '50% 50% 0'
    };
    var animation = {
      option,
      animates
    };
    var {
      transition,
      transitionProperty,
      transform,
      transformOrigin,
      style
    } = wx.animationToStyle(animation);
    var styleObj = node.__styleObj ? Object.assign({}, node.__styleObj, {
      transition,
      transform,
      transitionProperty,
      transformOrigin
    }) : {
      transition,
      transform,
      transitionProperty,
      transformOrigin
    };
    styleObj['-webkit-transition'] = styleObj.transition;
    styleObj['-webkit-transform'] = styleObj.transform;
    styleObj['-webkit-transition-property'] = styleObj.transitionProperty;
    styleObj['-webkit-transform-origin'] = styleObj.transformOrigin;
    for (var _key of Object.keys(style || {})) {
      styleObj[_key] = style[_key];
    }
    if (node.__styleObj && styleObj.transform === node.__styleObj.transform) {
      var flag = true;
      for (var _key2 of Object.keys(styleObj)) {
        if (styleProps.indexOf(_key2) >= 0) {
          if (node.__styleObj[_key2] !== styleObj[_key2]) {
            flag = false;
          }
        }
      }
      if (flag) {
        setTimeout(() => {
          if (node.__animationPendingQueue && node.__animationPendingQueue.length > 0) {
            setNodeAnimationInfo(node.__animationPendingQueue.shift(), node, true);
          }
        }, option.duration);
        return;
      }
    }
    if (option.transition.duration === 0) {
      styleObj.transition = 'unset';
      styleObj.transitionProperty = 'unset';
      styleObj['-webkit-transition'] = 'unset';
      styleObj['-webkit-transition-property'] = 'unset';
    } else {
      node.__animateStatus = STATUS.ANIMATING;
    }
    node.__styleObj = styleObj;
    if (shouldTriggerWithAnimeJS) {
      options.targets = node;
      if (options.ease) {
        options.easing = options.ease;
        delete options.ease;
      }
      wrapAnimationOptions(options);
      node.__animateStatus = STATUS.ANIMATING;
      if (node.__banned) {
        banComponentNode(node);
      }
      var prevComplete = options.complete;
      options.complete = (...args) => {
        animationCompleteCallback(undefined, isLastAnimation);
        typeof prevComplete === 'function' && prevComplete(...args);
      };
      var animeOptions = vendor_anime(options);
      if (!node.__animeOptions) {
        node.__animeOptions = [];
      }
      node.__animeOptions.push(animeOptions);
    } else {
      var animationStyleStr = getAnimationStyleStr(styleObj);
      var applyCurStyle = animationStyleStr => {
        var applyStyle = () => {
          node.setNodeStyle(wx.transformRpx(animationStyleStr, true), STYLE_SEGMENT_INDEX.ANIMATION);
        };
        applyStyle();
        registerResizer(node, STYLE_SEGMENT_INDEX.ANIMATION, applyStyle);
      };
      if (option.transition.duration === 0) {
        applyCurStyle(animationStyleStr);
      } else {
        setTimeout(() => {
          applyCurStyle(animationStyleStr);
        }, 32);
      }
      if (node.__banned) {
        banComponentNode(node);
      }
      if (!node.__animationListener) {
        node.addListener('transitionend', () => {
          animationCompleteCallback(applyCurStyle);
        });
        node.__animationListener = true;
      }
      if (option.transition.duration === 0) {
        if (node.__animationPendingQueue && node.__animationPendingQueue.length > 0) {
          node.__animateStatus = STATUS.WAITING;
          setNodeAnimationInfo(node.__animationPendingQueue.shift(), node, true);
        } else {
          node.__animateStatus = STATUS.FREE;
        }
      }
    }
  });
};
var getBoundingClientRect = (domNode, cb) => {
  if (currentRenderBackend() === 'webview') {
    cb(domNode.getBoundingClientRect());
  } else {
    domNode.getBoundingClientRect(rect => {
      cb(rect);
    });
  }
};
var fetch_info_getComputedStyle = (context, domNode, cb) => {
  if (currentRenderBackend() === 'webview') {
    cb(window.getComputedStyle(domNode));
  } else if (typeof (context === null || context === void 0 ? void 0 : context.getComputedStyle) === 'function') {
    context.getComputedStyle(domNode, style => {
      cb(style || {});
    });
  } else {
    cb({});
  }
};
var getNodeInfo = (node, fields, cb) => {
  var domNode = node.$$;
  var res = {};
  var onTasksCleared = null;
  var tasks = new Set();
  var addTask = task => {
    tasks.add(task);
    task(() => {
      tasks.delete(task);
      if (tasks.size === 0 && typeof onTasksCleared === 'function') {
        onTasksCleared(res);
      }
    });
  };
  if (fields.id) {
    res.id = node.id || '';
  }
  if (fields.dataset) {
    res.dataset = node.dataset || {};
  }
  if (fields.mark) {
    res.mark = node.collectMarks() || {};
  }
  if (fields.rect || fields.size) {
    if (domNode) {
      addTask(done => {
        getBoundingClientRect(domNode, rect => {
          if (fields.rect) {
            res.left = rect.left;
            res.right = rect.right;
            res.top = rect.top;
            res.bottom = rect.bottom;
          }
          if (fields.size) {
            res.width = rect.width;
            res.height = rect.height;
          }
          done();
        });
      });
    } else {
      res.left = res.right = res.top = res.bottom = res.width = res.height = 0;
    }
  }
  if (fields.properties) {
    fields.properties.forEach(name => {
      var propName = name.replace(/-([a-z])/g, (m, l) => l.toUpperCase());
      if (fetch_info_exparser.Component.hasPublicProperty(node, propName)) {
        res[propName] = node[propName];
      }
    });
  }
  if (fields.scrollOffset) {
    if (typeof node.hasBehavior === 'function' && node.hasBehavior('wx-positioning-container')) {
      var scrollPos = node.getScrollPosition();
      res.scrollLeft = scrollPos.scrollLeft;
      res.scrollTop = scrollPos.scrollTop;
      res.scrollWidth = scrollPos.scrollWidth;
      res.scrollHeight = scrollPos.scrollHeight;
    } else {
      res.scrollLeft = 0;
      res.scrollTop = 0;
      res.scrollWidth = 0;
      res.scrollHeight = 0;
    }
  }
  if (fields.computedStyle && fields.computedStyle.length) {
    if (domNode) {
      var context = currentRenderBackend() !== 'webview' ? node.__backendContext : null;
      addTask(done => {
        fetch_info_getComputedStyle(context, domNode, style => {
          for (var i = 0, len = fields.computedStyle.length; i < len; i++) {
            var key = fields.computedStyle[i];
            if (key && style[key] !== undefined) res[key] = style[key];
          }
          done();
        });
      });
    }
  }
  if (fields.context) {
    res.contextIs = node.is;
    res.contextId = typeof node.getContextId === 'function' && node.getContextId();
    res.contextCanvasId = node.canvasId || '';
    if (currentRenderBackend() === 'xr-frame') {
      res.__context = domNode.__xrElement;
    }
  }
  if (fields.node) {
    res.nodeIs = node.is;
    res.nodeId = typeof node.getContextId === 'function' && node.getContextId();
    res.nodeCanvasId = node.canvasId || '';
    res.nodeCanvasType = node.type || '';
    res.nodeNodeId = node.getNodeId();
  }
  if (tasks.size !== 0) {
    if (typeof cb !== 'function') {
      throw new Error('Framework Error: getNetInfo called asynchronously without a callback');
    } else {
      onTasksCleared = cb;
    }
  } else {
    if (typeof cb === 'function') {
      cb(res);
    } else {
      return res;
    }
  }
};
var getNodeInfoAsync = (node, fields) => currentRenderBackend() === 'webview' ? getNodeInfo(node, fields) : new Promise(resolve => {
  getNodeInfo(node, fields, res => {
    resolve(res);
  });
});
var getViewInfo = /*#__PURE__*/function () {
  var _ref = external_BabelRuntimeHelpers_asyncToGenerator_default()(function* (reqs, tm) {
    var res = [];
    var {
      pluginId,
      queue
    } = reqs;
    queue.forEach(req => {
      var component = req.component;
      var selector = req.selector;
      var single = req.single;
      var fields = req.fields;
      var itemRes = null;
      if (component === 0) {
        itemRes = getViewportInfo(fields, tm);
      } else {
        var shadowTree = tm.nodeId.getNodeById(component);
        var writeOnly = false;
        if (shadowTree) {
          if (fetch_info_exparser.Component.getComponentOptions(shadowTree).writeOnly) {
            writeOnly = true;
          }
          shadowTree = shadowTree.shadowRoot;
        } else if (!pluginId) {
          shadowTree = window.__DOMTree__ ? window.__DOMTree__.shadowRoot : null;
        }
        if (single) {
          var node = shadowTree && !writeOnly ? shadowTree.querySelector(selector) : null;
          if (node) {
            if (!node.$$ && (fields.size || fields.rect)) {
              console.warn('For developer:Node "' + selector + '" is virtual. Query selector cannot get size info.');
            }
            itemRes = getNodeInfoAsync(node, fields);
          } else {
            itemRes = null;
          }
        } else {
          var nodes = shadowTree && !writeOnly ? shadowTree.querySelectorAll(selector) : [];
          itemRes = [];
          for (var i = 0; i < nodes.length; i++) {
            if (!nodes[i].$$ && (fields.size || fields.rect)) {
              console.warn('For developer:Node "' + selector + '" is virtual. Query selector cannot get size info.');
            }
            itemRes.push(getNodeInfoAsync(nodes[i], fields));
          }
          itemRes = Promise.all(itemRes);
        }
      }
      res.push(itemRes);
    });
    return Promise.all(res);
  });
  return function getViewInfo(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
;// CONCATENATED MODULE: ./src/utils/intersectionObserver.ts
function createRectangle(left = 0, top = 0, width = 0, height = 0) {
  return {
    x: left,
    y: top,
    left,
    top,
    width,
    height,
    bottom: top + height,
    right: left + width
  };
}
var emptyRect = createRectangle();
function getRectangle(target) {
  if (target === document.documentElement) {
    return createRectangle(0, 0, target.clientWidth, target.clientHeight);
  }
  return target.getBoundingClientRect();
}
function getArea(rect) {
  return rect.width * rect.height;
}
function isEmpty(rect) {
  return rect.height === 0 && rect.width === 0;
}
function isEqual(first, second) {
  return first.top === second.top && first.left === second.left && first.right === second.right && first.bottom === second.bottom;
}
function parseThresholds(thresholds = 0) {
  var result;
  if (!Array.isArray(thresholds)) {
    result = [thresholds];
  } else if (!thresholds.length) {
    result = [0];
  } else {
    result = thresholds;
  }
  return result.map(threshold => {
    threshold = Number(threshold);
    if (!window.isFinite(threshold)) {
      throw new TypeError('The provided double value is non-finite.');
    } else if (threshold < 0 || threshold > 1) {
      throw new RangeError('Threshold values must be between 0 and 1.');
    }
    return threshold;
  }).sort();
}
function getThresholdGreaterThan(thresholds, ratio) {
  var thresholdsLen = thresholds.length;
  var l = 0;
  var r = thresholdsLen;
  var m;
  while (l !== r) {
    m = l + r >> 1;
    if (thresholds[m] <= ratio) {
      l = m + 1;
    } else {
      r = m;
    }
  }
  return l;
}
function applyMargins(targetRect, margins) {
  var left = targetRect.left - margins.left;
  var top = targetRect.top - margins.top;
  var right = targetRect.right + margins.right;
  var bottom = targetRect.bottom + margins.bottom;
  var width = right - left;
  var height = bottom - top;
  return createRectangle(left, top, width, height);
}
function computeIntersection(...rects) {
  var left = rects[0].left;
  var right = rects[0].right;
  var top = rects[0].top;
  var bottom = rects[0].bottom;
  for (var i = 0; i < rects.length; i += 1) {
    left = Math.max(left, rects[i].left);
    right = Math.min(right, rects[i].right);
    top = Math.max(top, rects[i].top);
    bottom = Math.min(bottom, rects[i].bottom);
  }
  var width = right - left;
  var height = bottom - top;
  return width > 0 && height > 0 ? createRectangle(left, top, width, height) : emptyRect;
}
function getIntersectionData(target, containerRect, targetRect) {
  var detached = !target.isConnected;
  var intersectRect = !detached ? computeIntersection(containerRect, targetRect) : emptyRect;
  var intersects = intersectRect.width > 0 && intersectRect.height > 0;
  var intersecRatio = intersects ? getArea(intersectRect) / getArea(targetRect) : 0;
  return {
    rect: intersectRect,
    ratio: intersecRatio,
    exists: intersects
  };
}
function throttleRaf(func) {
  var timer = null;
  var trigger = () => {
    if (timer) return;
    timer = requestAnimationFrame(() => {
      timer = null;
      func();
    });
  };
  return trigger;
}
var generateMiniProgramIntersectionObserver = (onReRender, offReRender) => {
  var _IntersectionObserverController;
  class IntersectionObserverController {
    static getInstance() {
      if (!this._instance) {
        this._instance = new IntersectionObserverController();
      }
      return this._instance;
    }
    constructor() {
      this._connected = false;
      this._observers = new Set();
      this.refresh = throttleRaf(this.refresh.bind(this));
    }
    addObserver(observer) {
      this._observers.add(observer);
      if (!this._connected) this._connect();
    }
    removeObserver(observer) {
      this._observers.delete(observer);
      if (this._observers.size === 0 && this._connected) this._disconnect();
    }
    refresh() {
      this._observers.forEach(observer => {
        observer.refresh();
      });
    }
    _connect() {
      if (this._connected) return;
      onReRender(this.refresh);
      this._connected = true;
    }
    _disconnect() {
      if (!this._connected) return;
      offReRender(this.refresh);
      this._connected = false;
    }
  }
  _IntersectionObserverController = IntersectionObserverController;
  IntersectionObserverController._instance = null;
  class IntersectionObservation {
    constructor(target, observer, _prevRatio = -1) {
      this.target = target;
      this.observer = observer;
      this._prevRatio = _prevRatio;
      this._prevTargetRect = emptyRect;
      this._prevThreshold = 0;
      this._prevThreshold = getThresholdGreaterThan(observer.thresholds, this._prevRatio);
    }
    updateIntersection(rootRect) {
      var targetRect = getRectangle(this.target);
      var intersection = getIntersectionData(this.target, rootRect, targetRect);
      var threshold = intersection.exists && !isEmpty(targetRect) ? getThresholdGreaterThan(this.observer.thresholds, intersection.ratio) : intersection.exists ? 1 : 0;
      var ratioChanged = intersection.ratio !== this._prevRatio;
      var targetRectChanged = !isEqual(targetRect, this._prevTargetRect);
      var thresholdChanged = threshold !== this._prevThreshold;
      this._prevTargetRect = targetRect;
      this._prevThreshold = threshold;
      this._prevRatio = intersection.ratio;
      return {
        intersection,
        targetRect,
        ratioChanged,
        thresholdChanged,
        targetRectChanged
      };
    }
  }
  class MiniProgramIntersectionObserver {
    constructor(_callback, options) {
      this._callback = _callback;
      this.relatives = void 0;
      this.thresholds = void 0;
      this.initialRatio = void 0;
      this._added = false;
      this._observations = new Map();
      this._controller = IntersectionObserverController.getInstance();
      this._entries = [];
      this._callbackScheduled = false;
      if (typeof _callback !== 'function') {
        throw new TypeError('The callback provided as parameter 1 is not a function.');
      }
      this.relatives = options.relatives;
      this.thresholds = Object.freeze(parseThresholds(options.threshold));
      this.initialRatio = options.initialRatio || 0;
    }
    _getRootRect() {
      return computeIntersection(...this.relatives.map(({
        node,
        margin
      }, i) => applyMargins(getRectangle(node || document.documentElement), margin)));
    }
    disconnect() {
      if (!this._added) return;
      this._added = false;
      this._observations.clear();
      this._controller.removeObserver(this);
    }
    observe(target) {
      if (!arguments.length) {
        throw new TypeError('1 argument required, but only 0 present.');
      }
      if (typeof Element === 'undefined' || !(Element instanceof Object)) {
        return;
      }
      if (!(target instanceof Element)) {
        throw new TypeError('parameter 1 is not of type "Element".');
      }
      if (this._observations.has(target)) return;
      var observation = new IntersectionObservation(target, this, this.initialRatio);
      this._observations.set(target, observation);
      if (!this._added) {
        this._controller.addObserver(this);
        this._added = true;
      }
      window.requestAnimationFrame(() => {
        if (this._added) this._initialRefresh(observation);
      });
    }
    unobserve(target) {
      if (!arguments.length) {
        throw new TypeError('1 argument required, but only 0 present.');
      }
      if (typeof Element === 'undefined' || !(Element instanceof Object)) {
        return;
      }
      if (!(target instanceof Element)) {
        throw new TypeError('parameter 1 is not of type "Element".');
      }
      if (!this._observations.has(target)) return;
      this._observations.delete(target);
      if (this._observations.size === 0 && this._added) {
        this._controller.removeObserver(this);
        this._added = false;
      }
    }
    _initialRefresh(observation) {
      var rootRect = this._getRootRect();
      var entries = this._entries;
      var result = observation.updateIntersection(rootRect);
      if (!result.thresholdChanged) return;
      entries.push({
        boundingClientRect: result.targetRect,
        intersectionRatio: result.intersection.ratio,
        intersectionRect: result.intersection.rect,
        isIntersecting: result.intersection.exists,
        rootBounds: rootRect,
        target: observation.target,
        time: Date.now()
      });
      this._scheduleCallback();
    }
    _scheduleCallback() {
      if (this._callbackScheduled) return;
      Promise.resolve().then(() => {
        this._callbackScheduled = false;
        var entries = this._entries;
        if (!entries.length) return;
        this._callback(entries);
        this._entries = [];
      });
      this._callbackScheduled = true;
    }
    refresh() {
      var rootRect = this._getRootRect();
      var entries = this._entries;
      this._observations.forEach(observation => {
        var result = observation.updateIntersection(rootRect);
        if (!result.thresholdChanged) return;
        entries.push({
          boundingClientRect: result.targetRect,
          intersectionRatio: result.intersection.ratio,
          intersectionRect: result.intersection.rect,
          isIntersecting: result.intersection.exists,
          rootBounds: rootRect,
          target: observation.target,
          time: Date.now()
        });
      });
      this._scheduleCallback();
    }
  }
  return MiniProgramIntersectionObserver;
};
;// CONCATENATED MODULE: ./src/utils/intersection.js




var useNativeIntersectionObserver = false;
__wxConfig.onReady(WXConfig => {
  var _WXConfig$expt;
  useNativeIntersectionObserver = !!Number(((_WXConfig$expt = WXConfig.expt) === null || _WXConfig$expt === void 0 ? void 0 : _WXConfig$expt.clicfg_appbrand_webview_native_intersection_observer) || 0);
});
var intersection_exparser = getExparser();
var intersectionObservers = {};
var attachObservers = {};
var listenerIdCountMap = {};
var filterBoundingFields = rect => ({
  left: rect.left,
  top: rect.top,
  right: rect.right,
  bottom: rect.bottom,
  width: rect.width,
  height: rect.height
});
var measureIntersect = (baseRect, newRect) => {
  var rect = {
    left: baseRect.left < newRect.left ? newRect.left : baseRect.left,
    top: baseRect.top < newRect.top ? newRect.top : baseRect.top,
    right: baseRect.right > newRect.right ? newRect.right : baseRect.right,
    bottom: baseRect.bottom > newRect.bottom ? newRect.bottom : baseRect.bottom,
    width: 0,
    height: 0
  };
  if (rect.right > rect.left) {
    rect.width = rect.right - rect.left;
  } else {
    rect.right = rect.left = rect.bottom = rect.top = 0;
  }
  if (rect.bottom > rect.top) {
    rect.height = rect.bottom - rect.top;
  } else {
    rect.right = rect.left = rect.bottom = rect.top = 0;
  }
  return rect;
};
var measureRelativeRect = /*#__PURE__*/function () {
  var _ref = external_BabelRuntimeHelpers_asyncToGenerator_default()(function* (relatives) {
    var clientWidth = __wxConfig.screenWidth || 500;
    var clientHeight = __wxConfig.screenHeight || 1000;
    var retRect = null;
    var _loop = function* () {
      var {
        node,
        margins
      } = relatives[i];
      var boundingRect = node ? yield yield new Promise(resolve => {
        node.$$.getBoundingClientRect(rect => resolve(rect));
      }) : {
        left: 0,
        top: 0,
        right: clientWidth,
        bottom: clientHeight,
        width: clientWidth,
        height: clientHeight
      };
      var rect = {
        left: boundingRect.left - margins.left,
        top: boundingRect.top - margins.top,
        right: boundingRect.right + margins.right,
        bottom: boundingRect.bottom + margins.bottom
      };
      if (retRect) retRect = measureIntersect(retRect, rect);else retRect = rect;
    };
    for (var i = 0; i < relatives.length; i++) {
      yield* _loop();
    }
    return retRect;
  });
  return function measureRelativeRect(_x) {
    return _ref.apply(this, arguments);
  };
}();
var normalizeMarginRect = margins => ({
  left: margins.left || 0,
  top: margins.top || 0,
  right: margins.right || 0,
  bottom: margins.bottom || 0
});
var marginRectToMarginString = ({
  left,
  top,
  right,
  bottom
}) => `${top}px ${right}px ${bottom}px ${left}px`;
var intersection_getThresholdGreaterThan = (thresholds, ratio) => {
  var thresholdsLen = thresholds.length;
  var l = 0;
  var r = thresholdsLen;
  var m;
  while (l !== r) {
    m = l + r >> 1;
    if (thresholds[m] <= ratio) {
      l = m + 1;
    } else {
      r = m;
    }
  }
  return l;
};
var registerIntersectionObserverHappyPath = (targetNode, relatives, thresholds, initialRatio, cb) => {
  var initialThreshold = intersection_getThresholdGreaterThan(initialRatio);
  var [{
    node,
    margins
  }] = relatives;
  var observer = new window.IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (initialThreshold !== null && initialThreshold === intersection_getThresholdGreaterThan(thresholds, entry.isIntersecting ? entry.intersectionRatio : -1)) return;
      var targetNode = entry.target.__wxElement;
      cb({
        id: targetNode.id,
        dataset: targetNode.dataset,
        time: Date.now(),
        boundingClientRect: entry.boundingClientRect,
        intersectionRatio: entry.intersectionRatio,
        intersectionRect: entry.intersectionRect,
        relativeRect: entry.rootBounds
      });
    });
    initialThreshold = null;
  }, {
    root: node ? node.$$ : null,
    rootMargin: marginRectToMarginString(margins),
    threshold: thresholds
  });
  return observer;
};
var registerIntersectionObserverFastPath = (targetNode, relatives, thresholds, initialRatio, cb) => {
  var nativeObservers;
  var MiniProgramIntersectionObserver = generateMiniProgramIntersectionObserver(refresh => {
    nativeObservers = relatives.map(({
      node,
      margins
    }) => {
      var firstCallback = true;
      var observer = new window.IntersectionObserver(() => {
        if (firstCallback) {
          firstCallback = false;
          return;
        }
        nativeObservers.forEach(nativeObserver => nativeObserver.takeRecords());
        refresh();
      }, {
        root: node ? node.$$ : null,
        rootMargin: marginRectToMarginString(margins),
        threshold: thresholds.length === 1 && thresholds[0] === 0 ? [0] : Array(101).fill(null).map((_, i) => i / 100)
      });
      observer.observe(targetNode.$$);
      return observer;
    });
  }, () => {
    nativeObservers.forEach(observer => observer.disconnect());
    nativeObservers = null;
  });
  var observer = new MiniProgramIntersectionObserver(entries => {
    entries.forEach(entry => {
      var targetNode = entry.target.__wxElement;
      cb({
        id: targetNode.id,
        dataset: targetNode.dataset,
        time: Date.now(),
        boundingClientRect: entry.boundingClientRect,
        intersectionRatio: entry.intersectionRatio,
        intersectionRect: entry.intersectionRect,
        relativeRect: entry.rootBounds
      });
    });
  }, {
    initialRatio,
    threshold: thresholds,
    relatives: relatives.map(({
      node,
      margins
    }) => ({
      node: node ? node.$$ : null,
      margin: margins
    }))
  });
  return observer;
};
var SlowPathMiniProgramIntersectionObserver;
var registerIntersectionObserverSlowPath = (targetNode, relatives, thresholds, initialRatio, cb) => {
  if (!SlowPathMiniProgramIntersectionObserver) {
    SlowPathMiniProgramIntersectionObserver = generateMiniProgramIntersectionObserver(cb => {
      document.addEventListener('pageReRender', cb);
      window.addEventListener('scroll', cb, {
        capture: true,
        passive: true
      });
    }, cb => {
      document.removeEventListener('pageReRender', cb);
      window.removeEventListener('scroll', cb, {
        capture: true
      });
    });
  }
  var observer = new SlowPathMiniProgramIntersectionObserver(entries => {
    entries.forEach(entry => {
      var targetNode = entry.target.__wxElement;
      cb({
        id: targetNode.id,
        dataset: targetNode.dataset,
        time: Date.now(),
        boundingClientRect: entry.boundingClientRect,
        intersectionRatio: entry.intersectionRatio,
        intersectionRect: entry.intersectionRect,
        relativeRect: entry.rootBounds
      });
    });
  }, {
    initialRatio,
    threshold: thresholds,
    relatives: relatives.map(({
      node,
      margins
    }) => ({
      node: node ? node.$$ : null,
      margin: margins
    }))
  });
  return observer;
};
var observeIntersection = (targetNodes, relatives, thresholds, initialRatio, cb) => {
  var listenerGroupId = utils_guid();
  if (!targetNodes.length || !relatives.length) return listenerGroupId;
  if (currentRenderBackend() === 'webview') {
    listenerIdCountMap[listenerGroupId] = targetNodes.length;
    if (initialRatio === 0) {
      initialRatio = -1;
    }
    targetNodes.forEach((targetNode, targetNodeIndex) => {
      var relativeToAncestorCount = relatives.filter(relative => {
        if (!relative.node) return true;
        var node = relative.node.$$;
        var cur = targetNode.$$;
        var foundAncestor = false;
        while (cur) {
          if (cur === node) {
            foundAncestor = true;
            break;
          }
          cur = cur.parentNode;
        }
        return foundAncestor;
      }).length;
      var listenerId = `${listenerGroupId}#${targetNodeIndex}`;
      var intersectionObserver;
      if (!useNativeIntersectionObserver || relativeToAncestorCount !== relatives.length) {
        intersectionObserver = registerIntersectionObserverSlowPath(targetNode, relatives, thresholds, initialRatio, cb);
      } else if (relatives.length !== 1) {
        intersectionObserver = registerIntersectionObserverFastPath(targetNode, relatives, thresholds, initialRatio, cb);
      } else {
        intersectionObserver = registerIntersectionObserverHappyPath(targetNode, relatives, thresholds, initialRatio, cb);
      }
      intersectionObservers[listenerId] = intersectionObserver;
      var attachObserver = intersection_exparser.Observer.create(e => {
        if (e.status === 'attached') {
          intersectionObserver.observe(targetNode.$$);
        } else if (e.status === 'detached') {
          intersectionObserver.disconnect();
        }
      });
      attachObservers[listenerId] = attachObserver;
      attachObserver.observe(targetNode, {
        attachStatus: true
      });
      if (intersection_exparser.Element.isAttached(targetNode)) {
        intersectionObserver.observe(targetNode.$$);
      }
    });
  } else if (currentRenderBackend() === 'skyline') {
    var observerCount = targetNodes.length;
    listenerIdCountMap[listenerGroupId] = observerCount;
    targetNodes.forEach((targetNode, i) => {
      var _listenerInfo$relativ;
      var listenerId = listenerGroupId + '#' + i;
      var listenerInfo = {
        targetNode,
        relatives,
        thresholds,
        currentRatio: initialRatio,
        cb
      };
      var skylineCore = getSkylineRuntimeCore();
      var marginRect = normalizeMarginRect((_listenerInfo$relativ = listenerInfo.relatives[0]) === null || _listenerInfo$relativ === void 0 ? void 0 : _listenerInfo$relativ.margins);
      var rootMargin = [marginRect.top, marginRect.right, marginRect.bottom, marginRect.left];
      var observer = new skylineCore.intersectionObserver(/*#__PURE__*/function () {
        var _ref2 = external_BabelRuntimeHelpers_asyncToGenerator_default()(function* (res) {
          var {
            targetNode
          } = listenerInfo;
          var relativeRect = yield measureRelativeRect(listenerInfo.relatives);
          cb({
            id: targetNode.id,
            dataset: targetNode.dataset,
            time: Date.now(),
            boundingClientRect: res[0].boundingClientRect,
            intersectionRatio: res[0].intersectionRatio,
            intersectionRect: filterBoundingFields(res[0].intersectionRect),
            relativeRect
          });
        });
        return function (_x2) {
          return _ref2.apply(this, arguments);
        };
      }(), {
        rootMargin,
        thresholds: listenerInfo.thresholds
      });
      intersectionObservers[listenerId] = observer;
      observer.observe(targetNode.$$);
    });
  }
  return listenerGroupId;
};
var addIntersectionObserver = (shadowRoot, targetSelector, relativeInfo, options, cb, source = 'internal') => {
  options = options || {};
  var targetNodes = null;
  if (options.observeAll) {
    targetNodes = shadowRoot.querySelectorAll(targetSelector);
  } else {
    var selected = shadowRoot.querySelector(targetSelector);
    if (selected) targetNodes = [selected];else targetNodes = [];
  }
  if (!targetNodes.length) console.warn('For developer:Node "' + targetSelector + '" is not found. Intersection observer will not trigger.');
  targetNodes = targetNodes.filter(targetNode => {
    if (!targetNode.$$) {
      console.warn('For developer:Node "' + targetSelector + '" is virtual. Intersection observer will not trigger.');
      return false;
    }
    return true;
  });
  var relatives = [];
  relativeInfo.forEach(rel => {
    var {
      selector,
      margins
    } = rel;
    var node = selector == null ? null : shadowRoot.querySelector(selector);
    if (!node && selector != null) console.warn('For developer:Node "' + selector + '" is not found. The relative node for intersection observer will be ignored.');else relatives.push({
      node,
      margins: normalizeMarginRect(margins || {})
    });
  });
  if (!relatives.length) console.warn('For developer:Intersection observer will be ignored because no relative nodes are found.');
  var thresholds = options.thresholds && Array.isArray(options.thresholds) ? options.thresholds.filter(threshold => 0 <= threshold && threshold <= 1) : [0];
  return observeIntersection(targetNodes, relatives, thresholds.length ? thresholds : [0], options.initialRatio || 0, cb);
};
var removeIntersectionObserver = listenerGroupId => {
  var count = listenerIdCountMap[listenerGroupId];
  delete listenerIdCountMap[listenerGroupId];
  for (var i = 0; i < count; i++) {
    var listenerId = listenerGroupId + '#' + i;
    var intersectionObserver = intersectionObservers[listenerId];
    if (intersectionObserver) {
      intersectionObserver.disconnect();
      delete intersectionObservers[listenerId];
    }
    var attachObserver = attachObservers[listenerId];
    if (attachObserver) {
      attachObserver.disconnect();
      delete attachObservers[listenerId];
    }
  }
};
var setViewObserver = (req, tm, resFunc) => {
  if (req.type === 'addIntersectionObserver') {
    var shadowRoot = null;
    if (req.nodeId) {
      var host = tm.nodeId.getNodeById(req.nodeId);
      if (!host) return undefined;
      shadowRoot = host.shadowRoot;
    } else if (!req.pluginId) {
      shadowRoot = window.__DOMTree__.shadowRoot;
    }
    if (!shadowRoot) return undefined;
    var observerId = addIntersectionObserver(shadowRoot, req.targetSelector, req.relativeInfo, req.options, info => {
      var res = {
        info
      };
      resFunc(res);
    }, 'user');
    return {
      observerId
    };
  } else if (req.type === 'removeIntersectionObserver') {
    var _observerId = req.observerId;
    removeIntersectionObserver(_observerId);
    return {
      reqEnd: true
    };
  }
  return undefined;
};
;// CONCATENATED MODULE: ./src/utils/match_media.js
var observerIdInc = 1;
var observerIdMap = {};
var composeMediaQueryObject = obj => {
  if (typeof obj !== 'object') {
    return '';
  }
  var query = '';
  ['minWidth', 'maxWidth', 'width', 'minHeight', 'maxHeight', 'height'].forEach(field => {
    if (obj[field] === undefined) return;
    var val = Number(obj[field]);
    if (!(val >= 0)) val = '';
    var dashed = field.replace(/[A-Z]/g, x => '-' + x.toLowerCase());
    if (query) query += ' and ';
    query += `(${dashed}: ${val}px)`;
  });
  ['orientation'].forEach(field => {
    if (obj[field] === undefined) return;
    var val = /^[-_a-z0-9]+$/i.test(obj[field]) ? obj[field] : '';
    var dashed = field.replace(/[A-Z]/g, x => '-' + x.toLowerCase());
    if (query) query += ' and ';
    query += `(${dashed}: ${val})`;
  });
  return query;
};
var addMediaQueryObserver = (mediaQueryCond, listener) => {
  var media = composeMediaQueryObject(mediaQueryCond);
  var observer = window.matchMedia(media);
  var observerId = observerIdInc++;
  var wrapped = e => {
    listener({
      matches: e.matches
    });
  };
  observerIdMap[observerId] = {
    observer,
    listener: wrapped
  };
  observer.addListener(wrapped);
  listener({
    matches: observer.matches
  });
  return observerId;
};
var removeMediaQueryObserver = observerId => {
  var {
    observer,
    listener
  } = observerIdMap[observerId];
  observer.removeListener(listener);
  delete observerIdMap[observerId];
};
var setMediaQueryObserver = (req, resFunc) => {
  if (req.type === 'addMediaQueryObserver') {
    var observerId = addMediaQueryObserver(req.mediaQueryCond, info => {
      var res = {
        info
      };
      resFunc(res);
    });
    return {
      observerId
    };
  } else if (req.type === 'removeMediaQueryObserver') {
    var _observerId = req.observerId;
    removeMediaQueryObserver(_observerId);
    return {
      reqEnd: true
    };
  }
  return undefined;
};
;// CONCATENATED MODULE: ./src/utils/worklet_animation.js



function _applyAnimatedStyleForNative(styleInfo, pageId, nodes, selector) {
  var {
    updaterId,
    userConfig
  } = styleInfo;
  var skylineRuntime = getSkylineRuntime();
  var animatedStyle = skylineRuntime.proxyCreateAnimatedStyle(pageId, updaterId, userConfig);
  var {
    mapperId
  } = animatedStyle;
  var validEleNum = 0;
  nodes.forEach(ele => {
    if (ele.__virtual) {
      console.warn(`applyAnimatedStyle can not be used on virtual component, selector(${selector})`);
      return;
    }
    ele.$$.addAnimatedStyle(animatedStyle);
    validEleNum++;
  });
  if (validEleNum === 0) {
    skylineRuntime.proxyStopMapper(pageId, mapperId);
    console.warn(`applyAnimatedStyle can not find valid element, selector(${selector})`);
  }
  return mapperId;
}
function _applyAnimatedStyleForWeb(styleInfo, _pageId, nodes, selector) {
  var {
    shouldAttach,
    mapperId,
    updateStyle
  } = styleInfo;
  var validEleNum = 0;
  nodes.forEach(ele => {
    if (ele.__virtual) {
      console.warn(`applyAnimatedStyle can not be used on virtual component, selector(${selector})`);
      return;
    }
    var attachedMapperIds = ele.$$.__worklet_animatedStyle_mapperIds__ || [];
    if (shouldAttach) {
      attachedMapperIds.push(mapperId);
      ele.$$.__worklet_animatedStyle_mapperIds__ = attachedMapperIds;
    }
    if (attachedMapperIds.indexOf(mapperId) >= 0) {
      Object.keys(updateStyle || {}).forEach(prop => {
        ele.$$.style[prop] = updateStyle[prop];
      });
    }
    validEleNum++;
  });
  if (validEleNum === 0) {
    console.warn(`applyAnimatedStyle can not find valid element, selector(${selector})`);
  }
  return mapperId;
}
function worklet_animation_applyAnimatedStyle(args, tm) {
  var {
    hasCallback,
    reqId,
    nodeId,
    pageId,
    selector,
    data
  } = args[0];
  var {
    renderer,
    styleInfo
  } = data;
  var shadowTree = tm.nodeId.getNodeById(nodeId);
  if (shadowTree) {
    shadowTree = shadowTree.shadowRoot;
  } else {
    shadowTree = window.__DOMTree__ ? window.__DOMTree__.shadowRoot : null;
  }
  var styleId = undefined;
  var nodes = shadowTree ? shadowTree.querySelectorAll(selector) : [];
  if (renderer === 'skyline') {
    styleId = _applyAnimatedStyleForNative(styleInfo, pageId, nodes, selector);
  } else if (renderer === 'webview') {
    styleId = _applyAnimatedStyleForWeb(styleInfo, pageId, nodes, selector);
  }
  if (hasCallback) {
    bridge_sendData(constants_SYNC_EVENT_NAME.APPLY_NODE_ANIMATED_STYLE_END, {
      reqId,
      styleId
    }, tm.viewId);
  }
}
function worklet_animation_clearAnimatedStyle(args, tm) {
  var {
    hasCallback,
    reqId,
    nodeId,
    selector,
    renderer,
    styleIds
  } = args[0];
  var shadowTree = tm.nodeId.getNodeById(nodeId);
  if (shadowTree) {
    shadowTree = shadowTree.shadowRoot;
  } else {
    shadowTree = window.__DOMTree__ ? window.__DOMTree__.shadowRoot : null;
  }
  var nodes = shadowTree ? shadowTree.querySelectorAll(selector) : [];
  nodes.forEach(ele => {
    if (ele.__virtual) {
      console.warn(`clearAnimatedStyle can not be used on virtual component, selector(${selector})`);
      return;
    }
    var removeMapperIds = Array.isArray(styleIds) ? styleIds : [styleIds];
    if (renderer === 'skyline') {
      if (typeof ele.$$.clearAnimatedStyle === 'function') {
        ele.$$.clearAnimatedStyle(removeMapperIds);
      }
    } else {
      var attachedMapperIds = ele.$$.__worklet_animatedStyle_mapperIds__ || [];
      removeMapperIds.forEach(mapperId => {
        var index = attachedMapperIds.indexOf(mapperId);
        if (index >= 0) attachedMapperIds.splice(index, 1);
      });
    }
  });
  if (hasCallback) {
    bridge_sendData(constants_SYNC_EVENT_NAME.CLEAR_NODE_ANIMATED_STYLE_END, {
      reqId
    }, tm.viewId);
  }
}
;// CONCATENATED MODULE: ./src/operation_flow.js











var operation_flow_exparser = getExparser();
class OperationIterator {
  constructor(treeManager, arr, startCb) {
    this._treeManager = treeManager;
    this._arr = arr;
    this._depth = 0;
    this._startCb = startCb;
  }
  _consumeHead() {
    var head = this._arr.shift();
    return head;
  }
  nextStepType() {
    return this._arr[0][0];
  }
  nextStep() {
    while (this._arr[0][0] === constants_SYNC_EVENT_NAME.FLOW_DEPTH) {
      this._startCb(this._treeManager);
    }
    if (this._arr[0][0] === constants_SYNC_EVENT_NAME.FLOW_REPEAT) {
      var loopSeg = this._arr[0][2];
      if (! --this._arr[0][1]) this._consumeHead();
      return [loopSeg];
    }
    return this._consumeHead();
  }
  nextStepIf(type) {
    while (this._arr[0][0] === constants_SYNC_EVENT_NAME.FLOW_DEPTH) {
      this._startCb(this._treeManager);
    }
    if (this._arr[0][0] === type) {
      return this._consumeHead();
    }
    return null;
  }
  expectStart() {
    var step = this._consumeHead();
    this._depth++;
    if (step[0] !== constants_SYNC_EVENT_NAME.FLOW_DEPTH || step[1] !== this._depth) {
      throw new Error(`Framework inner error (expect START descriptor with depth ${this._depth} but get ${getEvName(step[0])})`);
    }
    return step[2];
  }
  expectEnd() {
    while (this._arr[0][0] === constants_SYNC_EVENT_NAME.FLOW_DEPTH && this._arr[0][1] !== this._depth - 1) {
      this._startCb(this._treeManager);
    }
    var step = this._consumeHead();
    this._depth--;
    if (step[0] !== constants_SYNC_EVENT_NAME.FLOW_DEPTH || step[1] !== this._depth) {
      throw new Error(`Framework inner error (expect END descriptor with depth ${this._depth} but get ${getEvName(step[0])})`);
    }
  }
  skipToEnd() {
    while (this._arr[0]) {
      if (this._arr[0][0] === constants_SYNC_EVENT_NAME.FLOW_DEPTH) {
        if (this._arr[0][1] === this._depth - 1) {
          break;
        } else {
          this._startCb(this._treeManager);
          continue;
        }
      }
      this._consumeHead();
    }
  }
  getQueueLength() {
    return this._arr.length;
  }
  getDepth() {
    return this._depth;
  }
}
class OperationFlow {
  constructor(viewId, treeManager) {
    var _this = this;
    this._viewId = viewId;
    this._treeManager = treeManager;
    this._depth = 0;
    this._curWinSize = 0;
    this._setDataCallbackInc = 1;
    this._pendingSetDataCallbacks = [];
    this._setDataCallbackMap = {};
    this._received = [];
    this._cache = [];
    this._blocked = [];
    this._isBlocked = true;
    this._fetchingViewInfoCallbacks = [];
    var listener = (data, ev) => {
      this._received.push([ev].concat(data));
      if (ev === constants_SYNC_EVENT_NAME.FLOW_DEPTH) {
        this._depth = data[0];
        if (this._depth === 0) {
          var ret = this._received;
          this._received = [];
          if (this._isBlocked) {
            this._blocked.push(ret);
          } else {
            this.iterator = new OperationIterator(this._treeManager, ret, OperationFlow._startCb);
            OperationFlow._startCb(this._treeManager);
            this.onFinished();
          }
        }
      }
    };
    var _loop = function () {
      if (k.slice(0, 5) !== 'FLOW_') return 1;
      if (k === 'FLOW_SET_DATA') {
        setDataListener(constants_SYNC_EVENT_NAME[k], ([id]) => {
          _this._pendingSetDataCallbacks.push(id);
        }, viewId);
      } else if (k === 'FLOW_VIEW_INFO') {
        var responseViewInfo = /*#__PURE__*/function () {
          var _ref = external_BabelRuntimeHelpers_asyncToGenerator_default()(function* ([type, data, reqId]) {
            var res = null;
            if (type === 'selectorQuery') {
              res = yield getViewInfo(data, _this._treeManager);
            } else if (type === 'intersection') {
              res = setViewObserver(data, _this._treeManager, res => {
                bridge_sendData(constants_SYNC_EVENT_NAME.RESPONSE_VIEW_INFO, [res, reqId], _this._viewId);
              });
            } else if (type === 'matchMedia') {
              res = setMediaQueryObserver(data, res => {
                bridge_sendData(constants_SYNC_EVENT_NAME.RESPONSE_VIEW_INFO, [res, reqId], _this._viewId);
              });
            }
            if (res) {
              bridge_sendData(constants_SYNC_EVENT_NAME.RESPONSE_VIEW_INFO, [res, reqId], _this._viewId);
            }
          });
          return function responseViewInfo(_x) {
            return _ref.apply(this, arguments);
          };
        }();
        setDataListener(constants_SYNC_EVENT_NAME[k], args => {
          if (_this._received.length || _this._isBlocked) {
            _this._fetchingViewInfoCallbacks.push(responseViewInfo.bind(_this, args));
          } else {
            responseViewInfo(args);
          }
        }, viewId);
      } else if (k === 'FLOW_SET_NODE_ANIMATION_INFO') {
        setDataListener(constants_SYNC_EVENT_NAME[k], args => {
          if (args[0].type === 'scrollTimeline') {
            if (currentRenderBackend() === 'webview') {
              bindScrollAnimations(args[0], _this._treeManager);
            } else if (currentRenderBackend() === 'skyline') {
              console.warn("component rendered with skyline does not support timeline animation, 'animate' call will be ignored.");
            }
          } else {
            setNodeAnimationInfo(args[0]);
          }
        }, viewId);
      } else if (k === 'FLOW_CLEAR_NODE_ANIMATION_INFO') {
        setDataListener(constants_SYNC_EVENT_NAME[k], args => {
          clearNodeAnimationInfo(args[0]);
        }, viewId);
      } else if (k === 'FLOW_SET_NODE_ANIMATED_STYLE') {
        setDataListener(constants_SYNC_EVENT_NAME[k], args => {
          if (_this._received.length || _this._isBlocked) {
            _this._fetchingViewInfoCallbacks.push(worklet_animation_applyAnimatedStyle.bind(null, args, _this._treeManager));
          } else {
            worklet_animation_applyAnimatedStyle(args, _this._treeManager);
          }
        }, viewId);
      } else if (k === 'FLOW_CLEAR_NODE_ANIMATED_STYLE') {
        setDataListener(constants_SYNC_EVENT_NAME[k], args => {
          worklet_animation_clearAnimatedStyle(args, _this._treeManager);
        }, viewId);
      } else if (k === 'FLOW_SET_NODE_NEXT_ANIMATION_INFO') {
        setDataListener(constants_SYNC_EVENT_NAME[k], args => {
          setNodeNextAnimationInfo(args[0]);
        }, viewId);
      } else {
        setDataListener(constants_SYNC_EVENT_NAME[k], listener, viewId);
      }
    };
    for (var k of Object.keys(constants_SYNC_EVENT_NAME)) {
      if (_loop()) continue;
    }
    setDataListener(constants_SYNC_EVENT_NAME.SET_DATA_CALLBACK, ([ids]) => {
      this.triggerSetDataCallbacks(ids);
    }, viewId);
  }
  flushBlocked() {
    while (this._blocked.length && !this._isBlocked) {
      try {
        var ret = this._blocked.shift();
        this.iterator = new OperationIterator(this._treeManager, ret, OperationFlow._startCb);
        OperationFlow._startCb(this._treeManager);
        this.onFinished();
      } catch (error) {
        console.error(error.message);
        Reporter.errorReport({
          key: 'webviewScriptError',
          error
        });
      }
    }
  }
  unblock() {
    this._isBlocked = false;
    this.flushBlocked();
  }
  block() {
    if (!this._isBlocked) this._isBlocked = true;
  }
  sendInIndividualFlow(data) {
    this.start(Date.now());
    this.push(data);
    this.end();
  }
  start() {
    this.flush();
    this._depth++;
    bridge_sendData(constants_SYNC_EVENT_NAME.FLOW_DEPTH, [this._depth, Date.now()], this._viewId);
  }
  dedupe() {
    var cache = this._cache;
    if (!this._curWinSize) {
      var found = 0;
      if (cache.length > 2 && cache[0][0] === cache[1][0] && cache[0][0] === cache[2][0]) {
        if (cache[0][0] !== constants_SYNC_EVENT_NAME.FLOW_SET_DATA && cache[0][0] !== constants_SYNC_EVENT_NAME.FLOW_VIEW_INFO) {
          found = 1;
        }
      }
      if (found) {
        var loopSeg = cache[0][0];
        cache.splice(0, 3);
        this.flush();
        this._curWinSize = 1;
        cache.unshift([constants_SYNC_EVENT_NAME.FLOW_REPEAT, 3, loopSeg]);
      } else {
        if (cache.length > 3) {
          var data = cache.pop();
          var ev = data.shift();
          bridge_sendData(ev, data, this._viewId);
        }
      }
    } else {
      if (cache.length === 2) {
        var _loopSeg = cache[1][2];
        if (cache[0][0] !== _loopSeg) {
          var _data = cache.pop();
          var _ev = _data.shift();
          bridge_sendData(_ev, _data, this._viewId);
        } else {
          cache.shift();
          cache[0][1]++;
        }
      }
    }
  }
  push(data) {
    this._cache.unshift(data);
    if (data.length !== 1) this.flush();else this.dedupe();
  }
  flush() {
    this._curWinSize = 0;
    while (this._cache.length) {
      var data = this._cache.pop();
      var ev = data.shift();
      bridge_sendData(ev, data, this._viewId);
    }
  }
  end() {
    this.flush();
    this._depth--;
    bridge_sendData(constants_SYNC_EVENT_NAME.FLOW_DEPTH, this._depth, this._viewId);
    if (this._depth === 0) {
      flushDataBuffer();
    }
  }
  checkDelayFetchingViewInfo() {
    if (this._fetchingViewInfoCallbacks.length) {
      var arr = this._fetchingViewInfoCallbacks;
      this._fetchingViewInfoCallbacks = [];
      arr.forEach(func => func());
    }
  }
  registerSetDataCallback(cb, comp, exparserNode) {
    var id = this._setDataCallbackInc++;
    this._setDataCallbackMap[id] = [cb, comp, exparserNode];
    this.push([constants_SYNC_EVENT_NAME.FLOW_SET_DATA, id]);
  }
  triggerSetDataCallbacks(ids) {
    for (var i = 0; i < ids.length; i++) {
      var id = ids[i];
      if (this._setDataCallbackMap[id]) {
        var [cb, comp, exparserNode] = this._setDataCallbackMap[id];
        delete this._setDataCallbackMap[id];
        operation_flow_exparser.safeCallback('SetData Callback', cb, comp, [], exparserNode);
      } else {
        wxNativeConsole.error(`setDataCallback error`);
      }
    }
  }
  onFinished() {
    wx.triggerPageReRender();
    if (currentRenderBackend() === 'skyline') {
      var skylineRuntime = getSkylineRuntime();
      if (this._viewId === SKYLINE_TABBAR_VIEW_ID) {
        if (this._treeManager.__attached) {
          skylineRuntime.getTabBarContext().startRender(() => {
            wxNativeConsole.info('[Skyline.Critical] tabbar startRender callback, doing nothing.');
          });
        } else {
          wxNativeConsole.error('[OperationFlow] [Skyline.Critical] tabBar startRender ignored, because root element is not attached (may be due to some unexpected error). pageId=' + this._viewId);
        }
      } else {
        if (this._treeManager.__attached !== true) {
          wxNativeConsole.error('[OperationFlow] [Skyline.Critical] startRender ignored, because root element is not attached (may be due to some unexpected error). pageId=' + this._viewId);
        } else {
          if (!viewStartRenderSet.has(this._viewId)) {
            viewStartRenderSet.add(this._viewId);
            traceInstant('Framework', 'firstStartRender');
          }
          skylineRuntime.getContext(this._viewId).startRender(() => {
            wxNativeConsole.info('[Skyline.Critical] page startRender callback, doing nothing. pageId=' + this._viewId);
          });
        }
      }
    }
    if (!this._blocked.length) {
      bridge_sendData(constants_SYNC_EVENT_NAME.SET_DATA_CALLBACK, [this._pendingSetDataCallbacks], this._viewId, true);
      this._pendingSetDataCallbacks = [];
      this.checkDelayFetchingViewInfo();
    }
  }
  static setStartOperation(cb) {
    OperationFlow._startCb = cb;
  }
}
/* harmony default export */ const operation_flow = (OperationFlow);
;// CONCATENATED MODULE: ./src/comp_api/tree_manager.ts






var idTmMap = Object.create(null);
class tree_manager_TreeManager {
  constructor(viewId) {
    this.viewId = void 0;
    this.listenerInited = void 0;
    this.root = null;
    this.tabRoot = null;
    this.tabDestroyed = void 0;
    this.usedDef = null;
    this.tabUsedDef = null;
    this.statesData = null;
    this.operationFlow = void 0;
    this.nodeId = new node_id();
    this.compManager = void 0;
    this.rootNodeId = '';
    this.tabNodeId = '';
    this.rootCompName = '';
    this.tabCompName = '';
    this.applyAnimationCbMap = {};
    this.clearAnimationCbMap = {};
    this.animatedStyleCbMap = {};
    this.viewInfoCbMap = {};
    this.initialRootData = null;
    this.lifetimeListener = null;
    this.viewId = viewId;
    this.operationFlow = new operation_flow(viewId, this);
    this.compManager = new ComponentManager(viewId, this);
  }
  static create(viewId) {
    var ret = new tree_manager_TreeManager(viewId);
    idTmMap[viewId] = ret;
    return ret;
  }
  static destroy(viewId) {
    delete idTmMap[viewId];
  }
  static get(viewId) {
    return idTmMap[viewId];
  }
  static listViewId() {
    var ret = [];
    for (var k of Object.keys(idTmMap)) {
      ret.push(idTmMap[k].viewId);
    }
    return ret;
  }
  static list() {
    var ret = [];
    for (var k of Object.keys(idTmMap)) {
      ret.push(idTmMap[k]);
    }
    return ret;
  }
  static getByNode(node) {
    if (isDataThread()) return node.__treeManager__;
    if (currentRenderBackend() === 'webview') return tree_manager_TreeManager.get(0);
    if (currentRenderBackend() === 'scl') return tree_manager_TreeManager.get(SCL_TABBAR_VIEW_ID);
    return tree_manager_TreeManager.get(node.__backendContext.id);
  }
}
/* harmony default export */ const tree_manager = (tree_manager_TreeManager);
;// CONCATENATED MODULE: ./src/hot_update_view.js

var enableUpdateWxAppCode = function () {
  enableUpdateListener();
};
var blocking = [];
var updateWxAppCode = function (path, data) {
  var listener = updateListener[path];
  if (!listener) {
    if (blocking) {
      blocking.push({
        path,
        data
      });
    }
    return undefined;
  }
  wxConsole.log('Hot updated: ' + path);
  hot_update_updatedWxAppCode[path] = data;
  __wxAppCode__[path] = data;
  return listener(data);
};
var unblockWxAppCode = function () {
  var queue = blocking;
  blocking = [];
  queue.forEach(({
    path,
    data
  }) => updateWxAppCode(path, data));
};
;// CONCATENATED MODULE: ./src/xr-frame_view.js



var contextsEmitter = {};
var EV = 'contextReady';
setDataListener(constants_SYNC_EVENT_NAME.XR_FRAME_CANVAS_READY, (data, ev, xrFrameId) => {
  wxNativeConsole.info(`[xrFrameCreated] get canvasContext ${xrFrameId}`);
  var context = xrFrame.getOrCreateContext(xrFrameId, data[0], data[1]);
  context.id = xrFrameId;
  var emitter = getOrCreateEmitter(xrFrameId);
  emitter.notify(EV);
}, '$GLOBAL');
var getOrCreateEmitter = xrFrameId => {
  if (contextsEmitter[xrFrameId] === undefined) contextsEmitter[xrFrameId] = createPublishSubscribe([EV]);
  return contextsEmitter[xrFrameId];
};
var xrFrameContextReady = (xrFrameId, cb) => {
  var _cb = () => {
    wxNativeConsole.info('[xrFrameContextReady] emit context ready ' + xrFrameId);
    cb();
  };
  var emitter = getOrCreateEmitter(xrFrameId);
  if (emitter.isNotified(EV)) _cb();else emitter.on(EV, _cb);
};

;// CONCATENATED MODULE: ./src/spread_scope_data.js

var spread_scope_data_exparser = getExparser();
var dfsScopeDataToDOMNode = (node, scopeData) => {
  if (!(node instanceof spread_scope_data_exparser.Element)) return;
  if (node.__wxScopeData__ !== undefined) {
    scopeData = node.__wxScopeData__;
  }
  if (scopeData !== undefined && node instanceof spread_scope_data_exparser.Component) {
    node.setAttribute('wx:scope-data', JSON.stringify(scopeData));
  }
  var useChildNodes = false;
  if (node instanceof spread_scope_data_exparser.Component && !(node.shadowRoot instanceof spread_scope_data_exparser.Element)) {
    useChildNodes = true;
  }
  var children = useChildNodes ? node.childNodes : node.__wxSlotChildren;
  var childScopeData = node instanceof spread_scope_data_exparser.VirtualNode ? scopeData : undefined;
  for (var i = 0; i < children.length; i++) {
    var child = children[i];
    dfsScopeDataToDOMNode(child, childScopeData);
  }
};
var spreadScopeDataToDOMNode = () => {
  dfsScopeDataToDOMNode(window.__DOMTree__, undefined);
};
;// CONCATENATED MODULE: ./src/index.js









var src_exparser = getExparser();













if (typeof navigator !== 'undefined' && /wechatdevtools/.test(navigator.userAgent)) {
  setInDevtoolsWebView();
}
if (inDevtoolsWebview()) src_exparser.globalOptions.writeExtraInfoToAttr = true;
initViewThread();
registerResizeListener();
initBannedListener();
var customComponentMode = true;
var getMergeDataFunc = data => data;
var isPageExist = pageId => tree_manager.get(pageId) !== undefined;
var getRestoreState = () => save_restore_view_states;
var handleEarlyInitReady = callInitReady => {
  var benchmarkLevel = __wxConfig.benchmarkLevel || 24;
  if (currentRenderBackend() === 'skyline' && benchmarkLevel >= 23) {
    wxNativeConsole.info(`[startInitRender] [skyline] benchmarkLevel(${benchmarkLevel}) >= 23, calling initReady before unblocking operation flow`);
    callInitReady();
  }
};
var startInitRender = (pageId, callInitReady = () => {}, tracer) => {
  setTracer(tracer);
  if (currentRenderBackend() === 'webview') {
    wx._checkDeviceWidth(true);
  }
  runComponentDef(pageId);
  unblockWxAppCode();
  var tm = tree_manager.get(pageId);
  handleEarlyInitReady(callInitReady);
  tm.operationFlow.unblock();
};
var prepareInitRender = (pageId, cb) => {
  if (currentRenderBackend() === 'skyline') {
    getSkylineRuntime().onPageReady(pageId, cb);
    wxNativeConsole.info('[WABaseLib.Critical] skyline context ok, pageId=', pageId);
  } else if (currentRenderBackend() === 'xr-frame') {
    wxNativeConsole.info('[prepareInitRender] waiting for xrFrameContext, xrFrameId=', pageId);
    xrFrameContextReady(pageId, cb);
    wxNativeConsole.info('[prepareInitRender] xrFrameContext ok, xrFrameId=', pageId);
  } else if (currentRenderBackend() === 'webview') {
    cb();
  }
};
__virtualDOM__ = __webpack_exports__;
/******/ })()
;
var __webviewEngine__;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./src/base/globals.ts
var global =  false ? 0 : globalThis;
function getReporter() {
  return global.Reporter;
}
function reportViewLayerError(e, isUnhandledRejection = false) {
  ;
  global.Reporter.errorReport({
    key: 'webviewScriptError',
    error: e,
    isUnhandledRejection
  });
}
function reportViewLayerSDKError(e) {
  ;
  global.Reporter.errorReport({
    key:  false ? 0 : 'appSubContextSDKScriptError',
    error: e
  });
}
function reportExparserError(e) {
  ;
  global.Reporter.errorReport({
    key: 'exparserScriptError',
    error: e
  });
}
var WXConfig = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => {
  global.__wxConfig.onReady(() => {
    if (WXConfig !== global.__wxConfig && typeof WXConfig !== 'undefined') {
      Object.assign(WXConfig, global.__wxConfig);
    }
  });
  return global.__wxConfig;
})()));
var globals_virtualDOM = /* #__PURE__ */(() => global.__virtualDOM__)();
var _exparser = (() => {
  if (false) {}
  if (true) return __sclEngine__.exparser;
  if (false) {}
  return exparser;
})();

;// CONCATENATED MODULE: ./src/subcontext/init.ts
var __vd_version_info__ = {
  delayedGwx: false,
  genObject: false,
  globalThis,
  noCss: true
};
var init = () => {
  window.__webview_engine_version__ = 0.02;
  globalThis.__vd_version_info__ = window.__vd_version_info__ = __vd_version_info__;
};
;// CONCATENATED MODULE: ./src/subcontext/loadCode.ts

function injectCode(pageId, path) {
  wx.traceBeginEvent('Framework', 'viewEvaluateScript');
  var subPackage = virtualDOM.matchSubPackageName(path);
  var allPackages = [subPackage];
  if (!virtualDOM.isSubPackageIndependent(subPackage) && subPackage !== '__APP__') {
    allPackages.unshift('__APP__');
  }
  var entryFiles = allPackages.map(pkg => virtualDOM.getEntryFile(pkg, s => {
    wxNativeConsole.info(`[WebviewEngine] onViewRoute getEntryFiles: ${s}`);
  })).flat(1);
  var dispatchToVd = __webpack_require__.g.__mainPageFrameReady__;
  __webpack_require__.g.__mainPageFrameReady__ = () => {};
  __subContextEngine__.loadJsFiles(entryFiles);
  wx.traceEndEvent();
  dispatchToVd(pageId);
  __webpack_require__.g.__mainPageFrameReady__ = dispatchToVd;
}
function injectCodeAndStyleToScl(cb) {
  var entryFiles = globals_virtualDOM.getEntryFile('__APP__', s => {
    wxNativeConsole.info(`[CustomTabBar] injectCodeToScl getEntryFiles: ${s}`);
  });
  __subContextEngine__.loadJsFiles(entryFiles);
  __sclEngine__.loadStyleBincode('custom-tab-bar/index.fpcssb', cb);
}
;// CONCATENATED MODULE: ./src/subcontext/scl.ts



init();
__sclEngine__.setValidInit();
__sclEngine__.initScl(() => {
  injectCodeAndStyleToScl();
});
wx.subscribe('initTabBar', res => {
  wxNativeConsole.info('[CustomTabBar] recv initTabBar ' + JSON.stringify(res));
  if (__sclEngine__.isInitialized()) {
    globals_virtualDOM.newTabBar(res);
  } else {
    __sclEngine__.initScl(() => {
      globals_virtualDOM.newTabBar(res);
    });
  }
});
__webviewEngine__ = __webpack_exports__;
/******/ })()
;
var __WXML_GLOBAL__ = __WXML_GLOBAL__ || {entrys:{},defines:{},modules:{},ops:[],wxs_nf_init:undefined,total_ops:0};
var __vd_version_info__ = __vd_version_info__ || {};
var __wxAppCode__ = __wxAppCode__ || {};
var __WASclContextEndTime__ = Date.now() /* @snapshot-ignore Date.now */
typeof this.__wxLibrary.onEnd === 'function' && this.__wxLibrary.onEnd();
delete this.__wxLibrary;
//# sourceURL=WASclContext.js
