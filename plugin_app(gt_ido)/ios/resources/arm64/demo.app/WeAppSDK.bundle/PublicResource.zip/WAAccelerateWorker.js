
;(function (global) { /* LIBRARY_CLOSURE_START (global) */

var __wxConfig = global.WXConfig;
Foundation.env.workerType = 'accelerate'
Foundation.env.typeStr = 'accelerateWorker';

/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/************************************************************************/

;// CONCATENATED MODULE: ./src/base/errorType.ts
class AppServiceSdkKnownError extends Error {
  constructor(msg) {
    super(`APP-SERVICE-SDK:${msg}`);
    this.type = 'AppServiceSdkKnownError';
  }
}
class ThirdScriptError extends Error {
  constructor(...args) {
    super(...args);
    this.type = 'ThirdScriptError';
  }
}
if (typeof IS_WAGAME === 'boolean' && IS_WAGAME) {
  Object.freeze(ThirdScriptError);
  Object.freeze(ThirdScriptError.prototype);
}

;// CONCATENATED MODULE: ./src/base/util/base64.ts

var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
function btoa(input) {
  if (typeof globalThis.btoa === 'function') return globalThis.btoa(input);
  var str = String(input);
  var output = '';
  for (var block, charCode, idx = 0, map = chars; str.charAt(idx | 0) || (map = '=', idx % 1); output += map.charAt(63 & block >> 8 - idx % 1 * 8)) {
    charCode = str.charCodeAt(idx += 3 / 4);
    if (charCode > 0xff) {
      throw new AppServiceSdkKnownError('btoa failed');
    }
    block = block << 8 | charCode;
  }
  return output;
}
function atob(input) {
  if (typeof globalThis.atob === 'function') return globalThis.atob(input);
  var str = String(input).replace(/=+$/, '');
  var output = '';
  if (str.length % 4 === 1) {
    throw new AppServiceSdkKnownError(`atob failed: invalid string length ${str.length}`);
  }
  for (var bc = 0, bs, buffer, idx = 0; buffer = str.charAt(idx++); ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer, bc++ % 4) ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6)) : 0) {
    buffer = chars.indexOf(buffer);
  }
  return output;
}
function arrayBufferToBase64(buffer) {
  var binaryString = '';
  var bytes;
  if (ArrayBuffer.isView(buffer) && buffer.constructor.name === 'Uint8Array') {
    bytes = buffer;
  } else {
    bytes = new Uint8Array(buffer);
  }
  var len = bytes.byteLength;
  for (var i = 0; i < len; i++) {
    binaryString += String.fromCharCode(bytes[i]);
  }
  return btoa(binaryString);
}
function base64ToArrayBuffer(base64) {
  var binaryString = atob(base64);
  var len = binaryString.length;
  var bytes = new Uint8Array(len);
  for (var i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}
var base64Encode = str => btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (match, p1) => String.fromCharCode('0x' + p1)));
var base64Decode = str => decodeURIComponent(atob(str).split('').map(c => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join(''));
var base64UrlEncode = str => base64Encode(str).split('=')[0].replace(/\+/g, '-').replace(/\//g, '_');
var base64UrlDecode = str => base64Decode(str.replace(/-/g, '+').replace(/_/g, '/').padEnd(str.length + (4 - str.length % 4) % 4, '='));
;// CONCATENATED MODULE: ./src/accelerate-worker/aes/aes128-wasm.js

var WebAssembly = _WebAssembly;
var pkcs7Pad = data => {
  var padLength = ~(data.length & 0xf) + 17;
  var resultLength = data.length + padLength;
  var result = new Uint8Array(resultLength);
  result.set(data, 0);
  for (var i = data.length; i < resultLength; i++) {
    result[i] = padLength;
  }
  return result;
};
var pkcs7Strip = data => data.slice(0, data.length - data[data.length - 1]);
var initAesWasm = () => {
  var OFFSET_AES_CTX = 0x0e00;
  var OFFSET_BUFFER = 0x1000;
  var WASM_MEMORY_LENGTH = 0x10000;
  var AES_BLOCKLEN = 16;
  var AES_KEYLEN = 16;
  var AES_KEYEXPSIZE = 176;
  var cryptFunctionName = {
    L: {
      C: 't',
      M: 'O',
      s: 'a',
      P: 'b',
      Q: 'q'
    },
    H: {
      C: 'v',
      M: 'x',
      s: 'D',
      P: 'b',
      Q: 'q'
    }
  };
  var wasmMemory = new WebAssembly.Memory({
    initial: 1
  });
  var wasmHeapU8 = new Uint8Array(wasmMemory.buffer);
  var wasmExports;
  var wasmReady = new Promise(resolve => WebAssembly.instantiate(base64ToArrayBuffer('AGFzbQEAAAAAEAhkeWxpbmsuMAEFkAQEAAABDwNgA39/fwBgAn9/AGAAAAI7AwNlbnYPX19zdGFja19wb2ludGVyA38BA2Vudg1fX21lbW9yeV9iYXNlA38AA2VudgZtZW1vcnkCAAEDERACAQEAAQEBAAEBAAAAAAAAB0EMEV9fd2FzbV9jYWxsX2N0b3JzAAABcAABAWUAAwFoAAQBdAAFAXYACAFPAAoBeAALAWEADAFEAA0BYgAOAXEADwqKKBADAAELCAAgACABEAILjAMBCX8gACABLQAAOgAAIAAgAS0AAToAASAAIAEtAAI6AAIgACABLQADOgADIAAgAS0ABDoABCAAIAEtAAU6AAUgACABLQAGOgAGIAAgAS0ABzoAByAAIAEtAAg6AAggACABLQAJOgAJIAAgAS0ACjoACiAAIAEtAAs6AAsgACABLQAMOgAMIAAgAS0ADToADSAAIAEtAA46AA4gACABLQAPOgAPQQQhAwNAIANBAnQiBSAAaiICQQFrLQAAIQQgAkECay0AACEHIAJBA2stAAAhBiACQQRrLQAAIQgCfyADQQNxBEAgBCEJIAghCiAHDAELIwEiAUGAAmogA0ECdmotAAAgASAGai0AAHMhCiABIAhqLQAAIQkgASAHai0AACEGIAEgBGotAAALIQQgAiACQRBrLQAAIApzOgAAIAAgBUEBcmogAkEPay0AACAGczoAACAAIAVBAnJqIAJBDmstAAAgBHM6AAAgACAFQQNyaiACQQ1rLQAAIAlzOgAAIANBAWoiA0EsRw0ACwseACAAIAEQAiAAIAIpAAg3ALgBIAAgAikAADcAsAELGAAgACABKQAANwCwASAAIAEpAAg3ALgBCwgAIAEgABAGC70JARt/QQAgACABEAdBASEWA0AgACMBIgIgAC0AAGotAAAiEToAACAAIAIgAC0ABGotAAAiEjoABCAAIAIgAC0ACGotAAAiEzoACCAAIAIgAC0ADGotAAAiFDoADCAALQABIQMgACACIAAtAAVqLQAAIhU6AAEgAC0AAyEQIAAtAAchBCAALQAPIQYgAC0ACyEFIAAtAA4hCSAALQAGIQogAC0ACiELIAAtAAIhDCAALQAJIQ0gAC0ADSEOIAAgAiADai0AACIPOgANIAAgAiAOai0AACIOOgAJIAAgAiANai0AACINOgAFIAAgAiAMai0AACIMOgAKIAAgAiALai0AACILOgACIAAgAiAKai0AACIKOgAOIAAgAiAJai0AACIJOgAGIAAgAiAFai0AACIDOgAPIAAgAiAGai0AACIGOgADIAAgAiAEai0AACIEOgALIAAgAiAQai0AACICOgAHIBZB/wFxIhhBCkZFBEAgACAKIA8gFHMiEHMiGSADIBRzIgVBAXRzIAVBGHRBGHVBB3ZBG3FzOgAPIAAgAyAQcyADIApzIgVBAXRzIAVBGHRBGHVBB3ZBG3FzOgAOIAAgDCAOIBNzIgVzIhogBCATcyIHQQF0cyAHQRh0QRh1QQd2QRtxczoACyAAIAQgBXMgBCAMcyIHQQF0cyAHQRh0QRh1QQd2QRtxczoACiAAIAkgDSAScyIHcyIbIAIgEnMiCEEBdHMgCEEYdEEYdUEHdkEbcXM6AAcgACACIAdzIAIgCXMiCEEBdHMgCEEYdEEYdUEHdkEbcXM6AAYgACALIBEgFXMiCHMiHCAGIBFzIhdBAXRzIBdBGHRBGHVBB3ZBG3FzOgADIAAgBiAIcyAGIAtzIhdBAXRzIBdBGHRBGHVBB3ZBG3FzOgACIAAgAyAZcyIDIA8gCiAPcyIPQQF0cyAPQRh0QRh1QQd2QRtxc3M6AA0gACAQQRh0QRh1QQd2QRtxIBBBAXQgFHNzIANzOgAMIAAgBCAacyIDIAwgDnMiBEEBdCAOcyAEQRh0QRh1QQd2QRtxc3M6AAkgACAFQRh0QRh1QQd2QRtxIAVBAXQgE3NzIANzOgAIIAAgAiAbcyICIAkgDXMiA0EBdCANcyADQRh0QRh1QQd2QRtxc3M6AAUgACAHQRh0QRh1QQd2QRtxIAdBAXQgEnNzIAJzOgAEIAAgBiAccyICIAsgFXMiA0EBdCAVcyADQRh0QRh1QQd2QRtxc3M6AAEgACAIQRh0QRh1QQd2QRtxIAhBAXQgEXNzIAJzOgAAIBggACABEAcgFkEBaiEWDAELCyAAIAEtAKABIBFzOgAAIAAgAS0AoQEgFXM6AAEgACABLQCiASALczoAAiAAIAEtAKMBIAZzOgADIAAgAS0ApAEgEnM6AAQgACABLQClASANczoABSAAIAEtAKYBIAlzOgAGIAAgAS0ApwEgAnM6AAcgACABLQCoASATczoACCAAIAEtAKkBIA5zOgAJIAAgAS0AqgEgDHM6AAogACABLQCrASAEczoACyAAIAEtAKwBIBRzOgAMIAAgAS0ArQEgD3M6AA0gACABLQCuASAKczoADiAAIAEtAK8BIANzOgAPC4oCACABIAEtAAAgAiAAQQR0aiIALQAAczoAACABIAEtAAEgAC0AAXM6AAEgASABLQACIAAtAAJzOgACIAEgAS0AAyAALQADczoAAyABIAEtAAQgAC0ABHM6AAQgASABLQAFIAAtAAVzOgAFIAEgAS0ABiAALQAGczoABiABIAEtAAcgAC0AB3M6AAcgASABLQAIIAAtAAhzOgAIIAEgAS0ACSAALQAJczoACSABIAEtAAogAC0ACnM6AAogASABLQALIAAtAAtzOgALIAEgAS0ADCAALQAMczoADCABIAEtAA0gAC0ADXM6AA0gASABLQAOIAAtAA5zOgAOIAEgAS0ADyAALQAPczoADwsIACABIAAQCQv8BQETf0EKIAAgARAHQQkhDwNAIAAjAUGQAmoiAiAALQAAai0AADoAACAAIAIgAC0ABGotAAA6AAQgACACIAAtAAhqLQAAOgAIIAAtAAchBCAALQALIQUgAC0ADyEGIAAtAAMhByAALQAKIQggAC0ADiEJIAAtAAIhCiAALQAGIQsgAC0ADSEMIAAtAAEhDSAALQAFIQ4gAC0ACSEDIAAgAiAALQAMai0AADoADCAAIAIgA2otAAA6AA0gACACIA5qLQAAOgAJIAAgAiANai0AADoABSAAIAIgDGotAAA6AAEgACACIAtqLQAAOgAOIAAgAiAKai0AADoACiAAIAIgCWotAAA6AAYgACACIAhqLQAAOgACIAAgAiAHai0AADoADyAAIAIgBmotAAA6AAsgACACIAVqLQAAOgAHIAAgAiAEai0AADoAAyAPQf8BcSICIAAgARAHQQAhCCACBEADQCAAIAhBAnRqIgIgAiwAAiIEQQd2QRtxIARBAXRzIgkgAiwAAyIFQQd2QRtxIAVBAXRzIgMgAiwAASIGIAIsAAAiB3NzIhQgBXNzIAdBGXRBGHVBB3ZBG3EgB0EHdkEbcSAHQQF0cyIKQQF0cyIQcyAEQRl0QRh1QQd2QRtxIAlBAXRzIhFzIApBGXRBGHVBB3ZBG3EgEEEBdHMiC3MgBkEHdkEbcSAGQQF0cyIMQRl0QRh1QQd2QRtxIAZBGXRBGHVBB3ZBG3EgDEEBdHMiEkEBdHMiDXMgCUEZdEEYdUEHdkEbcSARQQF0cyIOcyADQRl0QRh1QQd2QRtxIAVBGXRBGHVBB3ZBG3EgA0EBdHMiE0EBdHMiA3M6AAIgAiAFIAQgBnMgCnNzIAxzIBBzIBFzIAtzIA1zIA5zIANzOgAAIAIgBCAUcyAKcyAScyALcyATcyANcyAOcyADczoAAyACIAUgBCAHc3MgDHMgCXMgEnMgC3MgE3MgDXMgDnMgA3M6AAEgCEEBaiIIQQRHDQALIA9BAWshDwwBCwsLzQIBBH8gAEGwAWoiBSEDIAIEQCAFIQQDQCABIgMgAy0AACAELQAAczoAACADIAMtAAEgBC0AAXM6AAEgAyADLQACIAQtAAJzOgACIAMgAy0AAyAELQADczoAAyADIAMtAAQgBC0ABHM6AAQgAyADLQAFIAQtAAVzOgAFIAMgAy0ABiAELQAGczoABiADIAMtAAcgBC0AB3M6AAcgAyADLQAIIAQtAAhzOgAIIAMgAy0ACSAELQAJczoACSADIAMtAAogBC0ACnM6AAogAyADLQALIAQtAAtzOgALIAMgAy0ADCAELQAMczoADCADIAMtAA0gBC0ADXM6AA0gAyADLQAOIAQtAA5zOgAOIAMgAy0ADyAELQAPczoADyADIAAQBiADQRBqIQEgAyEEIAZBEGoiBiACSQ0ACwsgBSADKQAANwAAIAUgAykACDcACAvyAgECfyMAQRBrIgMkACACBEADQCADIAEpAAA3AwAgAyABQQhqKQAANwMIIAEgABAJIAEgAS0AACAALQCwAXM6AAAgASABLQABIAAtALEBczoAASABIAEtAAIgAC0AsgFzOgACIAEgAS0AAyAALQCzAXM6AAMgASABLQAEIAAtALQBczoABCABIAEtAAUgAC0AtQFzOgAFIAEgAS0ABiAALQC2AXM6AAYgASABLQAHIAAtALcBczoAByABIAEtAAggAC0AuAFzOgAIIAEgAS0ACSAALQC5AXM6AAkgASABLQAKIAAtALoBczoACiABIAEtAAsgAC0AuwFzOgALIAEgAS0ADCAALQC8AXM6AAwgASABLQANIAAtAL0BczoADSABIAEtAA4gAC0AvgFzOgAOIAEgAS0ADyAALQC/AXM6AA8gACADKQMINwC4ASAAIAMpAwA3ALABIAFBEGohASAEQRBqIgQgAkkNAAsLIANBEGokAAvUAgECfyACBEAgAEGwAWohAwNAIAMgABAGIAEgAS0AACAALQCwAXM6AAAgASABLQABIAAtALEBczoAASABIAEtAAIgAC0AsgFzOgACIAEgAS0AAyAALQCzAXM6AAMgASABLQAEIAAtALQBczoABCABIAEtAAUgAC0AtQFzOgAFIAEgAS0ABiAALQC2AXM6AAYgASABLQAHIAAtALcBczoAByABQQhqIAEtAAggAC0AuAFzOgAAIAEgAS0ACSAALQC5AXM6AAkgASABLQAKIAAtALoBczoACiABIAEtAAsgAC0AuwFzOgALIAEgAS0ADCAALQC8AXM6AAwgASABLQANIAAtAL0BczoADSABIAEtAA4gAC0AvgFzOgAOIAEgAS0ADyAALQC/AXM6AA8gAyABKQAINwAIIAMgASkAADcAACABQRBqIQEgBEEQaiIEIAJJDQALCwv4AgEDfyMAQRBrIgMkACACBEAgAEGwAWohBANAIAMgASkAADcDACADIAFBCGopAAA3AwggBCAAEAYgASABLQAAIAAtALABczoAACABIAEtAAEgAC0AsQFzOgABIAEgAS0AAiAALQCyAXM6AAIgASABLQADIAAtALMBczoAAyABIAEtAAQgAC0AtAFzOgAEIAEgAS0ABSAALQC1AXM6AAUgASABLQAGIAAtALYBczoABiABIAEtAAcgAC0AtwFzOgAHIAEgAS0ACCAALQC4AXM6AAggASABLQAJIAAtALkBczoACSABIAEtAAogAC0AugFzOgAKIAEgAS0ACyAALQC7AXM6AAsgASABLQAMIAAtALwBczoADCABIAEtAA0gAC0AvQFzOgANIAEgAS0ADiAALQC+AXM6AA4gASABLQAPIAAtAL8BczoADyAEIAMpAwg3AAggBCADKQMANwAAIAFBEGohASAFQRBqIgUgAkkNAAsLIANBEGokAAu9AgECfyACBEAgAEGwAWohBANAIAQgABAGIAEgAS0AACAALQCwAXM6AAAgASABLQABIAAtALEBczoAASABIAEtAAIgAC0AsgFzOgACIAEgAS0AAyAALQCzAXM6AAMgASABLQAEIAAtALQBczoABCABIAEtAAUgAC0AtQFzOgAFIAEgAS0ABiAALQC2AXM6AAYgASABLQAHIAAtALcBczoAByABIAEtAAggAC0AuAFzOgAIIAEgAS0ACSAALQC5AXM6AAkgASABLQAKIAAtALoBczoACiABIAEtAAsgAC0AuwFzOgALIAEgAS0ADCAALQC8AXM6AAwgASABLQANIAAtAL0BczoADSABIAEtAA4gAC0AvgFzOgAOIAEgAS0ADyAALQC/AXM6AA8gAUEQaiEBIANBEGoiAyACSQ0ACwsLhwUBFH8jAEEQayIFJAAgAgRAIABBsQFqIQcgAEGyAWohCCAAQbMBaiEJIABBtAFqIQogAEG1AWohCyAAQbYBaiEMIABBtwFqIQ0gAEG4AWohDiAAQbkBaiEPIABBugFqIRAgAEG7AWohESAAQbwBaiESIABBvQFqIRMgAEG+AWohFCAAQb8BaiEWIABBsAFqIQZBECEDA0ACQCADQRBHDQAgBSAGKQAANwMAIAUgBikACDcDCCAFIAAQBiAWIQQCQCAALQC/ASIDQf8BRw0AIBZBADoAACAUIQQgFC0AACIDQf8BRw0AIBRBADoAACATIQQgEy0AACIDQf8BRw0AIBNBADoAACASIQQgEi0AACIDQf8BRw0AIBJBADoAACARIQQgES0AACIDQf8BRw0AIBFBADoAACAQIQQgEC0AACIDQf8BRw0AIBBBADoAACAPIQQgDy0AACIDQf8BRw0AIA9BADoAACAOIQQgDi0AACIDQf8BRw0AIA5BADoAACANIQQgDS0AACIDQf8BRw0AIA1BADoAACAMIQQgDC0AACIDQf8BRw0AIAxBADoAACALIQQgCy0AACIDQf8BRw0AIAtBADoAACAKIQQgCi0AACIDQf8BRw0AIApBADoAACAJIQQgCS0AACIDQf8BRw0AIAlBADoAACAIIQQgCC0AACIDQf8BRw0AIAhBADoAACAHIQQgBy0AACIDQf8BRw0AIAdBADoAACAGIQQgBi0AACIDQf8BRw0AQQAhAyAGQQA6AAAMAQsgBCADQQFqOgAAQQAhAwsgASAVaiIEIAMgBWotAAAgBC0AAHM6AAAgA0EBaiEDIBVBAWoiFSACRw0ACwsgBUEQaiQACwuXBAEAIwELkARjfHd78mtvxTABZyv+16t2yoLJffpZR/Ct1KKvnKRywLf9kyY2P/fMNKXl8XHYMRUExyPDGJYFmgcSgOLrJ7J1CYMsGhtuWqBSO9azKeMvhFPRAO0g/LFbasu+OUpMWM/Q76r7Q00zhUX5An9QPJ+oUaNAj5KdOPW8ttohEP/z0s0ME+xfl0QXxKd+PWRdGXNggU/cIiqQiEbuuBTeXgvb4DI6CkkGJFzC06xikZXkeefIN22N1U6pbFb06mV6rgi6eCUuHKa0xujddB9LvYuKcD61ZkgD9g5hNVe5hsEdnuH4mBFp2Y6Umx6H6c5VKN+MoYkNv+ZCaEGZLQ+wVLsWjQECBAgQIECAGzYAAAAAAFIJatUwNqU4v0CjnoHz1/t84zmCmy//hzSOQ0TE3unLVHuUMqbCIz3uTJULQvrDTgguoWYo2SSydluiSW2L0SVy+PZkhmiYFtSkXMxdZbaSbHBIUP3tudpeFUZXp42dhJDYqwCMvNMK9+RYBbizRQbQLB6Pyj8PAsGvvQMBE4prOpERQU9n3OqX8s/O8LTmc5asdCLnrTWF4vk36Bx1325H8RpxHSnFiW+3Yg6qGL4b/FY+S8bSeSCa28D+eM1a9B/dqDOIB8cxsRIQWSeA7F9gUX+pGbVKDS3lep+TyZzvoOA7Ta4q9bDI67s8g1OZYRcrBH66d9Ym4WkUY1UhDH0='), {
    env: {
      memory: wasmMemory,
      __memory_base: 0x0000,
      __stack_pointer: new WebAssembly.Global({
        mutable: true,
        value: 'i32'
      }, 0x0e00)
    }
  }).then(result => {
    wasmExports = result.instance.exports;
    resolve();
  }));
  var initContext = (initFunction, key, iv) => {
    wasmHeapU8.set(key, OFFSET_AES_CTX + AES_KEYEXPSIZE + AES_BLOCKLEN);
    iv && wasmHeapU8.set(iv, OFFSET_AES_CTX + AES_KEYEXPSIZE);
    initFunction(OFFSET_AES_CTX, OFFSET_AES_CTX + AES_KEYEXPSIZE + AES_BLOCKLEN, OFFSET_AES_CTX + AES_KEYEXPSIZE);
  };
  class AES {
    constructor(key = null, iv = null) {
      this._key = key;
      this._iv = iv;
    }
    crypt(operation, mode, buffer, key = this._key, iv = this._iv) {
      if ((mode === 'C' || mode === 'M') && buffer.length % AES_BLOCKLEN) {
        throw new Error(`Buffer length must be evenly divisible by ${AES_BLOCKLEN} in ECB/CBC mode`);
      }
      if (!(mode in cryptFunctionName[operation])) {
        throw new Error('Invalid mode');
      }
      if (key.length !== AES_KEYLEN) {
        throw new Error(`Key length must be ${AES_KEYLEN}`);
      }
      if (mode !== 'C' && iv.length !== AES_BLOCKLEN) {
        throw new Error(`IV length must be ${AES_BLOCKLEN}`);
      }
      var cryptFunction = wasmExports[cryptFunctionName[operation][mode]];
      initContext(wasmExports[mode === 'C' ? 'p' : 'e'], key, iv);
      var result = new Uint8Array(buffer.length);
      var cryptedLength = 0;
      while (cryptedLength < buffer.length) {
        var sliceLength = mode === 'C' ? AES_BLOCKLEN : Math.min(buffer.length - cryptedLength, WASM_MEMORY_LENGTH - OFFSET_BUFFER);
        wasmHeapU8.set(buffer.subarray(cryptedLength, cryptedLength + sliceLength), OFFSET_BUFFER);
        cryptFunction(OFFSET_AES_CTX, OFFSET_BUFFER, sliceLength);
        result.set(wasmHeapU8.subarray(OFFSET_BUFFER, OFFSET_BUFFER + sliceLength), cryptedLength);
        cryptedLength += sliceLength;
      }
      return result;
    }
    encrypt(mode, buffer, key, iv) {
      return this.crypt('L', mode, buffer, key, iv);
    }
    decrypt(mode, buffer, key, iv) {
      return this.crypt('H', mode, buffer, key, iv);
    }
  }
  AES.MODE_ECB = 'C';
  AES.MODE_CBC = 'M';
  AES.MODE_CFB = 's';
  AES.MODE_OFB = 'P';
  AES.MODE_CTR = 'Q';
  return wasmReady.then(() => AES);
};
var initing;
var init = () => {
  if (!initing) {
    initing = initAesWasm();
  }
  return initing;
};
;// CONCATENATED MODULE: ./src/accelerate-worker/aes/encryptWithAesWASM.js

function encryptWithAesWASM(textBytes, encryptKeyBytes, ivBytes) {
  textBytes = pkcs7Pad(textBytes);
  return init().then(AES => {
    var aesApi = new AES();
    var encryptedBytes = aesApi.encrypt(AES.MODE_CBC, textBytes, encryptKeyBytes, ivBytes);
    return encryptedBytes;
  });
}
;// CONCATENATED MODULE: ./src/accelerate-worker/utils/utf8.js
var codePointAt = function (str, b) {
  var c = str + '';
  var d = c.length;
  var e = b ? +b : 0;
  if (e != e && (e = 0), !(0 > e || e >= d)) {
    var g;
    var f = c.charCodeAt(e);
    return 55296 <= f && 56319 >= f && d > e + 1 && (g = c.charCodeAt(e + 1), 56320 <= g && 57343 >= g) ? 1024 * (f - 55296) + g - 56320 + 65536 : f;
  }
};
var fromCodePoint = function () {
  var f = [];
  var g;
  var h;
  var i = -1;
  var j = arguments.length;
  if (!j) return '';
  var l;
  var k = '';
  for (; ++i < j;) {
    if (l = +arguments[i], !isFinite(l) || 0 > l || 1114111 < l || Math.floor(l) != l) throw RangeError('Invalid code point: ' + l);
    65535 >= l ? f.push(l) : (l -= 65536, g = (l >> 10) + 55296, h = l % 1024 + 56320, f.push(g, h)), (i + 1 == j || f.length > 16384) && (k += String.fromCharCode.apply(null, f), f.length = 0);
  }
  return k;
};
var countByte = str => {
  if (typeof str !== 'string' || str.length === 0) return 0;
  var byteLength = 0;
  var code;
  for (var i = 0; i < str.length; i++) {
    code = str.codePointAt(i);
    if (code > 0xd7ff && code < 0xe000) continue;
    if (code < 128) byteLength++;else if (code < 2048) byteLength += 2;else if (code < 65536) byteLength += 3;else if (code < 1114112) byteLength += 4;else throw new Error('Invalid char code');
  }
  return byteLength;
};
function utf8ToBytes(str, offsetInArray = 0) {
  var code;
  var i = 0;
  var t = offsetInArray;
  var bytes = str.length ? countByte(str) : 0;
  var byteLength = offsetInArray + bytes;
  var arr = new Uint8Array(byteLength >= 0 ? byteLength : 0);
  if (bytes === 0 || bytes !== -1 && arr.length === 0) return arr;
  for (; i < str.length; i++) {
    code = codePointAt(str, i);
    if (code > 0xd7ff && code < 0xe000 || t < 0) continue;
    if (code < 128) {
      arr[t++] = code;
    } else if (code < 2048) {
      arr[t++] = code >> 6 | 0xc0;
      arr[t++] = code & 0x3f | 0x80;
    } else if (code < 65536) {
      arr[t++] = code >> 12 | 0xe0;
      arr[t++] = code >> 6 & 0x3f | 0x80;
      arr[t++] = code & 0x3f | 0x80;
    } else if (code < 1114112) {
      arr[t++] = code >> 18 | 0xf0;
      arr[t++] = code >> 12 & 0x3f | 0x80;
      arr[t++] = code >> 6 & 0x3f | 0x80;
      arr[t++] = code & 0x3f | 0x80;
    } else throw new Error('Invalid char code');
  }
  return arr;
}
function bytesToUtf8(arr) {
  var chars = [];
  var u = 0;
  var tCode = 0;
  for (var i = 0; i < arr.length; i++) {
    if (u) {
      tCode |= (arr[i] & 0x3f) << 6 * --u;
      if (u === 0) {
        chars.push(fromCodePoint(tCode));
      }
      continue;
    }
    if ((arr[i] & 0xf0) === 0xf0) {
      u = 3;
    } else if ((arr[i] & 0xe0) === 0xe0) u = 2;else if ((arr[i] & 0xc0) === 0xc0) u = 1;else if ((arr[i] & 0x80) === 0) {
      chars.push(String.fromCharCode(arr[i]));
      continue;
    }
    tCode = (arr[i] & 255 >> u + 2) << u * 6;
  }
  return chars.join('');
}
;// CONCATENATED MODULE: ./src/accelerate-worker/aes/aesEncrypt.js



var aesEncrypt = args => {
  var {
    data,
    tokenInfo,
    useBinary,
    isArrayData
  } = args;
  var textBytes;
  if (isArrayData) {
    textBytes = new Uint8Array(data);
  } else if (!ArrayBuffer.isView(data)) {
    textBytes = utf8ToBytes(data);
  }
  var encryptKeyBytes = new Uint8Array(tokenInfo.encryptKeyBytes);
  var ivBytes = new Uint8Array(tokenInfo.ivBytes);
  return encryptWithAesWASM(textBytes, encryptKeyBytes, ivBytes).then(encryptedData => {
    if (useBinary) return encryptedData.buffer;
    var base64 = arrayBufferToBase64(encryptedData);
    return base64;
  });
};
;// CONCATENATED MODULE: ./src/accelerate-worker/aes/decryptWithAesWASM.js

function decryptWithAesWASM(data, encryptKeyBytes, ivBytes) {
  return init().then(AES => {
    var aesApi = new AES();
    var decryptdBytes = aesApi.decrypt(AES.MODE_CBC, data, encryptKeyBytes, ivBytes);
    decryptdBytes = pkcs7Strip(decryptdBytes);
    return decryptdBytes;
  });
}
;// CONCATENATED MODULE: ./src/accelerate-worker/aes/aesDecrypt.js



var aesDecrypt = args => {
  var {
    tokenInfo,
    data: base64text
  } = args;
  var ab;
  if (typeof base64text === 'string') {
    ab = base64ToArrayBuffer(base64text);
  } else {
    ab = new ArrayBuffer(0);
  }
  var bytes = new Uint8Array(ab);
  var encryptKeyBytes = new Uint8Array(tokenInfo.encryptKeyBytes);
  var ivBytes = new Uint8Array(tokenInfo.ivBytes);
  return decryptWithAesWASM(bytes, encryptKeyBytes, ivBytes).then(decryptedBytes => {
    var decryptedText = bytesToUtf8(decryptedBytes);
    return decryptedText;
  });
};
;// CONCATENATED MODULE: ./src/base/type.js
var Object$$toString = /* #__PURE__ */(() => Object.prototype.toString)();
var TO_STRING = /* #__PURE__ */Function.prototype.call.bind(Object$$toString);
function getDataType(data) {
  return TO_STRING(data).slice(8, -1);
}
function safeInstanceOf(x, constructor) {
  if (x == null) return false;
  return x instanceof constructor || x.constructor != null && x.constructor.name === constructor.name;
}
var isString = x => getDataType(x) === 'String';
var isNumber = x => getDataType(x) === 'Number';
var isBoolean = x => x === true || x === false || getDataType(x) === 'Boolean';
var isUndefined = x => x === undefined;
var isNull = x => x === null;
var type_isNaN = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Number.isNaN || (x => x !== x))()));
var type_isFinite = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Number.isFinite || (x => isNumber(x) && __webpack_require__.g.isFinite(x)))()));
var isInfinity = x => isNumber(x) && Math.abs(x) === Infinity;
var isInteger = value => type_isFinite(value) && Math.floor(value) === value;
var isBasicValue = x => ['string', 'number', 'boolean', 'undefined'].includes(typeof x);
var isObject = x => getDataType(x) === 'Object';
var isNonNullObject = x => isObject(x) && !isNull(x);
var isJustObject = x => getDataType(x) === 'Object';
var isArray = /* #__PURE__ */(/* unused pure expression or super */ null && ((() => Array.isArray || (x => getDataType(x) === 'Array'))()));
var isFunction = x => typeof x === 'function';
var isDate = x => getDataType(x) === 'Date';
var isRegExp = x => getDataType(x) === 'RegExp';
var isError = x => getDataType(x) === 'Error';
var isSymbol = x => getDataType(x) === 'Symbol';
var isMap = x => getDataType(x) === 'Map';
var isWeakMap = x => getDataType(x) === 'WeakMap';
var isSet = x => getDataType(x) === 'Set';
var isWeakSet = x => getDataType(x) === 'WeakSet';
var isPromise = x => getDataType(x) === 'Promise';
var isEmptyObject = x => {
  for (var p in x) return false;
  return true;
};
var isArrayBuffer = x => getDataType(x) === 'ArrayBuffer';
var isDataView = x => getDataType(x) === 'DataView';
var isTypedArray = x => ArrayBuffer.isView(x) && !isDataView(x);
var isVirtualNode = x => x && x.type === 'WxVirtualNode';
var isVirtualText = x => x && x.type === 'WxVirtualText';
function paramCheck(value, expect, dept = 'parameter') {
  var type = getDataType(expect);
  var valueType = getDataType(value);
  if (valueType !== type) {
    return `${dept} should be ${type} instead of ${valueType};`;
  }
  var result = '';
  switch (type) {
    case 'Object':
      Object.keys(expect).forEach(key => {
        result += paramCheck(value[key], expect[key], `${dept}.${key}`);
      });
      break;
    case 'Array':
      if (value.length < expect.length) {
        return `${dept} should have at least ${expect.length} item;`;
      }
      for (var i = 0; i < expect.length; ++i) {
        result += paramCheck(value[i], expect[i], `${dept}[${i}]`);
      }
      break;
    case 'String':
      if (expect.length > 0 && value.length === 0) {
        return `${dept} should be not empty string`;
      }
      break;
    default:
      break;
  }
  return result;
}
function safelyToString(value) {
  try {
    return JSON.stringify(value);
  } catch (e) {
    wxConsole.error(`safelyToString fail: '${e.message}'`);
    return '';
  }
}
function noop() {}
;// CONCATENATED MODULE: ./src/accelerate-worker/registerTask.js

var taskMap = new Map();
var taskCallback = (callbackId, result, errMsg) => {
  worker.postMessage({
    cmd: 'callback',
    callbackId,
    data: {
      result,
      errMsg
    }
  });
};
worker.onMessage(msg => {
  var {
    data,
    callbackId,
    cmd
  } = msg;
  var p;
  try {
    var fn = taskMap.get(cmd);
    if (typeof fn === 'function') {
      p = fn(data);
    }
  } catch (err) {
    taskCallback(callbackId, undefined, err.message);
  }
  if (isPromise(p)) {
    p.then(res => {
      taskCallback(callbackId, res);
    }).catch(err => {
      taskCallback(callbackId, undefined, err.message);
    });
  } else {
    taskCallback(callbackId, p);
  }
});
var registerTask = (taskName, fn) => {
  taskMap.set(taskName, fn);
};
;// CONCATENATED MODULE: ./src/baseService/serviceCheck/userCustomRule.ts
var generateRuleKey = rule => {
  if (rule.key) {
    return rule.key + '.' + rule.val;
  }
  return 'STR_' + rule.val;
};
var transformCustomRule2InterpreterRule = rule => {
  var key = generateRuleKey(rule);
  var interpreterRule = {
    key: 'userCustom:' + key,
    type: 'Pat',
    url: rule.url,
    test: {
      test: rule.key,
      flag: rule.flag || ''
    },
    withRely: [{
      key: 'userCustomWR:' + key + '_val',
      type: 'Pat',
      test: {
        test: rule.val,
        flag: rule.flag || ''
      }
    }]
  };
  return interpreterRule;
};
var transformCustomRule2InterpreterStrRule = rule => {
  var _rule$flag;
  var key;
  if (typeof rule !== 'string') key = generateRuleKey(rule);else key = 'STR_' + rule;
  var interpreterRule = {
    key: 'userCustom:' + key,
    type: 'Pat',
    url: rule === null || rule === void 0 ? void 0 : rule.url,
    test: {
      test: typeof rule === 'string' ? rule : rule.val,
      flag: typeof rule === 'string' ? 'i' : (_rule$flag = rule.flag) !== null && _rule$flag !== void 0 ? _rule$flag : 'i'
    }
  };
  return interpreterRule;
};
var transformUserCustomRules = rules => {
  var interpreterRules = rules.rules.map(rule => transformCustomRule2InterpreterRule(rule));
  var interpreterStrRules = rules.strRules.map(rule => transformCustomRule2InterpreterStrRule(rule));
  var priorities = {};
  Object.keys(rules.priority).forEach(k => {
    priorities['userCustom:' + k] = rules.priority[k];
  });
  return {
    object: {
      conditions: interpreterRules
    },
    string: {
      conditions: interpreterStrRules
    },
    priorities,
    schemaVersion: '9.9.99'
  };
};
var rawUserCustomRules;
var setRawUserCustomRules = rules => {
  rawUserCustomRules = rules;
};
var getRawUserCustomRules = () => rawUserCustomRules;

;// CONCATENATED MODULE: ./src/accelerate-worker/weAppRequestMayErrorInterpreter/general.js
var CUSTOM_RULE_NORMAL = -15;
var CUSTOM_RULE_ERROR = 15;

;// CONCATENATED MODULE: ./src/accelerate-worker/weAppRequestMayErrorInterpreter/interpreter/common.js
// #define MAGIC_PRIORITY 0.0329
var magicPriority = 0.0329;

;// CONCATENATED MODULE: ./src/accelerate-worker/weAppRequestMayErrorInterpreter/interpreter/reportRuleInterpreter.js


var returnTrueError = '__return_true';
var returnResolveResult = result => `__return_resolve_${result}`;
var tryTransformObject = str => {
  if (typeof str === 'string') {
    if (str.startsWith('[') || str.startsWith('{')) {
      try {
        str = JSON.parse(str);
      } catch (err) {}
    }
    return str;
  } else {
    return str;
  }
};
var isCondition = condition => condition.if || condition.test;
var handlePointKeyChain = keyChain => {
  try {
    return keyChain.map(key => key.join('.'));
  } catch (e) {
    return [];
  }
};
var judgeGeneralPriority = kc => {
  try {
    return kc.split('.')[0] + '.*';
  } catch (err) {
    return '';
  }
};
var handlePriority = (keyChain, priorities) => {
  var isMayNoError = false;
  var p = handlePointKeyChain(keyChain).reduce((sum, kc) => {
    var _priorities$kc, _priorities$kc2;
    var priority;
    var generalPriority = priorities[judgeGeneralPriority(kc)];
    if (generalPriority !== undefined) priority = generalPriority;else if (kc[0] === '-') priority = (_priorities$kc = priorities[kc]) !== null && _priorities$kc !== void 0 ? _priorities$kc : -0.5;else priority = (_priorities$kc2 = priorities[kc]) !== null && _priorities$kc2 !== void 0 ? _priorities$kc2 : 0.5;
    if (priority === magicPriority) isMayNoError = true;
    return sum + priority;
  }, 0);
  if (p > 0 && isMayNoError) return magicPriority;
  return p;
};
class Interpreter {
  constructor(schema, appid) {
    this.prunePointKV = kv => kv.map(d => this.pruneOriginData(d).data);
    if (typeof schema === 'string') schema = JSON.parse(schema);
    if (Object.prototype.toString.call(schema) !== '[object Object]') {
      schema = {
        object: {},
        string: {}
      };
    }
    this.objectSchema = schema.object;
    this.stringSchema = schema.string;
    this.schema = schema;
    this.preHandleSchema({
      appId: appid
    });
    this.priorities = schema.priorities || {};
  }
  getSchema() {
    return this.schema;
  }
  getSchemaVersion() {
    return this.schema.schemaVersion;
  }
  preHandleSchema(infos = {}) {
    var {
      appId
    } = infos;
    var traverse = conditions => {
      if (!Array.isArray(conditions)) return;
      conditions.forEach((condition, key) => {
        if (isCondition(condition)) {
          if (condition.specific) {
            if (condition.specific.type === 'include') {
              if (Array.isArray(condition.specific.data)) {
                if (!condition.specific.data.includes(appId)) {
                  delete conditions[key];
                  return;
                }
              }
            } else if (condition.specific.type === 'exclude') {
              if (Array.isArray(condition.specific.data)) {
                if (condition.specific.data.includes(appId)) {
                  delete conditions[key];
                  return;
                }
              }
            }
          }
          ;
          [condition.with, condition.withRely, condition.someWith, condition.someWithRely].forEach(condition => {
            traverse(condition);
          });
        }
      });
    };
    traverse(this.schema.object.conditions);
    traverse(this.schema.string.conditions);
  }
  _pruneOriginData(data, prune, infos = {}) {
    try {
      if (typeof data === 'number') {
        data = String(data);
      }
      if (typeof data === 'string') {
        if (prune.type === 'replace') {
          return prune.replace.reduce((s, r) => {
            var pat = new RegExp(r.test, r.flag);
            return s.replace(pat, $1 => {
              if (Array.isArray(infos.point)) {
                infos.point.push(r.tag);
              }
              if (r.modify === '$&') return $1;
              return r.modify;
            });
          }, data);
        } else return data;
      }
      if (typeof data === 'object' && data !== null) {
        Object.keys(data).forEach(key => {
          if (prune.type === 'match') {
            var pat = new RegExp(prune.test.test, prune.test.flag);
            if (!pat.test(key)) {
              if (prune.deep) data[key] = this._pruneOriginData(data[key], prune, infos);
              return;
            }
            if (prune.rely) data[key] = this._pruneOriginData(data[key], prune.rely, infos);else if (prune.replace != undefined) data[key] = prune.replace;
            return;
          } else {
            if (prune.deep) data[key] = this._pruneOriginData(data[key], prune, infos);
          }
        });
        return data;
      }
    } catch (err) {
      return null;
    }
    return null;
  }
  pruneOriginData(data) {
    var prunes = typeof data === 'string' ? this.stringSchema.prunes : this.objectSchema.prunes;
    var infos = {
      point: []
    };
    if (!prunes || !prunes.length) {} else {
      prunes.forEach(prune => {
        if (typeof data === 'string') data = this._pruneOriginData(data, prune, infos);else this._pruneOriginData(data, prune, infos);
      });
    }
    return {
      data,
      infos
    };
  }
  _resolvePendingCondition(conditions, conditionStatus, status, pending = []) {
    if (!status) return false;
    if (status.status !== 'pending') {
      if (status.status === 'resolve') return true;else return false;
    }
    if (pending.includes(status.key)) return false;
    var allRely = true;
    var hasPush = false;
    pending.push(status.key);
    for (var peer of status.peers) {
      var _conditionStatus$peer;
      if (pending.includes(peer.key)) continue;
      if (((_conditionStatus$peer = conditionStatus[peer.key]) === null || _conditionStatus$peer === void 0 ? void 0 : _conditionStatus$peer.status) === 'pending') {
        var nextStatus = {
          ...conditionStatus[peer.key],
          key: peer.key
        };
        var ret = this._resolvePendingCondition(conditions, conditionStatus, nextStatus, pending.concat(peer.key));
        if (peer.not) ret = !ret;
        if (!ret) allRely = false;
      } else {
        if (peer.not) {
          var _conditionStatus$peer2;
          if (((_conditionStatus$peer2 = conditionStatus[peer.key]) === null || _conditionStatus$peer2 === void 0 ? void 0 : _conditionStatus$peer2.status) === 'resolve') allRely = false;
        } else {
          var _conditionStatus$peer3, _conditionStatus$peer4;
          if (!((_conditionStatus$peer3 = conditionStatus[peer.key]) !== null && _conditionStatus$peer3 !== void 0 && _conditionStatus$peer3.status) || ((_conditionStatus$peer4 = conditionStatus[peer.key]) === null || _conditionStatus$peer4 === void 0 ? void 0 : _conditionStatus$peer4.status) === 'reject') allRely = false;
        }
        if (peer.resolve) {
          conditions.push(status.push.concat(`p_${peer.key}`));
          hasPush = true;
        }
      }
    }
    pending.splice(pending.findIndex(k => k === status.key), 1);
    conditionStatus[status.key].status = hasPush || allRely ? 'resolve' : 'reject';
    if (!hasPush && allRely) {
      conditions.push(status.push.concat('p_a'));
      return true;
    }
    return false;
  }
  resolvePendingCondition(conditions, conditionStatus) {
    Object.entries(conditionStatus).forEach(([key, status]) => {
      status.key = key;
      this._resolvePendingCondition(conditions, conditionStatus, status, []);
    });
  }
  judgeData(data, args = {}, extra = {}) {
    var {
      exceptionPriorirtyThreshold = 0
    } = extra;
    args = {
      ...args
    };
    var pointCondition = [];
    var kvResult = [];
    var conditionStatus = {};
    try {
      if (isObject(data)) {
        var {
          conditions
        } = this.objectSchema || {};
        if (!conditions) {
          return {
            error: 'noObjectCondition',
            result: false
          };
        }
        Object.keys(data).forEach(key => {
          var val = data[key];
          conditions.forEach(condition => {
            var conditionKey = condition.key;
            var _pointCondition = [];
            args.__pointCondition = _pointCondition;
            args.__kv = kvResult;
            var pass = this.resolveCondition(condition, key, val, args);
            if (condition.not) {
              pass = !pass;
              conditionKey = '-' + conditionKey;
            }
            if (condition.resolve) {
              var breakJudge = true;
              if (condition.resolve === 'reverse') {
                pass = !pass;
              } else if (condition.resolve === 'reverse-true') {
                if (pass) pass = !pass;else breakJudge = false;
              } else if (condition.resolve === 'reverse-false') {
                if (!pass) pass = !pass;else breakJudge = false;
              } else if (condition.resolve === 'true' && !pass) breakJudge = false;else if (condition.resolve === 'false' && pass) breakJudge = false;
              if (breakJudge) {
                pointCondition.push([conditionKey].concat(_pointCondition));
                throw returnResolveResult(pass ? 'true' : 'false');
              }
            }
            if (pass) {
              if (!conditionStatus[conditionKey]) {
                if (condition.peers) {
                  conditionStatus[conditionKey] = {
                    status: 'pending',
                    peers: condition.peers,
                    push: [conditionKey].concat(_pointCondition)
                  };
                  return;
                } else {
                  conditionStatus[conditionKey] = {
                    status: 'resolve'
                  };
                }
              }
              if (!condition.onlyAsRely) pointCondition.push([conditionKey].concat(_pointCondition));
            }
          });
        });
      } else if (typeof data === 'string') {
        var {
          conditions: _conditions
        } = this.stringSchema || {};
        if (!_conditions) {
          return {
            error: 'noStringCondition',
            result: false
          };
        }
        _conditions.forEach(condition => {
          if (condition.type === 'Pat') {
            var pat = new RegExp(condition.test.test, condition.test.flag);
            var pass = false;
            if (pat.test(data)) {
              pass = true;
              if (condition.not) pass = !pass;
              if (condition.resolve) {
                var breakJudge = true;
                if (condition.resolve === 'reverse') pass = !pass;else if (condition.resolve === 'reverse-true') {
                  if (pass) pass = !pass;else breakJudge = false;
                } else if (condition.resolve === 'reverse-false') {
                  if (!pass) pass = !pass;else breakJudge = false;
                } else if (condition.resolve === 'true' && !pass) breakJudge = false;else if (condition.resolve === 'false' && pass) breakJudge = false;
                if (breakJudge) {
                  pointCondition.push([condition.key]);
                  throw returnResolveResult(pass ? 'true' : 'false');
                }
              }
            }
            if (pass) {
              pointCondition.push([condition.key]);
            }
          }
        });
      }
    } catch (err) {
      if (typeof err === 'string') {
        var result = err.match(/__return_resolve_(.*)/);
        if (result) {
          result = result[1] !== 'false';
          if (result) {
            return {
              result: true,
              point: handlePointKeyChain(pointCondition),
              priority: 'resolve',
              kvResult: this.prunePointKV(kvResult)
            };
          }
          return {
            result: false,
            priority: 'resolve',
            point: handlePointKeyChain(pointCondition)
          };
        }
      }
      wxConsole.error('request interpreter error:', err);
    }
    this.resolvePendingCondition(pointCondition, conditionStatus);
    var priority = handlePriority(pointCondition, this.priorities);
    if (priority > exceptionPriorirtyThreshold) {
      return {
        result: true,
        point: handlePointKeyChain(pointCondition),
        priority,
        kvResult: this.prunePointKV(kvResult)
      };
    }
    return {
      result: false,
      priority,
      point: handlePointKeyChain(pointCondition)
    };
  }
  matchCondition(condition, key, extra = {}) {
    var {
      url
    } = extra;
    if (!condition || key === undefined) return null;
    if (url && condition.url) {
      var urlPat = new RegExp(condition.url, 'i');
      if (!urlPat.test(url)) return null;
    }
    if (condition.type === 'Pat' && condition.test) {
      var pat = new RegExp(condition.test.test, condition.test.flag);
      return pat.test(key);
    } else if (condition.type === 'If' && condition.if) {
      var _if = condition.if;
      if (_if.pre) {
        switch (_if.pre) {
          case 'number':
            key = Number.isNaN(Number(key)) && key !== null ? key : Number(key);
            break;
          case 'string':
            key = String(key);
            break;
          case 'boolean':
            key = !!key;
            break;
          default:
            break;
        }
      }
      switch (_if.compare) {
        case 'not':
          return !key;
        case 'eq':
          return key == _if.right;
        case 'stricteq':
          return key === _if.right;
        case 'gt':
          return key > _if.right;
        case 'gte':
          return key >= _if.right;
        case 'lt':
          return key < _if.right;
        case 'lte':
          return key <= _if.right;
        case 'Type':
          return Object.prototype.toString.call(key) === `[object ${_if.right}]`;
        default:
          return false;
      }
    } else {
      return null;
    }
  }
  resolveCondition(condition, key, val, args = {}, {
    deep = false,
    judgeWith = false,
    prefix = ''
  } = {}) {
    var url = args.url;
    var secondaryCondition = args.__pointCondition || [];
    var kv = args.__kv;
    args.__pointCondition = [];
    if (key === undefined) return false;
    try {
      if (isObject(key) && (judgeWith || deep)) {
        var data = key;
        Object.keys(data).forEach(key => {
          if (deep) args.__pointCondition = secondaryCondition;
          if (this.resolveCondition(condition, key, data[key], args, {
            deep,
            prefix
          })) {
            if (!deep) secondaryCondition.push(condition.key);
            throw returnTrueError;
          }
        });
        return false;
      }
      var isContinue = null;
      isContinue = this.matchCondition(condition, key, {
        url
      });
      if (Array.isArray(condition.withRelyResponse)) {
        if (isContinue) {
          if (!condition.withRelyResponse.every(_condition => {
            return this.matchCondition(_condition.condition, args[_condition.responseKey]);
          })) {
            isContinue = false;
          }
        }
      }
      if (condition.not && isContinue !== null) isContinue = !isContinue;
      if (isContinue) {
        var {
          with: withCondition,
          withRely: withRelyCondition,
          someWith: someWithCondition,
          someWithRely: someWithRelyCondition
        } = condition;
        var noFollup = !withCondition && !withRelyCondition && !someWithCondition && !someWithRelyCondition;
        var _ret;
        if (withCondition) {
          _ret = withCondition.every(condition => this.resolveCondition(condition, key, val, args, {
            deep: false,
            judgeWith: true
          }));
          _ret && secondaryCondition.push('a') && kv.push({
            [prefix + `${prefix ? '.' : ''}${key}`]: val
          });
        } else if (withRelyCondition) {
          _ret = withRelyCondition.every(condition => this.resolveCondition(condition, val, null, args));
          _ret && secondaryCondition.push('b') && kv.push({
            [prefix + `${prefix ? '.' : ''}${key}`]: val
          });
        } else if (someWithCondition) {
          _ret = someWithCondition.some(condition => {
            var ret = this.resolveCondition(condition, key, val, args, {
              deep: false,
              judgeWith: true
            });
            ret && secondaryCondition.push('c_' + condition.key) && kv.push({
              [prefix + `${prefix ? '.' : ''}${key}`]: val
            });
            return ret;
          });
        } else if (someWithRelyCondition) {
          _ret = someWithRelyCondition.some(condition => {
            var ret = this.resolveCondition(condition, val, null, args);
            ret && secondaryCondition.push('d_' + condition.key) && kv.push({
              [prefix + `${prefix ? '.' : ''}${key}`]: val
            });
            return ret;
          });
        }
        if (_ret || noFollup) return true;
        val = tryTransformObject(val);
        if (condition.deep && isObject(val)) {
          args.__pointCondition = secondaryCondition;
          var ret = this.resolveCondition(condition, val, null, args, {
            deep: true,
            prefix: prefix + `${!prefix ? '' : '.'}${key}`
          });
          return ret;
        }
        return false;
      } else {
        if (condition.deep || condition.thisDeep) {
          val = tryTransformObject(condition.deep ? val : key);
          if (isObject(val)) {
            args.__pointCondition = secondaryCondition;
            var _ret2 = this.resolveCondition(condition, val, null, args, {
              deep: true,
              prefix: prefix + `${!prefix ? '' : '.'}${condition.deep ? key : ''}`
            });
            return _ret2;
          }
        }
      }
    } catch (err) {
      if (err === returnTrueError) return true;
      wxConsole.error('request interpreter error:', err);
      return false;
    }
  }
}
/* harmony default export */ const reportRuleInterpreter = (Interpreter);
;// CONCATENATED MODULE: ./src/accelerate-worker/weAppRequestMayErrorInterpreter/interpreter/util.js


var responseInterpreter;
var requestInterpreter;
var userCustomResponseInterpreter;
var userCustomResponseInterpreterListener = [];
var responseInterpreterListener = [];
var requestInterpreteListener = [];
var onUserCustomResponseInterpreterReady = handler => {
  userCustomResponseInterpreterListener.push(handler);
};
var onResponseInterpreterReady = handler => {
  responseInterpreterListener.push(handler);
};
var onRequestInterpreteReady = handler => {
  requestInterpreteListener.push(handler);
};
var emitUserCustomResponseInterpreterReady = () => userCustomResponseInterpreterListener.forEach(handler => handler(userCustomResponseInterpreter));
var emitResponseInterpreterReady = () => responseInterpreterListener.forEach(handler => handler(responseInterpreter));
var emitRequestInterpreteReady = () => requestInterpreteListener.forEach(handler => handler(requestInterpreter));
var createCustomResponseInterpreter = (schema, appid) => {
  if (!schema) userCustomResponseInterpreter = false;else userCustomResponseInterpreter = new reportRuleInterpreter(schema, appid);
  emitUserCustomResponseInterpreterReady();
};
var createResponseInterpreter = (schema, appid, isRequest = false) => {
  if (isRequest) {
    requestInterpreter = new reportRuleInterpreter(schema, appid);
    emitRequestInterpreteReady();
  } else {
    responseInterpreter = new reportRuleInterpreter(schema, appid);
    emitResponseInterpreterReady();
  }
};
var getResponseInterpreter = (isRequest = false) => {
  if (isRequest) return requestInterpreter;
  return responseInterpreter;
};
var getUserCustomResponseInterpreter = () => userCustomResponseInterpreter;
var clearArrayRepeat = target => {
  if (Array.isArray(target)) return [...new Set(target)];
  return target;
};
var mayUserCustomHasError = res => {
  if (!userCustomResponseInterpreter) return false;
  if (!res.data) return false;
  return userCustomResponseInterpreter.judgeData(res.data, res);
};
var mayHasError = (res, isRequest = false, _interpreter = null, extra = {}) => {
  var {
    exceptionPriorirtyThreshold = 0,
    delay
  } = extra;
  var interpreter = _interpreter || (isRequest ? requestInterpreter : responseInterpreter);
  if (!interpreter) {
    if (delay) {
      return new Promise(r => {
        var handler = () => {
          var interpreter = isRequest ? requestInterpreter : responseInterpreter;
          r(interpreter.judgeData(res.data, res, {
            exceptionPriorirtyThreshold
          }));
        };
        var onReady = isRequest ? onRequestInterpreteReady : onResponseInterpreterReady;
        onReady(handler);
      });
    }
    return false;
  }
  if (!res.data) return false;
  return interpreter.judgeData(res.data, res, {
    exceptionPriorirtyThreshold
  });
};
var reportResponse = (res, isRequest = false) => {
  var interpreter = isRequest ? requestInterpreter : responseInterpreter;
  if (!interpreter) return false;
  return interpreter.pruneOriginData(res);
};
var getKeyPriority = () => {
  var _responseInterpreter;
  return (_responseInterpreter = responseInterpreter) === null || _responseInterpreter === void 0 ? void 0 : _responseInterpreter.keyPriority;
};
var getResponseInterpreterVersion = (isRequest = false, isCustom) => {
  var _interpreter$getSchem;
  var interpreter = isCustom ? userCustomResponseInterpreter : isRequest ? requestInterpreter : responseInterpreter;
  if (!interpreter) return -1;
  return (_interpreter$getSchem = interpreter.getSchemaVersion()) !== null && _interpreter$getSchem !== void 0 ? _interpreter$getSchem : -2;
};
var compatKey = (key, condition, add = 1, def = 0) => {
  if (condition) key += add + ',';else key += def + ',';
  return key;
};
var computeKey = (priority, isKeyRuquest = false, isCustom = 0) => {
  var isHighPriority = isCustom === 1 ? false : isCustom === 2 ? true : getKeyPriority() <= priority;
  var isSpecialSchema = priority === magicPriority;
  var key = '';
  key = compatKey(key, true, String(priority));
  key = compatKey(key, isKeyRuquest);
  key = compatKey(key, true, isCustom ? isCustom + 1 : isHighPriority ? 1 : 0);
  key = compatKey(key, true, isSpecialSchema ? 1 : isCustom ? 2 : 0);
  if (key.endsWith(',')) key = key.slice(0, key.length - 1);
  return key;
};
var createValueSensitiveCondition = (matchValSensitiveInfo, key) => ({
  key,
  type: 'Pat',
  test: {
    test: '.*',
    flag: 'i'
  },
  someWithRely: matchValSensitiveInfo.map(s => {
    var _s$flag;
    return {
      type: 'Pat',
      test: {
        test: s.pure,
        flag: (_s$flag = s.flag) !== null && _s$flag !== void 0 ? _s$flag : ''
      },
      key: s.key,
      deep: s.deep
    };
  })
});
var createKeyAndValueSensitiveConditions = (matchKeyValSensitiveInfo, key) => matchKeyValSensitiveInfo.map(s => {
  var _s$flag2, _s$flag3;
  return {
    type: 'Pat',
    key: key + s.key,
    test: {
      test: s.matchKey,
      flag: (_s$flag2 = s.flag) !== null && _s$flag2 !== void 0 ? _s$flag2 : ''
    },
    deep: s.deep,
    withRely: [{
      type: 'Pat',
      key: '',
      test: {
        test: s.pure,
        flag: (_s$flag3 = s.flag) !== null && _s$flag3 !== void 0 ? _s$flag3 : ''
      }
    }]
  };
});
var createCheckKeyConditions = (importantKeyInfo, key) => importantKeyInfo.map(s => {
  var _s$flag4;
  return {
    type: 'Pat',
    key,
    test: {
      test: s.pure,
      flag: (_s$flag4 = s.flag) !== null && _s$flag4 !== void 0 ? _s$flag4 : ''
    },
    deep: s.deep
  };
});
var createCheckKeyPrunes = (importantKeyInfo, key) => importantKeyInfo.map(s => {
  var _s$flag5;
  return {
    key,
    type: 'match',
    test: {
      test: s.pure,
      flag: (_s$flag5 = s.flag) !== null && _s$flag5 !== void 0 ? _s$flag5 : ''
    },
    replace: '',
    deep: s.deep
  };
});
var createValuePrune = (matchValSafeSensitiveInfo, matchValSensitiveInfo, key) => ({
  key,
  type: 'match',
  test: {
    test: '.*',
    flag: ''
  },
  rely: {
    type: 'replace',
    replace: [...matchValSafeSensitiveInfo, ...matchValSensitiveInfo].map(s => {
      var _s$flag6;
      return {
        tag: s.key,
        test: s.pure,
        flag: (_s$flag6 = s.flag) !== null && _s$flag6 !== void 0 ? _s$flag6 : '',
        modify: s.modify || ''
      };
    })
  }
});
var createPrefixAndSuffixPrune = (sensitiveInfo, key) => ({
  key,
  type: 'replace',
  replace: sensitiveInfo.map(s => {
    var _s$flag7;
    return {
      tag: s.key,
      test: (s.prefix || '') + s.pure + (s.suffix || ''),
      flag: (_s$flag7 = s.flag) !== null && _s$flag7 !== void 0 ? _s$flag7 : '',
      modify: s.modify || ''
    };
  })
});
var createSensitiveConditions = commonInfo => {
  var {
    importantKeyInfo = [],
    sensitiveInfo = [],
    safeSensitiveInfo = []
  } = commonInfo;
  var matchKeyValSensitiveInfo = [];
  var matchValSensitiveInfo = [];
  var matchKeyValSafeSensitiveInfo = [];
  var matchValSafeSensitiveInfo = [];
  sensitiveInfo.forEach(info => {
    if (info.matchKey) matchKeyValSensitiveInfo.push(info);else matchValSensitiveInfo.push(info);
  });
  safeSensitiveInfo.forEach(info => {
    if (info.matchKey) matchKeyValSafeSensitiveInfo.push(info);else matchValSafeSensitiveInfo.push(info);
  });
  var sensitiveValueCondition = createValueSensitiveCondition(matchValSensitiveInfo, '4000');
  var sensitiveKeyAndValueConditions = createKeyAndValueSensitiveConditions(matchKeyValSensitiveInfo, '4000.d_');
  var safeSensitiveValueCondition = createValueSensitiveCondition(matchValSafeSensitiveInfo, '2000');
  var safeSensitiveKeyAndValueConditions = createKeyAndValueSensitiveConditions(matchKeyValSafeSensitiveInfo, '2000.d_');
  var checkImportantKeyConditions = createCheckKeyConditions(importantKeyInfo, '3000');
  var importantKeyPrunes = createCheckKeyPrunes(importantKeyInfo, '502');
  var sensitiveValuePrunes = createValuePrune(matchValSafeSensitiveInfo, matchValSensitiveInfo, '501');
  var stringPrunes = [createPrefixAndSuffixPrune([...safeSensitiveInfo, ...sensitiveInfo], '500')];
  return {
    prunes: [...importantKeyPrunes, sensitiveValuePrunes],
    prefixPrunes: stringPrunes,
    conditions: [sensitiveValueCondition, ...sensitiveKeyAndValueConditions, safeSensitiveValueCondition, ...safeSensitiveKeyAndValueConditions, ...checkImportantKeyConditions]
  };
};
var prehandleSchema = schema => {
  try {
    var _schema$object, _schema$object2, _schema$string;
    var common = schema.common;
    if (!common) return;
    var {
      conditions: sensitiveConditions,
      prunes: sensitivePrunes,
      prefixPrunes: stringPrunes
    } = createSensitiveConditions(common);
    if (Array.isArray(schema === null || schema === void 0 ? void 0 : (_schema$object = schema.object) === null || _schema$object === void 0 ? void 0 : _schema$object.conditions)) {
      schema.object.conditions.unshift(...sensitiveConditions);
    }
    if (Array.isArray(schema === null || schema === void 0 ? void 0 : (_schema$object2 = schema.object) === null || _schema$object2 === void 0 ? void 0 : _schema$object2.prunes)) {
      schema.object.prunes.push(...sensitivePrunes);
    }
    if (Array.isArray(schema === null || schema === void 0 ? void 0 : (_schema$string = schema.string) === null || _schema$string === void 0 ? void 0 : _schema$string.prunes)) {
      schema.string.prunes.push(...stringPrunes);
    }
  } catch (err) {}
};
var generateRequestSchema = schema => {
  if (!(schema !== null && schema !== void 0 && schema.common)) return;
  var {
    conditions: sensitiveConditions
  } = createSensitiveConditions(schema.common);
  var requestSchema = {
    priorities: {},
    keyPriority: 0,
    schemaVersion: schema.schemaVersion,
    object: {
      conditions: sensitiveConditions,
      prunes: null
    },
    string: {
      conditions: [],
      prunes: null
    }
  };
  return requestSchema;
};

;// CONCATENATED MODULE: ./src/accelerate-worker/weAppRequestMayErrorInterpreter/judgeLogic.js



var safeSensitivePointFilter = point => point && point.filter(p => p.startsWith('2000'));
var getImportantRequestFromPoint = point => point && point.filter(p => p.startsWith('4000') || p.startsWith('3000') || p.startsWith('2000'));
var resolveWeAppRequestInfo = (args, res, checkResponse) => {
  var isImportantRequest;
  var sensitiveRequestBody = false;
  var sensitiveRequestPoint;
  try {
    try {
      args.data = JSON.parse(args.data);
    } catch (err) {}
    if (res.data) {
      try {
        res.data = JSON.parse(res.data);
      } catch (err) {}
    }
    var sensitiveRequestInfo = mayHasError(args, true);
    if (sensitiveRequestInfo !== null && sensitiveRequestInfo !== void 0 && sensitiveRequestInfo.result) {
      sensitiveRequestBody = true;
      sensitiveRequestPoint = sensitiveRequestInfo.point;
    }
  } catch (err) {}
  isImportantRequest = sensitiveRequestBody;
  if (checkResponse) {
    try {
      if (res.errMsg || res.statusCode >= 400) {
        return {
          hasError: true,
          reportBody: res.data,
          isImportantRequest,
          isWxClientError: true
        };
      } else {
        var _mayError$point, _mayError$point2, _mayError$priority, _mayError;
        var mayError;
        res.url = args.url;
        mayError = mayUserCustomHasError(res, args);
        delete res.url;
        if (!mayError || !mayError.result && !((_mayError$point = mayError.point) !== null && _mayError$point !== void 0 && _mayError$point.length) || !mayError.result && (_mayError$point2 = mayError.point) !== null && _mayError$point2 !== void 0 && _mayError$point2.length && mayError.priority > CUSTOM_RULE_NORMAL) mayError = mayHasError(res, false, null, {
          delay: true,
          exceptionPriorirtyThreshold: -((_mayError$priority = (_mayError = mayError) === null || _mayError === void 0 ? void 0 : _mayError.priority) !== null && _mayError$priority !== void 0 ? _mayError$priority : 0)
        });else {
          if (mayError.result) {
            if (mayError.priority < CUSTOM_RULE_ERROR) mayError.hitUserLowPriortyCustom = true;else mayError.hitUserHighPriorityCustom = true;
          }
        }
        var checkAndReturnIsException = mayError => {
          var _sensitveResponsePoin;
          var sensitveResponsePoint = getImportantRequestFromPoint(mayError === null || mayError === void 0 ? void 0 : mayError.point);
          isImportantRequest = !!(isImportantRequest || (_sensitveResponsePoin = sensitveResponsePoint) !== null && _sensitveResponsePoin !== void 0 && _sensitveResponsePoin.length);
          sensitiveRequestPoint = clearArrayRepeat(safeSensitivePointFilter(sensitiveRequestPoint));
          sensitveResponsePoint = clearArrayRepeat(safeSensitivePointFilter(sensitveResponsePoint));
          if (mayError !== null && mayError !== void 0 && mayError.result) {
            var _reportResponse, _reportResponse2;
            return {
              type: 'checkResponse',
              hasError: true,
              reportBody: (_reportResponse = reportResponse(res.data)) === null || _reportResponse === void 0 ? void 0 : _reportResponse.data,
              reportArgs: (_reportResponse2 = reportResponse(args.data)) === null || _reportResponse2 === void 0 ? void 0 : _reportResponse2.data,
              isImportantRequest,
              key: computeKey(mayError.priority, isImportantRequest, mayError.hitUserLowPriortyCustom ? 1 : mayError.hitUserHighPriorityCustom ? 2 : 0),
              point: clearArrayRepeat(mayError.point),
              priority: mayError.priority,
              schemaVersion: getResponseInterpreterVersion(),
              kvResult: mayError.kvResult,
              ...(isImportantRequest ? {
                sensitiveRequestPoint,
                sensitveResponsePoint
              } : {})
            };
          } else {
            return {
              type: 'checkResponse',
              isImportantRequest,
              hasError: false,
              sensitiveRequestPoint,
              ...(isImportantRequest ? {
                sensitiveRequestPoint,
                sensitveResponsePoint
              } : {})
            };
          }
        };
        if (isPromise(mayError)) {
          return new Promise(resolve => {
            mayError.then(mayErrorInfo => {
              resolve(checkAndReturnIsException(mayErrorInfo));
            });
          });
        }
        return checkAndReturnIsException(mayError);
      }
    } catch (err) {
      wxNativeConsole.error('interprete 24247 error:', err);
    }
  }
  return {
    type: 'checkRequest',
    point: sensitiveRequestPoint,
    isImportantRequest
  };
};

;// CONCATENATED MODULE: ./src/accelerate-worker/weAppRequestMayErrorInterpreter/index.js





var appExclusiveSchema = {
  req: null,
  res: null
};
var customRuleInterpreter = {};
var createUserCustomInterpreter = infos => {
  var {
    userRules: userSchemas,
    appid
  } = infos;
  try {
    var schema;
    if (userSchemas) {
      userSchemas = JSON.parse(userSchemas);
      schema = transformUserCustomRules(userSchemas);
    }
    createCustomResponseInterpreter(schema, appid);
  } catch (err) {
    wxNativeConsole.warn('createUserCustomInterpreter occur error:', err);
  }
};
var createInterpreter = infos => {
  var {
    rules: schema,
    appid,
    userRules
  } = infos;
  try {
    schema = JSON.parse(schema);
  } catch (err) {}
  if (schema.exclusive) {
    var {
      req,
      res
    } = schema;
    if (req) {
      appExclusiveSchema.req = {
        priorities: {},
        keyPriority: 0,
        schemaVersion: schema.schemaVersion,
        object: {
          conditions: req,
          prunes: null
        },
        string: {
          conditions: [],
          prunes: null
        }
      };
    }
    if (res) {
      appExclusiveSchema.res = {
        priorities: {},
        keyPriority: 0,
        schemaVersion: schema.schemaVersion,
        object: {
          conditions: res,
          prunes: null
        },
        string: {
          conditions: [],
          prunes: null
        }
      };
    }
    return;
  }
  if (appExclusiveSchema.req) createResponseInterpreter(appExclusiveSchema.req, appid, true);else {
    var requestSchema = generateRequestSchema(schema);
    createResponseInterpreter(requestSchema, appid, true);
  }
  if (appExclusiveSchema.res) {
    appExclusiveSchema.res.object.prunes = schema.object.prunes;
    appExclusiveSchema.res.string.prunes = schema.string.prunes;
    appExclusiveSchema.res.common = schema.common;
    prehandleSchema(appExclusiveSchema.res);
  } else prehandleSchema(schema);
  createResponseInterpreter(appExclusiveSchema.res || schema, appid);
  if (userRules || userRules === '') createUserCustomInterpreter({
    userRules,
    appid
  });
};
var weAppRequestMayErrorInterpreter_resolveWeAppRequestInfo = (args = {}) => {
  var {
    requestData,
    response,
    checkResponse = true,
    delay
  } = args;
  if (delay && !getResponseInterpreter()) {
    return new Promise(resolve => {
      var wait = 0;
      var handler = () => {
        resolve(resolveWeAppRequestInfo(requestData, response, checkResponse));
      };
      onResponseInterpreterReady(() => {
        wait++;
        if (wait === 2) handler();
      });
      onUserCustomResponseInterpreterReady(() => {
        wait++;
        if (wait === 2) handler();
      });
    });
  }
  return resolveWeAppRequestInfo(requestData, response, checkResponse);
};
var resolveInteractiveApiContent = (args = {}) => {
  var _mayError$point, _mayError$point2;
  var {
    content
  } = args;
  var res = {
    data: content
  };
  var mayError;
  mayError = mayUserCustomHasError(res, args);
  if (!mayError || !mayError.result && !((_mayError$point = mayError.point) !== null && _mayError$point !== void 0 && _mayError$point.length) || !mayError.result && (_mayError$point2 = mayError.point) !== null && _mayError$point2 !== void 0 && _mayError$point2.length && mayError.priority > CUSTOM_RULE_NORMAL) mayError = mayHasError(res, false, null);else {
    if (mayError.result) {
      if (mayError.priority < CUSTOM_RULE_ERROR) mayError.hitUserLowPriortyCustom = true;else mayError.hitUserHighPriorityCustom = true;
    }
  }
  return mayError;
};
var resolvePointRule = (args = {}) => {
  var {
    name,
    rules,
    data
  } = args;
  var interpreter = customRuleInterpreter[name];
  if (!interpreter) {
    interpreter = customRuleInterpreter[name] = new reportRuleInterpreter(rules, args.appid);
  }
  return mayHasError({
    data
  }, false, interpreter);
};
var resolveApiFullRule = (args = {}) => {
  var ret = resolvePointRule({
    data: args.data,
    rules: args.rules,
    name: 'api',
    appid: args.appid
  });
  return ret;
};

;// CONCATENATED MODULE: ./src/accelerate-worker/index.js





registerTask('initAesWasm', init);
registerTask('aesEncrypt', aesEncrypt);
registerTask('aesDecrypt', aesDecrypt);
registerTask('createWeAppRequestInterpreter', createInterpreter);
registerTask('checkRequest', weAppRequestMayErrorInterpreter_resolveWeAppRequestInfo);
registerTask('resolveInteractiveApiContent', resolveInteractiveApiContent);
registerTask('resolveApiFullRule', resolveApiFullRule);
/******/ })()
;

})(this); /* LIBRARY_CLOSURE_END (this) */

