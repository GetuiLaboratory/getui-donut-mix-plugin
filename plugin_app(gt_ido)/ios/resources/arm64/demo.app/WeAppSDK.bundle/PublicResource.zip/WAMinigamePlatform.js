
;try {

;(function () { /* LIBRARY_CLOSURE_START () */


            let getGlobalVar = "getMinigamePlatformGlobalVar"
            let sdkSubpakcageGlobalVarGetter
            if(globalThis[getGlobalVar]) {
              sdkSubpakcageGlobalVarGetter = globalThis[getGlobalVar]
            } else if(typeof globalThis.WeixinJSBridge !== "undefined" && globalThis.WeixinJSBridge[getGlobalVar]){
              sdkSubpakcageGlobalVarGetter = globalThis.WeixinJSBridge[getGlobalVar]
            }
            var {console,wxNativeConsole,__wxConfig,__errorTracer__,wxConsole,wxGA,Reporter,Foundation,WeixinJSBridge,__appServiceSDK__,__IS_MINIGAME_LIVE_SUB_PACKAGE__,wxRunOnDebug} = sdkSubpakcageGlobalVarGetter();
          

var MiniGamePlatform;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 194:
/***/ ((module) => {

function E() {}
E.prototype = {
  on: function (name, callback, ctx) {
    var e = this.e || (this.e = {});
    (e[name] || (e[name] = [])).push({
      fn: callback,
      ctx: ctx
    });
    return this;
  },
  once: function (name, callback, ctx) {
    var self = this;
    function listener() {
      self.off(name, listener);
      callback.apply(ctx, arguments);
    }
    ;
    listener._ = callback;
    return this.on(name, listener, ctx);
  },
  emit: function (name) {
    var data = [].slice.call(arguments, 1);
    var evtArr = ((this.e || (this.e = {}))[name] || []).slice();
    var i = 0;
    var len = evtArr.length;
    for (i; i < len; i++) {
      evtArr[i].fn.apply(evtArr[i].ctx, data);
    }
    return this;
  },
  off: function (name, callback) {
    var e = this.e || (this.e = {});
    var evts = e[name];
    var liveEvents = [];
    if (evts && callback) {
      for (var i = 0, len = evts.length; i < len; i++) {
        if (evts[i].fn !== callback && evts[i].fn._ !== callback) liveEvents.push(evts[i]);
      }
    }
    liveEvents.length ? e[name] = liveEvents : delete e[name];
    return this;
  }
};
module.exports = E;
module.exports.TinyEmitter = E;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/common/util.js


function none() {}
function uid(length = 20, char) {
  var soup = `${char ? '' : '!#%()*+,-./:;=?@[]^_`{|}~'}ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789`;
  var soupLength = soup.length;
  var id = [];
  for (var i = 0; i < length; i++) {
    id[i] = soup.charAt(Math.random() * soupLength);
  }
  return id.join('');
}
function clamp(number, min, max) {
  return Math.max(min, Math.min(number, max));
}
function toFixed(num, digits) {
  var multiple = Math.pow(10, digits);
  return Math.round(num * multiple) / multiple;
}
function compareVersion(v1, v2) {
  if (typeof v1 !== 'string' || typeof v2 !== 'string') {
    if (typeof v1 !== 'string' && typeof v2 !== 'string') {
      return 0;
    }
    if (typeof v1 !== 'string') {
      return 1;
    }
    return -1;
  }
  var version1 = v1.split('.');
  var version2 = v2.split('.');
  var len = Math.max(version1.length, version2.length);
  while (version1.length < len) {
    version1.push('0');
  }
  while (version2.length < len) {
    version2.push('0');
  }
  for (var i = 0; i < len; i++) {
    var num1 = parseInt(version1[i], 10);
    var num2 = parseInt(version2[i], 10);
    if (num1 > num2) {
      return 1;
    }
    if (num1 < num2) {
      return -1;
    }
  }
  return 0;
}
function formatOutputNumber(value) {
  if (value < 1000) {
    return `${value}`;
  }
  if (value >= 1000 && value < 10000) {
    return `${parseFloat(`${value / 1000}`).toFixed(1)}k`;
  }
  if (value > 10000 && value < 100000) {
    return `${parseFloat(`${value / 10000}`).toFixed(1)}w`;
  }
  return '10w+';
}
function isNumber(value) {
  return typeof value === 'number' && isFinite(value);
}
function promiseRetry(func, times = 0, delay = 0, ...args) {
  return new Promise((resolve, reject) => {
    var retry = (_times = 0) => {
      func.apply(null, [...args, times]).then(resolve).catch(err => {
        if (_times > 0) {
          setTimeout(() => {
            retry(_times - 1);
          }, delay);
        } else {
          reject(err);
        }
      });
    };
    retry(times);
  });
}
function awaitWrap(promise) {
  return promise.then(data => [null, data]).catch(err => [err, null]);
}
function formatDate(ms, fmt = 'yyyy-MM-dd') {
  if (!ms) {
    return '';
  }
  var target = fmt;
  var time = String(ms).toString().length === 10 ? new Date(ms * 1000) : new Date(ms);
  var o = {
    'y+': time.getFullYear(),
    'M+': time.getMonth() + 1,
    'd+': time.getDate(),
    'h+': time.getHours(),
    'm+': time.getMinutes(),
    's+': time.getSeconds(),
    'q+': Math.floor((time.getMonth() + 3) / 3),
    'S+': time.getMilliseconds()
  };
  var _loop = function (value) {
    var reg = new RegExp(`(${key})`);
    if (reg.test(target)) {
      var [m] = target.match(reg);
      target = target.replace(reg, () => `00${value}`.slice(-`${m}`.length));
    }
  };
  for (var [key, value] of Object.entries(o)) {
    _loop(value);
  }
  return target;
}
function isEmpty(val) {
  if (val === null || val === undefined) {
    return true;
  }
  if (typeof val === 'boolean') {
    return false;
  }
  if (typeof val === 'number') {
    return !val;
  }
  if (val instanceof Error) {
    return val.message === '';
  }
  switch (Object.prototype.toString.call(val)) {
    case '[object String]':
    case '[object Array]':
      return !val.length;
    case '[object File]':
    case '[object Map]':
    case '[object Set]':
      {
        return !val.size;
      }
    case '[object Object]':
      {
        return !Object.keys(val).length;
      }
  }
  return false;
}
function isString(obj) {
  return Object.prototype.toString.call(obj) === '[object String]';
}
function isObject(obj) {
  return Object.prototype.toString.call(obj) === '[object Object]';
}
function isFunction(functionToCheck) {
  return functionToCheck && Object.prototype.toString.call(functionToCheck) === '[object Function]';
}
function isUndefined(val) {
  return typeof val === 'undefined';
}
function isDefined(val) {
  return val !== undefined && val !== null;
}
function rgbaToHex(r, g, b) {
  var outParts = [r.toString(16), g.toString(16), b.toString(16)];
  outParts.forEach((part, i) => {
    if (part.length === 1) {
      outParts[i] = `0${part}`;
    }
  });
  return parseInt(outParts.join(''), 16);
}
function getColor(colorString) {
  var hex = /^#([a-f0-9]{6})([a-f0-9]{2})?$/i;
  var rgba = /^rgba?\(\s*([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)\s*(?:[,|/]\s*([+-]?[\d.]+)(%?)\s*)?\)$/;
  var rgb = [0, 0, 0, 1];
  var match;
  var i;
  var hexAlpha;
  if (match = colorString.match(hex)) {
    hexAlpha = match[2];
    match = match[1];
    for (i = 0; i < 3; i++) {
      var i2 = i * 2;
      rgb[i] = parseInt(match.slice(i2, i2 + 2), 16);
    }
    if (hexAlpha) {
      rgb[3] = parseInt(hexAlpha, 16) / 255;
    }
  } else if (match = colorString.match(rgba)) {
    for (i = 0; i < 3; i++) {
      rgb[i] = parseInt(match[i + 1], 10);
    }
    if (match[4]) {
      if (match[5]) {
        rgb[3] = parseFloat(match[4]) * 0.01;
      } else {
        rgb[3] = parseFloat(match[4]);
      }
    }
  }
  return {
    hex: rgbaToHex(rgb[0], rgb[1], rgb[2]),
    alpha: rgb[3]
  };
}
function getErrMsg(errMsg) {
  var result = errMsg;
  try {
    if (typeof errMsg === 'object') {
      if (typeof errMsg.errMsg === 'string') {
        result = errMsg.errMsg;
      } else if (typeof errMsg.errmsg === 'string') {
        result = errMsg.errmsg;
      } else if (typeof errMsg.message === 'string') {
        result = errMsg.message;
      } else {
        result = JSON.stringify(errMsg);
      }
    }
  } catch (e) {
    console.error(e);
  }
  return result;
}
function setQueryString(url, key, value) {
  if (!value) {
    return url;
  }
  var getUrl = url;
  var re = new RegExp(`([?&])${key}=.*?(&|$)`, 'i');
  if (getUrl.match(re)) {
    return getUrl.replace(re, `$1${key}=${value}$2`);
  }
  var separator = getUrl.indexOf('?') !== -1 ? '&' : '?';
  var hash = getUrl.split('#');
  getUrl = `${hash[0] + separator + key}=${value}`;
  if (hash[1]) {
    getUrl += `#${hash[1]}`;
  }
  return getUrl;
}
function filterSpecialChar(str) {
  return str.replace(/[\r\n\t\s]/g, '');
}
function addEllipsis(str) {
  if (str.lastIndexOf(ELLIPSIS) === str.length - 1) {
    return str;
  }
  return str + ELLIPSIS;
}
function centToYuan(value) {
  if (value === undefined || value === null) {
    return 0;
  }
  return Number(((+value || 0) / 100).toFixed(2));
}
function clipboard(value) {
  if (typeof navigator.clipboard !== 'undefined') {
    navigator.clipboard.writeText(value);
  } else {
    var textarea = document.createElement('textarea');
    document.body.appendChild(textarea);
    textarea.style.position = 'fixed';
    textarea.style.top = '-100px';
    textarea.value = value;
    textarea.select();
    document.execCommand('copy', true);
    document.body.removeChild(textarea);
  }
}
function delay(callback, delayTime) {
  var start = 0;
  function loop(timestamp) {
    if (!start) {
      start = timestamp;
    }
    var progress = timestamp - start;
    if (progress < delayTime) {
      requestAnimationFrame(loop);
    } else {
      callback();
    }
  }
  requestAnimationFrame(loop);
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/minigame/quality/types.js

var IsVisible;
(function (IsVisible) {
  IsVisible[IsVisible["Front"] = 1] = "Front";
  IsVisible[IsVisible["Background"] = 2] = "Background";
})(IsVisible || (IsVisible = {}));
var ReportType;
(function (ReportType) {
  ReportType[ReportType["Default"] = 0] = "Default";
  ReportType[ReportType["GameTransfer"] = 1] = "GameTransfer";
  ReportType[ReportType["Request"] = 2] = "Request";
  ReportType[ReportType["DownloadFile"] = 3] = "DownloadFile";
  ReportType[ReportType["CgiSpeedMeasure"] = 4] = "CgiSpeedMeasure";
  ReportType[ReportType["BadJs"] = 5] = "BadJs";
  ReportType[ReportType["Init"] = 6] = "Init";
  ReportType[ReportType["CostTime"] = 7] = "CostTime";
  ReportType[ReportType["Error"] = 8] = "Error";
  ReportType[ReportType["UploadFile"] = 9] = "UploadFile";
  ReportType[ReportType["Login"] = 10] = "Login";
})(ReportType || (ReportType = {}));
var PluginReportType;
(function (PluginReportType) {
  PluginReportType[PluginReportType["Info"] = 101] = "Info";
  PluginReportType[PluginReportType["Warn"] = 102] = "Warn";
  PluginReportType[PluginReportType["Error"] = 103] = "Error";
})(PluginReportType || (PluginReportType = {}));
var QualityReportType;
(function (QualityReportType) {
  QualityReportType["GameTransferReport"] = "GameTransferReport";
  QualityReportType["KeyValueReport"] = "KeyValueReport";
  QualityReportType["WxRequestReport"] = "WxRequestReport";
})(QualityReportType || (QualityReportType = {}));
var REPORT_TYPE_LIST = Object.values(ReportType).filter(item => isNumber(item));
;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/common/const.ts
var ProjectName = 'MiniGamePlatform';
;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/report/quality.ts


var {
  Quality
} = __appServiceSDK__;
var startTime = 0;
var qualityReport = new Quality({
  pluginAppId: `wxapplib_${ProjectName}`,
  pluginVersion: '1.0.0'
});
function init() {
  startTime = Date.now();
  qualityReport.report({
    Type: PluginReportType.Info,
    Target: `${ProjectName}Init`
  });
}
function created() {
  qualityReport.report({
    Type: PluginReportType.Info,
    CostTime: Date.now() - startTime,
    Target: `${ProjectName}Created`
  });
}
function rendered() {
  qualityReport.report({
    Type: PluginReportType.Info,
    CostTime: Date.now() - startTime,
    Target: `${ProjectName}Rendered`
  });
}
function destroy() {
  qualityReport.report({
    Type: PluginReportType.Info,
    CostTime: Date.now() - startTime,
    Target: `${ProjectName}Destroy`
  });
}
function webviewInit() {
  qualityReport.report({
    Type: PluginReportType.Info,
    Target: `${ProjectName}WebviewInit`
  });
}
function webviewCreate(webviewInitTime) {
  qualityReport.report({
    Type: PluginReportType.Info,
    Target: `${ProjectName}webviewCreate`,
    CostTime: Date.now() - webviewInitTime
  });
}
function WebviewCreateSuccess(isGameWebview, webviewInitTime) {
  qualityReport.report({
    Type: PluginReportType.Info,
    Target: `${ProjectName}WebviewCreateSuccess`,
    CostTime: Date.now() - webviewInitTime,
    CustomKey1: `${isGameWebview}`
  });
}
function webviewLoaded(webviewInitTime) {
  qualityReport.report({
    Type: PluginReportType.Info,
    Target: `${ProjectName}WebviewLoaded`,
    CostTime: Date.now() - webviewInitTime
  });
}
function webviewError(errMsg, webviewInitTime) {
  qualityReport.report({
    Type: PluginReportType.Info,
    Target: `${ProjectName}WebviewError`,
    CostTime: Date.now() - webviewInitTime,
    Result: errMsg,
    IsError: 1
  });
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/pixi.js
var PIXIcore;
var setPIXI = core => {
  PIXIcore = core;
};
var pixi_getPIXI = () => PIXIcore;
// EXTERNAL MODULE: ../../node_modules/.pnpm/tiny-emitter@2.1.0/node_modules/tiny-emitter/index.js
var tiny_emitter = __webpack_require__(194);
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/core/common.js

class Common extends tiny_emitter.TinyEmitter {
  constructor() {
    super(...arguments);
    this.innerTweenGroup = null;
    this.deviceScale = 1;
    this.devicePixelRatio = 1;
    this.innerDebug = false;
  }
  init(options) {
    var _a;
    var {
      pixiJs,
      TWEEN,
      designWidth,
      gameWX,
      scale = 1,
      debug = false
    } = options;
    this.innerPixi = pixiJs;
    this.innerTween = TWEEN;
    this.innerTweenGroup = new TWEEN.Group();
    this.gameWX = gameWX;
    this.innerDebug = debug;
    this.designWithSystemInfo({
      designWidth,
      scale
    });
    (_a = gameWX.onDeviceOrientationChange) === null || _a === void 0 ? void 0 : _a.call(gameWX, () => {
      this.designWithSystemInfo({
        designWidth,
        scale
      });
      this.emit('onDeviceOrientationChange');
    });
    if (debug) {
      console.log('[minigamefe PixiCore]: Common inited');
    }
  }
  get debug() {
    return this.innerDebug;
  }
  get PIXI() {
    return this.innerPixi;
  }
  get TWEEN() {
    return this.innerTween;
  }
  get tweenGroup() {
    return this.innerTweenGroup;
  }
  get systemInfo() {
    return this.innerSystemInfo;
  }
  get scale() {
    return this.deviceScale;
  }
  get dpr() {
    return this.devicePixelRatio;
  }
  get wx() {
    return this.gameWX;
  }
  destroy() {
    if (this.innerTweenGroup) {
      this.innerTweenGroup.removeAll();
      this.innerTweenGroup = null;
    }
  }
  designWithSystemInfo(options) {
    var {
      designWidth = 375,
      scale = 1
    } = options;
    this.innerSystemInfo = this.gameWX.getSystemInfoSync();
    var {
      screenWidth,
      screenHeight,
      pixelRatio
    } = this.innerSystemInfo;
    var minSize = Math.min(screenWidth, screenHeight);
    this.deviceScale = Math.min(1, minSize / designWidth) * scale;
    this.devicePixelRatio = Math.round(pixelRatio * this.scale * 1000) / 1000;
  }
}
/* harmony default export */ const common = (new Common());
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/core/loader.js


var ResourceType;
(function (ResourceType) {
  ResourceType[ResourceType["Unknown"] = 0] = "Unknown";
  ResourceType[ResourceType["Buffer"] = 1] = "Buffer";
  ResourceType[ResourceType["Blob"] = 2] = "Blob";
  ResourceType[ResourceType["Json"] = 3] = "Json";
  ResourceType[ResourceType["Xml"] = 4] = "Xml";
  ResourceType[ResourceType["Image"] = 5] = "Image";
  ResourceType[ResourceType["Audio"] = 6] = "Audio";
  ResourceType[ResourceType["Video"] = 7] = "Video";
  ResourceType[ResourceType["Text"] = 8] = "Text";
})(ResourceType || (ResourceType = {}));
class LoaderManager extends tiny_emitter.TinyEmitter {
  constructor() {
    super();
    this.resLoadTicker = null;
    this.resLoadRetryCount = 3;
    var {
      PIXI
    } = common;
    this.loader = new PIXI.Loader();
    if (common.debug) {
      console.log('[minigamefe PixiCore]: LoaderManager constructor');
    }
  }
  load(data) {
    if (this.resLoadTicker) {
      return Promise.reject({
        errMsg: '正在加载中'
      });
    }
    var {
      timeout = 10000,
      list,
      mainTextureName,
      bindingScreen = 0
    } = data;
    list.forEach(it => {
      var _a;
      var {
        name,
        url
      } = it;
      (_a = this.loader) === null || _a === void 0 ? void 0 : _a.add({
        name,
        url,
        bindingScreen,
        timeout
      });
    });
    if (common.debug) {
      console.log('[minigamefe PixiCore]: loadResources start');
    }
    return new Promise((resolve, reject) => {
      var _a;
      var successCallback = resources => {
        list.forEach(it => {
          this.loadError(resources, it.name || it.url);
        });
        resolve({
          resources
        });
      };
      (_a = this.loader) === null || _a === void 0 ? void 0 : _a.load(() => {
        if (!this.loader) {
          return;
        }
        var {
          resources
        } = this.loader;
        if (common.debug) {
          console.log('[minigamefe PixiCore]: loadResources success:', resources);
        }
        this.clearLoadTicker();
        if (mainTextureName) {
          if (this.checkMainRes(resources, mainTextureName)) {
            successCallback(resources);
          } else {
            reject({
              errMsg: `关键资源${mainTextureName}加载失败`,
              resources
            });
          }
        } else {
          successCallback(resources);
        }
      });
      this.resLoadTicker = setTimeout(() => {
        if (!this.loader) {
          return;
        }
        var {
          resources
        } = this.loader;
        this.clearLoadTicker();
        this.emit('info', resources);
        if (mainTextureName) {
          if (this.checkMainRes(resources, mainTextureName)) {
            successCallback(resources);
            return;
          }
        }
        var errMsg = `resources load error，资源加载超时 retryCount:${this.resLoadRetryCount}`;
        this.emit('info', errMsg);
        this.resLoadRetryCount -= 1;
        if (this.resLoadRetryCount > 0) {
          this.load(data).then(res => {
            resolve({
              resources: res.resources
            });
          }).catch(res => {
            reject({
              errMsg: '资源加载失败',
              resources: res.resources
            });
          });
        } else {
          reject({
            errMsg: '资源加载失败，请求超时'
          });
        }
      }, timeout);
    });
  }
  clearLoadTicker() {
    var _a;
    if (this.resLoadTicker) {
      (_a = this.loader) === null || _a === void 0 ? void 0 : _a.reset();
      clearTimeout(this.resLoadTicker);
      this.resLoadTicker = null;
    }
  }
  destroy() {
    var _a;
    (_a = this.loader) === null || _a === void 0 ? void 0 : _a.destroy();
    delete this.loader;
  }
  checkMainRes(resources, mainTextureName) {
    if (resources[mainTextureName] && !resources[mainTextureName].error && resources[mainTextureName].textures && resources[`${mainTextureName}_image`]) {
      return true;
    }
    return false;
  }
  loadError(resources, key) {
    var errMsg = '';
    if (!resources[key]) {
      errMsg = `resources load error, ${key}: 资源加载失败`;
    } else {
      if (resources[key].error) {
        errMsg = `resources load error, ${key}:${resources[key].error}`;
      }
      if (resources[key].type === ResourceType.Json || resources[key].type === ResourceType.Text) {
        if (resources[key].children.length < 1) {
          errMsg = `resources load error, ${key}_image: 子资源加载失败`;
        } else {
          this.loadError(resources, resources[key].children[0].name || resources[key].children[0].url);
        }
      }
    }
    if (errMsg) {
      this.emit('error', errMsg);
    }
  }
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/screenCanvas/index.js


class ScreenCanvas extends tiny_emitter.TinyEmitter {
  constructor(data) {
    super();
    this.canvas = null;
    this.isNormalCanvas = false;
    this.realX = 0;
    this.realY = 0;
    this.realWidth = 0;
    this.realHeight = 0;
    this.realZIndex = '1';
    this.pixelRatio = 1;
    this.scale = 1;
    var {
      createScreenCanvas,
      pixelRatio = 1,
      scale = 1,
      isNormalCanvas = false
    } = data;
    this.pixelRatio = pixelRatio;
    this.scale = scale;
    this.canvas = createScreenCanvas();
    this.canvas.getBoundingClientRect = () => ({
      x: this.x,
      y: this.y,
      left: this.x,
      top: this.y,
      width: this.width,
      height: this.height,
      bottom: 0,
      right: 0,
      toJSON: none
    });
    this.isNormalCanvas = isNormalCanvas;
    if (!this.canvas.style) {
      this.isNormalCanvas = true;
      Object.assign(this.canvas, {
        style: {
          x: 0,
          y: 0,
          left: 0,
          top: 0,
          width: 0,
          height: 0,
          zIndex: 0
        }
      });
    }
  }
  set x(value) {
    var x = Math.round(value * 1000) / 1000;
    this.realX = x;
    this.changeStyle('left', `${x}px`);
  }
  get x() {
    return this.realX;
  }
  set y(value) {
    var y = Math.round(value * 1000) / 1000;
    this.realY = y;
    this.changeStyle('top', `${y}px`);
  }
  get y() {
    return this.realY;
  }
  set width(value) {
    this.realWidth = value * this.scale;
    if (this.canvas) {
      this.canvas.width = this.realWidth * this.pixelRatio;
      this.changeStyle('width', `${this.realWidth}px`);
    }
  }
  get width() {
    return this.realWidth;
  }
  get renderWidth() {
    return this.width / this.scale * this.pixelRatio;
  }
  set height(value) {
    this.realHeight = value * this.scale;
    if (this.canvas) {
      this.canvas.height = this.realHeight * this.pixelRatio;
      this.changeStyle('height', `${this.realHeight}px`);
    }
  }
  get height() {
    return this.realHeight;
  }
  get renderHeight() {
    return this.height / this.scale * this.pixelRatio;
  }
  set zIndex(value) {
    this.realZIndex = value;
    this.changeStyle('zIndex', value);
  }
  get zIndex() {
    return this.realZIndex;
  }
  set bindingScreen(value) {
    if (this.canvas) {
      this.canvas.bindingScreen = value;
    }
  }
  get bindingScreen() {
    var _a, _b;
    return (_b = (_a = this.canvas) === null || _a === void 0 ? void 0 : _a.bindingScreen) !== null && _b !== void 0 ? _b : 0;
  }
  remove() {
    var _a, _b;
    (_b = (_a = this.canvas) === null || _a === void 0 ? void 0 : _a.remove) === null || _b === void 0 ? void 0 : _b.call(_a);
    this.canvas = null;
  }
  changeStyle(key, value) {
    if (this.canvas && this.canvas.style) {
      this.canvas.style[key] = value;
      this.emit('changed');
    }
  }
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/core/position.js



var cachePosNumber = 10;
class Position extends tiny_emitter.TinyEmitter {
  constructor(screenCanvas) {
    super();
    this.histroyPosList = [];
    this.hideData = {
      isHide: false,
      x: 0,
      y: 0
    };
    this.screenCanvas = screenCanvas;
  }
  get isHide() {
    return this.hideData.isHide;
  }
  set(pos) {
    var {
      x,
      y
    } = pos;
    if (common.debug) {
      console.log('[minigamefe PixiCore]: Set Canvas Position', x, y);
    }
    if (isNumber(x)) {
      x = toFixed(x, 1);
    }
    if (isNumber(y)) {
      y = toFixed(y, 1);
    }
    if (toFixed(this.screenCanvas.x, 1) === x && toFixed(this.screenCanvas.y, 1) === y) {
      return;
    }
    this.histroyPosList.push({
      x: this.screenCanvas.x,
      y: this.screenCanvas.y
    });
    if (this.histroyPosList.length > cachePosNumber) {
      this.histroyPosList.shift();
    }
    if (this.hideData.isHide) {
      if (isNumber(x)) {
        this.hideData.x = x;
      }
      if (isNumber(y)) {
        this.hideData.y = y;
      }
    } else {
      if (isNumber(x)) {
        this.screenCanvas.x = x;
      }
      if (isNumber(y)) {
        this.screenCanvas.y = y;
      }
      this.emit('moved');
    }
  }
  back() {
    var pos = this.histroyPosList.pop();
    if (pos) {
      this.set(pos);
    }
  }
  get() {
    return {
      x: this.screenCanvas.x,
      y: this.screenCanvas.y
    };
  }
  hide() {
    if (this.hideData.isHide) {
      return;
    }
    this.hideData.isHide = true;
    this.hideData.x = this.screenCanvas.x;
    this.hideData.y = this.screenCanvas.y;
    this.screenCanvas.x = 9999;
    this.screenCanvas.y = 9999;
  }
  show(pos) {
    if (pos && isNumber(pos.x) && isNumber(pos.y)) {
      this.hideData.x = pos.x;
      this.hideData.y = pos.y;
      this.hideData.isHide = true;
    }
    if (this.hideData.isHide) {
      var {
        x,
        y
      } = this.hideData;
      this.hideData.isHide = false;
      if (isNumber(x)) {
        this.screenCanvas.x = x;
      }
      if (isNumber(y)) {
        this.screenCanvas.y = y;
      }
      this.emit('moved');
    }
  }
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/core/canvas.js





class CanvasManager extends tiny_emitter.TinyEmitter {
  constructor(options) {
    super();
    var {
      createScreenCanvas,
      createCanvas
    } = options;
    this.createScreenCanvas = createScreenCanvas;
    this.createCanvas = createCanvas;
    if (common.debug) {
      console.log('[minigamefe PixiCore]: CanvasManager constructor');
    }
  }
  init(isScreen = true) {
    if (this.canvas) {
      return this.canvas;
    }
    try {
      this.canvas = new ScreenCanvas({
        createScreenCanvas: isScreen ? this.createScreenCanvas : this.createCanvas,
        pixelRatio: common.dpr,
        scale: common.scale,
        isNormalCanvas: !isScreen
      });
      if (!isScreen) {
        this.canvas.on('changed', () => {
          this.emit('render');
        });
      }
      this.canvas.x = 0;
      this.canvas.y = 0;
      this.canvas.width = 1;
      this.canvas.height = 1;
      this.canvas.zIndex = '1';
      this.position = new Position(this.canvas);
      this.position.on('moved', () => {
        this.emit('moved');
      });
      this.emit('info', 'ScreenCanvas init success');
    } catch (e) {
      var errMsg = `ScreenCanvas init error:${getErrMsg(e)}`;
      this.emit('error', errMsg);
    }
    return this.canvas;
  }
  get screenCanvas() {
    return this.canvas;
  }
  get bindingScreen() {
    if (!this.canvas) {
      if (common.debug) {
        console.warn('[minigamefe PixiCore]: 无法获取bindingScreen，尚未创建ScreenCanvas');
      }
      return 0;
    }
    if (this.canvas.isNormalCanvas) {
      return 0;
    }
    return this.canvas.bindingScreen;
  }
  set zIndex(value) {
    if (!this.canvas) {
      return;
    }
    this.canvas.zIndex = value;
  }
  resize(data) {
    var {
      width,
      height,
      resetTouchArea = false
    } = data;
    if (common.debug) {
      console.log('[minigamefe PixiCore]: changeCanvasSize', width, height);
    }
    if (this.canvas) {
      if (typeof width !== 'undefined') {
        this.canvas.width = width;
      }
      if (typeof height !== 'undefined') {
        this.canvas.height = height;
      }
      this.emit('resize', {
        width: this.canvas.renderWidth,
        height: this.canvas.renderHeight,
        resetTouchArea
      });
      this.emit('render');
    }
  }
  hide() {
    var _a;
    (_a = this.position) === null || _a === void 0 ? void 0 : _a.hide();
  }
  show(pos) {
    var _a;
    (_a = this.position) === null || _a === void 0 ? void 0 : _a.show(pos);
  }
  destroy() {
    if (this.canvas) {
      this.canvas.remove();
      this.canvas = undefined;
    }
  }
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/core/display.js



var MAX_FONT_SIZE = 50;
var MAX_LINE_HEIGHT = 71;
var DEFAULT_FONT_SIZE = 12;
var DEFAULT_LINE_HEIGHT = 17;
class DisplayManager extends tiny_emitter.TinyEmitter {
  constructor() {
    super(...arguments);
    this.defaultTextStyle = {
      fill: 0xffffff,
      fontName: 'Arial',
      fontSize: DEFAULT_FONT_SIZE,
      whiteSpace: 'normal',
      textBaseline: 'middle',
      lineHeight: DEFAULT_LINE_HEIGHT
    };
    this.maxFontSize = MAX_FONT_SIZE;
    this.maxLineHeight = MAX_LINE_HEIGHT;
    this.defaultFontSize = DEFAULT_FONT_SIZE;
    this.defaultLineHeight = DEFAULT_LINE_HEIGHT;
    this.textures = {};
    this.bindingScreen = 0;
    this.cacheTextures = [];
    this.cachePixiTexts = [];
  }
  init(data) {
    var {
      bindingScreen,
      defaultTextStyle,
      defaultTextureName,
      defaultTextureKey
    } = data;
    this.bindingScreen = bindingScreen;
    this.initDesign(defaultTextStyle);
    this.defaultTextureName = defaultTextureName;
    this.defaultTextureKey = defaultTextureKey;
    if (common.debug) {
      console.log('[minigamefe PixiCore]: DisplayManager inited');
    }
  }
  createTextures(data) {
    var {
      name,
      imageData,
      jsonData
    } = data;
    return new Promise((resolve, reject) => {
      if (!imageData || imageData.indexOf('data:image') < 0 || !jsonData) {
        reject();
        return;
      }
      var {
        PIXI
      } = common;
      var sheet = new PIXI.Spritesheet(PIXI.BaseTexture.from(imageData), jsonData);
      sheet.parse(() => {
        this.addTextures({
          [name || this.defaultTextureName || '']: sheet
        });
        resolve(sheet);
      });
    });
  }
  addTextures(textures) {
    Object.assign(this.textures, textures);
  }
  getTexture(key = this.defaultTextureKey, name = this.defaultTextureName) {
    var _a, _b, _c;
    if (!name || !key) {
      if (common.debug) {
        console.error('[minigamefe PixiCore]: 请先设置通用纹理');
      }
      return PIXI.Texture.EMPTY;
    }
    if (!this.textures || !this.textures[name] || !this.textures[name].textures) {
      if (common.debug) {
        console.error('[minigamefe PixiCore]: 请先加载对应的纹理资源！', key, name);
      }
    }
    return (_c = (_b = (_a = this.textures) === null || _a === void 0 ? void 0 : _a[name].textures) === null || _b === void 0 ? void 0 : _b[key]) !== null && _c !== void 0 ? _c : PIXI.Texture.EMPTY;
  }
  createContainer(data) {
    var {
      PIXI
    } = common;
    var {
      x,
      y,
      isButton = false
    } = data || {};
    var node = new PIXI.Container();
    if (isButton) {
      this.isButton(node);
    }
    this.setNodeData({
      node,
      x,
      y
    });
    return node;
  }
  createSprite(data) {
    var {
      PIXI
    } = common;
    var {
      key = this.defaultTextureKey,
      name = this.defaultTextureName,
      isButton = false,
      x,
      y,
      width,
      height
    } = data || {};
    var node = new PIXI.Sprite(this.getTexture(key, name));
    if (isButton) {
      this.isButton(node);
    }
    this.setNodeData({
      node,
      x,
      y,
      width,
      height
    });
    return node;
  }
  createSpriteFrom(data) {
    var {
      PIXI
    } = common;
    var {
      bindingScreen
    } = this;
    var {
      url = PIXI.Texture.EMPTY,
      isButton = false,
      x,
      y,
      width,
      height
    } = data;
    var texture = url;
    if (typeof url === 'string') {
      texture = this.createTextureFrom({
        url
      });
    }
    var node = PIXI.Sprite.from(texture, {
      bindingScreen
    });
    if (isButton) {
      this.isButton(node);
    }
    this.setNodeData({
      node,
      x,
      y,
      width,
      height
    });
    return node;
  }
  createTexture(data) {
    var {
      PIXI
    } = common;
    var {
      bindingScreen
    } = this;
    var {
      url
    } = data;
    if (!url) {
      return this.getTexture();
    }
    var texture = new PIXI.Texture(new PIXI.BaseTexture(url, {
      bindingScreen
    }));
    texture.once('update', () => {
      this.emit('render');
    });
    this.cacheTextures.push(texture);
    return texture;
  }
  createTextureFrom(data) {
    var {
      PIXI
    } = common;
    var {
      bindingScreen
    } = this;
    var {
      url
    } = data;
    if (!url) {
      return this.getTexture();
    }
    var texture = PIXI.Texture.from(url, {
      bindingScreen
    });
    texture.once('update', () => {
      this.emit('render');
    });
    this.cacheTextures.push(texture);
    return texture;
  }
  createGraphics() {
    if (common.debug) {
      console.warn('[minigamefe PixiCore]: 如非必需请不要使用Graphics，会增加drawcall');
    }
    var {
      PIXI
    } = common;
    var {
      bindingScreen
    } = this;
    return new PIXI.Graphics(null, {
      bindingScreen
    });
  }
  createBitmapText(data) {
    var {
      PIXI
    } = common;
    var {
      textString = '',
      textStyle,
      anchor = new PIXI.Point(0, 0.5),
      isButton = false,
      x,
      y,
      width,
      height
    } = data || {};
    var renderTextStyle;
    var renderFontSize = this.defaultFontSize;
    if (textStyle) {
      renderTextStyle = Object.assign({}, this.defaultTextStyle, textStyle);
      renderFontSize = +(textStyle.fontSize || this.defaultFontSize);
    } else {
      renderTextStyle = this.defaultTextStyle;
    }
    var node;
    if (PIXI.BitmapText && PIXI.BitmapFont && renderTextStyle && renderTextStyle.fontName && PIXI.BitmapFont.available[renderTextStyle.fontName]) {
      node = new PIXI.BitmapText(textString, Object.assign({}, renderTextStyle, {
        fontSize: renderFontSize
      }));
      if (anchor) {
        node.anchor = anchor;
      }
      if (isButton) {
        this.isButton(node);
      }
      this.setNodeData({
        node,
        x,
        y,
        width,
        height
      });
    } else {
      node = this.createText({
        textString,
        textStyle: renderTextStyle,
        anchor,
        isButton,
        x,
        y,
        width,
        height
      });
    }
    return node;
  }
  createText(data) {
    var {
      PIXI
    } = common;
    var {
      textString = '',
      textStyle,
      anchor = new PIXI.Point(0, 0),
      isButton = false,
      x,
      y,
      width,
      height
    } = data || {};
    var renderTextStyle;
    var renderFontSize = this.defaultFontSize;
    var renderLineHeight = this.defaultLineHeight;
    if (textStyle) {
      renderTextStyle = Object.assign({}, this.defaultTextStyle, textStyle);
      renderFontSize = +(textStyle.fontSize || this.defaultFontSize);
      renderLineHeight = +(textStyle.lineHeight || this.defaultLineHeight);
    } else {
      renderTextStyle = this.defaultTextStyle;
    }
    if (renderTextStyle.wordWrapWidth) {
      renderTextStyle.wordWrapWidth /= renderFontSize / this.maxFontSize;
    }
    var node = new PIXI.Text(textString, Object.assign({}, renderTextStyle, {
      fontSize: this.maxFontSize,
      lineHeight: this.maxLineHeight * (renderLineHeight / this.defaultLineHeight)
    }), this.bindingScreen);
    node.scale.set(renderFontSize / this.maxFontSize);
    if (anchor) {
      node.anchor = anchor;
    }
    if (isButton) {
      this.isButton(node);
    }
    this.setNodeData({
      node,
      x,
      y,
      width,
      height
    });
    this.cachePixiTexts.push(node);
    return node;
  }
  setHitArea(node, style, key, debug = false) {
    var {
      PIXI,
      dpr
    } = common;
    var {
      x = 0,
      y = 0,
      width,
      height
    } = style;
    var getKey = key || this.defaultTextureKey;
    if (getKey) {
      var scale = 1 / node.scale.x;
      var innerNode = this.createSprite({
        key: getKey,
        x: x * scale,
        y: y * scale,
        width: width * scale,
        height: height * scale
      });
      if (debug) {
        innerNode.tint = 0xff0000;
        innerNode.alpha = 0.3;
      } else {
        innerNode.alpha = 0;
      }
      node.addChild(innerNode);
    } else {
      if (common.debug) {
        console.warn('[minigamefe PixiCore]: hitArea在x和y使用负数时有bug，建议传key或者设置默认精灵key');
      }
      node.hitArea = new PIXI.Rectangle(x * dpr, y * dpr, width * dpr, height * dpr);
    }
  }
  renderLabel(data) {
    var {
      PIXI
    } = common;
    var {
      textString = '',
      textStyle = this.defaultTextStyle,
      padding,
      backgroundColor,
      backgroundRadius,
      getLabelContainer
    } = data;
    var isFirst = !getLabelContainer;
    var labelBackground;
    var labelText;
    var labelContainer;
    if (!getLabelContainer) {
      labelContainer = new PIXI.Container();
      labelBackground = this.createGraphics();
      labelText = this.createText({
        textString,
        textStyle
      });
    } else {
      labelContainer = getLabelContainer;
      labelBackground = labelContainer.children[0];
      labelText = labelContainer.children[1];
    }
    labelText.text = textString;
    labelText.position.set(padding.left || 0, padding.top || 0);
    labelBackground.clear();
    labelBackground.beginFill(backgroundColor.fill, backgroundColor.alpha);
    labelBackground.drawRoundedRect(0, 0, labelText.width + (padding.left || 0) + (padding.right || 0), labelText.height + (padding.top || 0) + (padding.bottom || 0), backgroundRadius);
    labelBackground.endFill();
    if (isFirst && labelContainer) {
      labelContainer.addChild(labelBackground, labelText);
    }
    return {
      labelContainer,
      labelBackground,
      labelText
    };
  }
  createTextStyle(style) {
    var {
      PIXI
    } = common;
    return new PIXI.TextStyle(style);
  }
  getTextScale(fontSize = this.defaultFontSize) {
    return fontSize / this.maxFontSize;
  }
  isButton(node) {
    node.interactive = true;
    node.on('pointerup', () => {
      node.alpha = 1;
      this.emit('render');
    });
    node.on('pointerdown', () => {
      node.alpha = 0.5;
      this.emit('render');
    });
    node.on('pointerupoutside', () => {
      node.alpha = 1;
      this.emit('render');
    });
    node.on('pointercancel', () => {
      node.alpha = 1;
      this.emit('render');
    });
  }
  removeButton(node) {
    node.interactive = false;
    node.removeAllListeners('pointerup');
    node.removeAllListeners('pointerdown');
    node.removeAllListeners('pointerupoutside');
    node.removeAllListeners('pointertap');
    node.removeAllListeners('pointercancel');
  }
  get commonTextStyle() {
    return this.defaultTextStyle;
  }
  destroy() {
    for (var value of Object.values(this.textures)) {
      if (value.spritesheet) {
        value.spritesheet.destroy(true);
      }
    }
    for (var texture of this.cacheTextures) {
      texture.destroy(true);
    }
    for (var text of this.cachePixiTexts) {
      if (text.canvas) {
        text.destroy({
          children: true,
          texture: true,
          baseTexture: true
        });
      }
    }
    this.cacheTextures = [];
    this.cachePixiTexts = [];
    this.textures = {};
    this.defaultTextureName = '';
    this.defaultTextureKey = '';
  }
  setNodeData(data) {
    var {
      node,
      width,
      height,
      x = 0,
      y = 0
    } = data || {};
    if (isNumber(width)) {
      node.width = width;
    }
    if (isNumber(height)) {
      node.height = height;
    }
    if (isNumber(x) && isNumber(y)) {
      node.position.set(x, y);
    }
  }
  initDesign(textStyle) {
    if (textStyle) {
      Object.assign(this.defaultTextStyle, textStyle);
      this.defaultFontSize = +(textStyle.fontSize || DEFAULT_FONT_SIZE);
      this.defaultLineHeight = +(textStyle.lineHeight || DEFAULT_LINE_HEIGHT);
      this.maxFontSize = MAX_FONT_SIZE;
      this.maxLineHeight = MAX_FONT_SIZE / this.defaultFontSize * this.defaultLineHeight;
    }
  }
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/core/render.js


class RendererManager extends tiny_emitter.TinyEmitter {
  constructor() {
    super();
    this.needRender = false;
    this.ticker = null;
    this.autoRender = false;
    if (common.debug) {
      console.log('[minigamefe PixiCore]: RendererManager constructor');
    }
  }
  init(screenCanvas, debug = false, autoRender = false) {
    var {
      PIXI
    } = common;
    this.renderer = new PIXI.Renderer({
      view: screenCanvas.canvas,
      antialias: false,
      transparent: !debug,
      width: screenCanvas.renderWidth,
      height: screenCanvas.renderWidth,
      clearBeforeRender: false,
      preserveDrawingBuffer: true
    });
    this.innerStage = new PIXI.Container();
    this.innerStage.scale.set(common.dpr);
    this.autoRender = autoRender;
    this.renderer.on('postrender', () => {
      requestAnimationFrame(() => {
        this.emit('postrender');
      });
    });
    this.ticker = new PIXI.Ticker();
    this.ticker.add(this.render.bind(this));
    this.ticker.start();
    this.emit('info', 'Renderer init success');
    return this.renderer;
  }
  update() {
    this.needRender = true;
  }
  resize(width, height) {
    var _a;
    (_a = this.renderer) === null || _a === void 0 ? void 0 : _a.resize(width, height);
  }
  get stage() {
    return this.innerStage;
  }
  destroy() {
    if (this.ticker) {
      this.ticker.remove(this.render.bind(this));
      this.ticker.destroy();
      this.ticker = null;
    }
    if (this.innerStage) {
      this.innerStage.destroy();
      this.innerStage = undefined;
    }
    if (this.renderer) {
      this.renderer.destroy();
      this.renderer = undefined;
    }
  }
  render() {
    var _a;
    (_a = common.tweenGroup) === null || _a === void 0 ? void 0 : _a.update();
    if (!this.autoRender && !this.needRender) {
      return;
    }
    this.needRender = false;
    if (this.renderer) {
      this.renderer.render(this.stage, undefined, true);
    }
  }
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/core/const.js
var PIXI_ERROR = 'pixi_error';
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/common/index.js
function inHitArea(area, x, y) {
  return !!area.find(item => x >= item.left && x <= item.left + item.width && y >= item.top && y <= item.top + item.height);
}
var SnapType;
(function (SnapType) {
  SnapType[SnapType["None"] = 0] = "None";
  SnapType[SnapType["Horizontal"] = 1] = "Horizontal";
  SnapType[SnapType["Vertical"] = 2] = "Vertical";
  SnapType[SnapType["Left"] = 3] = "Left";
  SnapType[SnapType["Right"] = 4] = "Right";
  SnapType[SnapType["Top"] = 5] = "Top";
  SnapType[SnapType["Bottom"] = 6] = "Bottom";
  SnapType[SnapType["All"] = 7] = "All";
})(SnapType || (SnapType = {}));
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/minigame/const.js
var const_Platform;
(function (Platform) {
  Platform["devtools"] = "devtools";
  Platform["android"] = "android";
  Platform["ios"] = "ios";
  Platform["windows"] = "windows";
  Platform["mac"] = "mac";
})(const_Platform || (const_Platform = {}));
var DeviceOrientation;
(function (DeviceOrientation) {
  DeviceOrientation["portrait"] = "portrait";
  DeviceOrientation["landscape"] = "landscape";
  DeviceOrientation["landscapeLeft"] = "landscapeLeft";
  DeviceOrientation["landscapeRight"] = "landscapeRight";
})(DeviceOrientation || (DeviceOrientation = {}));
var EnvType;
(function (EnvType) {
  EnvType["DEVELOP"] = "develop";
  EnvType["TRIAL"] = "trial";
  EnvType["RELEASE"] = "release";
})(EnvType || (EnvType = {}));
var AppStateType;
(function (AppStateType) {
  AppStateType[AppStateType["release"] = 1] = "release";
  AppStateType[AppStateType["develop"] = 2] = "develop";
  AppStateType[AppStateType["trial"] = 3] = "trial";
})(AppStateType || (AppStateType = {}));
var const_RuntimeType;
(function (RuntimeType) {
  RuntimeType[RuntimeType["Android"] = 0] = "Android";
  RuntimeType[RuntimeType["IOSJscore"] = 1] = "IOSJscore";
  RuntimeType[RuntimeType["IOSWK"] = 2] = "IOSWK";
  RuntimeType[RuntimeType["UnKnow"] = 3] = "UnKnow";
  RuntimeType[RuntimeType["PC"] = 4] = "PC";
  RuntimeType[RuntimeType["Devtools"] = 5] = "Devtools";
  RuntimeType[RuntimeType["IPadJscore"] = 6] = "IPadJscore";
  RuntimeType[RuntimeType["IPadWK"] = 7] = "IPadWK";
})(const_RuntimeType || (const_RuntimeType = {}));
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/minigame/utils.js

function getRuntimeType(systemInfo) {
  var _a, _b;
  var runtimeType = RuntimeType.UnKnow;
  if (systemInfo.platform === Platform.devtools) {
    runtimeType = RuntimeType.Devtools;
  } else if (systemInfo.platform === Platform.ios) {
    runtimeType = ((_a = __webpack_require__.g) === null || _a === void 0 ? void 0 : _a.isIOSHighPerformanceMode) ? RuntimeType.IOSWK : RuntimeType.IOSJscore;
    if (systemInfo.model.indexOf('iPad') > -1) {
      runtimeType = ((_b = __webpack_require__.g) === null || _b === void 0 ? void 0 : _b.isIOSHighPerformanceMode) ? RuntimeType.IPadWK : RuntimeType.IPadJscore;
    }
  } else if (systemInfo.platform === Platform.android) {
    runtimeType = RuntimeType.Android;
  } else if (systemInfo.platform === Platform.windows) {
    runtimeType = RuntimeType.PC;
  }
  return runtimeType;
}
var cacheSafeArea = null;
function getSafeArea(useCache = false, systemInfo) {
  if (useCache && cacheSafeArea) {
    return cacheSafeArea;
  }
  var {
    safeArea
  } = systemInfo;
  var {
    deviceOrientation,
    screenWidth,
    screenHeight
  } = systemInfo;
  if (!safeArea) {
    safeArea = {
      top: 0,
      left: 0,
      right: screenWidth,
      bottom: screenHeight,
      width: screenWidth,
      height: screenHeight
    };
  }
  var {
    left,
    top,
    right,
    bottom,
    width,
    height
  } = safeArea;
  if (screenWidth > screenHeight) {
    if (deviceOrientation === DeviceOrientation.portrait || width < height) {
      left = safeArea.top;
      top = safeArea.left;
      right = safeArea.bottom;
      bottom = safeArea.right;
      width = safeArea.height;
      height = safeArea.width;
    } else if (width === screenHeight && width > height) {
      top = 0;
      left = 0;
      right = screenWidth;
      bottom = screenHeight;
      width = screenWidth;
      height = screenHeight;
    }
  }
  cacheSafeArea = {
    left,
    top,
    right,
    bottom,
    width,
    height
  };
  return cacheSafeArea;
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/screenCanvas/bindEvent.js
class TouchEvent {
  constructor(type) {
    this.target = null;
    this.currentTarget = [];
    this.touches = [];
    this.targetTouches = [];
    this.changedTouches = [];
    this.timeStamp = 0;
    this.buttons = 0;
    this.clientX = 0;
    this.clientY = 0;
    this.offsetX = 0;
    this.offsetY = 0;
    this.pageX = 0;
    this.pageY = 0;
    this.screenX = 0;
    this.screenY = 0;
    this.type = type;
  }
  preventDefault() {}
  stopPropagation() {}
}
function domTouchEventFilter(canvas, event) {
  var touchEvent = new TouchEvent('touch');
  var getTouches = event.touches;
  var getChangedTouches = event.changedTouches;
  if (event.target) {
    getTouches = Object.values(event.touches);
    getChangedTouches = Object.values(event.changedTouches);
  }
  touchEvent.touches = getTouches;
  touchEvent.targetTouches = Array.prototype.slice.call(getTouches);
  touchEvent.changedTouches = getChangedTouches;
  touchEvent.timeStamp = event.timeStamp;
  touchEvent.target = canvas;
  return touchEvent;
}
function getPixiJSCommonHandlers(renderer, canvas) {
  return {
    start: data => {
      var {
        event
      } = data;
      renderer.plugins.interaction.onPointerDown(domTouchEventFilter(canvas, event), 'touchstart');
    },
    move: data => {
      var {
        event
      } = data;
      renderer.plugins.interaction.onPointerMove(domTouchEventFilter(canvas, event), 'touchmove');
    },
    end: data => {
      var {
        event,
        isDraged
      } = data;
      if (!isDraged) {
        renderer.plugins.interaction.onPointerUp(domTouchEventFilter(canvas, event), 'touchend');
      } else {
        renderer.plugins.interaction.onPointerCancel(domTouchEventFilter(canvas, event), 'pointercancel');
      }
    }
  };
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/core/touch.js







class TouchEventManager extends tiny_emitter.TinyEmitter {
  constructor(canvas) {
    super();
    this.disabled = false;
    this.dragArea = [];
    this.padding = 8;
    this.preventArea = [];
    this.enableDrag = true;
    this.enableSnap = SnapType.Horizontal;
    this.isDraged = false;
    this.isMouseDown = false;
    this.isNormalCanvas = false;
    this.isPC = common.systemInfo.platform === const_Platform.windows || common.systemInfo.platform === const_Platform.mac;
    this.tweenGroup = common.tweenGroup;
    this.innerTween = common.TWEEN;
    this.borderAreaChanged = false;
    this.destroyed = false;
    this.dragParams = {
      identifier: 0,
      flag: false,
      pageX: 0,
      pageY: 0,
      startX: 0,
      startY: 0
    };
    this.pcListener = {};
    this.setBorderArea = area => {
      this.outDragArea = area;
      this.borderAreaChanged = true;
      this.resize();
    };
    this.setTouchArea = area => {
      this.dragArea = area;
      this.preventArea = area;
    };
    this.canvas = canvas;
    this.screenCanvas = canvas.screenCanvas;
    this.outDragArea = getSafeArea(false, common.systemInfo);
    this.isNormalCanvas = common.systemInfo.platform === 'devtools' || canvas.screenCanvas.isNormalCanvas;
    common.on('onDeviceOrientationChange', () => {
      if (!this.borderAreaChanged) {
        this.outDragArea = getSafeArea(false, common.systemInfo);
        this.resize();
      }
    });
    this.canvas.on('moved', () => {
      this.emit('render');
      this.snap(true);
    });
  }
  set canDrag(value) {
    this.enableDrag = value;
  }
  set snapType(value) {
    this.enableSnap = value;
  }
  resize() {
    if (!this.canvas.position.isHide) {
      this.canvas.position.set({
        x: clamp(this.screenCanvas.x, this.minDragX, this.maxDragX),
        y: clamp(this.screenCanvas.y, this.minDragY, this.maxDragY)
      });
      this.emit('render');
      this.snap(true);
    }
  }
  inDragArea(x, y) {
    if (!this.enableDrag) {
      return false;
    }
    if (this.dragArea.length === 0) {
      return false;
    }
    return inHitArea(this.dragArea, x, y);
  }
  inPreventArea(x, y) {
    if (this.preventArea.length === 0) {
      return false;
    }
    return inHitArea(this.preventArea, x, y);
  }
  enable() {
    this.disabled = false;
  }
  disable() {
    this.disabled = true;
  }
  get minDragX() {
    return this.outDragArea.left + this.padding;
  }
  get minDragY() {
    return this.outDragArea.top + this.padding;
  }
  get maxDragX() {
    return this.outDragArea.left + this.outDragArea.width - this.screenCanvas.width - this.padding;
  }
  get maxDragY() {
    return this.outDragArea.top + this.outDragArea.height - this.screenCanvas.height - this.padding;
  }
  bindScreenCanvasEventDispatch(handlers) {
    var {
      dragParams,
      screenCanvas
    } = this;
    var touchStartHandler = event => {
      var _a, _b;
      if (common.debug) {
        console.log('touchStartHandler, event:', event);
      }
      if (this.destroyed) {
        return true;
      }
      if (this.isPC && event.type === 'mousedown') {
        if (event.buttons === 0) {
          return false;
        }
        this.isMouseDown = true;
        var touchInfo = {
          identifier: 0,
          clientX: event.clientX,
          clientY: event.clientY,
          pageX: event.pageX,
          pageY: event.pageY,
          offsetX: event.offsetX,
          offsetY: event.offsetY,
          force: 1,
          screenX: event.screenX,
          screenY: event.screenY
        };
        event.touches = [touchInfo];
        event.changedTouches = [touchInfo];
      }
      var touch = event.changedTouches[0] || event.touches[0];
      var {
        pageX,
        pageY
      } = touch;
      var {
        offsetX,
        offsetY
      } = touch;
      if (this.isNormalCanvas || this.isPC) {
        offsetX = pageX - screenCanvas.x;
        offsetY = pageY - screenCanvas.y;
      }
      var isPrevent = this.inPreventArea(offsetX, offsetY);
      if (!isPrevent) {
        if (common.debug) {
          console.log('touchStartHandler isPrevent');
        }
        return true;
      }
      if (this.disabled) {
        if (common.debug) {
          console.log('touchStartHandler disabled');
        }
        (_a = handlers === null || handlers === void 0 ? void 0 : handlers.start) === null || _a === void 0 ? void 0 : _a.call(handlers, {
          event,
          isPrevent,
          isDraging: dragParams.flag
        });
        this.emit('render');
        return !isPrevent;
      }
      if (this.inDragArea(offsetX, offsetY)) {
        if (common.debug) {
          console.log('touchStartHandler need drag');
        }
        dragParams.identifier = touch.identifier;
        dragParams.flag = true;
        dragParams.pageX = pageX;
        dragParams.pageY = pageY;
        dragParams.startX = pageX;
        dragParams.startY = pageY;
      }
      this.isDraged = false;
      if (common.debug) {
        console.log('touchStartHandler pixi touchstart');
      }
      (_b = handlers === null || handlers === void 0 ? void 0 : handlers.start) === null || _b === void 0 ? void 0 : _b.call(handlers, {
        event,
        isPrevent,
        isDraging: dragParams.flag
      });
      this.emit('render');
      return !isPrevent;
    };
    var touchMoveHandler = event => {
      var _a, _b;
      if (common.debug) {
        console.log('touchMoveHandler, event:', event);
      }
      if (this.destroyed) {
        return true;
      }
      if (this.isPC && !this.isMouseDown) {
        return false;
      }
      var touch = event.changedTouches[0] || event.touches[0];
      var {
        pageX,
        pageY
      } = touch;
      var {
        offsetX,
        offsetY
      } = touch;
      if (this.isNormalCanvas || this.isPC) {
        offsetX = pageX - screenCanvas.x;
        offsetY = pageY - screenCanvas.y;
      }
      var isPrevent = this.inPreventArea(offsetX, offsetY);
      if (this.disabled) {
        (_a = handlers === null || handlers === void 0 ? void 0 : handlers.move) === null || _a === void 0 ? void 0 : _a.call(handlers, {
          event,
          isPrevent
        });
        this.emit('render');
        return !isPrevent;
      }
      if (dragParams.flag && dragParams.identifier === touch.identifier) {
        var disX = pageX - dragParams.pageX;
        var disY = pageY - dragParams.pageY;
        var newX = screenCanvas.x + disX;
        var newY = screenCanvas.y + disY;
        newX = clamp(newX, this.minDragX, this.maxDragX);
        newY = clamp(newY, this.minDragY, this.maxDragY);
        screenCanvas.x = newX;
        screenCanvas.y = newY;
        dragParams.pageX = pageX;
        dragParams.pageY = pageY;
        var dragDiffX = Math.abs(pageX - dragParams.startX);
        var dragDiffY = Math.abs(pageY - dragParams.startY);
        if (dragDiffX > 0.5 || dragDiffY > 0.5) {
          this.isDraged = true;
          this.emit('dragStart');
        }
      } else {
        (_b = handlers === null || handlers === void 0 ? void 0 : handlers.move) === null || _b === void 0 ? void 0 : _b.call(handlers, {
          event,
          isPrevent
        });
        this.emit('render');
      }
      return !isPrevent;
    };
    var touchEndHandler = event => {
      var _a, _b;
      if (common.debug) {
        console.log('touchEndHandler, event:', event);
      }
      if (this.destroyed) {
        return true;
      }
      if (this.isPC) {
        if (!this.isMouseDown) {
          return false;
        }
        this.isMouseDown = false;
      }
      var touch = event.changedTouches[0] || event.touches[0];
      var {
        pageX,
        pageY
      } = touch;
      var {
        offsetX,
        offsetY
      } = touch;
      if (this.isNormalCanvas || this.isPC) {
        offsetX = pageX - screenCanvas.x;
        offsetY = pageY - screenCanvas.y;
      }
      if (this.isDraged) {
        this.snap();
      }
      var isPrevent = this.inPreventArea(offsetX, offsetY);
      if (this.disabled) {
        (_a = handlers === null || handlers === void 0 ? void 0 : handlers.end) === null || _a === void 0 ? void 0 : _a.call(handlers, {
          event,
          isPrevent,
          isDraged: this.isDraged
        });
        this.emit('render');
        this.isDraged = false;
        dragParams.flag = false;
        return !isPrevent;
      }
      if (dragParams.flag) {
        if (dragParams.identifier !== touch.identifier) {
          return !isPrevent;
        }
        dragParams.flag = false;
        this.emit('dragEnd');
        this.emit('render');
      }
      (_b = handlers === null || handlers === void 0 ? void 0 : handlers.end) === null || _b === void 0 ? void 0 : _b.call(handlers, {
        event,
        isPrevent,
        isDraged: this.isDraged
      });
      this.emit('render');
      this.isDraged = false;
      return !isPrevent;
    };
    if (screenCanvas.canvas) {
      if (screenCanvas.isNormalCanvas) {
        return {
          touchStartHandler,
          touchMoveHandler,
          touchEndHandler
        };
      }
      if (this.isNormalCanvas) {
        screenCanvas.canvas.addEventListener('touchstart', touchStartHandler);
        screenCanvas.canvas.addEventListener('touchmove', touchMoveHandler);
        screenCanvas.canvas.addEventListener('touchend', touchEndHandler);
        screenCanvas.canvas.addEventListener('touchcancel', touchEndHandler);
      } else if (this.isPC) {
        screenCanvas.canvas.addEventListener('mousedown', touchInfo => {
          if (typeof transformNativeEvent === 'function') {
            touchInfo = transformNativeEvent(touchInfo);
          }
          if (common.debug) {
            console.log('mousedown touchInfo:', touchInfo);
          }
          return touchStartHandler(touchInfo);
        });
        var {
          onTouchMove,
          onTouchEnd,
          onTouchCancel
        } = common.wx;
        var commonTouchListener = cb => result => {
          var {
            touches,
            changedTouches
          } = result;
          var touch = new TouchEvent('mouse');
          touch.touches = touches;
          touch.changedTouches = changedTouches;
          cb && cb(touch);
        };
        this.pcListener.moveListener = commonTouchListener(touchMoveHandler);
        this.pcListener.endListener = commonTouchListener(touchEndHandler);
        this.pcListener.cancelListener = commonTouchListener(touchEndHandler);
        if (common.debug) {
          if (typeof onTouchMove === 'undefined') {
            console.error('缺少wx.onTouchMove');
          }
          if (typeof onTouchEnd === 'undefined') {
            console.error('缺少wx.onTouchEnd');
          }
          if (typeof onTouchCancel === 'undefined') {
            console.error('缺少wx.onTouchCancel');
          }
        }
        onTouchMove === null || onTouchMove === void 0 ? void 0 : onTouchMove(this.pcListener.moveListener);
        onTouchEnd === null || onTouchEnd === void 0 ? void 0 : onTouchEnd(this.pcListener.endListener);
        onTouchCancel === null || onTouchCancel === void 0 ? void 0 : onTouchCancel(this.pcListener.cancelListener);
      } else {
        screenCanvas.canvas.ontouchstart = touchStartHandler;
        screenCanvas.canvas.ontouchmove = touchMoveHandler;
        screenCanvas.canvas.ontouchend = touchEndHandler;
        screenCanvas.canvas.ontouchcancel = touchEndHandler;
      }
    }
    return;
  }
  snap(now = false) {
    if (common.debug) {
      console.log('snap', this.enableSnap === SnapType.None, this.disabled);
    }
    if (this.enableSnap === SnapType.None) {
      return;
    }
    if (this.disabled) {
      return;
    }
    var {
      screenCanvas
    } = this;
    var targetValue = 0;
    var targetType = 'x';
    var time = 0;
    var snapDirection = this.getSnapDirection();
    if (snapDirection === SnapType.Right) {
      targetValue = this.maxDragX;
    } else if (snapDirection === SnapType.Left) {
      targetValue = this.minDragX;
    } else if (snapDirection === SnapType.Top) {
      targetType = 'y';
      targetValue = this.minDragY;
    } else if (snapDirection === SnapType.Bottom) {
      targetType = 'y';
      targetValue = this.maxDragY;
    }
    time = Math.round(Math.abs(targetValue - screenCanvas[targetType]) * 2);
    this.emit('snapStart', snapDirection);
    var snapImmediately = () => {
      screenCanvas[targetType] = targetValue;
      this.emit('snapEnd', snapDirection);
      this.emit('render');
    };
    if (now) {
      snapImmediately();
    } else if (time && time > 0) {
      if (this.tweenGroup && this.innerTween) {
        this.disable();
        new this.innerTween.Tween(screenCanvas, this.tweenGroup).to({
          [targetType]: targetValue
        }, time).easing(this.innerTween.Easing.Quadratic.InOut).onComplete(() => {
          this.enable();
          this.emit('snapEnd', snapDirection);
          this.emit('render');
        }).start();
      } else {
        if (common.debug) {
          console.error('[minigamefe PixiCore]: tweenGroup&tween实例异常');
        }
        snapImmediately();
      }
    } else {
      snapImmediately();
    }
  }
  destroy() {
    this.destroyed = true;
    if (this.isPC) {
      var {
        offTouchMove,
        offTouchEnd,
        offTouchCancel
      } = common.wx;
      if (this.pcListener.moveListener) {
        offTouchMove === null || offTouchMove === void 0 ? void 0 : offTouchMove(this.pcListener.moveListener);
      }
      if (this.pcListener.endListener) {
        offTouchEnd === null || offTouchEnd === void 0 ? void 0 : offTouchEnd(this.pcListener.endListener);
      }
      if (this.pcListener.cancelListener) {
        offTouchCancel === null || offTouchCancel === void 0 ? void 0 : offTouchCancel(this.pcListener.cancelListener);
      }
    }
  }
  getSnapDirection() {
    var {
      screenCanvas,
      outDragArea
    } = this;
    var snapDirection = this.enableSnap;
    var centerPos = {
      x: screenCanvas.x + screenCanvas.width / 2,
      y: screenCanvas.y + screenCanvas.height / 2
    };
    if (this.enableSnap === SnapType.Horizontal) {
      if (centerPos.x <= outDragArea.left + outDragArea.width / 2) {
        snapDirection = SnapType.Left;
      } else {
        snapDirection = SnapType.Right;
      }
    } else if (this.enableSnap === SnapType.Vertical) {
      if (centerPos.y <= outDragArea.top + outDragArea.height / 2) {
        snapDirection = SnapType.Top;
      } else {
        snapDirection = SnapType.Bottom;
      }
    } else if (this.enableSnap === SnapType.All) {
      var getDisTop = Math.round(centerPos.y - outDragArea.top);
      var getDisBottom = Math.round(outDragArea.height + outDragArea.top - centerPos.y);
      var getDisLeft = Math.round(centerPos.x - outDragArea.left);
      var getDisRight = Math.round(outDragArea.width + outDragArea.left - centerPos.x);
      var minDis = Math.min(getDisLeft, getDisRight, getDisTop, getDisBottom);
      if (minDis === getDisLeft) {
        snapDirection = SnapType.Left;
      } else if (minDis === getDisBottom) {
        snapDirection = SnapType.Bottom;
      } else if (minDis === getDisRight) {
        snapDirection = SnapType.Right;
      } else if (minDis === getDisTop) {
        snapDirection = SnapType.Top;
      } else {
        snapDirection = SnapType.Left;
      }
    }
    return snapDirection;
  }
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/utils.js

function getGlobalPosition(node, point = null) {
  var PIXI = getPIXI();
  var newPoint = new PIXI.Point();
  if (point) {
    newPoint.x = point.x + node.x;
    newPoint.y = point.y + node.y;
  } else {
    newPoint.x = node.x;
    newPoint.y = node.y;
  }
  if (node.parent) {
    return getGlobalPosition(node.parent, newPoint);
  }
  return newPoint;
}
function debugBox(node, texture) {
  if (true) {
    return;
  }
  var parentNode = node;
  var debugNode;
  if (parentNode.debugNode) {
    debugNode = parentNode.debugNode;
  } else {
    var PIXI = getPIXI();
    debugNode = new PIXI.Sprite(texture);
    debugNode.alpha = 0.6;
    debugNode.tint = 0xff0000;
    parentNode.parent.addChild(debugNode);
    parentNode.debugNode = debugNode;
  }
  debugNode.width = node.width;
  debugNode.height = node.height;
  debugNode.position.set(node.x, node.y);
}
function compatiblePixiJsPoint(renderer) {
  renderer.plugins.interaction.mapPositionToPoint = (point, x, y) => {
    if (renderer) {
      var dom = renderer.plugins.interaction.interactionDOMElement;
      var rect = dom.getBoundingClientRect();
      var resolutionMultiplier = 1.0 / renderer.plugins.interaction.resolution;
      point.set((x - rect.left) * (dom.width / rect.width) * resolutionMultiplier, (y - rect.top) * (dom.height / rect.height) * resolutionMultiplier);
    }
  };
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/core/index.js













class PixiJsCore extends tiny_emitter.TinyEmitter {
  constructor(data) {
    var _a;
    super();
    this.destroyed = false;
    var {
      TWEEN,
      mgp,
      xlog,
      quality,
      designWidth = 375,
      createScreenCanvas,
      createCanvas,
      gameWX,
      scale = 1,
      debug = false
    } = data;
    if (!gameWX && debug) {
      console.error('[minigamefe PixiCore]: 请正确传入gameWX对象');
    }
    var pixiJs = pixi_getPIXI();
    if (pixiJs && pixiJs.settings) {
      pixiJs.settings.SPRITE_MAX_TEXTURES = 32;
    } else if (debug) {
      console.error('[minigamefe PixiCore]: 请先引入插件环境或者基础库环境的PIXI，并调用setPIXI');
    }
    if (!TWEEN && debug) {
      console.error('[minigamefe PixiCore]: 请先传入TWEEN');
    }
    if (mgp) {
      this.xlog = mgp.xlog;
      this.quality = mgp.quality;
    } else {
      if ((!quality || !xlog) && debug) {
        console.error('[minigamefe PixiCore]: 插件环境请传入MGP，基础库环境单独传入quality和xlog');
      }
      this.xlog = xlog;
      this.quality = quality;
    }
    common.init({
      pixiJs,
      TWEEN,
      gameWX,
      designWidth,
      scale,
      debug
    });
    if (debug && typeof createScreenCanvas === 'undefined' && typeof createCanvas === 'undefined') {
      console.error('[minigamefe PixiCore]: 至少传入一种创建canvas函数');
    }
    this.canvas = new CanvasManager({
      createScreenCanvas,
      createCanvas
    });
    this.renderer = new RendererManager();
    this.display = new DisplayManager();
    this.bindEvent(this.canvas);
    this.bindEvent(this.renderer);
    this.bindEvent(this.display);
    (_a = gameWX === null || gameWX === void 0 ? void 0 : gameWX.onShow) === null || _a === void 0 ? void 0 : _a.call(gameWX, () => {
      this.updateRender();
    });
    if (debug) {
      console.info('[minigamefe PixiCore]: inited');
    }
  }
  get isSupportBitMapText() {
    if (!common.systemInfo) {
      return false;
    }
    return compareVersion(common.systemInfo.SDKVersion, '2.24.7') >= 0;
  }
  init(data) {
    if (!this.canvas.screenCanvas) {
      if (common.debug) {
        console.error('[minigamefe PixiCore]: 请先调用pixiJsCore.canvas.init()');
      }
      return;
    }
    var {
      defaultTextureName,
      defaultTextureKey,
      defaultTextStyle,
      autoRender = false,
      debug = false
    } = data;
    var pixiRenderer = this.renderer.init(this.canvas.screenCanvas, debug, autoRender);
    if (compareVersion(common.systemInfo.SDKVersion, '2.20.2') <= 0) {
      compatiblePixiJsPoint(pixiRenderer);
    }
    this.touch = new TouchEventManager(this.canvas);
    this.bindTouchEvent(pixiRenderer);
    this.canvas.on('resize', data => {
      var _a, _b;
      var {
        width,
        height,
        resetTouchArea
      } = data;
      this.renderer.resize(width, height);
      (_a = this.touch) === null || _a === void 0 ? void 0 : _a.resize();
      if (resetTouchArea && this.canvas.screenCanvas) {
        (_b = this.touch) === null || _b === void 0 ? void 0 : _b.setTouchArea([{
          top: 0,
          left: 0,
          width: this.canvas.screenCanvas.width,
          height: this.canvas.screenCanvas.height
        }]);
      }
    });
    this.display.init({
      bindingScreen: this.canvas.bindingScreen,
      defaultTextureName,
      defaultTextureKey,
      defaultTextStyle
    });
    this.bindEvent(this.touch);
    common.on('onDeviceOrientationChange', () => {
      this.emit('onDeviceOrientationChange');
      this.updateRender();
    });
  }
  load(data) {
    if (!this.canvas.screenCanvas) {
      if (common.debug) {
        console.warn('[minigamefe PixiCore]: 请先调用pixiJsCore.canvas.init()');
      }
    }
    var {
      timeout,
      list,
      mainTextureName
    } = data;
    if (!this.loader) {
      this.loader = new LoaderManager();
      this.bindEvent(this.loader);
    }
    return new Promise((resolve, reject) => {
      if (!this.loader) {
        reject({
          errorMsg: '已销毁'
        });
        return;
      }
      this.loader.load({
        timeout,
        mainTextureName,
        list,
        bindingScreen: this.canvas.bindingScreen
      }).then(res => {
        if (res && res.resources) {
          this.display.addTextures(res.resources);
          resolve(res.resources);
        } else {
          this.qualityReport(PIXI_ERROR, res.errMsg || 'minigamefe PixiCore Load资源加载失败');
          reject({
            errorMsg: res.errMsg || '加载失败'
          });
        }
      }).catch(res => {
        this.qualityReport(PIXI_ERROR, res.errMsg || 'minigamefe PixiCore Load资源加载失败');
        reject({
          errorMsg: res.errMsg || '加载失败'
        });
      });
    });
  }
  tween(node) {
    return new common.TWEEN.Tween(node, this.tweenGroup).onUpdate(() => {
      this.updateRender();
    });
  }
  removeTween(tween) {
    this.tweenGroup.remove(tween);
  }
  destroy() {
    var _a, _b;
    if (this.destroyed) {
      return;
    }
    this.destroyed = true;
    (_a = this.loader) === null || _a === void 0 ? void 0 : _a.destroy();
    this.renderer.destroy();
    this.canvas.destroy();
    this.display.destroy();
    (_b = this.touch) === null || _b === void 0 ? void 0 : _b.destroy();
    common.destroy();
  }
  get touchEventHandler() {
    return this.innerTouchEventHandler;
  }
  get tweenGroup() {
    return common.tweenGroup;
  }
  updateRender() {
    this.renderer.update();
  }
  get stage() {
    return this.renderer.stage;
  }
  get pixelRatio() {
    return common.dpr;
  }
  bindTouchEvent(renderer) {
    var _a;
    if (!this.canvas.screenCanvas) {
      return;
    }
    var handlers = getPixiJSCommonHandlers(renderer, this.canvas.screenCanvas.canvas);
    this.innerTouchEventHandler = (_a = this.touch) === null || _a === void 0 ? void 0 : _a.bindScreenCanvasEventDispatch(handlers);
  }
  bindEvent(node) {
    node.on('postrender', () => {
      this.emit('render');
    });
    node.on('render', () => {
      this.updateRender();
      this.emit('render');
    });
    node.on('error', errMsg => {
      this.qualityReport(PIXI_ERROR, errMsg);
    });
    node.on('info', this.xlogReport.bind(this));
  }
  xlogReport(msg) {
    var _a;
    (_a = this.xlog) === null || _a === void 0 ? void 0 : _a.info(msg);
  }
  qualityReport(name, errMsg) {
    var _a;
    (_a = this.quality) === null || _a === void 0 ? void 0 : _a.report({
      Type: ReportType.Error,
      Target: name,
      IsError: 1,
      Result: errMsg
    });
  }
}
;// CONCATENATED MODULE: ../../node_modules/.pnpm/flatted@3.3.1/node_modules/flatted/esm/index.js
var {
  parse: $parse,
  stringify: $stringify
} = JSON;
var {
  keys
} = Object;
var Primitive = String;
var primitive = 'string';
var ignore = (/* unused pure expression or super */ null && ({}));
var object = 'object';
var noop = (_, value) => value;
var primitives = value => value instanceof Primitive ? Primitive(value) : value;
var Primitives = (_, value) => typeof value === primitive ? new Primitive(value) : value;
var revive = (input, parsed, output, $) => {
  var lazy = [];
  for (var ke = keys(output), {
      length
    } = ke, y = 0; y < length; y++) {
    var k = ke[y];
    var value = output[k];
    if (value instanceof Primitive) {
      var tmp = input[value];
      if (typeof tmp === object && !parsed.has(tmp)) {
        parsed.add(tmp);
        output[k] = ignore;
        lazy.push({
          k,
          a: [input, parsed, tmp, $]
        });
      } else output[k] = $.call(output, k, tmp);
    } else if (output[k] !== ignore) output[k] = $.call(output, k, value);
  }
  for (var {
      length: _length
    } = lazy, i = 0; i < _length; i++) {
    var {
      k: _k,
      a
    } = lazy[i];
    output[_k] = $.call(output, _k, revive.apply(null, a));
  }
  return output;
};
var set = (known, input, value) => {
  var index = Primitive(input.push(value) - 1);
  known.set(value, index);
  return index;
};
var parse = (text, reviver) => {
  var input = $parse(text, Primitives).map(primitives);
  var value = input[0];
  var $ = reviver || noop;
  var tmp = typeof value === object && value ? revive(input, new Set(), value, $) : value;
  return $.call({
    '': tmp
  }, '', tmp);
};
var stringify = (value, replacer, space) => {
  var $ = replacer && typeof replacer === object ? (k, v) => k === '' || -1 < replacer.indexOf(k) ? v : void 0 : replacer || noop;
  var known = new Map();
  var input = [];
  var output = [];
  var i = +set(known, input, $.call({
    '': value
  }, '', value));
  var firstRun = !i;
  while (i < input.length) {
    firstRun = true;
    output[i] = $stringify(input[i++], replace, space);
  }
  return '[' + output.join(',') + ']';
  function replace(key, value) {
    if (firstRun) {
      firstRun = !firstRun;
      return value;
    }
    var after = $.call(this, key, value);
    switch (typeof after) {
      case object:
        if (after === null) return after;
      case primitive:
        return known.get(after) || set(known, input, after);
    }
    return after;
  }
};
var toJSON = value => $parse(stringify(value));
var fromJSON = value => parse($stringify(value));
;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/minigame/xlog.js

var LogType;
(function (LogType) {
  LogType["log"] = "log";
  LogType["info"] = "info";
  LogType["warn"] = "warn";
  LogType["error"] = "error";
})(LogType || (LogType = {}));
class XLog {
  constructor({
    reportFunc,
    base,
    debug,
    delimiter,
    namespace
  }) {
    this.reportFunc = null;
    this.debug = false;
    this.base = {};
    this.delimiter = ' ';
    this.namespace = '';
    if (!reportFunc) {
      console.error('[minigamefe XLog]: 未传入上报函数。');
      return;
    }
    this.reportFunc = reportFunc;
    if (base) {
      this.setBase(base);
    }
    this.debug = !!debug;
    if (delimiter) {
      this.delimiter = delimiter;
    }
    this.namespace = namespace ? ` ${namespace} ` : ' ';
  }
  setBase(base) {
    this.base = Object.assign(Object.assign({}, this.base), base);
  }
  log(...content) {
    this.report(LogType.log, content);
  }
  info(...content) {
    this.report(LogType.info, content);
  }
  warn(...content) {
    this.report(LogType.warn, content);
  }
  error(...content) {
    this.report(LogType.error, content);
  }
  getLogStr(type, getContent) {
    var _a;
    if (!this.reportFunc) {
      console.error(`[minigamefe${this.namespace}XLog]: 未传入上报函数。`);
      return '';
    }
    if (!getContent) {
      return '';
    }
    var content = '';
    getContent.forEach(it => {
      if (content.length > 0) {
        content += this.delimiter;
      }
      var value = it;
      if (typeof value === 'object') {
        if (value instanceof TypeError) {
          value = value.message;
        } else {
          value = stringify(value);
        }
      }
      content += `${String(value).trim()}`;
    });
    var res = `[minigamefe${this.namespace}XLog]: ${JSON.stringify(Object.assign(Object.assign({}, this.base), {
      type,
      content
    }))}`;
    if (this.debug) {
      (_a = console[type]) === null || _a === void 0 ? void 0 : _a.call(console, res);
    }
    return res;
  }
  report(type, content) {
    var {
      reportFunc
    } = this;
    if (!reportFunc) {
      console.error(`[minigamefe${this.namespace}XLog]: 未传入上报函数。`);
      return;
    }
    if (!reportFunc[type] || typeof reportFunc[type] !== 'function') {
      console.error(`[minigamefe${this.namespace}XLog]: 传入的上报函数格式不对。`);
      return;
    }
    var str = this.getLogStr(type, content);
    if (!str) {
      return;
    }
    reportFunc[type](str);
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/logic/core.ts





var {
  _onShow: onShow,
  getSystemInfoSync,
  onDeviceOrientationChange,
  createScreenCanvas,
  touch,
  TWEEN
} = __appServiceSDK__;
var {
  onTouchMove,
  offTouchMove,
  onTouchEnd,
  offTouchEnd,
  onTouchCancel,
  offTouchCancel
} = touch;
var pixiJsCore;
function createPixiJsCore() {
  wxConsole.warn('createPixiJsCore');
  setPIXI(PIXI);
  pixiJsCore = new PixiJsCore({
    TWEEN,
    createScreenCanvas,
    xlog: new XLog({
      reportFunc: wxNativeConsole,
      namespace: ProjectName,
      base: {
        name: ProjectName
      }
    }),
    quality: qualityReport,
    gameWX: {
      onShow,
      getSystemInfoSync,
      onDeviceOrientationChange,
      onTouchMove,
      offTouchMove,
      onTouchEnd,
      offTouchEnd,
      onTouchCancel,
      offTouchCancel
    }
  });
}

;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/common/util.ts



var {
  getSystemInfoSync: util_getSystemInfoSync
} = __appServiceSDK__;
var info;
function getInfoSync() {
  if (info) {
    return info;
  }
  info = util_getSystemInfoSync();
  return info;
}
function sendError(errMsg, IsError = true) {
  qualityReport === null || qualityReport === void 0 ? void 0 : qualityReport.report({
    Type: PluginReportType.Error,
    Target: `${ProjectName}Error`,
    IsError: IsError ? 1 : 0,
    Result: errMsg
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/common/design.ts

var PADDING = 8;
var design = {
  ready: false,
  padding: PADDING,
  position: {
    x: 0,
    y: 0
  },
  iconSize: {
    width: 32,
    height: 32
  },
  size: {
    width: 32 + PADDING * 3,
    height: 32 + PADDING * 2
  },
  screen: {
    width: 0,
    height: 0
  }
};
var commonStyle = {
  fill: 0xffffff,
  fontSize: 12,
  whiteSpace: 'normal',
  textBaseline: 'middle',
  lineHeight: 16,
  dropShadow: true,
  dropShadowColor: 'rgba(0, 0, 0, 0.8)',
  dropShadowDistance: 1
};
var designStyle = {
  commonStyle
};
var setDesignFromInfo = info => {
  design.ready = true;
  var {
    screenWidth,
    screenHeight
  } = info;
  design.screen.width = screenWidth;
  design.screen.height = screenHeight;
  design.position.y = screenHeight / 2 - design.size.height / 2;
};
function designReady() {
  return new Promise(resolve => {
    if (design.ready) {
      resolve(design);
    } else {
      var info = getInfoSync();
      setDesignFromInfo(info);
      resolve(design);
    }
  });
}

;// CONCATENATED MODULE: ../../node_modules/.pnpm/@tencent+minigamefe@1.1.45/node_modules/@tencent/minigamefe/canvas/pixijs/graphics.js
function drawRoundRect(data) {
  var {
    node,
    x = 0,
    y = 0,
    width = 1,
    height = 1,
    radius = 0,
    fill,
    line,
    clear = false
  } = data;
  var getRadius;
  if (typeof radius === 'number') {
    getRadius = {
      tl: radius,
      tr: radius,
      br: radius,
      bl: radius
    };
  } else {
    getRadius = radius;
  }
  if (getRadius.tl + getRadius.tr > width || getRadius.bl + getRadius.br > width) {
    console.error('左右radius总和要小于width');
  }
  if (getRadius.tl + getRadius.bl > height || getRadius.tr + getRadius.br > height) {
    console.error('上下radius总和要小于height');
  }
  if (clear) {
    node.clear();
  }
  if (line) {
    node.lineStyle(line.width, line.color || 0x0, line.alpha || 1, line.alignment, line.native);
  }
  if (fill) {
    node.beginFill(fill.color || 0x0, fill.alpha || 1);
  }
  if (fill || line) {
    node.moveTo(x + getRadius.tl, y);
    node.lineTo(x + width - getRadius.tr, y);
    if (getRadius.tr > 0) {
      node.quadraticCurveTo(x + width, y, x + width, y + getRadius.tr);
    }
    node.lineTo(x + width, y + height - getRadius.br);
    if (getRadius.br > 0) {
      node.quadraticCurveTo(x + width, y + height, x + width - getRadius.br, y + height);
    }
    node.lineTo(x + getRadius.bl, y + height);
    if (getRadius.bl > 0) {
      node.quadraticCurveTo(x, y + height, x, y + height - getRadius.bl);
    }
    node.lineTo(x, y + getRadius.tl);
    if (getRadius.tl > 0) {
      node.quadraticCurveTo(x, y, x + getRadius.tl, y);
    }
    node.closePath();
  }
  if (fill) {
    node.endFill();
  }
}
function roundRect(Graphics, x, y, width, height, radius = 0, color, clear = false) {
  var getRadius;
  if (typeof radius === 'number') {
    getRadius = {
      tl: radius,
      tr: radius,
      br: radius,
      bl: radius
    };
  } else {
    getRadius = radius;
  }
  if (clear) {
    Graphics.clear();
  }
  Graphics.beginFill(color.fill, color.alpha);
  Graphics.moveTo(x + getRadius.tl, y);
  Graphics.lineTo(x + width - getRadius.tr, y);
  Graphics.quadraticCurveTo(x + width, y, x + width, y + getRadius.tr);
  Graphics.lineTo(x + width, y + height - getRadius.br);
  Graphics.quadraticCurveTo(x + width, y + height, x + width - getRadius.br, y + height);
  Graphics.lineTo(x + getRadius.bl, y + height);
  Graphics.quadraticCurveTo(x, y + height, x, y + height - getRadius.bl);
  Graphics.lineTo(x, y + getRadius.tl);
  Graphics.quadraticCurveTo(x, y, x + getRadius.tl, y);
  Graphics.endFill();
}
;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/report/index.ts
var {
  KeyValueReport20267
} = __appServiceSDK__;
var report20267 = new KeyValueReport20267();
report20267.setBase({
  SceneID: 66,
  UIArea: 6601
});
function send(data) {
  if (data.ExternInfo && typeof data.ExternInfo !== 'string') {
    data.ExternInfo = JSON.stringify(data.ExternInfo);
  }
  report20267.send(data);
}
function expose(text) {
  send({
    PositionID: 0,
    ActionID: 1,
    Status: text.length > 0 ? '1' : '2',
    ExternInfo: {
      text
    }
  });
}
function click(text) {
  send({
    PositionID: 1,
    ActionID: 2,
    Status: text.length > 0 ? '1' : '2',
    ExternInfo: {
      text
    }
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/render/webview.ts




var {
  onDeviceOrientationChange: webview_onDeviceOrientationChange,
  createWebView,
  hideLoading,
  showLoading,
  showToast,
  IS_PC,
  WXConfig
} = __appServiceSDK__;
var cacheHashQueue = [];
var cacheMessage = {};
var postMessageTicker = null;
class WebviewManager {
  constructor() {
    this.webview = null;
    this.visible = false;
    this.ready = false;
    this.realSrc = '';
    this.realStyle = {};
    this.hashChanging = false;
    this.clearHashTicker = null;
    this.isSupportGameWebview = false;
    this.webviewInitTime = 0;
  }
  init(src) {
    this.webviewInitTime = Date.now();
    webviewInit();
    if (IS_PC) {
      this.isSupportGameWebview = true;
    } else {
      var systemInfo = getInfoSync();
      this.isSupportGameWebview = compareVersion(systemInfo.version, '8.0.30') >= 0;
    }
    this.realSrc = src;
    this.realStyle = {
      left: 0,
      top: 9999,
      width: design.screen.width,
      height: design.screen.height
    };
  }
  get src() {
    return this.realSrc;
  }
  set src(value) {
    if (this.realSrc === value) {
      return;
    }
    this.realSrc = value;
    if (this.webview) {
      this.webview.src = this.realSrc;
    } else {
      sendError('set src error, please create webview first', false);
    }
  }
  get style() {
    return this.realStyle;
  }
  set style(value) {
    this.realStyle = Object.assign(this.realStyle, value);
    if (this.webview) {
      this.webview.style = this.realStyle;
    } else {
      sendError('set style error, please create webview first', false);
    }
  }
  show() {
    if (this.webview) {
      this.webview.style = {
        top: 0
      };
      this.visible = true;
    } else {
      this.create();
      this.show();
    }
  }
  hide() {
    if (this.webview) {
      this.webview.style = {
        top: 9999
      };
      this.visible = false;
    }
  }
  destroy() {
    var _this$webview;
    (_this$webview = this.webview) === null || _this$webview === void 0 ? void 0 : _this$webview.destroy();
    this.webview = null;
    this.visible = false;
    this.ready = false;
    this.hashChanging = false;
    cacheHashQueue = [];
  }
  create() {
    if (this.webview) {
      return this.webview;
    }
    webviewCreate(this.webviewInitTime);
    try {
      var options = {
        src: this.src,
        style: this.style,
        __skipDomainCheck__: true,
        zIndex: 1000000 - 1
      };
      if (this.isSupportGameWebview) {
        wxConsole.info('创建GameWebview');
        Object.assign(options, {
          isGameWebview: true
        });
      } else {
        wxConsole.info('创建通用Webview');
      }
      this.webview = createWebView(options);
      this.bindMessage();
      WebviewCreateSuccess(this.isSupportGameWebview, this.webviewInitTime);
      webview_onDeviceOrientationChange(() => {
        var systemInfo = getInfoSync();
        this.style = {
          width: systemInfo.screenWidth,
          height: systemInfo.screenHeight
        };
      });
    } catch (err) {
      sendError(`createWebView error:${getErrMsg(err)}`);
    }
    showLoading({
      title: '加载中...'
    });
    setTimeout(() => {
      hideLoading();
      if (!this.ready) {
        showToast({
          icon: 'none',
          title: '加载失败，请稍后重试'
        });
        this.destroy();
        sendError('webview_timeout');
      }
    }, 6000);
    return this.webview;
  }
  postMessage(key, value) {
    if (typeof value === 'undefined') {
      cacheMessage[key] = Date.now();
    } else {
      cacheMessage[key] = value;
    }
    if (postMessageTicker) {
      clearTimeout(postMessageTicker);
    }
    postMessageTicker = setTimeout(() => {
      this.innerPostMessage(cacheMessage);
      cacheMessage = {};
    }, 10);
  }
  innerPostMessage(hashObject, tryCount = 2) {
    if (!this.webview) {
      return;
    }
    wxConsole.info('postMessage to webview', hashObject);
    if (this.hashChanging) {
      cacheHashQueue.push(hashObject);
      return;
    }
    this.hashChanging = true;
    hashObject = Object.assign(hashObject, {
      [`postTime_${uid(10, true)}`]: Date.now()
    });
    var hash = JSON.stringify(hashObject);
    if (this.isSupportGameWebview) {
      if (!this.ready && !hashObject.info) {
        wxConsole.warn('如果不是初始化post，在ready前post，有可能出问题，需要排查', hashObject);
      }
      this.webview.postMessage(hash).then(res => {
        wxConsole.warn('发送消息成功', res);
        this.nextHash();
      }).catch(res => {
        wxConsole.warn('发送失败', res);
        this.clearHash();
        if (tryCount > 0) {
          wxConsole.warn('重试发送', res);
          setTimeout(() => {
            this.innerPostMessage(hashObject, tryCount - 1);
          }, 20);
        }
      });
    } else {
      var index = this.src.indexOf('#');
      if (index === -1) {
        this.src = `${this.src}#${hash}`;
      } else {
        this.src = `${this.src.substring(0, index + 1)}${hash}`;
      }
    }
    this.clearHashTicker = setTimeout(() => {
      if (this.hashChanging) {
        this.hashChanging = true;
      }
    }, 1000);
  }
  clearHash() {
    if (this.clearHashTicker) {
      clearTimeout(this.clearHashTicker);
    }
    this.hashChanging = false;
  }
  nextHash() {
    this.clearHash();
    if (cacheHashQueue.length > 0) {
      var data = cacheHashQueue.shift();
      if (data) {
        this.innerPostMessage(data);
      }
    }
  }
  update() {
    var _this$webview2;
    (_this$webview2 = this.webview) === null || _this$webview2 === void 0 ? void 0 : _this$webview2.update();
  }
  bindMessage() {
    if (this.webview) {
      var systemInfo = getInfoSync();
      this.webview.onmessage = e => {
        var {
          event
        } = e;
        switch (event) {
          case 'close':
            this.hide();
            break;
          case 'ready':
            this.postMessage('initTime', this.webviewInitTime);
            this.postMessage('info', JSON.stringify({
              platform: systemInfo.platform,
              version: systemInfo.version,
              SDKVersion: systemInfo.SDKVersion
            }));
            this.postMessage('appid', WXConfig.accountInfo.appId);
            hideLoading();
            this.ready = true;
            this.show();
            break;
          case 'hashChanged':
            this.nextHash();
            break;
        }
      };
      this.webview.onload = () => {
        wxConsole.info('webview onload');
        webviewLoaded(this.webviewInitTime);
      };
      this.webview.onerror = e => {
        wxConsole.warn('webview onerror');
        hideLoading();
        webviewError(getErrMsg(e.errMsg), this.webviewInitTime);
      };
    }
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/render/renderer.ts






var {
  IS_DEVTOOLS
} = __appServiceSDK__;
var animateTime = 200;
class Renderer {
  constructor(data) {
    this.renderSize = {
      width: design.size.width,
      height: design.size.height
    };
    this.view = void 0;
    this.background = void 0;
    this.titleNode = void 0;
    this.webviewManager = void 0;
    this.url = void 0;
    this.title = void 0;
    this.showTime = void 0;
    this.clicked = false;
    var {
      icon,
      title,
      url,
      time
    } = data;
    this.url = url;
    this.title = title;
    this.showTime = time;
    this.view = pixiJsCore.stage;
    this.background = pixiJsCore.display.createGraphics();
    var iconNode = pixiJsCore.display.createSpriteFrom({
      url: icon,
      x: design.padding,
      y: design.padding,
      width: design.iconSize.width,
      height: design.iconSize.height
    });
    this.view.addChild(this.background, iconNode);
    this.renderBackground();
    this.showTitle(title);
    expose(title);
    rendered();
    this.bindEvent();
    this.webviewManager = new WebviewManager();
    this.webviewManager.init(`${this.url}#wechat_redirect`);
  }
  destroy() {
    var _this$view, _this$webviewManager;
    (_this$view = this.view) === null || _this$view === void 0 ? void 0 : _this$view.destroy({
      children: true,
      texture: true,
      baseTexture: true
    });
    (_this$webviewManager = this.webviewManager) === null || _this$webviewManager === void 0 ? void 0 : _this$webviewManager.destroy();
    delete this.background;
    delete this.view;
    delete this.webviewManager;
  }
  renderBackground() {
    if (this.background) {
      drawRoundRect({
        node: this.background,
        width: this.renderSize.width,
        height: this.renderSize.height,
        radius: {
          tl: 0,
          tr: this.renderSize.height / 2,
          br: this.renderSize.height / 2,
          bl: 0
        },
        fill: {
          color: 0x0,
          alpha: 0.5
        },
        line: {
          width: 1,
          color: 0xffffff,
          alpha: 0.2,
          alignment: 0
        },
        clear: true
      });
      pixiJsCore.updateRender();
    }
  }
  showTitle(title) {
    if (!this.view || !title) {
      return;
    }
    this.titleNode = pixiJsCore.display.createText({
      textString: title,
      textStyle: designStyle.commonStyle,
      x: design.iconSize.width + design.padding * 2,
      y: (design.size.height - designStyle.commonStyle.lineHeight) / 2
    });
    this.titleNode.visible = false;
    this.view.addChild(this.titleNode);
    var textWidth = this.titleNode ? this.titleNode.width + design.padding * 1.5 : 0;
    var renderWidth = design.iconSize.width + textWidth + design.padding * 3;
    pixiJsCore.canvas.resize({
      width: renderWidth,
      height: this.renderSize.height,
      resetTouchArea: true
    });
    this.changeSize(renderWidth, () => {
      if (this.titleNode) {
        this.titleNode.visible = true;
      }
    });
    setTimeout(() => {
      this.hideTitle();
    }, this.showTime + animateTime);
  }
  hideTitle() {
    if (this.titleNode) {
      this.titleNode.destroy({
        texture: true,
        baseTexture: true
      });
      delete this.titleNode;
      this.changeSize(design.size.width, () => {
        pixiJsCore.canvas.resize({
          width: design.size.width,
          height: this.renderSize.height,
          resetTouchArea: true
        });
      });
    }
  }
  changeSize(width, callback) {
    pixiJsCore.tween(this.renderSize).to({
      width
    }, animateTime).onUpdate(() => {
      this.renderBackground();
    }).onComplete(() => {
      callback();
    }).start();
  }
  bindEvent() {
    if (!this.view) {
      return;
    }
    this.view.interactive = true;
    this.view.on('pointertap', () => {
      var _this$webviewManager2;
      if (IS_DEVTOOLS) {
        wxConsole.error('无法在开发者工具中打开，请使用真机调试');
        return;
      }
      if (this.clicked) {
        return;
      }
      this.clicked = true;
      click(this.title);
      (_this$webviewManager2 = this.webviewManager) === null || _this$webviewManager2 === void 0 ? void 0 : _this$webviewManager2.show();
      this.hideTitle();
      pixiJsCore.updateRender();
      setTimeout(() => {
        this.clicked = false;
      }, 500);
    });
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/server/api.ts
var {
  gameTransfer,
  WXConfig: api_WXConfig
} = __appServiceSDK__;
function getPcCouponConf() {
  return new Promise((resolve, reject) => {
    gameTransfer({
      reqData: {
        req_path: 'data.getpccouponconf',
        json_data: {
          appid: api_WXConfig.accountInfo.appId
        }
      },
      timeout: 30000,
      success(res) {
        var {
          data
        } = res;
        resolve(data);
      },
      fail(err) {
        reject(err);
      }
    });
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/render/index.ts








class MiniGamePlatform {
  constructor() {
    this.inited = false;
    this.destroyed = false;
    this.renderer = void 0;
    wxConsole.info('MiniGamePlatform init');
    getPcCouponConf().then(res => {
      var _res$tab_info;
      wxConsole.info('getPcCouponConf success:', res);
      if ((_res$tab_info = res.tab_info) !== null && _res$tab_info !== void 0 && _res$tab_info.tab_url) {
        var _res$tab_info2, _res$tab_info3, _res$tab_info4, _res$tab_info5;
        this.init({
          icon: ((_res$tab_info2 = res.tab_info) === null || _res$tab_info2 === void 0 ? void 0 : _res$tab_info2.tab_icon) || 'https://res.wx.qq.com/wechatgame/product/webpack/userupload/20230316/144933/ic-line-cash.png',
          title: ((_res$tab_info3 = res.tab_info) === null || _res$tab_info3 === void 0 ? void 0 : _res$tab_info3.tab_text) || '',
          url: (_res$tab_info4 = res.tab_info) === null || _res$tab_info4 === void 0 ? void 0 : _res$tab_info4.tab_url,
          time: (((_res$tab_info5 = res.tab_info) === null || _res$tab_info5 === void 0 ? void 0 : _res$tab_info5.disappear_seconds) || 5) * 1000
        });
      } else {
        sendError('缺少参数');
      }
    }).catch(err => {
      wxConsole.warn('getPcCouponConf fail:', err);
      sendError(`getPcCouponConf fail${getErrMsg(err)}`);
    });
  }
  init(data) {
    if (this.inited) {
      return;
    }
    this.inited = true;
    init();
    try {
      createPixiJsCore();
      this.initScreenCanvas();
      designReady().then(() => {
        this.initPixiJsCore();
        this.renderer = new Renderer(data);
      });
      created();
    } catch (e) {
      sendError(`初始化失败:${getErrMsg(e)}`, true);
      this.destroy();
    }
  }
  initScreenCanvas() {
    if (!pixiJsCore.canvas.screenCanvas) {
      pixiJsCore.canvas.init();
      wxConsole.info('screenCanvas create success');
    }
  }
  initPixiJsCore() {
    this.initScreenCanvas();
    pixiJsCore.init({
      defaultTextStyle: designStyle.commonStyle
    });
    if (pixiJsCore.touch) {
      pixiJsCore.touch.padding = 0;
      pixiJsCore.touch.canDrag = true;
      pixiJsCore.touch.snapType = SnapType.Left;
    }
    pixiJsCore.canvas.position.set({
      x: design.position.x,
      y: design.position.y
    });
    pixiJsCore.canvas.resize({
      width: design.size.width,
      height: design.size.height,
      resetTouchArea: true
    });
    pixiJsCore.canvas.zIndex = '101';
  }
  destroy() {
    if (this.destroyed) {
      return;
    }
    this.destroyed = true;
    if (this.renderer) {
      this.renderer.destroy();
      delete this.renderer;
    }
    pixiJsCore.destroy();
    this.inited = false;
    destroy();
  }
}
var instance;
var createMiniGamePlatform = function () {
  if (instance) {
    return instance;
  }
  instance = new MiniGamePlatform();
  return instance;
};
;// CONCATENATED MODULE: ./src/game/game-component/minigame_platform/src/index.ts

wxConsole.warn('minigamePlatform inject success');
Object.defineProperty(globalThis, '__minigamePlatformSDK__', {
  get() {
    return MiniGamePlatform;
  }
});
})();

MiniGamePlatform = __webpack_exports__["default"];
/******/ })()
;
null

})(); /* LIBRARY_CLOSURE_END () */


} catch(err) {
      console.error('catch sdkSubPackage: minigamePlatform error: ', err)
    }
