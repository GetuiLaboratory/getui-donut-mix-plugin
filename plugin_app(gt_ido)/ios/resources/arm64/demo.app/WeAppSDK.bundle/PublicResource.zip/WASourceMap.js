/* eslint-disable */
/**
 * @preserve
 * git: http://git.code.oa.com/wxweb/weapp-source-map.git 
 * version: 2022/6/14 下午3:21:59
 */
var __wxSourceMap = {
  get: function(name) {
    return __wxSourceMap[name];
  }
};

var __wxSourceMapRetrace__ = function(modules) {
  var installedModules = {};
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) return installedModules[moduleId].exports;
    var module = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    module.l = true;
    return module.exports;
  }
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) Object.defineProperty(exports, name, {
      enumerable: true,
      get: getter
    });
  };
  __webpack_require__.r = function(exports) {
    if ('undefined' !== typeof Symbol && Symbol.toStringTag) Object.defineProperty(exports, Symbol.toStringTag, {
      value: 'Module'
    });
    Object.defineProperty(exports, '__esModule', {
      value: true
    });
  };
  __webpack_require__.t = function(value, mode) {
    if (1 & mode) value = __webpack_require__(value);
    if (8 & mode) return value;
    if (4 & mode && 'object' === typeof value && value && value.__esModule) return value;
    var ns = Object.create(null);
    __webpack_require__.r(ns);
    Object.defineProperty(ns, 'default', {
      enumerable: true,
      value: value
    });
    if (2 & mode && 'string' != typeof value) for (var key in value) __webpack_require__.d(ns, key, function(key) {
      return value[key];
    }.bind(null, key));
    return ns;
  };
  __webpack_require__.n = function(module) {
    var getter = module && module.__esModule ? function getDefault() {
      return module['default'];
    } : function getModuleExports() {
      return module;
    };
    __webpack_require__.d(getter, 'a', getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = '';
  return __webpack_require__(__webpack_require__.s = 7);
}([ function(module, exports) {
  function getArg(aArgs, aName, aDefaultValue) {
    if (aName in aArgs) return aArgs[aName]; else if (3 === arguments.length) return aDefaultValue; else throw new Error('"' + aName + '" is a required argument.');
  }
  exports.getArg = getArg;
  var urlRegexp = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/;
  var dataUrlRegexp = /^data:.+\,.+$/;
  function urlParse(aUrl) {
    var match = aUrl.match(urlRegexp);
    if (!match) return null;
    return {
      scheme: match[1],
      auth: match[2],
      host: match[3],
      port: match[4],
      path: match[5]
    };
  }
  exports.urlParse = urlParse;
  function urlGenerate(aParsedUrl) {
    var url = '';
    if (aParsedUrl.scheme) url += aParsedUrl.scheme + ':';
    url += '//';
    if (aParsedUrl.auth) url += aParsedUrl.auth + '@';
    if (aParsedUrl.host) url += aParsedUrl.host;
    if (aParsedUrl.port) url += ':' + aParsedUrl.port;
    if (aParsedUrl.path) url += aParsedUrl.path;
    return url;
  }
  exports.urlGenerate = urlGenerate;
  function normalize(aPath) {
    var path = aPath;
    var url = urlParse(aPath);
    if (url) {
      if (!url.path) return aPath;
      path = url.path;
    }
    var isAbsolute = exports.isAbsolute(path);
    var parts = path.split(/\/+/);
    for (var part, up = 0, i = parts.length - 1; i >= 0; i--) {
      part = parts[i];
      if ('.' === part) parts.splice(i, 1); else if ('..' === part) up++; else if (up > 0) if ('' === part) {
        parts.splice(i + 1, up);
        up = 0;
      } else {
        parts.splice(i, 2);
        up--;
      }
    }
    path = parts.join('/');
    if ('' === path) path = isAbsolute ? '/' : '.';
    if (url) {
      url.path = path;
      return urlGenerate(url);
    }
    return path;
  }
  exports.normalize = normalize;
  function join(aRoot, aPath) {
    if ('' === aRoot) aRoot = '.';
    if ('' === aPath) aPath = '.';
    var aPathUrl = urlParse(aPath);
    var aRootUrl = urlParse(aRoot);
    if (aRootUrl) aRoot = aRootUrl.path || '/';
    if (aPathUrl && !aPathUrl.scheme) {
      if (aRootUrl) aPathUrl.scheme = aRootUrl.scheme;
      return urlGenerate(aPathUrl);
    }
    if (aPathUrl || aPath.match(dataUrlRegexp)) return aPath;
    if (aRootUrl && !aRootUrl.host && !aRootUrl.path) {
      aRootUrl.host = aPath;
      return urlGenerate(aRootUrl);
    }
    var joined = '/' === aPath.charAt(0) ? aPath : normalize(aRoot.replace(/\/+$/, '') + '/' + aPath);
    if (aRootUrl) {
      aRootUrl.path = joined;
      return urlGenerate(aRootUrl);
    }
    return joined;
  }
  exports.join = join;
  exports.isAbsolute = function(aPath) {
    return '/' === aPath.charAt(0) || urlRegexp.test(aPath);
  };
  function relative(aRoot, aPath) {
    if ('' === aRoot) aRoot = '.';
    aRoot = aRoot.replace(/\/$/, '');
    var level = 0;
    while (0 !== aPath.indexOf(aRoot + '/')) {
      var index = aRoot.lastIndexOf('/');
      if (index < 0) return aPath;
      aRoot = aRoot.slice(0, index);
      if (aRoot.match(/^([^\/]+:\/)?\/*$/)) return aPath;
      ++level;
    }
    return Array(level + 1).join('../') + aPath.substr(aRoot.length + 1);
  }
  exports.relative = relative;
  var supportsNullProto = function() {
    var obj = Object.create(null);
    return !('__proto__' in obj);
  }();
  function identity(s) {
    return s;
  }
  function toSetString(aStr) {
    if (isProtoString(aStr)) return '$' + aStr;
    return aStr;
  }
  exports.toSetString = supportsNullProto ? identity : toSetString;
  function fromSetString(aStr) {
    if (isProtoString(aStr)) return aStr.slice(1);
    return aStr;
  }
  exports.fromSetString = supportsNullProto ? identity : fromSetString;
  function isProtoString(s) {
    if (!s) return false;
    var length = s.length;
    if (length < 9) return false;
    if (95 !== s.charCodeAt(length - 1) || 95 !== s.charCodeAt(length - 2) || 111 !== s.charCodeAt(length - 3) || 116 !== s.charCodeAt(length - 4) || 111 !== s.charCodeAt(length - 5) || 114 !== s.charCodeAt(length - 6) || 112 !== s.charCodeAt(length - 7) || 95 !== s.charCodeAt(length - 8) || 95 !== s.charCodeAt(length - 9)) return false;
    for (var i = length - 10; i >= 0; i--) if (36 !== s.charCodeAt(i)) return false;
    return true;
  }
  function compareByOriginalPositions(mappingA, mappingB, onlyCompareOriginal) {
    var cmp = strcmp(mappingA.source, mappingB.source);
    if (0 !== cmp) return cmp;
    cmp = mappingA.originalLine - mappingB.originalLine;
    if (0 !== cmp) return cmp;
    cmp = mappingA.originalColumn - mappingB.originalColumn;
    if (0 !== cmp || onlyCompareOriginal) return cmp;
    cmp = mappingA.generatedColumn - mappingB.generatedColumn;
    if (0 !== cmp) return cmp;
    cmp = mappingA.generatedLine - mappingB.generatedLine;
    if (0 !== cmp) return cmp;
    return strcmp(mappingA.name, mappingB.name);
  }
  exports.compareByOriginalPositions = compareByOriginalPositions;
  function compareByGeneratedPositionsDeflated(mappingA, mappingB, onlyCompareGenerated) {
    var cmp = mappingA.generatedLine - mappingB.generatedLine;
    if (0 !== cmp) return cmp;
    cmp = mappingA.generatedColumn - mappingB.generatedColumn;
    if (0 !== cmp || onlyCompareGenerated) return cmp;
    cmp = strcmp(mappingA.source, mappingB.source);
    if (0 !== cmp) return cmp;
    cmp = mappingA.originalLine - mappingB.originalLine;
    if (0 !== cmp) return cmp;
    cmp = mappingA.originalColumn - mappingB.originalColumn;
    if (0 !== cmp) return cmp;
    return strcmp(mappingA.name, mappingB.name);
  }
  exports.compareByGeneratedPositionsDeflated = compareByGeneratedPositionsDeflated;
  function strcmp(aStr1, aStr2) {
    if (aStr1 === aStr2) return 0;
    if (null === aStr1) return 1;
    if (null === aStr2) return -1;
    if (aStr1 > aStr2) return 1;
    return -1;
  }
  function compareByGeneratedPositionsInflated(mappingA, mappingB) {
    var cmp = mappingA.generatedLine - mappingB.generatedLine;
    if (0 !== cmp) return cmp;
    cmp = mappingA.generatedColumn - mappingB.generatedColumn;
    if (0 !== cmp) return cmp;
    cmp = strcmp(mappingA.source, mappingB.source);
    if (0 !== cmp) return cmp;
    cmp = mappingA.originalLine - mappingB.originalLine;
    if (0 !== cmp) return cmp;
    cmp = mappingA.originalColumn - mappingB.originalColumn;
    if (0 !== cmp) return cmp;
    return strcmp(mappingA.name, mappingB.name);
  }
  exports.compareByGeneratedPositionsInflated = compareByGeneratedPositionsInflated;
  function parseSourceMapInput(str) {
    return JSON.parse(str.replace(/^\)]}'[^\n]*\n/, ''));
  }
  exports.parseSourceMapInput = parseSourceMapInput;
  function computeSourceURL(sourceRoot, sourceURL, sourceMapURL) {
    sourceURL = sourceURL || '';
    if (sourceRoot) {
      if ('/' !== sourceRoot[sourceRoot.length - 1] && '/' !== sourceURL[0]) sourceRoot += '/';
      sourceURL = sourceRoot + sourceURL;
    }
    if (sourceMapURL) {
      var parsed = urlParse(sourceMapURL);
      if (!parsed) throw new Error('sourceMapURL could not be parsed');
      if (parsed.path) {
        var index = parsed.path.lastIndexOf('/');
        if (index >= 0) parsed.path = parsed.path.substring(0, index + 1);
      }
      sourceURL = join(urlGenerate(parsed), sourceURL);
    }
    return normalize(sourceURL);
  }
  exports.computeSourceURL = computeSourceURL;
}, function(module, exports, __webpack_require__) {
  var util = __webpack_require__(0);
  var binarySearch = __webpack_require__(2);
  var ArraySet = __webpack_require__(3).ArraySet;
  var base64VLQ = __webpack_require__(4);
  var quickSort = __webpack_require__(6).quickSort;
  function SourceMapConsumer(aSourceMap, aSourceMapURL) {
    var sourceMap = aSourceMap;
    if ('string' === typeof aSourceMap) sourceMap = util.parseSourceMapInput(aSourceMap);
    return null != sourceMap.sections ? new IndexedSourceMapConsumer(sourceMap, aSourceMapURL) : new BasicSourceMapConsumer(sourceMap, aSourceMapURL);
  }
  SourceMapConsumer.fromSourceMap = function(aSourceMap, aSourceMapURL) {
    return BasicSourceMapConsumer.fromSourceMap(aSourceMap, aSourceMapURL);
  };
  SourceMapConsumer.prototype._version = 3;
  SourceMapConsumer.prototype.__generatedMappings = null;
  Object.defineProperty(SourceMapConsumer.prototype, '_generatedMappings', {
    configurable: true,
    enumerable: true,
    get: function() {
      if (!this.__generatedMappings) this._parseMappings(this._mappings, this.sourceRoot);
      return this.__generatedMappings;
    }
  });
  SourceMapConsumer.prototype.__originalMappings = null;
  Object.defineProperty(SourceMapConsumer.prototype, '_originalMappings', {
    configurable: true,
    enumerable: true,
    get: function() {
      if (!this.__originalMappings) this._parseMappings(this._mappings, this.sourceRoot);
      return this.__originalMappings;
    }
  });
  SourceMapConsumer.prototype._charIsMappingSeparator = function SourceMapConsumer_charIsMappingSeparator(aStr, index) {
    var c = aStr.charAt(index);
    return ';' === c || ',' === c;
  };
  SourceMapConsumer.prototype._parseMappings = function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
    throw new Error('Subclasses must implement _parseMappings');
  };
  SourceMapConsumer.GENERATED_ORDER = 1;
  SourceMapConsumer.ORIGINAL_ORDER = 2;
  SourceMapConsumer.GREATEST_LOWER_BOUND = 1;
  SourceMapConsumer.LEAST_UPPER_BOUND = 2;
  SourceMapConsumer.prototype.eachMapping = function SourceMapConsumer_eachMapping(aCallback, aContext, aOrder) {
    var context = aContext || null;
    var order = aOrder || SourceMapConsumer.GENERATED_ORDER;
    var mappings;
    switch (order) {
     case SourceMapConsumer.GENERATED_ORDER:
      mappings = this._generatedMappings;
      break;

     case SourceMapConsumer.ORIGINAL_ORDER:
      mappings = this._originalMappings;
      break;

     default:
      throw new Error('Unknown order of iteration.');
    }
    var sourceRoot = this.sourceRoot;
    mappings.map(function(mapping) {
      var source = null === mapping.source ? null : this._sources.at(mapping.source);
      source = util.computeSourceURL(sourceRoot, source, this._sourceMapURL);
      return {
        source: source,
        generatedLine: mapping.generatedLine,
        generatedColumn: mapping.generatedColumn,
        originalLine: mapping.originalLine,
        originalColumn: mapping.originalColumn,
        name: null === mapping.name ? null : this._names.at(mapping.name)
      };
    }, this).forEach(aCallback, context);
  };
  SourceMapConsumer.prototype.allGeneratedPositionsFor = function SourceMapConsumer_allGeneratedPositionsFor(aArgs) {
    var line = util.getArg(aArgs, 'line');
    var needle = {
      source: util.getArg(aArgs, 'source'),
      originalLine: line,
      originalColumn: util.getArg(aArgs, 'column', 0)
    };
    needle.source = this._findSourceIndex(needle.source);
    if (needle.source < 0) return [];
    var mappings = [];
    var index = this._findMapping(needle, this._originalMappings, 'originalLine', 'originalColumn', util.compareByOriginalPositions, binarySearch.LEAST_UPPER_BOUND);
    if (index >= 0) {
      var mapping = this._originalMappings[index];
      if (void 0 === aArgs.column) {
        var originalLine = mapping.originalLine;
        while (mapping && mapping.originalLine === originalLine) {
          mappings.push({
            line: util.getArg(mapping, 'generatedLine', null),
            column: util.getArg(mapping, 'generatedColumn', null),
            lastColumn: util.getArg(mapping, 'lastGeneratedColumn', null)
          });
          mapping = this._originalMappings[++index];
        }
      } else {
        var originalColumn = mapping.originalColumn;
        while (mapping && mapping.originalLine === line && mapping.originalColumn == originalColumn) {
          mappings.push({
            line: util.getArg(mapping, 'generatedLine', null),
            column: util.getArg(mapping, 'generatedColumn', null),
            lastColumn: util.getArg(mapping, 'lastGeneratedColumn', null)
          });
          mapping = this._originalMappings[++index];
        }
      }
    }
    return mappings;
  };
  exports.SourceMapConsumer = SourceMapConsumer;
  function BasicSourceMapConsumer(aSourceMap, aSourceMapURL) {
    var sourceMap = aSourceMap;
    if ('string' === typeof aSourceMap) sourceMap = util.parseSourceMapInput(aSourceMap);
    var version = util.getArg(sourceMap, 'version');
    var sources = util.getArg(sourceMap, 'sources');
    var names = util.getArg(sourceMap, 'names', []);
    var sourceRoot = util.getArg(sourceMap, 'sourceRoot', null);
    var sourcesContent = util.getArg(sourceMap, 'sourcesContent', null);
    var mappings = util.getArg(sourceMap, 'mappings');
    var file = util.getArg(sourceMap, 'file', null);
    if (version != this._version) throw new Error('Unsupported version: ' + version);
    if (sourceRoot) sourceRoot = util.normalize(sourceRoot);
    sources = sources.map(String).map(util.normalize).map(function(source) {
      return sourceRoot && util.isAbsolute(sourceRoot) && util.isAbsolute(source) ? util.relative(sourceRoot, source) : source;
    });
    this._names = ArraySet.fromArray(names.map(String), true);
    this._sources = ArraySet.fromArray(sources, true);
    this._absoluteSources = this._sources.toArray().map(function(s) {
      return util.computeSourceURL(sourceRoot, s, aSourceMapURL);
    });
    this.sourceRoot = sourceRoot;
    this.sourcesContent = sourcesContent;
    this._mappings = mappings;
    this._sourceMapURL = aSourceMapURL;
    this.file = file;
  }
  BasicSourceMapConsumer.prototype = Object.create(SourceMapConsumer.prototype);
  BasicSourceMapConsumer.prototype.consumer = SourceMapConsumer;
  BasicSourceMapConsumer.prototype._findSourceIndex = function(aSource) {
    var relativeSource = aSource;
    if (null != this.sourceRoot) relativeSource = util.relative(this.sourceRoot, relativeSource);
    if (this._sources.has(relativeSource)) return this._sources.indexOf(relativeSource);
    var i;
    for (i = 0; i < this._absoluteSources.length; ++i) if (this._absoluteSources[i] == aSource) return i;
    return -1;
  };
  BasicSourceMapConsumer.fromSourceMap = function SourceMapConsumer_fromSourceMap(aSourceMap, aSourceMapURL) {
    var smc = Object.create(BasicSourceMapConsumer.prototype);
    var names = smc._names = ArraySet.fromArray(aSourceMap._names.toArray(), true);
    var sources = smc._sources = ArraySet.fromArray(aSourceMap._sources.toArray(), true);
    smc.sourceRoot = aSourceMap._sourceRoot;
    smc.sourcesContent = aSourceMap._generateSourcesContent(smc._sources.toArray(), smc.sourceRoot);
    smc.file = aSourceMap._file;
    smc._sourceMapURL = aSourceMapURL;
    smc._absoluteSources = smc._sources.toArray().map(function(s) {
      return util.computeSourceURL(smc.sourceRoot, s, aSourceMapURL);
    });
    var generatedMappings = aSourceMap._mappings.toArray().slice();
    var destGeneratedMappings = smc.__generatedMappings = [];
    var destOriginalMappings = smc.__originalMappings = [];
    for (var i = 0, length = generatedMappings.length; i < length; i++) {
      var srcMapping = generatedMappings[i];
      var destMapping = new Mapping();
      destMapping.generatedLine = srcMapping.generatedLine;
      destMapping.generatedColumn = srcMapping.generatedColumn;
      if (srcMapping.source) {
        destMapping.source = sources.indexOf(srcMapping.source);
        destMapping.originalLine = srcMapping.originalLine;
        destMapping.originalColumn = srcMapping.originalColumn;
        if (srcMapping.name) destMapping.name = names.indexOf(srcMapping.name);
        destOriginalMappings.push(destMapping);
      }
      destGeneratedMappings.push(destMapping);
    }
    quickSort(smc.__originalMappings, util.compareByOriginalPositions);
    return smc;
  };
  BasicSourceMapConsumer.prototype._version = 3;
  Object.defineProperty(BasicSourceMapConsumer.prototype, 'sources', {
    get: function() {
      return this._absoluteSources.slice();
    }
  });
  function Mapping() {
    this.generatedLine = 0;
    this.generatedColumn = 0;
    this.source = null;
    this.originalLine = null;
    this.originalColumn = null;
    this.name = null;
  }
  BasicSourceMapConsumer.prototype._parseMappings = function SourceMapConsumer_parseMappings(aStr, aSourceRoot) {
    var generatedLine = 1;
    var previousGeneratedColumn = 0;
    var previousOriginalLine = 0;
    var previousOriginalColumn = 0;
    var previousSource = 0;
    var previousName = 0;
    var length = aStr.length;
    var index = 0;
    var cachedSegments = {};
    var temp = {};
    var originalMappings = [];
    var generatedMappings = [];
    var mapping, str, segment, end, value;
    while (index < length) if (';' === aStr.charAt(index)) {
      generatedLine++;
      index++;
      previousGeneratedColumn = 0;
    } else if (',' === aStr.charAt(index)) index++; else {
      mapping = new Mapping();
      mapping.generatedLine = generatedLine;
      for (end = index; end < length; end++) if (this._charIsMappingSeparator(aStr, end)) break;
      str = aStr.slice(index, end);
      segment = cachedSegments[str];
      if (segment) index += str.length; else {
        segment = [];
        while (index < end) {
          base64VLQ.decode(aStr, index, temp);
          value = temp.value;
          index = temp.rest;
          segment.push(value);
        }
        if (2 === segment.length) throw new Error('Found a source, but no line and column');
        if (3 === segment.length) throw new Error('Found a source and line, but no column');
        cachedSegments[str] = segment;
      }
      mapping.generatedColumn = previousGeneratedColumn + segment[0];
      previousGeneratedColumn = mapping.generatedColumn;
      if (segment.length > 1) {
        mapping.source = previousSource + segment[1];
        previousSource += segment[1];
        mapping.originalLine = previousOriginalLine + segment[2];
        previousOriginalLine = mapping.originalLine;
        mapping.originalLine += 1;
        mapping.originalColumn = previousOriginalColumn + segment[3];
        previousOriginalColumn = mapping.originalColumn;
        if (segment.length > 4) {
          mapping.name = previousName + segment[4];
          previousName += segment[4];
        }
      }
      generatedMappings.push(mapping);
      if ('number' === typeof mapping.originalLine) originalMappings.push(mapping);
    }
    quickSort(generatedMappings, util.compareByGeneratedPositionsDeflated);
    this.__generatedMappings = generatedMappings;
    quickSort(originalMappings, util.compareByOriginalPositions);
    this.__originalMappings = originalMappings;
  };
  BasicSourceMapConsumer.prototype._findMapping = function SourceMapConsumer_findMapping(aNeedle, aMappings, aLineName, aColumnName, aComparator, aBias) {
    if (aNeedle[aLineName] <= 0) throw new TypeError('Line must be greater than or equal to 1, got ' + aNeedle[aLineName]);
    if (aNeedle[aColumnName] < 0) throw new TypeError('Column must be greater than or equal to 0, got ' + aNeedle[aColumnName]);
    return binarySearch.search(aNeedle, aMappings, aComparator, aBias);
  };
  BasicSourceMapConsumer.prototype.computeColumnSpans = function SourceMapConsumer_computeColumnSpans() {
    for (var index = 0; index < this._generatedMappings.length; ++index) {
      var mapping = this._generatedMappings[index];
      if (index + 1 < this._generatedMappings.length) {
        var nextMapping = this._generatedMappings[index + 1];
        if (mapping.generatedLine === nextMapping.generatedLine) {
          mapping.lastGeneratedColumn = nextMapping.generatedColumn - 1;
          continue;
        }
      }
      mapping.lastGeneratedColumn = 1 / 0;
    }
  };
  BasicSourceMapConsumer.prototype.originalPositionFor = function SourceMapConsumer_originalPositionFor(aArgs) {
    var needle = {
      generatedLine: util.getArg(aArgs, 'line'),
      generatedColumn: util.getArg(aArgs, 'column')
    };
    var index = this._findMapping(needle, this._generatedMappings, 'generatedLine', 'generatedColumn', util.compareByGeneratedPositionsDeflated, util.getArg(aArgs, 'bias', SourceMapConsumer.GREATEST_LOWER_BOUND));
    if (index >= 0) {
      var mapping = this._generatedMappings[index];
      if (mapping.generatedLine === needle.generatedLine) {
        var source = util.getArg(mapping, 'source', null);
        if (null !== source) {
          source = this._sources.at(source);
          source = util.computeSourceURL(this.sourceRoot, source, this._sourceMapURL);
        }
        var name = util.getArg(mapping, 'name', null);
        if (null !== name) name = this._names.at(name);
        return {
          source: source,
          line: util.getArg(mapping, 'originalLine', null),
          column: util.getArg(mapping, 'originalColumn', null),
          name: name
        };
      }
    }
    return {
      source: null,
      line: null,
      column: null,
      name: null
    };
  };
  BasicSourceMapConsumer.prototype.hasContentsOfAllSources = function BasicSourceMapConsumer_hasContentsOfAllSources() {
    if (!this.sourcesContent) return false;
    return this.sourcesContent.length >= this._sources.size() && !this.sourcesContent.some(function(sc) {
      return null == sc;
    });
  };
  BasicSourceMapConsumer.prototype.sourceContentFor = function SourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
    if (!this.sourcesContent) return null;
    var index = this._findSourceIndex(aSource);
    if (index >= 0) return this.sourcesContent[index];
    var relativeSource = aSource;
    if (null != this.sourceRoot) relativeSource = util.relative(this.sourceRoot, relativeSource);
    var url;
    if (null != this.sourceRoot && (url = util.urlParse(this.sourceRoot))) {
      var fileUriAbsPath = relativeSource.replace(/^file:\/\//, '');
      if ('file' == url.scheme && this._sources.has(fileUriAbsPath)) return this.sourcesContent[this._sources.indexOf(fileUriAbsPath)];
      if ((!url.path || '/' == url.path) && this._sources.has('/' + relativeSource)) return this.sourcesContent[this._sources.indexOf('/' + relativeSource)];
    }
    if (nullOnMissing) return null; else throw new Error('"' + relativeSource + '" is not in the SourceMap.');
  };
  BasicSourceMapConsumer.prototype.generatedPositionFor = function SourceMapConsumer_generatedPositionFor(aArgs) {
    var source = util.getArg(aArgs, 'source');
    source = this._findSourceIndex(source);
    if (source < 0) return {
      line: null,
      column: null,
      lastColumn: null
    };
    var needle = {
      source: source,
      originalLine: util.getArg(aArgs, 'line'),
      originalColumn: util.getArg(aArgs, 'column')
    };
    var index = this._findMapping(needle, this._originalMappings, 'originalLine', 'originalColumn', util.compareByOriginalPositions, util.getArg(aArgs, 'bias', SourceMapConsumer.GREATEST_LOWER_BOUND));
    if (index >= 0) {
      var mapping = this._originalMappings[index];
      if (mapping.source === needle.source) return {
        line: util.getArg(mapping, 'generatedLine', null),
        column: util.getArg(mapping, 'generatedColumn', null),
        lastColumn: util.getArg(mapping, 'lastGeneratedColumn', null)
      };
    }
    return {
      line: null,
      column: null,
      lastColumn: null
    };
  };
  exports.BasicSourceMapConsumer = BasicSourceMapConsumer;
  function IndexedSourceMapConsumer(aSourceMap, aSourceMapURL) {
    var sourceMap = aSourceMap;
    if ('string' === typeof aSourceMap) sourceMap = util.parseSourceMapInput(aSourceMap);
    var version = util.getArg(sourceMap, 'version');
    var sections = util.getArg(sourceMap, 'sections');
    if (version != this._version) throw new Error('Unsupported version: ' + version);
    this._sources = new ArraySet();
    this._names = new ArraySet();
    var lastOffset = {
      line: -1,
      column: 0
    };
    this._sections = sections.map(function(s) {
      if (s.url) throw new Error('Support for url field in sections not implemented.');
      var offset = util.getArg(s, 'offset');
      var offsetLine = util.getArg(offset, 'line');
      var offsetColumn = util.getArg(offset, 'column');
      if (offsetLine < lastOffset.line || offsetLine === lastOffset.line && offsetColumn < lastOffset.column) throw new Error('Section offsets must be ordered and non-overlapping.');
      lastOffset = offset;
      return {
        generatedOffset: {
          generatedLine: offsetLine + 1,
          generatedColumn: offsetColumn + 1
        },
        consumer: new SourceMapConsumer(util.getArg(s, 'map'), aSourceMapURL)
      };
    });
  }
  IndexedSourceMapConsumer.prototype = Object.create(SourceMapConsumer.prototype);
  IndexedSourceMapConsumer.prototype.constructor = SourceMapConsumer;
  IndexedSourceMapConsumer.prototype._version = 3;
  Object.defineProperty(IndexedSourceMapConsumer.prototype, 'sources', {
    get: function() {
      var sources = [];
      for (var i = 0; i < this._sections.length; i++) for (var j = 0; j < this._sections[i].consumer.sources.length; j++) sources.push(this._sections[i].consumer.sources[j]);
      return sources;
    }
  });
  IndexedSourceMapConsumer.prototype.originalPositionFor = function IndexedSourceMapConsumer_originalPositionFor(aArgs) {
    var needle = {
      generatedLine: util.getArg(aArgs, 'line'),
      generatedColumn: util.getArg(aArgs, 'column')
    };
    var sectionIndex = binarySearch.search(needle, this._sections, function(needle, section) {
      var cmp = needle.generatedLine - section.generatedOffset.generatedLine;
      if (cmp) return cmp;
      return needle.generatedColumn - section.generatedOffset.generatedColumn;
    });
    var section = this._sections[sectionIndex];
    if (!section) return {
      source: null,
      line: null,
      column: null,
      name: null
    };
    return section.consumer.originalPositionFor({
      line: needle.generatedLine - (section.generatedOffset.generatedLine - 1),
      column: needle.generatedColumn - (section.generatedOffset.generatedLine === needle.generatedLine ? section.generatedOffset.generatedColumn - 1 : 0),
      bias: aArgs.bias
    });
  };
  IndexedSourceMapConsumer.prototype.hasContentsOfAllSources = function IndexedSourceMapConsumer_hasContentsOfAllSources() {
    return this._sections.every(function(s) {
      return s.consumer.hasContentsOfAllSources();
    });
  };
  IndexedSourceMapConsumer.prototype.sourceContentFor = function IndexedSourceMapConsumer_sourceContentFor(aSource, nullOnMissing) {
    for (var i = 0; i < this._sections.length; i++) {
      var section = this._sections[i];
      var content = section.consumer.sourceContentFor(aSource, true);
      if (content) return content;
    }
    if (nullOnMissing) return null; else throw new Error('"' + aSource + '" is not in the SourceMap.');
  };
  IndexedSourceMapConsumer.prototype.generatedPositionFor = function IndexedSourceMapConsumer_generatedPositionFor(aArgs) {
    for (var i = 0; i < this._sections.length; i++) {
      var section = this._sections[i];
      if (-1 === section.consumer._findSourceIndex(util.getArg(aArgs, 'source'))) continue;
      var generatedPosition = section.consumer.generatedPositionFor(aArgs);
      if (generatedPosition) {
        var ret = {
          line: generatedPosition.line + (section.generatedOffset.generatedLine - 1),
          column: generatedPosition.column + (section.generatedOffset.generatedLine === generatedPosition.line ? section.generatedOffset.generatedColumn - 1 : 0)
        };
        return ret;
      }
    }
    return {
      line: null,
      column: null
    };
  };
  IndexedSourceMapConsumer.prototype._parseMappings = function IndexedSourceMapConsumer_parseMappings(aStr, aSourceRoot) {
    this.__generatedMappings = [];
    this.__originalMappings = [];
    for (var i = 0; i < this._sections.length; i++) {
      var section = this._sections[i];
      var sectionMappings = section.consumer._generatedMappings;
      for (var j = 0; j < sectionMappings.length; j++) {
        var mapping = sectionMappings[j];
        var source = section.consumer._sources.at(mapping.source);
        source = util.computeSourceURL(section.consumer.sourceRoot, source, this._sourceMapURL);
        this._sources.add(source);
        source = this._sources.indexOf(source);
        var name = null;
        if (mapping.name) {
          name = section.consumer._names.at(mapping.name);
          this._names.add(name);
          name = this._names.indexOf(name);
        }
        var adjustedMapping = {
          source: source,
          generatedLine: mapping.generatedLine + (section.generatedOffset.generatedLine - 1),
          generatedColumn: mapping.generatedColumn + (section.generatedOffset.generatedLine === mapping.generatedLine ? section.generatedOffset.generatedColumn - 1 : 0),
          originalLine: mapping.originalLine,
          originalColumn: mapping.originalColumn,
          name: name
        };
        this.__generatedMappings.push(adjustedMapping);
        if ('number' === typeof adjustedMapping.originalLine) this.__originalMappings.push(adjustedMapping);
      }
    }
    quickSort(this.__generatedMappings, util.compareByGeneratedPositionsDeflated);
    quickSort(this.__originalMappings, util.compareByOriginalPositions);
  };
  exports.IndexedSourceMapConsumer = IndexedSourceMapConsumer;
}, function(module, exports) {
  exports.GREATEST_LOWER_BOUND = 1;
  exports.LEAST_UPPER_BOUND = 2;
  function recursiveSearch(aLow, aHigh, aNeedle, aHaystack, aCompare, aBias) {
    var mid = Math.floor((aHigh - aLow) / 2) + aLow;
    var cmp = aCompare(aNeedle, aHaystack[mid], true);
    if (0 === cmp) return mid; else if (cmp > 0) {
      if (aHigh - mid > 1) return recursiveSearch(mid, aHigh, aNeedle, aHaystack, aCompare, aBias);
      if (aBias == exports.LEAST_UPPER_BOUND) return aHigh < aHaystack.length ? aHigh : -1; else return mid;
    } else {
      if (mid - aLow > 1) return recursiveSearch(aLow, mid, aNeedle, aHaystack, aCompare, aBias);
      if (aBias == exports.LEAST_UPPER_BOUND) return mid; else return aLow < 0 ? -1 : aLow;
    }
  }
  exports.search = function search(aNeedle, aHaystack, aCompare, aBias) {
    if (0 === aHaystack.length) return -1;
    var index = recursiveSearch(-1, aHaystack.length, aNeedle, aHaystack, aCompare, aBias || exports.GREATEST_LOWER_BOUND);
    if (index < 0) return -1;
    while (index - 1 >= 0) {
      if (0 !== aCompare(aHaystack[index], aHaystack[index - 1], true)) break;
      --index;
    }
    return index;
  };
}, function(module, exports, __webpack_require__) {
  var util = __webpack_require__(0);
  var has = Object.prototype.hasOwnProperty;
  var hasNativeMap = 'undefined' !== typeof Map;
  function ArraySet() {
    this._array = [];
    this._set = hasNativeMap ? new Map() : Object.create(null);
  }
  ArraySet.fromArray = function ArraySet_fromArray(aArray, aAllowDuplicates) {
    var set = new ArraySet();
    for (var i = 0, len = aArray.length; i < len; i++) set.add(aArray[i], aAllowDuplicates);
    return set;
  };
  ArraySet.prototype.size = function ArraySet_size() {
    return hasNativeMap ? this._set.size : Object.getOwnPropertyNames(this._set).length;
  };
  ArraySet.prototype.add = function ArraySet_add(aStr, aAllowDuplicates) {
    var sStr = hasNativeMap ? aStr : util.toSetString(aStr);
    var isDuplicate = hasNativeMap ? this.has(aStr) : has.call(this._set, sStr);
    var idx = this._array.length;
    if (!isDuplicate || aAllowDuplicates) this._array.push(aStr);
    if (!isDuplicate) if (hasNativeMap) this._set.set(aStr, idx); else this._set[sStr] = idx;
  };
  ArraySet.prototype.has = function ArraySet_has(aStr) {
    if (hasNativeMap) return this._set.has(aStr); else {
      var sStr = util.toSetString(aStr);
      return has.call(this._set, sStr);
    }
  };
  ArraySet.prototype.indexOf = function ArraySet_indexOf(aStr) {
    if (hasNativeMap) {
      var idx = this._set.get(aStr);
      if (idx >= 0) return idx;
    } else {
      var sStr = util.toSetString(aStr);
      if (has.call(this._set, sStr)) return this._set[sStr];
    }
    throw new Error('"' + aStr + '" is not in the set.');
  };
  ArraySet.prototype.at = function ArraySet_at(aIdx) {
    if (aIdx >= 0 && aIdx < this._array.length) return this._array[aIdx];
    throw new Error('No element indexed by ' + aIdx);
  };
  ArraySet.prototype.toArray = function ArraySet_toArray() {
    return this._array.slice();
  };
  exports.ArraySet = ArraySet;
}, function(module, exports, __webpack_require__) {
  var base64 = __webpack_require__(5);
  var VLQ_BASE_SHIFT = 5;
  var VLQ_BASE = 1 << VLQ_BASE_SHIFT;
  var VLQ_BASE_MASK = VLQ_BASE - 1;
  var VLQ_CONTINUATION_BIT = VLQ_BASE;
  function toVLQSigned(aValue) {
    return aValue < 0 ? (-aValue << 1) + 1 : (aValue << 1) + 0;
  }
  function fromVLQSigned(aValue) {
    var isNegative = 1 === (1 & aValue);
    var shifted = aValue >> 1;
    return isNegative ? -shifted : shifted;
  }
  exports.encode = function base64VLQ_encode(aValue) {
    var encoded = '';
    var digit;
    var vlq = toVLQSigned(aValue);
    do {
      digit = vlq & VLQ_BASE_MASK;
      vlq >>>= VLQ_BASE_SHIFT;
      if (vlq > 0) digit |= VLQ_CONTINUATION_BIT;
      encoded += base64.encode(digit);
    } while (vlq > 0);
    return encoded;
  };
  exports.decode = function base64VLQ_decode(aStr, aIndex, aOutParam) {
    var strLen = aStr.length;
    var result = 0;
    var shift = 0;
    var continuation, digit;
    do {
      if (aIndex >= strLen) throw new Error('Expected more digits in base 64 VLQ value.');
      digit = base64.decode(aStr.charCodeAt(aIndex++));
      if (-1 === digit) throw new Error('Invalid base64 digit: ' + aStr.charAt(aIndex - 1));
      continuation = !!(digit & VLQ_CONTINUATION_BIT);
      digit &= VLQ_BASE_MASK;
      result = result + (digit << shift);
      shift += VLQ_BASE_SHIFT;
    } while (continuation);
    aOutParam.value = fromVLQSigned(result);
    aOutParam.rest = aIndex;
  };
}, function(module, exports) {
  var intToCharMap = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'.split('');
  exports.encode = function(number) {
    if (0 <= number && number < intToCharMap.length) return intToCharMap[number];
    throw new TypeError('Must be between 0 and 63: ' + number);
  };
  exports.decode = function(charCode) {
    var bigA = 65;
    var bigZ = 90;
    var littleA = 97;
    var littleZ = 122;
    var zero = 48;
    var nine = 57;
    var plus = 43;
    var slash = 47;
    var littleOffset = 26;
    var numberOffset = 52;
    if (bigA <= charCode && charCode <= bigZ) return charCode - bigA;
    if (littleA <= charCode && charCode <= littleZ) return charCode - littleA + littleOffset;
    if (zero <= charCode && charCode <= nine) return charCode - zero + numberOffset;
    if (charCode == plus) return 62;
    if (charCode == slash) return 63;
    return -1;
  };
}, function(module, exports) {
  function swap(ary, x, y) {
    var temp = ary[x];
    ary[x] = ary[y];
    ary[y] = temp;
  }
  function randomIntInRange(low, high) {
    return Math.round(low + Math.random() * (high - low));
  }
  function doQuickSort(ary, comparator, p, r) {
    if (p < r) {
      var pivotIndex = randomIntInRange(p, r);
      var i = p - 1;
      swap(ary, pivotIndex, r);
      var pivot = ary[r];
      for (var j = p; j < r; j++) if (comparator(ary[j], pivot) <= 0) {
        i += 1;
        swap(ary, i, j);
      }
      swap(ary, i + 1, j);
      var q = i + 1;
      doQuickSort(ary, comparator, p, q - 1);
      doQuickSort(ary, comparator, q + 1, r);
    }
  }
  exports.quickSort = function(ary, comparator) {
    doQuickSort(ary, comparator, 0, ary.length - 1);
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  'use strict';
  __webpack_require__.r(__webpack_exports__);
  function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
  }
  function _iterableToArrayLimit(arr, i) {
    if ('undefined' === typeof Symbol || !(Symbol.iterator in Object(arr))) return;
    var _arr = [];
    var _n = true;
    var _d = false;
    var _e = void 0;
    try {
      for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
        _arr.push(_s.value);
        if (i && _arr.length === i) break;
      }
    } catch (err) {
      _d = true;
      _e = err;
    } finally {
      try {
        if (!_n && null != _i['return']) _i['return']();
      } finally {
        if (_d) throw _e;
      }
    }
    return _arr;
  }
  function _arrayLikeToArray(arr, len) {
    if (null == len || len > arr.length) len = arr.length;
    for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
    return arr2;
  }
  function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if ('string' === typeof o) return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if ('Object' === n && o.constructor) n = o.constructor.name;
    if ('Map' === n || 'Set' === n) return Array.from(n);
    if ('Arguments' === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
  }
  function _nonIterableRest() {
    throw new TypeError('Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.');
  }
  function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
  }
  function _typeof(obj) {
    '@babel/helpers - typeof';
    if ('function' === typeof Symbol && 'symbol' === typeof Symbol.iterator) _typeof = function _typeof(obj) {
      return typeof obj;
    }; else _typeof = function _typeof(obj) {
      return obj && 'function' === typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? 'symbol' : typeof obj;
    };
    return _typeof(obj);
  }
  var source_map_consumer = __webpack_require__(1);
  var systemInfo = {
    platform: 'android',
    version: 5
  };
  var inited = false;
  function initEnvOnce() {
    if (inited) return;
    inited = true;
    if ('object' === ('undefined' === typeof __wxSourceMap ? 'undefined' : _typeof(__wxSourceMap))) {
      if ('function' !== typeof __wxSourceMap.get) void 0;
      if ('string' !== typeof __wxSourceMap.__system) void 0; else {
        var _wxSourceMap$__syste = __wxSourceMap.__system.toLowerCase().split(/\s+/), _wxSourceMap$__syste2 = _slicedToArray(_wxSourceMap$__syste, 2), platform = _wxSourceMap$__syste2[0], version = _wxSourceMap$__syste2[1];
        systemInfo.platform = platform;
        systemInfo.version = version;
        void 0;
      }
    } else void 0;
  }
  function getSourceMap(type, filePath) {
    var sourceMaps = 'undefined' !== typeof __wxSourceMap ? __wxSourceMap : {};
    sourceMaps.get = sourceMaps.get || function() {
      return void 0;
    };
    var sourceMap = sourceMaps.get('https://' + type + '/' + filePath) || sourceMaps.get('https://' + type + '//' + filePath) || sourceMaps.get(filePath) || sourceMaps.get('/' + filePath);
    if (!sourceMap || 'object' !== _typeof(sourceMap)) {
      void 0;
      return null;
    } else return sourceMap;
  }
  var consumers = {};
  function getConsumer(type, filePath) {
    var key = type + '/' + filePath;
    if (!consumers[key]) {
      var sourceMap = getSourceMap(type, filePath);
      if (!sourceMap) return null;
      consumers[key] = new source_map_consumer['SourceMapConsumer'](sourceMap);
    }
    return consumers[key];
  }
  function isIOS() {
    return 'ios' === systemInfo.platform;
  }
  void 0;
  var regex = /[ (@]*(?:https?:\/\/)?(usr|lib)?\/+(.*?):(\d+):(\d+)/;
  var regexWithDomain = /https?:\/\/res.servicewechat.com\/\w+\/\w+\/\w+\/\d+\//;
  var NATIVE_CODE = /@?\[native code\]$/;
  var STACK_END_RE = /Stack:([^ ]*)$/;
  var LINE_COLUMN_START_RE = /line:\d+,column:\d+,/;
  var SM_SOURCE_FULLPATH_PREFIX = /^\w+:(\/)+/;
  var PREFIX_SLASH = /^(\/)+/;
  var src_isIOSNativeCode = function isIOSNativeCode(stackLine) {
    return isIOS() && NATIVE_CODE.test(stackLine);
  };
  var resultAvailable = function resultAvailable(result) {
    return null != result.source && null != result.line && null != result.column;
  };
  var src_getOriginalStack = function getOriginalStack(item) {
    var consumer = getConsumer(item.type, item.path);
    if (!consumer) return null;
    var hotfix = isIOS() ? 2 : 1;
    var result = consumer.originalPositionFor({
      line: item.line,
      column: item.column - hotfix >= 0 ? item.column - hotfix : 0
    });
    return resultAvailable(result) ? result : null;
  };
  function parsePackage(fileName) {
    if (fileName.indexOf('/') > 0) {
      var parts = fileName.split('/');
      return [ parts[0], parts.slice(1).join('/') ];
    } else return [ '', fileName ];
  }
  function formatSourceName(name, packageName) {
    if (!name) return '';
    if (SM_SOURCE_FULLPATH_PREFIX.test(name)) return name.replace(SM_SOURCE_FULLPATH_PREFIX, ''); else return (packageName ? packageName + '/' : '') + name.replace(PREFIX_SLASH, '');
  }
  function parseLine(stackLine) {
    var origin = stackLine;
    var matchDomain = stackLine.match(regexWithDomain);
    if (matchDomain) stackLine = stackLine.replace(matchDomain, 'https://usr/');
    var match = regex.exec(stackLine);
    if (!match || match.length < 5) if (src_isIOSNativeCode(stackLine)) return {
      origin: origin,
      type: 'native',
      file: 'native code',
      message: 'at ' + stackLine.replace(NATIVE_CODE, '')
    }; else return null;
    var message = stackLine.slice(0, match.index).trim();
    var prepend = '';
    var oddEnd = message.match(STACK_END_RE);
    if (oddEnd) {
      prepend = message.replace(STACK_END_RE, '').replace(LINE_COLUMN_START_RE, '') + '\n';
      message = oddEnd[1] || '';
    }
    if ('at' != message && 0 !== message.indexOf('at ')) message = 'at ' + message;
    var path = match[2];
    var _parsePackage = parsePackage(path), _parsePackage2 = _slicedToArray(_parsePackage, 2), packageName = _parsePackage2[0], file = _parsePackage2[1];
    return {
      origin: origin,
      type: match[1],
      package: packageName,
      file: file,
      path: path,
      line: parseInt(match[3], 10),
      column: parseInt(match[4], 10),
      message: message,
      prepend: prepend
    };
  }
  function wrappedParseLine(stackLine) {
    try {
      return parseLine(stackLine);
    } catch (e) {
      void 0;
      return null;
    }
  }
  var src = __webpack_exports__['default'] = function(error) {
    try {
      initEnvOnce();
      if ('string' === typeof error.stack) {
        var stackInfoArr = [];
        var isEnd = false;
        error.stack = error.stack.split('\n').map(function(stackLine) {
          if (stackLine.indexOf('evaluate') >= 0 && stackLine.indexOf('WAServiceMainContext.js') >= 0) isEnd = true;
          if (isEnd) return null;
          var parsed = wrappedParseLine(stackLine);
          void 0;
          if (parsed) stackInfoArr.push(parsed);
          if (!parsed) return stackLine; else if ('lib' === parsed.type) return '' + parsed.prepend + parsed.message + ' (' + parsed.path + ':' + parsed.line + ':' + parsed.column + ')'; else if ('native' === parsed.type) return parsed.message + ' (' + parsed.file + ')'; else {
            var originalStack = src_getOriginalStack(parsed);
            parsed.originalStack = originalStack;
            if (originalStack) {
              var message = originalStack.name ? 'at ' + originalStack.name : parsed.message;
              return '' + parsed.prepend + message + ' (' + formatSourceName(originalStack.source, parsed['package']) + ':' + originalStack.line + ':' + (originalStack.column + 1) + ')';
            } else {
              void 0;
              return '' + parsed.prepend + parsed.message + ' (' + parsed.file + ':' + parsed.line + ':' + parsed.column + ')';
            }
          }
        }).filter(function(x) {
          return !!x;
        }).join('\n');
        error.stackInfoArr = stackInfoArr;
      }
      return error;
    } catch (e) {
      void 0;
      return error;
    }
  };
} ])['default'];