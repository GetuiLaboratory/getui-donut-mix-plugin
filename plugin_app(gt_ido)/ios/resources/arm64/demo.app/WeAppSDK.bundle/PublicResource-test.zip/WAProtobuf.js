
;try {

;(function () { /* LIBRARY_CLOSURE_START () */


            let getGlobalVar = "getProtobufGlobalVar"
            let sdkSubpakcageGlobalVarGetter
            if(globalThis[getGlobalVar]) {
              sdkSubpakcageGlobalVarGetter = globalThis[getGlobalVar]
            } else if(typeof globalThis.WeixinJSBridge !== "undefined" && globalThis.WeixinJSBridge[getGlobalVar]){
              sdkSubpakcageGlobalVarGetter = globalThis.WeixinJSBridge[getGlobalVar]
            }
            var {wxConsole,console,NativeGlobal,__Function__,__SDK_SUB_PACKAGE__} = sdkSubpakcageGlobalVarGetter();
          

/* eslint-disable */
// 直接用jscontext上的NativeGlobal，strict mode有坑，不要require
// var NativeGlobal = require('@/base/NativeGlobal').default

var Function = typeof __Function__ !== 'undefined' ? __Function__ : globalThis.Function;

let protobuf
function getProtobuf() {
  if (!protobuf) {
    protobuf = (function (modules) { // webpackBootstrap
      /******/ 	// The module cache
      /******/ 	var installedModules = {};
      /******/
      /******/ 	// The require function
      /******/ 	function __webpack_require__(moduleId) {
      /******/
      /******/ 		// Check if module is in cache
      /******/ 		if (installedModules[moduleId]) {
      /******/ 			return installedModules[moduleId].exports;
        /******/
  }
      /******/ 		// Create a new module (and put it into the cache)
      /******/ 		var module = installedModules[moduleId] = {
      /******/ 			i: moduleId,
      /******/ 			l: false,
      /******/ 			exports: {}
        /******/
  };
      /******/
      /******/ 		// Execute the module function
      /******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
      /******/
      /******/ 		// Flag the module as loaded
      /******/ 		module.l = true;
      /******/
      /******/ 		// Return the exports of the module
      /******/ 		return module.exports;
      /******/
  }
      /******/
      /******/
      /******/ 	// expose the modules object (__webpack_modules__)
      /******/ 	__webpack_require__.m = modules;
      /******/
      /******/ 	// expose the module cache
      /******/ 	__webpack_require__.c = installedModules;
      /******/
      /******/ 	// define getter function for harmony exports
      /******/ 	__webpack_require__.d = function (exports, name, getter) {
      /******/ 		if (!__webpack_require__.o(exports, name)) {
      /******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
        /******/
  }
      /******/
  };
      /******/
      /******/ 	// define __esModule on exports
      /******/ 	__webpack_require__.r = function (exports) {
      /******/ 		if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
      /******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
        /******/
  }
      /******/ 		Object.defineProperty(exports, '__esModule', { value: true });
      /******/
  };
      /******/
      /******/ 	// create a fake namespace object
      /******/ 	// mode & 1: value is a module id, require it
      /******/ 	// mode & 2: merge all properties of value into the ns
      /******/ 	// mode & 4: return value when already ns object
      /******/ 	// mode & 8|1: behave like require
      /******/ 	__webpack_require__.t = function (value, mode) {
      /******/ 		if (mode & 1) value = __webpack_require__(value);
      /******/ 		if (mode & 8) return value;
      /******/ 		if ((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
      /******/ 		var ns = Object.create(null);
      /******/ 		__webpack_require__.r(ns);
      /******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
      /******/ 		if (mode & 2 && typeof value != 'string') for (var key in value) __webpack_require__.d(ns, key, function (key) { return value[key]; }.bind(null, key));
      /******/ 		return ns;
      /******/
  };
      /******/
      /******/ 	// getDefaultExport function for compatibility with non-harmony modules
      /******/ 	__webpack_require__.n = function (module) {
      /******/ 		var getter = module && module.__esModule ?
      /******/ 			function getDefault() { return module['default']; } :
      /******/ 			function getModuleExports() { return module; };
      /******/ 		__webpack_require__.d(getter, 'a', getter);
      /******/ 		return getter;
      /******/
  };
      /******/
      /******/ 	// Object.prototype.hasOwnProperty.call
      /******/ 	__webpack_require__.o = function (object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
      /******/
      /******/ 	// __webpack_public_path__
      /******/ 	__webpack_require__.p = "";
      /******/
      /******/
      /******/ 	// Load entry module and return exports
      /******/ 	return __webpack_require__(__webpack_require__.s = "./entry.js");
    /******/
      })
          /************************************************************************/
          /******/({
      
          /***/ "./entry.js":
          /*!******************!*\
            !*** ./entry.js ***!
            \******************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
          /* WEBPACK VAR INJECTION */(function (Buffer) {
              const pb = __webpack_require__(/*! protocol-buffers */ "./node_modules/protocol-buffers/index.js");
              const pbe = __webpack_require__(/*! protocol-buffers-encodings */ "./node_modules/protocol-buffers-encodings/index.js");
              var varint = __webpack_require__(/*! varint */ "./node_modules/varint/index.js");
      
              const convertVarintBufferToInt64Buffer = (() => {
                var MSB = 0x80, REST = 0x7F
      
                return function (buffer, offset) {
                  const ret = new Uint8Array(8);
                  let bufferI = offset
                  let retI = 0;
                  let temp = 0;
                  let bitlength = 0;
      
                  do {
                    // 拼接varint里的7个bit
                    temp = temp | ((buffer[bufferI] & REST) << bitlength);
                    bitlength += 7;
      
                    // 如果总位数已经大于8
                    if (bitlength >= 8) {
                      // console.log(temp);
                      // 把右8位放入ret buffer，指针+1
                      ret[retI] = 0xFF & temp;
                      // 缓冲区右移8位
                      temp = temp >> 8;
                      bitlength -= 8
                      retI++;
                    }
                  } while (buffer[bufferI++] >= MSB);
                  // 把剩余的放入最后
                  ret[retI] = 0xFF & temp;
      
                  convertVarintBufferToInt64Buffer.bytes = bufferI - offset
                  return ret;
                }
              })();
              function varintLength(buffer, offset) {
                let length = 0;
                for (let i = offset; i < buffer.length; i++) {
                  if (!(buffer[i] & 0x80)) {
                    return length + 1;
      
                  } else {
                    length++;
                  }
                }
                return length
              }
      
              var encoder = function (type, encode, decode, encodingLength) {
                encode.bytes = decode.bytes = 0
                return {
                  type: type,
                  encode: encode,
                  decode: decode,
                  encodingLength: encodingLength
                }
              }
              pbe.uint64 = (function () {
      
                var decode = function (buffer, offset) {
                  var varLength = varintLength(buffer, offset)
                  // if (varLength >= 7 && NativeGlobal.decodeVarintArray) {
                  //     var val = NativeGlobal.decodeVarintArray(new Uint8Array(buffer.buffer, offset, buffer.length - offset));
                  //     decode.bytes = varLength;
                  if (varLength >= 7 && NativeGlobal.decodeUint64Array) {
                    buffer = convertVarintBufferToInt64Buffer(buffer, offset);
                    var val = NativeGlobal.decodeUint64Array(buffer);
                    decode.bytes = varLength;
      
                  } else {
                    var val = varint.decode(buffer, offset);
                    decode.bytes = varint.decode.bytes
                  }
      
                  return val
                }
      
                var encode = varint.encode;
      
                var encodingLength = function (val) {
                  return val < 0 ? 10 : varint.encodingLength(val)
                }
                return encoder(0, encode, decode, encodingLength)
              })();
              pbe.int64 = (function () {
                var decode = function (buffer, offset) {
                  var val = varint.decode(buffer, offset)
                  if (
                    (val > Number.MAX_SAFE_INTEGER || val < Number.MIN_SAFE_INTEGER)
                    && NativeGlobal.decodeUint64Array
                  ) {
                    var varLength = varintLength(buffer, offset)
                    let negative = varLength == 10;
                    if (negative) {
                      buffer[9 + offset] = buffer[9 + offset] & 0x7F
                    }
                    buffer = convertVarintBufferToInt64Buffer(buffer, offset);
                    var val = NativeGlobal.decodeUint64Array(buffer);
                    decode.bytes = varLength;
                    return negative ? "-" + val : val;
                  }
      
                  if (val >= Math.pow(2, 63)) {
                    var limit = 9
                    while (buffer[offset + limit - 1] === 0xff) limit--
                    limit = limit || 9
                    var subset = new Buffer(limit)
                    buffer.copy(subset, 0, offset, offset + limit)
                    subset[limit - 1] = subset[limit - 1] & 0x7f
                    val = -1 * varint.decode(subset, 0)
                    decode.bytes = 10
                  } else {
                    decode.bytes = varint.decode.bytes
                  }
                  return val
                }
      
                var encode = function (val, buffer, offset) {
                  if (val > Number.MAX_SAFE_INTEGER || val < Number.MIN_SAFE_INTEGER) {
                    throw new Error('number too large, not supported yet');
                  }
      
                  if (val < 0) {
                    var last = offset + 9
                    varint.encode(val * -1, buffer, offset)
                    offset += varint.encode.bytes - 1
                    buffer[offset] = buffer[offset] | 0x80
                    while (offset < last - 1) {
                      offset++
                      buffer[offset] = 0xff
                    }
                    buffer[last] = 0x01
                    encode.bytes = 10
                  } else {
                    varint.encode(val, buffer, offset)
                    encode.bytes = varint.encode.bytes
                  }
                  return buffer
                }
      
                var encodingLength = function (val) {
                  return val < 0 ? 10 : varint.encodingLength(val)
                }
                return encoder(0, encode, decode, encodingLength)
              })()
      
              function fixedDecode(odecode) {
                return function decode(buffer) {
                  if (Object.prototype.toString.call(buffer) == "[object Uint8Array]" && buffer.__proto__ != Buffer.__proto__) {
                    buffer.__proto__ = Buffer.prototype
                  }
                  const result = odecode.apply(this, arguments);
                  decode.bytes = odecode.bytes;
                  return result;
                }
              }
              module.exports = function (proto) {
                const message = pb(proto)
                Object.keys(message).forEach(function (struct) {
                  if (message[struct].decode) {
                    message[struct].decode = fixedDecode(message[struct].decode)
                  }
                })
      
                return message;
              };
      
              // module.exports = pb
              module.exports.fixBuffer = function (buffer) {
                if (Object.prototype.toString.call(buffer) == "[object Uint8Array]" && buffer.__proto__ != Buffer.__proto__) {
                  buffer.__proto__ = Buffer.prototype
                }
                return buffer;
              }
              /* WEBPACK VAR INJECTION */
      }.call(this, __webpack_require__(/*! ./node_modules/buffer/index.js */ "./node_modules/buffer/index.js").Buffer))
      
            /***/
      }),
      
          /***/ "./node_modules/base64-js/index.js":
          /*!*****************************************!*\
            !*** ./node_modules/base64-js/index.js ***!
            \*****************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
            "use strict";
      
      
            exports.byteLength = byteLength
            exports.toByteArray = toByteArray
            exports.fromByteArray = fromByteArray
      
            var lookup = []
            var revLookup = []
            var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array
      
            var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
            for (var i = 0, len = code.length; i < len; ++i) {
              lookup[i] = code[i]
              revLookup[code.charCodeAt(i)] = i
            }
      
            // Support decoding URL-safe base64 strings, as Node.js does.
            // See: https://en.wikipedia.org/wiki/Base64#URL_applications
            revLookup['-'.charCodeAt(0)] = 62
            revLookup['_'.charCodeAt(0)] = 63
      
            function getLens(b64) {
              var len = b64.length
      
              if (len % 4 > 0) {
                throw new Error('Invalid string. Length must be a multiple of 4')
              }
      
              // Trim off extra bytes after placeholder bytes are found
              // See: https://github.com/beatgammit/base64-js/issues/42
              var validLen = b64.indexOf('=')
              if (validLen === -1) validLen = len
      
              var placeHoldersLen = validLen === len
                ? 0
                : 4 - (validLen % 4)
      
              return [validLen, placeHoldersLen]
            }
      
            // base64 is 4/3 + up to two characters of the original data
            function byteLength(b64) {
              var lens = getLens(b64)
              var validLen = lens[0]
              var placeHoldersLen = lens[1]
              return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
            }
      
            function _byteLength(b64, validLen, placeHoldersLen) {
              return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
            }
      
            function toByteArray(b64) {
              var tmp
              var lens = getLens(b64)
              var validLen = lens[0]
              var placeHoldersLen = lens[1]
      
              var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen))
      
              var curByte = 0
      
              // if there are placeholders, only get up to the last complete 4 chars
              var len = placeHoldersLen > 0
                ? validLen - 4
                : validLen
      
              var i
              for (i = 0; i < len; i += 4) {
                tmp =
                  (revLookup[b64.charCodeAt(i)] << 18) |
                  (revLookup[b64.charCodeAt(i + 1)] << 12) |
                  (revLookup[b64.charCodeAt(i + 2)] << 6) |
                  revLookup[b64.charCodeAt(i + 3)]
                arr[curByte++] = (tmp >> 16) & 0xFF
                arr[curByte++] = (tmp >> 8) & 0xFF
                arr[curByte++] = tmp & 0xFF
              }
      
              if (placeHoldersLen === 2) {
                tmp =
                  (revLookup[b64.charCodeAt(i)] << 2) |
                  (revLookup[b64.charCodeAt(i + 1)] >> 4)
                arr[curByte++] = tmp & 0xFF
              }
      
              if (placeHoldersLen === 1) {
                tmp =
                  (revLookup[b64.charCodeAt(i)] << 10) |
                  (revLookup[b64.charCodeAt(i + 1)] << 4) |
                  (revLookup[b64.charCodeAt(i + 2)] >> 2)
                arr[curByte++] = (tmp >> 8) & 0xFF
                arr[curByte++] = tmp & 0xFF
              }
      
              return arr
            }
      
            function tripletToBase64(num) {
              return lookup[num >> 18 & 0x3F] +
                lookup[num >> 12 & 0x3F] +
                lookup[num >> 6 & 0x3F] +
                lookup[num & 0x3F]
            }
      
            function encodeChunk(uint8, start, end) {
              var tmp
              var output = []
              for (var i = start; i < end; i += 3) {
                tmp =
                  ((uint8[i] << 16) & 0xFF0000) +
                  ((uint8[i + 1] << 8) & 0xFF00) +
                  (uint8[i + 2] & 0xFF)
                output.push(tripletToBase64(tmp))
              }
              return output.join('')
            }
      
            function fromByteArray(uint8) {
              var tmp
              var len = uint8.length
              var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
              var parts = []
              var maxChunkLength = 16383 // must be multiple of 3
      
              // go through the array every three bytes, we'll deal with trailing stuff later
              for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
                parts.push(encodeChunk(
                  uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)
                ))
              }
      
              // pad the end with zeros, but make sure to not forget the extra bytes
              if (extraBytes === 1) {
                tmp = uint8[len - 1]
                parts.push(
                  lookup[tmp >> 2] +
                  lookup[(tmp << 4) & 0x3F] +
                  '=='
                )
              } else if (extraBytes === 2) {
                tmp = (uint8[len - 2] << 8) + uint8[len - 1]
                parts.push(
                  lookup[tmp >> 10] +
                  lookup[(tmp >> 4) & 0x3F] +
                  lookup[(tmp << 2) & 0x3F] +
                  '='
                )
              }
      
              return parts.join('')
            }
      
      
            /***/
      }),
      
          /***/ "./node_modules/buffer/index.js":
          /*!**************************************!*\
            !*** ./node_modules/buffer/index.js ***!
            \**************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
            "use strict";
          /* WEBPACK VAR INJECTION */(function (global) {/*!
          * The buffer module from node.js, for the browser.
          *
          * @author   Feross Aboukhadijeh <http://feross.org>
          * @license  MIT
          */
              /* eslint-disable no-proto */
      
      
      
              var base64 = __webpack_require__(/*! base64-js */ "./node_modules/base64-js/index.js")
              var ieee754 = __webpack_require__(/*! ieee754 */ "./node_modules/ieee754/index.js")
              var isArray = __webpack_require__(/*! isarray */ "./node_modules/isarray/index.js")
      
              exports.Buffer = Buffer
              exports.SlowBuffer = SlowBuffer
              exports.INSPECT_MAX_BYTES = 50
      
              /**
               * If `Buffer.TYPED_ARRAY_SUPPORT`:
               *   === true    Use Uint8Array implementation (fastest)
               *   === false   Use Object implementation (most compatible, even IE6)
               *
               * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
               * Opera 11.6+, iOS 4.2+.
               *
               * Due to various browser bugs, sometimes the Object implementation will be used even
               * when the browser supports typed arrays.
               *
               * Note:
               *
               *   - Firefox 4-29 lacks support for adding new properties to `Uint8Array` instances,
               *     See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438.
               *
               *   - Chrome 9-10 is missing the `TypedArray.prototype.subarray` function.
               *
               *   - IE10 has a broken `TypedArray.prototype.subarray` function which returns arrays of
               *     incorrect length in some situations.
      
              * We detect these buggy browsers and set `Buffer.TYPED_ARRAY_SUPPORT` to `false` so they
              * get the Object implementation, which is slower but behaves correctly.
              */
              Buffer.TYPED_ARRAY_SUPPORT = global.TYPED_ARRAY_SUPPORT !== undefined
                ? global.TYPED_ARRAY_SUPPORT
                : typedArraySupport()
      
              /*
              * Export kMaxLength after typed array support is determined.
              */
              exports.kMaxLength = kMaxLength()
      
              function typedArraySupport() {
                try {
                  var arr = new Uint8Array(1)
                  arr.__proto__ = { __proto__: Uint8Array.prototype, foo: function () { return 42 } }
                  return arr.foo() === 42 && // typed array instances can be augmented
                    typeof arr.subarray === 'function' && // chrome 9-10 lack `subarray`
                    arr.subarray(1, 1).byteLength === 0 // ie10 has broken `subarray`
                } catch (e) {
                  return false
                }
              }
      
              function kMaxLength() {
                return Buffer.TYPED_ARRAY_SUPPORT
                  ? 0x7fffffff
                  : 0x3fffffff
              }
      
              function createBuffer(that, length) {
                if (kMaxLength() < length) {
                  throw new RangeError('Invalid typed array length')
                }
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  // Return an augmented `Uint8Array` instance, for best performance
                  that = new Uint8Array(length)
                  that.__proto__ = Buffer.prototype
                } else {
                  // Fallback: Return an object instance of the Buffer class
                  if (that === null) {
                    that = new Buffer(length)
                  }
                  that.length = length
                }
      
                return that
              }
      
              /**
               * The Buffer constructor returns instances of `Uint8Array` that have their
               * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
               * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
               * and the `Uint8Array` methods. Square bracket notation works as expected -- it
               * returns a single octet.
               *
               * The `Uint8Array` prototype remains unmodified.
               */
      
              function Buffer(arg, encodingOrOffset, length) {
                if (!Buffer.TYPED_ARRAY_SUPPORT && !(this instanceof Buffer)) {
                  return new Buffer(arg, encodingOrOffset, length)
                }
      
                // Common case.
                if (typeof arg === 'number') {
                  if (typeof encodingOrOffset === 'string') {
                    throw new Error(
                      'If encoding is specified then the first argument must be a string'
                    )
                  }
                  return allocUnsafe(this, arg)
                }
                return from(this, arg, encodingOrOffset, length)
              }
      
              Buffer.poolSize = 8192 // not used by this implementation
      
              // TODO: Legacy, not needed anymore. Remove in next major version.
              Buffer._augment = function (arr) {
                arr.__proto__ = Buffer.prototype
                return arr
              }
      
              function from(that, value, encodingOrOffset, length) {
                if (typeof value === 'number') {
                  throw new TypeError('"value" argument must not be a number')
                }
      
                if (typeof ArrayBuffer !== 'undefined' && value instanceof ArrayBuffer) {
                  return fromArrayBuffer(that, value, encodingOrOffset, length)
                }
      
                if (typeof value === 'string') {
                  return fromString(that, value, encodingOrOffset)
                }
      
                return fromObject(that, value)
              }
      
              /**
               * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
               * if value is a number.
               * Buffer.from(str[, encoding])
               * Buffer.from(array)
               * Buffer.from(buffer)
               * Buffer.from(arrayBuffer[, byteOffset[, length]])
               **/
              Buffer.from = function (value, encodingOrOffset, length) {
                return from(null, value, encodingOrOffset, length)
              }
      
              if (Buffer.TYPED_ARRAY_SUPPORT) {
                Buffer.prototype.__proto__ = Uint8Array.prototype
                Buffer.__proto__ = Uint8Array
                if (typeof Symbol !== 'undefined' && Symbol.species &&
                  Buffer[Symbol.species] === Buffer) {
                  // Fix subarray() in ES2016. See: https://github.com/feross/buffer/pull/97
                  Object.defineProperty(Buffer, Symbol.species, {
                    value: null,
                    configurable: true
                  })
                }
              }
      
              function assertSize(size) {
                if (typeof size !== 'number') {
                  throw new TypeError('"size" argument must be a number')
                } else if (size < 0) {
                  throw new RangeError('"size" argument must not be negative')
                }
              }
      
              function alloc(that, size, fill, encoding) {
                assertSize(size)
                if (size <= 0) {
                  return createBuffer(that, size)
                }
                if (fill !== undefined) {
                  // Only pay attention to encoding if it's a string. This
                  // prevents accidentally sending in a number that would
                  // be interpretted as a start offset.
                  return typeof encoding === 'string'
                    ? createBuffer(that, size).fill(fill, encoding)
                    : createBuffer(that, size).fill(fill)
                }
                return createBuffer(that, size)
              }
      
              /**
               * Creates a new filled Buffer instance.
               * alloc(size[, fill[, encoding]])
               **/
              Buffer.alloc = function (size, fill, encoding) {
                return alloc(null, size, fill, encoding)
              }
      
              function allocUnsafe(that, size) {
                assertSize(size)
                that = createBuffer(that, size < 0 ? 0 : checked(size) | 0)
                if (!Buffer.TYPED_ARRAY_SUPPORT) {
                  for (var i = 0; i < size; ++i) {
                    that[i] = 0
                  }
                }
                return that
              }
      
              /**
               * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
               * */
              Buffer.allocUnsafe = function (size) {
                return allocUnsafe(null, size)
              }
              /**
               * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
               */
              Buffer.allocUnsafeSlow = function (size) {
                return allocUnsafe(null, size)
              }
      
              function fromString(that, string, encoding) {
                if (typeof encoding !== 'string' || encoding === '') {
                  encoding = 'utf8'
                }
      
                if (!Buffer.isEncoding(encoding)) {
                  throw new TypeError('"encoding" must be a valid string encoding')
                }
      
                var length = byteLength(string, encoding) | 0
                that = createBuffer(that, length)
      
                var actual = that.write(string, encoding)
      
                if (actual !== length) {
                  // Writing a hex string, for example, that contains invalid characters will
                  // cause everything after the first invalid character to be ignored. (e.g.
                  // 'abxxcd' will be treated as 'ab')
                  that = that.slice(0, actual)
                }
      
                return that
              }
      
              function fromArrayLike(that, array) {
                var length = array.length < 0 ? 0 : checked(array.length) | 0
                that = createBuffer(that, length)
                for (var i = 0; i < length; i += 1) {
                  that[i] = array[i] & 255
                }
                return that
              }
      
              function fromArrayBuffer(that, array, byteOffset, length) {
                array.byteLength // this throws if `array` is not a valid ArrayBuffer
      
                if (byteOffset < 0 || array.byteLength < byteOffset) {
                  throw new RangeError('\'offset\' is out of bounds')
                }
      
                if (array.byteLength < byteOffset + (length || 0)) {
                  throw new RangeError('\'length\' is out of bounds')
                }
      
                if (byteOffset === undefined && length === undefined) {
                  array = new Uint8Array(array)
                } else if (length === undefined) {
                  array = new Uint8Array(array, byteOffset)
                } else {
                  array = new Uint8Array(array, byteOffset, length)
                }
      
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  // Return an augmented `Uint8Array` instance, for best performance
                  that = array
                  that.__proto__ = Buffer.prototype
                } else {
                  // Fallback: Return an object instance of the Buffer class
                  that = fromArrayLike(that, array)
                }
                return that
              }
      
              function fromObject(that, obj) {
                if (Buffer.isBuffer(obj)) {
                  var len = checked(obj.length) | 0
                  that = createBuffer(that, len)
      
                  if (that.length === 0) {
                    return that
                  }
      
                  obj.copy(that, 0, 0, len)
                  return that
                }
      
                if (obj) {
                  if ((typeof ArrayBuffer !== 'undefined' &&
                    obj.buffer instanceof ArrayBuffer) || 'length' in obj) {
                    if (typeof obj.length !== 'number' || isnan(obj.length)) {
                      return createBuffer(that, 0)
                    }
                    return fromArrayLike(that, obj)
                  }
      
                  if (obj.type === 'Buffer' && isArray(obj.data)) {
                    return fromArrayLike(that, obj.data)
                  }
                }
      
                throw new TypeError('First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.')
              }
      
              function checked(length) {
                // Note: cannot use `length < kMaxLength()` here because that fails when
                // length is NaN (which is otherwise coerced to zero.)
                if (length >= kMaxLength()) {
                  throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
                    'size: 0x' + kMaxLength().toString(16) + ' bytes')
                }
                return length | 0
              }
      
              function SlowBuffer(length) {
                if (+length != length) { // eslint-disable-line eqeqeq
                  length = 0
                }
                return Buffer.alloc(+length)
              }
      
              Buffer.isBuffer = function isBuffer(b) {
                return !!(b != null && b._isBuffer)
              }
      
              Buffer.compare = function compare(a, b) {
                if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
                  throw new TypeError('Arguments must be Buffers')
                }
      
                if (a === b) return 0
      
                var x = a.length
                var y = b.length
      
                for (var i = 0, len = Math.min(x, y); i < len; ++i) {
                  if (a[i] !== b[i]) {
                    x = a[i]
                    y = b[i]
                    break
                  }
                }
      
                if (x < y) return -1
                if (y < x) return 1
                return 0
              }
      
              Buffer.isEncoding = function isEncoding(encoding) {
                switch (String(encoding).toLowerCase()) {
                  case 'hex':
                  case 'utf8':
                  case 'utf-8':
                  case 'ascii':
                  case 'latin1':
                  case 'binary':
                  case 'base64':
                  case 'ucs2':
                  case 'ucs-2':
                  case 'utf16le':
                  case 'utf-16le':
                    return true
                  default:
                    return false
                }
              }
      
              Buffer.concat = function concat(list, length) {
                if (!isArray(list)) {
                  throw new TypeError('"list" argument must be an Array of Buffers')
                }
      
                if (list.length === 0) {
                  return Buffer.alloc(0)
                }
      
                var i
                if (length === undefined) {
                  length = 0
                  for (i = 0; i < list.length; ++i) {
                    length += list[i].length
                  }
                }
      
                var buffer = Buffer.allocUnsafe(length)
                var pos = 0
                for (i = 0; i < list.length; ++i) {
                  var buf = list[i]
                  if (!Buffer.isBuffer(buf)) {
                    throw new TypeError('"list" argument must be an Array of Buffers')
                  }
                  buf.copy(buffer, pos)
                  pos += buf.length
                }
                return buffer
              }
      
              function byteLength(string, encoding) {
                if (Buffer.isBuffer(string)) {
                  return string.length
                }
                if (typeof ArrayBuffer !== 'undefined' && typeof ArrayBuffer.isView === 'function' &&
                  (ArrayBuffer.isView(string) || string instanceof ArrayBuffer)) {
                  return string.byteLength
                }
                if (typeof string !== 'string') {
                  string = '' + string
                }
      
                var len = string.length
                if (len === 0) return 0
      
                // Use a for loop to avoid recursion
                var loweredCase = false
                for (; ;) {
                  switch (encoding) {
                    case 'ascii':
                    case 'latin1':
                    case 'binary':
                      return len
                    case 'utf8':
                    case 'utf-8':
                    case undefined:
                      return utf8ToBytes(string).length
                    case 'ucs2':
                    case 'ucs-2':
                    case 'utf16le':
                    case 'utf-16le':
                      return len * 2
                    case 'hex':
                      return len >>> 1
                    case 'base64':
                      return base64ToBytes(string).length
                    default:
                      if (loweredCase) return utf8ToBytes(string).length // assume utf8
                      encoding = ('' + encoding).toLowerCase()
                      loweredCase = true
                  }
                }
              }
              Buffer.byteLength = byteLength
      
              function slowToString(encoding, start, end) {
                var loweredCase = false
      
                // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
                // property of a typed array.
      
                // This behaves neither like String nor Uint8Array in that we set start/end
                // to their upper/lower bounds if the value passed is out of range.
                // undefined is handled specially as per ECMA-262 6th Edition,
                // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
                if (start === undefined || start < 0) {
                  start = 0
                }
                // Return early if start > this.length. Done here to prevent potential uint32
                // coercion fail below.
                if (start > this.length) {
                  return ''
                }
      
                if (end === undefined || end > this.length) {
                  end = this.length
                }
      
                if (end <= 0) {
                  return ''
                }
      
                // Force coersion to uint32. This will also coerce falsey/NaN values to 0.
                end >>>= 0
                start >>>= 0
      
                if (end <= start) {
                  return ''
                }
      
                if (!encoding) encoding = 'utf8'
      
                while (true) {
                  switch (encoding) {
                    case 'hex':
                      return hexSlice(this, start, end)
      
                    case 'utf8':
                    case 'utf-8':
                      return utf8Slice(this, start, end)
      
                    case 'ascii':
                      return asciiSlice(this, start, end)
      
                    case 'latin1':
                    case 'binary':
                      return latin1Slice(this, start, end)
      
                    case 'base64':
                      return base64Slice(this, start, end)
      
                    case 'ucs2':
                    case 'ucs-2':
                    case 'utf16le':
                    case 'utf-16le':
                      return utf16leSlice(this, start, end)
      
                    default:
                      if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
                      encoding = (encoding + '').toLowerCase()
                      loweredCase = true
                  }
                }
              }
      
              // The property is used by `Buffer.isBuffer` and `is-buffer` (in Safari 5-7) to detect
              // Buffer instances.
              Buffer.prototype._isBuffer = true
      
              function swap(b, n, m) {
                var i = b[n]
                b[n] = b[m]
                b[m] = i
              }
      
              Buffer.prototype.swap16 = function swap16() {
                var len = this.length
                if (len % 2 !== 0) {
                  throw new RangeError('Buffer size must be a multiple of 16-bits')
                }
                for (var i = 0; i < len; i += 2) {
                  swap(this, i, i + 1)
                }
                return this
              }
      
              Buffer.prototype.swap32 = function swap32() {
                var len = this.length
                if (len % 4 !== 0) {
                  throw new RangeError('Buffer size must be a multiple of 32-bits')
                }
                for (var i = 0; i < len; i += 4) {
                  swap(this, i, i + 3)
                  swap(this, i + 1, i + 2)
                }
                return this
              }
      
              Buffer.prototype.swap64 = function swap64() {
                var len = this.length
                if (len % 8 !== 0) {
                  throw new RangeError('Buffer size must be a multiple of 64-bits')
                }
                for (var i = 0; i < len; i += 8) {
                  swap(this, i, i + 7)
                  swap(this, i + 1, i + 6)
                  swap(this, i + 2, i + 5)
                  swap(this, i + 3, i + 4)
                }
                return this
              }
      
              Buffer.prototype.toString = function toString() {
                var length = this.length | 0
                if (length === 0) return ''
                if (arguments.length === 0) return utf8Slice(this, 0, length)
                return slowToString.apply(this, arguments)
              }
      
              Buffer.prototype.equals = function equals(b) {
                if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
                if (this === b) return true
                return Buffer.compare(this, b) === 0
              }
      
              Buffer.prototype.inspect = function inspect() {
                var str = ''
                var max = exports.INSPECT_MAX_BYTES
                if (this.length > 0) {
                  str = this.toString('hex', 0, max).match(/.{2}/g).join(' ')
                  if (this.length > max) str += ' ... '
                }
                return '<Buffer ' + str + '>'
              }
      
              Buffer.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
                if (!Buffer.isBuffer(target)) {
                  throw new TypeError('Argument must be a Buffer')
                }
      
                if (start === undefined) {
                  start = 0
                }
                if (end === undefined) {
                  end = target ? target.length : 0
                }
                if (thisStart === undefined) {
                  thisStart = 0
                }
                if (thisEnd === undefined) {
                  thisEnd = this.length
                }
      
                if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
                  throw new RangeError('out of range index')
                }
      
                if (thisStart >= thisEnd && start >= end) {
                  return 0
                }
                if (thisStart >= thisEnd) {
                  return -1
                }
                if (start >= end) {
                  return 1
                }
      
                start >>>= 0
                end >>>= 0
                thisStart >>>= 0
                thisEnd >>>= 0
      
                if (this === target) return 0
      
                var x = thisEnd - thisStart
                var y = end - start
                var len = Math.min(x, y)
      
                var thisCopy = this.slice(thisStart, thisEnd)
                var targetCopy = target.slice(start, end)
      
                for (var i = 0; i < len; ++i) {
                  if (thisCopy[i] !== targetCopy[i]) {
                    x = thisCopy[i]
                    y = targetCopy[i]
                    break
                  }
                }
      
                if (x < y) return -1
                if (y < x) return 1
                return 0
              }
      
              // Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
              // OR the last index of `val` in `buffer` at offset <= `byteOffset`.
              //
              // Arguments:
              // - buffer - a Buffer to search
              // - val - a string, Buffer, or number
              // - byteOffset - an index into `buffer`; will be clamped to an int32
              // - encoding - an optional encoding, relevant is val is a string
              // - dir - true for indexOf, false for lastIndexOf
              function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
                // Empty buffer means no match
                if (buffer.length === 0) return -1
      
                // Normalize byteOffset
                if (typeof byteOffset === 'string') {
                  encoding = byteOffset
                  byteOffset = 0
                } else if (byteOffset > 0x7fffffff) {
                  byteOffset = 0x7fffffff
                } else if (byteOffset < -0x80000000) {
                  byteOffset = -0x80000000
                }
                byteOffset = +byteOffset  // Coerce to Number.
                if (isNaN(byteOffset)) {
                  // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
                  byteOffset = dir ? 0 : (buffer.length - 1)
                }
      
                // Normalize byteOffset: negative offsets start from the end of the buffer
                if (byteOffset < 0) byteOffset = buffer.length + byteOffset
                if (byteOffset >= buffer.length) {
                  if (dir) return -1
                  else byteOffset = buffer.length - 1
                } else if (byteOffset < 0) {
                  if (dir) byteOffset = 0
                  else return -1
                }
      
                // Normalize val
                if (typeof val === 'string') {
                  val = Buffer.from(val, encoding)
                }
      
                // Finally, search either indexOf (if dir is true) or lastIndexOf
                if (Buffer.isBuffer(val)) {
                  // Special case: looking for empty string/buffer always fails
                  if (val.length === 0) {
                    return -1
                  }
                  return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
                } else if (typeof val === 'number') {
                  val = val & 0xFF // Search for a byte value [0-255]
                  if (Buffer.TYPED_ARRAY_SUPPORT &&
                    typeof Uint8Array.prototype.indexOf === 'function') {
                    if (dir) {
                      return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset)
                    } else {
                      return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
                    }
                  }
                  return arrayIndexOf(buffer, [val], byteOffset, encoding, dir)
                }
      
                throw new TypeError('val must be string, number or Buffer')
              }
      
              function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
                var indexSize = 1
                var arrLength = arr.length
                var valLength = val.length
      
                if (encoding !== undefined) {
                  encoding = String(encoding).toLowerCase()
                  if (encoding === 'ucs2' || encoding === 'ucs-2' ||
                    encoding === 'utf16le' || encoding === 'utf-16le') {
                    if (arr.length < 2 || val.length < 2) {
                      return -1
                    }
                    indexSize = 2
                    arrLength /= 2
                    valLength /= 2
                    byteOffset /= 2
                  }
                }
      
                function read(buf, i) {
                  if (indexSize === 1) {
                    return buf[i]
                  } else {
                    return buf.readUInt16BE(i * indexSize)
                  }
                }
      
                var i
                if (dir) {
                  var foundIndex = -1
                  for (i = byteOffset; i < arrLength; i++) {
                    if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
                      if (foundIndex === -1) foundIndex = i
                      if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
                    } else {
                      if (foundIndex !== -1) i -= i - foundIndex
                      foundIndex = -1
                    }
                  }
                } else {
                  if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength
                  for (i = byteOffset; i >= 0; i--) {
                    var found = true
                    for (var j = 0; j < valLength; j++) {
                      if (read(arr, i + j) !== read(val, j)) {
                        found = false
                        break
                      }
                    }
                    if (found) return i
                  }
                }
      
                return -1
              }
      
              Buffer.prototype.includes = function includes(val, byteOffset, encoding) {
                return this.indexOf(val, byteOffset, encoding) !== -1
              }
      
              Buffer.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
                return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
              }
      
              Buffer.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
                return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
              }
      
              function hexWrite(buf, string, offset, length) {
                offset = Number(offset) || 0
                var remaining = buf.length - offset
                if (!length) {
                  length = remaining
                } else {
                  length = Number(length)
                  if (length > remaining) {
                    length = remaining
                  }
                }
      
                // must be an even number of digits
                var strLen = string.length
                if (strLen % 2 !== 0) throw new TypeError('Invalid hex string')
      
                if (length > strLen / 2) {
                  length = strLen / 2
                }
                for (var i = 0; i < length; ++i) {
                  var parsed = parseInt(string.substr(i * 2, 2), 16)
                  if (isNaN(parsed)) return i
                  buf[offset + i] = parsed
                }
                return i
              }
      
              function utf8Write(buf, string, offset, length) {
                return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
              }
      
              function asciiWrite(buf, string, offset, length) {
                return blitBuffer(asciiToBytes(string), buf, offset, length)
              }
      
              function latin1Write(buf, string, offset, length) {
                return asciiWrite(buf, string, offset, length)
              }
      
              function base64Write(buf, string, offset, length) {
                return blitBuffer(base64ToBytes(string), buf, offset, length)
              }
      
              function ucs2Write(buf, string, offset, length) {
                return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
              }
      
              Buffer.prototype.write = function write(string, offset, length, encoding) {
                // Buffer#write(string)
                if (offset === undefined) {
                  encoding = 'utf8'
                  length = this.length
                  offset = 0
                  // Buffer#write(string, encoding)
                } else if (length === undefined && typeof offset === 'string') {
                  encoding = offset
                  length = this.length
                  offset = 0
                  // Buffer#write(string, offset[, length][, encoding])
                } else if (isFinite(offset)) {
                  offset = offset | 0
                  if (isFinite(length)) {
                    length = length | 0
                    if (encoding === undefined) encoding = 'utf8'
                  } else {
                    encoding = length
                    length = undefined
                  }
                  // legacy write(string, encoding, offset, length) - remove in v0.13
                } else {
                  throw new Error(
                    'Buffer.write(string, encoding, offset[, length]) is no longer supported'
                  )
                }
      
                var remaining = this.length - offset
                if (length === undefined || length > remaining) length = remaining
      
                if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
                  throw new RangeError('Attempt to write outside buffer bounds')
                }
      
                if (!encoding) encoding = 'utf8'
      
                var loweredCase = false
                for (; ;) {
                  switch (encoding) {
                    case 'hex':
                      return hexWrite(this, string, offset, length)
      
                    case 'utf8':
                    case 'utf-8':
                      return utf8Write(this, string, offset, length)
      
                    case 'ascii':
                      return asciiWrite(this, string, offset, length)
      
                    case 'latin1':
                    case 'binary':
                      return latin1Write(this, string, offset, length)
      
                    case 'base64':
                      // Warning: maxLength not taken into account in base64Write
                      return base64Write(this, string, offset, length)
      
                    case 'ucs2':
                    case 'ucs-2':
                    case 'utf16le':
                    case 'utf-16le':
                      return ucs2Write(this, string, offset, length)
      
                    default:
                      if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
                      encoding = ('' + encoding).toLowerCase()
                      loweredCase = true
                  }
                }
              }
      
              Buffer.prototype.toJSON = function toJSON() {
                return {
                  type: 'Buffer',
                  data: Array.prototype.slice.call(this._arr || this, 0)
                }
              }
      
              function base64Slice(buf, start, end) {
                if (start === 0 && end === buf.length) {
                  return base64.fromByteArray(buf)
                } else {
                  return base64.fromByteArray(buf.slice(start, end))
                }
              }
      
              function utf8Slice(buf, start, end) {
                end = Math.min(buf.length, end)
                var res = []
      
                var i = start
                while (i < end) {
                  var firstByte = buf[i]
                  var codePoint = null
                  var bytesPerSequence = (firstByte > 0xEF) ? 4
                    : (firstByte > 0xDF) ? 3
                      : (firstByte > 0xBF) ? 2
                        : 1
      
                  if (i + bytesPerSequence <= end) {
                    var secondByte, thirdByte, fourthByte, tempCodePoint
      
                    switch (bytesPerSequence) {
                      case 1:
                        if (firstByte < 0x80) {
                          codePoint = firstByte
                        }
                        break
                      case 2:
                        secondByte = buf[i + 1]
                        if ((secondByte & 0xC0) === 0x80) {
                          tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
                          if (tempCodePoint > 0x7F) {
                            codePoint = tempCodePoint
                          }
                        }
                        break
                      case 3:
                        secondByte = buf[i + 1]
                        thirdByte = buf[i + 2]
                        if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
                          tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
                          if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
                            codePoint = tempCodePoint
                          }
                        }
                        break
                      case 4:
                        secondByte = buf[i + 1]
                        thirdByte = buf[i + 2]
                        fourthByte = buf[i + 3]
                        if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
                          tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
                          if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
                            codePoint = tempCodePoint
                          }
                        }
                    }
                  }
      
                  if (codePoint === null) {
                    // we did not generate a valid codePoint so insert a
                    // replacement char (U+FFFD) and advance only 1 byte
                    codePoint = 0xFFFD
                    bytesPerSequence = 1
                  } else if (codePoint > 0xFFFF) {
                    // encode to utf16 (surrogate pair dance)
                    codePoint -= 0x10000
                    res.push(codePoint >>> 10 & 0x3FF | 0xD800)
                    codePoint = 0xDC00 | codePoint & 0x3FF
                  }
      
                  res.push(codePoint)
                  i += bytesPerSequence
                }
      
                return decodeCodePointsArray(res)
              }
      
              // Based on http://stackoverflow.com/a/22747272/680742, the browser with
              // the lowest limit is Chrome, with 0x10000 args.
              // We go 1 magnitude less, for safety
              var MAX_ARGUMENTS_LENGTH = 0x1000
      
              function decodeCodePointsArray(codePoints) {
                var len = codePoints.length
                if (len <= MAX_ARGUMENTS_LENGTH) {
                  return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
                }
      
                // Decode in chunks to avoid "call stack size exceeded".
                var res = ''
                var i = 0
                while (i < len) {
                  res += String.fromCharCode.apply(
                    String,
                    codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
                  )
                }
                return res
              }
      
              function asciiSlice(buf, start, end) {
                var ret = ''
                end = Math.min(buf.length, end)
      
                for (var i = start; i < end; ++i) {
                  ret += String.fromCharCode(buf[i] & 0x7F)
                }
                return ret
              }
      
              function latin1Slice(buf, start, end) {
                var ret = ''
                end = Math.min(buf.length, end)
      
                for (var i = start; i < end; ++i) {
                  ret += String.fromCharCode(buf[i])
                }
                return ret
              }
      
              function hexSlice(buf, start, end) {
                var len = buf.length
      
                if (!start || start < 0) start = 0
                if (!end || end < 0 || end > len) end = len
      
                var out = ''
                for (var i = start; i < end; ++i) {
                  out += toHex(buf[i])
                }
                return out
              }
      
              function utf16leSlice(buf, start, end) {
                var bytes = buf.slice(start, end)
                var res = ''
                for (var i = 0; i < bytes.length; i += 2) {
                  res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256)
                }
                return res
              }
      
              Buffer.prototype.slice = function slice(start, end) {
                var len = this.length
                start = ~~start
                end = end === undefined ? len : ~~end
      
                if (start < 0) {
                  start += len
                  if (start < 0) start = 0
                } else if (start > len) {
                  start = len
                }
      
                if (end < 0) {
                  end += len
                  if (end < 0) end = 0
                } else if (end > len) {
                  end = len
                }
      
                if (end < start) end = start
      
                var newBuf
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  newBuf = this.subarray(start, end)
                  newBuf.__proto__ = Buffer.prototype
                } else {
                  var sliceLen = end - start
                  newBuf = new Buffer(sliceLen, undefined)
                  for (var i = 0; i < sliceLen; ++i) {
                    newBuf[i] = this[i + start]
                  }
                }
      
                return newBuf
              }
      
              /*
              * Need to make sure that buffer isn't trying to write out of bounds.
              */
              function checkOffset(offset, ext, length) {
                if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
                if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
              }
      
              Buffer.prototype.readUIntLE = function readUIntLE(offset, byteLength, noAssert) {
                offset = offset | 0
                byteLength = byteLength | 0
                if (!noAssert) checkOffset(offset, byteLength, this.length)
      
                var val = this[offset]
                var mul = 1
                var i = 0
                while (++i < byteLength && (mul *= 0x100)) {
                  val += this[offset + i] * mul
                }
      
                return val
              }
      
              Buffer.prototype.readUIntBE = function readUIntBE(offset, byteLength, noAssert) {
                offset = offset | 0
                byteLength = byteLength | 0
                if (!noAssert) {
                  checkOffset(offset, byteLength, this.length)
                }
      
                var val = this[offset + --byteLength]
                var mul = 1
                while (byteLength > 0 && (mul *= 0x100)) {
                  val += this[offset + --byteLength] * mul
                }
      
                return val
              }
      
              Buffer.prototype.readUInt8 = function readUInt8(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 1, this.length)
                return this[offset]
              }
      
              Buffer.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 2, this.length)
                return this[offset] | (this[offset + 1] << 8)
              }
      
              Buffer.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 2, this.length)
                return (this[offset] << 8) | this[offset + 1]
              }
      
              Buffer.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 4, this.length)
      
                return ((this[offset]) |
                  (this[offset + 1] << 8) |
                  (this[offset + 2] << 16)) +
                  (this[offset + 3] * 0x1000000)
              }
      
              Buffer.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 4, this.length)
      
                return (this[offset] * 0x1000000) +
                  ((this[offset + 1] << 16) |
                    (this[offset + 2] << 8) |
                    this[offset + 3])
              }
      
              Buffer.prototype.readIntLE = function readIntLE(offset, byteLength, noAssert) {
                offset = offset | 0
                byteLength = byteLength | 0
                if (!noAssert) checkOffset(offset, byteLength, this.length)
      
                var val = this[offset]
                var mul = 1
                var i = 0
                while (++i < byteLength && (mul *= 0x100)) {
                  val += this[offset + i] * mul
                }
                mul *= 0x80
      
                if (val >= mul) val -= Math.pow(2, 8 * byteLength)
      
                return val
              }
      
              Buffer.prototype.readIntBE = function readIntBE(offset, byteLength, noAssert) {
                offset = offset | 0
                byteLength = byteLength | 0
                if (!noAssert) checkOffset(offset, byteLength, this.length)
      
                var i = byteLength
                var mul = 1
                var val = this[offset + --i]
                while (i > 0 && (mul *= 0x100)) {
                  val += this[offset + --i] * mul
                }
                mul *= 0x80
      
                if (val >= mul) val -= Math.pow(2, 8 * byteLength)
      
                return val
              }
      
              Buffer.prototype.readInt8 = function readInt8(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 1, this.length)
                if (!(this[offset] & 0x80)) return (this[offset])
                return ((0xff - this[offset] + 1) * -1)
              }
      
              Buffer.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 2, this.length)
                var val = this[offset] | (this[offset + 1] << 8)
                return (val & 0x8000) ? val | 0xFFFF0000 : val
              }
      
              Buffer.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 2, this.length)
                var val = this[offset + 1] | (this[offset] << 8)
                return (val & 0x8000) ? val | 0xFFFF0000 : val
              }
      
              Buffer.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 4, this.length)
      
                return (this[offset]) |
                  (this[offset + 1] << 8) |
                  (this[offset + 2] << 16) |
                  (this[offset + 3] << 24)
              }
      
              Buffer.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 4, this.length)
      
                return (this[offset] << 24) |
                  (this[offset + 1] << 16) |
                  (this[offset + 2] << 8) |
                  (this[offset + 3])
              }
      
              Buffer.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 4, this.length)
                return ieee754.read(this, offset, true, 23, 4)
              }
      
              Buffer.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 4, this.length)
                return ieee754.read(this, offset, false, 23, 4)
              }
      
              Buffer.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 8, this.length)
                return ieee754.read(this, offset, true, 52, 8)
              }
      
              Buffer.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
                if (!noAssert) checkOffset(offset, 8, this.length)
                return ieee754.read(this, offset, false, 52, 8)
              }
      
              function checkInt(buf, value, offset, ext, max, min) {
                if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
                if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
                if (offset + ext > buf.length) throw new RangeError('Index out of range')
              }
      
              Buffer.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength, noAssert) {
                value = +value
                offset = offset | 0
                byteLength = byteLength | 0
                if (!noAssert) {
                  var maxBytes = Math.pow(2, 8 * byteLength) - 1
                  checkInt(this, value, offset, byteLength, maxBytes, 0)
                }
      
                var mul = 1
                var i = 0
                this[offset] = value & 0xFF
                while (++i < byteLength && (mul *= 0x100)) {
                  this[offset + i] = (value / mul) & 0xFF
                }
      
                return offset + byteLength
              }
      
              Buffer.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength, noAssert) {
                value = +value
                offset = offset | 0
                byteLength = byteLength | 0
                if (!noAssert) {
                  var maxBytes = Math.pow(2, 8 * byteLength) - 1
                  checkInt(this, value, offset, byteLength, maxBytes, 0)
                }
      
                var i = byteLength - 1
                var mul = 1
                this[offset + i] = value & 0xFF
                while (--i >= 0 && (mul *= 0x100)) {
                  this[offset + i] = (value / mul) & 0xFF
                }
      
                return offset + byteLength
              }
      
              Buffer.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
                if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value)
                this[offset] = (value & 0xff)
                return offset + 1
              }
      
              function objectWriteUInt16(buf, value, offset, littleEndian) {
                if (value < 0) value = 0xffff + value + 1
                for (var i = 0, j = Math.min(buf.length - offset, 2); i < j; ++i) {
                  buf[offset + i] = (value & (0xff << (8 * (littleEndian ? i : 1 - i)))) >>>
                    (littleEndian ? i : 1 - i) * 8
                }
              }
      
              Buffer.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  this[offset] = (value & 0xff)
                  this[offset + 1] = (value >>> 8)
                } else {
                  objectWriteUInt16(this, value, offset, true)
                }
                return offset + 2
              }
      
              Buffer.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  this[offset] = (value >>> 8)
                  this[offset + 1] = (value & 0xff)
                } else {
                  objectWriteUInt16(this, value, offset, false)
                }
                return offset + 2
              }
      
              function objectWriteUInt32(buf, value, offset, littleEndian) {
                if (value < 0) value = 0xffffffff + value + 1
                for (var i = 0, j = Math.min(buf.length - offset, 4); i < j; ++i) {
                  buf[offset + i] = (value >>> (littleEndian ? i : 3 - i) * 8) & 0xff
                }
              }
      
              Buffer.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  this[offset + 3] = (value >>> 24)
                  this[offset + 2] = (value >>> 16)
                  this[offset + 1] = (value >>> 8)
                  this[offset] = (value & 0xff)
                } else {
                  objectWriteUInt32(this, value, offset, true)
                }
                return offset + 4
              }
      
              Buffer.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  this[offset] = (value >>> 24)
                  this[offset + 1] = (value >>> 16)
                  this[offset + 2] = (value >>> 8)
                  this[offset + 3] = (value & 0xff)
                } else {
                  objectWriteUInt32(this, value, offset, false)
                }
                return offset + 4
              }
      
              Buffer.prototype.writeIntLE = function writeIntLE(value, offset, byteLength, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) {
                  var limit = Math.pow(2, 8 * byteLength - 1)
      
                  checkInt(this, value, offset, byteLength, limit - 1, -limit)
                }
      
                var i = 0
                var mul = 1
                var sub = 0
                this[offset] = value & 0xFF
                while (++i < byteLength && (mul *= 0x100)) {
                  if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
                    sub = 1
                  }
                  this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
                }
      
                return offset + byteLength
              }
      
              Buffer.prototype.writeIntBE = function writeIntBE(value, offset, byteLength, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) {
                  var limit = Math.pow(2, 8 * byteLength - 1)
      
                  checkInt(this, value, offset, byteLength, limit - 1, -limit)
                }
      
                var i = byteLength - 1
                var mul = 1
                var sub = 0
                this[offset + i] = value & 0xFF
                while (--i >= 0 && (mul *= 0x100)) {
                  if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
                    sub = 1
                  }
                  this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
                }
      
                return offset + byteLength
              }
      
              Buffer.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
                if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value)
                if (value < 0) value = 0xff + value + 1
                this[offset] = (value & 0xff)
                return offset + 1
              }
      
              Buffer.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  this[offset] = (value & 0xff)
                  this[offset + 1] = (value >>> 8)
                } else {
                  objectWriteUInt16(this, value, offset, true)
                }
                return offset + 2
              }
      
              Buffer.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  this[offset] = (value >>> 8)
                  this[offset + 1] = (value & 0xff)
                } else {
                  objectWriteUInt16(this, value, offset, false)
                }
                return offset + 2
              }
      
              Buffer.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  this[offset] = (value & 0xff)
                  this[offset + 1] = (value >>> 8)
                  this[offset + 2] = (value >>> 16)
                  this[offset + 3] = (value >>> 24)
                } else {
                  objectWriteUInt32(this, value, offset, true)
                }
                return offset + 4
              }
      
              Buffer.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
                value = +value
                offset = offset | 0
                if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
                if (value < 0) value = 0xffffffff + value + 1
                if (Buffer.TYPED_ARRAY_SUPPORT) {
                  this[offset] = (value >>> 24)
                  this[offset + 1] = (value >>> 16)
                  this[offset + 2] = (value >>> 8)
                  this[offset + 3] = (value & 0xff)
                } else {
                  objectWriteUInt32(this, value, offset, false)
                }
                return offset + 4
              }
      
              function checkIEEE754(buf, value, offset, ext, max, min) {
                if (offset + ext > buf.length) throw new RangeError('Index out of range')
                if (offset < 0) throw new RangeError('Index out of range')
              }
      
              function writeFloat(buf, value, offset, littleEndian, noAssert) {
                if (!noAssert) {
                  checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
                }
                ieee754.write(buf, value, offset, littleEndian, 23, 4)
                return offset + 4
              }
      
              Buffer.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
                return writeFloat(this, value, offset, true, noAssert)
              }
      
              Buffer.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
                return writeFloat(this, value, offset, false, noAssert)
              }
      
              function writeDouble(buf, value, offset, littleEndian, noAssert) {
                if (!noAssert) {
                  checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
                }
                ieee754.write(buf, value, offset, littleEndian, 52, 8)
                return offset + 8
              }
      
              Buffer.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
                return writeDouble(this, value, offset, true, noAssert)
              }
      
              Buffer.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
                return writeDouble(this, value, offset, false, noAssert)
              }
      
              // copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
              Buffer.prototype.copy = function copy(target, targetStart, start, end) {
                if (!start) start = 0
                if (!end && end !== 0) end = this.length
                if (targetStart >= target.length) targetStart = target.length
                if (!targetStart) targetStart = 0
                if (end > 0 && end < start) end = start
      
                // Copy 0 bytes; we're done
                if (end === start) return 0
                if (target.length === 0 || this.length === 0) return 0
      
                // Fatal error conditions
                if (targetStart < 0) {
                  throw new RangeError('targetStart out of bounds')
                }
                if (start < 0 || start >= this.length) throw new RangeError('sourceStart out of bounds')
                if (end < 0) throw new RangeError('sourceEnd out of bounds')
      
                // Are we oob?
                if (end > this.length) end = this.length
                if (target.length - targetStart < end - start) {
                  end = target.length - targetStart + start
                }
      
                var len = end - start
                var i
      
                if (this === target && start < targetStart && targetStart < end) {
                  // descending copy from end
                  for (i = len - 1; i >= 0; --i) {
                    target[i + targetStart] = this[i + start]
                  }
                } else if (len < 1000 || !Buffer.TYPED_ARRAY_SUPPORT) {
                  // ascending copy from start
                  for (i = 0; i < len; ++i) {
                    target[i + targetStart] = this[i + start]
                  }
                } else {
                  Uint8Array.prototype.set.call(
                    target,
                    this.subarray(start, start + len),
                    targetStart
                  )
                }
      
                return len
              }
      
              // Usage:
              //    buffer.fill(number[, offset[, end]])
              //    buffer.fill(buffer[, offset[, end]])
              //    buffer.fill(string[, offset[, end]][, encoding])
              Buffer.prototype.fill = function fill(val, start, end, encoding) {
                // Handle string cases:
                if (typeof val === 'string') {
                  if (typeof start === 'string') {
                    encoding = start
                    start = 0
                    end = this.length
                  } else if (typeof end === 'string') {
                    encoding = end
                    end = this.length
                  }
                  if (val.length === 1) {
                    var code = val.charCodeAt(0)
                    if (code < 256) {
                      val = code
                    }
                  }
                  if (encoding !== undefined && typeof encoding !== 'string') {
                    throw new TypeError('encoding must be a string')
                  }
                  if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
                    throw new TypeError('Unknown encoding: ' + encoding)
                  }
                } else if (typeof val === 'number') {
                  val = val & 255
                }
      
                // Invalid ranges are not set to a default, so can range check early.
                if (start < 0 || this.length < start || this.length < end) {
                  throw new RangeError('Out of range index')
                }
      
                if (end <= start) {
                  return this
                }
      
                start = start >>> 0
                end = end === undefined ? this.length : end >>> 0
      
                if (!val) val = 0
      
                var i
                if (typeof val === 'number') {
                  for (i = start; i < end; ++i) {
                    this[i] = val
                  }
                } else {
                  var bytes = Buffer.isBuffer(val)
                    ? val
                    : utf8ToBytes(new Buffer(val, encoding).toString())
                  var len = bytes.length
                  for (i = 0; i < end - start; ++i) {
                    this[i + start] = bytes[i % len]
                  }
                }
      
                return this
              }
      
              // HELPER FUNCTIONS
              // ================
      
              var INVALID_BASE64_RE = /[^+\/0-9A-Za-z-_]/g
      
              function base64clean(str) {
                // Node strips out invalid characters like \n and \t from the string, base64-js does not
                str = stringtrim(str).replace(INVALID_BASE64_RE, '')
                // Node converts strings with length < 2 to ''
                if (str.length < 2) return ''
                // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
                while (str.length % 4 !== 0) {
                  str = str + '='
                }
                return str
              }
      
              function stringtrim(str) {
                if (str.trim) return str.trim()
                return str.replace(/^\s+|\s+$/g, '')
              }
      
              function toHex(n) {
                if (n < 16) return '0' + n.toString(16)
                return n.toString(16)
              }
      
              function utf8ToBytes(string, units) {
                units = units || Infinity
                var codePoint
                var length = string.length
                var leadSurrogate = null
                var bytes = []
      
                for (var i = 0; i < length; ++i) {
                  codePoint = string.charCodeAt(i)
      
                  // is surrogate component
                  if (codePoint > 0xD7FF && codePoint < 0xE000) {
                    // last char was a lead
                    if (!leadSurrogate) {
                      // no lead yet
                      if (codePoint > 0xDBFF) {
                        // unexpected trail
                        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
                        continue
                      } else if (i + 1 === length) {
                        // unpaired lead
                        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
                        continue
                      }
      
                      // valid lead
                      leadSurrogate = codePoint
      
                      continue
                    }
      
                    // 2 leads in a row
                    if (codePoint < 0xDC00) {
                      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
                      leadSurrogate = codePoint
                      continue
                    }
      
                    // valid surrogate pair
                    codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000
                  } else if (leadSurrogate) {
                    // valid bmp char, but last char was a lead
                    if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
                  }
      
                  leadSurrogate = null
      
                  // encode utf8
                  if (codePoint < 0x80) {
                    if ((units -= 1) < 0) break
                    bytes.push(codePoint)
                  } else if (codePoint < 0x800) {
                    if ((units -= 2) < 0) break
                    bytes.push(
                      codePoint >> 0x6 | 0xC0,
                      codePoint & 0x3F | 0x80
                    )
                  } else if (codePoint < 0x10000) {
                    if ((units -= 3) < 0) break
                    bytes.push(
                      codePoint >> 0xC | 0xE0,
                      codePoint >> 0x6 & 0x3F | 0x80,
                      codePoint & 0x3F | 0x80
                    )
                  } else if (codePoint < 0x110000) {
                    if ((units -= 4) < 0) break
                    bytes.push(
                      codePoint >> 0x12 | 0xF0,
                      codePoint >> 0xC & 0x3F | 0x80,
                      codePoint >> 0x6 & 0x3F | 0x80,
                      codePoint & 0x3F | 0x80
                    )
                  } else {
                    throw new Error('Invalid code point')
                  }
                }
      
                return bytes
              }
      
              function asciiToBytes(str) {
                var byteArray = []
                for (var i = 0; i < str.length; ++i) {
                  // Node's code seems to be doing this and not & 0x7F..
                  byteArray.push(str.charCodeAt(i) & 0xFF)
                }
                return byteArray
              }
      
              function utf16leToBytes(str, units) {
                var c, hi, lo
                var byteArray = []
                for (var i = 0; i < str.length; ++i) {
                  if ((units -= 2) < 0) break
      
                  c = str.charCodeAt(i)
                  hi = c >> 8
                  lo = c % 256
                  byteArray.push(lo)
                  byteArray.push(hi)
                }
      
                return byteArray
              }
      
              function base64ToBytes(str) {
                return base64.toByteArray(base64clean(str))
              }
      
              function blitBuffer(src, dst, offset, length) {
                for (var i = 0; i < length; ++i) {
                  if ((i + offset >= dst.length) || (i >= src.length)) break
                  dst[i + offset] = src[i]
                }
                return i
              }
      
              function isnan(val) {
                return val !== val // eslint-disable-line no-self-compare
              }
      
              /* WEBPACK VAR INJECTION */
      }.call(this, __webpack_require__(/*! ./../webpack/buildin/global.js */ "./node_modules/webpack/buildin/global.js")))
      
            /***/
      }),
      
          /***/ "./node_modules/generate-function/index.js":
          /*!*************************************************!*\
            !*** ./node_modules/generate-function/index.js ***!
            \*************************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
            var util = __webpack_require__(/*! util */ "./node_modules/util/util.js")
            var isProperty = __webpack_require__(/*! is-property */ "./node_modules/is-property/is-property.js")
      
            var INDENT_START = /[\{\[]/
            var INDENT_END = /[\}\]]/
      
            // from https://mathiasbynens.be/notes/reserved-keywords
            var RESERVED = [
              'do',
              'if',
              'in',
              'for',
              'let',
              'new',
              'try',
              'var',
              'case',
              'else',
              'enum',
              'eval',
              'null',
              'this',
              'true',
              'void',
              'with',
              'await',
              'break',
              'catch',
              'class',
              'const',
              'false',
              'super',
              'throw',
              'while',
              'yield',
              'delete',
              'export',
              'import',
              'public',
              'return',
              'static',
              'switch',
              'typeof',
              'default',
              'extends',
              'finally',
              'package',
              'private',
              'continue',
              'debugger',
              'function',
              'arguments',
              'interface',
              'protected',
              'implements',
              'instanceof',
              'NaN',
              'undefined'
            ]
      
            var RESERVED_MAP = {}
      
            for (var i = 0; i < RESERVED.length; i++) {
              RESERVED_MAP[RESERVED[i]] = true
            }
      
            var isVariable = function (name) {
              return isProperty(name) && !RESERVED_MAP.hasOwnProperty(name)
            }
      
            var formats = {
              s: function (s) {
                return '' + s
              },
              d: function (d) {
                return '' + Number(d)
              },
              o: function (o) {
                return JSON.stringify(o)
              }
            }
      
            var genfun = function () {
              var lines = []
              var indent = 0
              var vars = {}
      
              var push = function (str) {
                var spaces = ''
                while (spaces.length < indent * 2) spaces += '  '
                lines.push(spaces + str)
              }
      
              var pushLine = function (line) {
                if (INDENT_END.test(line.trim()[0]) && INDENT_START.test(line[line.length - 1])) {
                  indent--
                  push(line)
                  indent++
                  return
                }
                if (INDENT_START.test(line[line.length - 1])) {
                  push(line)
                  indent++
                  return
                }
                if (INDENT_END.test(line.trim()[0])) {
                  indent--
                  push(line)
                  return
                }
      
                push(line)
              }
      
              var line = function (fmt) {
                if (!fmt) return line
      
                if (arguments.length === 1 && fmt.indexOf('\n') > -1) {
                  var lines = fmt.trim().split('\n')
                  for (var i = 0; i < lines.length; i++) {
                    pushLine(lines[i].trim())
                  }
                } else {
                  pushLine(util.format.apply(util, arguments))
                }
      
                return line
              }
      
              line.scope = {}
              line.formats = formats
      
              line.sym = function (name) {
                if (!name || !isVariable(name)) name = 'tmp'
                if (!vars[name]) vars[name] = 0
                return name + (vars[name]++ || '')
              }
      
              line.property = function (obj, name) {
                if (arguments.length === 1) {
                  name = obj
                  obj = ''
                }
      
                name = name + ''
      
                if (isProperty(name)) return (obj ? obj + '.' + name : name)
                return obj ? obj + '[' + JSON.stringify(name) + ']' : JSON.stringify(name)
              }
      
              line.toString = function () {
                return lines.join('\n')
              }
      
              line.toFunction = function (scope) {
                if (!scope) scope = {}
      
                var src = 'return (' + lines.join('\n') + ')'
      
                Object.keys(line.scope).forEach(function (key) {
                  if (!scope[key]) scope[key] = line.scope[key]
                })
      
                var keys = Object.keys(scope).map(function (key) {
                  return key
                })
      
                var vals = keys.map(function (key) {
                  return scope[key]
                })

                return Function.apply(null, keys.concat(src)).apply(null, vals)
              }
      
              if (arguments.length) line.apply(null, arguments)
      
              return line
            }
      
            genfun.formats = formats
            module.exports = genfun
      
      
            /***/
      }),
      
          /***/ "./node_modules/generate-object-property/index.js":
          /*!********************************************************!*\
            !*** ./node_modules/generate-object-property/index.js ***!
            \********************************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
            var isProperty = __webpack_require__(/*! is-property */ "./node_modules/is-property/is-property.js")
      
            var gen = function (obj, prop) {
              return isProperty(prop) ? obj + '.' + prop : obj + '[' + JSON.stringify(prop) + ']'
            }
      
            gen.valid = isProperty
            gen.property = function (prop) {
              return isProperty(prop) ? prop : JSON.stringify(prop)
            }
      
            module.exports = gen
      
      
            /***/
      }),
      
          /***/ "./node_modules/ieee754/index.js":
          /*!***************************************!*\
            !*** ./node_modules/ieee754/index.js ***!
            \***************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            exports.read = function (buffer, offset, isLE, mLen, nBytes) {
              var e, m
              var eLen = (nBytes * 8) - mLen - 1
              var eMax = (1 << eLen) - 1
              var eBias = eMax >> 1
              var nBits = -7
              var i = isLE ? (nBytes - 1) : 0
              var d = isLE ? -1 : 1
              var s = buffer[offset + i]
      
              i += d
      
              e = s & ((1 << (-nBits)) - 1)
              s >>= (-nBits)
              nBits += eLen
              for (; nBits > 0; e = (e * 256) + buffer[offset + i], i += d, nBits -= 8) { }
      
              m = e & ((1 << (-nBits)) - 1)
              e >>= (-nBits)
              nBits += mLen
              for (; nBits > 0; m = (m * 256) + buffer[offset + i], i += d, nBits -= 8) { }
      
              if (e === 0) {
                e = 1 - eBias
              } else if (e === eMax) {
                return m ? NaN : ((s ? -1 : 1) * Infinity)
              } else {
                m = m + Math.pow(2, mLen)
                e = e - eBias
              }
              return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
            }
      
            exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
              var e, m, c
              var eLen = (nBytes * 8) - mLen - 1
              var eMax = (1 << eLen) - 1
              var eBias = eMax >> 1
              var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
              var i = isLE ? 0 : (nBytes - 1)
              var d = isLE ? 1 : -1
              var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0
      
              value = Math.abs(value)
      
              if (isNaN(value) || value === Infinity) {
                m = isNaN(value) ? 1 : 0
                e = eMax
              } else {
                e = Math.floor(Math.log(value) / Math.LN2)
                if (value * (c = Math.pow(2, -e)) < 1) {
                  e--
                  c *= 2
                }
                if (e + eBias >= 1) {
                  value += rt / c
                } else {
                  value += rt * Math.pow(2, 1 - eBias)
                }
                if (value * c >= 2) {
                  e++
                  c /= 2
                }
      
                if (e + eBias >= eMax) {
                  m = 0
                  e = eMax
                } else if (e + eBias >= 1) {
                  m = ((value * c) - 1) * Math.pow(2, mLen)
                  e = e + eBias
                } else {
                  m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
                  e = 0
                }
              }
      
              for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) { }
      
              e = (e << mLen) | m
              eLen += mLen
              for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) { }
      
              buffer[offset + i - d] |= s * 128
            }
      
      
            /***/
      }),
      
          /***/ "./node_modules/is-property/is-property.js":
          /*!*************************************************!*\
            !*** ./node_modules/is-property/is-property.js ***!
            \*************************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
            "use strict";
      
            function isProperty(str) {
              return /^[$A-Z\_a-z\xaa\xb5\xba\xc0-\xd6\xd8-\xf6\xf8-\u02c1\u02c6-\u02d1\u02e0-\u02e4\u02ec\u02ee\u0370-\u0374\u0376\u0377\u037a-\u037d\u0386\u0388-\u038a\u038c\u038e-\u03a1\u03a3-\u03f5\u03f7-\u0481\u048a-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05d0-\u05ea\u05f0-\u05f2\u0620-\u064a\u066e\u066f\u0671-\u06d3\u06d5\u06e5\u06e6\u06ee\u06ef\u06fa-\u06fc\u06ff\u0710\u0712-\u072f\u074d-\u07a5\u07b1\u07ca-\u07ea\u07f4\u07f5\u07fa\u0800-\u0815\u081a\u0824\u0828\u0840-\u0858\u08a0\u08a2-\u08ac\u0904-\u0939\u093d\u0950\u0958-\u0961\u0971-\u0977\u0979-\u097f\u0985-\u098c\u098f\u0990\u0993-\u09a8\u09aa-\u09b0\u09b2\u09b6-\u09b9\u09bd\u09ce\u09dc\u09dd\u09df-\u09e1\u09f0\u09f1\u0a05-\u0a0a\u0a0f\u0a10\u0a13-\u0a28\u0a2a-\u0a30\u0a32\u0a33\u0a35\u0a36\u0a38\u0a39\u0a59-\u0a5c\u0a5e\u0a72-\u0a74\u0a85-\u0a8d\u0a8f-\u0a91\u0a93-\u0aa8\u0aaa-\u0ab0\u0ab2\u0ab3\u0ab5-\u0ab9\u0abd\u0ad0\u0ae0\u0ae1\u0b05-\u0b0c\u0b0f\u0b10\u0b13-\u0b28\u0b2a-\u0b30\u0b32\u0b33\u0b35-\u0b39\u0b3d\u0b5c\u0b5d\u0b5f-\u0b61\u0b71\u0b83\u0b85-\u0b8a\u0b8e-\u0b90\u0b92-\u0b95\u0b99\u0b9a\u0b9c\u0b9e\u0b9f\u0ba3\u0ba4\u0ba8-\u0baa\u0bae-\u0bb9\u0bd0\u0c05-\u0c0c\u0c0e-\u0c10\u0c12-\u0c28\u0c2a-\u0c33\u0c35-\u0c39\u0c3d\u0c58\u0c59\u0c60\u0c61\u0c85-\u0c8c\u0c8e-\u0c90\u0c92-\u0ca8\u0caa-\u0cb3\u0cb5-\u0cb9\u0cbd\u0cde\u0ce0\u0ce1\u0cf1\u0cf2\u0d05-\u0d0c\u0d0e-\u0d10\u0d12-\u0d3a\u0d3d\u0d4e\u0d60\u0d61\u0d7a-\u0d7f\u0d85-\u0d96\u0d9a-\u0db1\u0db3-\u0dbb\u0dbd\u0dc0-\u0dc6\u0e01-\u0e30\u0e32\u0e33\u0e40-\u0e46\u0e81\u0e82\u0e84\u0e87\u0e88\u0e8a\u0e8d\u0e94-\u0e97\u0e99-\u0e9f\u0ea1-\u0ea3\u0ea5\u0ea7\u0eaa\u0eab\u0ead-\u0eb0\u0eb2\u0eb3\u0ebd\u0ec0-\u0ec4\u0ec6\u0edc-\u0edf\u0f00\u0f40-\u0f47\u0f49-\u0f6c\u0f88-\u0f8c\u1000-\u102a\u103f\u1050-\u1055\u105a-\u105d\u1061\u1065\u1066\u106e-\u1070\u1075-\u1081\u108e\u10a0-\u10c5\u10c7\u10cd\u10d0-\u10fa\u10fc-\u1248\u124a-\u124d\u1250-\u1256\u1258\u125a-\u125d\u1260-\u1288\u128a-\u128d\u1290-\u12b0\u12b2-\u12b5\u12b8-\u12be\u12c0\u12c2-\u12c5\u12c8-\u12d6\u12d8-\u1310\u1312-\u1315\u1318-\u135a\u1380-\u138f\u13a0-\u13f4\u1401-\u166c\u166f-\u167f\u1681-\u169a\u16a0-\u16ea\u16ee-\u16f0\u1700-\u170c\u170e-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176c\u176e-\u1770\u1780-\u17b3\u17d7\u17dc\u1820-\u1877\u1880-\u18a8\u18aa\u18b0-\u18f5\u1900-\u191c\u1950-\u196d\u1970-\u1974\u1980-\u19ab\u19c1-\u19c7\u1a00-\u1a16\u1a20-\u1a54\u1aa7\u1b05-\u1b33\u1b45-\u1b4b\u1b83-\u1ba0\u1bae\u1baf\u1bba-\u1be5\u1c00-\u1c23\u1c4d-\u1c4f\u1c5a-\u1c7d\u1ce9-\u1cec\u1cee-\u1cf1\u1cf5\u1cf6\u1d00-\u1dbf\u1e00-\u1f15\u1f18-\u1f1d\u1f20-\u1f45\u1f48-\u1f4d\u1f50-\u1f57\u1f59\u1f5b\u1f5d\u1f5f-\u1f7d\u1f80-\u1fb4\u1fb6-\u1fbc\u1fbe\u1fc2-\u1fc4\u1fc6-\u1fcc\u1fd0-\u1fd3\u1fd6-\u1fdb\u1fe0-\u1fec\u1ff2-\u1ff4\u1ff6-\u1ffc\u2071\u207f\u2090-\u209c\u2102\u2107\u210a-\u2113\u2115\u2119-\u211d\u2124\u2126\u2128\u212a-\u212d\u212f-\u2139\u213c-\u213f\u2145-\u2149\u214e\u2160-\u2188\u2c00-\u2c2e\u2c30-\u2c5e\u2c60-\u2ce4\u2ceb-\u2cee\u2cf2\u2cf3\u2d00-\u2d25\u2d27\u2d2d\u2d30-\u2d67\u2d6f\u2d80-\u2d96\u2da0-\u2da6\u2da8-\u2dae\u2db0-\u2db6\u2db8-\u2dbe\u2dc0-\u2dc6\u2dc8-\u2dce\u2dd0-\u2dd6\u2dd8-\u2dde\u2e2f\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303c\u3041-\u3096\u309d-\u309f\u30a1-\u30fa\u30fc-\u30ff\u3105-\u312d\u3131-\u318e\u31a0-\u31ba\u31f0-\u31ff\u3400-\u4db5\u4e00-\u9fcc\ua000-\ua48c\ua4d0-\ua4fd\ua500-\ua60c\ua610-\ua61f\ua62a\ua62b\ua640-\ua66e\ua67f-\ua697\ua6a0-\ua6ef\ua717-\ua71f\ua722-\ua788\ua78b-\ua78e\ua790-\ua793\ua7a0-\ua7aa\ua7f8-\ua801\ua803-\ua805\ua807-\ua80a\ua80c-\ua822\ua840-\ua873\ua882-\ua8b3\ua8f2-\ua8f7\ua8fb\ua90a-\ua925\ua930-\ua946\ua960-\ua97c\ua984-\ua9b2\ua9cf\uaa00-\uaa28\uaa40-\uaa42\uaa44-\uaa4b\uaa60-\uaa76\uaa7a\uaa80-\uaaaf\uaab1\uaab5\uaab6\uaab9-\uaabd\uaac0\uaac2\uaadb-\uaadd\uaae0-\uaaea\uaaf2-\uaaf4\uab01-\uab06\uab09-\uab0e\uab11-\uab16\uab20-\uab26\uab28-\uab2e\uabc0-\uabe2\uac00-\ud7a3\ud7b0-\ud7c6\ud7cb-\ud7fb\uf900-\ufa6d\ufa70-\ufad9\ufb00-\ufb06\ufb13-\ufb17\ufb1d\ufb1f-\ufb28\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40\ufb41\ufb43\ufb44\ufb46-\ufbb1\ufbd3-\ufd3d\ufd50-\ufd8f\ufd92-\ufdc7\ufdf0-\ufdfb\ufe70-\ufe74\ufe76-\ufefc\uff21-\uff3a\uff41-\uff5a\uff66-\uffbe\uffc2-\uffc7\uffca-\uffcf\uffd2-\uffd7\uffda-\uffdc][$A-Z\_a-z\xaa\xb5\xba\xc0-\xd6\xd8-\xf6\xf8-\u02c1\u02c6-\u02d1\u02e0-\u02e4\u02ec\u02ee\u0370-\u0374\u0376\u0377\u037a-\u037d\u0386\u0388-\u038a\u038c\u038e-\u03a1\u03a3-\u03f5\u03f7-\u0481\u048a-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05d0-\u05ea\u05f0-\u05f2\u0620-\u064a\u066e\u066f\u0671-\u06d3\u06d5\u06e5\u06e6\u06ee\u06ef\u06fa-\u06fc\u06ff\u0710\u0712-\u072f\u074d-\u07a5\u07b1\u07ca-\u07ea\u07f4\u07f5\u07fa\u0800-\u0815\u081a\u0824\u0828\u0840-\u0858\u08a0\u08a2-\u08ac\u0904-\u0939\u093d\u0950\u0958-\u0961\u0971-\u0977\u0979-\u097f\u0985-\u098c\u098f\u0990\u0993-\u09a8\u09aa-\u09b0\u09b2\u09b6-\u09b9\u09bd\u09ce\u09dc\u09dd\u09df-\u09e1\u09f0\u09f1\u0a05-\u0a0a\u0a0f\u0a10\u0a13-\u0a28\u0a2a-\u0a30\u0a32\u0a33\u0a35\u0a36\u0a38\u0a39\u0a59-\u0a5c\u0a5e\u0a72-\u0a74\u0a85-\u0a8d\u0a8f-\u0a91\u0a93-\u0aa8\u0aaa-\u0ab0\u0ab2\u0ab3\u0ab5-\u0ab9\u0abd\u0ad0\u0ae0\u0ae1\u0b05-\u0b0c\u0b0f\u0b10\u0b13-\u0b28\u0b2a-\u0b30\u0b32\u0b33\u0b35-\u0b39\u0b3d\u0b5c\u0b5d\u0b5f-\u0b61\u0b71\u0b83\u0b85-\u0b8a\u0b8e-\u0b90\u0b92-\u0b95\u0b99\u0b9a\u0b9c\u0b9e\u0b9f\u0ba3\u0ba4\u0ba8-\u0baa\u0bae-\u0bb9\u0bd0\u0c05-\u0c0c\u0c0e-\u0c10\u0c12-\u0c28\u0c2a-\u0c33\u0c35-\u0c39\u0c3d\u0c58\u0c59\u0c60\u0c61\u0c85-\u0c8c\u0c8e-\u0c90\u0c92-\u0ca8\u0caa-\u0cb3\u0cb5-\u0cb9\u0cbd\u0cde\u0ce0\u0ce1\u0cf1\u0cf2\u0d05-\u0d0c\u0d0e-\u0d10\u0d12-\u0d3a\u0d3d\u0d4e\u0d60\u0d61\u0d7a-\u0d7f\u0d85-\u0d96\u0d9a-\u0db1\u0db3-\u0dbb\u0dbd\u0dc0-\u0dc6\u0e01-\u0e30\u0e32\u0e33\u0e40-\u0e46\u0e81\u0e82\u0e84\u0e87\u0e88\u0e8a\u0e8d\u0e94-\u0e97\u0e99-\u0e9f\u0ea1-\u0ea3\u0ea5\u0ea7\u0eaa\u0eab\u0ead-\u0eb0\u0eb2\u0eb3\u0ebd\u0ec0-\u0ec4\u0ec6\u0edc-\u0edf\u0f00\u0f40-\u0f47\u0f49-\u0f6c\u0f88-\u0f8c\u1000-\u102a\u103f\u1050-\u1055\u105a-\u105d\u1061\u1065\u1066\u106e-\u1070\u1075-\u1081\u108e\u10a0-\u10c5\u10c7\u10cd\u10d0-\u10fa\u10fc-\u1248\u124a-\u124d\u1250-\u1256\u1258\u125a-\u125d\u1260-\u1288\u128a-\u128d\u1290-\u12b0\u12b2-\u12b5\u12b8-\u12be\u12c0\u12c2-\u12c5\u12c8-\u12d6\u12d8-\u1310\u1312-\u1315\u1318-\u135a\u1380-\u138f\u13a0-\u13f4\u1401-\u166c\u166f-\u167f\u1681-\u169a\u16a0-\u16ea\u16ee-\u16f0\u1700-\u170c\u170e-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176c\u176e-\u1770\u1780-\u17b3\u17d7\u17dc\u1820-\u1877\u1880-\u18a8\u18aa\u18b0-\u18f5\u1900-\u191c\u1950-\u196d\u1970-\u1974\u1980-\u19ab\u19c1-\u19c7\u1a00-\u1a16\u1a20-\u1a54\u1aa7\u1b05-\u1b33\u1b45-\u1b4b\u1b83-\u1ba0\u1bae\u1baf\u1bba-\u1be5\u1c00-\u1c23\u1c4d-\u1c4f\u1c5a-\u1c7d\u1ce9-\u1cec\u1cee-\u1cf1\u1cf5\u1cf6\u1d00-\u1dbf\u1e00-\u1f15\u1f18-\u1f1d\u1f20-\u1f45\u1f48-\u1f4d\u1f50-\u1f57\u1f59\u1f5b\u1f5d\u1f5f-\u1f7d\u1f80-\u1fb4\u1fb6-\u1fbc\u1fbe\u1fc2-\u1fc4\u1fc6-\u1fcc\u1fd0-\u1fd3\u1fd6-\u1fdb\u1fe0-\u1fec\u1ff2-\u1ff4\u1ff6-\u1ffc\u2071\u207f\u2090-\u209c\u2102\u2107\u210a-\u2113\u2115\u2119-\u211d\u2124\u2126\u2128\u212a-\u212d\u212f-\u2139\u213c-\u213f\u2145-\u2149\u214e\u2160-\u2188\u2c00-\u2c2e\u2c30-\u2c5e\u2c60-\u2ce4\u2ceb-\u2cee\u2cf2\u2cf3\u2d00-\u2d25\u2d27\u2d2d\u2d30-\u2d67\u2d6f\u2d80-\u2d96\u2da0-\u2da6\u2da8-\u2dae\u2db0-\u2db6\u2db8-\u2dbe\u2dc0-\u2dc6\u2dc8-\u2dce\u2dd0-\u2dd6\u2dd8-\u2dde\u2e2f\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303c\u3041-\u3096\u309d-\u309f\u30a1-\u30fa\u30fc-\u30ff\u3105-\u312d\u3131-\u318e\u31a0-\u31ba\u31f0-\u31ff\u3400-\u4db5\u4e00-\u9fcc\ua000-\ua48c\ua4d0-\ua4fd\ua500-\ua60c\ua610-\ua61f\ua62a\ua62b\ua640-\ua66e\ua67f-\ua697\ua6a0-\ua6ef\ua717-\ua71f\ua722-\ua788\ua78b-\ua78e\ua790-\ua793\ua7a0-\ua7aa\ua7f8-\ua801\ua803-\ua805\ua807-\ua80a\ua80c-\ua822\ua840-\ua873\ua882-\ua8b3\ua8f2-\ua8f7\ua8fb\ua90a-\ua925\ua930-\ua946\ua960-\ua97c\ua984-\ua9b2\ua9cf\uaa00-\uaa28\uaa40-\uaa42\uaa44-\uaa4b\uaa60-\uaa76\uaa7a\uaa80-\uaaaf\uaab1\uaab5\uaab6\uaab9-\uaabd\uaac0\uaac2\uaadb-\uaadd\uaae0-\uaaea\uaaf2-\uaaf4\uab01-\uab06\uab09-\uab0e\uab11-\uab16\uab20-\uab26\uab28-\uab2e\uabc0-\uabe2\uac00-\ud7a3\ud7b0-\ud7c6\ud7cb-\ud7fb\uf900-\ufa6d\ufa70-\ufad9\ufb00-\ufb06\ufb13-\ufb17\ufb1d\ufb1f-\ufb28\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40\ufb41\ufb43\ufb44\ufb46-\ufbb1\ufbd3-\ufd3d\ufd50-\ufd8f\ufd92-\ufdc7\ufdf0-\ufdfb\ufe70-\ufe74\ufe76-\ufefc\uff21-\uff3a\uff41-\uff5a\uff66-\uffbe\uffc2-\uffc7\uffca-\uffcf\uffd2-\uffd7\uffda-\uffdc0-9\u0300-\u036f\u0483-\u0487\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7\u0610-\u061a\u064b-\u0669\u0670\u06d6-\u06dc\u06df-\u06e4\u06e7\u06e8\u06ea-\u06ed\u06f0-\u06f9\u0711\u0730-\u074a\u07a6-\u07b0\u07c0-\u07c9\u07eb-\u07f3\u0816-\u0819\u081b-\u0823\u0825-\u0827\u0829-\u082d\u0859-\u085b\u08e4-\u08fe\u0900-\u0903\u093a-\u093c\u093e-\u094f\u0951-\u0957\u0962\u0963\u0966-\u096f\u0981-\u0983\u09bc\u09be-\u09c4\u09c7\u09c8\u09cb-\u09cd\u09d7\u09e2\u09e3\u09e6-\u09ef\u0a01-\u0a03\u0a3c\u0a3e-\u0a42\u0a47\u0a48\u0a4b-\u0a4d\u0a51\u0a66-\u0a71\u0a75\u0a81-\u0a83\u0abc\u0abe-\u0ac5\u0ac7-\u0ac9\u0acb-\u0acd\u0ae2\u0ae3\u0ae6-\u0aef\u0b01-\u0b03\u0b3c\u0b3e-\u0b44\u0b47\u0b48\u0b4b-\u0b4d\u0b56\u0b57\u0b62\u0b63\u0b66-\u0b6f\u0b82\u0bbe-\u0bc2\u0bc6-\u0bc8\u0bca-\u0bcd\u0bd7\u0be6-\u0bef\u0c01-\u0c03\u0c3e-\u0c44\u0c46-\u0c48\u0c4a-\u0c4d\u0c55\u0c56\u0c62\u0c63\u0c66-\u0c6f\u0c82\u0c83\u0cbc\u0cbe-\u0cc4\u0cc6-\u0cc8\u0cca-\u0ccd\u0cd5\u0cd6\u0ce2\u0ce3\u0ce6-\u0cef\u0d02\u0d03\u0d3e-\u0d44\u0d46-\u0d48\u0d4a-\u0d4d\u0d57\u0d62\u0d63\u0d66-\u0d6f\u0d82\u0d83\u0dca\u0dcf-\u0dd4\u0dd6\u0dd8-\u0ddf\u0df2\u0df3\u0e31\u0e34-\u0e3a\u0e47-\u0e4e\u0e50-\u0e59\u0eb1\u0eb4-\u0eb9\u0ebb\u0ebc\u0ec8-\u0ecd\u0ed0-\u0ed9\u0f18\u0f19\u0f20-\u0f29\u0f35\u0f37\u0f39\u0f3e\u0f3f\u0f71-\u0f84\u0f86\u0f87\u0f8d-\u0f97\u0f99-\u0fbc\u0fc6\u102b-\u103e\u1040-\u1049\u1056-\u1059\u105e-\u1060\u1062-\u1064\u1067-\u106d\u1071-\u1074\u1082-\u108d\u108f-\u109d\u135d-\u135f\u1712-\u1714\u1732-\u1734\u1752\u1753\u1772\u1773\u17b4-\u17d3\u17dd\u17e0-\u17e9\u180b-\u180d\u1810-\u1819\u18a9\u1920-\u192b\u1930-\u193b\u1946-\u194f\u19b0-\u19c0\u19c8\u19c9\u19d0-\u19d9\u1a17-\u1a1b\u1a55-\u1a5e\u1a60-\u1a7c\u1a7f-\u1a89\u1a90-\u1a99\u1b00-\u1b04\u1b34-\u1b44\u1b50-\u1b59\u1b6b-\u1b73\u1b80-\u1b82\u1ba1-\u1bad\u1bb0-\u1bb9\u1be6-\u1bf3\u1c24-\u1c37\u1c40-\u1c49\u1c50-\u1c59\u1cd0-\u1cd2\u1cd4-\u1ce8\u1ced\u1cf2-\u1cf4\u1dc0-\u1de6\u1dfc-\u1dff\u200c\u200d\u203f\u2040\u2054\u20d0-\u20dc\u20e1\u20e5-\u20f0\u2cef-\u2cf1\u2d7f\u2de0-\u2dff\u302a-\u302f\u3099\u309a\ua620-\ua629\ua66f\ua674-\ua67d\ua69f\ua6f0\ua6f1\ua802\ua806\ua80b\ua823-\ua827\ua880\ua881\ua8b4-\ua8c4\ua8d0-\ua8d9\ua8e0-\ua8f1\ua900-\ua909\ua926-\ua92d\ua947-\ua953\ua980-\ua983\ua9b3-\ua9c0\ua9d0-\ua9d9\uaa29-\uaa36\uaa43\uaa4c\uaa4d\uaa50-\uaa59\uaa7b\uaab0\uaab2-\uaab4\uaab7\uaab8\uaabe\uaabf\uaac1\uaaeb-\uaaef\uaaf5\uaaf6\uabe3-\uabea\uabec\uabed\uabf0-\uabf9\ufb1e\ufe00-\ufe0f\ufe20-\ufe26\ufe33\ufe34\ufe4d-\ufe4f\uff10-\uff19\uff3f]*$/.test(str)
            }
            module.exports = isProperty
      
            /***/
      }),
      
          /***/ "./node_modules/isarray/index.js":
          /*!***************************************!*\
            !*** ./node_modules/isarray/index.js ***!
            \***************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            var toString = {}.toString;
      
            module.exports = Array.isArray || function (arr) {
              return toString.call(arr) == '[object Array]';
            };
      
      
            /***/
      }),
      
          /***/ "./node_modules/os-browserify/browser.js":
          /*!***********************************************!*\
            !*** ./node_modules/os-browserify/browser.js ***!
            \***********************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            exports.endianness = function () { return 'LE' };
      
            exports.hostname = function () {
              if (typeof location !== 'undefined') {
                return location.hostname
              }
              else return '';
            };
      
            exports.loadavg = function () { return [] };
      
            exports.uptime = function () { return 0 };
      
            exports.freemem = function () {
              return Number.MAX_VALUE;
            };
      
            exports.totalmem = function () {
              return Number.MAX_VALUE;
            };
      
            exports.cpus = function () { return [] };
      
            exports.type = function () { return 'Browser' };
      
            exports.release = function () {
              if (typeof navigator !== 'undefined') {
                return navigator.appVersion;
              }
              return '';
            };
      
            exports.networkInterfaces
              = exports.getNetworkInterfaces
              = function () { return {} };
      
            exports.arch = function () { return 'javascript' };
      
            exports.platform = function () { return 'browser' };
      
            exports.tmpdir = exports.tmpDir = function () {
              return '/tmp';
            };
      
            exports.EOL = '\n';
      
            exports.homedir = function () {
              return '/'
            };
      
      
            /***/
      }),
      
          /***/ "./node_modules/process/browser.js":
          /*!*****************************************!*\
            !*** ./node_modules/process/browser.js ***!
            \*****************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            // shim for using process in browser
            var process = module.exports = {};
      
            // cached from whatever global is present so that test runners that stub it
            // don't break things.  But we need to wrap it in a try catch in case it is
            // wrapped in strict mode code which doesn't define any globals.  It's inside a
            // function because try/catches deoptimize in certain engines.
      
            var cachedSetTimeout;
            var cachedClearTimeout;
      
            function defaultSetTimout() {
              throw new Error('setTimeout has not been defined');
            }
            function defaultClearTimeout() {
              throw new Error('clearTimeout has not been defined');
            }
            (function () {
              try {
                if (typeof setTimeout === 'function') {
                  cachedSetTimeout = setTimeout;
                } else {
                  cachedSetTimeout = defaultSetTimout;
                }
              } catch (e) {
                cachedSetTimeout = defaultSetTimout;
              }
              try {
                if (typeof clearTimeout === 'function') {
                  cachedClearTimeout = clearTimeout;
                } else {
                  cachedClearTimeout = defaultClearTimeout;
                }
              } catch (e) {
                cachedClearTimeout = defaultClearTimeout;
              }
            }())
            function runTimeout(fun) {
              if (cachedSetTimeout === setTimeout) {
                //normal enviroments in sane situations
                return setTimeout(fun, 0);
              }
              // if setTimeout wasn't available but was latter defined
              if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
                cachedSetTimeout = setTimeout;
                return setTimeout(fun, 0);
              }
              try {
                // when when somebody has screwed with setTimeout but no I.E. maddness
                return cachedSetTimeout(fun, 0);
              } catch (e) {
                try {
                  // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
                  return cachedSetTimeout.call(null, fun, 0);
                } catch (e) {
                  // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
                  return cachedSetTimeout.call(this, fun, 0);
                }
              }
      
      
            }
            function runClearTimeout(marker) {
              if (cachedClearTimeout === clearTimeout) {
                //normal enviroments in sane situations
                return clearTimeout(marker);
              }
              // if clearTimeout wasn't available but was latter defined
              if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
                cachedClearTimeout = clearTimeout;
                return clearTimeout(marker);
              }
              try {
                // when when somebody has screwed with setTimeout but no I.E. maddness
                return cachedClearTimeout(marker);
              } catch (e) {
                try {
                  // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
                  return cachedClearTimeout.call(null, marker);
                } catch (e) {
                  // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
                  // Some versions of I.E. have different rules for clearTimeout vs setTimeout
                  return cachedClearTimeout.call(this, marker);
                }
              }
      
      
      
            }
            var queue = [];
            var draining = false;
            var currentQueue;
            var queueIndex = -1;
      
            function cleanUpNextTick() {
              if (!draining || !currentQueue) {
                return;
              }
              draining = false;
              if (currentQueue.length) {
                queue = currentQueue.concat(queue);
              } else {
                queueIndex = -1;
              }
              if (queue.length) {
                drainQueue();
              }
            }
      
            function drainQueue() {
              if (draining) {
                return;
              }
              var timeout = runTimeout(cleanUpNextTick);
              draining = true;
      
              var len = queue.length;
              while (len) {
                currentQueue = queue;
                queue = [];
                while (++queueIndex < len) {
                  if (currentQueue) {
                    currentQueue[queueIndex].run();
                  }
                }
                queueIndex = -1;
                len = queue.length;
              }
              currentQueue = null;
              draining = false;
              runClearTimeout(timeout);
            }
      
            process.nextTick = function (fun) {
              var args = new Array(arguments.length - 1);
              if (arguments.length > 1) {
                for (var i = 1; i < arguments.length; i++) {
                  args[i - 1] = arguments[i];
                }
              }
              queue.push(new Item(fun, args));
              if (queue.length === 1 && !draining) {
                runTimeout(drainQueue);
              }
            };
      
            // v8 likes predictible objects
            function Item(fun, array) {
              this.fun = fun;
              this.array = array;
            }
            Item.prototype.run = function () {
              this.fun.apply(null, this.array);
            };
            process.title = 'browser';
            process.browser = true;
            process.env = {};
            process.argv = [];
            process.version = ''; // empty string to avoid regexp issues
            process.versions = {};
      
            function noop() { }
      
            process.on = noop;
            process.addListener = noop;
            process.once = noop;
            process.off = noop;
            process.removeListener = noop;
            process.removeAllListeners = noop;
            process.emit = noop;
            process.prependListener = noop;
            process.prependOnceListener = noop;
      
            process.listeners = function (name) { return [] }
      
            process.binding = function (name) {
              throw new Error('process.binding is not supported');
            };
      
            process.cwd = function () { return '/' };
            process.chdir = function (dir) {
              throw new Error('process.chdir is not supported');
            };
            process.umask = function () { return 0; };
      
      
            /***/
      }),
      
          /***/ "./node_modules/protocol-buffers-encodings/index.js":
          /*!**********************************************************!*\
            !*** ./node_modules/protocol-buffers-encodings/index.js ***!
            \**********************************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
          /* WEBPACK VAR INJECTION */(function (Buffer) {
              var varint = __webpack_require__(/*! varint */ "./node_modules/varint/index.js")
              var svarint = __webpack_require__(/*! signed-varint */ "./node_modules/signed-varint/index.js")
      
              exports.make = encoder
      
              exports.name = function (enc) {
                var keys = Object.keys(exports)
                for (var i = 0; i < keys.length; i++) {
                  if (exports[keys[i]] === enc) return keys[i]
                }
                return null
              }
      
              exports.skip = function (type, buffer, offset) {
                switch (type) {
                  case 0:
                    varint.decode(buffer, offset)
                    return offset + varint.decode.bytes
      
                  case 1:
                    return offset + 8
      
                  case 2:
                    var len = varint.decode(buffer, offset)
                    return offset + varint.decode.bytes + len
      
                  case 3:
                  case 4:
                    throw new Error('Groups are not supported')
      
                  case 5:
                    return offset + 4
                }
      
                throw new Error('Unknown wire type: ' + type)
              }
      
              exports.bytes = encoder(2,
                function encode(val, buffer, offset) {
                  var oldOffset = offset
                  var len = bufferLength(val)
      
                  varint.encode(len, buffer, offset)
                  offset += varint.encode.bytes
      
                  if (Buffer.isBuffer(val)) val.copy(buffer, offset)
                  else buffer.write(val, offset, len)
                  offset += len
      
                  encode.bytes = offset - oldOffset
                  return buffer
                },
                function decode(buffer, offset) {
                  var oldOffset = offset
      
                  var len = varint.decode(buffer, offset)
                  offset += varint.decode.bytes
      
                  var val = buffer.slice(offset, offset + len)
                  offset += val.length
      
                  decode.bytes = offset - oldOffset
                  return val
                },
                function encodingLength(val) {
                  var len = bufferLength(val)
                  return varint.encodingLength(len) + len
                }
              )
      
              exports.string = encoder(2,
                function encode(val, buffer, offset) {
                  var oldOffset = offset
                  var len = Buffer.byteLength(val)
      
                  varint.encode(len, buffer, offset, 'utf-8')
                  offset += varint.encode.bytes
      
                  buffer.write(val, offset, len)
                  offset += len
      
                  encode.bytes = offset - oldOffset
                  return buffer
                },
                function decode(buffer, offset) {
                  var oldOffset = offset
      
                  var len = varint.decode(buffer, offset)
                  offset += varint.decode.bytes
      
                  var val = buffer.toString('utf-8', offset, offset + len)
                  offset += len
      
                  decode.bytes = offset - oldOffset
                  return val
                },
                function encodingLength(val) {
                  var len = Buffer.byteLength(val)
                  return varint.encodingLength(len) + len
                }
              )
      
              exports.bool = encoder(0,
                function encode(val, buffer, offset) {
                  buffer[offset] = val ? 1 : 0
                  encode.bytes = 1
                  return buffer
                },
                function decode(buffer, offset) {
                  var bool = buffer[offset] > 0
                  decode.bytes = 1
                  return bool
                },
                function encodingLength() {
                  return 1
                }
              )
      
              exports.int32 = encoder(0,
                function encode(val, buffer, offset) {
                  varint.encode(val < 0 ? val + 4294967296 : val, buffer, offset)
                  encode.bytes = varint.encode.bytes
                  return buffer
                },
                function decode(buffer, offset) {
                  var val = varint.decode(buffer, offset)
                  decode.bytes = varint.decode.bytes
                  return val > 2147483647 ? val - 4294967296 : val
                },
                function encodingLength(val) {
                  return varint.encodingLength(val < 0 ? val + 4294967296 : val)
                }
              )
      
              exports.int64 = encoder(0,
                function encode(val, buffer, offset) {
                  if (val < 0) {
                    var last = offset + 9
                    varint.encode(val * -1, buffer, offset)
                    offset += varint.encode.bytes - 1
                    buffer[offset] = buffer[offset] | 0x80
                    while (offset < last - 1) {
                      offset++
                      buffer[offset] = 0xff
                    }
                    buffer[last] = 0x01
                    encode.bytes = 10
                  } else {
                    varint.encode(val, buffer, offset)
                    encode.bytes = varint.encode.bytes
                  }
                  return buffer
                },
                function decode(buffer, offset) {
                  var val = varint.decode(buffer, offset)
                  if (val >= Math.pow(2, 63)) {
                    var limit = 9
                    while (buffer[offset + limit - 1] === 0xff) limit--
                    limit = limit || 9
                    var subset = Buffer.allocUnsafe(limit)
                    buffer.copy(subset, 0, offset, offset + limit)
                    subset[limit - 1] = subset[limit - 1] & 0x7f
                    val = -1 * varint.decode(subset, 0)
                    decode.bytes = 10
                  } else {
                    decode.bytes = varint.decode.bytes
                  }
                  return val
                },
                function encodingLength(val) {
                  return val < 0 ? 10 : varint.encodingLength(val)
                }
              )
      
              exports.sint32 =
                exports.sint64 = encoder(0,
                  svarint.encode,
                  svarint.decode,
                  svarint.encodingLength
                )
      
              exports.uint32 =
                exports.uint64 =
                exports.enum =
                exports.varint = encoder(0,
                  varint.encode,
                  varint.decode,
                  varint.encodingLength
                )
      
              // we cannot represent these in javascript so we just use buffers
              exports.fixed64 =
                exports.sfixed64 = encoder(1,
                  function encode(val, buffer, offset) {
                    val.copy(buffer, offset)
                    encode.bytes = 8
                    return buffer
                  },
                  function decode(buffer, offset) {
                    var val = buffer.slice(offset, offset + 8)
                    decode.bytes = 8
                    return val
                  },
                  function encodingLength() {
                    return 8
                  }
                )
      
              exports.double = encoder(1,
                function encode(val, buffer, offset) {
                  buffer.writeDoubleLE(val, offset)
                  encode.bytes = 8
                  return buffer
                },
                function decode(buffer, offset) {
                  var val = buffer.readDoubleLE(offset)
                  decode.bytes = 8
                  return val
                },
                function encodingLength() {
                  return 8
                }
              )
      
              exports.fixed32 = encoder(5,
                function encode(val, buffer, offset) {
                  buffer.writeUInt32LE(val, offset)
                  encode.bytes = 4
                  return buffer
                },
                function decode(buffer, offset) {
                  var val = buffer.readUInt32LE(offset)
                  decode.bytes = 4
                  return val
                },
                function encodingLength() {
                  return 4
                }
              )
      
              exports.sfixed32 = encoder(5,
                function encode(val, buffer, offset) {
                  buffer.writeInt32LE(val, offset)
                  encode.bytes = 4
                  return buffer
                },
                function decode(buffer, offset) {
                  var val = buffer.readInt32LE(offset)
                  decode.bytes = 4
                  return val
                },
                function encodingLength() {
                  return 4
                }
              )
      
              exports.float = encoder(5,
                function encode(val, buffer, offset) {
                  buffer.writeFloatLE(val, offset)
                  encode.bytes = 4
                  return buffer
                },
                function decode(buffer, offset) {
                  var val = buffer.readFloatLE(offset)
                  decode.bytes = 4
                  return val
                },
                function encodingLength() {
                  return 4
                }
              )
      
              function encoder(type, encode, decode, encodingLength) {
                encode.bytes = decode.bytes = 0
      
                return {
                  type: type,
                  encode: encode,
                  decode: decode,
                  encodingLength: encodingLength
                }
              }
      
              function bufferLength(val) {
                return Buffer.isBuffer(val) ? val.length : Buffer.byteLength(val)
              }
      
              /* WEBPACK VAR INJECTION */
      }.call(this, __webpack_require__(/*! ./../buffer/index.js */ "./node_modules/buffer/index.js").Buffer))
      
            /***/
      }),
      
          /***/ "./node_modules/protocol-buffers-schema/index.js":
          /*!*******************************************************!*\
            !*** ./node_modules/protocol-buffers-schema/index.js ***!
            \*******************************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
            var parse = __webpack_require__(/*! ./parse */ "./node_modules/protocol-buffers-schema/parse.js")
            var stringify = __webpack_require__(/*! ./stringify */ "./node_modules/protocol-buffers-schema/stringify.js")
      
            module.exports = parse
            module.exports.parse = parse
            module.exports.stringify = stringify
      
      
            /***/
      }),
      
          /***/ "./node_modules/protocol-buffers-schema/parse.js":
          /*!*******************************************************!*\
            !*** ./node_modules/protocol-buffers-schema/parse.js ***!
            \*******************************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
            var tokenize = __webpack_require__(/*! ./tokenize */ "./node_modules/protocol-buffers-schema/tokenize.js")
            var MAX_RANGE = 0x1FFFFFFF
      
            // "Only repeated fields of primitive numeric types (types which use the varint, 32-bit, or 64-bit wire types) can be declared "packed"."
            // https://developers.google.com/protocol-buffers/docs/encoding#optional
            var PACKABLE_TYPES = [
              // varint wire types
              'int32', 'int64', 'uint32', 'uint64', 'sint32', 'sint64', 'bool',
              // + ENUMS
              // 64-bit wire types
              'fixed64', 'sfixed64', 'double',
              // 32-bit wire types
              'fixed32', 'sfixed32', 'float'
            ]
      
            var onfieldoptions = function (tokens) {
              var opts = {}
      
              while (tokens.length) {
                switch (tokens[0]) {
                  case '[':
                  case ',':
                    tokens.shift()
                    var name = tokens.shift()
                    if (name === '(') { // handling [(A) = B]
                      name = tokens.shift()
                      tokens.shift() // remove the end of bracket
                    }
                    if (tokens[0] !== '=') throw new Error('Unexpected token in field options: ' + tokens[0])
                    tokens.shift()
                    if (tokens[0] === ']') throw new Error('Unexpected ] in field option')
                    opts[name] = tokens.shift()
                    break
                  case ']':
                    tokens.shift()
                    return opts
      
                  default:
                    throw new Error('Unexpected token in field options: ' + tokens[0])
                }
              }
      
              throw new Error('No closing tag for field options')
            }
      
            var onfield = function (tokens) {
              var field = {
                name: null,
                type: null,
                tag: -1,
                map: null,
                oneof: null,
                required: false,
                repeated: false,
                options: {}
              }
      
              while (tokens.length) {
                switch (tokens[0]) {
                  case '=':
                    tokens.shift()
                    field.tag = Number(tokens.shift())
                    break
      
                  case 'map':
                    field.type = 'map'
                    field.map = { from: null, to: null }
                    tokens.shift()
                    if (tokens[0] !== '<') throw new Error('Unexpected token in map type: ' + tokens[0])
                    tokens.shift()
                    field.map.from = tokens.shift()
                    if (tokens[0] !== ',') throw new Error('Unexpected token in map type: ' + tokens[0])
                    tokens.shift()
                    field.map.to = tokens.shift()
                    if (tokens[0] !== '>') throw new Error('Unexpected token in map type: ' + tokens[0])
                    tokens.shift()
                    field.name = tokens.shift()
                    break
      
                  case 'repeated':
                  case 'required':
                  case 'optional':
                    var t = tokens.shift()
                    field.required = t === 'required'
                    field.repeated = t === 'repeated'
                    field.type = tokens.shift()
                    field.name = tokens.shift()
                    break
      
                  case '[':
                    field.options = onfieldoptions(tokens)
                    break
      
                  case ';':
                    if (field.name === null) throw new Error('Missing field name')
                    if (field.type === null) throw new Error('Missing type in message field: ' + field.name)
                    if (field.tag === -1) throw new Error('Missing tag number in message field: ' + field.name)
                    tokens.shift()
                    return field
      
                  default:
                    throw new Error('Unexpected token in message field: ' + tokens[0])
                }
              }
      
              throw new Error('No ; found for message field')
            }
      
            var onmessagebody = function (tokens) {
              var body = {
                enums: [],
                options: {},
                messages: [],
                fields: [],
                extends: [],
                extensions: null
              }
      
              while (tokens.length) {
                switch (tokens[0]) {
                  case 'map':
                  case 'repeated':
                  case 'optional':
                  case 'required':
                    body.fields.push(onfield(tokens))
                    break
      
                  case 'enum':
                    body.enums.push(onenum(tokens))
                    break
      
                  case 'message':
                    body.messages.push(onmessage(tokens))
                    break
      
                  case 'extensions':
                    body.extensions = onextensions(tokens)
                    break
      
                  case 'oneof':
                    tokens.shift()
                    var name = tokens.shift()
                    if (tokens[0] !== '{') throw new Error('Unexpected token in oneof: ' + tokens[0])
                    tokens.shift()
                    while (tokens[0] !== '}') {
                      tokens.unshift('optional')
                      var field = onfield(tokens)
                      field.oneof = name
                      body.fields.push(field)
                    }
                    tokens.shift()
                    break
      
                  case 'extend':
                    body.extends.push(onextend(tokens))
                    break
      
                  case ';':
                    tokens.shift()
                    break
      
                  case 'reserved':
                    tokens.shift()
                    while (tokens[0] !== ';') {
                      tokens.shift()
                    }
                    break
      
                  case 'option':
                    var opt = onoption(tokens)
                    if (body.options[opt.name] !== undefined) throw new Error('Duplicate option ' + opt.name)
                    body.options[opt.name] = opt.value
                    break
      
                  default:
                    // proto3 does not require the use of optional/required, assumed as optional
                    // "singular: a well-formed message can have zero or one of this field (but not more than one)."
                    // https://developers.google.com/protocol-buffers/docs/proto3#specifying-field-rules
                    tokens.unshift('optional')
                    body.fields.push(onfield(tokens))
                }
              }
      
              return body
            }
      
            var onextend = function (tokens) {
              var out = {
                name: tokens[1],
                message: onmessage(tokens)
              }
              return out
            }
      
            var onextensions = function (tokens) {
              tokens.shift()
              var from = Number(tokens.shift())
              if (isNaN(from)) throw new Error('Invalid from in extensions definition')
              if (tokens.shift() !== 'to') throw new Error("Expected keyword 'to' in extensions definition")
              var to = tokens.shift()
              if (to === 'max') to = MAX_RANGE
              to = Number(to)
              if (isNaN(to)) throw new Error('Invalid to in extensions definition')
              if (tokens.shift() !== ';') throw new Error('Missing ; in extensions definition')
              return { from: from, to: to }
            }
            var onmessage = function (tokens) {
              tokens.shift()
      
              var lvl = 1
              var body = []
              var msg = {
                name: tokens.shift(),
                options: {},
                enums: [],
                extends: [],
                messages: [],
                fields: []
              }
      
              if (tokens[0] !== '{') throw new Error('Expected { but found ' + tokens[0])
              tokens.shift()
      
              while (tokens.length) {
                if (tokens[0] === '{') lvl++
                else if (tokens[0] === '}') lvl--
      
                if (!lvl) {
                  tokens.shift()
                  body = onmessagebody(body)
                  msg.enums = body.enums
                  msg.messages = body.messages
                  msg.fields = body.fields
                  msg.extends = body.extends
                  msg.extensions = body.extensions
                  msg.options = body.options
                  return msg
                }
      
                body.push(tokens.shift())
              }
      
              if (lvl) throw new Error('No closing tag for message')
            }
      
            var onpackagename = function (tokens) {
              tokens.shift()
              var name = tokens.shift()
              if (tokens[0] !== ';') throw new Error('Expected ; but found ' + tokens[0])
              tokens.shift()
              return name
            }
      
            var onsyntaxversion = function (tokens) {
              tokens.shift()
      
              if (tokens[0] !== '=') throw new Error('Expected = but found ' + tokens[0])
              tokens.shift()
      
              var version = tokens.shift()
              switch (version) {
                case '"proto2"':
                  version = 2
                  break
      
                case '"proto3"':
                  version = 3
                  break
      
                default:
                  throw new Error('Expected protobuf syntax version but found ' + version)
              }
      
              if (tokens[0] !== ';') throw new Error('Expected ; but found ' + tokens[0])
              tokens.shift()
      
              return version
            }
      
            var onenumvalue = function (tokens) {
              if (tokens.length < 4) throw new Error('Invalid enum value: ' + tokens.slice(0, 3).join(' '))
              if (tokens[1] !== '=') throw new Error('Expected = but found ' + tokens[1])
              if (tokens[3] !== ';' && tokens[3] !== '[') throw new Error('Expected ; or [ but found ' + tokens[1])
      
              var name = tokens.shift()
              tokens.shift()
              var val = {
                value: null,
                options: {}
              }
              val.value = Number(tokens.shift())
              if (tokens[0] === '[') {
                val.options = onfieldoptions(tokens)
              }
              tokens.shift() // expecting the semicolon here
      
              return {
                name: name,
                val: val
              }
            }
      
            var onenum = function (tokens) {
              tokens.shift()
              var options = {}
              var e = {
                name: tokens.shift(),
                values: {},
                options: {}
              }
      
              if (tokens[0] !== '{') throw new Error('Expected { but found ' + tokens[0])
              tokens.shift()
      
              while (tokens.length) {
                if (tokens[0] === '}') {
                  tokens.shift()
                  // there goes optional semicolon after the enclosing "}"
                  if (tokens[0] === ';') tokens.shift()
                  return e
                }
                if (tokens[0] === 'option') {
                  options = onoption(tokens)
                  e.options[options.name] = options.value
                  continue
                }
                var val = onenumvalue(tokens)
                e.values[val.name] = val.val
              }
      
              throw new Error('No closing tag for enum')
            }
      
            var onoption = function (tokens) {
              var name = null
              var value = null
      
              var parse = function (value) {
                if (value === 'true') return true
                if (value === 'false') return false
                return value.replace(/^"+|"+$/gm, '')
              }
      
              while (tokens.length) {
                if (tokens[0] === ';') {
                  tokens.shift()
                  return { name: name, value: value }
                }
                switch (tokens[0]) {
                  case 'option':
                    tokens.shift()
      
                    var hasBracket = tokens[0] === '('
                    if (hasBracket) tokens.shift()
      
                    name = tokens.shift()
      
                    if (hasBracket) {
                      if (tokens[0] !== ')') throw new Error('Expected ) but found ' + tokens[0])
                      tokens.shift()
                    }
      
                    if (tokens[0][0] === '.') {
                      name += tokens.shift()
                    }
      
                    break
      
                  case '=':
                    tokens.shift()
                    if (name === null) throw new Error('Expected key for option with value: ' + tokens[0])
                    value = parse(tokens.shift())
      
                    if (name === 'optimize_for' && !/^(SPEED|CODE_SIZE|LITE_RUNTIME)$/.test(value)) {
                      throw new Error('Unexpected value for option optimize_for: ' + value)
                    } else if (value === '{') {
                      // option foo = {bar: baz}
                      value = onoptionMap(tokens)
                    }
                    break
      
                  default:
                    throw new Error('Unexpected token in option: ' + tokens[0])
                }
              }
            }
      
            var onoptionMap = function (tokens) {
              var parse = function (value) {
                if (value === 'true') return true
                if (value === 'false') return false
                return value.replace(/^"+|"+$/gm, '')
              }
      
              var map = {}
      
              while (tokens.length) {
                if (tokens[0] === '}') {
                  tokens.shift()
                  return map
                }
      
                var hasBracket = tokens[0] === '('
                if (hasBracket) tokens.shift()
      
                var key = tokens.shift()
                if (hasBracket) {
                  if (tokens[0] !== ')') throw new Error('Expected ) but found ' + tokens[0])
                  tokens.shift()
                }
      
                var value = null
      
                switch (tokens[0]) {
                  case ':':
                    if (map[key] !== undefined) throw new Error('Duplicate option map key ' + key)
      
                    tokens.shift()
      
                    value = parse(tokens.shift())
      
                    if (value === '{') {
                      // option foo = {bar: baz}
                      value = onoptionMap(tokens)
                    }
      
                    map[key] = value
      
                    if (tokens[0] === ';') {
                      tokens.shift()
                    }
                    break
      
                  case '{':
                    tokens.shift()
                    value = onoptionMap(tokens)
      
                    if (map[key] === undefined) map[key] = []
                    if (!Array.isArray(map[key])) throw new Error('Duplicate option map key ' + key)
      
                    map[key].push(value)
                    break
      
                  default:
                    throw new Error('Unexpected token in option map: ' + tokens[0])
                }
              }
      
              throw new Error('No closing tag for option map')
            }
      
            var onimport = function (tokens) {
              tokens.shift()
              var file = tokens.shift().replace(/^"+|"+$/gm, '')
      
              if (tokens[0] !== ';') throw new Error('Unexpected token: ' + tokens[0] + '. Expected ";"')
      
              tokens.shift()
              return file
            }
      
            var onservice = function (tokens) {
              tokens.shift()
      
              var service = {
                name: tokens.shift(),
                methods: [],
                options: {}
              }
      
              if (tokens[0] !== '{') throw new Error('Expected { but found ' + tokens[0])
              tokens.shift()
      
              while (tokens.length) {
                if (tokens[0] === '}') {
                  tokens.shift()
                  // there goes optional semicolon after the enclosing "}"
                  if (tokens[0] === ';') tokens.shift()
                  return service
                }
      
                switch (tokens[0]) {
                  case 'option':
                    var opt = onoption(tokens)
                    if (service.options[opt.name] !== undefined) throw new Error('Duplicate option ' + opt.name)
                    service.options[opt.name] = opt.value
                    break
                  case 'rpc':
                    service.methods.push(onrpc(tokens))
                    break
                  default:
                    throw new Error('Unexpected token in service: ' + tokens[0])
                }
              }
      
              throw new Error('No closing tag for service')
            }
      
            var onrpc = function (tokens) {
              tokens.shift()
      
              var rpc = {
                name: tokens.shift(),
                input_type: null,
                output_type: null,
                client_streaming: false,
                server_streaming: false,
                options: {}
              }
      
              if (tokens[0] !== '(') throw new Error('Expected ( but found ' + tokens[0])
              tokens.shift()
      
              if (tokens[0] === 'stream') {
                tokens.shift()
                rpc.client_streaming = true
              }
      
              rpc.input_type = tokens.shift()
      
              if (tokens[0] !== ')') throw new Error('Expected ) but found ' + tokens[0])
              tokens.shift()
      
              if (tokens[0] !== 'returns') throw new Error('Expected returns but found ' + tokens[0])
              tokens.shift()
      
              if (tokens[0] !== '(') throw new Error('Expected ( but found ' + tokens[0])
              tokens.shift()
      
              if (tokens[0] === 'stream') {
                tokens.shift()
                rpc.server_streaming = true
              }
      
              rpc.output_type = tokens.shift()
      
              if (tokens[0] !== ')') throw new Error('Expected ) but found ' + tokens[0])
              tokens.shift()
      
              if (tokens[0] === ';') {
                tokens.shift()
                return rpc
              }
      
              if (tokens[0] !== '{') throw new Error('Expected { but found ' + tokens[0])
              tokens.shift()
      
              while (tokens.length) {
                if (tokens[0] === '}') {
                  tokens.shift()
                  // there goes optional semicolon after the enclosing "}"
                  if (tokens[0] === ';') tokens.shift()
                  return rpc
                }
      
                if (tokens[0] === 'option') {
                  var opt = onoption(tokens)
                  if (rpc.options[opt.name] !== undefined) throw new Error('Duplicate option ' + opt.name)
                  rpc.options[opt.name] = opt.value
                } else {
                  throw new Error('Unexpected token in rpc options: ' + tokens[0])
                }
              }
      
              throw new Error('No closing tag for rpc')
            }
      
            var parse = function (buf) {
              var tokens = tokenize(buf.toString())
              // check for isolated strings in tokens by looking for opening quote
              for (var i = 0; i < tokens.length; i++) {
                if (/^("|')([^'"]*)$/.test(tokens[i])) {
                  var j
                  if (tokens[i].length === 1) {
                    j = i + 1
                  } else {
                    j = i
                  }
                  // look ahead for the closing quote and collapse all
                  // in-between tokens into a single token
                  for (j; j < tokens.length; j++) {
                    if (/^[^'"\\]*(?:\\.[^'"\\]*)*("|')$/.test(tokens[j])) {
                      tokens = tokens.slice(0, i).concat(tokens.slice(i, j + 1).join('')).concat(tokens.slice(j + 1))
                      break
                    }
                  }
                }
              }
              var schema = {
                syntax: 3,
                package: null,
                imports: [],
                enums: [],
                messages: [],
                options: {},
                extends: []
              }
      
              var firstline = true
      
              while (tokens.length) {
                switch (tokens[0]) {
                  case 'package':
                    schema.package = onpackagename(tokens)
                    break
      
                  case 'syntax':
                    if (!firstline) throw new Error('Protobuf syntax version should be first thing in file')
                    schema.syntax = onsyntaxversion(tokens)
                    break
      
                  case 'message':
                    schema.messages.push(onmessage(tokens))
                    break
      
                  case 'enum':
                    schema.enums.push(onenum(tokens))
                    break
      
                  case 'option':
                    var opt = onoption(tokens)
                    if (schema.options[opt.name]) throw new Error('Duplicate option ' + opt.name)
                    schema.options[opt.name] = opt.value
                    break
      
                  case 'import':
                    schema.imports.push(onimport(tokens))
                    break
      
                  case 'extend':
                    schema.extends.push(onextend(tokens))
                    break
      
                  case 'service':
                    if (!schema.services) schema.services = []
                    schema.services.push(onservice(tokens))
                    break
      
                  default:
                    throw new Error('Unexpected token: ' + tokens[0])
                }
                firstline = false
              }
      
              // now iterate over messages and propagate extends
              schema.extends.forEach(function (ext) {
                schema.messages.forEach(function (msg) {
                  if (msg.name === ext.name) {
                    ext.message.fields.forEach(function (field) {
                      if (!msg.extensions || field.tag < msg.extensions.from || field.tag > msg.extensions.to) {
                        throw new Error(msg.name + ' does not declare ' + field.tag + ' as an extension number')
                      }
                      msg.fields.push(field)
                    })
                  }
                })
              })
      
              schema.messages.forEach(function (msg) {
                msg.fields.forEach(function (field) {
                  var fieldSplit
                  var messageName
                  var nestedEnumName
                  var message
      
                  function enumNameIsFieldType(en) {
                    return en.name === field.type
                  }
      
                  function enumNameIsNestedEnumName(en) {
                    return en.name === nestedEnumName
                  }
      
                  if (field.options && field.options.packed === 'true') {
                    if (PACKABLE_TYPES.indexOf(field.type) === -1) {
                      // let's see if it's an enum
                      if (field.type.indexOf('.') === -1) {
                        if (msg.enums && msg.enums.some(enumNameIsFieldType)) {
                          return
                        }
                      } else {
                        fieldSplit = field.type.split('.')
                        if (fieldSplit.length > 2) {
                          throw new Error('what is this?')
                        }
      
                        messageName = fieldSplit[0]
                        nestedEnumName = fieldSplit[1]
      
                        schema.messages.some(function (msg) {
                          if (msg.name === messageName) {
                            message = msg
                            return msg
                          }
                        })
      
                        if (message && message.enums && message.enums.some(enumNameIsNestedEnumName)) {
                          return
                        }
                      }
      
                      throw new Error(
                        'Fields of type ' + field.type + ' cannot be declared [packed=true]. ' +
                        'Only repeated fields of primitive numeric types (types which use ' +
                        'the varint, 32-bit, or 64-bit wire types) can be declared "packed". ' +
                        'See https://developers.google.com/protocol-buffers/docs/encoding#optional'
                      )
                    }
                  }
                })
              })
      
              return schema
            }
      
            module.exports = parse
      
      
            /***/
      }),
      
          /***/ "./node_modules/protocol-buffers-schema/stringify.js":
          /*!***********************************************************!*\
            !*** ./node_modules/protocol-buffers-schema/stringify.js ***!
            \***********************************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            var onfield = function (f, result) {
              var prefix = f.repeated ? 'repeated' : f.required ? 'required' : 'optional'
              if (f.type === 'map') prefix = 'map<' + f.map.from + ',' + f.map.to + '>'
              if (f.oneof) prefix = ''
      
              var opts = Object.keys(f.options || {}).map(function (key) {
                return key + ' = ' + f.options[key]
              }).join(',')
      
              if (opts) opts = ' [' + opts + ']'
      
              result.push((prefix ? prefix + ' ' : '') + (f.map === 'map' ? '' : f.type + ' ') + f.name + ' = ' + f.tag + opts + ';')
              return result
            }
      
            var onmessage = function (m, result) {
              result.push('message ' + m.name + ' {')
      
              if (!m.options) m.options = {}
              onoption(m.options, result)
      
              if (!m.enums) m.enums = []
              m.enums.forEach(function (e) {
                result.push(onenum(e, []))
              })
      
              if (!m.messages) m.messages = []
              m.messages.forEach(function (m) {
                result.push(onmessage(m, []))
              })
      
              var oneofs = {}
      
              if (!m.fields) m.fields = []
              m.fields.forEach(function (f) {
                if (f.oneof) {
                  if (!oneofs[f.oneof]) oneofs[f.oneof] = []
                  oneofs[f.oneof].push(onfield(f, []))
                } else {
                  result.push(onfield(f, []))
                }
              })
      
              Object.keys(oneofs).forEach(function (n) {
                oneofs[n].unshift('oneof ' + n + ' {')
                oneofs[n].push('}')
                result.push(oneofs[n])
              })
      
              result.push('}', '')
              return result
            }
      
            var onenum = function (e, result) {
              result.push('enum ' + e.name + ' {')
              if (!e.options) e.options = {}
              var options = onoption(e.options, [])
              if (options.length > 1) {
                result.push(options.slice(0, -1))
              }
              Object.keys(e.values).map(function (v) {
                var val = onenumvalue(e.values[v])
                result.push([v + ' = ' + val + ';'])
              })
              result.push('}', '')
              return result
            }
      
            var onenumvalue = function (v, result) {
              var opts = Object.keys(v.options || {}).map(function (key) {
                return key + ' = ' + v.options[key]
              }).join(',')
      
              if (opts) opts = ' [' + opts + ']'
              var val = v.value + opts
              return val
            }
      
            var onoption = function (o, result) {
              var keys = Object.keys(o)
              keys.forEach(function (option) {
                var v = o[option]
                if (~option.indexOf('.')) option = '(' + option + ')'
      
                var type = typeof v
      
                if (type === 'object') {
                  v = onoptionMap(v, [])
                  if (v.length) result.push('option ' + option + ' = {', v, '};')
                } else {
                  if (type === 'string' && option !== 'optimize_for') v = '"' + v + '"'
                  result.push('option ' + option + ' = ' + v + ';')
                }
              })
              if (keys.length > 0) {
                result.push('')
              }
      
              return result
            }
      
            var onoptionMap = function (o, result) {
              var keys = Object.keys(o)
              keys.forEach(function (k) {
                var v = o[k]
      
                var type = typeof v
      
                if (type === 'object') {
                  if (Array.isArray(v)) {
                    v.forEach(function (v) {
                      v = onoptionMap(v, [])
                      if (v.length) result.push(k + ' {', v, '}')
                    })
                  } else {
                    v = onoptionMap(v, [])
                    if (v.length) result.push(k + ' {', v, '}')
                  }
                } else {
                  if (type === 'string') v = '"' + v + '"'
                  result.push(k + ': ' + v)
                }
              })
      
              return result
            }
      
            var onservices = function (s, result) {
              result.push('service ' + s.name + ' {')
      
              if (!s.options) s.options = {}
              onoption(s.options, result)
              if (!s.methods) s.methods = []
              s.methods.forEach(function (m) {
                result.push(onrpc(m, []))
              })
      
              result.push('}', '')
              return result
            }
      
            var onrpc = function (rpc, result) {
              var def = 'rpc ' + rpc.name + '('
              if (rpc.client_streaming) def += 'stream '
              def += rpc.input_type + ') returns ('
              if (rpc.server_streaming) def += 'stream '
              def += rpc.output_type + ')'
      
              if (!rpc.options) rpc.options = {}
      
              var options = onoption(rpc.options, [])
              if (options.length > 1) {
                result.push(def + ' {', options.slice(0, -1), '}')
              } else {
                result.push(def + ';')
              }
      
              return result
            }
      
            var indent = function (lvl) {
              return function (line) {
                if (Array.isArray(line)) return line.map(indent(lvl + '  ')).join('\n')
                return lvl + line
              }
            }
      
            module.exports = function (schema) {
              var result = []
      
              result.push('syntax = "proto' + schema.syntax + '";', '')
      
              if (schema.package) result.push('package ' + schema.package + ';', '')
      
              if (!schema.options) schema.options = {}
      
              onoption(schema.options, result)
      
              if (!schema.enums) schema.enums = []
              schema.enums.forEach(function (e) {
                onenum(e, result)
              })
      
              if (!schema.messages) schema.messages = []
              schema.messages.forEach(function (m) {
                onmessage(m, result)
              })
      
              if (schema.services) {
                schema.services.forEach(function (s) {
                  onservices(s, result)
                })
              }
              return result.map(indent('')).join('\n')
            }
      
      
            /***/
      }),
      
          /***/ "./node_modules/protocol-buffers-schema/tokenize.js":
          /*!**********************************************************!*\
            !*** ./node_modules/protocol-buffers-schema/tokenize.js ***!
            \**********************************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            module.exports = function (sch) {
              var noComments = function (line) {
                var i = line.indexOf('//')
                return i > -1 ? line.slice(0, i) : line
              }
      
              var noMultilineComments = function () {
                var inside = false
                return function (token) {
                  if (token === '/*') {
                    inside = true
                    return false
                  }
                  if (token === '*/') {
                    inside = false
                    return false
                  }
                  return !inside
                }
              }
      
              var trim = function (line) {
                return line.trim()
              }
      
              return sch
                .replace(/([;,{}()=:[\]<>]|\/\*|\*\/)/g, ' $1 ')
                .split(/\n/)
                .map(trim)
                .filter(Boolean)
                .map(noComments)
                .map(trim)
                .filter(Boolean)
                .join('\n')
                .split(/\s+|\n+/gm)
                .filter(noMultilineComments())
            }
      
      
            /***/
      }),
      
          /***/ "./node_modules/protocol-buffers/compile-to-js.js":
          /*!********************************************************!*\
            !*** ./node_modules/protocol-buffers/compile-to-js.js ***!
            \********************************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
            var os = __webpack_require__(/*! os */ "./node_modules/os-browserify/browser.js")
      
            var RESERVED = {
              type: true,
              message: true,
              name: true,
              buffer: true,
              encode: true,
              decode: true,
              encodingLength: true,
              dependencies: true
            }
      
            function isEncoder(m) {
              return typeof m.encode === 'function'
            }
      
            function compile(messages) {
              var out = ''
      
              out += '// This file is auto generated by the protocol-buffers compiler' + os.EOL
              out += os.EOL
              out += '/* eslint-disable quotes */' + os.EOL
              out += '/* eslint-disable indent */' + os.EOL
              out += '/* eslint-disable no-redeclare */' + os.EOL
              out += '/* eslint-disable camelcase */' + os.EOL
              out += os.EOL
              out += '// Remember to `npm install --save protocol-buffers-encodings`' + os.EOL
              out += 'var encodings = require(\'protocol-buffers-encodings\')' + os.EOL
              out += 'var varint = encodings.varint' + os.EOL
              out += 'var skip = encodings.skip' + os.EOL
              out += os.EOL
      
              visit(messages, 'exports', '')
      
              function stringifyEnum(map, spaces) {
                const keys = Object.keys(map)
                const safe = keys.every(function (k) {
                  if (typeof map[k] !== 'number') return false
                  return /^[a-z][a-z0-9]+$/i.test(k)
                })
      
                if (!safe) return JSON.stringify(map, null, 2).replace(/\n/g, os.EOL) + os.EOL
      
                var out = '{' + os.EOL
      
                keys.forEach(function (k, i) {
                  out += spaces + '  ' + k + ': ' + map[k] + (i < keys.length - 1 ? ',' : '') + os.EOL
                })
      
                return out + spaces + '}' + os.EOL
              }
      
              function visit(messages, exports, spaces) {
                var encoders = Object.keys(messages).filter(function (name) {
                  if (RESERVED[name]) return false
                  return isEncoder(messages[name])
                })
      
                var enums = Object.keys(messages).filter(function (name) {
                  if (RESERVED[name]) return false
                  return !isEncoder(messages[name])
                })
      
                enums.forEach(function (name) {
                  out += spaces + exports + '.' + name + ' = ' +
                    stringifyEnum(messages[name], spaces) + os.EOL
                })
      
                encoders.forEach(function (name) {
                  out += spaces + 'var ' + name + ' = ' + exports + '.' + name + ' = {' + os.EOL
                  out += spaces + '  buffer: true,' + os.EOL
                  out += spaces + '  encodingLength: null,' + os.EOL
                  out += spaces + '  encode: null,' + os.EOL
                  out += spaces + '  decode: null' + os.EOL
                  out += spaces + '}' + os.EOL
                  out += os.EOL
                })
      
                encoders.forEach(function (name) {
                  out += spaces + 'define' + name + '()' + os.EOL
                })
      
                if (encoders.length) out += os.EOL
      
                encoders.forEach(function (name) {
                  out += spaces + 'function define' + name + ' () {' + os.EOL
      
                  visit(messages[name], name, spaces + '  ')
      
                  out += spaces + '  ' + name + '.encodingLength = encodingLength' + os.EOL
                  out += spaces + '  ' + name + '.encode = encode' + os.EOL
                  out += spaces + '  ' + name + '.decode = decode' + os.EOL + os.EOL
                  out += spaces + '  ' + funToString(messages[name].encodingLength, spaces + '  ') + os.EOL + os.EOL
                  out += spaces + '  ' + funToString(messages[name].encode, spaces + '  ') + os.EOL + os.EOL
                  out += spaces + '  ' + funToString(messages[name].decode, spaces + '  ') + os.EOL
                  out += spaces + '}' + os.EOL + os.EOL
                })
              }
      
              out += funToString(__webpack_require__(/*! ./compile */ "./node_modules/protocol-buffers/compile.js").defined, '') + os.EOL
      
              return out
      
              function funToString(fn, spaces) {
                return fn.toString().split('\n').map(indent).join('\n')
      
                function indent(n, i) {
                  if (!i) return n.replace(/(function \w+)\(/, '$1 (')
                  return spaces + n
                }
              }
            }
      
            module.exports = compile
      
      
            /***/
      }),
      
          /***/ "./node_modules/protocol-buffers/compile.js":
          /*!**************************************************!*\
            !*** ./node_modules/protocol-buffers/compile.js ***!
            \**************************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
          /* WEBPACK VAR INJECTION */(function (Buffer) {/* eslint-disable no-spaced-func */
              /* eslint-disable no-unexpected-multiline */
              /* eslint-disable func-call-spacing */
      
              var encodings = __webpack_require__(/*! protocol-buffers-encodings */ "./node_modules/protocol-buffers-encodings/index.js")
              var varint = __webpack_require__(/*! varint */ "./node_modules/varint/index.js")
              var genobj = __webpack_require__(/*! generate-object-property */ "./node_modules/generate-object-property/index.js")
              var genfun = __webpack_require__(/*! generate-function */ "./node_modules/generate-function/index.js")
      
              var flatten = function (values) {
                if (!values) return null
                var result = {}
                Object.keys(values).forEach(function (k) {
                  result[k] = values[k].value
                })
                return result
              }
      
              var defined = function defined(val) {
                return val !== null && val !== undefined && (typeof val !== 'number' || !isNaN(val))
              }
      
              var isString = function (def) {
                try {
                  return !!def && typeof JSON.parse(def) === 'string'
                } catch (err) {
                  return false
                }
              }
      
              var defaultValue = function (f, def) {
                if (f.map) return '{}'
                if (f.repeated) return '[]'
      
                switch (f.type) {
                  case 'string':
                    return isString(def) ? def : '""'
      
                  case 'bool':
                    if (def === 'true') return 'true'
                    return 'false'
      
                  case 'float':
                  case 'double':
                  case 'sfixed32':
                  case 'fixed32':
                  case 'varint':
                  case 'enum':
                  case 'uint64':
                  case 'uint32':
                  case 'int64':
                  case 'int32':
                  case 'sint64':
                  case 'sint32':
                    return '' + Number(def || 0)
      
                  default:
                    return 'null'
                }
              }
      
              var unique = function () {
                var seen = {}
                return function (key) {
                  if (seen.hasOwnProperty(key)) return false
                  seen[key] = true
                  return true
                }
              }
      
              var encName = function (e) {
                var name = encodings.name(e)
                if (name) name = 'encodings.' + name
                else if (!e.name) name = 'encodings.enum'
                else name = e.name
                return name
              }
      
              module.exports = function (schema, extraEncodings, inlineEnc) {
                var messages = {}
                var enums = {}
                var cache = {}
      
                var encString = function (idx, encs) {
                  return inlineEnc ? encName(encs[idx]) : 'enc[' + idx + ']'
                }
      
                var visit = function (schema, prefix) {
                  if (schema.enums) {
                    schema.enums.forEach(function (e) {
                      e.id = prefix + (prefix ? '.' : '') + e.name
                      enums[e.id] = e
                      visit(e, e.id)
                    })
                  }
                  if (schema.messages) {
                    schema.messages.forEach(function (m) {
                      m.id = prefix + (prefix ? '.' : '') + m.name
                      messages[m.id] = m
                      m.fields.forEach(function (f) {
                        if (!f.map) return
      
                        var name = 'Map_' + f.map.from + '_' + f.map.to
                        var map = {
                          name: name,
                          enums: [],
                          messages: [],
                          fields: [{
                            name: 'key',
                            type: f.map.from,
                            tag: 1,
                            repeated: false,
                            required: true
                          }, {
                            name: 'value',
                            type: f.map.to,
                            tag: 2,
                            repeated: false,
                            required: false
                          }],
                          extensions: null,
                          id: prefix + (prefix ? '.' : '') + name
                        }
      
                        if (!messages[map.id]) {
                          messages[map.id] = map
                          schema.messages.push(map)
                        }
                        f.type = name
                        f.repeated = true
                      })
                      visit(m, m.id)
                    })
                  }
                }
      
                visit(schema, '')
      
                var compileEnum = function (e) {
                  var conditions = Object.keys(e.values)
                    .map(function (k) {
                      return 'val !== ' + parseInt(e.values[k].value, 10)
                    })
                    .join(' && ')
      
                  if (!conditions) conditions = 'true'
      
                  var encode = genfun()
                    ('function encode (val, buf, offset) {')
                    ('if (%s) throw new Error("Invalid enum value: "+val)', conditions)
                    ('varint.encode(val, buf, offset)')
                    ('encode.bytes = varint.encode.bytes')
                    ('return buf')
                    ('}')
                    .toFunction({
                      varint: varint
                    })
      
                  var decode = genfun()
                    ('function decode (buf, offset) {')
                    ('var val = varint.decode(buf, offset)')
                    ('if (%s) throw new Error("Invalid enum value: "+val)', conditions)
                    ('decode.bytes = varint.decode.bytes')
                    ('return val')
                    ('}')
                    .toFunction({
                      varint: varint
                    })
      
                  return encodings.make(0, encode, decode, varint.encodingLength)
                }
      
                var compileMessage = function (m, exports) {
                  m.messages.forEach(function (nested) {
                    exports[nested.name] = resolve(nested.name, m.id)
                  })
      
                  m.enums.forEach(function (val) {
                    exports[val.name] = flatten(val.values)
                  })
      
                  exports.type = 2
                  exports.message = true
                  exports.name = m.name
      
                  var oneofs = {}
      
                  m.fields.forEach(function (f) {
                    if (!f.oneof) return
                    if (!oneofs[f.oneof]) oneofs[f.oneof] = []
                    oneofs[f.oneof].push(f.name)
                  })
      
                  var enc = m.fields.map(function (f) {
                    return resolve(f.type, m.id)
                  })
      
                  var dedupEnc = enc.filter(function (e, i) {
                    return enc.indexOf(e) === i
                  })
      
                  var dedupIndex = enc.map(function (e) {
                    return dedupEnc.indexOf(e)
                  })
      
                  var forEach = function (fn) {
                    for (var i = 0; i < enc.length; i++) fn(enc[i], m.fields[i], genobj('obj', m.fields[i].name), i)
                  }
      
                  // compile encodingLength
      
                  var encodingLength = genfun()
                    ('function encodingLength (obj) {')
                    ('var length = 0')
      
                  Object.keys(oneofs).forEach(function (name) {
                    var msg = JSON.stringify('only one of the properties defined in oneof ' + name + ' can be set')
                    var cnt = oneofs[name]
                      .map(function (prop) {
                        return '+defined(' + genobj('obj', prop) + ')'
                      })
                      .join(' + ')
      
                    encodingLength('if ((%s) > 1) throw new Error(%s)', cnt, msg)
                  })
      
                  forEach(function (e, f, val, i) {
                    var packed = f.repeated && f.options && f.options.packed && f.options.packed !== 'false'
                    var hl = varint.encodingLength(f.tag << 3 | e.type)
      
                    if (f.required) encodingLength('if (!defined(%s)) throw new Error(%s)', val, JSON.stringify(f.name + ' is required'))
                    else encodingLength('if (defined(%s)) {', val)
      
                    if (f.map) {
                      encodingLength()
                        ('var tmp = Object.keys(%s)', val)
                        ('for (var i = 0; i < tmp.length; i++) {')
                        ('tmp[i] = {key: tmp[i], value: %s[tmp[i]]}', val)
                        ('}')
                      val = 'tmp'
                    }
      
                    if (packed) {
                      encodingLength()
                        ('var packedLen = 0')
                        ('for (var i = 0; i < %s.length; i++) {', val)
                        ('if (!defined(%s)) continue', val + '[i]')
                        ('var len = %s.encodingLength(%s)', encString(dedupIndex[i], dedupEnc), val + '[i]')
                        ('packedLen += len')
      
                      if (e.message) encodingLength('packedLen += varint.encodingLength(len)')
      
                      encodingLength('}')
                        ('if (packedLen) {')
                        ('length += %d + packedLen + varint.encodingLength(packedLen)', hl)
                        ('}')
                    } else {
                      if (f.repeated) {
                        encodingLength('for (var i = 0; i < %s.length; i++) {', val)
                        val += '[i]'
                        encodingLength('if (!defined(%s)) continue', val)
                      }
      
                      encodingLength('var len = %s.encodingLength(%s)', encString(dedupIndex[i], dedupEnc), val)
                      if (e.message) encodingLength('length += varint.encodingLength(len)')
                      encodingLength('length += %d + len', hl)
                      if (f.repeated) encodingLength('}')
                    }
      
                    if (!f.required) encodingLength('}')
                  })
      
                  encodingLength()
                    ('return length')
                    ('}')
      
                  encodingLength = encodingLength.toFunction({
                    defined: defined,
                    varint: varint,
                    enc: dedupEnc
                  })
      
                  // compile encode
      
                  var encode = genfun()
                    ('function encode (obj, buf, offset) {')
                    ('if (!offset) offset = 0')
                    ('if (!buf) buf = Buffer.allocUnsafe(encodingLength(obj))')
                    ('var oldOffset = offset')
      
                  Object.keys(oneofs).forEach(function (name) {
                    var msg = JSON.stringify('only one of the properties defined in oneof ' + name + ' can be set')
                    var cnt = oneofs[name]
                      .map(function (prop) {
                        return '+defined(' + genobj('obj', prop) + ')'
                      })
                      .join(' + ')
      
                    encode('if ((%s) > 1) throw new Error(%s)', cnt, msg)
                  })
      
                  forEach(function (e, f, val, i) {
                    if (f.required) encode('if (!defined(%s)) throw new Error(%s)', val, JSON.stringify(f.name + ' is required'))
                    else encode('if (defined(%s)) {', val)
      
                    var packed = f.repeated && f.options && f.options.packed && f.options.packed !== 'false'
                    var p = varint.encode(f.tag << 3 | 2)
                    var h = varint.encode(f.tag << 3 | e.type)
                    var j
      
                    if (f.map) {
                      encode()
                        ('var tmp = Object.keys(%s)', val)
                        ('for (var i = 0; i < tmp.length; i++) {')
                        ('tmp[i] = {key: tmp[i], value: %s[tmp[i]]}', val)
                        ('}')
                      val = 'tmp'
                    }
      
                    if (packed) {
                      encode()
                        ('var packedLen = 0')
                        ('for (var i = 0; i < %s.length; i++) {', val)
                        ('if (!defined(%s)) continue', val + '[i]')
                        ('packedLen += %s.encodingLength(%s)', encString(dedupIndex[i], dedupEnc), val + '[i]')
                        ('}')
      
                      encode('if (packedLen) {')
                      for (j = 0; j < h.length; j++) encode('buf[offset++] = %d', p[j])
                      encode('varint.encode(packedLen, buf, offset)')
                      encode('offset += varint.encode.bytes')
                      encode('}')
                    }
      
                    if (f.repeated) {
                      encode('for (var i = 0; i < %s.length; i++) {', val)
                      val += '[i]'
                      encode('if (!defined(%s)) continue', val)
                    }
      
                    if (!packed) for (j = 0; j < h.length; j++) encode('buf[offset++] = %d', h[j])
      
                    if (e.message) {
                      encode('varint.encode(%s.encodingLength(%s), buf, offset)', encString(dedupIndex[i], dedupEnc), val)
                      encode('offset += varint.encode.bytes')
                    }
      
                    encode('%s.encode(%s, buf, offset)', encString(dedupIndex[i], dedupEnc), val)
                    encode('offset += %s.encode.bytes', encString(dedupIndex[i], dedupEnc))
      
                    if (f.repeated) encode('}')
                    if (!f.required) encode('}')
                  })
      
                  encode()
                    ('encode.bytes = offset - oldOffset')
                    ('return buf')
                    ('}')
      
                  encode = encode.toFunction({
                    encodingLength: encodingLength,
                    defined: defined,
                    varint: varint,
                    enc: dedupEnc,
                    Buffer: Buffer
                  })
      
                  // compile decode
      
                  var invalid = m.fields
                    .map(function (f, i) {
                      return f.required && '!found' + i
                    })
                    .filter(function (f) {
                      return f
                    })
                    .join(' || ')
      
                  var decode = genfun()
      
                  var objectKeys = []
      
                  forEach(function (e, f) {
                    var def = f.options && f.options.default
                    var resolved = resolve(f.type, m.id, false)
                    var vals = resolved && resolved.values
      
                    if (vals) { // is enum
                      if (f.repeated) {
                        objectKeys.push(genobj.property(f.name) + ': []')
                      } else {
                        def = (def && vals[def]) ? vals[def].value : vals[Object.keys(vals)[0]].value
                        objectKeys.push(genobj.property(f.name) + ': ' + parseInt(def || 0, 10))
                      }
                      return
                    }
      
                    objectKeys.push(genobj.property(f.name) + ': ' + defaultValue(f, def))
                  })
      
                  objectKeys = objectKeys.filter(unique())
      
                  decode()
                    ('function decode (buf, offset, end) {')
                    ('if (!offset) offset = 0')
                    ('if (!end) end = buf.length')
                    ('if (!(end <= buf.length && offset <= buf.length)) throw new Error("Decoded message is not valid")')
                    ('var oldOffset = offset')
                    ('var obj = {')
      
                  objectKeys.forEach(function (prop, i) {
                    decode(prop + (i === objectKeys.length - 1 ? '' : ','))
                  })
      
                  decode('}')
      
                  forEach(function (e, f, val, i) {
                    if (f.required) decode('var found%d = false', i)
                  })
      
                  decode('while (true) {')
                    ('if (end <= offset) {')
                    (invalid && 'if (%s) throw new Error("Decoded message is not valid")', invalid)
                    ('decode.bytes = offset - oldOffset')
                    ('return obj')
                    ('}')
                    ('var prefix = varint.decode(buf, offset)')
                    ('offset += varint.decode.bytes')
                    ('var tag = prefix >> 3')
                    ('switch (tag) {')
      
                  forEach(function (e, f, val, i) {
                    var packed = f.repeated &&
                      (
                        (f.options && f.options.packed && f.options.packed !== 'false') ||
                        (
                          !(f.options && f.options.packed == 'false') &&
                          schema.syntax == 3 && (f.type === 'float' || f.type === 'double' || f.type.indexOf('int') != -1)
                        )
                      );
      
                    decode('case %d:', f.tag)
      
                    if (f.oneof) {
                      m.fields.forEach(function (otherField) {
                        if (otherField.oneof === f.oneof && f.name !== otherField.name) {
                          decode('delete %s', genobj('obj', otherField.name))
                        }
                      })
                    }
      
                    if (packed) {
                      decode()
                        ('var packedEnd = varint.decode(buf, offset)')
                        ('offset += varint.decode.bytes')
                        ('packedEnd += offset')
                        ('while (offset < packedEnd) {')
                    }
      
                    if (e.message) {
                      decode('var len = varint.decode(buf, offset)')
                      decode('offset += varint.decode.bytes')
                      if (f.map) {
                        decode('var tmp = %s.decode(buf, offset, offset + len)', encString(dedupIndex[i], dedupEnc))
                        decode('%s[tmp.key] = tmp.value', val)
                      } else if (f.repeated) {
                        decode('%s.push(%s.decode(buf, offset, offset + len))', val, encString(dedupIndex[i], dedupEnc))
                      } else {
                        decode('%s = %s.decode(buf, offset, offset + len)', val, encString(dedupIndex[i], dedupEnc))
                      }
                    } else {
                      if (f.repeated) {
                        decode('%s.push(%s.decode(buf, offset))', val, encString(dedupIndex[i], dedupEnc))
                      } else {
                        decode('%s = %s.decode(buf, offset)', val, encString(dedupIndex[i], dedupEnc))
                      }
                    }
      
                    decode('offset += %s.decode.bytes', encString(dedupIndex[i], dedupEnc))
      
                    if (packed) decode('}')
                    if (f.required) decode('found%d = true', i)
                    decode('break')
                  })
      
                  decode()
                    ('default:')
                    ('offset = skip(prefix & 7, buf, offset)')
                    ('}')
                    ('}')
                    ('}')
      
                  decode = decode.toFunction({
                    varint: varint,
                    skip: encodings.skip,
                    enc: dedupEnc
                  })
      
                  // end of compilation - return all the things
      
                  encode.bytes = decode.bytes = 0
      
                  exports.buffer = true
                  exports.encode = encode
                  exports.decode = decode
                  exports.encodingLength = encodingLength
                  exports.dependencies = dedupEnc
      
                  return exports
                }
      
                var resolve = function (name, from, compile) {
                  if (extraEncodings && extraEncodings[name]) return extraEncodings[name]
                  if (encodings[name]) return encodings[name]
      
                  var m = (from ? from + '.' + name : name).split('.')
                    .map(function (part, i, list) {
                      return list.slice(0, i).concat(name).join('.')
                    })
                    .reverse()
                    .reduce(function (result, id) {
                      return result || messages[id] || enums[id]
                    }, null)
      
                  if (compile === false) return m
                  if (!m) throw new Error('Could not resolve ' + name)
      
                  if (m.values) return compileEnum(m)
                  if (cache[m.id]) return cache[m.id]
      
                  cache[m.id] = {}
                  return compileMessage(m, cache[m.id])
                }
      
                return (schema.enums || []).concat((schema.messages || []).map(function (message) {
                  return resolve(message.id)
                }))
              }
      
              module.exports.defined = defined
      
              /* WEBPACK VAR INJECTION */
      }.call(this, __webpack_require__(/*! ./../buffer/index.js */ "./node_modules/buffer/index.js").Buffer))
      
            /***/
      }),
      
          /***/ "./node_modules/protocol-buffers/index.js":
          /*!************************************************!*\
            !*** ./node_modules/protocol-buffers/index.js ***!
            \************************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
          /* WEBPACK VAR INJECTION */(function (Buffer) {
              var schema = __webpack_require__(/*! protocol-buffers-schema */ "./node_modules/protocol-buffers-schema/index.js")
              var compile = __webpack_require__(/*! ./compile */ "./node_modules/protocol-buffers/compile.js")
              var compileToJS = __webpack_require__(/*! ./compile-to-js */ "./node_modules/protocol-buffers/compile-to-js.js")
      
              var flatten = function (values) {
                if (!values) return null
                var result = {}
                Object.keys(values).forEach(function (k) {
                  result[k] = values[k].value
                })
                return result
              }
      
              module.exports = function (proto, opts) {
                if (!opts) opts = {}
                if (!proto) throw new Error('Pass in a .proto string or a protobuf-schema parsed object')
      
                var sch = (typeof proto === 'object' && !Buffer.isBuffer(proto)) ? proto : schema.parse(proto)
      
                // to not make toString,toJSON enumarable we make a fire-and-forget prototype
                var Messages = function () {
                  var self = this
      
                  compile(sch, opts.encodings || {}, opts.inlineEnc).forEach(function (m) {
                    self[m.name] = flatten(m.values) || m
                  })
                }
      
                Messages.prototype.toString = function () {
                  return schema.stringify(sch)
                }
      
                Messages.prototype.toJSON = function () {
                  return sch
                }
      
                return new Messages()
              }
      
              module.exports.toJS = function (proto) {
                return compileToJS(module.exports(proto, { inlineEnc: true }))
              }
      
              /* WEBPACK VAR INJECTION */
      }.call(this, __webpack_require__(/*! ./../buffer/index.js */ "./node_modules/buffer/index.js").Buffer))
      
            /***/
      }),
      
          /***/ "./node_modules/signed-varint/index.js":
          /*!*********************************************!*\
            !*** ./node_modules/signed-varint/index.js ***!
            \*********************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
            var varint = __webpack_require__(/*! varint */ "./node_modules/varint/index.js")
            exports.encode = function encode(v, b, o) {
              v = v >= 0 ? v * 2 : v * -2 - 1
              var r = varint.encode(v, b, o)
              encode.bytes = varint.encode.bytes
              return r
            }
            exports.decode = function decode(b, o) {
              var v = varint.decode(b, o)
              decode.bytes = varint.decode.bytes
              return v & 1 ? (v + 1) / -2 : v / 2
            }
      
            exports.encodingLength = function (v) {
              return varint.encodingLength(v >= 0 ? v * 2 : v * -2 - 1)
            }
      
      
            /***/
      }),
      
          /***/ "./node_modules/util/node_modules/inherits/inherits_browser.js":
          /*!*********************************************************************!*\
            !*** ./node_modules/util/node_modules/inherits/inherits_browser.js ***!
            \*********************************************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            if (typeof Object.create === 'function') {
              // implementation from standard node.js 'util' module
              module.exports = function inherits(ctor, superCtor) {
                ctor.super_ = superCtor
                ctor.prototype = Object.create(superCtor.prototype, {
                  constructor: {
                    value: ctor,
                    enumerable: false,
                    writable: true,
                    configurable: true
                  }
                });
              };
            } else {
              // old school shim for old browsers
              module.exports = function inherits(ctor, superCtor) {
                ctor.super_ = superCtor
                var TempCtor = function () { }
                TempCtor.prototype = superCtor.prototype
                ctor.prototype = new TempCtor()
                ctor.prototype.constructor = ctor
              }
            }
      
      
            /***/
      }),
      
          /***/ "./node_modules/util/support/isBufferBrowser.js":
          /*!******************************************************!*\
            !*** ./node_modules/util/support/isBufferBrowser.js ***!
            \******************************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            module.exports = function isBuffer(arg) {
              return arg && typeof arg === 'object'
                && typeof arg.copy === 'function'
                && typeof arg.fill === 'function'
                && typeof arg.readUInt8 === 'function';
            }
      
            /***/
      }),
      
          /***/ "./node_modules/util/util.js":
          /*!***********************************!*\
            !*** ./node_modules/util/util.js ***!
            \***********************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
          /* WEBPACK VAR INJECTION */(function (process) {// Copyright Joyent, Inc. and other Node contributors.
              //
              // Permission is hereby granted, free of charge, to any person obtaining a
              // copy of this software and associated documentation files (the
              // "Software"), to deal in the Software without restriction, including
              // without limitation the rights to use, copy, modify, merge, publish,
              // distribute, sublicense, and/or sell copies of the Software, and to permit
              // persons to whom the Software is furnished to do so, subject to the
              // following conditions:
              //
              // The above copyright notice and this permission notice shall be included
              // in all copies or substantial portions of the Software.
              //
              // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
              // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
              // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
              // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
              // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
              // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
              // USE OR OTHER DEALINGS IN THE SOFTWARE.
      
              var getOwnPropertyDescriptors = Object.getOwnPropertyDescriptors ||
                function getOwnPropertyDescriptors(obj) {
                  var keys = Object.keys(obj);
                  var descriptors = {};
                  for (var i = 0; i < keys.length; i++) {
                    descriptors[keys[i]] = Object.getOwnPropertyDescriptor(obj, keys[i]);
                  }
                  return descriptors;
                };
      
              var formatRegExp = /%[sdj%]/g;
              exports.format = function (f) {
                if (!isString(f)) {
                  var objects = [];
                  for (var i = 0; i < arguments.length; i++) {
                    objects.push(inspect(arguments[i]));
                  }
                  return objects.join(' ');
                }
      
                var i = 1;
                var args = arguments;
                var len = args.length;
                var str = String(f).replace(formatRegExp, function (x) {
                  if (x === '%%') return '%';
                  if (i >= len) return x;
                  switch (x) {
                    case '%s': return String(args[i++]);
                    case '%d': return Number(args[i++]);
                    case '%j':
                      try {
                        return JSON.stringify(args[i++]);
                      } catch (_) {
                        return '[Circular]';
                      }
                    default:
                      return x;
                  }
                });
                for (var x = args[i]; i < len; x = args[++i]) {
                  if (isNull(x) || !isObject(x)) {
                    str += ' ' + x;
                  } else {
                    str += ' ' + inspect(x);
                  }
                }
                return str;
              };
      
      
              // Mark that a method should not be used.
              // Returns a modified function which warns once by default.
              // If --no-deprecation is set, then it is a no-op.
              exports.deprecate = function (fn, msg) {
                if (typeof process !== 'undefined' && process.noDeprecation === true) {
                  return fn;
                }
      
                // Allow for deprecating things in the process of starting up.
                if (typeof process === 'undefined') {
                  return function () {
                    return exports.deprecate(fn, msg).apply(this, arguments);
                  };
                }
      
                var warned = false;
                function deprecated() {
                  if (!warned) {
                    if (process.throwDeprecation) {
                      throw new Error(msg);
                    } else if (process.traceDeprecation) {
                      console.trace(msg);
                    } else {
                      console.error(msg);
                    }
                    warned = true;
                  }
                  return fn.apply(this, arguments);
                }
      
                return deprecated;
              };
      
      
              var debugs = {};
              var debugEnviron;
              exports.debuglog = function (set) {
                if (isUndefined(debugEnviron))
                  debugEnviron = process.env.NODE_DEBUG || '';
                set = set.toUpperCase();
                if (!debugs[set]) {
                  if (new RegExp('\\b' + set + '\\b', 'i').test(debugEnviron)) {
                    var pid = process.pid;
                    debugs[set] = function () {
                      var msg = exports.format.apply(exports, arguments);
                      console.error('%s %d: %s', set, pid, msg);
                    };
                  } else {
                    debugs[set] = function () { };
                  }
                }
                return debugs[set];
              };
      
      
              /**
               * Echos the value of a value. Trys to print the value out
               * in the best way possible given the different types.
               *
               * @param {Object} obj The object to print out.
               * @param {Object} opts Optional options object that alters the output.
               */
              /* legacy: obj, showHidden, depth, colors*/
              function inspect(obj, opts) {
                // default options
                var ctx = {
                  seen: [],
                  stylize: stylizeNoColor
                };
                // legacy...
                if (arguments.length >= 3) ctx.depth = arguments[2];
                if (arguments.length >= 4) ctx.colors = arguments[3];
                if (isBoolean(opts)) {
                  // legacy...
                  ctx.showHidden = opts;
                } else if (opts) {
                  // got an "options" object
                  exports._extend(ctx, opts);
                }
                // set default options
                if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
                if (isUndefined(ctx.depth)) ctx.depth = 2;
                if (isUndefined(ctx.colors)) ctx.colors = false;
                if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
                if (ctx.colors) ctx.stylize = stylizeWithColor;
                return formatValue(ctx, obj, ctx.depth);
              }
              exports.inspect = inspect;
      
      
              // http://en.wikipedia.org/wiki/ANSI_escape_code#graphics
              inspect.colors = {
                'bold': [1, 22],
                'italic': [3, 23],
                'underline': [4, 24],
                'inverse': [7, 27],
                'white': [37, 39],
                'grey': [90, 39],
                'black': [30, 39],
                'blue': [34, 39],
                'cyan': [36, 39],
                'green': [32, 39],
                'magenta': [35, 39],
                'red': [31, 39],
                'yellow': [33, 39]
              };
      
              // Don't use 'blue' not visible on cmd.exe
              inspect.styles = {
                'special': 'cyan',
                'number': 'yellow',
                'boolean': 'yellow',
                'undefined': 'grey',
                'null': 'bold',
                'string': 'green',
                'date': 'magenta',
                // "name": intentionally not styling
                'regexp': 'red'
              };
      
      
              function stylizeWithColor(str, styleType) {
                var style = inspect.styles[styleType];
      
                if (style) {
                  return '\u001b[' + inspect.colors[style][0] + 'm' + str +
                    '\u001b[' + inspect.colors[style][1] + 'm';
                } else {
                  return str;
                }
              }
      
      
              function stylizeNoColor(str, styleType) {
                return str;
              }
      
      
              function arrayToHash(array) {
                var hash = {};
      
                array.forEach(function (val, idx) {
                  hash[val] = true;
                });
      
                return hash;
              }
      
      
              function formatValue(ctx, value, recurseTimes) {
                // Provide a hook for user-specified inspect functions.
                // Check that value is an object with an inspect function on it
                if (ctx.customInspect &&
                  value &&
                  isFunction(value.inspect) &&
                  // Filter out the util module, it's inspect function is special
                  value.inspect !== exports.inspect &&
                  // Also filter out any prototype objects using the circular check.
                  !(value.constructor && value.constructor.prototype === value)) {
                  var ret = value.inspect(recurseTimes, ctx);
                  if (!isString(ret)) {
                    ret = formatValue(ctx, ret, recurseTimes);
                  }
                  return ret;
                }
      
                // Primitive types cannot have properties
                var primitive = formatPrimitive(ctx, value);
                if (primitive) {
                  return primitive;
                }
      
                // Look up the keys of the object.
                var keys = Object.keys(value);
                var visibleKeys = arrayToHash(keys);
      
                if (ctx.showHidden) {
                  keys = Object.getOwnPropertyNames(value);
                }
      
                // IE doesn't make error fields non-enumerable
                // http://msdn.microsoft.com/en-us/library/ie/dww52sbt(v=vs.94).aspx
                if (isError(value)
                  && (keys.indexOf('message') >= 0 || keys.indexOf('description') >= 0)) {
                  return formatError(value);
                }
      
                // Some type of object without properties can be shortcutted.
                if (keys.length === 0) {
                  if (isFunction(value)) {
                    var name = value.name ? ': ' + value.name : '';
                    return ctx.stylize('[Function' + name + ']', 'special');
                  }
                  if (isRegExp(value)) {
                    return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
                  }
                  if (isDate(value)) {
                    return ctx.stylize(Date.prototype.toString.call(value), 'date');
                  }
                  if (isError(value)) {
                    return formatError(value);
                  }
                }
      
                var base = '', array = false, braces = ['{', '}'];
      
                // Make Array say that they are Array
                if (isArray(value)) {
                  array = true;
                  braces = ['[', ']'];
                }
      
                // Make functions say that they are functions
                if (isFunction(value)) {
                  var n = value.name ? ': ' + value.name : '';
                  base = ' [Function' + n + ']';
                }
      
                // Make RegExps say that they are RegExps
                if (isRegExp(value)) {
                  base = ' ' + RegExp.prototype.toString.call(value);
                }
      
                // Make dates with properties first say the date
                if (isDate(value)) {
                  base = ' ' + Date.prototype.toUTCString.call(value);
                }
      
                // Make error with message first say the error
                if (isError(value)) {
                  base = ' ' + formatError(value);
                }
      
                if (keys.length === 0 && (!array || value.length == 0)) {
                  return braces[0] + base + braces[1];
                }
      
                if (recurseTimes < 0) {
                  if (isRegExp(value)) {
                    return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
                  } else {
                    return ctx.stylize('[Object]', 'special');
                  }
                }
      
                ctx.seen.push(value);
      
                var output;
                if (array) {
                  output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
                } else {
                  output = keys.map(function (key) {
                    return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
                  });
                }
      
                ctx.seen.pop();
      
                return reduceToSingleString(output, base, braces);
              }
      
      
              function formatPrimitive(ctx, value) {
                if (isUndefined(value))
                  return ctx.stylize('undefined', 'undefined');
                if (isString(value)) {
                  var simple = '\'' + JSON.stringify(value).replace(/^"|"$/g, '')
                    .replace(/'/g, "\\'")
                    .replace(/\\"/g, '"') + '\'';
                  return ctx.stylize(simple, 'string');
                }
                if (isNumber(value))
                  return ctx.stylize('' + value, 'number');
                if (isBoolean(value))
                  return ctx.stylize('' + value, 'boolean');
                // For some reason typeof null is "object", so special case here.
                if (isNull(value))
                  return ctx.stylize('null', 'null');
              }
      
      
              function formatError(value) {
                return '[' + Error.prototype.toString.call(value) + ']';
              }
      
      
              function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
                var output = [];
                for (var i = 0, l = value.length; i < l; ++i) {
                  if (hasOwnProperty(value, String(i))) {
                    output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
                      String(i), true));
                  } else {
                    output.push('');
                  }
                }
                keys.forEach(function (key) {
                  if (!key.match(/^\d+$/)) {
                    output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
                      key, true));
                  }
                });
                return output;
              }
      
      
              function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
                var name, str, desc;
                desc = Object.getOwnPropertyDescriptor(value, key) || { value: value[key] };
                if (desc.get) {
                  if (desc.set) {
                    str = ctx.stylize('[Getter/Setter]', 'special');
                  } else {
                    str = ctx.stylize('[Getter]', 'special');
                  }
                } else {
                  if (desc.set) {
                    str = ctx.stylize('[Setter]', 'special');
                  }
                }
                if (!hasOwnProperty(visibleKeys, key)) {
                  name = '[' + key + ']';
                }
                if (!str) {
                  if (ctx.seen.indexOf(desc.value) < 0) {
                    if (isNull(recurseTimes)) {
                      str = formatValue(ctx, desc.value, null);
                    } else {
                      str = formatValue(ctx, desc.value, recurseTimes - 1);
                    }
                    if (str.indexOf('\n') > -1) {
                      if (array) {
                        str = str.split('\n').map(function (line) {
                          return '  ' + line;
                        }).join('\n').substr(2);
                      } else {
                        str = '\n' + str.split('\n').map(function (line) {
                          return '   ' + line;
                        }).join('\n');
                      }
                    }
                  } else {
                    str = ctx.stylize('[Circular]', 'special');
                  }
                }
                if (isUndefined(name)) {
                  if (array && key.match(/^\d+$/)) {
                    return str;
                  }
                  name = JSON.stringify('' + key);
                  if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
                    name = name.substr(1, name.length - 2);
                    name = ctx.stylize(name, 'name');
                  } else {
                    name = name.replace(/'/g, "\\'")
                      .replace(/\\"/g, '"')
                      .replace(/(^"|"$)/g, "'");
                    name = ctx.stylize(name, 'string');
                  }
                }
      
                return name + ': ' + str;
              }
      
      
              function reduceToSingleString(output, base, braces) {
                var numLinesEst = 0;
                var length = output.reduce(function (prev, cur) {
                  numLinesEst++;
                  if (cur.indexOf('\n') >= 0) numLinesEst++;
                  return prev + cur.replace(/\u001b\[\d\d?m/g, '').length + 1;
                }, 0);
      
                if (length > 60) {
                  return braces[0] +
                    (base === '' ? '' : base + '\n ') +
                    ' ' +
                    output.join(',\n  ') +
                    ' ' +
                    braces[1];
                }
      
                return braces[0] + base + ' ' + output.join(', ') + ' ' + braces[1];
              }
      
      
              // NOTE: These type checking functions intentionally don't use `instanceof`
              // because it is fragile and can be easily faked with `Object.create()`.
              function isArray(ar) {
                return Array.isArray(ar);
              }
              exports.isArray = isArray;
      
              function isBoolean(arg) {
                return typeof arg === 'boolean';
              }
              exports.isBoolean = isBoolean;
      
              function isNull(arg) {
                return arg === null;
              }
              exports.isNull = isNull;
      
              function isNullOrUndefined(arg) {
                return arg == null;
              }
              exports.isNullOrUndefined = isNullOrUndefined;
      
              function isNumber(arg) {
                return typeof arg === 'number';
              }
              exports.isNumber = isNumber;
      
              function isString(arg) {
                return typeof arg === 'string';
              }
              exports.isString = isString;
      
              function isSymbol(arg) {
                return typeof arg === 'symbol';
              }
              exports.isSymbol = isSymbol;
      
              function isUndefined(arg) {
                return arg === void 0;
              }
              exports.isUndefined = isUndefined;
      
              function isRegExp(re) {
                return isObject(re) && objectToString(re) === '[object RegExp]';
              }
              exports.isRegExp = isRegExp;
      
              function isObject(arg) {
                return typeof arg === 'object' && arg !== null;
              }
              exports.isObject = isObject;
      
              function isDate(d) {
                return isObject(d) && objectToString(d) === '[object Date]';
              }
              exports.isDate = isDate;
      
              function isError(e) {
                return isObject(e) &&
                  (objectToString(e) === '[object Error]' || e instanceof Error);
              }
              exports.isError = isError;
      
              function isFunction(arg) {
                return typeof arg === 'function';
              }
              exports.isFunction = isFunction;
      
              function isPrimitive(arg) {
                return arg === null ||
                  typeof arg === 'boolean' ||
                  typeof arg === 'number' ||
                  typeof arg === 'string' ||
                  typeof arg === 'symbol' ||  // ES6 symbol
                  typeof arg === 'undefined';
              }
              exports.isPrimitive = isPrimitive;
      
              exports.isBuffer = __webpack_require__(/*! ./support/isBuffer */ "./node_modules/util/support/isBufferBrowser.js");
      
              function objectToString(o) {
                return Object.prototype.toString.call(o);
              }
      
      
              function pad(n) {
                return n < 10 ? '0' + n.toString(10) : n.toString(10);
              }
      
      
              var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep',
                'Oct', 'Nov', 'Dec'];
      
              // 26 Feb 16:19:34
              function timestamp() {
                var d = new Date();
                var time = [pad(d.getHours()),
                pad(d.getMinutes()),
                pad(d.getSeconds())].join(':');
                return [d.getDate(), months[d.getMonth()], time].join(' ');
              }
      
      
              // log is just a thin wrapper to console.log that prepends a timestamp
              exports.log = function () {
                console.log('%s - %s', timestamp(), exports.format.apply(exports, arguments));
              };
      
      
              /**
               * Inherit the prototype methods from one constructor into another.
               *
               * The Function.prototype.inherits from lang.js rewritten as a standalone
               * function (not on Function.prototype). NOTE: If this file is to be loaded
               * during bootstrapping this function needs to be rewritten using some native
               * functions as prototype setup using normal JavaScript does not work as
               * expected during bootstrapping (see mirror.js in r114903).
               *
               * @param {function} ctor Constructor function which needs to inherit the
               *     prototype.
               * @param {function} superCtor Constructor function to inherit prototype from.
               */
              exports.inherits = __webpack_require__(/*! inherits */ "./node_modules/util/node_modules/inherits/inherits_browser.js");
      
              exports._extend = function (origin, add) {
                // Don't do anything if add isn't an object
                if (!add || !isObject(add)) return origin;
      
                var keys = Object.keys(add);
                var i = keys.length;
                while (i--) {
                  origin[keys[i]] = add[keys[i]];
                }
                return origin;
              };
      
              function hasOwnProperty(obj, prop) {
                return Object.prototype.hasOwnProperty.call(obj, prop);
              }
      
              var kCustomPromisifiedSymbol = typeof Symbol !== 'undefined' ? Symbol('util.promisify.custom') : undefined;
      
              exports.promisify = function promisify(original) {
                if (typeof original !== 'function')
                  throw new TypeError('The "original" argument must be of type Function');
      
                if (kCustomPromisifiedSymbol && original[kCustomPromisifiedSymbol]) {
                  var fn = original[kCustomPromisifiedSymbol];
                  if (typeof fn !== 'function') {
                    throw new TypeError('The "util.promisify.custom" argument must be of type Function');
                  }
                  Object.defineProperty(fn, kCustomPromisifiedSymbol, {
                    value: fn, enumerable: false, writable: false, configurable: true
                  });
                  return fn;
                }
      
                function fn() {
                  var promiseResolve, promiseReject;
                  var promise = new Promise(function (resolve, reject) {
                    promiseResolve = resolve;
                    promiseReject = reject;
                  });
      
                  var args = [];
                  for (var i = 0; i < arguments.length; i++) {
                    args.push(arguments[i]);
                  }
                  args.push(function (err, value) {
                    if (err) {
                      promiseReject(err);
                    } else {
                      promiseResolve(value);
                    }
                  });
      
                  try {
                    original.apply(this, args);
                  } catch (err) {
                    promiseReject(err);
                  }
      
                  return promise;
                }
      
                Object.setPrototypeOf(fn, Object.getPrototypeOf(original));
      
                if (kCustomPromisifiedSymbol) Object.defineProperty(fn, kCustomPromisifiedSymbol, {
                  value: fn, enumerable: false, writable: false, configurable: true
                });
                return Object.defineProperties(
                  fn,
                  getOwnPropertyDescriptors(original)
                );
              }
      
              exports.promisify.custom = kCustomPromisifiedSymbol
      
              function callbackifyOnRejected(reason, cb) {
                // `!reason` guard inspired by bluebird (Ref: https://goo.gl/t5IS6M).
                // Because `null` is a special error value in callbacks which means "no error
                // occurred", we error-wrap so the callback consumer can distinguish between
                // "the promise rejected with null" or "the promise fulfilled with undefined".
                if (!reason) {
                  var newReason = new Error('Promise was rejected with a falsy value');
                  newReason.reason = reason;
                  reason = newReason;
                }
                return cb(reason);
              }
      
              function callbackify(original) {
                if (typeof original !== 'function') {
                  throw new TypeError('The "original" argument must be of type Function');
                }
      
                // We DO NOT return the promise as it gives the user a false sense that
                // the promise is actually somehow related to the callback's execution
                // and that the callback throwing will reject the promise.
                function callbackified() {
                  var args = [];
                  for (var i = 0; i < arguments.length; i++) {
                    args.push(arguments[i]);
                  }
      
                  var maybeCb = args.pop();
                  if (typeof maybeCb !== 'function') {
                    throw new TypeError('The last argument must be of type Function');
                  }
                  var self = this;
                  var cb = function () {
                    return maybeCb.apply(self, arguments);
                  };
                  // In true node style we process the callback on `nextTick` with all the
                  // implications (stack, `uncaughtException`, `async_hooks`)
                  original.apply(this, args)
                    .then(function (ret) { process.nextTick(cb, null, ret) },
                      function (rej) { process.nextTick(callbackifyOnRejected, rej, cb) });
                }
      
                Object.setPrototypeOf(callbackified, Object.getPrototypeOf(original));
                Object.defineProperties(callbackified,
                  getOwnPropertyDescriptors(original));
                return callbackified;
              }
              exports.callbackify = callbackify;
      
              /* WEBPACK VAR INJECTION */
      }.call(this, __webpack_require__(/*! ./../process/browser.js */ "./node_modules/process/browser.js")))
      
            /***/
      }),
      
          /***/ "./node_modules/varint/decode.js":
          /*!***************************************!*\
            !*** ./node_modules/varint/decode.js ***!
            \***************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            module.exports = read
      
            var MSB = 0x80
              , REST = 0x7F
      
            function read(buf, offset) {
              var res = 0
                , offset = offset || 0
                , shift = 0
                , counter = offset
                , b
                , l = buf.length
      
              do {
                if (counter >= l) {
                  read.bytes = 0
                  throw new RangeError('Could not decode varint')
                }
                b = buf[counter++]
                res += shift < 28
                  ? (b & REST) << shift
                  : (b & REST) * Math.pow(2, shift)
                shift += 7
              } while (b >= MSB)
      
              read.bytes = counter - offset
      
              return res
            }
      
      
            /***/
      }),
      
          /***/ "./node_modules/varint/encode.js":
          /*!***************************************!*\
            !*** ./node_modules/varint/encode.js ***!
            \***************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            module.exports = encode
      
            var MSB = 0x80
              , REST = 0x7F
              , MSBALL = ~REST
              , INT = Math.pow(2, 31)
      
            function encode(num, out, offset) {
              out = out || []
              offset = offset || 0
              var oldOffset = offset
      
              while (num >= INT) {
                out[offset++] = (num & 0xFF) | MSB
                num /= 128
              }
              while (num & MSBALL) {
                out[offset++] = (num & 0xFF) | MSB
                num >>>= 7
              }
              out[offset] = num | 0
      
              encode.bytes = offset - oldOffset + 1
      
              return out
            }
      
      
            /***/
      }),
      
          /***/ "./node_modules/varint/index.js":
          /*!**************************************!*\
            !*** ./node_modules/varint/index.js ***!
            \**************************************/
          /*! no static exports found */
          /***/ (function (module, exports, __webpack_require__) {
      
            module.exports = {
              encode: __webpack_require__(/*! ./encode.js */ "./node_modules/varint/encode.js")
              , decode: __webpack_require__(/*! ./decode.js */ "./node_modules/varint/decode.js")
              , encodingLength: __webpack_require__(/*! ./length.js */ "./node_modules/varint/length.js")
            }
      
      
            /***/
      }),
      
          /***/ "./node_modules/varint/length.js":
          /*!***************************************!*\
            !*** ./node_modules/varint/length.js ***!
            \***************************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
      
            var N1 = Math.pow(2, 7)
            var N2 = Math.pow(2, 14)
            var N3 = Math.pow(2, 21)
            var N4 = Math.pow(2, 28)
            var N5 = Math.pow(2, 35)
            var N6 = Math.pow(2, 42)
            var N7 = Math.pow(2, 49)
            var N8 = Math.pow(2, 56)
            var N9 = Math.pow(2, 63)
      
            module.exports = function (value) {
              return (
                value < N1 ? 1
                  : value < N2 ? 2
                    : value < N3 ? 3
                      : value < N4 ? 4
                        : value < N5 ? 5
                          : value < N6 ? 6
                            : value < N7 ? 7
                              : value < N8 ? 8
                                : value < N9 ? 9
                                  : 10
              )
            }
      
      
            /***/
      }),
      
          /***/ "./node_modules/webpack/buildin/global.js":
          /*!***********************************!*\
            !*** (webpack)/buildin/global.js ***!
            \***********************************/
          /*! no static exports found */
          /***/ (function (module, exports) {
      
            var g;
      
            // This works in non-strict mode
            g = (function () {
              return globalThis;
            })();
      
            try {
              // This works if eval is allowed (see CSP)
              g = g || new Function("return this")();
            } catch (e) {
              // This works if the window reference is available
              if (typeof window === "object") g = window;
            }
      
            // g can still be undefined, but nothing to do about it...
            // We return undefined, instead of nothing here, so it's
            // easier to handle this case. if(!global) { ...}
      
            module.exports = g;
      
      
            /***/
      })
      
        /******/
      });
  }
  return protobuf
}

// protobuf 这个文件不能在 strict mode 下运行，所以不能用 import 和 export 语法，要用 commonjs 的 require、module.exports 语法
if(typeof __SDK_SUB_PACKAGE__ === 'undefined') {
  module.exports = getProtobuf
}


globalThis.__protobufSDKGetter__ = {
  getProtobuf: () => (...args) => getProtobuf()(...args)
}

null

})(); /* LIBRARY_CLOSURE_END () */


} catch(err) {
      console.error('catch sdkSubPackage: protobuf error: ', err)
    }
