
;try {

;(function () { /* LIBRARY_CLOSURE_START () */


            let getGlobalVar = "getGamePerformanceUtilsSDKGlobalVar"
            let sdkSubpakcageGlobalVarGetter
            if(globalThis[getGlobalVar]) {
              sdkSubpakcageGlobalVarGetter = globalThis[getGlobalVar]
            } else if(typeof globalThis.WeixinJSBridge !== "undefined" && globalThis.WeixinJSBridge[getGlobalVar]){
              sdkSubpakcageGlobalVarGetter = globalThis.WeixinJSBridge[getGlobalVar]
            }
            var {wxConsole} = sdkSubpakcageGlobalVarGetter();
          

var GamePerformanceAudit;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 515:
/***/ ((module) => {

function asyncGeneratorStep(n, t, e, r, o, a, c) {
  try {
    var i = n[a](c),
      u = i.value;
  } catch (n) {
    return void e(n);
  }
  i.done ? t(u) : Promise.resolve(u).then(r, o);
}
function _asyncToGenerator(n) {
  return function () {
    var t = this,
      e = arguments;
    return new Promise(function (r, o) {
      var a = n.apply(t, e);
      function _next(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
      }
      function _throw(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
      }
      _next(void 0);
    });
  };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ src)
});

// EXTERNAL MODULE: ../../node_modules/.pnpm/@babel+runtime@7.25.6/node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(515);
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/detect_common/common/index.ts
class Singleton {
  static getInstance() {
    if (!this.instance) {
      this.instance = new this();
    }
    return this.instance;
  }
}
Singleton.instance = void 0;
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/utils/get-wx.ts
var globalWx = null;
var originalWriteFile;
var originalRemoveFile;
var deviceInfo;
var appBaseInfo;
function setGlobalWx(privateWx) {
  if (privateWx) {
    globalWx = privateWx;
    var fs = globalWx.getFileSystemManager();
    originalWriteFile = fs.writeFile;
    originalRemoveFile = fs.unlink;
    deviceInfo = globalWx.getDeviceInfo();
    appBaseInfo = globalWx.getAppBaseInfo();
  }
}
var wx;
function setSdkWX(sdkWx) {
  wx = sdkWx;
  setGlobalWx(wx);
}
function getGlobalWx() {
  return globalWx;
}
function getWriteFile() {
  return originalWriteFile;
}
function getRemoveFile() {
  return originalRemoveFile;
}
function getDeviceInfo() {
  return deviceInfo;
}
function getAppBaseInfo() {
  return appBaseInfo;
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/common/util.js


function none() {}
function uid(length = 20, char) {
  var soup = `${char ? '' : '!#%()*+,-./:;=?@[]^_`{|}~'}ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789`;
  var soupLength = soup.length;
  var id = [];
  for (var i = 0; i < length; i++) {
    id[i] = soup.charAt(Math.random() * soupLength);
  }
  return id.join('');
}
function clamp(number, min, max) {
  return Math.max(min, Math.min(number, max));
}
function toFixed(num, digits) {
  var multiple = Math.pow(10, digits);
  return Math.round(num * multiple) / multiple;
}
function compareVersion(v1, v2) {
  if (typeof v1 !== 'string' || typeof v2 !== 'string') {
    if (typeof v1 !== 'string' && typeof v2 !== 'string') {
      return 0;
    }
    if (typeof v1 !== 'string') {
      return 1;
    }
    return -1;
  }
  var version1 = v1.split('.');
  var version2 = v2.split('.');
  var len = Math.max(version1.length, version2.length);
  while (version1.length < len) {
    version1.push('0');
  }
  while (version2.length < len) {
    version2.push('0');
  }
  for (var i = 0; i < len; i++) {
    var num1 = parseInt(version1[i], 10);
    var num2 = parseInt(version2[i], 10);
    if (num1 > num2) {
      return 1;
    }
    if (num1 < num2) {
      return -1;
    }
  }
  return 0;
}
function formatOutputNumber(value) {
  if (value < 1000) {
    return `${value}`;
  }
  if (value >= 1000 && value < 10000) {
    return `${parseFloat(`${value / 1000}`).toFixed(1)}k`;
  }
  if (value > 10000 && value < 100000) {
    return `${parseFloat(`${value / 10000}`).toFixed(1)}w`;
  }
  return '10w+';
}
function isNumber(value) {
  return typeof value === 'number' && isFinite(value);
}
function promiseRetry(func, times = 0, delay = 0, ...args) {
  return new Promise((resolve, reject) => {
    var retry = (_times = 0) => {
      func.apply(null, [...args, _times]).then(resolve).catch(err => {
        if (_times > 0) {
          setTimeout(() => {
            retry(_times - 1);
          }, delay);
        } else {
          reject(err);
        }
      });
    };
    retry(times);
  });
}
function awaitWrap(promise) {
  return promise.then(data => [null, data]).catch(err => [err, null]);
}
function formatDate(ms, fmt = 'yyyy-MM-dd') {
  if (!ms) {
    return '';
  }
  var target = fmt;
  var time = String(ms).toString().length === 10 ? new Date(ms * 1000) : new Date(ms);
  var o = {
    'y+': time.getFullYear(),
    'M+': time.getMonth() + 1,
    'd+': time.getDate(),
    'h+': time.getHours(),
    'm+': time.getMinutes(),
    's+': time.getSeconds(),
    'q+': Math.floor((time.getMonth() + 3) / 3),
    'S+': time.getMilliseconds()
  };
  var _loop = function (value) {
    var reg = new RegExp(`(${key})`);
    if (reg.test(target)) {
      var [m] = target.match(reg);
      target = target.replace(reg, () => `00${value}`.slice(-`${m}`.length));
    }
  };
  for (var [key, value] of Object.entries(o)) {
    _loop(value);
  }
  return target;
}
function isEmpty(val) {
  if (val === null || val === undefined) {
    return true;
  }
  if (typeof val === 'boolean') {
    return false;
  }
  if (typeof val === 'number') {
    return !val;
  }
  if (val instanceof Error) {
    return val.message === '';
  }
  switch (Object.prototype.toString.call(val)) {
    case '[object String]':
    case '[object Array]':
      return !val.length;
    case '[object File]':
    case '[object Map]':
    case '[object Set]':
      {
        return !val.size;
      }
    case '[object Object]':
      {
        return !Object.keys(val).length;
      }
  }
  return false;
}
function isString(obj) {
  return Object.prototype.toString.call(obj) === '[object String]';
}
function isObject(obj) {
  return Object.prototype.toString.call(obj) === '[object Object]';
}
function isFunction(functionToCheck) {
  return functionToCheck && Object.prototype.toString.call(functionToCheck) === '[object Function]';
}
function isUndefined(val) {
  return typeof val === 'undefined';
}
function isDefined(val) {
  return val !== undefined && val !== null;
}
function rgbaToHex(r, g, b) {
  var outParts = [r.toString(16), g.toString(16), b.toString(16)];
  outParts.forEach((part, i) => {
    if (part.length === 1) {
      outParts[i] = `0${part}`;
    }
  });
  return parseInt(outParts.join(''), 16);
}
function getColor(colorString) {
  var hex = /^#([a-f0-9]{6})([a-f0-9]{2})?$/i;
  var rgba = /^rgba?\(\s*([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)\s*(?:[,|/]\s*([+-]?[\d.]+)(%?)\s*)?\)$/;
  var rgb = [0, 0, 0, 1];
  var match;
  var i;
  var hexAlpha;
  if (match = colorString.match(hex)) {
    hexAlpha = match[2];
    match = match[1];
    for (i = 0; i < 3; i++) {
      var i2 = i * 2;
      rgb[i] = parseInt(match.slice(i2, i2 + 2), 16);
    }
    if (hexAlpha) {
      rgb[3] = parseInt(hexAlpha, 16) / 255;
    }
  } else if (match = colorString.match(rgba)) {
    for (i = 0; i < 3; i++) {
      rgb[i] = parseInt(match[i + 1], 10);
    }
    if (match[4]) {
      if (match[5]) {
        rgb[3] = parseFloat(match[4]) * 0.01;
      } else {
        rgb[3] = parseFloat(match[4]);
      }
    }
  }
  return {
    hex: rgbaToHex(rgb[0], rgb[1], rgb[2]),
    alpha: rgb[3]
  };
}
function getErrMsg(errMsg) {
  var result = errMsg;
  try {
    if (typeof errMsg === 'object') {
      if (typeof errMsg.errMsg === 'string') {
        result = errMsg.errMsg;
      } else if (typeof errMsg.errmsg === 'string') {
        result = errMsg.errmsg;
      } else if (typeof errMsg.message === 'string') {
        result = errMsg.message;
      } else {
        result = JSON.stringify(errMsg);
      }
    }
  } catch (e) {
    console.error(e);
  }
  return result;
}
function setQueryString(url, key, value) {
  if (!value) {
    return url;
  }
  var getUrl = url;
  var re = new RegExp(`([?&])${key}=.*?(&|$)`, 'i');
  if (getUrl.match(re)) {
    return getUrl.replace(re, `$1${key}=${value}$2`);
  }
  var separator = getUrl.indexOf('?') !== -1 ? '&' : '?';
  var hash = getUrl.split('#');
  getUrl = `${hash[0] + separator + key}=${value}`;
  if (hash[1]) {
    getUrl += `#${hash[1]}`;
  }
  return getUrl;
}
function filterSpecialChar(str) {
  return str.replace(/[\r\n\t\s]/g, '');
}
function addEllipsis(str) {
  if (str.lastIndexOf(ELLIPSIS) === str.length - 1) {
    return str;
  }
  return str + ELLIPSIS;
}
function centToYuan(value) {
  if (value === undefined || value === null) {
    return 0;
  }
  return Number(((+value || 0) / 100).toFixed(2));
}
function clipboard(value) {
  if (typeof navigator.clipboard !== 'undefined') {
    navigator.clipboard.writeText(value);
  } else {
    var textarea = document.createElement('textarea');
    document.body.appendChild(textarea);
    textarea.style.position = 'fixed';
    textarea.style.top = '-100px';
    textarea.value = value;
    textarea.select();
    document.execCommand('copy', true);
    document.body.removeChild(textarea);
  }
}
function util_delay(callback, delayTime) {
  var start = 0;
  function loop(timestamp) {
    if (!start) {
      start = timestamp;
    }
    var progress = timestamp - start;
    if (progress < delayTime) {
      requestAnimationFrame(loop);
    } else {
      callback();
    }
  }
  requestAnimationFrame(loop);
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/timer/index.ts

class Timer extends Singleton {
  constructor(...args) {
    super(...args);
    this.frameInfo = void 0;
    this.frame = 0;
    this.requestId = void 0;
    this.startTime = 0;
    this.prevTime = 0;
  }
  get currentFrame() {
    return this.frame + 1;
  }
  init() {
    this.startTime = Date.now();
    this.start();
  }
  getRuntime() {
    return Date.now() - this.startTime;
  }
  start() {
    if (!this.requestId) {
      this.prevTime = Date.now();
      requestAnimationFrame(this.counter.bind(this));
    }
  }
  stop() {
    cancelAnimationFrame(this.requestId);
    this.requestId = 0;
  }
  reset() {
    this.stop();
    this.requestId = 0;
    this.startTime = 0;
    this.prevTime = 0;
    this.frameInfo = null;
  }
  counter() {
    this.frame += 1;
    var now = Date.now();
    var cost = now - this.prevTime;
    this.frameInfo = {
      frame: this.frame,
      startTime: this.prevTime,
      endTime: now,
      cost
    };
    this.prevTime = now;
    this.requestId = requestAnimationFrame(this.counter.bind(this));
  }
}
/* harmony default export */ const timer = (Timer.getInstance());
;// CONCATENATED MODULE: ./src/base/eventemitter2.js
var isArray = Array.isArray ? Array.isArray : function _isArray(obj) {
  return Object.prototype.toString.call(obj) === '[object Array]';
};
var defaultMaxListeners = 20;
function init() {
  this._events = {};
  if (this._conf) {
    configure.call(this, this._conf);
  }
}
function configure(conf) {
  if (conf) {
    this._conf = conf;
    conf.delimiter && (this.delimiter = conf.delimiter);
    this._maxListeners = conf.maxListeners !== undefined ? conf.maxListeners : defaultMaxListeners;
    conf.newListener && (this._newListener = conf.newListener);
    conf.removeListener && (this._removeListener = conf.removeListener);
  } else {
    this._maxListeners = defaultMaxListeners;
  }
}
function logPossibleMemoryLeak(count, eventName) {
  console.warn(`[Event] ${count} listeners of event ${eventName} have been added, possibly causing memory leak.`);
}
function EventEmitter(conf) {
  this._events = {};
  this._newListener = false;
  this._removeListener = false;
  configure.call(this, conf);
}
EventEmitter.prototype.delimiter = '.';
EventEmitter.prototype.setMaxListeners = function (n) {
  if (n !== undefined) {
    this._maxListeners = n;
    if (!this._conf) this._conf = {};
    this._conf.maxListeners = n;
  }
};
EventEmitter.prototype.event = '';
EventEmitter.prototype.once = function (event, fn) {
  return this._once(event, fn, false);
};
EventEmitter.prototype.prependOnceListener = function (event, fn) {
  return this._once(event, fn, true);
};
EventEmitter.prototype._once = function (event, fn, prepend) {
  this._many(event, 1, fn, prepend);
  return this;
};
EventEmitter.prototype.many = function (event, ttl, fn) {
  return this._many(event, ttl, fn, false);
};
EventEmitter.prototype.prependMany = function (event, ttl, fn) {
  return this._many(event, ttl, fn, true);
};
EventEmitter.prototype._many = function (event, ttl, fn, prepend) {
  var self = this;
  if (typeof fn !== 'function') {
    throw new Error('many only accepts instances of Function');
  }
  function listener() {
    if (--ttl === 0) {
      self.off(event, listener);
    }
    return fn.apply(this, arguments);
  }
  listener._origin = fn;
  this._on(event, listener, prepend);
  return self;
};
EventEmitter.prototype.emit = function () {
  this._events || init.call(this);
  var type = arguments[0];
  if (type === 'newListener' && !this._newListener) {
    if (!this._events.newListener) {
      return false;
    }
  }
  var al = arguments.length;
  var args, l, i, j;
  var handler;
  if (this._all && this._all.length) {
    handler = this._all.slice();
    if (al > 3) {
      args = new Array(al);
      for (j = 0; j < al; j++) args[j] = arguments[j];
    }
    for (i = 0, l = handler.length; i < l; i++) {
      this.event = type;
      switch (al) {
        case 1:
          handler[i].call(this, type);
          break;
        case 2:
          handler[i].call(this, type, arguments[1]);
          break;
        case 3:
          handler[i].call(this, type, arguments[1], arguments[2]);
          break;
        default:
          handler[i].apply(this, args);
      }
    }
  }
  handler = this._events[type];
  if (typeof handler === 'function') {
    this.event = type;
    switch (al) {
      case 1:
        handler.call(this);
        break;
      case 2:
        handler.call(this, arguments[1]);
        break;
      case 3:
        handler.call(this, arguments[1], arguments[2]);
        break;
      default:
        args = new Array(al - 1);
        for (j = 1; j < al; j++) args[j - 1] = arguments[j];
        handler.apply(this, args);
    }
    return true;
  } else if (handler) {
    handler = handler.slice();
  }
  if (handler && handler.length) {
    if (al > 3) {
      args = new Array(al - 1);
      for (j = 1; j < al; j++) args[j - 1] = arguments[j];
    }
    for (i = 0, l = handler.length; i < l; i++) {
      this.event = type;
      switch (al) {
        case 1:
          handler[i].call(this);
          break;
        case 2:
          handler[i].call(this, arguments[1]);
          break;
        case 3:
          handler[i].call(this, arguments[1], arguments[2]);
          break;
        default:
          handler[i].apply(this, args);
      }
    }
    return true;
  } else if (!this._all && type === 'error') {
    if (arguments[1] instanceof Error) {
      throw arguments[1];
    } else {
      throw new Error("Uncaught, unspecified 'error' event.");
    }
  }
  return !!this._all;
};
EventEmitter.prototype.emitAsync = function () {
  this._events || init.call(this);
  var type = arguments[0];
  if (type === 'newListener' && !this._newListener) {
    if (!this._events.newListener) {
      return Promise.resolve([false]);
    }
  }
  var promises = [];
  var al = arguments.length;
  var args, l, i, j;
  var handler;
  if (this._all) {
    if (al > 3) {
      args = new Array(al);
      for (j = 1; j < al; j++) args[j] = arguments[j];
    }
    for (i = 0, l = this._all.length; i < l; i++) {
      this.event = type;
      switch (al) {
        case 1:
          promises.push(this._all[i].call(this, type));
          break;
        case 2:
          promises.push(this._all[i].call(this, type, arguments[1]));
          break;
        case 3:
          promises.push(this._all[i].call(this, type, arguments[1], arguments[2]));
          break;
        default:
          promises.push(this._all[i].apply(this, args));
      }
    }
  }
  handler = this._events[type];
  if (typeof handler === 'function') {
    this.event = type;
    switch (al) {
      case 1:
        promises.push(handler.call(this));
        break;
      case 2:
        promises.push(handler.call(this, arguments[1]));
        break;
      case 3:
        promises.push(handler.call(this, arguments[1], arguments[2]));
        break;
      default:
        args = new Array(al - 1);
        for (j = 1; j < al; j++) args[j - 1] = arguments[j];
        promises.push(handler.apply(this, args));
    }
  } else if (handler && handler.length) {
    handler = handler.slice();
    if (al > 3) {
      args = new Array(al - 1);
      for (j = 1; j < al; j++) args[j - 1] = arguments[j];
    }
    for (i = 0, l = handler.length; i < l; i++) {
      this.event = type;
      switch (al) {
        case 1:
          promises.push(handler[i].call(this));
          break;
        case 2:
          promises.push(handler[i].call(this, arguments[1]));
          break;
        case 3:
          promises.push(handler[i].call(this, arguments[1], arguments[2]));
          break;
        default:
          promises.push(handler[i].apply(this, args));
      }
    }
  } else if (!this._all && type === 'error') {
    if (arguments[1] instanceof Error) {
      return Promise.reject(arguments[1]);
    } else {
      return Promise.reject("Uncaught, unspecified 'error' event.");
    }
  }
  return Promise.all(promises);
};
EventEmitter.prototype.on = function (type, listener) {
  return this._on(type, listener, false);
};
EventEmitter.prototype.prependListener = function (type, listener) {
  return this._on(type, listener, true);
};
EventEmitter.prototype.onAny = function (fn) {
  return this._onAny(fn, false);
};
EventEmitter.prototype.prependAny = function (fn) {
  return this._onAny(fn, true);
};
EventEmitter.prototype.addListener = EventEmitter.prototype.on;
EventEmitter.prototype._onAny = function (fn, prepend) {
  if (typeof fn !== 'function') {
    throw new Error('onAny only accepts instances of Function');
  }
  if (!this._all) {
    this._all = [];
  }
  if (prepend) {
    this._all.unshift(fn);
  } else {
    this._all.push(fn);
  }
  return this;
};
EventEmitter.prototype._on = function (type, listener, prepend) {
  if (typeof type === 'function') {
    this._onAny(type, listener);
    return this;
  }
  if (typeof listener !== 'function') {
    throw new Error('on only accepts instances of Function');
  }
  this._events || init.call(this);
  if (this._newListener) {
    this.emit('newListener', type, listener);
  }
  if (!this._events[type]) {
    this._events[type] = listener;
  } else {
    if (typeof this._events[type] === 'function') {
      this._events[type] = [this._events[type]];
    }
    if (prepend) {
      this._events[type].unshift(listener);
    } else {
      this._events[type].push(listener);
    }
    if (!this._events[type].warned && this._maxListeners > 0 && this._events[type].length > this._maxListeners) {
      this._events[type].warned = true;
      logPossibleMemoryLeak.call(this, this._events[type].length, type);
    }
  }
  return this;
};
EventEmitter.prototype.off = function (type, listener) {
  if (typeof listener !== 'function') {
    throw new Error('removeListener only takes instances of Function');
  }
  var handlers,
    leafs = [];
  if (!this._events[type]) return this;
  handlers = this._events[type];
  leafs.push({
    _listeners: handlers
  });
  for (var iLeaf = 0; iLeaf < leafs.length; iLeaf++) {
    var leaf = leafs[iLeaf];
    handlers = leaf._listeners;
    if (isArray(handlers)) {
      var position = -1;
      for (var i = 0, length = handlers.length; i < length; i++) {
        if (handlers[i] === listener || handlers[i].listener && handlers[i].listener === listener || handlers[i]._origin && handlers[i]._origin === listener) {
          position = i;
          break;
        }
      }
      if (position < 0) {
        continue;
      }
      this._events[type].splice(position, 1);
      if (handlers.length === 0) {
        delete this._events[type];
      }
      if (this._removeListener) {
        this.emit('removeListener', type, listener);
      }
      return this;
    } else if (handlers === listener || handlers.listener && handlers.listener === listener || handlers._origin && handlers._origin === listener) {
      delete this._events[type];
      if (this._removeListener) {
        this.emit('removeListener', type, listener);
      }
    }
  }
  function recursivelyGarbageCollect(root) {
    if (root === undefined) {
      return;
    }
    var keys = Object.keys(root);
    for (var i in keys) {
      var key = keys[i];
      var obj = root[key];
      if (obj instanceof Function || typeof obj !== 'object' || obj === null) {
        continue;
      }
      if (Object.keys(obj).length > 0) {
        recursivelyGarbageCollect(root[key]);
      }
      if (Object.keys(obj).length === 0) {
        delete root[key];
      }
    }
  }
  recursivelyGarbageCollect(this.listenerTree);
  return this;
};
EventEmitter.prototype.offAny = function (fn) {
  var i = 0,
    l = 0,
    fns;
  if (fn && this._all && this._all.length > 0) {
    fns = this._all;
    for (i = 0, l = fns.length; i < l; i++) {
      if (fn === fns[i]) {
        fns.splice(i, 1);
        if (this._removeListener) {
          this.emit('removeListenerAny', fn);
        }
        return this;
      }
    }
  } else {
    fns = this._all;
    if (this._removeListener) {
      for (i = 0, l = fns.length; i < l; i++) {
        this.emit('removeListenerAny', fns[i]);
      }
    }
    this._all = [];
  }
  return this;
};
EventEmitter.prototype.removeListener = EventEmitter.prototype.off;
EventEmitter.prototype.removeAllListeners = function (type) {
  if (type === undefined) {
    !this._events || init.call(this);
    return this;
  }
  if (this._events) {
    delete this._events[type];
  }
  return this;
};
EventEmitter.prototype.listeners = function (type) {
  this._events || init.call(this);
  if (!this._events[type]) this._events[type] = [];
  if (!isArray(this._events[type])) {
    this._events[type] = [this._events[type]];
  }
  return this._events[type];
};
EventEmitter.prototype.eventNames = function () {
  return Object.keys(this._events);
};
EventEmitter.prototype.listenerCount = function (type) {
  return this.listeners(type).length;
};
EventEmitter.prototype.listenersAny = function () {
  if (this._all) {
    return this._all;
  } else {
    return [];
  }
};
/* harmony default export */ const eventemitter2 = (EventEmitter);

;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/messenger/index.ts

/* harmony default export */ const messenger = (new eventemitter2());
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/enums/message.ts
var NetworkMessageType = {
  LoadStart: "wx-request-load-start",
  LoadFail: "wx-reqeust-load-fail",
  LoadSuccess: "wx-request-load-success",
  LoadComplete: "wx-request-load-complete"
};
var DetectEventMessageType = {
  Start: "detect-start",
  End: "detect-end",
  BeforeResult: "detect-before-result"
};
var PerformanceMessageType = {
  Received: "performance-data-received"
};
var RenderTypeMessageType = {
  Drawcall: "canvas-drawcall"
};
var ApiInvokeMessageType = {
  Invoked: "api-invoked",
  ReportInteraction: "report-interaction",
  JsError: "on-js-error",
  UnhandledPromiseRejection: "unhandled-promise-rejection"
};
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/utils/sync-apis.ts
/* harmony default export */ const sync_apis = (['getStorageSync', 'readFileSync', 'fs_appendFileSync', 'measureText', 'createAudioInstance', 'loadLibFiles', 'setDisplayOrientation', 'restoreWebviewFocus', 'getPublicLibVersion', 'getCurrentRoute', 'enableDeviceOrientationChangeListening', 'setStorageSync', 'writeFileSync', 'createLoadSubPackageTask', 'initReadyForPrerender', 'unlinkSync', 'statSync', 'initReady', 'isdirSync', 'createDownloadTask', 'getStorageInfoSync', 'getBackgroundAudioState', 'removeStorageSync', 'accessSync', 'exitMiniProgram', 'initReadyAfterRenderingCache', 'readdirSync', 'readCompressedFileSync', 'clearStorageSync', 'saveFileSync', 'getSystemInfoSync', 'mkdirSync', 'canvasToTempFilePathSync', 'rmdirSync', 'loadWAFileSync', 'fs_renameSync', 'markScene', 'getSelectedTextRange', 'fs_copyFileSync', 'createUploadTask', 'createSocketTask', 'getPluginPermissionBytes', 'getPermissionBytes', 'measureTextString', 'isGameRecorderSupported', 'getABTestConfig', 'createRequestTask', 'createRequestTaskAsync', 'openSystemSetting', 'getMenuButtonBoundingClientRect', 'remoteDebugInfo', 'getSystemInfo', 'sync_jsapi_end', 'getStorage', 'setStorage', 'bindUDPSocket', 'sendDataToH5', 'createBufferURL', 'revokeBufferURL']);
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/utils/util.ts
function getHeader(headers, header) {
  if (!headers) {
    return '';
  }
  return headers[header] || headers[header.toLowerCase()];
}
function getElementsById(tree, id) {
  var res = null;
  for (var child of tree.children) {
    var _child$attributes;
    if ((child === null || child === void 0 ? void 0 : (_child$attributes = child.attributes) === null || _child$attributes === void 0 ? void 0 : _child$attributes.id) === id) {
      res = child;
      break;
    }
    if (child.children.length > 0) {
      var tmp = getElementsById(child, id);
      if (tmp !== null) {
        res = tmp;
        break;
      }
    }
  }
  return res;
}
function customStringify(obj, ignoreKeys = []) {
  var seen = new WeakMap();
  var replacer = (key, value) => {
    if (ignoreKeys.includes(key)) {
      return undefined;
    }
    var isTypedArray = value && value.buffer instanceof ArrayBuffer && value.BYTES_PER_ELEMENT !== undefined;
    if (typeof value === 'function' || Array.isArray(value) || value instanceof ArrayBuffer || isTypedArray || value instanceof Map || value instanceof Set) {
      return undefined;
    }
    if (typeof value === 'object' && value !== null) {
      if (seen.has(value)) {
        return undefined;
      }
      seen.set(value, true);
    }
    return value;
  };
  var jsonString = JSON.stringify(obj, replacer);
  if (jsonString === '{}') {
    return '';
  }
  return jsonString;
}
function isSuccessStatusCode(statusCode) {
  return statusCode >= 200 && statusCode < 300;
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/model/api.ts






class GeneralApiInvokeInfo {
  constructor(params) {
    var _args$map;
    this.invokeInfo = void 0;
    this.args = null;
    this.result = null;
    this.isSyncApi = false;
    this.ret = null;
    this.recorded = false;
    var {
      apiName,
      args
    } = params;
    var startTime = Date.now();
    var random = Math.random();
    this.args = args;
    this.invokeInfo = {
      frame: timer.currentFrame,
      uniqueId: startTime * 10000 + Math.round(random * 9999),
      startTime,
      endTime: 0,
      args: args === null || args === void 0 ? void 0 : (_args$map = args.map(arg => customStringify(arg))) === null || _args$map === void 0 ? void 0 : _args$map.filter(arg => !!arg),
      apiName,
      errno: 0,
      invokeCost: 0,
      callbackDuration: 0,
      errMsg: '',
      isSyncApi: this.checkIsSyncApi(apiName)
    };
  }
  afterExecute(ret) {
    if (ret) {
      this.ret = ret;
    }
    this.invokeInfo.invokeCost = Date.now() - this.invokeInfo.startTime;
    if (this.isSyncApi) {
      this.sendMessage();
    }
  }
  complete(res) {
    var {
      endTime
    } = this.invokeInfo;
    if (!endTime) {
      var now = Date.now();
      this.invokeInfo.endTime = now;
      this.invokeInfo.callbackDuration = now - this.invokeInfo.startTime;
    }
    if (!this.result) {
      this.result = res;
    }
    var {
      errMsg,
      errno
    } = res;
    if (errMsg && !errMsg.includes(':ok')) {
      this.invokeInfo.errMsg = errMsg;
      this.invokeInfo.errno = isUndefined(errno) ? 1 : errno;
    }
    if (!this.isSyncApi) {
      this.sendMessage();
    }
  }
  sendMessage() {
    if (this.recorded) {
      return;
    }
    this.recorded = true;
    messenger.emit(ApiInvokeMessageType.Invoked, this);
  }
  checkIsSyncApi(apiName) {
    return apiName.toLowerCase().endsWith('sync') && !apiName.toLowerCase().endsWith('async') || (sync_apis === null || sync_apis === void 0 ? void 0 : sync_apis.includes(apiName));
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/logger/index.ts
var LogLevel = /*#__PURE__*/function (LogLevel) {
  LogLevel[LogLevel["None"] = 0] = "None";
  LogLevel[LogLevel["Event"] = 1] = "Event";
  LogLevel[LogLevel["Error"] = 2] = "Error";
  LogLevel[LogLevel["Warn"] = 3] = "Warn";
  LogLevel[LogLevel["Info"] = 4] = "Info";
  LogLevel[LogLevel["Debug"] = 5] = "Debug";
  return LogLevel;
}(LogLevel || {});
class Logger {
  static error(...message) {
    if (Logger.logLevel >= LogLevel.Error) {
      console.error('[DETECT ERROR]', ...message);
    }
  }
  static warn(...message) {
    if (Logger.logLevel >= LogLevel.Warn) {
      console.warn('[DETECT WARN]', ...message);
    }
  }
  static info(...message) {
    if (Logger.logLevel >= LogLevel.Info) {
      console.info('[DETECT INFO]', ...message);
    }
  }
  static event(...message) {
    if (Logger.logLevel >= LogLevel.Event) {
      console.info('[DETECT EVENT]', ...message);
    }
  }
  static debug(...message) {
    if (Logger.logLevel >= LogLevel.Debug) {
      console.log('[DETECT DEBUG]', ...message);
    }
  }
  static setLogLevel(logLevel) {
    Logger.logLevel = logLevel;
  }
  static getLogLevel() {
    return Logger.logLevel;
  }
}
Logger.logLevel =  false ? 0 : LogLevel.Warn;
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/config/index.ts


class GlobalConfig extends Singleton {
  constructor(...args) {
    super(...args);
    this.injectTime = 0;
    this.detectTimes = 0;
    this.showTimes = 0;
    this.lastTimeStamp = 0;
    this.initParams = void 0;
    this.isWxApplib = false;
    this.sdk = {};
    this.meta = {
      startTime: 0,
      endTime: 0,
      uploadTime: 0
    };
    this.defaultMaxConcurrent = 10;
    this.onShow = () => {
      this.showTimes += 1;
      Logger.debug('return front end after ', Date.now() - this.lastTimeStamp, ' ms');
      this.lastTimeStamp = 0;
    };
    this.onHide = () => {
      this.lastTimeStamp = Date.now();
    };
  }
  get hasWXConfig() {
    return this.isWxApplib && this.sdk.WXConfig;
  }
  get audits() {
    if (this.hasWXConfig) {
      return this.sdk.WXConfig.audits || {};
    }
    return {};
  }
  get iOSHighPerformance() {
    if (this.hasWXConfig) {
      return !!this.sdk.WXConfig.jitMode || !!this.sdk.WXConfig.iOSHighPerformance;
    }
    return false;
  }
  get maxConcurrentCount() {
    if (this.hasWXConfig) {
      var _this$sdk$WXConfig$wx;
      return ((_this$sdk$WXConfig$wx = this.sdk.WXConfig.wxAppInfo) === null || _this$sdk$WXConfig$wx === void 0 ? void 0 : _this$sdk$WXConfig$wx.maxRequestConcurrent) || this.defaultMaxConcurrent;
    }
    return this.defaultMaxConcurrent;
  }
  get subpackages() {
    if (this.hasWXConfig) {
      return this.sdk.WXConfig.subpackages;
    }
    return [];
  }
  get parallelPreloadSubpackages() {
    if (this.hasWXConfig) {
      return this.sdk.WXConfig.parallelPreloadSubpackages;
    }
    return [];
  }
  get isIOS() {
    return this.sdk.WXConfig.platform === 'ios';
  }
  get isDevtools() {
    return this.sdk.WXConfig.platform === 'devtools';
  }
  get isAndroid() {
    return this.sdk.WXConfig.platform === 'android';
  }
  init(initParams) {
    this.initParams = initParams;
    this.injectTime = Date.now();
    if (typeof this.initParams.WXConfig !== 'undefined') {
      this.isWxApplib = true;
      var obj = initParams;
      this.sdk = {
        WXConfig: obj.WXConfig,
        wxConsole: obj.wxConsole,
        onShow: obj.onShow,
        onHide: obj.onHide,
        offShow: obj.offShow,
        offHide: obj.offHide,
        getSystemInfoSync: obj.getSystemInfoSync,
        getNetworkType: obj.getNetworkType,
        onNetworkStatusChange: obj.onNetworkStatusChange,
        gameTransfer: obj.gameTransfer,
        reportKeyValue: obj.reportKeyValue
      };
    } else {
      this.isWxApplib = false;
    }
    this.bindVisibleListener();
  }
  reset() {
    this.detectTimes = 0;
    this.showTimes = 0;
    this.meta = {
      startTime: 0,
      endTime: 0,
      uploadTime: 0
    };
    this.removeVisibleListener();
  }
  bindVisibleListener() {
    if (this.sdk.onShow) {
      this.sdk.onShow(this.onShow);
      this.sdk.onHide(this.onHide);
    }
  }
  removeVisibleListener() {
    if (this.sdk.offShow) {
      this.sdk.offShow(this.onShow);
      this.sdk.offHide(this.onHide);
    }
  }
}
var config_Config = GlobalConfig.getInstance();
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/network/network-task.ts




var networkQueueMap = new WeakMap();
class NetworkTask {
  get requestingCount() {
    return this.networkInfo.requestingCount;
  }
  get needPushQueue() {
    var {
      requestingCount,
      maxConcurrent
    } = this.networkInfo;
    return requestingCount > maxConcurrent;
  }
  constructor() {
    this.networkInfo = void 0;
    this.reset();
  }
  reset() {
    this.networkInfo = {
      invokeCount: 0,
      failCount: 0,
      responseSize: 0,
      requestingCount: 0,
      requestStartTime: 0,
      totalNetworkTime: 0,
      maxConcurrent: config_Config.maxConcurrentCount,
      totalQueueCount: 0,
      totalQueueTime: 0
    };
  }
  loadStart(generalInvokeInfo) {
    if (!controller.isRunning) {
      return;
    }
    if (this.networkInfo.requestingCount === 0) {
      this.networkInfo.requestStartTime = Date.now();
    }
    this.networkInfo.requestingCount += 1;
    this.networkInfo.invokeCount += 1;
    if (this.needPushQueue) {
      this.networkInfo.totalQueueCount += 1;
      networkQueueMap.set(generalInvokeInfo, [Date.now()]);
    }
  }
  loadSuccess(generalNetworkInfo) {
    if (!controller.isRunning) {
      return;
    }
    this.handleInfo(generalNetworkInfo);
  }
  loadFail(generalNetworkInfo) {
    if (!controller.isRunning) {
      return;
    }
    this.networkInfo.failCount += 1;
    this.handleInfo(generalNetworkInfo);
  }
  handleInfo(generalNetworkInfo) {
    var {
      networkInfo
    } = generalNetworkInfo;
    var res = generalNetworkInfo.result;
    if (this.networkInfo.requestingCount > 0) {
      this.networkInfo.requestingCount -= 1;
      if (this.networkInfo.requestingCount === 0) {
        var cost = Date.now() - this.networkInfo.requestStartTime;
        this.networkInfo.totalNetworkTime += cost;
        Logger.debug('all network finished, cost=', cost, ', total=', this.networkInfo.totalNetworkTime);
      }
      this.networkInfo.responseSize += networkInfo.byteLength;
      if (res && !isSuccessStatusCode(res.statusCode)) {
        Logger.error('network task statusCode error, statusCode=', res.statusCode, ', url=', generalNetworkInfo.networkInfo.url);
        this.networkInfo.failCount += 1;
      }
      this.calculateQueueTime(generalNetworkInfo);
      Logger.debug('network task complete, currentInfo=', JSON.parse(JSON.stringify(this.networkInfo)));
    }
  }
  calculateQueueTime(generalNetworkInfo) {
    var generalInvokeInfo = generalNetworkInfo.invokeInfoMap.get(generalNetworkInfo);
    if (generalInvokeInfo) {
      var queueTimeList = networkQueueMap.get(generalInvokeInfo) || [];
      var queueStartTime = queueTimeList[0];
      if (queueStartTime && queueStartTime > 0) {
        var queueCost = Date.now() - queueStartTime;
        networkQueueMap.set(generalInvokeInfo, [queueStartTime, queueCost]);
        this.networkInfo.totalQueueTime += queueCost;
      }
    }
  }
}
var networkTaskManager = new NetworkTask();
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/enums/api.ts
var ManualHookApis = {
  Request: "request",
  DownloadFile: "downloadFile",
  CreateImage: "createImage",
  CreateCanvas: "createCanvas",
  ReportScene: "reportScene",
  OnError: "onError",
  OnUnhandledRejection: "onUnhandledRejection"
};
var SpecialApis = {
  Env: "env",
  Cloud: "cloud"
};
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/model/network.ts




class GeneralNetworkInfo {
  constructor(params) {
    this.type = void 0;
    this.networkInfo = void 0;
    this.invokeInfoMap = new WeakMap();
    this.result = void 0;
    this.needPushQueue = false;
    var {
      generalInvokeInfo,
      type,
      args = {}
    } = params;
    var {
      url
    } = args;
    this.type = type;
    this.invokeInfoMap.set(this, generalInvokeInfo);
    if (generalInvokeInfo.result) {
      this.result = generalInvokeInfo.result;
    }
    this.networkInfo = {
      url,
      byteLength: 0,
      currentConcurrentCount: networkTaskManager.requestingCount,
      params: customStringify(args, ['data']),
      statusCode: 0,
      method: args.method,
      protocol: '',
      contentEncoding: '',
      cache: true,
      queueTime: 0
    };
    this.needPushQueue = networkTaskManager.needPushQueue;
  }
  complete() {
    var generalInvokeInfo = this.invokeInfoMap.get(this);
    if (!generalInvokeInfo) {
      return;
    }
    if (generalInvokeInfo.result) {
      this.result = generalInvokeInfo.result;
      this.networkInfo.statusCode = this.result.statusCode;
      this.networkInfo.protocol = this.result.profile ? this.result.profile.protocol : '';
      if (this.type === ManualHookApis.Request) {
        this.checkRequest();
      } else if (this.type === ManualHookApis.DownloadFile) {
        this.setResponseSize(this.result);
      }
      this.calculateQueueTime(generalInvokeInfo);
    }
    if (this.type === ManualHookApis.CreateImage) {
      this.networkInfo.statusCode = 200;
    }
  }
  calculateQueueTime(generalInvokeInfo) {
    if (this.needPushQueue) {
      var {
        profile
      } = generalInvokeInfo.result;
      if (profile) {
        this.networkInfo.queueTime = profile.fetchStart - generalInvokeInfo.invokeInfo.startTime;
      } else {}
    }
  }
  checkRequest() {
    var res = this.result;
    if (isSuccessStatusCode(res.statusCode)) {
      this.checkHeader(res.header);
      this.setResponseSize(res);
    }
  }
  checkHeader(header) {
    if (header) {
      this.networkInfo.contentEncoding = getHeader(header, 'Content-Encoding');
      this.networkInfo.cache = this.checkCache(header);
      this.networkInfo.byteLength = parseInt(getHeader(header, 'Content-Length'), 10) || 0;
    }
  }
  checkCache(header) {
    var cache = true;
    if (header) {
      var cacheHeader = getHeader(header, 'X-Cache-Lookup') || getHeader(header, 'X-Cache');
      var ageHeader = getHeader(header, 'Age');
      var cacheString = (cacheHeader || '').toLowerCase();
      if (cacheString) {
        cache = cacheString.includes('hit');
      } else {
        if (ageHeader) {
          cache = Number(ageHeader) > 0;
        }
      }
    }
    return cache;
  }
  setResponseSize(res) {
    var {
      profile
    } = res;
    var responseSize = this.networkInfo.byteLength;
    if (profile) {
      responseSize = profile.receivedBytedCount;
    } else {
      if (this.type === ManualHookApis.Request) {
        responseSize = this.getResponseSizeByBody(res);
      }
    }
    this.networkInfo.byteLength = responseSize;
    return responseSize;
  }
  getResponseSizeByBody(res) {
    var {
      data
    } = res;
    var responseSize = 0;
    if (isString(data)) {
      responseSize = data.length;
    } else if (!!data && data.byteLength) {
      responseSize = data.byteLength;
    }
    return responseSize;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/model/performance.ts

class GeneralGamePerformance {
  constructor(params) {
    this.performanceInfo = void 0;
    var startTime = Date.now();
    var random = Math.random();
    this.performanceInfo = {
      ...params,
      uniqueId: startTime * 10000 + Math.round(random * 9999),
      frame: timer.currentFrame,
      startTime,
      endTime: startTime
    };
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/model/index.ts



;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/common.ts

function hookApi(apiName, originApi, handler, ...args) {
  var _handler$beforeExecut, _handler$afterExecute;
  var invokeInfo = new GeneralApiInvokeInfo({
    apiName,
    args
  });
  var options = args === null || args === void 0 ? void 0 : args[0];
  if (options) {
    var originSuccess = options === null || options === void 0 ? void 0 : options.success;
    if (originSuccess) {
      options.success = function (res) {
        var _handler$success, _handler$afterSuccess;
        invokeInfo.complete(res);
        handler === null || handler === void 0 ? void 0 : (_handler$success = handler.success) === null || _handler$success === void 0 ? void 0 : _handler$success.call(handler, invokeInfo);
        if (typeof originSuccess === 'function') {
          originSuccess(res);
        }
        handler === null || handler === void 0 ? void 0 : (_handler$afterSuccess = handler.afterSuccess) === null || _handler$afterSuccess === void 0 ? void 0 : _handler$afterSuccess.call(handler, invokeInfo);
      };
    }
    var originFail = options === null || options === void 0 ? void 0 : options.fail;
    if (originFail) {
      options.fail = function (res) {
        var _handler$fail, _handler$afterFail;
        invokeInfo.complete(res);
        handler === null || handler === void 0 ? void 0 : (_handler$fail = handler.fail) === null || _handler$fail === void 0 ? void 0 : _handler$fail.call(handler, invokeInfo);
        if (typeof originFail === 'function') {
          originFail(res);
        }
        handler === null || handler === void 0 ? void 0 : (_handler$afterFail = handler.afterFail) === null || _handler$afterFail === void 0 ? void 0 : _handler$afterFail.call(handler, invokeInfo);
      };
    }
    var originComplete = options === null || options === void 0 ? void 0 : options.complete;
    if (originComplete) {
      options.complete = function (res) {
        var _handler$complete, _handler$afterComplet;
        invokeInfo.complete(res);
        handler === null || handler === void 0 ? void 0 : (_handler$complete = handler.complete) === null || _handler$complete === void 0 ? void 0 : _handler$complete.call(handler, invokeInfo);
        if (typeof originComplete === 'function') {
          originComplete(res);
        }
        handler === null || handler === void 0 ? void 0 : (_handler$afterComplet = handler.afterComplete) === null || _handler$afterComplet === void 0 ? void 0 : _handler$afterComplet.call(handler, invokeInfo);
      };
    }
  }
  handler === null || handler === void 0 ? void 0 : (_handler$beforeExecut = handler.beforeExecute) === null || _handler$beforeExecut === void 0 ? void 0 : _handler$beforeExecut.call(handler, invokeInfo);
  var ret = originApi(...args);
  invokeInfo.ret = ret;
  handler === null || handler === void 0 ? void 0 : (_handler$afterExecute = handler.afterExecute) === null || _handler$afterExecute === void 0 ? void 0 : _handler$afterExecute.call(handler, invokeInfo);
  invokeInfo.afterExecute(ret);
  return ret;
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/network/request.ts







var networkInfoMap = new WeakMap();
function hookRequest() {
  var apiName = ManualHookApis.Request;
  var globalWx = getGlobalWx();
  var originRequest = globalWx.request;
  Object.defineProperties(globalWx, {
    [apiName]: {
      value(args) {
        return hookApi(apiName, originRequest, {
          beforeExecute: invokeInfo => {
            networkTaskManager.loadStart(invokeInfo);
            var generalNetworkInfo = new GeneralNetworkInfo({
              generalInvokeInfo: invokeInfo,
              apiName,
              args,
              type: ManualHookApis.Request
            });
            networkInfoMap.set(invokeInfo, generalNetworkInfo);
            Logger.debug(args.url, ` before ${apiName} execute, invokeInfo=`, invokeInfo, ', networkInfo=', generalNetworkInfo.networkInfo);
            messenger.emit(NetworkMessageType.LoadStart, {
              args,
              generalNetworkInfo
            });
          },
          success: invokeInfo => {
            Logger.debug(args.url, ' request success, result=', invokeInfo.result);
            var generalNetworkInfo = networkInfoMap.get(invokeInfo);
            if (generalNetworkInfo) {
              generalNetworkInfo.complete();
              networkTaskManager.loadSuccess(generalNetworkInfo);
            }
            messenger.emit(NetworkMessageType.LoadSuccess, {
              args,
              generalNetworkInfo
            });
          },
          complete: invokeInfo => {
            Logger.debug(args.url, ' request complete');
            var generalNetworkInfo = networkInfoMap.get(invokeInfo);
            messenger.emit(NetworkMessageType.LoadComplete, {
              args,
              generalNetworkInfo
            });
          },
          fail: invokeInfo => {
            Logger.error(args.url, ' request fail, result=', invokeInfo.result, ', msg=', invokeInfo.invokeInfo.errMsg);
            var generalNetworkInfo = networkInfoMap.get(invokeInfo);
            if (generalNetworkInfo) {
              generalNetworkInfo.complete();
              networkTaskManager.loadFail(generalNetworkInfo);
            }
            messenger.emit(NetworkMessageType.LoadFail, {
              args,
              generalNetworkInfo
            });
          }
        }, args);
      },
      configurable: true
    }
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/network/download-file.ts







var download_file_networkInfoMap = new WeakMap();
function hookDownloadFile() {
  var globalWx = getGlobalWx();
  var apiName = ManualHookApis.DownloadFile;
  var originDownloadFile = globalWx.downloadFile;
  Object.defineProperties(globalWx, {
    [apiName]: {
      value(args) {
        return hookApi(apiName, originDownloadFile, {
          beforeExecute: invokeInfo => {
            networkTaskManager.loadStart(invokeInfo);
            var generalNetworkInfo = new GeneralNetworkInfo({
              generalInvokeInfo: invokeInfo,
              apiName,
              args,
              type: ManualHookApis.DownloadFile
            });
            download_file_networkInfoMap.set(invokeInfo, generalNetworkInfo);
            Logger.debug(args.url, ' before download execute, invokeInfo=', invokeInfo, ', networkInfo=', generalNetworkInfo.networkInfo);
            messenger.emit(NetworkMessageType.LoadStart, {
              args,
              generalNetworkInfo
            });
          },
          success: invokeInfo => {
            Logger.debug(args.url, ' downloadFile success, result=', invokeInfo.result);
            var generalNetworkInfo = download_file_networkInfoMap.get(invokeInfo);
            if (generalNetworkInfo) {
              generalNetworkInfo.complete();
              networkTaskManager.loadSuccess(generalNetworkInfo);
            }
            messenger.emit(NetworkMessageType.LoadSuccess, {
              args,
              generalNetworkInfo
            });
          },
          complete: invokeInfo => {
            Logger.debug(args.url, ' download complete');
            var generalNetworkInfo = download_file_networkInfoMap.get(invokeInfo);
            messenger.emit(NetworkMessageType.LoadComplete, {
              args,
              generalNetworkInfo
            });
          },
          fail: invokeInfo => {
            Logger.error(args.url, ' download fail, result=', invokeInfo.result, ', msg=', invokeInfo.invokeInfo.errMsg);
            var generalNetworkInfo = download_file_networkInfoMap.get(invokeInfo);
            if (generalNetworkInfo) {
              generalNetworkInfo.complete();
              networkTaskManager.loadFail(generalNetworkInfo);
            }
            messenger.emit(NetworkMessageType.LoadFail, {
              args,
              generalNetworkInfo
            });
          },
          afterExecute: invokeInfo => {
            var {
              ret
            } = invokeInfo;
            function onHeadersReceived(header) {
              var generalNetworkInfo = download_file_networkInfoMap.get(invokeInfo);
              generalNetworkInfo === null || generalNetworkInfo === void 0 ? void 0 : generalNetworkInfo.checkHeader(header);
              ret.offHeadersReceived(onHeadersReceived);
            }
            ret.onHeadersReceived(onHeadersReceived);
          }
        }, args);
      },
      configurable: true
    }
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/network/create-image-impl.ts
var imageMap = new WeakMap();
var imageCallbackMap = new WeakMap();
var _defineGetter = Object.prototype.__defineGetter__;
var _defineSetter = Object.prototype.__defineSetter__;
var objDefProp = Object.defineProperty;
var defineGetter = (target, prop, getter) => {
  _defineGetter.call(target, prop, getter);
};
var defineSetter = (target, prop, setter) => {
  _defineSetter.call(target, prop, setter);
};
var initProps = function () {
  ['width', 'height', 'complete'].forEach(prop => {
    defineGetter(this, prop, function () {
      var image = imageMap.get(this);
      return image === null || image === void 0 ? void 0 : image[prop];
    });
    defineSetter(this, prop, function (value) {
      var image = imageMap.get(this);
      if (image) {
        image[prop] = value;
      }
    });
  });
  ['onload', 'onerror'].forEach(type => {
    defineGetter(this, type, () => this[`__original__${type}`]);
    defineSetter(this, type, function (listener) {
      var image = imageMap.get(this);
      if (image) {
        var _listener$bind;
        image[type] = listener === null || listener === void 0 ? void 0 : (_listener$bind = listener.bind) === null || _listener$bind === void 0 ? void 0 : _listener$bind.call(listener, this);
      }
      objDefProp(this, `__original__${type}`, {
        value: listener,
        writable: true,
        configurable: true,
        enumerable: false
      });
    });
  });
  this.tagName = 'IMG';
  this.nodeName = 'IMG';
};
class ImageWrapper {
  constructor(img) {
    imageMap.set(this, img);
    this.__image__ = true;
    initProps.call(this);
  }
  addEventListener(...args) {
    var img = imageMap.get(this);
    if (img) {
      img.addEventListener(...args);
    }
  }
  removeEventListener(...args) {
    var img = imageMap.get(this);
    if (img) {
      img.removeEventListener(...args);
    }
  }
}
function srcSetter(src) {
  var image = imageMap.get(this);
  if (image) {
    image.src = src;
    var callback = imageCallbackMap.get(this);
    if (callback) {
      callback(src);
      imageCallbackMap.delete(this);
    }
  }
}
function bindImageSrcSetterCallback(wrapper, callback) {
  if (!callback) {
    return;
  }
  imageCallbackMap.set(wrapper, callback);
}
var hasDefinedSrc = false;
var createImageFactory = originalApi => function createImage() {
  var image = originalApi();
  var wrapper = new ImageWrapper(image);
  if (!hasDefinedSrc) {
    wrapper.__proto__.__defineGetter__('src', function () {
      var image = imageMap.get(this);
      return image === null || image === void 0 ? void 0 : image.src;
    });
    wrapper.__proto__.__defineSetter__('src', srcSetter);
    hasDefinedSrc = true;
  }
  return wrapper;
};
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/network/create-image.ts








var create_image_networkInfoMap = new WeakMap();
function hookCreateImage() {
  var globalWx = getGlobalWx();
  var apiName = ManualHookApis.CreateImage;
  var originalCreateImage = globalWx.createImage;
  Reflect.defineProperty(globalWx, apiName, {
    value() {
      var cachedInvokeInfo;
      var image = hookApi(apiName, createImageFactory(originalCreateImage), {
        beforeExecute: invokeInfo => {
          cachedInvokeInfo = invokeInfo;
        },
        afterExecute: invokeInfo => {
          cachedInvokeInfo = invokeInfo;
        }
      });
      bindImageSrcSetterCallback(image, src => {
        imageLoadStart(cachedInvokeInfo, src);
        bindImageEvent(image, src, cachedInvokeInfo);
      });
      return image;
    },
    configurable: true
  });
}
function imageLoadStart(invokeInfo, src) {
  if (src && src.includes('http')) {
    var apiName = ManualHookApis.CreateImage;
    networkTaskManager.loadStart(invokeInfo);
    var generalNetworkInfo = new GeneralNetworkInfo({
      generalInvokeInfo: invokeInfo,
      apiName,
      args: undefined,
      type: ManualHookApis.CreateImage
    });
    generalNetworkInfo.networkInfo.url = src;
    create_image_networkInfoMap.set(invokeInfo, generalNetworkInfo);
    Logger.debug(`before ${apiName} execute, invokeInfo=`, invokeInfo, ', networkInfo=', generalNetworkInfo.networkInfo);
    messenger.emit(NetworkMessageType.LoadStart, {
      generalNetworkInfo
    });
  }
}
function bindImageEvent(image, src, invokeInfo) {
  var originalOnload = image.onload;
  image.onload = function (...args) {
    if (src && src.includes('http')) {
      Logger.debug('image, src=', src, ', onload');
      var generalNetworkInfo = create_image_networkInfoMap.get(invokeInfo);
      if (generalNetworkInfo) {
        generalNetworkInfo.complete();
        Logger.debug('image network info=', generalNetworkInfo);
        networkTaskManager.loadSuccess(generalNetworkInfo);
      }
    }
    if (originalOnload) {
      originalOnload.apply(image, args);
    }
  };
  var originalOnerror = image.onerror;
  image.onerror = function (...args) {
    if (src && src.includes('http')) {
      var generalNetworkInfo = create_image_networkInfoMap.get(invokeInfo);
      if (generalNetworkInfo) {
        networkTaskManager.loadFail(generalNetworkInfo);
      }
      Logger.error('image, src=', src, ', onerror', ...args);
    }
    if (originalOnerror) {
      originalOnerror.apply(image, args);
    }
  };
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/render/index.ts






var isMainCanvas = false;
function hookCanvas() {
  var globalWx = getGlobalWx();
  var apiName = ManualHookApis.CreateCanvas;
  var originalCreateCanvas = globalWx.createCanvas;
  Object.defineProperties(globalWx, {
    [apiName]: {
      value() {
        return hookApi(apiName, originalCreateCanvas, {
          afterExecute: invokeInfo => {
            var {
              ret
            } = invokeInfo;
            if (!isMainCanvas) {
              isMainCanvas = true;
            }
            var originalGetContext = ret.getContext;
            ret.getContext = function (contextType, contextAttributes) {
              var originalContext = originalGetContext.apply(ret, [contextType, contextAttributes]);
              if (contextType === '2d') {
                hookCanvas2d(originalContext);
              }
              if (contextType === 'webgl' || contextType === 'webgl2') {
                hookWebgl(originalContext, contextType);
              }
              return originalContext;
            };
          }
        });
      },
      configurable: true
    }
  });
}
function hookCanvas2d(originalContext) {
  var _Config$audits, _Config$audits$rules, _Config$audits2, _Config$audits2$rules;
  var drawcallApis = ['fillRect', 'strokeRect', 'beginPath', 'closePath', 'moveTo', 'lineTo', 'arc', 'quadraticCurveTo', 'clip'];
  var drawImageApi = ['drawImage'];
  var textApis = ['fillText', 'strokeText'];
  var renderApis = [...drawcallApis];
  var disableFillText = (_Config$audits = config_Config.audits) === null || _Config$audits === void 0 ? void 0 : (_Config$audits$rules = _Config$audits.rules) === null || _Config$audits$rules === void 0 ? void 0 : _Config$audits$rules.disableFillText;
  var disableDrawImage = (_Config$audits2 = config_Config.audits) === null || _Config$audits2 === void 0 ? void 0 : (_Config$audits2$rules = _Config$audits2.rules) === null || _Config$audits2$rules === void 0 ? void 0 : _Config$audits2$rules.disableCreateImage;
  if (isUndefined(disableFillText) || !disableFillText) {
    renderApis.push(...textApis);
  }
  if (isUndefined(disableDrawImage) || !disableDrawImage) {
    renderApis.push(...drawImageApi);
  }
  drawImageApi.forEach(key => {
    var originalApi = originalContext[key];
    Reflect.defineProperty(originalContext, key, {
      value(...args) {
        if (key === 'drawImage') {
          return fake2DApis(originalContext, originalApi).apply(originalContext, args);
        }
        return originalApi.apply(originalContext, args);
      },
      configurable: true
    });
  });
}
function fake2DApis(originalContext, originalApi) {
  return (...args) => {
    var _;
    if (args !== null && args !== void 0 && (_ = args[0]) !== null && _ !== void 0 && _.__image__) {
      args[0] = imageMap.get(args[0]);
    }
    originalApi.call(originalContext, ...args);
  };
}
function hookWebgl(originalContext, contextType) {
  var _Config$audits3, _Config$audits3$rules;
  var drawcallApis = ['drawArrays', 'drawElements'];
  if (contextType === 'webgl2') {
    var webgl2Apis = ['drawElementsInstanced', 'drawArraysInstanced'];
    drawcallApis.push(...webgl2Apis);
  }
  var disableDrawImage = (_Config$audits3 = config_Config.audits) === null || _Config$audits3 === void 0 ? void 0 : (_Config$audits3$rules = _Config$audits3.rules) === null || _Config$audits3$rules === void 0 ? void 0 : _Config$audits3$rules.disableCreateImage;
  if (isUndefined(disableDrawImage) || !disableDrawImage) {
    hookTextureRender(originalContext, contextType);
  }
}
function hookTextureRender(gl, contextType) {
  var apis = ['texImage2D', 'texSubImage2D', 'compressedTexImage2D', 'compressedTexSubImage2D'];
  var webgl2Apis = ['texImage3D', 'texSubImage3D', 'compressedTexImage3D', 'compressedTexSubImage3D'];
  if (contextType === 'webgl2') {
    apis.push(...webgl2Apis);
  }
  var properties = Object.create(null);
  apis.forEach(api => {
    var originalApi = gl[api];
    properties[api] = {
      value(...args) {
        if (args) {
          if (args[5] && args[5].__image__) {
            args[5] = imageMap.get(args[5]);
          }
          if (args[6] && args[6].__image__) {
            args[6] = imageMap.get(args[6]);
          }
          if (args[7] && args[7].__image__) {
            args[7] = imageMap.get(args[7]);
          }
          if (args[8] && args[8].__image__) {
            args[8] = imageMap.get(args[8]);
          }
        }
        var ret = originalApi.apply(gl, args);
        return ret;
      },
      configurable: true
    };
    Object.defineProperties(gl, properties);
  });
}
function getTextureCompression(format) {
  if (format >= 0x83F0 && format <= 0x83F3 || format >= 0x8C4C && format <= 0x8C4F) {
    return 'DXT';
  }
  if (format >= 0x9270 && format <= 0x9279 || format === 0x8D64) {
    return 'ETC';
  }
  if (format >= 0x8C00 && format <= 0x8C03) {
    return 'PVRTC';
  }
  if (format >= 0x93B0 && format <= 0x93BD || format >= 0x93D0 && format <= 0x93DD) {
    return 'ASTC';
  }
  return 'Unknown';
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/minigame/coverview/common/util.js


var getCharWidth = (char, fontSize) => {
  var width = 0;
  width = config.presetChars[char] > 0 ? config.presetChars[char] : 10;
  return width * fontSize / 10;
};
var getTextWidth = (text, fontSize) => {
  var getText = text.split('');
  var width = 0;
  getText.forEach(item => {
    var cw = getCharWidth(item, fontSize);
    width += cw;
  });
  return width;
};
var isValidClick = event => {
  var startPosX = event.absoluteX;
  var startPosY = event.absoluteY;
  var endPosX = event.absoluteEndX;
  var endPosY = event.absoluteEndY;
  var touchTimes = event.pressInterval;
  var result = false;
  if (Math.abs(endPosY - startPosY) < 30 && Math.abs(endPosX - startPosX) < 30 && touchTimes < 300) {
    result = true;
  }
  return result;
};
var bindClick = (target, callback, needOpacity = true) => {
  var node = target;
  if (needOpacity) {
    node.on('touchstart', () => {
      node.style.opacity = 0.5;
    });
    node.on('touchend', () => {
      node.style.opacity = 1;
    });
  }
  node.on('click', event => {
    if (!isValidClick(event)) {
      return;
    }
    callback();
  });
};
function animatePromise(node, options) {
  var {
    duration
  } = options;
  return new Promise(resolve => {
    node.animate(options).then(() => {
      delay(resolve, duration);
    });
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/ui/style.ts
var defaultWidth = 76;
var defaultHeight = 32;
var defaultTop = 200;
var defaultLeft = 0;
var style = {
  body: {
    zIndex: 1000009,
    position: 'absolute',
    overflow: 'visible',
    hidden: false,
    width: defaultWidth,
    height: defaultHeight,
    top: defaultTop,
    left: defaultLeft
  },
  container: {
    position: 'absolute',
    overflow: 'visible',
    hidden: false,
    width: defaultWidth,
    height: defaultHeight,
    backgroundColor: '#00000080',
    borderRadius: defaultHeight / 2
  },
  operateBtn: {
    position: 'absolute',
    left: 24,
    top: 0,
    width: 44,
    height: defaultHeight,
    lineHeight: defaultHeight,
    textAlign: 'center',
    color: '#ffffff',
    fontSize: 11
  },
  stopIcon: {
    position: 'absolute',
    width: 7.5,
    height: 12.5,
    left: 9.83,
    top: 9.75,
    hidden: true
  },
  startIcon: {
    position: 'absolute',
    width: 10.82,
    height: 12.13,
    top: 9.4,
    left: 9,
    hidden: true
  },
  touchMask: {
    zIndex: 1000009,
    position: 'absolute',
    overflow: 'hidden',
    hidden: false,
    width: defaultWidth,
    height: defaultHeight,
    backgroundColor: 'rgba(0, 0, 0, 0)'
  }
};
var template = `
  <view id="body">
    <view id="container">
      <image id="stop-icon" src="https://mmgame.qpic.cn/image/b5afaa12383dfdd20314efea098fc902f29b33df99010626b01f676f3765d82c/0"></image>
      <image id="start-icon" src="https://mmgame.qpic.cn/image/171782a3ed34a9322ef8ceed3916b13a293475191ca0745dbb6a3988bc634bf8/0"></image>
      <text id="operate-btn" value="开始录制"></text>
    </view>
    <view id="touch-mask"></view>
  </view>
`;
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/enums/report.ts
var report_AuditReportType = {
  Launch: "auditStart",
  End: "auditEnd",
  WriteReport: "writeReport",
  UploadReport: "uploadReport",
  AddEveluationReport: "addEveluationReport",
  OnHide: "onHide",
  OnShow: "onShow",
  RemoveReportFile: "removeReportFile",
  GetAuthToken: "getAuthToken"
};
var EnableType = {
  Self: 0,
  Devtools: 1
};
var DetectMode = (/* unused pure expression or super */ null && ({
  Auto: 0,
  Manaul: 1
}));
var ActionStatus = (/* unused pure expression or super */ null && ({
  Fail: 0,
  Success: 1
}));
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/utils/time-logger.ts
class TimeLogger {
  static start(label) {
    if (!TimeLogger.timeMap.has(label)) {
      var t = Date.now();
      TimeLogger.timeMap.set(label, t);
      return t;
    }
    return 0;
  }
  static timeEnd(label) {
    if (TimeLogger.timeMap.has(label)) {
      var t1 = Date.now();
      var t2 = TimeLogger.timeMap.get(label);
      TimeLogger.timeMap.delete(label);
      return t1 - t2;
    }
    return 0;
  }
}
TimeLogger.timeMap = new Map();
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/minigame/quality/types.js

var IsVisible;
(function (IsVisible) {
  IsVisible[IsVisible["Front"] = 1] = "Front";
  IsVisible[IsVisible["Background"] = 2] = "Background";
})(IsVisible || (IsVisible = {}));
var ReportType;
(function (ReportType) {
  ReportType[ReportType["Default"] = 0] = "Default";
  ReportType[ReportType["GameTransfer"] = 1] = "GameTransfer";
  ReportType[ReportType["Request"] = 2] = "Request";
  ReportType[ReportType["DownloadFile"] = 3] = "DownloadFile";
  ReportType[ReportType["CgiSpeedMeasure"] = 4] = "CgiSpeedMeasure";
  ReportType[ReportType["BadJs"] = 5] = "BadJs";
  ReportType[ReportType["Init"] = 6] = "Init";
  ReportType[ReportType["CostTime"] = 7] = "CostTime";
  ReportType[ReportType["Error"] = 8] = "Error";
  ReportType[ReportType["UploadFile"] = 9] = "UploadFile";
  ReportType[ReportType["Login"] = 10] = "Login";
  ReportType[ReportType["WebTransfer"] = 11] = "WebTransfer";
})(ReportType || (ReportType = {}));
var types_PluginReportType;
(function (PluginReportType) {
  PluginReportType[PluginReportType["Info"] = 101] = "Info";
  PluginReportType[PluginReportType["Warn"] = 102] = "Warn";
  PluginReportType[PluginReportType["Error"] = 103] = "Error";
})(types_PluginReportType || (types_PluginReportType = {}));
var QualityReportType;
(function (QualityReportType) {
  QualityReportType["GameTransferReport"] = "GameTransferReport";
  QualityReportType["KeyValueReport"] = "KeyValueReport";
  QualityReportType["WxRequestReport"] = "WxRequestReport";
})(QualityReportType || (QualityReportType = {}));
var REPORT_TYPE_LIST = Object.values(ReportType).filter(item => isNumber(item));
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/common/reportBase.js
var ColumnType;
(function (ColumnType) {
  ColumnType["STRING"] = "STRING";
  ColumnType["LONGLONG"] = "LONGLONG";
  ColumnType["UINT"] = "UINT";
  ColumnType["INT"] = "INT";
})(ColumnType || (ColumnType = {}));
var reportBase_ReportType;
(function (ReportType) {
  ReportType["SvrReport"] = "SvrReport";
  ReportType["KvStat"] = "KvStat";
})(reportBase_ReportType || (reportBase_ReportType = {}));
var columnValidator = {
  [ColumnType.STRING](value) {
    return typeof value === 'string' && value.length <= 1024;
  },
  [ColumnType.LONGLONG](value) {
    return typeof value === 'number' && Math.floor(value) === value;
  },
  [ColumnType.UINT](value) {
    return typeof value === 'number' && Math.floor(value) === value && value >= 0;
  },
  [ColumnType.INT](value) {
    return typeof value === 'number' && Math.floor(value) === value;
  }
};
class ReportBase {
  constructor({
    logid,
    schemas = {},
    base,
    debug = false,
    namespace = '',
    skipValidateInProdEnv = true
  }) {
    this.debug = false;
    this.base = {};
    this.namespace = '';
    this.skipValidateInProdEnv = true;
    this.asyncGetBase = () => Promise.resolve({});
    this.logid = logid;
    this.schemas = schemas;
    if (base) {
      this.setBase(base);
    }
    this.debug = debug;
    this.skipValidateInProdEnv = skipValidateInProdEnv;
    this.namespace = namespace ? ` ${namespace} ` : ' ';
  }
  setBase(base) {
    this.validate(base);
    this.base = Object.assign(Object.assign({}, this.base), base);
  }
  validate(data) {
    if (!(this.debug || !this.skipValidateInProdEnv)) {
      return;
    }
    if (!Object.keys(this.schemas).length) {
      return;
    }
    for (var [key, item] of Object.entries(data)) {
      if (item === void 0) {
        continue;
      }
      var columnType = this.schemas[key];
      if (!columnType) {
        console.warn(`[minigamefe${this.namespace}SchemaValidator]: logid${this.logid}: ${key} 缺少类型定义`);
        continue;
      }
      if (!this.validateColumn(columnType, item)) {
        console.error(`[minigamefe${this.namespace}SchemaValidator]: logid ${this.logid}: ${key} should be ${columnType}, but now ${item}`);
      }
    }
  }
  validateColumn(columnType, value) {
    return columnValidator[columnType](value);
  }
}
var networkType = '';
function getNetworkTypeValue(callback, getNetworkType, onNetworkStatusChange) {
  if (networkType) {
    if (callback) {
      callback(networkType);
    }
  } else {
    getNetworkType({
      success: res => {
        networkType = res.networkType;
        if (callback) {
          callback(networkType);
        }
      }
    });
    onNetworkStatusChange(res => {
      networkType = res.networkType;
      if (!res.isConnected) {
        networkType = 'none';
      }
      if (callback) {
        callback(networkType);
      }
    });
  }
}
var netMap = (/* unused pure expression or super */ null && ({
  wifi: '0',
  unknown: '1',
  none: '1',
  '2g': '2',
  '3g': '3',
  '4g': '4',
  '5g': '5'
}));
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/minigame/keyValueReport.js

var KeyValueTypeMap = {
  19283: 'GameComponent',
  19335: 'GameWhatsNew',
  20285: 'MidasFriendPayment',
  21494: 'WXGameWASMLaunchClose',
  21493: 'WXGameWASMLaunchException',
  21492: 'WXGameWASMLaunchTime',
  21898: 'GameLifeMiniGameCardAction',
  20267: 'GameAdsSkipCard'
};
class KeyValueReporter extends ReportBase {
  constructor({
    reportFunc,
    logid,
    protocolParams,
    schemas,
    base,
    asyncGetBase = () => Promise.resolve({}),
    debug,
    namespace = '',
    skipValidateInProdEnv = true
  }) {
    var id = logid;
    if (typeof logid === 'number' && KeyValueTypeMap[logid]) {
      id = KeyValueTypeMap[logid];
      if (debug) {
        console.warn(`[minigamefe${namespace ? ` ${namespace} ` : ' '}KeyValueReporter]: logid ${logid} auto map to ${id}!`);
      }
    }
    super({
      logid: id,
      schemas,
      base,
      debug,
      namespace,
      skipValidateInProdEnv
    });
    this.asyncGetBase = asyncGetBase;
    if (!reportFunc) {
      console.error(`[minigamefe${this.namespace}KeyValueReporter]: 未传入上报函数。`);
    }
    this.reportFunc = reportFunc || function () {};
    this.protocolParams = protocolParams;
    this.sendCbk = null;
  }
  setAppInfoBase(info) {
    Object.assign(this.schemas, {
      AppId: ColumnType.STRING,
      AppVersion: ColumnType.UINT,
      AppState: ColumnType.UINT
    });
    this.protocolParams.unshift('AppId', 'AppVersion', 'AppState');
    this.setBase(info);
  }
  send(rptList, callback) {
    var list;
    if (!Array.isArray(rptList)) {
      list = [rptList];
    } else {
      list = rptList;
    }
    this.asyncGetBase().then(base => {
      this.setBase(base);
      list.forEach(items => {
        var reportParams = Object.assign(Object.assign({}, this.base), items);
        this.validate(reportParams);
        var resultValue = [];
        this.protocolParams.forEach(key => {
          var v = typeof reportParams[key] !== 'undefined' ? reportParams[key] : '';
          resultValue.push(v);
        });
        this.reportFunc({
          key: this.logid,
          value: resultValue.map(encodeURIComponent).join(','),
          immediately: true
        });
        var cbk = callback || this.sendCbk;
        if (cbk) {
          cbk(this.logid, resultValue.map(encodeURIComponent).join(','));
        }
        if (this.debug) {
          var logFunc = reportParams.IsError ? console.error : console.log;
          logFunc(`[minigamefe${this.namespace}keyValueReport]: ${this.logid}`, reportParams);
        }
      });
    });
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/minigame/const.js
var Platform;
(function (Platform) {
  Platform["devtools"] = "devtools";
  Platform["android"] = "android";
  Platform["ios"] = "ios";
  Platform["windows"] = "windows";
  Platform["mac"] = "mac";
})(Platform || (Platform = {}));
var const_DeviceOrientation;
(function (DeviceOrientation) {
  DeviceOrientation["portrait"] = "portrait";
  DeviceOrientation["landscape"] = "landscape";
  DeviceOrientation["landscapeLeft"] = "landscapeLeft";
  DeviceOrientation["landscapeRight"] = "landscapeRight";
})(const_DeviceOrientation || (const_DeviceOrientation = {}));
var EnvType;
(function (EnvType) {
  EnvType["DEVELOP"] = "develop";
  EnvType["TRIAL"] = "trial";
  EnvType["RELEASE"] = "release";
})(EnvType || (EnvType = {}));
var AppStateType;
(function (AppStateType) {
  AppStateType[AppStateType["release"] = 1] = "release";
  AppStateType[AppStateType["develop"] = 2] = "develop";
  AppStateType[AppStateType["trial"] = 3] = "trial";
})(AppStateType || (AppStateType = {}));
var RuntimeType;
(function (RuntimeType) {
  RuntimeType[RuntimeType["Android"] = 0] = "Android";
  RuntimeType[RuntimeType["IOSJscore"] = 1] = "IOSJscore";
  RuntimeType[RuntimeType["IOSWK"] = 2] = "IOSWK";
  RuntimeType[RuntimeType["UnKnow"] = 3] = "UnKnow";
  RuntimeType[RuntimeType["PC"] = 4] = "PC";
  RuntimeType[RuntimeType["Devtools"] = 5] = "Devtools";
  RuntimeType[RuntimeType["IPadJscore"] = 6] = "IPadJscore";
  RuntimeType[RuntimeType["IPadWK"] = 7] = "IPadWK";
})(RuntimeType || (RuntimeType = {}));
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/minigame/gameTransferReport.js



class GameTransferReport extends ReportBase {
  constructor({
    reportFunc,
    logid,
    schemas = {},
    base,
    reportType,
    asyncGetBase = () => Promise.resolve({}),
    debug,
    namespace = '',
    skipValidateInProdEnv = true
  }) {
    super({
      logid,
      schemas,
      base,
      debug,
      namespace,
      skipValidateInProdEnv
    });
    this.reportType = reportBase_ReportType.SvrReport;
    this.asyncGetBase = asyncGetBase;
    if (!reportFunc) {
      console.error(`[minigamefe${this.namespace}GameTransferReport]: 未传入上报函数。`);
    }
    this.reportFunc = reportFunc;
    if (reportType !== undefined) {
      this.reportType = reportType;
    }
  }
  setKvStatBase(info, accountInfo) {
    if (this.reportType === reportBase_ReportType.KvStat) {
      var system = (info.system || '').split(' ');
      Object.assign(this.schemas, {
        DeviceModel: ColumnType.STRING,
        DeviceBrand: ColumnType.STRING,
        OsName: ColumnType.STRING,
        OsVersion: ColumnType.STRING,
        LanguageVersion: ColumnType.STRING,
        Count: ColumnType.UINT,
        AppId: ColumnType.STRING,
        AppVersion: ColumnType.UINT,
        AppState: ColumnType.UINT
      });
      this.setBase({
        DeviceModel: info.model || '',
        DeviceBrand: info.brand || '',
        OsName: system[0] || '',
        OsVersion: system[1] || '',
        LanguageVersion: info.language || '',
        Count: 1
      });
      if (accountInfo === null || accountInfo === void 0 ? void 0 : accountInfo.miniProgram) {
        this.setBase({
          AppState: AppStateType[accountInfo.miniProgram.envVersion] || AppStateType.release,
          AppId: accountInfo.miniProgram.appId,
          AppVersion: 0
        });
      }
    }
  }
  send(rptList, callback) {
    if (!this.reportFunc || typeof this.reportFunc !== 'function') {
      console.error('[minigamefe GameTransferReport]: 未传入上报函数!!!');
      return;
    }
    var list = [];
    var getLogid = this.logid;
    var reportMsgs;
    if (!Array.isArray(rptList)) {
      reportMsgs = [rptList];
    } else {
      reportMsgs = rptList;
    }
    this.asyncGetBase().then(base => {
      this.setBase(base);
      reportMsgs.forEach(reportMsg => {
        var data = Object.assign(Object.assign({}, this.base), reportMsg);
        if (data.ExternInfo && typeof data.ExternInfo === 'object' && this.schemas.ExternInfo === ColumnType.STRING) {
          data.ExternInfo = encodeURIComponent(JSON.stringify(data.ExternInfo));
        }
        this.validate(data);
        if (this.reportType === reportBase_ReportType.KvStat) {
          var time = Math.floor(Date.now() / 1000);
          Object.assign(data, {
            StartTime: time,
            EndTime: time
          });
        }
        var msg = {
          log_id: this.logid,
          custom_data: data
        };
        list.push(msg);
        if (this.debug) {
          console.log(`[minigamefe${this.namespace}GameTransferReport]: ${getLogid},`, data);
        }
      });
      var reqBodyStr = {
        report_list: list
      };
      this.reportFunc({
        req_path: 'comm_datareport',
        json_data: JSON.stringify(reqBodyStr),
        success() {
          if (callback) {
            callback(getLogid, JSON.stringify(reqBodyStr));
          }
        },
        fail(err) {
          console.error(err);
          if (callback) {
            callback(getLogid, getErrMsg(err));
          }
        }
      });
    });
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/common/const.js
var CGI_URL = 'https://game.weixin.qq.com';
var SESSION_KEY = 'minigamefe_session_id';
var const_ELLIPSIS = '…';
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/minigame/requestReport.js




var reportCgiPath = '/cgi-bin/comm/datareport';
class RequestReport extends ReportBase {
  constructor({
    reportFunc,
    logid,
    schemas = {},
    base,
    debug,
    namespace,
    asyncGetBase = () => Promise.resolve({}),
    reportType,
    skipValidateInProdEnv = true
  }) {
    super({
      logid,
      schemas,
      base,
      debug,
      namespace,
      skipValidateInProdEnv
    });
    this.reportType = reportBase_ReportType.SvrReport;
    this.reportFunc = reportFunc;
    if (!reportFunc) {
      console.error(`[minigamefe${this.namespace}RequestReport]: 未传入上报函数。`);
    }
    this.asyncGetBase = asyncGetBase;
    if (reportType !== undefined) {
      this.reportType = reportType;
    }
  }
  setKvStatBase(info, accountInfo) {
    if (this.reportType === reportBase_ReportType.KvStat) {
      var system = (info.system || '').split(' ');
      Object.assign(this.schemas, {
        DeviceModel: ColumnType.STRING,
        DeviceBrand: ColumnType.STRING,
        OsName: ColumnType.STRING,
        OsVersion: ColumnType.STRING,
        LanguageVersion: ColumnType.STRING,
        Count: ColumnType.UINT,
        AppId: ColumnType.STRING,
        AppVersion: ColumnType.UINT,
        AppState: ColumnType.UINT
      });
      this.setBase({
        DeviceModel: info.model || '',
        DeviceBrand: info.brand || '',
        OsName: system[0] || '',
        OsVersion: system[1] || '',
        LanguageVersion: info.language || '',
        Count: 1
      });
      if (accountInfo === null || accountInfo === void 0 ? void 0 : accountInfo.miniProgram) {
        this.setBase({
          AppState: AppStateType[accountInfo.miniProgram.envVersion] || AppStateType.release,
          AppId: accountInfo.miniProgram.appId,
          AppVersion: 0
        });
      }
    }
  }
  send(rptList, callback) {
    if (!this.reportFunc || typeof this.reportFunc !== 'function') {
      console.error('[minigamefe RequestReport]: 未传入上报函数!!!');
      return;
    }
    var list = [];
    var getLogid = this.logid;
    var reportMsgs;
    if (!Array.isArray(rptList)) {
      reportMsgs = [rptList];
    } else {
      reportMsgs = rptList;
    }
    this.asyncGetBase().then(base => {
      this.setBase(base);
      reportMsgs.forEach(reportMsg => {
        var data = Object.assign(Object.assign({}, this.base), reportMsg);
        this.validate(data);
        var msg = {
          log_id: getLogid,
          custom_data: data
        };
        list.push(msg);
      });
      var reqBodyStr = JSON.stringify({
        report_list: list
      });
      if (this.debug) {
        console.log(`[minigamefe${this.namespace}RequestReport]: ${getLogid}`, ...list);
      }
      this.reportFunc({
        url: `${CGI_URL}${reportCgiPath}`,
        method: 'POST',
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        data: reqBodyStr,
        success() {
          if (callback) {
            callback(getLogid, JSON.stringify(reqBodyStr));
          }
        },
        fail(err) {
          console.error(err);
          if (callback) {
            callback(getLogid, getErrMsg(err));
          }
        }
      });
    });
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/report/configs/26340.js

var PROTOCOL_PARAMS = ['BenchmarkLevel', 'NetworkType', 'RuntimeType', 'PluginAppId', 'PluginVersion', 'Scene', 'SDKVersion', 'IsVisible', 'Type', 'Target', 'Params', 'Result', 'CostTime', 'ExternInfo', 'CustomKey1', 'CustomKey2', 'CustomKey3', 'IsError', 'FELibVersion', 'Query'];
var SCHEMAS = {
  BenchmarkLevel: ColumnType.UINT,
  NetworkType: ColumnType.STRING,
  RuntimeType: ColumnType.UINT,
  PluginAppId: ColumnType.STRING,
  PluginVersion: ColumnType.STRING,
  Scene: ColumnType.UINT,
  SDKVersion: ColumnType.STRING,
  IsVisible: ColumnType.UINT,
  Type: ColumnType.UINT,
  Target: ColumnType.STRING,
  Params: ColumnType.STRING,
  Result: ColumnType.STRING,
  CostTime: ColumnType.UINT,
  ExternInfo: ColumnType.STRING,
  CustomKey1: ColumnType.STRING,
  CustomKey2: ColumnType.STRING,
  CustomKey3: ColumnType.STRING,
  IsError: ColumnType.UINT,
  FELibVersion: ColumnType.STRING,
  Query: ColumnType.STRING
};
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/minigame/quality/report26340.js






function initReport26340(config) {
  var {
    type = QualityReportType.KeyValueReport,
    reportKeyValue,
    debug,
    gameTransfer,
    systemInfo,
    accountInfo,
    getNetworkType,
    onNetworkStatusChange,
    request,
    namespace
  } = config;
  var network = '';
  var reporter;
  function asyncGetBase() {
    return new Promise(resolve => {
      if (network) {
        resolve({
          NetworkType: network
        });
      } else {
        getNetworkType({
          success: res => {
            network = res.networkType;
            resolve({
              NetworkType: network
            });
          },
          fail: () => {
            network = 'unknown';
            resolve({
              NetworkType: network
            });
          }
        });
      }
    });
  }
  if (type === QualityReportType.KeyValueReport) {
    reporter = new KeyValueReporter({
      reportFunc: reportKeyValue,
      logid: 26340,
      schemas: SCHEMAS,
      protocolParams: PROTOCOL_PARAMS,
      debug,
      namespace,
      asyncGetBase
    });
  } else if (type === QualityReportType.GameTransferReport) {
    reporter = new GameTransferReport({
      reportFunc: gameTransfer,
      logid: 26340,
      schemas: SCHEMAS,
      reportType: reportBase_ReportType.KvStat,
      debug,
      namespace,
      asyncGetBase
    });
    reporter.setKvStatBase(systemInfo, accountInfo);
  } else {
    console.warn('[minigamefe]: 当前选择 reqeust 进行质量上报, 请自行确保兼容性');
    reporter = new RequestReport({
      reportFunc: request,
      logid: 26340,
      schemas: SCHEMAS,
      debug,
      namespace,
      asyncGetBase,
      reportType: reportBase_ReportType.KvStat
    });
    reporter.setKvStatBase(systemInfo, accountInfo);
  }
  if (type === QualityReportType.GameTransferReport || type === QualityReportType.WxRequestReport) {
    getNetworkTypeValue(type => {
      network = type;
      reporter.setBase({
        NetworkType: type
      });
    }, getNetworkType, onNetworkStatusChange);
  }
  return reporter;
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/minigame/utils.js

function getRuntimeType(systemInfo) {
  var _a, _b;
  var runtimeType = RuntimeType.UnKnow;
  var platform = systemInfo.platform.toLocaleLowerCase();
  if (platform === Platform.devtools) {
    runtimeType = RuntimeType.Devtools;
  } else if (platform === Platform.ios) {
    runtimeType = ((_a = __webpack_require__.g) === null || _a === void 0 ? void 0 : _a.isIOSHighPerformanceMode) ? RuntimeType.IOSWK : RuntimeType.IOSJscore;
    if (systemInfo.model.indexOf('iPad') > -1) {
      runtimeType = ((_b = __webpack_require__.g) === null || _b === void 0 ? void 0 : _b.isIOSHighPerformanceMode) ? RuntimeType.IPadWK : RuntimeType.IPadJscore;
    }
  } else if (platform === Platform.android) {
    runtimeType = RuntimeType.Android;
  } else if (platform === Platform.windows) {
    runtimeType = RuntimeType.PC;
  }
  return runtimeType;
}
var cacheSafeArea = null;
function getSafeArea(useCache = false, systemInfo) {
  if (useCache && cacheSafeArea) {
    return cacheSafeArea;
  }
  var {
    safeArea
  } = systemInfo;
  var {
    deviceOrientation,
    screenWidth,
    screenHeight
  } = systemInfo;
  if (!safeArea) {
    safeArea = {
      top: 0,
      left: 0,
      right: screenWidth,
      bottom: screenHeight,
      width: screenWidth,
      height: screenHeight
    };
  }
  var {
    left,
    top,
    right,
    bottom,
    width,
    height
  } = safeArea;
  if (screenWidth > screenHeight) {
    if (deviceOrientation === DeviceOrientation.portrait || width < height) {
      left = safeArea.top;
      top = safeArea.left;
      right = safeArea.bottom;
      bottom = safeArea.right;
      width = safeArea.height;
      height = safeArea.width;
    } else if (width === screenHeight && width > height) {
      top = 0;
      left = 0;
      right = screenWidth;
      bottom = screenHeight;
      width = screenWidth;
      height = screenHeight;
    }
  }
  cacheSafeArea = {
    left,
    top,
    right,
    bottom,
    width,
    height
  };
  return cacheSafeArea;
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/index.js
var VERSION = '1.1.51';
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/minigame/quality/util.js

function stringify(content, key) {
  var res = content || '';
  if (isObject(res)) {
    try {
      res = JSON.stringify(res);
    } catch (e) {
      console.error(`[minigamefe stringify error]: ${e}`);
      res = '';
    }
  } else {
    res = String(res);
  }
  if (res.length && res.length >= 1024) {
    res = res.substr(0, 1024);
    console.warn(`[minigamefe stringify warning]: ${key} 上报长度超过1024, 已裁剪`);
  }
  return res;
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/node_modules/@tencent/minigamefe/minigame/quality/index.js







class Quality {
  constructor(config) {
    var _a, _b, _c;
    this.benchmarkLevel = 0;
    this.network = '';
    this.runtimeType = RuntimeType.UnKnow;
    this.sdkVersion = '0.0.0';
    this.isVisible = IsVisible.Front;
    this.scene = 0;
    this.query = '';
    this.pluginAppId = '';
    this.pluginVersion = '';
    this.inited = false;
    var {
      systemInfo,
      launchInfo,
      onShow,
      onHide,
      pluginAppId = '',
      pluginVersion = ''
    } = config;
    if (!onShow || !onHide) {
      console.error('[minigamefe stringify warning]: please inject QualityConfig correctly');
      this.inited = false;
      return;
    }
    this.inited = true;
    this.onShow = onShow;
    this.onHide = onHide;
    this.benchmarkLevel = (systemInfo.benchmarkLevel || 1) + 100;
    this.sdkVersion = systemInfo.SDKVersion;
    this.launchInfo = launchInfo;
    this.scene = ((_a = this.launchInfo) === null || _a === void 0 ? void 0 : _a.scene) || 0;
    if (!isEmpty((_b = this.launchInfo) === null || _b === void 0 ? void 0 : _b.query)) {
      this.query = encodeURIComponent(JSON.stringify((_c = this.launchInfo) === null || _c === void 0 ? void 0 : _c.query));
    }
    this.runtimeType = getRuntimeType(systemInfo);
    this.pluginAppId = pluginAppId;
    this.pluginVersion = pluginVersion;
    this.bindNativeEvent();
    this.reporter = initReport26340(config);
    this.reporter.setBase({
      BenchmarkLevel: this.benchmarkLevel,
      RuntimeType: this.runtimeType,
      Scene: +this.scene,
      SDKVersion: this.sdkVersion,
      IsVisible: this.isVisible,
      PluginAppId: pluginAppId,
      PluginVersion: pluginVersion,
      FELibVersion: VERSION,
      Query: this.query
    });
  }
  bindNativeEvent() {
    this.onHide(() => {
      this.isVisible = IsVisible.Background;
      this.reporter.setBase({
        IsVisible: this.isVisible
      });
    });
    this.onShow(res => {
      if (!isEmpty(res === null || res === void 0 ? void 0 : res.query)) {
        this.query = encodeURIComponent(JSON.stringify(res.query));
      }
      this.isVisible = IsVisible.Front;
      this.reporter.setBase({
        IsVisible: this.isVisible,
        Query: this.query
      });
    });
  }
  innerReport(opt) {
    this.reporter.send(Object.assign(opt, {
      CostTime: isNumber(opt.CostTime) ? opt.CostTime : 0,
      Params: stringify(opt.Params, 'Params'),
      Result: stringify(opt.Result, 'Result'),
      ExternInfo: stringify(opt.ExternInfo, 'ExternInfo')
    }));
  }
  report(opt) {
    if (REPORT_TYPE_LIST.indexOf(opt.Type) > -1) {
      console.error(`[minigamefe quality report]: 若为自定义上报, Type 请不要使用内置枚举值 ${opt.Type}, 内置枚举可见 mgp.consts.ReportType`);
    }
    if (this.inited) {
      this.innerReport(opt);
    }
  }
  setCustomKey(info) {
    if (this.inited) {
      this.reporter.setBase({
        CustomKey1: info.CustomKey1 && stringify(info.CustomKey1, 'CustomKey1') || '',
        CustomKey2: info.CustomKey2 && stringify(info.CustomKey2, 'CustomKey2') || '',
        CustomKey3: info.CustomKey3 && stringify(info.CustomKey3, 'CustomKey3') || ''
      });
    }
  }
  clearCustomKey() {
    if (this.inited) {
      this.reporter.setBase({
        CustomKey1: '',
        CustomKey2: '',
        CustomKey3: ''
      });
    }
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/audit-reporter/report.ts



class AuditQuality {
  constructor() {
    this.quality = void 0;
    this.inited = false;
    this.initPromise = void 0;
    this.initPromise = this.initQuality();
  }
  initQuality() {
    return new Promise(resolve => {
      if (config_Config.sdk.WXConfig) {
        config_Config.sdk.WXConfig.onReady(() => {
          this.inited = true;
          this.quality = new Quality({
            debug: false,
            type: QualityReportType.KeyValueReport,
            pluginAppId: 'game_audits',
            pluginVersion: config_Config.sdk.WXConfig.SDKVersion,
            launchInfo: config_Config.sdk.WXConfig.appLaunchInfo,
            accountInfo: config_Config.sdk.WXConfig.accountInfo,
            systemInfo: config_Config.sdk.getSystemInfoSync(),
            onShow: config_Config.sdk.onShow,
            onHide: config_Config.sdk.onHide,
            getNetworkType: config_Config.sdk.getNetworkType,
            onNetworkStatusChange: config_Config.sdk.onNetworkStatusChange,
            gameTransfer: config_Config.sdk.gameTransfer,
            reportKeyValue: config_Config.sdk.reportKeyValue
          });
          resolve(this.quality);
        });
      }
    });
  }
  report(opt) {
    if (this.inited) {
      this.quality.report(opt);
    } else {
      this.initPromise.then(() => {
        this.quality.report(opt);
      });
    }
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/audit-reporter/index.ts




var qualityReporter = null;
function initReporter() {
  qualityReporter = new AuditQuality();
}
var commonExtra;
function getCommonExtra() {
  if (!commonExtra) {
    var _Config$sdk$WXConfig$;
    commonExtra = {
      autoStart: (_Config$sdk$WXConfig$ = config_Config.sdk.WXConfig.audits) === null || _Config$sdk$WXConfig$ === void 0 ? void 0 : _Config$sdk$WXConfig$.autoStart,
      enableType: EnableType.Self,
      showTimes: config_Config.showTimes,
      detectTimes: config_Config.detectTimes
    };
  }
  return commonExtra;
}
function auditLaunch() {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.Launch,
      ExternInfo: {
        subpackages: config_Config.sdk.WXConfig.subpackages,
        parallelPreloadSubpackages: config_Config.sdk.WXConfig.parallelPreloadSubpackages,
        ...getCommonExtra()
      }
    });
  }
}
function auditEnd() {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.End,
      ExternInfo: {
        detectTime: Date.now() - config_Config.meta.startTime,
        ...getCommonExtra()
      }
    });
  }
}
function writeReport({
  fileSize,
  costTime
}) {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.WriteReport,
      ExternInfo: {
        fileSize,
        costTime,
        ...getCommonExtra()
      }
    });
  }
}
function writeReportError({
  fileSize,
  errMsg
}) {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.WriteReport,
      ExternInfo: {
        fileSize,
        errMsg,
        ...getCommonExtra()
      }
    });
  }
}
function uploadReport({
  costTime,
  blobid
}) {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.UploadReport,
      ExternInfo: {
        costTime,
        blobid,
        ...getCommonExtra()
      }
    });
  }
}
function uploadReportError({
  errMsg
}) {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.UploadReport,
      ExternInfo: {
        errMsg,
        ...getCommonExtra()
      }
    });
  }
}
function addEveluationReport(costTime) {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.AddEveluationReport,
      ExternInfo: {
        costTime,
        ...getCommonExtra()
      }
    });
  }
}
function addEveluationReportError(errMsg) {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.AddEveluationReport,
      ExternInfo: {
        errMsg,
        ...getCommonExtra()
      }
    });
  }
}
function reportShow() {
  if (Config.isWxApplib) {
    qualityReporter.report({
      Type: PluginReportType.Info,
      Target: AuditReportType.OnShow,
      ExternInfo: {
        ...getCommonExtra()
      }
    });
  }
}
function reportHide() {
  if (Config.isWxApplib) {
    qualityReporter.report({
      Type: PluginReportType.Info,
      Target: AuditReportType.OnHide,
      ExternInfo: {
        ...getCommonExtra()
      }
    });
  }
}
function removeReportFile(costTime) {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.RemoveReportFile,
      ExternInfo: {
        costTime,
        ...getCommonExtra()
      }
    });
  }
}
function removeReportFileError(errMsg) {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.RemoveReportFile,
      ExternInfo: {
        errMsg,
        ...getCommonExtra()
      }
    });
  }
}
function reportGetAuthToken({
  token,
  costTime
}) {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.GetAuthToken,
      ExternInfo: {
        token,
        costTime,
        ...getCommonExtra()
      }
    });
  }
}
function reportGetAuthTokenError(errMsg) {
  if (config_Config.isWxApplib) {
    qualityReporter.report({
      Type: types_PluginReportType.Info,
      Target: report_AuditReportType.GetAuthToken,
      ExternInfo: {
        errMsg,
        ...getCommonExtra()
      }
    });
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/api/login.ts







var gameTransfer;
var authRequest;
var isSupportNoStringifyReqData = false;
var lastToken = '';
function setAuthFunc(params) {
  if (params.gameTransfer) {
    gameTransfer = params.gameTransfer;
    isSupportNoStringifyReqData = compareVersion(getAppBaseInfo().SDKVersion, '2.29.1') >= 0;
  }
  if (params.authRequest) {
    authRequest = params.authRequest;
  }
}
function resetToken() {
  lastToken = '';
}
var loginExpiredErrcode = -10000401;
function getAuthByGameTransfer() {
  return new Promise((resolve, reject) => {
    var url = 'unity.refreshcontexttoken';
    var requestData = {
      auth_payload: {}
    };
    if (lastToken) {
      return resolve(lastToken);
    }
    requestData.auth_payload.expired_time = 60;
    var reqOptions = {
      req_path: url,
      success: res => {
        var _data$rsp_list;
        var data = res.data;
        Logger.debug('auth res = ', res, ', data=', data);
        if (data !== null && data !== void 0 && (_data$rsp_list = data.rsp_list) !== null && _data$rsp_list !== void 0 && _data$rsp_list.length) {
          var token = (data.rsp_list.find(info => info.key === 'auth_token') || {}).value;
          if (token) {
            reportGetAuthToken({
              token,
              costTime: TimeLogger.timeEnd(report_AuditReportType.GetAuthToken)
            });
            Logger.debug('token=', token);
            lastToken = encodeURIComponent(token);
            return resolve(lastToken);
          }
        }
        var errMsg = 'system error';
        reportGetAuthTokenError(errMsg);
        reject({
          errMsg
        });
      },
      fail: err => {
        Logger.error('gametransfer auth error, ', err);
        TimeLogger.timeEnd(report_AuditReportType.GetAuthToken);
        reportGetAuthTokenError(err.errmsg || 'get auth token failed');
        reject(err);
      }
    };
    if (isSupportNoStringifyReqData) {
      reqOptions.reqData = {
        req_path: url,
        ...requestData
      };
      delete reqOptions.req_path;
    } else {
      reqOptions = {
        ...reqOptions,
        ...requestData
      };
    }
    if (gameTransfer) {
      TimeLogger.start(report_AuditReportType.GetAuthToken);
      gameTransfer(reqOptions);
    }
  });
}
function getAuthByAuthRequest() {
  return _getAuthByAuthRequest.apply(this, arguments);
}
function _getAuthByAuthRequest() {
  _getAuthByAuthRequest = asyncToGenerator_default()(function* () {
    if (authRequest) {
      var token = yield authRequest();
      lastToken = token;
      return Promise.resolve(lastToken);
    }
    return Promise.resolve();
  });
  return _getAuthByAuthRequest.apply(this, arguments);
}
function auth() {
  if (gameTransfer) {
    return getAuthByGameTransfer();
  }
  if (authRequest) {
    return getAuthByAuthRequest();
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/api/base.ts



var domain = 'https://game.weixin.qq.com';
var requestFunc;
var uploadFunc;
function setRequestFunction(params) {
  if (params.request) {
    requestFunc = params.request;
  } else {
    requestFunc = getGlobalWx().request;
  }
  if (params.uploadFile) {
    uploadFunc = params.uploadFile;
  } else {
    uploadFunc = getGlobalWx().uploadFile;
  }
  setAuthFunc(params);
}
function doRequest(options) {
  var _auth;
  Logger.debug(`before ${options.url} request, auth`);
  (_auth = auth()) === null || _auth === void 0 ? void 0 : _auth.then(token => {
    Logger.debug('request auth token=', token);
    if (options.url.includes('ticket')) {
      options.url = options.url.substring(0, options.url.indexOf('?ticket'));
    }
    options.url = `${options.url}?ticket=${token}`;
    Logger.debug('before request, options=', options);
    requestFunc(options);
  });
}
function doUpload(options) {
  var _auth2;
  Logger.debug(`before ${options.url} upload, auth`);
  (_auth2 = auth()) === null || _auth2 === void 0 ? void 0 : _auth2.then(token => {
    Logger.debug('upload auth token=', token);
    if (options.url.includes('ticket')) {
      options.url = options.url.substring(0, options.url.indexOf('?ticket'));
    }
    options.url = `${options.url}?ticket=${token}`;
    uploadFunc(options);
  });
}
function post(url, data) {
  return new Promise((resolve, reject) => {
    var requestOptions = {
      url: `${domain}${url}`,
      method: 'POST',
      data: {
        ...data
      },
      success: res => {
        Logger.debug(`post ${url} success, res=`, res);
        if (res.statusCode === 200) {
          if (res.data.errcode === loginExpiredErrcode) {
            resetToken();
            return doRequest(requestOptions);
          }
          return resolve(res.data);
        }
        return reject(res);
      },
      fail: err => {
        Logger.error(`post ${url} failed, err=`, err);
        reject(err);
      }
    };
    doRequest(requestOptions);
  });
}
function upload(params) {
  return new Promise((resolve, reject) => {
    var {
      url,
      filePath,
      name
    } = params;
    var uploadOptions = {
      url: `${domain}${url}`,
      filePath,
      name,
      success(res) {
        Logger.debug(`upload ${url} success, res=`, res);
        if (res.statusCode === 200) {
          var {
            data
          } = res;
          if (typeof data === 'string') {
            data = JSON.parse(data);
          }
          if (data.errcode === loginExpiredErrcode) {
            resetToken();
            return doUpload(uploadOptions);
          }
          return resolve(data);
        }
        return reject(res);
      },
      fail: err => {
        Logger.error(`post ${url} failed, err=`, err);
        reject(err);
      }
    };
    doUpload(uploadOptions);
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/api/index.ts

function addGameEveluationReport(metaInfo) {
  return post('/cgi-bin/gamewxagbdatawap/addgameevaluationreport', {
    meta_info: metaInfo
  });
}
function uploadEveluationReport(filePath) {
  return upload({
    url: '/cgi-bin/gamewxagbdatawap/uploadfile',
    filePath,
    name: 'file'
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/detect_common/model/base.ts
var base_Platform = /*#__PURE__*/function (Platform) {
  Platform[Platform["iOS"] = 1] = "iOS";
  Platform[Platform["Android"] = 2] = "Android";
  Platform[Platform["iPad"] = 13] = "iPad";
  Platform[Platform["Mac"] = 14] = "Mac";
  Platform[Platform["Windows"] = 15] = "Windows";
  Platform[Platform["AndroidPad"] = 28] = "AndroidPad";
  Platform[Platform["Devtools"] = -1] = "Devtools";
  return Platform;
}({});
var PlatformNameMap = {
  [base_Platform.iOS]: 'iOS',
  [base_Platform.Android]: 'Android',
  [base_Platform.iPad]: 'iPad',
  [base_Platform.Mac]: 'Mac',
  [base_Platform.Windows]: 'Windows',
  [base_Platform.AndroidPad]: 'AndrdoidPad',
  [base_Platform.Devtools]: 'Devtools'
};
var platformType = {
  ios: 1,
  android: 2,
  ipad: 13,
  mac: 14,
  windows: 15,
  devtools: -1
};
var TaskType = /*#__PURE__*/function (TaskType) {
  TaskType[TaskType["Launch"] = 0] = "Launch";
  TaskType[TaskType["Performance"] = 1] = "Performance";
  TaskType[TaskType["Practice"] = 2] = "Practice";
  TaskType[TaskType["Render"] = 3] = "Render";
  TaskType[TaskType["Compatibility"] = 4] = "Compatibility";
  return TaskType;
}({});
var CheckType = /*#__PURE__*/function (CheckType) {
  CheckType["Start"] = "start";
  CheckType["Performance"] = "performance";
  CheckType["Network"] = "network";
  CheckType["WxAPI"] = "wxapi";
  CheckType["Practice"] = "practice";
  CheckType["Compatibility"] = "compatibility";
  CheckType["Render"] = "render";
  return CheckType;
}({});
var StageType = /*#__PURE__*/function (StageType) {
  StageType["Init"] = "init";
  StageType["Resource"] = "resource";
  StageType["Inject"] = "inject";
  StageType["Context"] = "context";
  StageType["Compile"] = "compile";
  return StageType;
}({});
var StageName = /*#__PURE__*/function (StageName) {
  StageName["InitClickStart"] = "clickStart";
  StageName["InitContactCGI"] = "contactcgi";
  StageName["InitLaunchCGI"] = "launchcgi";
  StageName["ResourceApp"] = "resousceApp";
  StageName["ResourceSub"] = "resourceSub";
  StageName["ResoucePlugin"] = "reesourcePlugin";
  StageName["InjectGame"] = "injectGame";
  StageName["InjectWxAppLib"] = "injectWxAppLib";
  return StageName;
}({});
var LaunchSubItem = /*#__PURE__*/function (LaunchSubItem) {
  LaunchSubItem["longFirstMeaningfulPaint"] = "long-first-meaningful-paint";
  LaunchSubItem["longInteractionCost"] = "long-interaction-cost";
  return LaunchSubItem;
}({});
var PerformanceSubItem = /*#__PURE__*/function (PerformanceSubItem) {
  PerformanceSubItem["highCpuUsage"] = "high-cpu-usage";
  PerformanceSubItem["highMemoryUsage"] = "high-memory-usage";
  PerformanceSubItem["highAverageFps"] = "high-average-fps";
  PerformanceSubItem["highStutter"] = "high-stutter";
  return PerformanceSubItem;
}({});
var PracticeSubItem = /*#__PURE__*/function (PracticeSubItem) {
  PracticeSubItem["noIosHighPerformance"] = "no-ios-high-performance";
  PracticeSubItem["noHttp2"] = "no-http2";
  PracticeSubItem["noContentEncoding"] = "no-content-encoding";
  PracticeSubItem["noCdnCache"] = "no-cdn-cache";
  PracticeSubItem["noParallelDownload"] = "no-parallel-download";
  PracticeSubItem["noInteractionReport"] = "no-interaction-report";
  PracticeSubItem["largeNetworkResponse"] = "large-network-response";
  PracticeSubItem["lowNetworkLatencyRation"] = "low-network-latency-ration";
  PracticeSubItem["highNetworkQueueingLatency"] = "high-network-queueing-latency";
  PracticeSubItem["longSingleNetworkLatency"] = "long-single-network";
  PracticeSubItem["highSingleNetworkResponse"] = "high-single-network-response";
  PracticeSubItem["noCacheApiCall"] = "no-cache-api-call";
  return PracticeSubItem;
}({});
var RenderSubItem = /*#__PURE__*/function (RenderSubItem) {
  RenderSubItem["highDrawcall"] = "high-drawcall";
  RenderSubItem["noTextureCompression"] = "no-texture-compression";
  RenderSubItem["incorrectTextureCompressionFormat"] = "incorrect-texture-compression-format";
  RenderSubItem["unreleasedCanvas"] = "unreleased-canvas";
  return RenderSubItem;
}({});
var CompatibilitySubItem = /*#__PURE__*/function (CompatibilitySubItem) {
  CompatibilitySubItem["noJsError"] = "no-js-error";
  CompatibilitySubItem["noUnhandledRejection"] = "no-unhandled-rejection";
  CompatibilitySubItem["noNetworkError"] = "no-network-error";
  CompatibilitySubItem["noNetworkStatusError"] = "no-network-status-error";
  return CompatibilitySubItem;
}({});
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/detect_common/model/map.ts

var checkTypeMap = {
  [CheckType.Practice]: {
    type: CheckType.Practice,
    name: '最佳实践检测',
    description: '',
    subItems: []
  },
  [CheckType.Performance]: {
    type: CheckType.Performance,
    name: '运行性能',
    description: '',
    subItems: []
  },
  [CheckType.Start]: {
    type: CheckType.Start,
    name: '启动性能',
    description: '',
    subItems: []
  },
  [CheckType.WxAPI]: {
    type: CheckType.WxAPI,
    name: 'wx api',
    description: '',
    subItems: []
  },
  [CheckType.Network]: {
    type: CheckType.Network,
    name: '网络性能',
    description: '',
    subItems: []
  },
  [CheckType.Compatibility]: {
    type: CheckType.Compatibility,
    name: '兼容性',
    description: '',
    subItems: []
  },
  [CheckType.Render]: {
    type: CheckType.Render,
    name: '渲染',
    description: '',
    subItems: []
  }
};
var checkTypeInfoMap = {
  [TaskType.Launch]: {
    [LaunchSubItem.longFirstMeaningfulPaint]: {
      metaInfo: {
        name: '首帧渲染时长过长',
        description: '降低小游戏的启动时长对于用户新进留存具有非常重要的价值。',
        document: [{
          title: '了解更多',
          href: 'https://developers.weixin.qq.com/minigame/dev/guide/performance/perf-action-start2.html'
        }],
        weight: 8
      },
      headers: [{
        key: 'cost',
        header: '首屏时间',
        uint: 'ms'
      }],
      threshold: 5150
    },
    [LaunchSubItem.longInteractionCost]: {
      metaInfo: {
        name: '游戏可交互时长过长',
        description: '建议优化游戏启动过程，尽可能减少游戏前置的资源下载，缩短游戏可交互时间，提升用户体验。',
        document: [{
          title: '了解更多',
          href: 'https://developers.weixin.qq.com/minigame/dev/guide/performance/perf-action-start-reportScene.html'
        }],
        weight: 3
      },
      headers: [{
        key: 'costTime',
        header: '可交互耗时',
        uint: 'ms'
      }],
      threshold: 11840
    }
  },
  [TaskType.Performance]: {
    [PerformanceSubItem.highCpuUsage]: {
      metaInfo: {
        name: 'CPU利用率过高',
        description: 'CPU利用率过高较易引起游戏卡顿等问题，建议通过CPU Profile工具排查长耗时逻辑，通过worker等方式优化相关业务逻辑。',
        document: [{
          title: '问题排查工具',
          href: 'https://developers.weixin.qq.com/minigame/dev/devtools/profile.html'
        }],
        weight: 7
      },
      headers: [{
        key: 'cpu',
        header: '平均CPU利用率',
        uint: '%'
      }],
      threshold: 30
    },
    [PerformanceSubItem.highMemoryUsage]: {
      metaInfo: {
        name: '内存占用过高',
        description: '游戏内存占用过高是影响游戏稳定性的最大因素，建议通过相关工具游戏内存问题。',
        document: [{
          title: '常见内存优化手段',
          href: 'https://developers.weixin.qq.com/minigame/dev/guide/performance/perf-action-memory-overview.html'
        }],
        weight: 7
      },
      headers: [{
        key: 'memory',
        header: '平均内存占用',
        uint: 'MB'
      }],
      threshold: 650 * 1024
    },
    [PerformanceSubItem.highAverageFps]: {
      metaInfo: {
        name: '帧率过低',
        description: '较低的帧率将直接影响游戏体验的流畅度，可通过CPU Profile针对游戏场景排查长耗时任务，定位卡顿原因。',
        document: [{
          title: '问题排查工具',
          href: 'https://developers.weixin.qq.com/minigame/dev/devtools/profile.html'
        }],
        weight: 5
      },
      headers: [{
        key: 'fps',
        header: '平均FPS'
      }],
      threshold: 50
    },
    [PerformanceSubItem.highStutter]: {
      metaInfo: {
        name: '卡顿率过高',
        description: '较高的卡顿率将影响游戏用户的实际游玩体验，可考虑适当降低帧率、优化游戏业务逻辑等手段来降低游戏卡顿问题。',
        document: [],
        weight: 7
      },
      headers: [{
        key: 'stutter',
        header: '卡顿率',
        uint: '%'
      }],
      threshold: 1.5
    }
  },
  [TaskType.Practice]: {
    [PracticeSubItem.noIosHighPerformance]: {
      metaInfo: {
        name: '高性能模式',
        description: '建议开启高性能模式，iOS设备下能拥有更好的渲染性能和表现。',
        weight: 0,
        document: [{
          title: '了解更多',
          href: 'https://developers.weixin.qq.com/minigame/dev/guide/performance/perf-high-performance.html'
        }]
      },
      threshold: true
    },
    [PracticeSubItem.noHttp2]: {
      metaInfo: {
        name: 'HTTP/2',
        description: '建议服务器开启HTTP2.0，通过多路复用和头部压缩等的特性，能提升细碎文件的下载效率。',
        weight: 8
      },
      headers: [{
        key: 'url',
        header: 'URL'
      }, {
        key: 'protocol',
        header: '协议'
      }],
      threshold: true
    },
    [PracticeSubItem.noContentEncoding]: {
      metaInfo: {
        name: '服务器压缩',
        description: '建议开启服务器压缩，尽可能对传输数据进行压缩，减少网络数据的传输体积。',
        document: [{
          title: '了解更多',
          href: 'https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Content-Encoding'
        }],
        weight: 10
      },
      headers: [{
        key: 'url',
        header: 'URL'
      }, {
        key: 'contentEncoding',
        header: 'content-encoding'
      }],
      threshold: true
    },
    [PracticeSubItem.noCdnCache]: {
      metaInfo: {
        name: 'CDN缓存',
        description: '发布新版本时，建议进行CDN预热，避免直接从源站拉取资源。',
        weight: 10
      },
      headers: [{
        key: 'url',
        header: 'URL'
      }],
      threshold: true
    },
    [PracticeSubItem.noParallelDownload]: {
      metaInfo: {
        name: '并行下载',
        description: '建议开启小游戏分包的并行下载能力，提前下载后续游戏必要的分包资源，减少用户后续等待分包资源下载的时间，缩短用户进入游戏核心玩法的耗时。',
        document: [{
          title: '了解更多',
          href: 'https://developers.weixin.qq.com/minigame/dev/guide/performance/perf-action-start-parallel-download.html'
        }],
        weight: 0
      },
      threshold: true
    },
    [PracticeSubItem.noInteractionReport]: {
      metaInfo: {
        name: '游戏可交互上报',
        description: '建议在游戏资源加载完毕时，上报用户的最早可操作游戏画面的时间点，用于统计游戏启动性能表现以及游戏启动留存情况。',
        document: [{
          title: '了解更多',
          href: 'https://developers.weixin.qq.com/minigame/dev/guide/performance/perf-action-start-reportScene.html'
        }],
        weight: 3
      },
      threshold: true
    },
    [PracticeSubItem.largeNetworkResponse]: {
      metaInfo: {
        name: '网络请求总响应过大',
        description: '减小网络请求资源量，过大的资源下载会增加用户启动耗时。',
        weight: 5
      },
      headers: [{
        key: 'byteLength',
        header: '总响应大小',
        uint: 'MB'
      }],
      threshold: 50 * 1024 * 1024
    },
    [PracticeSubItem.lowNetworkLatencyRation]: {
      metaInfo: {
        name: '网络利用率',
        description: '网络利用率过低，未能在CPU密集时段，充分利用网络带宽。',
        weight: 6
      },
      headers: [{
        key: 'networkLatencyRation',
        header: '网络利用率',
        uint: '%'
      }],
      threshold: 30
    },
    [PracticeSubItem.highNetworkQueueingLatency]: {
      metaInfo: {
        name: '网络排队平均耗时',
        description: '网络排队平均耗时过高，排队超过一定时长会对用户体验造成影响。可以考虑使用CDN加速、使用HTTP/2协议等技术，减少网络请求的延迟时间。',
        weight: 6
      },
      headers: [{
        key: 'networkQueueingLatency',
        header: '平均网络排队耗时',
        uint: 'ms'
      }],
      threshold: 1500
    },
    [PracticeSubItem.longSingleNetworkLatency]: {
      metaInfo: {
        name: '单个网络耗时过长',
        description: '单个网络耗时过长，耗时过长会对用户体验造成影响。可以考虑使用CDN加速、使用HTTP/2协议等技术，减少网络请求的延迟时间。',
        weight: 8
      },
      headers: [{
        key: 'url',
        header: 'URL'
      }, {
        key: 'callbackDuration',
        header: '网络耗时',
        uint: 'ms'
      }],
      threshold: 1500
    },
    [PracticeSubItem.highSingleNetworkResponse]: {
      metaInfo: {
        name: '单个网络请求资源量过大',
        description: '网络请求体积大会导致请求的传输时间变长，影响用户体验。可适当将资源拆分进行按需下载、或使用数据压缩。',
        weight: 8
      },
      headers: [{
        key: 'url',
        header: 'URL'
      }, {
        key: 'byteLength',
        header: '响应大小',
        uint: 'MB'
      }],
      threshold: 3 * 1024 * 1024
    },
    [PracticeSubItem.noCacheApiCall]: {
      metaInfo: {
        name: 'wx api调用缓存',
        description: '建议在调用API时，使用缓存，减少API的重复调用次数，提升用户体验。',
        weight: 5
      },
      headers: [{
        key: 'apiName',
        header: '接口名称'
      }, {
        key: 'times',
        header: '调用次数'
      }],
      threshold: 3
    }
  },
  [TaskType.Render]: {
    [RenderSubItem.highDrawcall]: {
      metaInfo: {
        name: 'Drawcall过高',
        description: '建议使用合适手段减少Drawcall调用次数，大量、频繁的绘制请求，会一定程度上降低游戏帧率，造成游戏卡顿等问题',
        weight: 5
      },
      headers: [{
        key: 'drawcall',
        header: '峰值drawcall'
      }],
      threshold: 200
    },
    [RenderSubItem.noTextureCompression]: {
      metaInfo: {
        name: '未使用纹理压缩',
        description: '建议针对纹理资源，使用压缩格式，减少纹理大小，提升用户体验。',
        weight: 0
      },
      headers: [{
        key: 'asset',
        header: '资源名'
      }, {
        key: 'format',
        header: '压缩格式'
      }],
      threshold: true
    },
    [RenderSubItem.incorrectTextureCompressionFormat]: {
      metaInfo: {
        name: '未使用合理的纹理压缩',
        description: '建议使用合理的压缩格式，减少纹理大小，提升用户体验。',
        document: [{
          title: '常见纹理压缩格式兼容性',
          href: 'https://developers.weixin.qq.com/minigame/dev/guide/performance/perf-technical-manual.html'
        }],
        weight: 0
      },
      headers: [{
        key: 'asset',
        header: '资源名'
      }, {
        key: 'format',
        header: '压缩格式'
      }]
    },
    [RenderSubItem.unreleasedCanvas]: {
      metaInfo: {
        name: '未释放Canvas',
        description: '建议主动释放Canvas实例，减少内存占用，特别是在iOS设备下，过高的内存占用较为容易造成内存不足而导致小游戏被kill的问题。',
        weight: 0
      },
      headers: [{
        key: 'count',
        header: '未释放canvas数'
      }]
    }
  },
  [TaskType.Compatibility]: {
    [CompatibilitySubItem.noJsError]: {
      metaInfo: {
        name: '存在JavaScript Exception',
        description: '出现 JavaScript 异常可能导致程序的交互无法进行下去，我们应当追求零异常，保证程序的高鲁棒性和高可用性',
        weight: 9
      },
      headers: [{
        key: 'message',
        header: '错误信息'
      }, {
        key: 'stack',
        header: '错误堆栈'
      }]
    },
    [CompatibilitySubItem.noUnhandledRejection]: {
      metaInfo: {
        name: '存在Unhandled Promise Rejection',
        description: '处理 Unhandled Promise Rejection，我们可以使程序更稳定。',
        weight: 9
      },
      headers: [{
        key: 'reason',
        header: '错误信息'
      }]
    },
    [CompatibilitySubItem.noNetworkError]: {
      metaInfo: {
        name: '存在网络错误',
        description: '处理网络错误有助于提高用户体验',
        weight: 10
      },
      headers: [{
        key: 'url',
        header: 'URL'
      }, {
        key: 'errMsg',
        header: '错误信息'
      }]
    },
    [CompatibilitySubItem.noNetworkStatusError]: {
      metaInfo: {
        name: '存在网络状态码错误',
        description: '处理网络错误有助于提高用户体验',
        weight: 10
      },
      headers: [{
        key: 'url',
        header: 'URL'
      }, {
        key: 'statusCode',
        header: '状态码'
      }]
    }
  }
};
var getRuleIdInfo = () => {
  var flatCheckTypeInfoMap = {};
  Object.keys(checkTypeInfoMap).forEach(categoryKeyName => {
    flatCheckTypeInfoMap = {
      ...flatCheckTypeInfoMap,
      ...checkTypeInfoMap[categoryKeyName]
    };
  });
  return flatCheckTypeInfoMap;
};
var ruleIdInfoMap = getRuleIdInfo();
var checkTypeCustomInfoMap = {
  [CheckType.Start]: {
    description: '依据小游戏启动耗时指标评估游戏启动过程中潜在的问题。'
  },
  [CheckType.Performance]: {
    description: '依据小游戏运行过程中的CPU、内存峰值、FPS、卡顿率均值等指标，评估游戏运行过程中潜在的问题。'
  },
  [CheckType.Render]: {
    description: '依据小游戏渲染性能指标，评估游戏渲染性能问题。'
  },
  [CheckType.Practice]: {
    description: '结合平台历史开发经验和常用优化手段，帮助开发者在开发阶段针对常见问题进行优化，以使游戏达到更好的性能表现。'
  },
  [CheckType.Compatibility]: {
    description: '根据小游戏运行过程中的JS错误数、Promise错误等指标，评估游戏运行过程中潜在的问题。'
  }
};
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/detect_common/model/index.ts



;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/detect_common/index.ts


;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/trace/api.ts



class ApiTrace extends Singleton {
  constructor(...args) {
    super(...args);
    this.invokeList = [];
    this.recordApi = generalInvokeInfo => {
      this.invokeList.push(generalInvokeInfo.invokeInfo);
    };
  }
  init() {
    messenger.on(ApiInvokeMessageType.Invoked, this.recordApi);
  }
  off() {
    messenger.off(ApiInvokeMessageType.Invoked, this.recordApi);
  }
  getResult() {
    return {
      invokeList: this.invokeList
    };
  }
  reset() {
    this.invokeList = [];
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/trace/fmp.ts


class FMPTrace extends Singleton {
  constructor(...args) {
    super(...args);
    this.fmp = {};
    this.recordFMP = () => {};
  }
  init() {}
  off() {}
  getResult() {
    this.fmp = {
      [StageType.Init]: [{
        stageName: StageName.InitClickStart,
        stageType: StageType.Init,
        startTime: 0,
        endTime: 0,
        delta: 0
      }],
      [StageType.Resource]: [{
        stageName: StageName.ResourceApp,
        stageType: StageType.Resource,
        startTime: 0,
        endTime: 0,
        delta: 0,
        size: 0,
        resourceName: 'app'
      }],
      [StageType.Inject]: [{
        stageName: StageName.InjectGame,
        stageType: StageType.Inject,
        startTime: 0,
        endTime: 0,
        delta: 0,
        resouceName: 'app',
        evaluateStartTime: 0
      }],
      [StageType.Context]: [{
        stageType: StageType.Context,
        startTime: 0,
        endTime: 0,
        delta: 0,
        contextId: 0,
        contextName: 'main'
      }],
      [StageType.Compile]: [{
        stageType: StageType.Compile,
        startTime: 0,
        endTime: 0,
        delta: 0
      }]
    };
    return this.fmp;
  }
  reset() {
    this.fmp = null;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/trace/network.ts



class NetworkTrace extends Singleton {
  constructor(...args) {
    super(...args);
    this.networkList = [];
    this.recordNetwork = params => {
      var {
        generalNetworkInfo
      } = params;
      if (generalNetworkInfo) {
        var {
          networkInfo,
          invokeInfoMap
        } = generalNetworkInfo;
        var generalInvokeInfo = invokeInfoMap.get(generalNetworkInfo);
        if (generalInvokeInfo) {
          var {
            invokeInfo
          } = generalInvokeInfo;
          this.networkList.push(Object.assign({}, networkInfo, invokeInfo));
        }
      }
    };
  }
  init() {
    messenger.on(NetworkMessageType.LoadSuccess, this.recordNetwork);
    messenger.on(NetworkMessageType.LoadFail, this.recordNetwork);
  }
  off() {
    messenger.off(NetworkMessageType.LoadSuccess, this.recordNetwork);
    messenger.off(NetworkMessageType.LoadFail, this.recordNetwork);
  }
  getResult() {
    return {
      networkList: this.networkList
    };
  }
  reset() {
    this.networkList = [];
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/trace/performance.ts



class PerformanceTrace extends Singleton {
  constructor(...args) {
    super(...args);
    this.performanceList = [];
    this.recordPerformance = generalPerformanceInfo => {
      this.performanceList.push(generalPerformanceInfo.performanceInfo);
    };
  }
  init() {
    messenger.on(PerformanceMessageType.Received, this.recordPerformance);
  }
  off() {
    messenger.off(PerformanceMessageType.Received, this.recordPerformance);
  }
  getResult() {
    return {
      performanceList: this.performanceList
    };
  }
  reset() {
    this.performanceList = [];
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/base-task.ts

class BaseTask extends Singleton {
  constructor(...args) {
    super(...args);
    this.metaInfo = void 0;
    this.failedItems = [];
    this.ruleId = void 0;
    this.threshold = void 0;
    this.headers = void 0;
    this.enable = false;
  }
  addFailedItem(item) {
    if (item) {
      this.failedItems.push(item);
    }
  }
  addFailedItems(items) {
    items.forEach(item => {
      this.addFailedItem(item);
    });
  }
  generateResult() {
    var result = Object.assign(Object.create(null), {
      ruleId: this.ruleId,
      failedItems: this.failedItems
    });
    if (this.headers) {
      result.headers = this.headers;
    }
    if (this.metaInfo) {
      Object.assign(result, this.metaInfo);
    }
    return result;
  }
  clear() {
    this.failedItems = [];
  }
  init() {}
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/no-cdn-cache.ts






class NoCdnCache extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PracticeSubItem.noCdnCache;
    this.threshold = checkTypeInfoMap[TaskType.Practice][this.ruleId].threshold;
    this.handler = params => {
      if (!this.check(params)) {
        var _params$generalNetwor;
        Logger.warn(`check ${this.ruleId} failed current=`, (_params$generalNetwor = params.generalNetworkInfo) === null || _params$generalNetwor === void 0 ? void 0 : _params$generalNetwor.networkInfo.url);
        this.addFailedItem(this.generateItem(params));
      }
    };
  }
  init() {
    messenger.on(NetworkMessageType.LoadSuccess, this.handler);
  }
  off() {
    messenger.off(NetworkMessageType.LoadSuccess, this.handler);
  }
  check(params) {
    var {
      generalNetworkInfo
    } = params;
    if (!generalNetworkInfo) {
      return true;
    }
    return generalNetworkInfo.networkInfo.cache === this.threshold;
  }
  generateItem(params) {
    var {
      generalNetworkInfo
    } = params;
    if (generalNetworkInfo) {
      var _generalNetworkInfo$i;
      return {
        uniqueId: (_generalNetworkInfo$i = generalNetworkInfo.invokeInfoMap.get(generalNetworkInfo)) === null || _generalNetworkInfo$i === void 0 ? void 0 : _generalNetworkInfo$i.invokeInfo.uniqueId
      };
    }
    return null;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/no-content-encoding.ts







class NoContentEncoding extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PracticeSubItem.noContentEncoding;
    this.threshold = checkTypeInfoMap[TaskType.Practice][this.ruleId].threshold;
    this.handler = params => {
      if (!this.check(params)) {
        var _params$generalNetwor;
        Logger.warn(`check ${this.ruleId} failed, current=`, (_params$generalNetwor = params.generalNetworkInfo) === null || _params$generalNetwor === void 0 ? void 0 : _params$generalNetwor.networkInfo.url);
        this.addFailedItem(this.generateItem(params));
      }
    };
  }
  init() {
    messenger.on(NetworkMessageType.LoadSuccess, this.handler);
  }
  off() {
    messenger.off(NetworkMessageType.LoadSuccess, this.handler);
  }
  check(params) {
    var {
      generalNetworkInfo
    } = params;
    var passed = true;
    if (!generalNetworkInfo) {
      return passed;
    }
    var res = generalNetworkInfo.result;
    var {
      contentEncoding
    } = generalNetworkInfo.networkInfo;
    if (isSuccessStatusCode(res.statusCode) && contentEncoding) {
      passed = contentEncoding.includes('gzip') || contentEncoding.includes('br');
    }
    return passed === this.threshold;
  }
  generateItem(params) {
    var {
      generalNetworkInfo
    } = params;
    if (generalNetworkInfo) {
      var _generalNetworkInfo$i;
      return {
        uniqueId: (_generalNetworkInfo$i = generalNetworkInfo.invokeInfoMap.get(generalNetworkInfo)) === null || _generalNetworkInfo$i === void 0 ? void 0 : _generalNetworkInfo$i.invokeInfo.uniqueId
      };
    }
    return null;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/no-http2.ts







class NoHttp2 extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PracticeSubItem.noHttp2;
    this.threshold = checkTypeInfoMap[TaskType.Practice][this.ruleId].threshold;
    this.handler = params => {
      if (!this.check(params)) {
        var _params$generalNetwor;
        Logger.warn(`check ${this.ruleId} failed, current=`, (_params$generalNetwor = params.generalNetworkInfo) === null || _params$generalNetwor === void 0 ? void 0 : _params$generalNetwor.networkInfo.url, params.args);
        this.addFailedItem(this.generateItem(params));
      }
    };
  }
  init() {
    messenger.on(NetworkMessageType.LoadSuccess, this.handler);
  }
  off() {
    messenger.off(NetworkMessageType.LoadSuccess, this.handler);
  }
  check(params) {
    var {
      generalNetworkInfo
    } = params;
    var passed = true;
    if (!generalNetworkInfo) {
      return passed;
    }
    var res = generalNetworkInfo.result;
    var {
      networkInfo
    } = generalNetworkInfo;
    if (isSuccessStatusCode(res.statusCode) && networkInfo.protocol) {
      var _networkInfo$protocol, _networkInfo$protocol2;
      passed = networkInfo.protocol === 'h2' || ((_networkInfo$protocol = networkInfo.protocol) === null || _networkInfo$protocol === void 0 ? void 0 : (_networkInfo$protocol2 = _networkInfo$protocol.includes) === null || _networkInfo$protocol2 === void 0 ? void 0 : _networkInfo$protocol2.call(_networkInfo$protocol, 'http/2'));
    }
    return passed === this.threshold;
  }
  generateItem(params) {
    var {
      generalNetworkInfo
    } = params;
    if (generalNetworkInfo) {
      var _generalNetworkInfo$i;
      return {
        uniqueId: (_generalNetworkInfo$i = generalNetworkInfo.invokeInfoMap.get(generalNetworkInfo)) === null || _generalNetworkInfo$i === void 0 ? void 0 : _generalNetworkInfo$i.invokeInfo.uniqueId
      };
    }
    return null;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/high-network-queueing-latency.ts







class HighNetworkQueueingLatency extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PracticeSubItem.highNetworkQueueingLatency;
    this.threshold = checkTypeInfoMap[TaskType.Practice][this.ruleId].threshold;
    this.averageQueueTime = 0;
    this.handler = () => {
      if (!this.check()) {
        Logger.warn(`check ${PracticeSubItem.highNetworkQueueingLatency} failed, current=`, this.averageQueueTime, ', threshold=', this.threshold);
        this.addFailedItem(this.generateItem());
      }
    };
  }
  init() {
    messenger.on(DetectEventMessageType.BeforeResult, this.handler);
  }
  off() {
    messenger.off(DetectEventMessageType.BeforeResult, this.handler);
  }
  check() {
    var {
      totalQueueCount,
      totalQueueTime
    } = networkTaskManager.networkInfo;
    if (totalQueueCount) {
      this.averageQueueTime = totalQueueTime / totalQueueCount;
    }
    return this.averageQueueTime < this.threshold;
  }
  generateItem() {
    return {
      networkQueueingLatency: this.averageQueueTime
    };
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/high-single-network-response.ts







class HighSingleNetworkResponse extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PracticeSubItem.highSingleNetworkResponse;
    this.threshold = checkTypeInfoMap[TaskType.Practice][this.ruleId].threshold;
    this.handler = params => {
      if (!this.check(params)) {
        var _params$generalNetwor;
        Logger.warn(`check ${this.ruleId} failed, current=`, (_params$generalNetwor = params.generalNetworkInfo) === null || _params$generalNetwor === void 0 ? void 0 : _params$generalNetwor.networkInfo.byteLength, ', threshold=', this.threshold);
        this.addFailedItem(this.generateItem(params));
      }
    };
  }
  init() {
    messenger.on(NetworkMessageType.LoadSuccess, this.handler);
  }
  off() {
    messenger.off(NetworkMessageType.LoadSuccess, this.handler);
  }
  check(params) {
    var {
      generalNetworkInfo
    } = params;
    var passed = true;
    if (!generalNetworkInfo) {
      return passed;
    }
    var res = generalNetworkInfo.result;
    var {
      byteLength
    } = generalNetworkInfo.networkInfo;
    if (isSuccessStatusCode(res.statusCode) && byteLength) {
      passed = byteLength < this.threshold;
    }
    return passed;
  }
  generateItem(params) {
    var {
      generalNetworkInfo
    } = params;
    if (generalNetworkInfo) {
      var _generalNetworkInfo$i;
      return {
        uniqueId: (_generalNetworkInfo$i = generalNetworkInfo.invokeInfoMap.get(generalNetworkInfo)) === null || _generalNetworkInfo$i === void 0 ? void 0 : _generalNetworkInfo$i.invokeInfo.uniqueId
      };
    }
    return null;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/large-network-response.ts







class LargeNetworkResponse extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PracticeSubItem.largeNetworkResponse;
    this.threshold = checkTypeInfoMap[TaskType.Practice][this.ruleId].threshold;
    this.handler = () => {
      if (!this.check()) {
        Logger.warn('check large-network-response failed, current=', networkTaskManager.networkInfo.responseSize, ', threshold=', this.threshold);
        this.addFailedItem(this.generateItem());
      }
    };
  }
  init() {
    messenger.on(DetectEventMessageType.BeforeResult, this.handler);
  }
  off() {
    messenger.off(DetectEventMessageType.BeforeResult, this.handler);
  }
  check() {
    return networkTaskManager.networkInfo.responseSize < this.threshold;
  }
  generateItem() {
    return {
      byteLength: networkTaskManager.networkInfo.responseSize
    };
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/long-single-network-latency.ts







class LongSingleNetworkLatency extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PracticeSubItem.longSingleNetworkLatency;
    this.threshold = checkTypeInfoMap[TaskType.Practice][this.ruleId].threshold;
    this.handler = params => {
      if (!this.check(params)) {
        var {
          generalNetworkInfo
        } = params;
        var generalInvokeInfo = generalNetworkInfo === null || generalNetworkInfo === void 0 ? void 0 : generalNetworkInfo.invokeInfoMap.get(generalNetworkInfo);
        Logger.warn(`check ${PracticeSubItem.longSingleNetworkLatency} failed, current=`, generalInvokeInfo === null || generalInvokeInfo === void 0 ? void 0 : generalInvokeInfo.invokeInfo.callbackDuration, ', threshold=', this.threshold);
        this.addFailedItem(this.generateItem(params));
      }
    };
  }
  init() {
    messenger.on(NetworkMessageType.LoadSuccess, this.handler);
  }
  off() {
    messenger.off(NetworkMessageType.LoadSuccess, this.handler);
  }
  check(params) {
    var {
      generalNetworkInfo
    } = params;
    var passed = true;
    if (!generalNetworkInfo) {
      return passed;
    }
    var res = generalNetworkInfo.result;
    var generalInvokeInfo = generalNetworkInfo.invokeInfoMap.get(generalNetworkInfo);
    if (generalInvokeInfo) {
      var {
        invokeInfo: {
          callbackDuration
        }
      } = generalInvokeInfo;
      if (isSuccessStatusCode(res.statusCode) && callbackDuration) {
        passed = callbackDuration < this.threshold;
      }
    }
    return passed;
  }
  generateItem(params) {
    var {
      generalNetworkInfo
    } = params;
    if (generalNetworkInfo) {
      var _generalNetworkInfo$i;
      return {
        uniqueId: (_generalNetworkInfo$i = generalNetworkInfo.invokeInfoMap.get(generalNetworkInfo)) === null || _generalNetworkInfo$i === void 0 ? void 0 : _generalNetworkInfo$i.invokeInfo.uniqueId
      };
    }
    return null;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/no-interaction-report.ts






class NoInteractionReport extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PracticeSubItem.noInteractionReport;
    this.threshold = checkTypeInfoMap[TaskType.Practice][this.ruleId].threshold;
    this.reported = false;
    this.handler = () => {
      if (!this.check()) {
        Logger.warn(`check ${this.ruleId} failed, current=`, this.reported);
        this.addFailedItem(this.generateItem());
      }
    };
    this.reportInteractionHandler = () => {
      this.reported = true;
    };
  }
  init() {
    messenger.on(DetectEventMessageType.BeforeResult, this.handler);
    messenger.on(ApiInvokeMessageType.ReportInteraction, this.reportInteractionHandler);
  }
  off() {
    messenger.off(DetectEventMessageType.BeforeResult, this.handler);
    messenger.off(ApiInvokeMessageType.ReportInteraction, this.reportInteractionHandler);
  }
  generateItem() {
    return {
      passed: false
    };
  }
  check() {
    return this.reported === this.threshold;
  }
  clear() {
    super.clear();
    this.reported = false;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/no-ios-high-performance.ts







class NoIosHighPerformance extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PracticeSubItem.noIosHighPerformance;
    this.iosHighPerformance = true;
    this.threshold = checkTypeInfoMap[TaskType.Practice][this.ruleId].threshold;
    this.handler = () => {
      if (!this.check()) {
        Logger.warn(`check ${this.ruleId} failed, current=`, this.iosHighPerformance);
        this.addFailedItem(this.generateItem());
      }
    };
  }
  init() {
    messenger.on(DetectEventMessageType.Start, this.handler);
  }
  off() {
    messenger.off(DetectEventMessageType.Start, this.handler);
  }
  generateItem() {
    return {
      passed: false
    };
  }
  check() {
    this.iosHighPerformance = config_Config.iOSHighPerformance;
    return this.iosHighPerformance === this.threshold;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/no-parallel-download.ts







class NoParallelDownload extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PracticeSubItem.noParallelDownload;
    this.parallelDownload = true;
    this.threshold = checkTypeInfoMap[TaskType.Practice][this.ruleId].threshold;
    this.handler = () => {
      if (!this.check()) {
        Logger.warn(`check ${this.ruleId} failed, current=`, this.parallelDownload);
        this.addFailedItem(this.generateItem());
      }
    };
  }
  init() {
    messenger.on(DetectEventMessageType.Start, this.handler);
  }
  off() {
    messenger.off(DetectEventMessageType.Start, this.handler);
  }
  generateItem() {
    return {
      passed: false
    };
  }
  check() {
    var _Config$subpackages, _Config$parallelPrelo;
    return ((_Config$subpackages = config_Config.subpackages) === null || _Config$subpackages === void 0 ? void 0 : _Config$subpackages.length) && ((_Config$parallelPrelo = config_Config.parallelPreloadSubpackages) === null || _Config$parallelPrelo === void 0 ? void 0 : _Config$parallelPrelo.length);
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/practice/index.ts












function registerTasks() {
  NoCdnCache.getInstance().init();
  NoContentEncoding.getInstance().init();
  NoHttp2.getInstance().init();
  HighNetworkQueueingLatency.getInstance().init();
  HighSingleNetworkResponse.getInstance().init();
  LargeNetworkResponse.getInstance().init();
  LongSingleNetworkLatency.getInstance().init();
  NoInteractionReport.getInstance().init();
  NoIosHighPerformance.getInstance().init();
  NoParallelDownload.getInstance().init();
}
function offTasks() {
  NoCdnCache.getInstance().off();
  NoContentEncoding.getInstance().off();
  NoHttp2.getInstance().off();
  HighNetworkQueueingLatency.getInstance().off();
  HighSingleNetworkResponse.getInstance().off();
  LargeNetworkResponse.getInstance().off();
  LongSingleNetworkLatency.getInstance().off();
  NoInteractionReport.getInstance().off();
  NoIosHighPerformance.getInstance().off();
  NoParallelDownload.getInstance().off();
}
function getResult() {
  var practiceResult = checkTypeMap[CheckType.Practice];
  practiceResult.subItems = [NoCdnCache.getInstance().generateResult(), NoContentEncoding.getInstance().generateResult(), NoHttp2.getInstance().generateResult(), HighNetworkQueueingLatency.getInstance().generateResult(), HighSingleNetworkResponse.getInstance().generateResult(), LargeNetworkResponse.getInstance().generateResult(), LongSingleNetworkLatency.getInstance().generateResult(), NoInteractionReport.getInstance().generateResult(), NoIosHighPerformance.getInstance().generateResult(), NoParallelDownload.getInstance().generateResult()];
  return practiceResult;
}
function practice_reset() {
  NoCdnCache.getInstance().clear();
  NoContentEncoding.getInstance().clear();
  NoHttp2.getInstance().clear();
  HighNetworkQueueingLatency.getInstance().clear();
  HighSingleNetworkResponse.getInstance().clear();
  LargeNetworkResponse.getInstance().clear();
  LongSingleNetworkLatency.getInstance().clear();
  NoInteractionReport.getInstance().clear();
  NoIosHighPerformance.getInstance().clear();
  NoParallelDownload.getInstance().clear();
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/launch/long-interaction-cost.ts






class LongInteractionCost extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = LaunchSubItem.longInteractionCost;
    this.threshold = checkTypeInfoMap[TaskType.Launch][this.ruleId].threshold;
    this.handler = params => {
      if (!this.check(params)) {
        Logger.warn(`check ${this.ruleId} failed, current=`, params.costTime, ', threshold=', this.threshold);
        this.addFailedItem(this.generateItem(params));
      }
    };
  }
  init() {
    messenger.on(ApiInvokeMessageType.ReportInteraction, this.handler);
  }
  off() {
    messenger.off(ApiInvokeMessageType.ReportInteraction, this.handler);
  }
  check(params) {
    var {
      costTime,
      sceneId
    } = params;
    if (sceneId && sceneId === 7) {
      if (costTime) {
        return costTime < this.threshold;
      }
    }
    return true;
  }
  generateItem(params) {
    return params;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/launch/index.ts



function launch_registerTasks() {
  LongInteractionCost.getInstance().init();
}
function launch_offTasks() {
  LongInteractionCost.getInstance().off();
}
function launch_getResult() {
  var launchResult = checkTypeMap[CheckType.Start];
  launchResult.subItems = [LongInteractionCost.getInstance().generateResult()];
  return launchResult;
}
function launch_reset() {
  LongInteractionCost.getInstance().clear();
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/performance/high-average-fps.ts






class HighAverageFps extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PerformanceSubItem.highAverageFps;
    this.threshold = checkTypeInfoMap[TaskType.Performance][this.ruleId].threshold;
    this.handler = generalPerformanceInfo => {
      if (!this.check(generalPerformanceInfo)) {
        Logger.warn(`check ${this.ruleId} failed, current=`, generalPerformanceInfo.performanceInfo.fps, ', threshold=', this.threshold);
        this.addFailedItem(this.generateItem(generalPerformanceInfo));
      }
    };
  }
  init() {
    messenger.on(PerformanceMessageType.Received, this.handler);
  }
  off() {
    messenger.off(PerformanceMessageType.Received, this.handler);
  }
  check(generalPerformanceInfo) {
    var {
      performanceInfo
    } = generalPerformanceInfo;
    return performanceInfo.fps > this.threshold;
  }
  generateItem(generalPerformanceInfo) {
    return {
      fps: generalPerformanceInfo.performanceInfo.fps,
      uniqueId: generalPerformanceInfo.performanceInfo.uniqueId
    };
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/performance/high-cpu-usage.ts






class HighCpuUsage extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PerformanceSubItem.highCpuUsage;
    this.threshold = checkTypeInfoMap[TaskType.Performance][this.ruleId].threshold;
    this.handler = generalPerformanceInfo => {
      if (!this.check(generalPerformanceInfo)) {
        Logger.warn(`check ${this.ruleId} failed, current=`, generalPerformanceInfo.performanceInfo.cpu, ', threshold=', this.threshold);
        this.addFailedItem(this.generateItem(generalPerformanceInfo));
      }
    };
  }
  init() {
    messenger.on(PerformanceMessageType.Received, this.handler);
  }
  off() {
    messenger.off(PerformanceMessageType.Received, this.handler);
  }
  check(generalPerformanceInfo) {
    var {
      performanceInfo
    } = generalPerformanceInfo;
    return performanceInfo.cpu < this.threshold;
  }
  generateItem(generalPerformanceInfo) {
    return {
      cpu: generalPerformanceInfo.performanceInfo.cpu,
      uniqueId: generalPerformanceInfo.performanceInfo.uniqueId
    };
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/performance/high-memory-usage.ts






class HighMemoryUsage extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PerformanceSubItem.highMemoryUsage;
    this.threshold = checkTypeInfoMap[TaskType.Performance][this.ruleId].threshold;
    this.handler = generalPerformanceInfo => {
      if (!this.check(generalPerformanceInfo)) {
        Logger.warn(`check ${this.ruleId} failed, current=`, generalPerformanceInfo.performanceInfo.memory, ', threshold=', this.threshold);
        this.addFailedItem(this.generateItem(generalPerformanceInfo));
      }
    };
  }
  init() {
    messenger.on(PerformanceMessageType.Received, this.handler);
  }
  off() {
    messenger.off(PerformanceMessageType.Received, this.handler);
  }
  check(generalPerformanceInfo) {
    var {
      performanceInfo
    } = generalPerformanceInfo;
    return performanceInfo.memory < this.threshold;
  }
  generateItem(generalPerformanceInfo) {
    return {
      memory: generalPerformanceInfo.performanceInfo.memory,
      uniqueId: generalPerformanceInfo.performanceInfo.uniqueId
    };
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/performance/high-stutter.ts






class HighStutter extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = PerformanceSubItem.highStutter;
    this.threshold = checkTypeInfoMap[TaskType.Performance][this.ruleId].threshold;
    this.handler = generalPerformanceInfo => {
      if (!this.check(generalPerformanceInfo)) {
        Logger.warn(`check ${this.ruleId} failed, current=`, generalPerformanceInfo.performanceInfo.stutter, ', threshold=', this.threshold);
        this.addFailedItem(this.generateItem(generalPerformanceInfo));
      }
    };
  }
  init() {
    messenger.on(PerformanceMessageType.Received, this.handler);
  }
  off() {
    messenger.off(PerformanceMessageType.Received, this.handler);
  }
  check(generalPerformanceInfo) {
    var {
      performanceInfo
    } = generalPerformanceInfo;
    return performanceInfo.stutter < this.threshold;
  }
  generateItem(generalPerformanceInfo) {
    return {
      stutter: generalPerformanceInfo.performanceInfo.stutter,
      uniqueId: generalPerformanceInfo.performanceInfo.uniqueId
    };
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/performance/index.ts






function performance_registerTasks() {
  HighAverageFps.getInstance().init();
  HighCpuUsage.getInstance().init();
  HighMemoryUsage.getInstance().init();
  HighStutter.getInstance().init();
}
function performance_offTasks() {
  HighAverageFps.getInstance().off();
  HighCpuUsage.getInstance().off();
  HighMemoryUsage.getInstance().off();
  HighStutter.getInstance().off();
}
function performance_getResult() {
  var performanceResult = checkTypeMap[CheckType.Performance];
  performanceResult.subItems = [HighAverageFps.getInstance().generateResult(), HighCpuUsage.getInstance().generateResult(), HighMemoryUsage.getInstance().generateResult(), HighStutter.getInstance().generateResult()];
  return performanceResult;
}
function performance_reset() {
  HighAverageFps.getInstance().clear();
  HighCpuUsage.getInstance().clear();
  HighMemoryUsage.getInstance().clear();
  HighStutter.getInstance().clear();
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/render/drawcall.ts






class Drawcall extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = RenderSubItem.highDrawcall;
    this.drawcall = 0;
    this.latestFrame = 0;
    this.threshold = checkTypeInfoMap[TaskType.Render][this.ruleId].threshold;
    this.handler = () => {
      this.drawcall += 1;
      if (!this.latestFrame) {
        this.latestFrame = timer.currentFrame;
      }
      if (timer.currentFrame !== this.latestFrame) {
        if (!this.check()) {
          this.addFailedItem(this.generateItem());
        }
        this.latestFrame = 0;
        this.drawcall = 0;
      }
    };
  }
  init() {
    messenger.on(RenderTypeMessageType.Drawcall, this.handler);
  }
  off() {
    messenger.off(RenderTypeMessageType.Drawcall, this.handler);
  }
  check() {
    return this.drawcall < this.threshold;
  }
  generateItem() {
    return {
      drawcall: this.drawcall
    };
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/render/index.ts



function render_registerTasks() {
  Drawcall.getInstance().init();
}
function render_offTasks() {
  Drawcall.getInstance().off();
}
function render_getResult() {
  var renderResult = checkTypeMap[CheckType.Render];
  renderResult.subItems = [Drawcall.getInstance().generateResult()];
  return renderResult;
}
function render_reset() {
  Drawcall.getInstance().clear();
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/compatibility/no-js-error.ts







class NoJsError extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = CompatibilitySubItem.noJsError;
    this.threshold = checkTypeInfoMap[TaskType.Compatibility][this.ruleId].threshold;
    this.handler = params => {
      Logger.warn(`check ${this.ruleId} failed, current=`, params.message);
      this.addFailedItem(this.generateItem(params));
    };
  }
  init() {
    messenger.on(ApiInvokeMessageType.JsError, this.handler);
  }
  off() {
    messenger.off(ApiInvokeMessageType.JsError, this.handler);
  }
  generateItem(params) {
    return {
      message: String.prototype.slice.call(params.message, 0, 1024),
      stack: String.prototype.slice.call(params.stack, 0, 1024),
      frame: timer.currentFrame,
      runtime: timer.getRuntime()
    };
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/compatibility/no-unhandled-promise-rejection.ts







class NoUnhandledRejection extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = CompatibilitySubItem.noUnhandledRejection;
    this.threshold = checkTypeInfoMap[TaskType.Compatibility][this.ruleId].threshold;
    this.handler = params => {
      Logger.warn(`check ${this.ruleId} failed, current=`, params.reason);
      this.addFailedItem(this.generateItem(params));
    };
  }
  init() {
    messenger.on(ApiInvokeMessageType.UnhandledPromiseRejection, this.handler);
  }
  off() {
    messenger.off(ApiInvokeMessageType.UnhandledPromiseRejection, this.handler);
  }
  generateItem(params) {
    return {
      reason: String.prototype.slice.call(params.reason, 0, 1024),
      frame: timer.currentFrame,
      runtime: timer.getRuntime()
    };
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/compatibility/no-network-error.ts






class NoNetworkError extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = CompatibilitySubItem.noNetworkError;
    this.threshold = checkTypeInfoMap[TaskType.Compatibility][this.ruleId].threshold;
    this.handler = params => {
      Logger.warn(`check ${this.ruleId} failed, info=`, params);
      this.addFailedItem(this.generateItem(params));
    };
  }
  init() {
    messenger.on(NetworkMessageType.LoadFail, this.handler);
  }
  off() {
    messenger.off(NetworkMessageType.LoadFail, this.handler);
  }
  generateItem(params) {
    var {
      generalNetworkInfo
    } = params;
    if (generalNetworkInfo) {
      var _generalNetworkInfo$i;
      var invokeInfo = (_generalNetworkInfo$i = generalNetworkInfo.invokeInfoMap.get(generalNetworkInfo)) === null || _generalNetworkInfo$i === void 0 ? void 0 : _generalNetworkInfo$i.invokeInfo;
      return {
        uniqueId: invokeInfo === null || invokeInfo === void 0 ? void 0 : invokeInfo.uniqueId
      };
    }
    return null;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/compatibility/no-network-status-error.ts







class NoNetworkStatusError extends BaseTask {
  constructor(...args) {
    super(...args);
    this.ruleId = CompatibilitySubItem.noNetworkStatusError;
    this.threshold = checkTypeInfoMap[TaskType.Compatibility][this.ruleId].threshold;
    this.handler = params => {
      if (!this.check(params)) {
        Logger.warn(`check ${this.ruleId} failed, info=`, params);
        this.addFailedItem(this.generateItem(params));
      }
    };
  }
  init() {
    messenger.on(NetworkMessageType.LoadSuccess, this.handler);
  }
  off() {
    messenger.off(NetworkMessageType.LoadSuccess, this.handler);
  }
  check(params) {
    var {
      generalNetworkInfo
    } = params;
    var passed = true;
    if (!generalNetworkInfo) {
      return passed;
    }
    var res = generalNetworkInfo.result;
    if (!isSuccessStatusCode(res.statusCode)) {
      passed = false;
    }
    return passed;
  }
  generateItem(params) {
    var {
      generalNetworkInfo
    } = params;
    if (generalNetworkInfo) {
      var _generalNetworkInfo$i;
      var invokeInfo = (_generalNetworkInfo$i = generalNetworkInfo.invokeInfoMap.get(generalNetworkInfo)) === null || _generalNetworkInfo$i === void 0 ? void 0 : _generalNetworkInfo$i.invokeInfo;
      return {
        uniqueId: invokeInfo === null || invokeInfo === void 0 ? void 0 : invokeInfo.uniqueId
      };
    }
    return null;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/compatibility/index.ts






function compatibility_registerTasks() {
  NoJsError.getInstance().init();
  NoUnhandledRejection.getInstance().init();
  NoNetworkError.getInstance().init();
  NoNetworkStatusError.getInstance().init();
}
function compatibility_offTasks() {
  NoJsError.getInstance().off();
  NoUnhandledRejection.getInstance().off();
  NoNetworkError.getInstance().off();
  NoNetworkStatusError.getInstance().off();
}
function compatibility_getResult() {
  var compatibilityResult = checkTypeMap[CheckType.Compatibility];
  compatibilityResult.subItems = [NoJsError.getInstance().generateResult(), NoUnhandledRejection.getInstance().generateResult(), NoNetworkError.getInstance().generateResult(), NoNetworkStatusError.getInstance().generateResult()];
  return compatibilityResult;
}
function compatibility_reset() {
  NoJsError.getInstance().clear();
  NoUnhandledRejection.getInstance().clear();
  NoNetworkError.getInstance().clear();
  NoNetworkStatusError.getInstance().clear();
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/controller/result.ts





















class ResultManager extends Singleton {
  constructor(...args) {
    super(...args);
    this.deviceInfo = void 0;
    this.result = void 0;
    this.resultFilename = '__detect_result.txt';
  }
  reset() {
    this.result = null;
  }
  getDeviceInfo() {
    var _this = this;
    return asyncToGenerator_default()(function* () {
      var deviceInfo = getDeviceInfo();
      var appBaseInfo = getAppBaseInfo();
      if (!_this.deviceInfo && deviceInfo && appBaseInfo) {
        var networkType = yield _this.getNetworkType();
        _this.deviceInfo = {
          platform: platformType[deviceInfo.platform],
          wechatVersion: appBaseInfo.version,
          deviceBrand: deviceInfo.brand,
          deviceModel: _this.convertDeviceModel(deviceInfo.model),
          SDKVersion: appBaseInfo.SDKVersion,
          osName: deviceInfo.system,
          osVersion: deviceInfo.system,
          memorySize: deviceInfo.memorySize,
          benchmarkLevel: deviceInfo.benchmarkLevel,
          networkType
        };
      }
      return _this.deviceInfo;
    })();
  }
  uploadReport() {
    var _this2 = this;
    return asyncToGenerator_default()(function* () {
      return _this2.addEveluationReport(_this2.getResult());
    })();
  }
  getNetworkType() {
    return new Promise((resolve, reject) => {
      getGlobalWx().getNetworkType({
        success(res) {
          resolve(res.networkType);
        },
        fail: reject
      });
    });
  }
  addEveluationReport(result) {
    var _this3 = this;
    return asyncToGenerator_default()(function* () {
      var [, filePath] = yield awaitWrap(_this3.storeResult(result));
      if (filePath) {
        TimeLogger.start(report_AuditReportType.UploadReport);
        var [uploadErr, blobId] = yield awaitWrap(_this3.uploadEveluationReport(filePath));
        if (uploadErr) {
          TimeLogger.timeEnd(report_AuditReportType.UploadReport);
          uploadReportError((uploadErr === null || uploadErr === void 0 ? void 0 : uploadErr.errMsg) || (uploadErr === null || uploadErr === void 0 ? void 0 : uploadErr.statusCode) || uploadErr);
          Logger.error('upload error, ', uploadErr);
          UIController.getInstance().showUploadFailed(uploadErr, true);
          return Promise.reject(uploadErr);
        }
        if (blobId) {
          var _Config$audits;
          Logger.event('upload success, ', blobId);
          uploadReport({
            blobid: blobId,
            costTime: TimeLogger.timeEnd(report_AuditReportType.UploadReport)
          });
          TimeLogger.start(report_AuditReportType.AddEveluationReport);
          var [addErr, addRes] = yield awaitWrap(addGameEveluationReport({
            device: _this3.convertDeviceInfo(result.device),
            start_time: config_Config.meta.startTime,
            blob_id: blobId,
            end_time: config_Config.meta.endTime,
            official_desc: (config_Config === null || config_Config === void 0 ? void 0 : (_Config$audits = config_Config.audits) === null || _Config$audits === void 0 ? void 0 : _Config$audits.systemDescription) || ''
          }));
          if (addRes && addRes.errcode === 0) {
            addEveluationReport(TimeLogger.timeEnd(report_AuditReportType.AddEveluationReport));
            Logger.debug('addGameEveluationReport success, ', addRes);
            Logger.event('addGameEveluationReport success');
            UIController.getInstance().showUploadSuccess();
            _this3.removeResult();
            return Promise.resolve();
          }
          addEveluationReportError((addErr === null || addErr === void 0 ? void 0 : addErr.errMsg) || (addRes === null || addRes === void 0 ? void 0 : addRes.errcode));
          Logger.error('addEveluation error, ', addErr || addRes);
          UIController.getInstance().showUploadFailed(addErr || addRes);
          return Promise.reject(addErr || addRes);
        }
      }
    })();
  }
  uploadEveluationReport(filePath) {
    return uploadEveluationReport(filePath).then(res => {
      if (res.data && res.data.file_meta_list) {
        return Promise.resolve(res.data.file_meta_list[0].blob_id);
      }
      return Promise.reject(res.errcode);
    });
  }
  storeResult(result) {
    return new Promise((resolve, reject) => {
      var {
        wxapi,
        network,
        performance,
        checkLists,
        fmp
      } = result;
      var fileSize = 0;
      try {
        TimeLogger.start('stringifyResult');
        fileSize = JSON.stringify(result).length;
        Logger.debug('report fileSize=', fileSize, ', cost=', TimeLogger.timeEnd('stringifyResult'));
      } catch (error) {
        Logger.error('calculate report fileSize error, ', error);
      }
      var filePath = `${getGlobalWx().env.USER_DATA_PATH}/${this.resultFilename}`;
      TimeLogger.start(report_AuditReportType.WriteReport);
      getWriteFile()({
        filePath,
        data: JSON.stringify({
          wxapi,
          network,
          performance,
          checkLists,
          fmp
        }),
        success: () => {
          writeReport({
            fileSize,
            costTime: TimeLogger.timeEnd(report_AuditReportType.WriteReport)
          });
          resolve(filePath);
        },
        fail: err => {
          writeReportError({
            fileSize,
            errMsg: err.errMsg
          });
          reject(err);
        }
      });
    });
  }
  removeResult() {
    return new Promise((resolve, reject) => {
      var filePath = `${getGlobalWx().env.USER_DATA_PATH}/${this.resultFilename}`;
      TimeLogger.start(report_AuditReportType.RemoveReportFile);
      getRemoveFile()({
        filePath,
        success: res => {
          removeReportFile(TimeLogger.timeEnd(report_AuditReportType.RemoveReportFile));
          resolve(res);
        },
        fail: err => {
          removeReportFileError(err.errMsg);
          reject(err);
        }
      });
    });
  }
  getResult() {
    if (!this.result) {
      var wxapi = ApiTrace.getInstance().getResult();
      var network = NetworkTrace.getInstance().getResult();
      var performance = PerformanceTrace.getInstance().getResult();
      var fmp = FMPTrace.getInstance().getResult();
      var practiceResult = getResult();
      var launchResult = launch_getResult();
      var performanceResult = performance_getResult();
      var renderResult = render_getResult();
      var compatibilityResult = compatibility_getResult();
      config_Config.meta.uploadTime = Date.now();
      this.result = {
        meta: config_Config.meta,
        device: this.deviceInfo,
        wxapi,
        network,
        performance,
        checkLists: [practiceResult, launchResult, performanceResult, renderResult, compatibilityResult],
        fmp
      };
    }
    Logger.debug('result=', this.result);
    return this.result;
  }
  convertDeviceInfo(deviceInfo) {
    if (!deviceInfo) {
      return {};
    }
    var {
      platform,
      wechatVersion: wechat_version,
      deviceBrand: device_brand,
      deviceModel: device_model,
      SDKVersion: sdk_version,
      osName: os_name,
      osVersion: os_version,
      benchmarkLevel: benchmark_level,
      memorySize: memory_size,
      networkType: network_type
    } = deviceInfo;
    return {
      platform,
      wechat_version,
      device_brand,
      device_model,
      sdk_version,
      os_name,
      os_version,
      benchmark_level,
      memory_size,
      network_type
    };
  }
  convertDeviceModel(deviceModel) {
    if (deviceModel !== null && deviceModel !== void 0 && deviceModel.includes('unknown') && config_Config.sdk.WXConfig.platform === 'ios') {
      if (deviceModel.includes('<iPhone15,4>')) {
        return 'iPhone 15';
      }
      if (deviceModel.includes('<iPhone15,5>')) {
        return 'iPhone 15 Plus';
      }
      if (deviceModel.includes('<iPhone16,1>')) {
        return 'iPhone 15 Pro';
      }
      if (deviceModel.includes('<iPhone16,2>')) {
        return 'iPhone 15 Pro Max';
      }
    }
    return deviceModel;
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/ui/index.ts







class UIController extends Singleton {
  constructor(...args) {
    super(...args);
    this.coverview = void 0;
    this.ui = void 0;
    this.inited = false;
    this.draged = false;
    this.screenWidth = 0;
    this.screenHeight = 0;
    this.defaultWidth = defaultWidth;
    this.defaultHeight = defaultHeight;
    this.defaultTop = 60;
    this.defaultTopPortrait = 200;
    this.defaultLeft = 0;
    this.deviceOrientation = 'portrait';
  }
  init(coverview) {
    if (this.inited) {
      return;
    }
    this.inited = true;
    if (coverview) {
      this.coverview = coverview;
      setTimeout(() => {
        this.create();
      }, 1000);
    }
  }
  create() {
    if (this.coverview) {
      var {
        Component,
        getPrivateThis,
        init,
        webviewLayout,
        xmlParser
      } = this.coverview;
      this.ui = new Component();
      var privateThis = getPrivateThis(this.ui);
      var xdom = xmlParser(template).root;
      var realStyle = JSON.parse(JSON.stringify(style));
      var operateBtn = getElementsById(xdom, 'operate-btn');
      var systemInfo = getGlobalWx().getSystemInfoSync();
      this.setDeviceOrientation(systemInfo);
      if (src.autoStart) {
        operateBtn.attributes.value = '录制中...';
        realStyle.operateBtn.color = '#ff6146';
        realStyle.startIcon.hidden = true;
        realStyle.stopIcon.hidden = false;
      } else {
        operateBtn.attributes.value = '开始录制';
        realStyle.operateBtn.color = '#ffffff';
        realStyle.stopIcon.hidden = true;
        realStyle.startIcon.hidden = false;
      }
      this.setOperateBtnPos(realStyle, systemInfo);
      init.call(this.ui, xdom, realStyle);
      webviewLayout.add(privateThis.body);
      this.bindClick(privateThis);
    }
  }
  setOperateBtnPos(realStyle, systemInfo) {
    var {
      deviceOrientation
    } = this;
    var offsetSize = deviceOrientation === 'landscape' || deviceOrientation === 'landscapeLeft' ? systemInfo.safeArea.left || systemInfo.safeArea.top : 0;
    if (deviceOrientation === 'portrait' || deviceOrientation === 'landscapeRight') {
      realStyle.body.top = this.defaultTopPortrait;
      realStyle.body.left = this.defaultLeft;
    }
    if (deviceOrientation === 'landscape' || deviceOrientation === 'landscapeLeft') {
      realStyle.body.top = this.defaultTop;
      realStyle.body.left = this.defaultLeft + offsetSize;
    }
  }
  setDeviceOrientation(systemInfo) {
    var deviceOrientation = systemInfo.deviceOrientation;
    var width = systemInfo.windowWidth;
    var height = systemInfo.windowHeight;
    if (deviceOrientation === 'portrait' && width > height) {
      if (width > height) {
        deviceOrientation = 'landscape';
        width = systemInfo.windowHeight;
        height = systemInfo.windowWidth;
      }
    } else {
      if (width < height) {
        deviceOrientation = 'portrait';
        width = systemInfo.windowHeight;
        height = systemInfo.windowWidth;
      }
    }
    this.deviceOrientation = deviceOrientation;
    this.screenWidth = width;
    this.screenHeight = height;
    return this.deviceOrientation;
  }
  bindDragEvent(privateThis) {
    privateThis.touchMask.on('touchstart', e => {
      this.beforeDrag(privateThis);
      var offsetX = e.x - privateThis.container.style.left;
      var offsetY = e.y - privateThis.container.style.top;
      var touchMove = touches => {
        this.draged = true;
        var x = touches[0].x - offsetX;
        var y = touches[0].y - offsetY;
        var maxX = this.screenWidth - this.defaultWidth;
        var maxY = this.screenHeight - this.defaultHeight;
        privateThis.container.style.left = Math.max(0, Math.min(x, maxX));
        privateThis.container.style.top = Math.max(0, Math.min(y, maxY));
      };
      var touchEnd = () => {
        privateThis.touchMask.off('touchmove', touchMove);
        privateThis.touchMask.off('touchend', touchEnd);
        if (!this.draged) {
          if (src.isRunning) {
            this.showConfirm();
          } else {
            this.setRunning();
          }
        }
        this.draged = false;
        this.afterDrag(privateThis);
      };
      privateThis.touchMask.on('touchmove', touchMove);
      privateThis.touchMask.on('touchend', touchEnd);
    });
  }
  bindClick(privateThis) {
    bindClick(privateThis.touchMask, () => {
      if (src.isRunning) {
        this.showConfirm();
      } else {
        this.setRunning();
      }
    });
  }
  beforeDrag(privateThis) {
    privateThis.container.style.opacity = 0;
    privateThis.body.style.width = this.screenWidth;
    privateThis.body.style.height = this.screenHeight;
    privateThis.container.style.left = privateThis.body.style.left;
    privateThis.container.style.top = privateThis.body.style.top;
    privateThis.touchMask.style.left = privateThis.body.style.left;
    privateThis.touchMask.style.top = privateThis.body.style.top;
    privateThis.body.style.top = 0;
    privateThis.body.style.left = 0;
    privateThis.container.style.opacity = 1;
  }
  afterDrag(privateThis) {
    privateThis.container.style.hidden = true;
    privateThis.body.style.left = privateThis.container.style.left;
    privateThis.body.style.top = privateThis.container.style.top;
    privateThis.body.style.height = this.defaultHeight;
    privateThis.body.style.width = this.defaultWidth;
    privateThis.container.style.left = 0;
    privateThis.container.style.top = 0;
    privateThis.touchMask.style.left = 0;
    privateThis.touchMask.style.top = 0;
    privateThis.container.style.hidden = false;
  }
  setRunning() {
    src.start();
    if (this.coverview) {
      var {
        getPrivateThis
      } = this.coverview;
      var privateThis = getPrivateThis(this.ui);
      privateThis.operateBtn.value = '录制中...';
      privateThis.operateBtn.style.color = '#ff6146';
      privateThis.startIcon.style.hidden = true;
      privateThis.stopIcon.style.hidden = false;
    }
  }
  setStop() {
    if (this.coverview) {
      var {
        getPrivateThis
      } = this.coverview;
      var privateThis = getPrivateThis(this.ui);
      privateThis.operateBtn.value = '开始录制';
      privateThis.operateBtn.style.color = '#ffffff';
      privateThis.stopIcon.style.hidden = true;
      privateThis.startIcon.style.hidden = false;
    }
    getGlobalWx().showLoading({
      title: '上传中...'
    });
    src.stop();
  }
  showConfirm() {
    getGlobalWx().showModal({
      title: '是否结束录制并上传本次评测数据？',
      content: '将会根据上传数据分析得出录制期间的性能报告',
      confirmText: '上传数据',
      success: res => {
        if (res.confirm) {
          this.setStop();
        }
      }
    });
  }
  showUploadSuccess() {
    getGlobalWx().hideLoading();
    getGlobalWx().showModal({
      title: '数据上传成功',
      content: '请前往性能结果页面，查看详细性能测评报告',
      showCancel: false,
      confirmText: '我知道了'
    });
  }
  showUploadFailed(res, isUpload = false) {
    getGlobalWx().hideLoading();
    var isErrcode = typeof res === 'number';
    var errMsg = res;
    if (!isErrcode) {
      var {
        statusCode
      } = res;
      var {
        errcode
      } = res;
      errMsg = statusCode || errcode || res.errno;
    }
    getGlobalWx().showModal({
      title: isUpload ? '报告上传失败' : '报告添加失败',
      content: `错误代码: ${errMsg}`,
      confirmText: '重试',
      success(res) {
        if (res.confirm) {
          ResultManager.getInstance().uploadReport().then(src.reset);
        }
      }
    });
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/normal/index.ts




function hookNormalApi() {
  var globalWx = getGlobalWx();
  var apiNames = Object.keys(globalWx);
  var hookedApis = [ManualHookApis.Request, ManualHookApis.DownloadFile, ManualHookApis.CreateImage, ManualHookApis.CreateCanvas, ManualHookApis.OnError, ManualHookApis.OnUnhandledRejection];
  var specialApis = [SpecialApis.Env, SpecialApis.Cloud];
  var ignoreApis = [...specialApis, ...hookedApis];
  apiNames.forEach(apiName => {
    if (ignoreApis.includes(apiName)) {
      return;
    }
    var originalMethod = globalWx[apiName];
    Reflect.defineProperty(globalWx, apiName, {
      value(...args) {
        return hookApi(apiName, originalMethod, undefined, ...args);
      }
    });
  });
  addInterface();
}
function addInterface() {
  var globalWx = getGlobalWx();
  Reflect.defineProperty(globalWx, 'startMinigameDetect', {
    value() {
      UIController.getInstance().setRunning();
    },
    configurable: true
  });
  Reflect.defineProperty(globalWx, 'stopMinigameDetect', {
    value() {
      UIController.getInstance().setStop();
    },
    configurable: true
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/report-scene/index.ts




function hookReportScene() {
  var globalWx = getGlobalWx();
  var apiName = ManualHookApis.ReportScene;
  var originalApi = globalWx.reportScene;
  if (!originalApi) {
    return;
  }
  Reflect.defineProperty(globalWx, apiName, {
    value(args) {
      if (args.sceneId === 7) {
        messenger.emit(ApiInvokeMessageType.ReportInteraction, {
          costTime: args.costTime,
          sceneId: args.sceneId
        });
      }
      return hookApi(apiName, originalApi, undefined, args);
    },
    configurable: true
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/normal/error.ts




function onErrorHandler() {
  var globalWx = getGlobalWx();
  var apiName = ManualHookApis.OnError;
  var originalApi = globalWx.onError;
  Reflect.defineProperty(globalWx, apiName, {
    value(args) {
      var fakeCallback = info => {
        messenger.emit(ApiInvokeMessageType.JsError, {
          message: info.message,
          stack: info.stack
        });
        args.call(null, info, '');
      };
      return hookApi(apiName, originalApi, undefined, fakeCallback);
    }
  });
}
function onUnhandledPromiseRejection() {
  var globalWx = getGlobalWx();
  var apiName = ManualHookApis.OnUnhandledRejection;
  var originalApi = globalWx.onUnhandledRejection;
  Reflect.defineProperty(globalWx, apiName, {
    value(args) {
      var fakeCallback = res => {
        messenger.emit(ApiInvokeMessageType.UnhandledPromiseRejection, {
          reason: res.reason
        });
        args.call(null, res);
      };
      return hookApi(apiName, originalApi, undefined, fakeCallback);
    }
  });
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/hook/index.ts









var hooked = false;
function initHook() {
  var _Config$audits, _Config$audits$rules, _Config$audits2, _Config$audits2$rules, _Config$audits3, _Config$audits3$rules;
  if (hooked) {
    return;
  }
  hooked = true;
  var disableRequest = (_Config$audits = config_Config.audits) === null || _Config$audits === void 0 ? void 0 : (_Config$audits$rules = _Config$audits.rules) === null || _Config$audits$rules === void 0 ? void 0 : _Config$audits$rules.disableRequest;
  var disableCreateImage = (_Config$audits2 = config_Config.audits) === null || _Config$audits2 === void 0 ? void 0 : (_Config$audits2$rules = _Config$audits2.rules) === null || _Config$audits2$rules === void 0 ? void 0 : _Config$audits2$rules.disableCreateImage;
  var disableDownloadFile = (_Config$audits3 = config_Config.audits) === null || _Config$audits3 === void 0 ? void 0 : (_Config$audits3$rules = _Config$audits3.rules) === null || _Config$audits3$rules === void 0 ? void 0 : _Config$audits3$rules.disableDownloadFile;
  if (isUndefined(disableRequest) || !disableRequest) {
    hookRequest();
  }
  if (isUndefined(disableCreateImage) || !disableCreateImage) {
    hookCreateImage();
  }
  if (isUndefined(disableDownloadFile) || !disableDownloadFile) {
    hookDownloadFile();
  }
  hookCanvas();
  hookNormalApi();
  hookReportScene();
  onErrorHandler();
  onUnhandledPromiseRejection();
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/tasks/index.ts





function register() {
  registerTasks();
  render_registerTasks();
  launch_registerTasks();
  performance_registerTasks();
  compatibility_registerTasks();
}
function off() {
  offTasks();
  render_offTasks();
  launch_offTasks();
  performance_offTasks();
  compatibility_offTasks();
}
function resetTasks() {
  practice_reset();
  render_reset();
  launch_reset();
  performance_reset();
  compatibility_reset();
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/trace/index.ts




function trace_register() {
  ApiTrace.getInstance().init();
  NetworkTrace.getInstance().init();
  PerformanceTrace.getInstance().init();
  FMPTrace.getInstance().init();
}
function trace_off() {
  ApiTrace.getInstance().off();
  NetworkTrace.getInstance().off();
  PerformanceTrace.getInstance().off();
  FMPTrace.getInstance().off();
}
function trace_reset() {
  ApiTrace.getInstance().reset();
  NetworkTrace.getInstance().reset();
  PerformanceTrace.getInstance().reset();
  FMPTrace.getInstance().reset();
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/enums/controller.ts
var ConfigKeys = {
  Enable: "DETECT_KEY__ENABLE",
  AutoStart: "DETECT_KEY__AUTO_START",
  WebSocketUrl: "DETECT_KEY__WEB_SOCKET_URL",
  injectMode: "DETECT_KEY__INJECT_MODE"
};
var DetectStatus = (/* unused pure expression or super */ null && ({
  Start: 0,
  End: 1
}));
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/messenger/performance.ts







class GamePerformance extends Singleton {
  constructor(...args) {
    var _this;
    super(...args);
    _this = this;
    this.requestId = void 0;
    this.running = true;
    this.interval = 2000;
    this.supportGamePerformance = false;
    this.getGamePerformance = void 0;
    this.getAndDispatchPerformanceData = /*#__PURE__*/asyncToGenerator_default()(function* () {
      if (!_this.running) {
        return;
      }
      var [, res] = yield awaitWrap(_this.postGetGamePerformance());
      if (res) {
        if (_this.enable) {
          delete res.errMsg;
          messenger.emit(PerformanceMessageType.Received, new GeneralGamePerformance(res));
        }
      }
      if (_this.running) {
        _this.requestId = setTimeout(() => {
          _this.getAndDispatchPerformanceData();
        }, _this.interval);
      }
    });
  }
  get enable() {
    return controller.isRunning && this.supportGamePerformance;
  }
  init(getGamePerformance) {
    if (!getGamePerformance) {
      this.supportGamePerformance = false;
      return;
    }
    this.supportGamePerformance = true;
    this.getGamePerformance = getGamePerformance;
  }
  start() {
    if (!this.enable) {
      return;
    }
    this.running = true;
    this.getAndDispatchPerformanceData();
  }
  stop() {
    this.running = false;
    if (this.requestId) {
      clearTimeout(this.requestId);
    }
  }
  postGetGamePerformance() {
    if (this.getGamePerformance) {
      return new Promise((resolve, reject) => {
        var _this$getGamePerforma;
        (_this$getGamePerforma = this.getGamePerformance) === null || _this$getGamePerforma === void 0 ? void 0 : _this$getGamePerforma.call(this, {
          success: resolve,
          fail: reject
        });
      });
    }
    return Promise.reject();
  }
}
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/controller/index.ts
















class Controller extends Singleton {
  constructor(...args) {
    super(...args);
    this.enable = false;
    this.isRunning = false;
    this.injectMode = false;
    this.autoStart = false;
    this.deviceInfo = void 0;
    this.result = void 0;
    this.initParams = void 0;
    this.start = () => {
      this.isRunning = true;
      config_Config.detectTimes += 1;
      Logger.event('minigame detect logic running!!');
      config_Config.meta.startTime = Date.now();
      timer.init();
      trace_register();
      register();
      GamePerformance.getInstance().start();
      messenger.emit(DetectEventMessageType.Start);
    };
    this.stop = () => {
      this.isRunning = false;
      messenger.emit(DetectEventMessageType.BeforeResult);
      messenger.emit(DetectEventMessageType.End);
      Logger.event('minigame detect logic stop!!');
      config_Config.meta.endTime = Date.now();
      auditEnd();
      timer.stop();
      GamePerformance.getInstance().stop();
      trace_off();
      off();
      ResultManager.getInstance().uploadReport().then(this.reset);
    };
  }
  init(initParams) {
    Logger.event('minigame detect tool inject!!');
    Logger.debug('minigame detect tool inject!!, initParams=', initParams);
    config_Config.init(initParams);
    initReporter();
    this.initParams = initParams;
    setGlobalWx(initParams.globalWx);
    if (config_Config.isWxApplib) {
      this.enable = true;
      this.autoStart = config_Config.audits.autoStart;
    } else {
      this.handleLaunchConfig();
    }
    Logger.event(`enable=${this.enable}, autoStart=${this.autoStart}`);
    if (this.enable) {
      auditLaunch();
      this.beforeStart();
      this.generateDetectTask();
      if (this.autoStart) {
        this.start();
      } else {}
    }
    setRequestFunction({
      request: initParams.request,
      uploadFile: initParams.uploadFile,
      gameTransfer: initParams.gameTransfer
    });
  }
  generateDetectTask() {
    return asyncToGenerator_default()(function* () {
      ResultManager.getInstance().getDeviceInfo();
    })();
  }
  handleLaunchConfig() {
    this.injectMode = false;
    var configObject = {};
    this.enable = !!configObject[ConfigKeys.Enable];
    this.autoStart = !!configObject[ConfigKeys.AutoStart];
  }
  registerDetectEvent() {
    messenger.once(DetectEventMessageType.Start, this.start);
    messenger.once(DetectEventMessageType.End, this.stop);
  }
  beforeStart() {
    var {
      coverview,
      getGamePerformance
    } = this.initParams;
    initHook();
    if (config_Config.isWxApplib) {
      UIController.getInstance().init(coverview);
      GamePerformance.getInstance().init(getGamePerformance);
    }
  }
  reset() {
    ResultManager.getInstance().reset();
    config_Config.reset();
    resetTasks();
    timer.reset();
    trace_reset();
  }
}
/* harmony default export */ const controller = (Controller.getInstance());
;// CONCATENATED MODULE: ./src/game/game-component/game_performance_audit/src/index.ts


Object.defineProperty(globalThis, '__GamePerformanceUtilsSDK', {
  get() {
    return {
      getSDK() {
        return {
          controller: controller,
          setWx(wx) {
            setSdkWX(wx);
          }
        };
      }
    };
  }
});
/* harmony default export */ const src = (controller);
})();

GamePerformanceAudit = __webpack_exports__["default"];
/******/ })()
;
null

})(); /* LIBRARY_CLOSURE_END () */


} catch(err) {
      console.error('catch sdkSubPackage: gamePerformanceUtilsSDK error: ', err)
    }
