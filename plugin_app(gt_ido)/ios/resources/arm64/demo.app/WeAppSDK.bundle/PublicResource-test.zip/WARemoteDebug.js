(()=>{var e={4515:e=>{function t(e,t,n,r,i,o,s){try{var a=e[o](s),d=a.value}catch(e){return void n(e)}a.done?t(d):Promise.resolve(d).then(r,i)}e.exports=function(e){return function(){var n=this,r=arguments;return new Promise((function(i,o){var s=e.apply(n,r);function a(e){t(s,i,o,a,d,"next",e)}function d(e){t(s,i,o,a,d,"throw",e)}a(void 0)}))}},e.exports.__esModule=!0,e.exports.default=e.exports},1722:(e,t,n)=>{"use strict";n.d(t,{A:()=>a,T:()=>r,_:()=>o,a:()=>s});var r,i=n(2993);function o(e,t,n,r){var i,o=arguments.length,s=o<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(i=e[a])&&(s=(o<3?i(s):o>3?i(t,n,s):i(t,n))||s);return o>3&&s&&Object.defineProperty(t,n,s),s}function s(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)}!function(e){e[e.Inspector=0]="Inspector",e[e.RendererInspectee=1]="RendererInspectee",e[e.ServiceInspectee=2]="ServiceInspectee",e[e.AllInspectee=3]="AllInspectee"}(r||(r={}));var a=class{constructor(e=r.AllInspectee){this.callbacks=new Map,this.type=e}get inited(){return this._inited}init(){this.initSubscription(this.handleCDPMessage.bind(this)),this._inited=!0}emit(e){this.send(e)}reply(e,t){this.send({id:e,result:t})}on(e,t){this.callbacks.has(e)||this.callbacks.set(e,[]),this.callbacks.get(e).push(t)}off(e,t){if(this.callbacks.has(e)){var n=this.callbacks.get(e);n=[...n.filter((e=>e!==t))]}}handleCDPMessage(e,t,n){var r,i,o,s,a;((s=this.type)===(a=t)||s&a)&&("id"in e?null===(r=this.callbacks.get("command"))||void 0===r||r.forEach((t=>t(e,n))):null===(i=this.callbacks.get("event"))||void 0===i||i.forEach((t=>t(e,n))),null===(o=this.callbacks.get("all"))||void 0===o||o.forEach((t=>t(e,n))))}};a=o([(0,i._G)(),s("design:paramtypes",[Number])],a)},1911:(e,t,n)=>{"use strict";n.d(t,{pS:()=>s});var r=n(1722),i=(n(2803),n(2993)),o={exports:{}};!function(e){var t=Object.prototype.hasOwnProperty,n="~";function r(){}function i(e,t,n){this.fn=e,this.context=t,this.once=n||!1}function o(e,t,r,o,s){if("function"!=typeof r)throw new TypeError("The listener must be a function");var a=new i(r,o||e,s),d=n?n+t:t;return e._events[d]?e._events[d].fn?e._events[d]=[e._events[d],a]:e._events[d].push(a):(e._events[d]=a,e._eventsCount++),e}function s(e,t){0==--e._eventsCount?e._events=new r:delete e._events[t]}function a(){this._events=new r,this._eventsCount=0}Object.create&&(r.prototype=Object.create(null),(new r).__proto__||(n=!1)),a.prototype.eventNames=function(){var e,r,i=[];if(0===this._eventsCount)return i;for(r in e=this._events)t.call(e,r)&&i.push(n?r.slice(1):r);return Object.getOwnPropertySymbols?i.concat(Object.getOwnPropertySymbols(e)):i},a.prototype.listeners=function(e){var t=n?n+e:e,r=this._events[t];if(!r)return[];if(r.fn)return[r.fn];for(var i=0,o=r.length,s=new Array(o);i<o;i++)s[i]=r[i].fn;return s},a.prototype.listenerCount=function(e){var t=n?n+e:e,r=this._events[t];return r?r.fn?1:r.length:0},a.prototype.emit=function(e,t,r,i,o,s){var a=n?n+e:e;if(!this._events[a])return!1;var d,l,u=this._events[a],c=arguments.length;if(u.fn){switch(u.once&&this.removeListener(e,u.fn,void 0,!0),c){case 1:return u.fn.call(u.context),!0;case 2:return u.fn.call(u.context,t),!0;case 3:return u.fn.call(u.context,t,r),!0;case 4:return u.fn.call(u.context,t,r,i),!0;case 5:return u.fn.call(u.context,t,r,i,o),!0;case 6:return u.fn.call(u.context,t,r,i,o,s),!0}for(l=1,d=new Array(c-1);l<c;l++)d[l-1]=arguments[l];u.fn.apply(u.context,d)}else{var h,p=u.length;for(l=0;l<p;l++)switch(u[l].once&&this.removeListener(e,u[l].fn,void 0,!0),c){case 1:u[l].fn.call(u[l].context);break;case 2:u[l].fn.call(u[l].context,t);break;case 3:u[l].fn.call(u[l].context,t,r);break;case 4:u[l].fn.call(u[l].context,t,r,i);break;default:if(!d)for(h=1,d=new Array(c-1);h<c;h++)d[h-1]=arguments[h];u[l].fn.apply(u[l].context,d)}}return!0},a.prototype.on=function(e,t,n){return o(this,e,t,n,!1)},a.prototype.once=function(e,t,n){return o(this,e,t,n,!0)},a.prototype.removeListener=function(e,t,r,i){var o=n?n+e:e;if(!this._events[o])return this;if(!t)return s(this,o),this;var a=this._events[o];if(a.fn)a.fn!==t||i&&!a.once||r&&a.context!==r||s(this,o);else{for(var d=0,l=[],u=a.length;d<u;d++)(a[d].fn!==t||i&&!a[d].once||r&&a[d].context!==r)&&l.push(a[d]);l.length?this._events[o]=1===l.length?l[0]:l:s(this,o)}return this},a.prototype.removeAllListeners=function(e){var t;return e?(t=n?n+e:e,this._events[t]&&s(this,t)):(this._events=new r,this._eventsCount=0),this},a.prototype.off=a.prototype.removeListener,a.prototype.addListener=a.prototype.on,a.prefixed=n,a.EventEmitter=a,e.exports=a}(o);new o.exports.EventEmitter;var s=class extends r.A{constructor(e){super(e),this.eventBus=(()=>{var e=Reflect.get(globalThis,Symbol.for("defaultEventBus"));if(e)return e;var t=new o.exports.EventEmitter;return Reflect.set(globalThis,Symbol.for("defaultEventBus"),t),t})(),this.init()}initSubscription(e){var t=this.type===r.T.Inspector?"inspector":"inspectee";this.eventBus.addListener(t,e)}send(e,t=r.T.Inspector){var n=t===r.T.Inspector?"inspector":"inspectee";this.eventBus.emit(n,e,t,this.type)}};s=(0,r._)([(0,i._G)(),(0,r.a)("design:paramtypes",[Number])],s)},4192:(e,t,n)=>{"use strict";n.d(t,{yK:()=>r.T});n(2803);var r=n(1722);n(2993)},7691:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.tagProperty=t.tagParameter=t.decorate=void 0;var r=n(8705),i=n(1852);function o(e,t,n,i,o){var s={},a="number"==typeof o,d=void 0!==o&&a?o.toString():n;if(a&&void 0!==n)throw new Error(r.INVALID_DECORATOR_OPERATION);Reflect.hasOwnMetadata(e,t)&&(s=Reflect.getMetadata(e,t));var l=s[d];if(Array.isArray(l))for(var u=0,c=l;u<c.length;u++){var h=c[u];if(h.key===i.key)throw new Error(r.DUPLICATED_METADATA+" "+h.key.toString())}else l=[];l.push(i),s[d]=l,Reflect.defineMetadata(e,s,t)}function s(e,t){Reflect.decorate(e,t)}function a(e,t){return function(n,r){t(n,r,e)}}t.tagParameter=function(e,t,n,r){o(i.TAGGED,e,t,r,n)},t.tagProperty=function(e,t,n){o(i.TAGGED_PROP,e.constructor,t,n)},t.decorate=function(e,t,n){"number"==typeof n?s([a(n,e)],t):"string"==typeof n?Reflect.decorate([e],t,n):s([e],t)}},4187:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.inject=t.LazyServiceIdentifer=void 0;var r=n(8705),i=n(1852),o=n(2811),s=n(7691),a=function(){function e(e){this._cb=e}return e.prototype.unwrap=function(){return this._cb()},e}();t.LazyServiceIdentifer=a,t.inject=function(e){return function(t,n,a){if(void 0===e)throw new Error(r.UNDEFINED_INJECT_ANNOTATION(t.name));var d=new o.Metadata(i.INJECT_TAG,e);"number"==typeof a?s.tagParameter(t,n,a,d):s.tagProperty(t,n,d)}}},3779:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.injectable=void 0;var r=n(8705),i=n(1852);t.injectable=function(){return function(e){if(Reflect.hasOwnMetadata(i.PARAM_TYPES,e))throw new Error(r.DUPLICATED_INJECTABLE_DECORATOR);var t=Reflect.getMetadata(i.DESIGN_PARAM_TYPES,e)||[];return Reflect.defineMetadata(i.PARAM_TYPES,t,e),e}}},9165:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.multiInject=void 0;var r=n(1852),i=n(2811),o=n(7691);t.multiInject=function(e){return function(t,n,s){var a=new i.Metadata(r.MULTI_INJECT_TAG,e);"number"==typeof s?o.tagParameter(t,n,s,a):o.tagProperty(t,n,a)}}},9217:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.named=void 0;var r=n(1852),i=n(2811),o=n(7691);t.named=function(e){return function(t,n,s){var a=new i.Metadata(r.NAMED_TAG,e);"number"==typeof s?o.tagParameter(t,n,s,a):o.tagProperty(t,n,a)}}},4610:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.optional=void 0;var r=n(1852),i=n(2811),o=n(7691);t.optional=function(){return function(e,t,n){var s=new i.Metadata(r.OPTIONAL_TAG,!0);"number"==typeof n?o.tagParameter(e,t,n,s):o.tagProperty(e,t,s)}}},2998:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.postConstruct=void 0;var r=n(8705),i=n(1852),o=n(2811);t.postConstruct=function(){return function(e,t,n){var s=new o.Metadata(i.POST_CONSTRUCT,t);if(Reflect.hasOwnMetadata(i.POST_CONSTRUCT,e.constructor))throw new Error(r.MULTIPLE_POST_CONSTRUCT_METHODS);Reflect.defineMetadata(i.POST_CONSTRUCT,s,e.constructor)}}},9758:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.tagged=void 0;var r=n(2811),i=n(7691);t.tagged=function(e,t){return function(n,o,s){var a=new r.Metadata(e,t);"number"==typeof s?i.tagParameter(n,o,s,a):i.tagProperty(n,o,a)}}},5009:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.targetName=void 0;var r=n(1852),i=n(2811),o=n(7691);t.targetName=function(e){return function(t,n,s){var a=new i.Metadata(r.NAME_TAG,e);o.tagParameter(t,n,s,a)}}},5772:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.unmanaged=void 0;var r=n(1852),i=n(2811),o=n(7691);t.unmanaged=function(){return function(e,t,n){var s=new i.Metadata(r.UNMANAGED_TAG,!0);o.tagParameter(e,t,n,s)}}},454:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.Binding=void 0;var r=n(8199),i=n(2145),o=function(){function e(e,t){this.id=i.id(),this.activated=!1,this.serviceIdentifier=e,this.scope=t,this.type=r.BindingTypeEnum.Invalid,this.constraint=function(e){return!0},this.implementationType=null,this.cache=null,this.factory=null,this.provider=null,this.onActivation=null,this.dynamicValue=null}return e.prototype.clone=function(){var t=new e(this.serviceIdentifier,this.scope);return t.activated=t.scope===r.BindingScopeEnum.Singleton&&this.activated,t.implementationType=this.implementationType,t.dynamicValue=this.dynamicValue,t.scope=this.scope,t.type=this.type,t.factory=this.factory,t.provider=this.provider,t.constraint=this.constraint,t.onActivation=this.onActivation,t.cache=this.cache,t},e}();t.Binding=o},6422:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.BindingCount=void 0;t.BindingCount={MultipleBindingsAvailable:2,NoBindingsAvailable:0,OnlyOneBindingAvailable:1}},8705:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.STACK_OVERFLOW=t.CIRCULAR_DEPENDENCY_IN_FACTORY=t.POST_CONSTRUCT_ERROR=t.MULTIPLE_POST_CONSTRUCT_METHODS=t.CONTAINER_OPTIONS_INVALID_SKIP_BASE_CHECK=t.CONTAINER_OPTIONS_INVALID_AUTO_BIND_INJECTABLE=t.CONTAINER_OPTIONS_INVALID_DEFAULT_SCOPE=t.CONTAINER_OPTIONS_MUST_BE_AN_OBJECT=t.ARGUMENTS_LENGTH_MISMATCH=t.INVALID_DECORATOR_OPERATION=t.INVALID_TO_SELF_VALUE=t.INVALID_FUNCTION_BINDING=t.INVALID_MIDDLEWARE_RETURN=t.NO_MORE_SNAPSHOTS_AVAILABLE=t.INVALID_BINDING_TYPE=t.NOT_IMPLEMENTED=t.CIRCULAR_DEPENDENCY=t.UNDEFINED_INJECT_ANNOTATION=t.MISSING_INJECT_ANNOTATION=t.MISSING_INJECTABLE_ANNOTATION=t.NOT_REGISTERED=t.CANNOT_UNBIND=t.AMBIGUOUS_MATCH=t.KEY_NOT_FOUND=t.NULL_ARGUMENT=t.DUPLICATED_METADATA=t.DUPLICATED_INJECTABLE_DECORATOR=void 0,t.DUPLICATED_INJECTABLE_DECORATOR="Cannot apply @injectable decorator multiple times.",t.DUPLICATED_METADATA="Metadata key was used more than once in a parameter:",t.NULL_ARGUMENT="NULL argument",t.KEY_NOT_FOUND="Key Not Found",t.AMBIGUOUS_MATCH="Ambiguous match found for serviceIdentifier:",t.CANNOT_UNBIND="Could not unbind serviceIdentifier:",t.NOT_REGISTERED="No matching bindings found for serviceIdentifier:",t.MISSING_INJECTABLE_ANNOTATION="Missing required @injectable annotation in:",t.MISSING_INJECT_ANNOTATION="Missing required @inject or @multiInject annotation in:";t.UNDEFINED_INJECT_ANNOTATION=function(e){return"@inject called with undefined this could mean that the class "+e+" has a circular dependency problem. You can use a LazyServiceIdentifer to  overcome this limitation."},t.CIRCULAR_DEPENDENCY="Circular dependency found:",t.NOT_IMPLEMENTED="Sorry, this feature is not fully implemented yet.",t.INVALID_BINDING_TYPE="Invalid binding type:",t.NO_MORE_SNAPSHOTS_AVAILABLE="No snapshot available to restore.",t.INVALID_MIDDLEWARE_RETURN="Invalid return type in middleware. Middleware must return!",t.INVALID_FUNCTION_BINDING="Value provided to function binding must be a function!",t.INVALID_TO_SELF_VALUE="The toSelf function can only be applied when a constructor is used as service identifier",t.INVALID_DECORATOR_OPERATION="The @inject @multiInject @tagged and @named decorators must be applied to the parameters of a class constructor or a class property.";t.ARGUMENTS_LENGTH_MISMATCH=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];return"The number of constructor arguments in the derived class "+e[0]+" must be >= than the number of constructor arguments of its base class."},t.CONTAINER_OPTIONS_MUST_BE_AN_OBJECT="Invalid Container constructor argument. Container options must be an object.",t.CONTAINER_OPTIONS_INVALID_DEFAULT_SCOPE="Invalid Container option. Default scope must be a string ('singleton' or 'transient').",t.CONTAINER_OPTIONS_INVALID_AUTO_BIND_INJECTABLE="Invalid Container option. Auto bind injectable must be a boolean",t.CONTAINER_OPTIONS_INVALID_SKIP_BASE_CHECK="Invalid Container option. Skip base check must be a boolean",t.MULTIPLE_POST_CONSTRUCT_METHODS="Cannot apply @postConstruct decorator multiple times in the same class";t.POST_CONSTRUCT_ERROR=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];return"@postConstruct error in class "+e[0]+": "+e[1]};t.CIRCULAR_DEPENDENCY_IN_FACTORY=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];return"It looks like there is a circular dependency in one of the '"+e[0]+"' bindings. Please investigate bindings withservice identifier '"+e[1]+"'."},t.STACK_OVERFLOW="Maximum call stack size exceeded"},8199:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.TargetTypeEnum=t.BindingTypeEnum=t.BindingScopeEnum=void 0;t.BindingScopeEnum={Request:"Request",Singleton:"Singleton",Transient:"Transient"};t.BindingTypeEnum={ConstantValue:"ConstantValue",Constructor:"Constructor",DynamicValue:"DynamicValue",Factory:"Factory",Function:"Function",Instance:"Instance",Invalid:"Invalid",Provider:"Provider"};t.TargetTypeEnum={ClassProperty:"ClassProperty",ConstructorArgument:"ConstructorArgument",Variable:"Variable"}},1852:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.NON_CUSTOM_TAG_KEYS=t.POST_CONSTRUCT=t.DESIGN_PARAM_TYPES=t.PARAM_TYPES=t.TAGGED_PROP=t.TAGGED=t.MULTI_INJECT_TAG=t.INJECT_TAG=t.OPTIONAL_TAG=t.UNMANAGED_TAG=t.NAME_TAG=t.NAMED_TAG=void 0,t.NAMED_TAG="named",t.NAME_TAG="name",t.UNMANAGED_TAG="unmanaged",t.OPTIONAL_TAG="optional",t.INJECT_TAG="inject",t.MULTI_INJECT_TAG="multi_inject",t.TAGGED="inversify:tagged",t.TAGGED_PROP="inversify:tagged_props",t.PARAM_TYPES="inversify:paramtypes",t.DESIGN_PARAM_TYPES="design:paramtypes",t.POST_CONSTRUCT="post_construct",t.NON_CUSTOM_TAG_KEYS=[t.INJECT_TAG,t.MULTI_INJECT_TAG,t.NAME_TAG,t.UNMANAGED_TAG,t.NAMED_TAG,t.OPTIONAL_TAG]},903:(e,t,n)=>{"use strict";var r=globalThis&&globalThis.__awaiter||function(e,t,n,r){return new(n||(n=Promise))((function(i,o){function s(e){try{d(r.next(e))}catch(e){o(e)}}function a(e){try{d(r.throw(e))}catch(e){o(e)}}function d(e){var t;e.done?i(e.value):(t=e.value,t instanceof n?t:new n((function(e){e(t)}))).then(s,a)}d((r=r.apply(e,t||[])).next())}))},i=globalThis&&globalThis.__generator||function(e,t){var n,r,i,o,s={label:0,sent:function(){if(1&i[0])throw i[1];return i[1]},trys:[],ops:[]};return o={next:a(0),throw:a(1),return:a(2)},"function"==typeof Symbol&&(o[Symbol.iterator]=function(){return this}),o;function a(o){return function(a){return function(o){if(n)throw new TypeError("Generator is already executing.");for(;s;)try{if(n=1,r&&(i=2&o[0]?r.return:o[0]?r.throw||((i=r.return)&&i.call(r),0):r.next)&&!(i=i.call(r,o[1])).done)return i;switch(r=0,i&&(o=[2&o[0],i.value]),o[0]){case 0:case 1:i=o;break;case 4:return s.label++,{value:o[1],done:!1};case 5:s.label++,r=o[1],o=[0];continue;case 7:o=s.ops.pop(),s.trys.pop();continue;default:if(!(i=s.trys,(i=i.length>0&&i[i.length-1])||6!==o[0]&&2!==o[0])){s=0;continue}if(3===o[0]&&(!i||o[1]>i[0]&&o[1]<i[3])){s.label=o[1];break}if(6===o[0]&&s.label<i[1]){s.label=i[1],i=o;break}if(i&&s.label<i[2]){s.label=i[2],s.ops.push(o);break}i[2]&&s.ops.pop(),s.trys.pop();continue}o=t.call(e,s)}catch(e){o=[6,e],r=0}finally{n=i=0}if(5&o[0])throw o[1];return{value:o[0]?o[1]:void 0,done:!0}}([o,a])}}},o=globalThis&&globalThis.__spreadArray||function(e,t){for(var n=0,r=t.length,i=e.length;n<r;n++,i++)e[i]=t[n];return e};Object.defineProperty(t,"__esModule",{value:!0}),t.Container=void 0;var s=n(454),a=n(8705),d=n(8199),l=n(1852),u=n(6597),c=n(484),h=n(8621),p=n(3025),f=n(2145),v=n(830),g=n(982),m=n(5008),y=function(){function e(e){this._appliedMiddleware=[];var t=e||{};if("object"!=typeof t)throw new Error(""+a.CONTAINER_OPTIONS_MUST_BE_AN_OBJECT);if(void 0===t.defaultScope)t.defaultScope=d.BindingScopeEnum.Transient;else if(t.defaultScope!==d.BindingScopeEnum.Singleton&&t.defaultScope!==d.BindingScopeEnum.Transient&&t.defaultScope!==d.BindingScopeEnum.Request)throw new Error(""+a.CONTAINER_OPTIONS_INVALID_DEFAULT_SCOPE);if(void 0===t.autoBindInjectable)t.autoBindInjectable=!1;else if("boolean"!=typeof t.autoBindInjectable)throw new Error(""+a.CONTAINER_OPTIONS_INVALID_AUTO_BIND_INJECTABLE);if(void 0===t.skipBaseClassChecks)t.skipBaseClassChecks=!1;else if("boolean"!=typeof t.skipBaseClassChecks)throw new Error(""+a.CONTAINER_OPTIONS_INVALID_SKIP_BASE_CHECK);this.options={autoBindInjectable:t.autoBindInjectable,defaultScope:t.defaultScope,skipBaseClassChecks:t.skipBaseClassChecks},this.id=f.id(),this._bindingDictionary=new m.Lookup,this._snapshots=[],this._middleware=null,this.parent=null,this._metadataReader=new u.MetadataReader}return e.merge=function(t,n){for(var r=[],i=2;i<arguments.length;i++)r[i-2]=arguments[i];var s=new e,a=o([t,n],r).map((function(e){return c.getBindingDictionary(e)})),d=c.getBindingDictionary(s);return a.forEach((function(e){var t;t=d,e.traverse((function(e,n){n.forEach((function(e){t.add(e.serviceIdentifier,e.clone())}))}))})),s},e.prototype.load=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];for(var n=this._getContainerModuleHelpersFactory(),r=0,i=e;r<i.length;r++){var o=i[r],s=n(o.id);o.registry(s.bindFunction,s.unbindFunction,s.isboundFunction,s.rebindFunction)}},e.prototype.loadAsync=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];return r(this,void 0,void 0,(function(){var t,n,r,o,s;return i(this,(function(i){switch(i.label){case 0:t=this._getContainerModuleHelpersFactory(),n=0,r=e,i.label=1;case 1:return n<r.length?(o=r[n],s=t(o.id),[4,o.registry(s.bindFunction,s.unbindFunction,s.isboundFunction,s.rebindFunction)]):[3,4];case 2:i.sent(),i.label=3;case 3:return n++,[3,1];case 4:return[2]}}))}))},e.prototype.unload=function(){for(var e=this,t=[],n=0;n<arguments.length;n++)t[n]=arguments[n];t.forEach((function(t){var n,r=(n=t.id,function(e){return e.moduleId===n});e._bindingDictionary.removeByCondition(r)}))},e.prototype.bind=function(e){var t=this.options.defaultScope||d.BindingScopeEnum.Transient,n=new s.Binding(e,t);return this._bindingDictionary.add(e,n),new p.BindingToSyntax(n)},e.prototype.rebind=function(e){return this.unbind(e),this.bind(e)},e.prototype.unbind=function(e){try{this._bindingDictionary.remove(e)}catch(t){throw new Error(a.CANNOT_UNBIND+" "+v.getServiceIdentifierAsString(e))}},e.prototype.unbindAll=function(){this._bindingDictionary=new m.Lookup},e.prototype.isBound=function(e){var t=this._bindingDictionary.hasKey(e);return!t&&this.parent&&(t=this.parent.isBound(e)),t},e.prototype.isBoundNamed=function(e,t){return this.isBoundTagged(e,l.NAMED_TAG,t)},e.prototype.isBoundTagged=function(e,t,n){var r=!1;if(this._bindingDictionary.hasKey(e)){var i=this._bindingDictionary.get(e),o=c.createMockRequest(this,e,t,n);r=i.some((function(e){return e.constraint(o)}))}return!r&&this.parent&&(r=this.parent.isBoundTagged(e,t,n)),r},e.prototype.snapshot=function(){this._snapshots.push(g.ContainerSnapshot.of(this._bindingDictionary.clone(),this._middleware))},e.prototype.restore=function(){var e=this._snapshots.pop();if(void 0===e)throw new Error(a.NO_MORE_SNAPSHOTS_AVAILABLE);this._bindingDictionary=e.bindings,this._middleware=e.middleware},e.prototype.createChild=function(t){var n=new e(t||this.options);return n.parent=this,n},e.prototype.applyMiddleware=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._appliedMiddleware=this._appliedMiddleware.concat(e);var n=this._middleware?this._middleware:this._planAndResolve();this._middleware=e.reduce((function(e,t){return t(e)}),n)},e.prototype.applyCustomMetadataReader=function(e){this._metadataReader=e},e.prototype.get=function(e){return this._get(!1,!1,d.TargetTypeEnum.Variable,e)},e.prototype.getTagged=function(e,t,n){return this._get(!1,!1,d.TargetTypeEnum.Variable,e,t,n)},e.prototype.getNamed=function(e,t){return this.getTagged(e,l.NAMED_TAG,t)},e.prototype.getAll=function(e){return this._get(!0,!0,d.TargetTypeEnum.Variable,e)},e.prototype.getAllTagged=function(e,t,n){return this._get(!1,!0,d.TargetTypeEnum.Variable,e,t,n)},e.prototype.getAllNamed=function(e,t){return this.getAllTagged(e,l.NAMED_TAG,t)},e.prototype.resolve=function(e){var t=this.createChild();return t.bind(e).toSelf(),this._appliedMiddleware.forEach((function(e){t.applyMiddleware(e)})),t.get(e)},e.prototype._getContainerModuleHelpersFactory=function(){var e=this,t=function(e,t){e._binding.moduleId=t},n=function(n){return function(r){var i=e.rebind.bind(e)(r);return t(i,n),i}};return function(r){return{bindFunction:(i=r,function(n){var r=e.bind.bind(e)(n);return t(r,i),r}),isboundFunction:function(t){return e.isBound.bind(e)(t)},rebindFunction:n(r),unbindFunction:function(t){e.unbind.bind(e)(t)}};var i}},e.prototype._get=function(e,t,n,r,i,o){var s=null,d={avoidConstraints:e,contextInterceptor:function(e){return e},isMultiInject:t,key:i,serviceIdentifier:r,targetType:n,value:o};if(this._middleware){if(null==(s=this._middleware(d)))throw new Error(a.INVALID_MIDDLEWARE_RETURN)}else s=this._planAndResolve()(d);return s},e.prototype._planAndResolve=function(){var e=this;return function(t){var n=c.plan(e._metadataReader,e,t.isMultiInject,t.targetType,t.serviceIdentifier,t.key,t.value,t.avoidConstraints);return n=t.contextInterceptor(n),h.resolve(n)}},e}();t.Container=y},1950:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.AsyncContainerModule=t.ContainerModule=void 0;var r=n(2145),i=function(e){this.id=r.id(),this.registry=e};t.ContainerModule=i;var o=function(e){this.id=r.id(),this.registry=e};t.AsyncContainerModule=o},982:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.ContainerSnapshot=void 0;var n=function(){function e(){}return e.of=function(t,n){var r=new e;return r.bindings=t,r.middleware=n,r},e}();t.ContainerSnapshot=n},5008:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.Lookup=void 0;var r=n(8705),i=function(){function e(){this._map=new Map}return e.prototype.getMap=function(){return this._map},e.prototype.add=function(e,t){if(null==e)throw new Error(r.NULL_ARGUMENT);if(null==t)throw new Error(r.NULL_ARGUMENT);var n=this._map.get(e);void 0!==n?(n.push(t),this._map.set(e,n)):this._map.set(e,[t])},e.prototype.get=function(e){if(null==e)throw new Error(r.NULL_ARGUMENT);var t=this._map.get(e);if(void 0!==t)return t;throw new Error(r.KEY_NOT_FOUND)},e.prototype.remove=function(e){if(null==e)throw new Error(r.NULL_ARGUMENT);if(!this._map.delete(e))throw new Error(r.KEY_NOT_FOUND)},e.prototype.removeByCondition=function(e){var t=this;this._map.forEach((function(n,r){var i=n.filter((function(t){return!e(t)}));i.length>0?t._map.set(r,i):t._map.delete(r)}))},e.prototype.hasKey=function(e){if(null==e)throw new Error(r.NULL_ARGUMENT);return this._map.has(e)},e.prototype.clone=function(){var t=new e;return this._map.forEach((function(e,n){e.forEach((function(e){return t.add(n,e.clone())}))})),t},e.prototype.traverse=function(e){this._map.forEach((function(t,n){e(n,t)}))},e}();t.Lookup=i},2993:(e,t,n)=>{"use strict";t.lq=t.WQ=t.KT=t._G=t.mc=void 0,n(1852);var r=n(903);Object.defineProperty(t,"mc",{enumerable:!0,get:function(){return r.Container}});var i=n(8199);var o=n(1950);var s=n(3779);Object.defineProperty(t,"_G",{enumerable:!0,get:function(){return s.injectable}});var a=n(9758);var d=n(9217);Object.defineProperty(t,"KT",{enumerable:!0,get:function(){return d.named}});var l=n(4187);Object.defineProperty(t,"WQ",{enumerable:!0,get:function(){return l.inject}});var u=n(4610);Object.defineProperty(t,"lq",{enumerable:!0,get:function(){return u.optional}});var c=n(5772);var h=n(9165);var p=n(5009);var f=n(2998);var v=n(6597);var g=n(2145);var m=n(7691);var y=n(4753);var x=n(830);var b=n(1549)},4623:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.Context=void 0;var r=n(2145),i=function(){function e(e){this.id=r.id(),this.container=e}return e.prototype.addPlan=function(e){this.plan=e},e.prototype.setCurrentRequest=function(e){this.currentRequest=e},e}();t.Context=i},2811:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.Metadata=void 0;var r=n(1852),i=function(){function e(e,t){this.key=e,this.value=t}return e.prototype.toString=function(){return this.key===r.NAMED_TAG?"named: "+this.value.toString()+" ":"tagged: { key:"+this.key.toString()+", value: "+this.value+" }"},e}();t.Metadata=i},6597:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.MetadataReader=void 0;var r=n(1852),i=function(){function e(){}return e.prototype.getConstructorMetadata=function(e){return{compilerGeneratedMetadata:Reflect.getMetadata(r.PARAM_TYPES,e),userGeneratedMetadata:Reflect.getMetadata(r.TAGGED,e)||{}}},e.prototype.getPropertiesMetadata=function(e){return Reflect.getMetadata(r.TAGGED_PROP,e)||[]},e}();t.MetadataReader=i},8833:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.Plan=void 0;var n=function(e,t){this.parentContext=e,this.rootRequest=t};t.Plan=n},484:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.getBindingDictionary=t.createMockRequest=t.plan=void 0;var r=n(6422),i=n(8705),o=n(8199),s=n(1852),a=n(3174),d=n(830),l=n(4623),u=n(2811),c=n(8833),h=n(8265),p=n(8897),f=n(9955);function v(e){return e._bindingDictionary}function g(e,t,n,o,s){var a=y(n.container,s.serviceIdentifier),l=[];return a.length===r.BindingCount.NoBindingsAvailable&&n.container.options.autoBindInjectable&&"function"==typeof s.serviceIdentifier&&e.getConstructorMetadata(s.serviceIdentifier).compilerGeneratedMetadata&&(n.container.bind(s.serviceIdentifier).toSelf(),a=y(n.container,s.serviceIdentifier)),l=t?a:a.filter((function(e){var t=new p.Request(e.serviceIdentifier,n,o,e,s);return e.constraint(t)})),function(e,t,n,o){switch(t.length){case r.BindingCount.NoBindingsAvailable:if(n.isOptional())return t;var s=d.getServiceIdentifierAsString(e),a=i.NOT_REGISTERED;throw a+=d.listMetadataForTarget(s,n),a+=d.listRegisteredBindingsForServiceIdentifier(o,s,y),new Error(a);case r.BindingCount.OnlyOneBindingAvailable:if(!n.isArray())return t;case r.BindingCount.MultipleBindingsAvailable:default:if(n.isArray())return t;s=d.getServiceIdentifierAsString(e),a=i.AMBIGUOUS_MATCH+" "+s;throw a+=d.listRegisteredBindingsForServiceIdentifier(o,s,y),new Error(a)}}(s.serviceIdentifier,l,s,n.container),l}function m(e,t,n,r,s,a){var d,l;if(null===s){d=g(e,t,r,null,a),l=new p.Request(n,r,null,d,a);var u=new c.Plan(r,l);r.addPlan(u)}else d=g(e,t,r,s,a),l=s.addChildRequest(a.serviceIdentifier,d,a);d.forEach((function(t){var n=null;if(a.isArray())n=l.addChildRequest(t.serviceIdentifier,t,a);else{if(t.cache)return;n=l}if(t.type===o.BindingTypeEnum.Instance&&null!==t.implementationType){var s=h.getDependencies(e,t.implementationType);if(!r.container.options.skipBaseClassChecks){var d=h.getBaseClassDependencyCount(e,t.implementationType);if(s.length<d){var u=i.ARGUMENTS_LENGTH_MISMATCH(h.getFunctionName(t.implementationType));throw new Error(u)}}s.forEach((function(t){m(e,!1,t.serviceIdentifier,r,n,t)}))}}))}function y(e,t){var n=[],r=v(e);return r.hasKey(t)?n=r.get(t):null!==e.parent&&(n=y(e.parent,t)),n}t.getBindingDictionary=v,t.plan=function(e,t,n,r,i,o,c,h){void 0===h&&(h=!1);var p=new l.Context(t),v=function(e,t,n,r,i,o){var a=e?s.MULTI_INJECT_TAG:s.INJECT_TAG,d=new u.Metadata(a,n),l=new f.Target(t,r,n,d);if(void 0!==i){var c=new u.Metadata(i,o);l.metadata.push(c)}return l}(n,r,i,"",o,c);try{return m(e,h,i,p,null,v),p}catch(e){throw a.isStackOverflowExeption(e)&&p.plan&&d.circularDependencyToException(p.plan.rootRequest),e}},t.createMockRequest=function(e,t,n,r){var i=new f.Target(o.TargetTypeEnum.Variable,"",t,new u.Metadata(n,r)),s=new l.Context(e);return new p.Request(t,s,null,[],i)}},5102:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.QueryableString=void 0;var n=function(){function e(e){this.str=e}return e.prototype.startsWith=function(e){return 0===this.str.indexOf(e)},e.prototype.endsWith=function(e){var t,n=e.split("").reverse().join("");return t=this.str.split("").reverse().join(""),this.startsWith.call({str:t},n)},e.prototype.contains=function(e){return-1!==this.str.indexOf(e)},e.prototype.equals=function(e){return this.str===e},e.prototype.value=function(){return this.str},e}();t.QueryableString=n},8265:(e,t,n)=>{"use strict";var r=globalThis&&globalThis.__spreadArray||function(e,t){for(var n=0,r=t.length,i=e.length;n<r;n++,i++)e[i]=t[n];return e};Object.defineProperty(t,"__esModule",{value:!0}),t.getFunctionName=t.getBaseClassDependencyCount=t.getDependencies=void 0;var i=n(4187),o=n(8705),s=n(8199),a=n(1852),d=n(830);Object.defineProperty(t,"getFunctionName",{enumerable:!0,get:function(){return d.getFunctionName}});var l=n(9955);function u(e,t,n,i){var s=e.getConstructorMetadata(n),a=s.compilerGeneratedMetadata;if(void 0===a){var d=o.MISSING_INJECTABLE_ANNOTATION+" "+t+".";throw new Error(d)}var l=s.userGeneratedMetadata,u=Object.keys(l),p=0===n.length&&u.length>0,f=u.length>n.length,v=function(e,t,n,r,i){for(var o=[],s=0;s<i;s++){var a=c(s,e,t,n,r);null!==a&&o.push(a)}return o}(i,t,a,l,p||f?u.length:n.length),g=h(e,n);return r(r([],v),g)}function c(e,t,n,r,a){var d=a[e.toString()]||[],u=p(d),c=!0!==u.unmanaged,h=r[e],f=u.inject||u.multiInject;if((h=f||h)instanceof i.LazyServiceIdentifer&&(h=h.unwrap()),c){if(!t&&(h===Object||h===Function||void 0===h)){var v=o.MISSING_INJECT_ANNOTATION+" argument "+e+" in class "+n+".";throw new Error(v)}var g=new l.Target(s.TargetTypeEnum.ConstructorArgument,u.targetName,h);return g.metadata=d,g}return null}function h(e,t){for(var n=e.getPropertiesMetadata(t),i=[],o=0,a=Object.keys(n);o<a.length;o++){var d=a[o],u=n[d],c=p(n[d]),f=c.targetName||d,v=c.inject||c.multiInject,g=new l.Target(s.TargetTypeEnum.ClassProperty,f,v);g.metadata=u,i.push(g)}var m=Object.getPrototypeOf(t.prototype).constructor;if(m!==Object){var y=h(e,m);i=r(r([],i),y)}return i}function p(e){var t={};return e.forEach((function(e){t[e.key.toString()]=e.value})),{inject:t[a.INJECT_TAG],multiInject:t[a.MULTI_INJECT_TAG],targetName:t[a.NAME_TAG],unmanaged:t[a.UNMANAGED_TAG]}}t.getDependencies=function(e,t){return u(e,d.getFunctionName(t),t,!1)},t.getBaseClassDependencyCount=function e(t,n){var r=Object.getPrototypeOf(n.prototype).constructor;if(r!==Object){var i=u(t,d.getFunctionName(r),r,!0),o=i.map((function(e){return e.metadata.filter((function(e){return e.key===a.UNMANAGED_TAG}))})),s=[].concat.apply([],o).length,l=i.length-s;return l>0?l:e(t,r)}return 0}},8897:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.Request=void 0;var r=n(2145),i=function(){function e(e,t,n,i,o){this.id=r.id(),this.serviceIdentifier=e,this.parentContext=t,this.parentRequest=n,this.target=o,this.childRequests=[],this.bindings=Array.isArray(i)?i:[i],this.requestScope=null===n?new Map:null}return e.prototype.addChildRequest=function(t,n,r){var i=new e(t,this.parentContext,this,n,r);return this.childRequests.push(i),i},e}();t.Request=i},9955:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.Target=void 0;var r=n(1852),i=n(2145),o=n(2811),s=n(5102),a=function(){function e(e,t,n,a){this.id=i.id(),this.type=e,this.serviceIdentifier=n,this.name=new s.QueryableString(t||""),this.metadata=new Array;var d=null;"string"==typeof a?d=new o.Metadata(r.NAMED_TAG,a):a instanceof o.Metadata&&(d=a),null!==d&&this.metadata.push(d)}return e.prototype.hasTag=function(e){for(var t=0,n=this.metadata;t<n.length;t++){if(n[t].key===e)return!0}return!1},e.prototype.isArray=function(){return this.hasTag(r.MULTI_INJECT_TAG)},e.prototype.matchesArray=function(e){return this.matchesTag(r.MULTI_INJECT_TAG)(e)},e.prototype.isNamed=function(){return this.hasTag(r.NAMED_TAG)},e.prototype.isTagged=function(){return this.metadata.some((function(e){return r.NON_CUSTOM_TAG_KEYS.every((function(t){return e.key!==t}))}))},e.prototype.isOptional=function(){return this.matchesTag(r.OPTIONAL_TAG)(!0)},e.prototype.getNamedTag=function(){return this.isNamed()?this.metadata.filter((function(e){return e.key===r.NAMED_TAG}))[0]:null},e.prototype.getCustomTags=function(){return this.isTagged()?this.metadata.filter((function(e){return r.NON_CUSTOM_TAG_KEYS.every((function(t){return e.key!==t}))})):null},e.prototype.matchesNamedTag=function(e){return this.matchesTag(r.NAMED_TAG)(e)},e.prototype.matchesTag=function(e){var t=this;return function(n){for(var r=0,i=t.metadata;r<i.length;r++){var o=i[r];if(o.key===e&&o.value===n)return!0}return!1}},e}();t.Target=a},1798:(e,t,n)=>{"use strict";var r=globalThis&&globalThis.__spreadArray||function(e,t){for(var n=0,r=t.length,i=e.length;n<r;n++,i++)e[i]=t[n];return e};Object.defineProperty(t,"__esModule",{value:!0}),t.resolveInstance=void 0;var i=n(8705),o=n(8199),s=n(1852);t.resolveInstance=function(e,t,n){var a,d,l=null;if(t.length>0){var u=t.filter((function(e){return null!==e.target&&e.target.type===o.TargetTypeEnum.ConstructorArgument})).map(n);d=u,l=function(e,t,n){var r=t.filter((function(e){return null!==e.target&&e.target.type===o.TargetTypeEnum.ClassProperty})),i=r.map(n);return r.forEach((function(t,n){var r;r=t.target.name.value();var o=i[n];e[r]=o})),e}(l=new((a=e).bind.apply(a,r([void 0],d))),t,n)}else l=new e;return function(e,t){if(Reflect.hasMetadata(s.POST_CONSTRUCT,e)){var n=Reflect.getMetadata(s.POST_CONSTRUCT,e);try{t[n.value]()}catch(t){throw new Error(i.POST_CONSTRUCT_ERROR(e.name,t.message))}}}(e,l),l}},8621:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.resolve=void 0;var r=n(8705),i=n(8199),o=n(3174),s=n(830),a=n(1798),d=function(e,t,n){try{return n()}catch(n){throw o.isStackOverflowExeption(n)?new Error(r.CIRCULAR_DEPENDENCY_IN_FACTORY(e,t.toString())):n}},l=function(e){return function(t){t.parentContext.setCurrentRequest(t);var n=t.bindings,o=t.childRequests,u=t.target&&t.target.isArray(),c=!(t.parentRequest&&t.parentRequest.target&&t.target&&t.parentRequest.target.matchesArray(t.target.serviceIdentifier));if(u&&c)return o.map((function(t){return l(e)(t)}));var h=null;if(!t.target.isOptional()||0!==n.length){var p=n[0],f=p.scope===i.BindingScopeEnum.Singleton,v=p.scope===i.BindingScopeEnum.Request;if(f&&p.activated)return p.cache;if(v&&null!==e&&e.has(p.id))return e.get(p.id);if(p.type===i.BindingTypeEnum.ConstantValue)h=p.cache,p.activated=!0;else if(p.type===i.BindingTypeEnum.Function)h=p.cache,p.activated=!0;else if(p.type===i.BindingTypeEnum.Constructor)h=p.implementationType;else if(p.type===i.BindingTypeEnum.DynamicValue&&null!==p.dynamicValue)h=d("toDynamicValue",p.serviceIdentifier,(function(){return p.dynamicValue(t.parentContext)}));else if(p.type===i.BindingTypeEnum.Factory&&null!==p.factory)h=d("toFactory",p.serviceIdentifier,(function(){return p.factory(t.parentContext)}));else if(p.type===i.BindingTypeEnum.Provider&&null!==p.provider)h=d("toProvider",p.serviceIdentifier,(function(){return p.provider(t.parentContext)}));else{if(p.type!==i.BindingTypeEnum.Instance||null===p.implementationType){var g=s.getServiceIdentifierAsString(t.serviceIdentifier);throw new Error(r.INVALID_BINDING_TYPE+" "+g)}h=a.resolveInstance(p.implementationType,o,l(e))}return"function"==typeof p.onActivation&&(h=p.onActivation(t.parentContext,h)),f&&(p.cache=h,p.activated=!0),v&&null!==e&&!e.has(p.id)&&e.set(p.id,h),h}}};t.resolve=function(e){return l(e.plan.rootRequest.requestScope)(e.plan.rootRequest)}},8631:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.BindingInSyntax=void 0;var r=n(8199),i=n(2852),o=function(){function e(e){this._binding=e}return e.prototype.inRequestScope=function(){return this._binding.scope=r.BindingScopeEnum.Request,new i.BindingWhenOnSyntax(this._binding)},e.prototype.inSingletonScope=function(){return this._binding.scope=r.BindingScopeEnum.Singleton,new i.BindingWhenOnSyntax(this._binding)},e.prototype.inTransientScope=function(){return this._binding.scope=r.BindingScopeEnum.Transient,new i.BindingWhenOnSyntax(this._binding)},e}();t.BindingInSyntax=o},5222:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.BindingInWhenOnSyntax=void 0;var r=n(8631),i=n(6581),o=n(4206),s=function(){function e(e){this._binding=e,this._bindingWhenSyntax=new o.BindingWhenSyntax(this._binding),this._bindingOnSyntax=new i.BindingOnSyntax(this._binding),this._bindingInSyntax=new r.BindingInSyntax(e)}return e.prototype.inRequestScope=function(){return this._bindingInSyntax.inRequestScope()},e.prototype.inSingletonScope=function(){return this._bindingInSyntax.inSingletonScope()},e.prototype.inTransientScope=function(){return this._bindingInSyntax.inTransientScope()},e.prototype.when=function(e){return this._bindingWhenSyntax.when(e)},e.prototype.whenTargetNamed=function(e){return this._bindingWhenSyntax.whenTargetNamed(e)},e.prototype.whenTargetIsDefault=function(){return this._bindingWhenSyntax.whenTargetIsDefault()},e.prototype.whenTargetTagged=function(e,t){return this._bindingWhenSyntax.whenTargetTagged(e,t)},e.prototype.whenInjectedInto=function(e){return this._bindingWhenSyntax.whenInjectedInto(e)},e.prototype.whenParentNamed=function(e){return this._bindingWhenSyntax.whenParentNamed(e)},e.prototype.whenParentTagged=function(e,t){return this._bindingWhenSyntax.whenParentTagged(e,t)},e.prototype.whenAnyAncestorIs=function(e){return this._bindingWhenSyntax.whenAnyAncestorIs(e)},e.prototype.whenNoAncestorIs=function(e){return this._bindingWhenSyntax.whenNoAncestorIs(e)},e.prototype.whenAnyAncestorNamed=function(e){return this._bindingWhenSyntax.whenAnyAncestorNamed(e)},e.prototype.whenAnyAncestorTagged=function(e,t){return this._bindingWhenSyntax.whenAnyAncestorTagged(e,t)},e.prototype.whenNoAncestorNamed=function(e){return this._bindingWhenSyntax.whenNoAncestorNamed(e)},e.prototype.whenNoAncestorTagged=function(e,t){return this._bindingWhenSyntax.whenNoAncestorTagged(e,t)},e.prototype.whenAnyAncestorMatches=function(e){return this._bindingWhenSyntax.whenAnyAncestorMatches(e)},e.prototype.whenNoAncestorMatches=function(e){return this._bindingWhenSyntax.whenNoAncestorMatches(e)},e.prototype.onActivation=function(e){return this._bindingOnSyntax.onActivation(e)},e}();t.BindingInWhenOnSyntax=s},6581:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.BindingOnSyntax=void 0;var r=n(4206),i=function(){function e(e){this._binding=e}return e.prototype.onActivation=function(e){return this._binding.onActivation=e,new r.BindingWhenSyntax(this._binding)},e}();t.BindingOnSyntax=i},3025:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.BindingToSyntax=void 0;var r=n(8705),i=n(8199),o=n(5222),s=n(2852),a=function(){function e(e){this._binding=e}return e.prototype.to=function(e){return this._binding.type=i.BindingTypeEnum.Instance,this._binding.implementationType=e,new o.BindingInWhenOnSyntax(this._binding)},e.prototype.toSelf=function(){if("function"!=typeof this._binding.serviceIdentifier)throw new Error(""+r.INVALID_TO_SELF_VALUE);var e=this._binding.serviceIdentifier;return this.to(e)},e.prototype.toConstantValue=function(e){return this._binding.type=i.BindingTypeEnum.ConstantValue,this._binding.cache=e,this._binding.dynamicValue=null,this._binding.implementationType=null,this._binding.scope=i.BindingScopeEnum.Singleton,new s.BindingWhenOnSyntax(this._binding)},e.prototype.toDynamicValue=function(e){return this._binding.type=i.BindingTypeEnum.DynamicValue,this._binding.cache=null,this._binding.dynamicValue=e,this._binding.implementationType=null,new o.BindingInWhenOnSyntax(this._binding)},e.prototype.toConstructor=function(e){return this._binding.type=i.BindingTypeEnum.Constructor,this._binding.implementationType=e,this._binding.scope=i.BindingScopeEnum.Singleton,new s.BindingWhenOnSyntax(this._binding)},e.prototype.toFactory=function(e){return this._binding.type=i.BindingTypeEnum.Factory,this._binding.factory=e,this._binding.scope=i.BindingScopeEnum.Singleton,new s.BindingWhenOnSyntax(this._binding)},e.prototype.toFunction=function(e){if("function"!=typeof e)throw new Error(r.INVALID_FUNCTION_BINDING);var t=this.toConstantValue(e);return this._binding.type=i.BindingTypeEnum.Function,this._binding.scope=i.BindingScopeEnum.Singleton,t},e.prototype.toAutoFactory=function(e){return this._binding.type=i.BindingTypeEnum.Factory,this._binding.factory=function(t){return function(){return t.container.get(e)}},this._binding.scope=i.BindingScopeEnum.Singleton,new s.BindingWhenOnSyntax(this._binding)},e.prototype.toProvider=function(e){return this._binding.type=i.BindingTypeEnum.Provider,this._binding.provider=e,this._binding.scope=i.BindingScopeEnum.Singleton,new s.BindingWhenOnSyntax(this._binding)},e.prototype.toService=function(e){this.toDynamicValue((function(t){return t.container.get(e)}))},e}();t.BindingToSyntax=a},2852:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.BindingWhenOnSyntax=void 0;var r=n(6581),i=n(4206),o=function(){function e(e){this._binding=e,this._bindingWhenSyntax=new i.BindingWhenSyntax(this._binding),this._bindingOnSyntax=new r.BindingOnSyntax(this._binding)}return e.prototype.when=function(e){return this._bindingWhenSyntax.when(e)},e.prototype.whenTargetNamed=function(e){return this._bindingWhenSyntax.whenTargetNamed(e)},e.prototype.whenTargetIsDefault=function(){return this._bindingWhenSyntax.whenTargetIsDefault()},e.prototype.whenTargetTagged=function(e,t){return this._bindingWhenSyntax.whenTargetTagged(e,t)},e.prototype.whenInjectedInto=function(e){return this._bindingWhenSyntax.whenInjectedInto(e)},e.prototype.whenParentNamed=function(e){return this._bindingWhenSyntax.whenParentNamed(e)},e.prototype.whenParentTagged=function(e,t){return this._bindingWhenSyntax.whenParentTagged(e,t)},e.prototype.whenAnyAncestorIs=function(e){return this._bindingWhenSyntax.whenAnyAncestorIs(e)},e.prototype.whenNoAncestorIs=function(e){return this._bindingWhenSyntax.whenNoAncestorIs(e)},e.prototype.whenAnyAncestorNamed=function(e){return this._bindingWhenSyntax.whenAnyAncestorNamed(e)},e.prototype.whenAnyAncestorTagged=function(e,t){return this._bindingWhenSyntax.whenAnyAncestorTagged(e,t)},e.prototype.whenNoAncestorNamed=function(e){return this._bindingWhenSyntax.whenNoAncestorNamed(e)},e.prototype.whenNoAncestorTagged=function(e,t){return this._bindingWhenSyntax.whenNoAncestorTagged(e,t)},e.prototype.whenAnyAncestorMatches=function(e){return this._bindingWhenSyntax.whenAnyAncestorMatches(e)},e.prototype.whenNoAncestorMatches=function(e){return this._bindingWhenSyntax.whenNoAncestorMatches(e)},e.prototype.onActivation=function(e){return this._bindingOnSyntax.onActivation(e)},e}();t.BindingWhenOnSyntax=o},4206:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.BindingWhenSyntax=void 0;var r=n(6581),i=n(4753),o=function(){function e(e){this._binding=e}return e.prototype.when=function(e){return this._binding.constraint=e,new r.BindingOnSyntax(this._binding)},e.prototype.whenTargetNamed=function(e){return this._binding.constraint=i.namedConstraint(e),new r.BindingOnSyntax(this._binding)},e.prototype.whenTargetIsDefault=function(){return this._binding.constraint=function(e){return null!==e.target&&!e.target.isNamed()&&!e.target.isTagged()},new r.BindingOnSyntax(this._binding)},e.prototype.whenTargetTagged=function(e,t){return this._binding.constraint=i.taggedConstraint(e)(t),new r.BindingOnSyntax(this._binding)},e.prototype.whenInjectedInto=function(e){return this._binding.constraint=function(t){return i.typeConstraint(e)(t.parentRequest)},new r.BindingOnSyntax(this._binding)},e.prototype.whenParentNamed=function(e){return this._binding.constraint=function(t){return i.namedConstraint(e)(t.parentRequest)},new r.BindingOnSyntax(this._binding)},e.prototype.whenParentTagged=function(e,t){return this._binding.constraint=function(n){return i.taggedConstraint(e)(t)(n.parentRequest)},new r.BindingOnSyntax(this._binding)},e.prototype.whenAnyAncestorIs=function(e){return this._binding.constraint=function(t){return i.traverseAncerstors(t,i.typeConstraint(e))},new r.BindingOnSyntax(this._binding)},e.prototype.whenNoAncestorIs=function(e){return this._binding.constraint=function(t){return!i.traverseAncerstors(t,i.typeConstraint(e))},new r.BindingOnSyntax(this._binding)},e.prototype.whenAnyAncestorNamed=function(e){return this._binding.constraint=function(t){return i.traverseAncerstors(t,i.namedConstraint(e))},new r.BindingOnSyntax(this._binding)},e.prototype.whenNoAncestorNamed=function(e){return this._binding.constraint=function(t){return!i.traverseAncerstors(t,i.namedConstraint(e))},new r.BindingOnSyntax(this._binding)},e.prototype.whenAnyAncestorTagged=function(e,t){return this._binding.constraint=function(n){return i.traverseAncerstors(n,i.taggedConstraint(e)(t))},new r.BindingOnSyntax(this._binding)},e.prototype.whenNoAncestorTagged=function(e,t){return this._binding.constraint=function(n){return!i.traverseAncerstors(n,i.taggedConstraint(e)(t))},new r.BindingOnSyntax(this._binding)},e.prototype.whenAnyAncestorMatches=function(e){return this._binding.constraint=function(t){return i.traverseAncerstors(t,e)},new r.BindingOnSyntax(this._binding)},e.prototype.whenNoAncestorMatches=function(e){return this._binding.constraint=function(t){return!i.traverseAncerstors(t,e)},new r.BindingOnSyntax(this._binding)},e}();t.BindingWhenSyntax=o},4753:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.typeConstraint=t.namedConstraint=t.taggedConstraint=t.traverseAncerstors=void 0;var r=n(1852),i=n(2811),o=function(e,t){var n=e.parentRequest;return null!==n&&(!!t(n)||o(n,t))};t.traverseAncerstors=o;var s=function(e){return function(t){var n=function(n){return null!==n&&null!==n.target&&n.target.matchesTag(e)(t)};return n.metaData=new i.Metadata(e,t),n}};t.taggedConstraint=s;var a=s(r.NAMED_TAG);t.namedConstraint=a;t.typeConstraint=function(e){return function(t){var n=null;if(null!==t){if(n=t.bindings[0],"string"==typeof e)return n.serviceIdentifier===e;var r=t.bindings[0].implementationType;return e===r}return!1}}},1549:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.multiBindToService=void 0;t.multiBindToService=function(e){return function(t){return function(){for(var n=[],r=0;r<arguments.length;r++)n[r]=arguments[r];return n.forEach((function(n){return e.bind(n).toService(t)}))}}}},3174:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.isStackOverflowExeption=void 0;var r=n(8705);t.isStackOverflowExeption=function(e){return e instanceof RangeError||e.message===r.STACK_OVERFLOW}},2145:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.id=void 0;var n=0;t.id=function(){return n++}},830:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.circularDependencyToException=t.listMetadataForTarget=t.listRegisteredBindingsForServiceIdentifier=t.getServiceIdentifierAsString=t.getFunctionName=void 0;var r=n(8705);function i(e){return"function"==typeof e?e.name:"symbol"==typeof e?e.toString():e}function o(e,t){return null!==e.parentRequest&&(e.parentRequest.serviceIdentifier===t||o(e.parentRequest,t))}function s(e){if(e.name)return e.name;var t=e.toString(),n=t.match(/^function\s*([^\s(]+)/);return n?n[1]:"Anonymous function: "+t}t.getServiceIdentifierAsString=i,t.listRegisteredBindingsForServiceIdentifier=function(e,t,n){var r="",i=n(e,t);return 0!==i.length&&(r="\nRegistered bindings:",i.forEach((function(e){var t="Object";null!==e.implementationType&&(t=s(e.implementationType)),r=r+"\n "+t,e.constraint.metaData&&(r=r+" - "+e.constraint.metaData)}))),r},t.circularDependencyToException=function e(t){t.childRequests.forEach((function(t){if(o(t,t.serviceIdentifier)){var n=function(e){var t=function e(t,n){void 0===n&&(n=[]);var r=i(t.serviceIdentifier);return n.push(r),null!==t.parentRequest?e(t.parentRequest,n):n}(e);return t.reverse().join(" --\x3e ")}(t);throw new Error(r.CIRCULAR_DEPENDENCY+" "+n)}e(t)}))},t.listMetadataForTarget=function(e,t){if(t.isTagged()||t.isNamed()){var n="",r=t.getNamedTag(),i=t.getCustomTags();return null!==r&&(n+=r.toString()+"\n"),null!==i&&i.forEach((function(e){n+=e.toString()+"\n"}))," "+e+"\n "+e+" - "+n}return" "+e},t.getFunctionName=s},2803:(e,t,n)=>{var r;!function(e){!function(){var t="object"==typeof n.g?n.g:"object"==typeof self?self:"object"==typeof this?this:Function("return this;")(),r=i(e);function i(e,t){return function(n,r){"function"!=typeof e[n]&&Object.defineProperty(e,n,{configurable:!0,writable:!0,value:r}),t&&t(n,r)}}void 0===t.Reflect?t.Reflect=e:r=i(t.Reflect,r),function(e){var t=Object.prototype.hasOwnProperty,n="function"==typeof Symbol,r=n&&void 0!==Symbol.toPrimitive?Symbol.toPrimitive:"@@toPrimitive",i=n&&void 0!==Symbol.iterator?Symbol.iterator:"@@iterator",o="function"==typeof Object.create,s={__proto__:[]}instanceof Array,a=!o&&!s,d={create:o?function(){return re(Object.create(null))}:s?function(){return re({__proto__:null})}:function(){return re({})},has:a?function(e,n){return t.call(e,n)}:function(e,t){return t in e},get:a?function(e,n){return t.call(e,n)?e[n]:void 0}:function(e,t){return e[t]}},l=Object.getPrototypeOf(Function),u="object"==typeof process&&process.env&&"true"===process.env.REFLECT_METADATA_USE_MAP_POLYFILL,c=u||"function"!=typeof Map||"function"!=typeof Map.prototype.entries?ee():Map,h=u||"function"!=typeof Set||"function"!=typeof Set.prototype.entries?te():Set,p=new(u||"function"!=typeof WeakMap?ne():WeakMap);function f(e,t,n,r){if(k(n)){if(!G(e))throw new TypeError;if(!H(t))throw new TypeError;return S(e,t)}if(!G(e))throw new TypeError;if(!j(t))throw new TypeError;if(!j(r)&&!k(r)&&!L(r))throw new TypeError;return L(r)&&(r=void 0),E(e,t,n=$(n),r)}function v(e,t){function n(n,r){if(!j(n))throw new TypeError;if(!k(r)&&!q(r))throw new TypeError;O(e,t,n,r)}return n}function g(e,t,n,r){if(!j(n))throw new TypeError;return k(r)||(r=$(r)),O(e,t,n,r)}function m(e,t,n){if(!j(t))throw new TypeError;return k(n)||(n=$(n)),I(e,t,n)}function y(e,t,n){if(!j(t))throw new TypeError;return k(n)||(n=$(n)),A(e,t,n)}function x(e,t,n){if(!j(t))throw new TypeError;return k(n)||(n=$(n)),M(e,t,n)}function b(e,t,n){if(!j(t))throw new TypeError;return k(n)||(n=$(n)),C(e,t,n)}function w(e,t){if(!j(e))throw new TypeError;return k(t)||(t=$(t)),P(e,t)}function _(e,t){if(!j(e))throw new TypeError;return k(t)||(t=$(t)),R(e,t)}function T(e,t,n){if(!j(t))throw new TypeError;k(n)||(n=$(n));var r=N(t,n,!1);if(k(r))return!1;if(!r.delete(e))return!1;if(r.size>0)return!0;var i=p.get(t);return i.delete(n),i.size>0||p.delete(t),!0}function S(e,t){for(var n=e.length-1;n>=0;--n){var r=(0,e[n])(t);if(!k(r)&&!L(r)){if(!H(r))throw new TypeError;t=r}}return t}function E(e,t,n,r){for(var i=e.length-1;i>=0;--i){var o=(0,e[i])(t,n,r);if(!k(o)&&!L(o)){if(!j(o))throw new TypeError;r=o}}return r}function N(e,t,n){var r=p.get(e);if(k(r)){if(!n)return;r=new c,p.set(e,r)}var i=r.get(t);if(k(i)){if(!n)return;i=new c,r.set(t,i)}return i}function I(e,t,n){if(A(e,t,n))return!0;var r=Z(t);return!L(r)&&I(e,r,n)}function A(e,t,n){var r=N(t,n,!1);return!k(r)&&z(r.has(e))}function M(e,t,n){if(A(e,t,n))return C(e,t,n);var r=Z(t);return L(r)?void 0:M(e,r,n)}function C(e,t,n){var r=N(t,n,!1);if(!k(r))return r.get(e)}function O(e,t,n,r){N(n,r,!0).set(e,t)}function P(e,t){var n=R(e,t),r=Z(e);if(null===r)return n;var i=P(r,t);if(i.length<=0)return n;if(n.length<=0)return i;for(var o=new h,s=[],a=0,d=n;a<d.length;a++){var l=d[a];o.has(l)||(o.add(l),s.push(l))}for(var u=0,c=i;u<c.length;u++){l=c[u];o.has(l)||(o.add(l),s.push(l))}return s}function R(e,t){var n=[],r=N(e,t,!1);if(k(r))return n;for(var i=X(r.keys()),o=0;;){var s=J(i);if(!s)return n.length=o,n;var a=K(s);try{n[o]=a}catch(e){try{Q(i)}finally{throw e}}o++}}function D(e){if(null===e)return 1;switch(typeof e){case"undefined":return 0;case"boolean":return 2;case"string":return 3;case"symbol":return 4;case"number":return 5;case"object":return null===e?1:6;default:return 6}}function k(e){return void 0===e}function L(e){return null===e}function B(e){return"symbol"==typeof e}function j(e){return"object"==typeof e?null!==e:"function"==typeof e}function F(e,t){switch(D(e)){case 0:case 1:case 2:case 3:case 4:case 5:return e}var n=3===t?"string":5===t?"number":"default",i=Y(e,r);if(void 0!==i){var o=i.call(e,n);if(j(o))throw new TypeError;return o}return V(e,"default"===n?"number":n)}function V(e,t){if("string"===t){var n=e.toString;if(U(n))if(!j(i=n.call(e)))return i;if(U(r=e.valueOf))if(!j(i=r.call(e)))return i}else{var r;if(U(r=e.valueOf))if(!j(i=r.call(e)))return i;var i,o=e.toString;if(U(o))if(!j(i=o.call(e)))return i}throw new TypeError}function z(e){return!!e}function W(e){return""+e}function $(e){var t=F(e,3);return B(t)?t:W(t)}function G(e){return Array.isArray?Array.isArray(e):e instanceof Object?e instanceof Array:"[object Array]"===Object.prototype.toString.call(e)}function U(e){return"function"==typeof e}function H(e){return"function"==typeof e}function q(e){switch(D(e)){case 3:case 4:return!0;default:return!1}}function Y(e,t){var n=e[t];if(null!=n){if(!U(n))throw new TypeError;return n}}function X(e){var t=Y(e,i);if(!U(t))throw new TypeError;var n=t.call(e);if(!j(n))throw new TypeError;return n}function K(e){return e.value}function J(e){var t=e.next();return!t.done&&t}function Q(e){var t=e.return;t&&t.call(e)}function Z(e){var t=Object.getPrototypeOf(e);if("function"!=typeof e||e===l)return t;if(t!==l)return t;var n=e.prototype,r=n&&Object.getPrototypeOf(n);if(null==r||r===Object.prototype)return t;var i=r.constructor;return"function"!=typeof i||i===e?t:i}function ee(){var e={},t=[],n=function(){function e(e,t,n){this._index=0,this._keys=e,this._values=t,this._selector=n}return e.prototype["@@iterator"]=function(){return this},e.prototype[i]=function(){return this},e.prototype.next=function(){var e=this._index;if(e>=0&&e<this._keys.length){var n=this._selector(this._keys[e],this._values[e]);return e+1>=this._keys.length?(this._index=-1,this._keys=t,this._values=t):this._index++,{value:n,done:!1}}return{value:void 0,done:!0}},e.prototype.throw=function(e){throw this._index>=0&&(this._index=-1,this._keys=t,this._values=t),e},e.prototype.return=function(e){return this._index>=0&&(this._index=-1,this._keys=t,this._values=t),{value:e,done:!0}},e}();return function(){function t(){this._keys=[],this._values=[],this._cacheKey=e,this._cacheIndex=-2}return Object.defineProperty(t.prototype,"size",{get:function(){return this._keys.length},enumerable:!0,configurable:!0}),t.prototype.has=function(e){return this._find(e,!1)>=0},t.prototype.get=function(e){var t=this._find(e,!1);return t>=0?this._values[t]:void 0},t.prototype.set=function(e,t){var n=this._find(e,!0);return this._values[n]=t,this},t.prototype.delete=function(t){var n=this._find(t,!1);if(n>=0){for(var r=this._keys.length,i=n+1;i<r;i++)this._keys[i-1]=this._keys[i],this._values[i-1]=this._values[i];return this._keys.length--,this._values.length--,t===this._cacheKey&&(this._cacheKey=e,this._cacheIndex=-2),!0}return!1},t.prototype.clear=function(){this._keys.length=0,this._values.length=0,this._cacheKey=e,this._cacheIndex=-2},t.prototype.keys=function(){return new n(this._keys,this._values,r)},t.prototype.values=function(){return new n(this._keys,this._values,o)},t.prototype.entries=function(){return new n(this._keys,this._values,s)},t.prototype["@@iterator"]=function(){return this.entries()},t.prototype[i]=function(){return this.entries()},t.prototype._find=function(e,t){return this._cacheKey!==e&&(this._cacheIndex=this._keys.indexOf(this._cacheKey=e)),this._cacheIndex<0&&t&&(this._cacheIndex=this._keys.length,this._keys.push(e),this._values.push(void 0)),this._cacheIndex},t}();function r(e,t){return e}function o(e,t){return t}function s(e,t){return[e,t]}}function te(){return function(){function e(){this._map=new c}return Object.defineProperty(e.prototype,"size",{get:function(){return this._map.size},enumerable:!0,configurable:!0}),e.prototype.has=function(e){return this._map.has(e)},e.prototype.add=function(e){return this._map.set(e,e),this},e.prototype.delete=function(e){return this._map.delete(e)},e.prototype.clear=function(){this._map.clear()},e.prototype.keys=function(){return this._map.keys()},e.prototype.values=function(){return this._map.values()},e.prototype.entries=function(){return this._map.entries()},e.prototype["@@iterator"]=function(){return this.keys()},e.prototype[i]=function(){return this.keys()},e}()}function ne(){var e=16,n=d.create(),r=i();return function(){function e(){this._key=i()}return e.prototype.has=function(e){var t=o(e,!1);return void 0!==t&&d.has(t,this._key)},e.prototype.get=function(e){var t=o(e,!1);return void 0!==t?d.get(t,this._key):void 0},e.prototype.set=function(e,t){return o(e,!0)[this._key]=t,this},e.prototype.delete=function(e){var t=o(e,!1);return void 0!==t&&delete t[this._key]},e.prototype.clear=function(){this._key=i()},e}();function i(){var e;do{e="@@WeakMap@@"+l()}while(d.has(n,e));return n[e]=!0,e}function o(e,n){if(!t.call(e,r)){if(!n)return;Object.defineProperty(e,r,{value:d.create()})}return e[r]}function s(e,t){for(var n=0;n<t;++n)e[n]=255*Math.random()|0;return e}function a(e){return"function"==typeof Uint8Array?"undefined"!=typeof crypto?crypto.getRandomValues(new Uint8Array(e)):"undefined"!=typeof msCrypto?msCrypto.getRandomValues(new Uint8Array(e)):s(new Uint8Array(e),e):s(new Array(e),e)}function l(){var t=a(e);t[6]=79&t[6]|64,t[8]=191&t[8]|128;for(var n="",r=0;r<e;++r){var i=t[r];4!==r&&6!==r&&8!==r||(n+="-"),i<16&&(n+="0"),n+=i.toString(16).toLowerCase()}return n}}function re(e){return e.__=void 0,delete e.__,e}e("decorate",f),e("metadata",v),e("defineMetadata",g),e("hasMetadata",m),e("hasOwnMetadata",y),e("getMetadata",x),e("getOwnMetadata",b),e("getMetadataKeys",w),e("getOwnMetadataKeys",_),e("deleteMetadata",T)}(r)}()}(r||(r={}))},9379:(e,t,n)=>{"use strict";n.r(t),n.d(t,{Inspectee:()=>zr});n(2803);var r=n(2993);function i(e,t,n,r){var i,o=arguments.length,s=o<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(i=e[a])&&(s=(o<3?i(s):o>3?i(t,n,s):i(t,n))||s);return o>3&&s&&Object.defineProperty(t,n,s),s}function o(e,t){return function(n,r){t(n,r,e)}}function s(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)}function a(e,t,n,r){return new(n||(n=Promise))((function(i,o){function s(e){try{d(r.next(e))}catch(e){o(e)}}function a(e){try{d(r.throw(e))}catch(e){o(e)}}function d(e){var t;e.done?i(e.value):(t=e.value,t instanceof n?t:new n((function(e){e(t)}))).then(s,a)}d((r=r.apply(e,t||[])).next())}))}var d,l,u="Adapter",c="Bridge",h="Inspectee",p={Props:"VirtualTreeProps"},f="Container";(l=d||(d={}))[l.Inspector=0]="Inspector",l[l.RendererInspectee=1]="RendererInspectee",l[l.ServiceInspectee=2]="ServiceInspectee",l[l.AllInspectee=3]="AllInspectee";var v=class{constructor(e=d.AllInspectee){this.callbacks=new Map,this.type=e}get inited(){return this._inited}init(){this.initSubscription(this.handleCDPMessage.bind(this)),this._inited=!0}emit(e){this.send(e)}reply(e,t){this.send({id:e,result:t})}on(e,t){this.callbacks.has(e)||this.callbacks.set(e,[]),this.callbacks.get(e).push(t)}off(e,t){if(this.callbacks.has(e)){var n=this.callbacks.get(e);n=[...n.filter((e=>e!==t))]}}handleCDPMessage(e,t,n){var r,i,o;((e,t)=>e===t||e&t)(this.type,t)&&("id"in e?null===(r=this.callbacks.get("command"))||void 0===r||r.forEach((t=>t(e,n))):null===(i=this.callbacks.get("event"))||void 0===i||i.forEach((t=>t(e,n))),null===(o=this.callbacks.get("all"))||void 0===o||o.forEach((t=>t(e,n))))}};v=function(e,t,n,r){var i,o=arguments.length,s=o<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(i=e[a])&&(s=(o<3?i(s):o>3?i(t,n,s):i(t,n))||s);return o>3&&s&&Object.defineProperty(t,n,s),s}([(0,r._G)(),function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)}("design:paramtypes",[Number])],v);var g=e=>!!e&&("object"==typeof e||"function"==typeof e)&&"function"==typeof e.then;var m=new WeakMap,y=new Map,x=(e,t={})=>{var n,r,i={},o=typeof e,s="";try{s=null===(n=null==e?void 0:e.toString)||void 0===n?void 0:n.call(e)}catch(e){s={}.toString()}if("object"===o||"function"===o||"symbol"===o){if(m.has(e))i.objectId=m.get(e);else{i.objectId="testid";try{e&&e instanceof Object&&m.set(e,i.objectId)}catch(t){console.error("objectToRemoteIdMap fail",t,e)}y.set(i.objectId,e)}if("object"===o){var a,d=null===(r=null==e?void 0:e.constructor)||void 0===r?void 0:r.name;if(d&&(i.className=d),Array.isArray(e)?a="array":null===e?a="null":e instanceof RegExp?a="regexp":e instanceof Date?a="date":e instanceof Map?a="map":e instanceof Set?a="set":e instanceof WeakMap?a="weakmap":e instanceof WeakSet?a="weakset":e instanceof Error?a="error":g(e)?a="promise":!function(e){try{return[Int8Array,Uint8Array,Uint8ClampedArray,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array].some((t=>e instanceof t))}catch(e){return!1}}(e)?e instanceof ArrayBuffer?a="arraybuffer":e instanceof DataView?a="dataview":globalThis.WebAssembly&&e instanceof globalThis.WebAssembly.Memory&&(a="webassemblymemory"):a="typedarray",a&&(i.subtype=a),t.generatePreview){var l={type:o,description:s,properties:Object.keys(e).flatMap((t=>e===globalThis&&"BabelRuntimeHelpers"===t?[]:Object.assign({name:t},x(e[t],{generatePreview:!1})))),overflow:!0};a&&(l.subtype=a),"map"===a?l.entries=[...e].map((([e,t])=>({key:e,value:x(t,{generatePreview:!1})}))):"set"===a&&(l.entries=[...e].map((e=>({value:x(e,{generatePreview:!1})})))),i.preview=l}}}else i.value=e;return Object.assign({type:o,description:s},i)},b=e=>y.get(e),w=e=>{var t=x(e);if(e instanceof Error){var{name:n,message:r}=e;return{text:n,exception:t}}return{text:"Unknown Error",exception:t}},_=Symbol("eval"),T=class{constructor(e=globalThis.eval){this.enabled=!1,this.eval=e,this._hookedConsole=function({beforeInvoke:e,afterInvoke:t,console:n=globalThis.console}){return new Proxy(n,{get(n,r,i){var o=Reflect.get(n,r);return"function"==typeof o&&"debug"!==r?function(...i){null==e||e({method:r,args:i,originConsole:n});var s=Reflect.apply(o,n,i);return null==t||t({method:r,args:i,ret:s,originConsole:n}),s}:o},getPrototypeOf:e=>null})}({beforeInvoke:({method:e,args:t,originConsole:n})=>{this.bridge.emit({method:"Runtime.consoleAPICalled",params:{type:e,args:t.map((e=>x(e,{generatePreview:!0}))),executionContextId:0,timestamp:Date.now()}})}})}get hookedConsole(){return this._hookedConsole}hookConsole(){var e;null!==(e=Reflect.get(console,Symbol.for("hooked")))&&void 0!==e&&e||(console=this._hookedConsole),Reflect.set(console,Symbol.for("hooked"),!0)}awaitPromise(e){return a(this,void 0,void 0,(function*(){var{promiseObjectId:t}=e,n=b(t);if(g(n))try{return{result:x(yield n)}}catch(e){return{exceptionDetails:w(e),result:x(e)}}var r="no such promise";return{exceptionDetails:w(r),result:x(r)}}))}callFunctionOn(e){throw new Error("Method not implemented.")}compileScript(e){throw new Error("Method not implemented.")}disable(){return a(this,void 0,void 0,(function*(){this.enabled=!1}))}discardConsoleEntries(){throw new Error("Method not implemented.")}enable(){return a(this,void 0,void 0,(function*(){this.enabled=!0}))}evaluate(e){return a(this,void 0,void 0,(function*(){var{expression:t,awaitPromise:n,returnByValue:r,generatePreview:i=!0}=e;try{var o=this.eval.call(globalThis,t);return n&&g(o)&&(o=yield o),{result:x(o,{returnByValue:r,generatePreview:i})}}catch(e){return{exceptionDetails:w(e),result:x(e)}}}))}getIsolateId(){throw new Error("Method not implemented.")}getHeapUsage(){throw new Error("Method not implemented.")}getProperties(e){return a(this,void 0,void 0,(function*(){var{objectId:t,ownProperties:n=!0,accessorPropertiesOnly:r=!1}=e,i=b(t),o=[];if(!i)return{result:o};if(o=Object.keys(i).map((e=>Object.assign(Reflect.getOwnPropertyDescriptor(i,e),{name:e,isOwn:!!Reflect.getOwnPropertyDescriptor(i,e)}))),i instanceof Map){var s=[...i];o.push({name:"[[Entries]]",value:s.length?s.map((([e,t])=>({key:e,value:t}))):"no entry"}),s.length&&o.push({name:"size",value:i.size})}if(i instanceof Set){var a=[...i];o.push({name:"[[Entries]]",value:a.length?a:"no entry"}),a.length&&o.push({name:"size",value:i.size})}return o=o.flatMap((e=>{if(i===globalThis&&"BabelRuntimeHelpers"===e.name)return[];var{get:t,set:n,value:r}=e;return r&&(e["symbol"===r?"symbol":"value"]=x(r)),t&&(e.get=x(t)),n&&(e.set=x(n)),e})),r&&(o=o.filter((e=>e.get||e.set))),{result:o}}))}globalLexicalScopeNames(e){throw new Error("Method not implemented.")}queryObjects(e){throw new Error("Method not implemented.")}releaseObject(e){return a(this,void 0,void 0,(function*(){var t;t=e.objectId,y.get(t)&&y.delete(t)}))}releaseObjectGroup(e){throw new Error("Method not implemented.")}runIfWaitingForDebugger(){throw new Error("Method not implemented.")}runScript(e){throw new Error("Method not implemented.")}setAsyncCallStackDepth(e){throw new Error("Method not implemented.")}setCustomObjectFormatterEnabled(e){throw new Error("Method not implemented.")}setMaxCallStackSizeToCapture(e){throw new Error("Method not implemented.")}terminateExecution(){throw new Error("Method not implemented.")}addBinding(e){throw new Error("Method not implemented.")}removeBinding(e){throw new Error("Method not implemented.")}on(e,t){throw new Error("Method not implemented.")}};i([(0,r.WQ)(c),s("design:type",v)],T.prototype,"bridge",void 0),T=i([(0,r._G)(),o(0,(0,r.WQ)(_)),o(0,(0,r.lq)()),s("design:paramtypes",[Object])],T);class S{constructor(e=0){this._id=e}get id(){return this._id++}reset(){this._id=0}}var E=new r.mc;function N(e="Default"){return(t,n,i)=>{(0,r.WQ)(u)(t,n,i),(0,r.KT)(e)(t,n,i)}}var I=(e,t)=>e.bind(p.Props).toConstantValue(t),A=(e,t)=>e.bind(c).toConstantValue(t),M=(e,t,n="Default")=>{var r=e.bind(u).to(t).inSingletonScope().whenTargetNamed(n);return"Default"===n&&r.onActivation(((e,t)=>new Proxy(t,{get:(e,t)=>"enabled"===t||(()=>a(void 0,void 0,void 0,(function*(){return{message:"N/A",domain:n}})))}))),r},C=(e,t)=>e.getNamed(u,t),O=(e,t)=>t.bind(null,e),P=class{constructor(){this.tempId=new S}get enabled(){var e,t;return null!==(t=null===(e=this.RuntimeAdapter)||void 0===e?void 0:e.enabled)&&void 0!==t&&t}saveToConsole({objectId:e="",value:t}){return a(this,void 0,void 0,(function*(){var n=null!=t?t:b(e);if(n){for(var r=`temp${this.tempId.id}`;Reflect.has(globalThis,r);)r=`temp${this.tempId.id}`;return Reflect.set(globalThis,r,n),r}}))}disable(){var e;return a(this,void 0,void 0,(function*(){null===(e=this.RuntimeAdapter)||void 0===e||e.disable()}))}enable(){var e;return a(this,void 0,void 0,(function*(){null===(e=this.RuntimeAdapter)||void 0===e||e.enable()}))}};i([N("Runtime"),(0,r.lq)(),s("design:type",T)],P.prototype,"RuntimeAdapter",void 0),P=i([(0,r._G)()],P);class R extends Map{constructor(){super(...arguments),this.revMap=new Map}set(e,t){return super.set(e,t),this.revMap.set(t,e),this}delete(e){var t=super.get(e),n=super.delete(e),r=this.revMap.delete(t);return n&&r}getRev(e){return this.revMap.get(e)}hasRev(e){return this.revMap.has(e)}}var D=class{constructor(){this.enabled=!0}};function k(e,t=1e3,n){var r;return function(...i){if(r&&clearTimeout(r),n){if(!r)return e.apply(null,i);r=setTimeout((()=>r=null),t)}else r=setTimeout((()=>e.apply(null,i)),t)}}function L(e){return function(...t){return new Promise((function(n,r){t.push((e=>{n(e)})),e(...t)}))}}D=i([(0,r._G)()],D);var B=null,j=["position","top","left","right","bottom","width","height","margin-right","margin-left","margin-top","margin-bottom","padding-left","padding-right","padding-top","padding-bottom","border-left-width","border-right-width","border-top-width","border-bottom-width"];var F=new class{get isSkyline(){return!!(null===window||void 0===window?void 0:window.__skylineEngine__)}getBoundingClientRect(e){return a(this,void 0,void 0,(function*(){var t;try{if(this.isSkyline){var n=L(e.getBoundingClientRect.bind(e));t=yield n()}else t=e.getBoundingClientRect()}catch(e){console.log("getComputedStyle: error",e)}return t}))}formatComputedStyle(e){var t={};return j.forEach((n=>{var r=function(e,t="_"){return e.replace(new RegExp(`\\${t}(\\w)`,"g"),(function(e,t){return t.toUpperCase()}))}(n,"-"),i=e[n]||e[r];"number"==typeof i&&(i=`${i}px`),t[n]=i})),t}getComputedStyle(e){return a(this,void 0,void 0,(function*(){var t={};try{if(this.isSkyline){var n=C(E,"DOM"),r=yield n.tree.getPageContext(),i=L(r.getComputedStyle.bind(r));t=yield i(e),t=this.formatComputedStyle(t)}else t=window.getComputedStyle(e)}catch(e){console.error("getComputedStyle: error",e)}return t}))}getWindowInfo(){return a(this,void 0,void 0,(function*(){if(this.isSkyline){var e=C(E,"DOM"),t=yield e.tree.getPageContext(),{clientHeight:n,clientWidth:r,scrollLeft:i=0,scrollTop:o=0}=t;return{innerHeight:n,innerWidth:r,scrollTop:o,scrollLeft:i}}return{innerHeight:window.innerHeight,innerWidth:window.innerWidth,scrollTop:window.scrollY,scrollLeft:window.screenX}}))}getAttribute(e,t){var n,r,i;return"id"===t?(null===(n=e.$$)||void 0===n?void 0:n.id)||"":"classList"===t?(null===(r=e.$$)||void 0===r?void 0:r.classList)||[]:null===(i=e.$$)||void 0===i?void 0:i.getAttribute(t)}appendChild(e,t,n=!0){e.appendChild(t),n&&this.startRender()}getStyle(e){return this.isSkyline?((null==e?void 0:e.__styleSegments)||[]).join(""):e.$$.getAttribute("style")}parseStyle2Map(e=""){var t=e.split(";"),n={};return t.length&&t.forEach((e=>{var t=e.split(":");2===t.length&&(n[t[0]]=t[1])})),n}updateStyle(e,t,n=!0){var r=this.getStyle(e),i=this.parseStyle2Map(r),o=this.parseStyle2Map(t),s=Object.assign(Object.assign({},i),o),a="";for(var d in s)a+=`${d}:${s[d]};`;this.setStyle(e,a,n)}setStyle(e,t,n=!0){e.setNodeStyle(t),n&&this.startRender()}startRender(){return a(this,void 0,void 0,(function*(){this.isSkyline&&(B&&clearTimeout(B),B=setTimeout((()=>a(this,void 0,void 0,(function*(){var e=C(E,"DOM");(yield e.tree.getPageContext()).startRender(),B=null}))),100))}))}};class V{}var z={showInfo:!0,showAccessibilityInfo:!0,showStyles:!0,contentColor:{r:161,g:197,b:232,a:.66},paddingColor:{r:196,g:222,b:184,a:.55},borderColor:{r:255,g:229,b:153,a:.66},marginColor:{r:246,g:178,b:107,a:.5},eventTargetColor:{r:255,g:196,b:196,a:.66},shapeColor:{r:96,g:82,b:177,a:.8},shapeMarginColor:{r:96,g:82,b:127,a:.6}},W='\n  all: unset;\n  pointer-events: none;\n  top: 100%;\n  margin-top: -4px;\n  transform: rotate(45deg) skewX(5deg) skewY(5deg);\n  content: "";\n  position: absolute;\n  z-index: -100;\n  left: 10px;\n  width: 8px;\n  height: 8px;\n  border-radius: 0 0 2px 0;\n  background: #ffffff;\n  bottom: 100%;\n  margin-bottom: -4px;\n',$="__wx_inspectee_highlight__";function G(e,t){var n=e.__wxSlotChildren[0].createNativeNode("wx-inspectee-highlight-element");return n.id=`${$}${t}`,n}function U(e,t){var n=e.__wxSlotChildren[0].createTextNode("wx-text");return n.id=`${$}${t}`,n}function H(e){return e.id&&e.id.startsWith($)}function q(){return a(this,void 0,void 0,(function*(){var e=yield function(){return a(this,void 0,void 0,(function*(){return new Promise(((e,t)=>{wx.getCurrentWebviewId({success(t){e(t.webviewId)},fail(){t()}})}))}))}();return __virtualDOM__.getDomTreeByPageId(e)}))}var Y,X=(Y=9e5,()=>Y++),K=function(e){return("0"+parseInt(e,10).toString(16)).slice(-2)},J={};class Q{constructor(e,t){this.domTree=e,this.viewId=X(),this.node=G(this.domTree,this.viewId.toString());var n=J[t];n?(F.appendChild(n,this.node),F.setStyle(this.node,"pointer-events: none;position:absolute;top:0;left:0;width:0;height:0;")):(F.appendChild(this.domTree.__wxSlotChildren[0],this.node),F.setStyle(this.node,"pointer-events: none;position:fixed;top:0;left:0;width:0;height:0;")),J[this.viewId]=this.node}update(e={}){var{position:t={},style:n={}}=e,r="pointer-events: none;";for(var i in t)r+=`${i}:${t[i]}px;`;for(var o in n)r+=`${o}:${n[o]};`;F.setStyle(this.node,r)}hide(){F.setStyle(this.node,"pointer-events: none;position:absolute;top:0;left:0;width:0;height:0;")}destroy(){this.domTree.__wxSlotChildren[0].removeChild(this.node),delete J[this.viewId],this.node=null}}var Z,ee=new class extends V{constructor(){super(),this.resetDOM(),this.resetTips(),this._target=null,this._tasks=[],this._runing=!1}resetTips(){this._tipsInited=!1,this._inspectTipsContainer=null,this._tagContainer=null,this._tagNameTips=null,this._tagNameTipsText=null,this._idTips=null,this._idTipsText=null,this._classTips=null,this._classTipsText=null,this._inspectTipsSep=null,this._sizeTips=null,this._sizeTipsText=null,this._arrowTips=null}initTips(){this._inspectTipsContainer=G(this._domTree,"inspectTag"),this._tagContainer=G(this._domTree,"tagContainer"),this._tagNameTips=G(this._domTree,"tagNameTips"),this._tagNameTipsText=U(this._domTree,"inspectTagText"),this._idTips=G(this._domTree,"idTips"),this._idTipsText=U(this._domTree,"idTipsText"),this._classTips=G(this._domTree,"classTips"),this._classTipsText=U(this._domTree,"classTipsText"),this._inspectTipsSep=G(this._domTree,"inspectTipsSep"),this._sizeTips=G(this._domTree,"sizeTip"),this._sizeTipsText=U(this._domTree,"sizeTipText"),this._arrowTips=G(this._domTree,"arrowTip"),F.setStyle(this._inspectTipsContainer,"\n  all: unset;\n  pointer-events: none;\n  display: flex;\n  flex-direction: row;\n  position: absolute;\n  padding: 4px 10px;\n  font-size: 12px;\n  color: #d9d9d9;\n  background-color: #ffffff;\n  z-index: 8000;\n  border-radius: 2px;\n  cursor: default;\n  box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 2px;\n  box-sizing: border-box;\n",!1),F.setStyle(this._tagContainer,"\n  all: unset;\n  pointer-events: none;\n  display: flex; \n  flex-direction: \n  row; margin: auto; \n  word-break: break-all; \n  flex-shrink: 2;\n",!1),F.setStyle(this._tagNameTips,"\n  all: unset;\n  pointer-events: none;\n  display:inline-block;\n  color:#df80e1;\n",!1),F.setStyle(this._idTips,"\n  all: unset;\n  pointer-events: none;\n  display:inline-block;\n  color: #f3ae71;\n",!1),F.setStyle(this._classTips,"\n  all: unset;\n  pointer-events: none;\n  display:inline-block;\n  color: #98cbef;\n",!1),F.setStyle(this._inspectTipsSep,"\n  all: unset;\n  pointer-events: none;\n  display: inline-block;\n  align-self: center;\n  height: 100%;\n  vertical-align: middle;\n  width: 1px;\n  height: 18px;\n  background-color: rgba(204,204,204,0.5);\n  margin: 0 8px;\n",!1),F.setStyle(this._sizeTips,"\n  all: unset;\n  pointer-events: none;\n  display:inline-block;\n  color: #ccc; \n  font-size: 11px; \n  white-space: nowrap; \n  align-self: center;\n",!1),F.setStyle(this._arrowTips,W,!1),F.appendChild(this._tagNameTips,this._tagNameTipsText,!1),F.appendChild(this._idTips,this._idTipsText,!1),F.appendChild(this._classTips,this._classTipsText,!1),F.appendChild(this._sizeTips,this._sizeTipsText,!1),F.appendChild(this._tagContainer,this._tagNameTips,!1),F.appendChild(this._tagContainer,this._idTips,!1),F.appendChild(this._tagContainer,this._classTips,!1),F.appendChild(this._inspectTipsContainer,this._tagContainer,!1),F.appendChild(this._inspectTipsContainer,this._inspectTipsSep,!1),F.appendChild(this._inspectTipsContainer,this._sizeTips,!1),F.appendChild(this._inspectTipsContainer,this._arrowTips,!1),F.startRender(),this._tipsInited=!0}hideTips(){this._tipsInited&&F.updateStyle(this._inspectTipsContainer,"display: none;")}destroyTips(){this._tipsInited&&(this._inspectTipsContainer&&this._inspectTipsContainer.parentNode&&this._inspectTipsContainer.parentNode.removeChild(this._inspectTipsContainer),this.resetTips(),this._tipsInited=!1)}resetDOM(){this._domInited=!1,this._dom=null,this._borderDom=null,this._paddingDom=null,this._sizeDom=null}initDOM(){this._dom=new Q(this._domTree,0),this._borderDom=new Q(this._domTree,this._dom.viewId),this._paddingDom=new Q(this._domTree,this._dom.viewId),this._sizeDom=new Q(this._domTree,this._dom.viewId),this._domInited=!0}hideDOM(){this._dom&&this._dom.update({style:{display:"none"}})}destroyDOM(){this._dom&&(this._dom.destroy(),this.resetDOM())}setTips(e){return a(this,void 0,void 0,(function*(){if(this._target){var{top:t,left:n,width:r,height:i,contentWidth:o,contentHeight:s}=e,a=(this._target.is||"").replace(/^wx-/,"").toLowerCase();"body"===a&&(a="page"),this._tagNameTipsText.textContent=a;var d=F.getAttribute(this._target,"id");this._idTipsText.textContent=d?`#${d}`:"";var l=F.getAttribute(this._target,"classList"),u=Array.prototype.map.call(l,(e=>`.${e}`)).join("");this._classTipsText.textContent=u?`${u}`:"",this._sizeTipsText.textContent=`${this.pruneNum(o)} x ${this.pruneNum(s)}`;var c="display:block;",{innerWidth:h,innerHeight:p}=yield F.getWindowInfo(),f=h-100,v=20+6.2*(this._tagNameTipsText.textContent.length+this._idTipsText.textContent.length+this._classTipsText.textContent.length)+16+1+6*this._sizeTipsText.textContent.length;c+=`max-width:${f}px;min-width:120px;width:${v}px;`,F.appendChild(this._domTree.__wxSlotChildren[0],this._inspectTipsContainer),F.updateStyle(this._inspectTipsContainer,c);var g=(yield F.getBoundingClientRect(this._inspectTipsContainer.$$)).height,m=n+Math.min(f,v)>h,y=e=>{if(m){F.setStyle(this._arrowTips,e?'\n  all: unset;\n  pointer-events: none;\n  top: 100%;\n  margin-top: -4px;\n  transform: rotate(45deg) skewX(5deg) skewY(5deg);\n  content: "";\n  position: absolute;\n  z-index: -100;\n  right: 10px;\n  width: 8px;\n  height: 8px;\n  border-radius: 0 0 2px 0;\n  background: #ffffff;\n  bottom: 100%;\n  margin-bottom: -4px;\n':'\n  all: unset;\n  pointer-events: none;\n  bottom: 100%;\n  margin-bottom: -4px;\n  transform: rotate(225deg) skewX(5deg) skewY(5deg);\n  content: "";\n  position: absolute;\n  z-index: -100;\n  right: 10px;\n  width: 8px;\n  height: 8px;\n  border-radius: 0 0 2px 0;\n  background: #ffffff;\n');var t=r+n-Math.min(f,v);c+=`left:${Math.max(0,t)}px;`,t<0&&(c+=`width:${Math.min(f,v)+t}px;`)}else F.setStyle(this._arrowTips,e?W:'\n  all: unset;\n  pointer-events: none;\n  bottom: 100%;\n  margin-bottom: -4px;\n  transform: rotate(225deg) skewX(5deg) skewY(5deg);\n  content: "";\n  position: absolute;\n  z-index: -100;\n  left: 10px;\n  width: 8px;\n  height: 8px;\n  border-radius: 0 0 2px 0;\n  background: #ffffff;\n'),c+=`left:${n}px;`};if(t>p-t-i){y(!0);var x=t-g-4;c+=`top:${x>0?x:0}px;`}else{y(!1);var b=t+i+4;c+=`top:${b+g<p?b:p-g}px;`}F.updateStyle(this._inspectTipsContainer,c)}}))}show(e,t=z){return a(this,void 0,void 0,(function*(){this._tasks.push({type:"show",target:e,config:t}),this.handleTasks()}))}hide(){this._tasks.push({type:"hide"}),this.handleTasks()}handleTasks(){return a(this,void 0,void 0,(function*(){var e=yield q();if(e&&this._domTree===e||(this._runing=!1),this._tasks.length&&!this._runing){for(this._runing=!0;this._tasks.length;){var t=this._tasks.shift();try{"show"===t.type?yield this.handleShowTask(e,t.target,t.config):this.handleHideTask()}catch(e){console.error("handle highlight task fail:",t,e)}finally{this._runing=!1}}this._runing=!1}}))}handleShowTask(e,t,n=z){return a(this,void 0,void 0,(function*(){try{if(!t||t===this._target||!t.$$)return;this._domTree!==e&&(this.destroyDOM(),this.destroyTips()),this._domTree=e,this._tipsInited||this.initTips(),this._domInited||this.initDOM(),this._target=t;var r=yield F.getBoundingClientRect(t.$$),i=yield F.getComputedStyle(t.$$),o={};["width","height","margin-left","margin-right","margin-top","margin-bottom","padding-left","padding-right","padding-top","padding-bottom","border-left-width","border-right-width","border-top-width","border-bottom-width"].forEach((e=>{o[e]=parseFloat(i[e].replace("px",""))}));var{top:s,left:a,width:d,height:l}=r,{scrollLeft:u,scrollTop:c}=yield F.getWindowInfo();this._dom.update({style:Object.assign(Object.assign({},this.formatConfigColorRgba(n,"marginColor")),{position:"absolute",display:"block"}),position:{top:s-o["margin-top"]+c,left:a-o["margin-left"]+u,width:d+o["margin-left"]+o["margin-right"],height:l+o["margin-top"]+o["margin-bottom"]}}),this._borderDom.update({style:Object.assign(Object.assign({},this.formatConfigColorRgba(n,"borderColor")),{position:"absolute",display:"block"}),position:{top:o["margin-top"],left:o["margin-left"],width:d,height:l}}),this._paddingDom.update({style:Object.assign(Object.assign({},this.formatConfigColorRgba(n,"paddingColor")),{position:"absolute",display:"block"}),position:{top:o["margin-top"]+o["border-top-width"],left:o["margin-left"]+o["border-left-width"],width:d-o["border-left-width"]-o["border-right-width"],height:l-o["border-top-width"]-o["border-bottom-width"]}}),this._sizeDom.update({style:Object.assign(Object.assign({},this.formatConfigColorRgba(n,"contentColor")),{position:"absolute",display:"block"}),position:{top:o["margin-top"]+o["border-top-width"]+o["padding-top"],left:o["margin-left"]+o["border-left-width"]+o["padding-left"],width:d-o["border-left-width"]-o["border-right-width"]-o["padding-left"]-o["padding-right"],height:l-o["border-top-width"]-o["border-bottom-width"]-o["padding-top"]-o["padding-bottom"]}}),yield this.setTips({top:s-o["margin-top"]+c,left:a-o["margin-left"]+u,width:d+o["margin-left"]+o["margin-right"],height:l+o["margin-top"]+o["margin-bottom"],contentWidth:d,contentHeight:l})}catch(e){"cancel"!==e.message&&console.error("highlight show error:",e)}}))}handleHideTask(){this.hideDOM(),this.hideTips(),this._target=null,F.startRender()}pruneNum(e){return e.toFixed(2).replace(/\.?(0{1,})$/i,"")}formatConfigColorRgba(e,t={}){if(e[t]){var{r:n,g:r,b:i,a:o}=e[t];return{background:`#${K(n)}${K(r)}${K(i)}`,opacity:o}}}},te="#text",ne=new Set(["class","is"]);!function(e){e[e.Unknown=0]="Unknown",e[e.TextNode=1]="TextNode",e[e.VirtualNode=2]="VirtualNode",e[e.Component=3]="Component",e[e.NativeNode=4]="NativeNode",e[e.Element=5]="Element"}(Z||(Z={}));class re{constructor({exparser:e,root:t,customTabbar:n,hideVirtual:r=!0}){var i;this.name="mini-app",this.nodeId=new S(4),this.inspectedId=new S(0),this.nodeIdMap=new Map,this.idNodeMap=new Map,this.options={},this.skippedDOMAttrs=ne,this.getNodeType=e=>e instanceof this.exparser.TextNode?Z.TextNode:e instanceof this.exparser.VirtualNode?Z.VirtualNode:e instanceof this.exparser.Component?Z.Component:e instanceof this.exparser.NativeNode?Z.NativeNode:e instanceof this.exparser.Element?Z.Element:Z.Unknown,this.getNodeName=(e,t="")=>{throw new Error("no implement")},this.domify=({root:e,node:t,nodeId:n,customTabbar:r,currentDepth:i=1,depth:o=1,parentId:s,emit:a,env:d={},defalutNodeName:l=""}={})=>{var u,c,h,p,f,v,g,m;if(t?this.nodeIdMap.has(t)||(n=this.nodeId.id,this.addToMap(t,n)):n?t=this.getNodeById(n):r?(t=this.customTabbar,this.addToMap(t,4)):(t=e,this.addToMap(t,3)),!t)return null;n||(n=this.nodeIdMap.get(t));var y=this.getNodeType(t),x={type:y};if(this.observeNode({root:e,emit:a,nodeId:n}),y===Z.TextNode)return{nodeId:n,parentId:s,backendNodeId:n,nodeType:3,nodeName:te,localName:te,nodeValue:t.textContent};x.is=t.is,x.parentId=s,x.nodeType=1,x.nodeId=x.backendNodeId=n,x.nodeName=x.localName=this.getNodeName(t,l),t.__component__&&(x.component=t.__component__,x.componentId=parseInt(this.getAttributeValue(t,"wx:nodeid"))),"slot"===(null===(u=null==t?void 0:t.__wxSlotParent)||void 0===u?void 0:u.is)&&"string"==typeof(null===(c=null==t?void 0:t.__wxSlotParent)||void 0===c?void 0:c.__slotName)&&(null===(f=null===(p=null===(h=null==t?void 0:t.__wxSlotParent)||void 0===h?void 0:h.ownerShadowRoot)||void 0===p?void 0:p.__wxHost)||void 0===f?void 0:f.__component__)&&!(null===(m=null===(g=null===(v=null==t?void 0:t.__wxSlotParent)||void 0===v?void 0:v.ownerShadowRoot)||void 0===g?void 0:g.__wxHost)||void 0===m?void 0:m.__virtual)&&(x.slotParentId=parseInt(this.getAttributeValue(t.__wxSlotParent.ownerShadowRoot.__wxHost,"wx:nodeid")));var b=this.getChildren(t),w=[];if(this.options.hideVirtual&&t!==this.customTabbar&&(y===Z.VirtualNode||t.__component__&&t.__virtual))return null==b||b.forEach(((t,n)=>{if(!H(t)){var r=this.domify({root:e,node:t,depth:o,currentDepth:i,parentId:s,emit:a,defalutNodeName:l});r&&(Array.isArray(r)?w.push(...r):w.push(r))}})),w;(i<=o||-1===o)&&(null==b||b.forEach(((t,n)=>{if(!H(t)){var r=this.domify({root:e,node:t,depth:o,currentDepth:i+1,parentId:x.nodeId,emit:a,defalutNodeName:l});r&&(Array.isArray(r)?w.push(...r):w.push(r))}})),x.children=i!==o&&w.length?w:void 0,x.childNodeCount=null==w?void 0:w.length);var _=this.getAttributes(t);return _.length&&(x.attributes=_),x},this.setInspectedNode=e=>(this.inspectedNode=this.getNodeById(e),this.inspectedNode?e:null),this.setInspectedNodeForExparser=e=>{var t,{node:n,variableName:r}=null!==(t=this.idNodeMap.get(e))&&void 0!==t?t:{};if(!n)return null;if(!r){for(r=`$$${this.inspectedId.id}`;Reflect.has(globalThis,r);)r=`$$${this.inspectedId.id}`;this.idNodeMap.get(e)&&(this.idNodeMap.get(e).variableName=r)}return Reflect.set(globalThis,r,n),r},this.findLogicalParent=e=>this.options.hideVirtual?this.findNearestNonVirtualAncestor(e):this.getParent(e),this.getChildren=e=>{var t;return"string"==typeof e.__slotName?this.findNearestNonVirtualChildren(null===(t=e.ownerShadowRoot)||void 0===t?void 0:t.__wxHost).filter((t=>"slot"===t.is||t.slot===e.__slotName)):e.__component__?[e.shadowRoot]:e.childNodes||[]},this.getSibling=(e,t="prev")=>{var n,{hideVirtual:r}=this.options,i=this.getParent(e),o=this.getChildren(i),s=Array.prototype.indexOf.call(o,e);if(o.length<2||s<0||"next"===t&&s===o.length-1||"prev"===t&&0===s)return r&&this.isVirtual(i)?this.getSibling(i,t):null;if("prev"===t)for(n=o[s-1];r&&this.isVirtual(n);){var a=this.getChildren(n);n=a[a.length-1]}else for(n=o[s+1];r&&this.isVirtual(n);){n=this.getChildren(n)[0]}return null!=n?n:null},this.observeNode=({root:e,nodeId:t=-1,emit:n})=>{var r,{node:i,observer:o}=null!==(r=this.idNodeMap.get(t))&&void 0!==r?r:{};i&&(o||(o=this.exparser.Observer.create((r=>{var o,s,a,d,l,u,c,h,p;switch(r.type){case"characterData":var f=i.textContent;null==n||n({method:"DOM.characterDataModified",params:{nodeId:t,characterData:f}});break;case"properties":var v=r.propertyName,g=i[v];if(this.options.hideVirtual&&(null===(o=null==r?void 0:r.target)||void 0===o?void 0:o.__virtual))return;null==g?null==n||n({method:"DOM.attributeRemoved",params:{nodeId:t,name:v}}):null==n||n({method:"DOM.attributeModified",params:{nodeId:t,name:v,value:"number"==typeof g?g.toString():g}});break;case"childList":var m=this.nodeIdMap.get(r.target),y=(null===(s=i.childNodes)||void 0===s?void 0:s.length)||0,x=y;if(null===(a=r.removedNodes)||void 0===a?void 0:a.length)for(var b of(x=y-(null===(d=r.removedNodes)||void 0===d?void 0:d.length),r.removedNodes))if(!H(b)){var w=null!==(l=this.nodeIdMap.get(b))&&void 0!==l?l:-1;null==n||n({method:"DOM.childNodeRemoved",params:{parentNodeId:m,nodeId:w}}),this.nodeIdMap.delete(b),this.idNodeMap.delete(w);var{observer:_}=null!==(u=this.idNodeMap.get(t))&&void 0!==u?u:{};null==_||_.disconnect()}if(null===(c=r.addedNodes)||void 0===c?void 0:c.length)for(var T of(x=y+(null===(h=r.addedNodes)||void 0===h?void 0:h.length),r.addedNodes))if(!H(T)){var S=null!==(p=this.nodeIdMap.get(this.getSibling(T)))&&void 0!==p?p:-1,E=this.domify({root:e,node:T,parentId:m,emit:n});n({method:"DOM.childNodeInserted",params:{parentNodeId:m,previousNodeId:S,node:E}})}x!==y&&(null==n||n({method:"DOM.childNodeCountUpdated",params:{nodeId:t,childNodeCount:y}}))}})),o.observe(i,{properties:!0,childList:!0,characterData:i instanceof this.exparser.TextNode}),this.idNodeMap.set(t,{node:i,observer:o})))},this._exparser=e,this._root=t,this._customTabbar=n,this.options={hideVirtual:r},this.document={nodeId:1,backendNodeId:1,childNodeCount:1,children:[],nodeType:9,nodeName:"#document"};var o={parentId:1,nodeId:2,backendNodeId:2,nodeType:10,nodeName:this.name};null===(i=this.document.children)||void 0===i||i.push(o),this.registerCustomComponents()}getRoot(){return a(this,void 0,void 0,(function*(){throw new Error("no implement")}))}get exparser(){return this._exparser?this._exparser():window.exparser}get virtualDOM(){return this._virtualDOM?this._virtualDOM():window.__virtualDOM__}get customTabbar(){return this._customTabbar?this._customTabbar():window.__TAB_BAR__}get webviewEngine(){return this._webviewEngine?this._webviewEngine():window.__webviewEngine__}get skylineEngine(){return this._skylineEngine?this._skylineEngine():window.__skylineEngine__}registerCustomComponents(){this.exparser.registerElement({is:"wx-inspectee-highlight-element",template:"<span></span>",behaviors:["wx-base"],properties:{},attached(){}})}getPageContext(){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}getPageContextId(){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}getStyleSCopeId(e,t){return this.webviewEngine.getStyleSheetScope(e,t)}addToMap(e,t){this.nodeIdMap.set(e,t),this.idNodeMap.set(t,{node:e}),e.setAttribute&&e.setAttribute("wx:nodeid",t)}removeNode(e){var t;return a(this,void 0,void 0,(function*(){var n=this.getNodeById(e);if(n!==(yield this.getRoot())){var r=this.getObserverById(e);r&&r.disconnect(),null===(t=n.parentNode)||void 0===t||t.removeChild(n),this.nodeIdMap.delete(n),this.idNodeMap.delete(e)}}))}getNodeById(e){var t;return null===(t=this.idNodeMap.get(e))||void 0===t?void 0:t.node}getObserverById(e){var t;return null===(t=this.idNodeMap.get(e))||void 0===t?void 0:t.observe}requestIdForNode(e){var t=this.nodeIdMap.get(e);return t||(t=this.nodeId.id,this.addToMap(e,t)),t}isWxComponent(e){var t;return null===(t=e.is)||void 0===t?void 0:t.startsWith("wx-")}spreadScopeData(){this.virtualDOM?this.virtualDOM.spreadScopeDataToDOMNode():setTimeout((()=>{this.spreadScopeData()}),200)}isVirtual(e){return e instanceof this.exparser.VirtualNode}getParent(e){return this.isVirtual(e)?e.__wxSlotParent:e.parentNode}findNearestNonVirtualAncestor(e){for(var t=e;this.isVirtual(t);)t=t.__wxSlotParent;return null==t?void 0:t.parentNode}findNearestNonVirtualChildren(e){var t=e.childNodes||[],n=[];return t.forEach((e=>{this.isVirtual(e)&&"slot"!==e.is?n=n.concat(this.findNearestNonVirtualChildren(e)):n.push(e)})),n}getDocument({depth:e,emit:t}={}){return a(this,void 0,void 0,(function*(){var n=yield this.getRoot();if(!n)return this.document;var r=this.domify({root:n,depth:e,parentId:this.document.nodeId,emit:t});if(this.document.children[1]=r,this.customTabbar){var i=this.domify({root:n,depth:e,parentId:this.document.nodeId,emit:t,customTabbar:!0});this.document.children[2]=i}return this.document.childNodeCount=this.document.children.length,this.document}))}}var ie=class{constructor(){this.enabled=!1}getExparserNodeFromParams(e){return a(this,void 0,void 0,(function*(){var t,{nodeId:n,backendNodeId:r,objectId:i}=e;if(n||r)t=this.tree.getNodeById(n||r);else if(i){var o=yield this.requestNode({objectId:i});t=this.tree.getNodeById(o.nodeId)}return t||console.warn("can not found node",e),t}))}scrollIntoViewIfNeeded(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}collectClassNamesFromSubtree(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}copyTo(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}describeNode(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}discardSearchResults(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}disable(){return a(this,void 0,void 0,(function*(){this.enabled=!1}))}enable(){return a(this,void 0,void 0,(function*(){this.enabled=!0}))}focus(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}getAttributes(e){return a(this,void 0,void 0,(function*(){var{nodeId:t}=e,n=yield this.getExparserNodeFromParams({nodeId:t});return{attributes:this.tree.getAttributes(n)}}))}getBoxModel(e){throw new Error("Method not implemented.")}getContentQuads(e){throw new Error("Method not implemented.")}getDocument(e){return a(this,void 0,void 0,(function*(){var{depth:t=2}=e;try{return{root:yield this.tree.getDocument({depth:t,emit:e=>{this.bridge.emit(e)}})}}catch(e){throw console.error(e),e}}))}getFlattenedDocument(e){throw new Error("Method not implemented.")}getNodesForSubtreeByStyle(e){throw new Error("Method not implemented.")}getNodeForLocation(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}getOuterHTML(e){throw new Error("Method not implemented.")}getRelayoutBoundary(e){throw new Error("Method not implemented.")}getSearchResults(e){throw new Error("Method not implemented.")}hideHighlight(){return a(this,void 0,void 0,(function*(){this.highlight.hide()}))}highlightNode(e){return a(this,void 0,void 0,(function*(){var{nodeId:t,backendNodeId:n,objectId:r,selector:i,highlightConfig:o={}}=e||{},s=yield this.getExparserNodeFromParams({nodeId:t,backendNodeId:n,objectId:r});s&&i&&(s=s.querySelector(i)),s&&(yield this.highlight.show(s,o))}))}highlightRect(){throw new Error("Method not implemented.")}markUndoableState(){throw new Error("Method not implemented.")}moveTo(e){throw new Error("Method not implemented.")}performSearch(e){throw new Error("Method not implemented.")}pushNodeByPathToFrontend(e){throw new Error("Method not implemented.")}pushNodesByBackendIdsToFrontend(e){return a(this,void 0,void 0,(function*(){var{backendNodeIds:t}=e;return{nodeIds:t}}))}querySelector(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}querySelectorAll(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}redo(){throw new Error("Method not implemented.")}removeAttribute(e){return a(this,void 0,void 0,(function*(){var{nodeId:t,name:n}=e,r=yield this.getExparserNodeFromParams(e);this.tree.removeAttributes(r,n),this.bridge.emit({method:"DOM.attributeRemoved",params:{nodeId:t,name:n}})}))}setAttributeValue(e){return a(this,void 0,void 0,(function*(){var{nodeId:t,name:n,value:r}=e,i=yield this.getExparserNodeFromParams(e);this.tree.setAttributeValue(i,n,r),this.bridge.emit({method:"DOM.attributeModified",params:{nodeId:t,name:n,value:r}})}))}setAttributesAsText(e){return a(this,void 0,void 0,(function*(){var{name:t,nodeId:n,text:r}=e;if(!t)throw new Error("invalid name");for(var i=yield this.getExparserNodeFromParams(e),o={},s=r.match(/(\w+)(-\w+)?\s*=\s*['"]([^"]*)['"]/g)||[],a=0,d=s.length;a<d;a++){var l=s[a].split("="),u=l[0].trim(),c=l[1]?l[1].trim().replace(/^"/,"").replace(/"$/,""):"true";o[u]=c,this.tree.getAttributeValue(i,u)!==c&&this.setAttributeValue({nodeId:n,name:u,value:c})}t&&!o[t]&&this.removeAttribute({nodeId:n,name:t})}))}removeNode(e){return a(this,void 0,void 0,(function*(){var{nodeId:t}=e;yield this.tree.removeNode(t)}))}requestChildNodes(e){var t;return a(this,void 0,void 0,(function*(){var{nodeId:n,depth:r=2,pierce:i}=e,o=this.tree.domify({depth:r,nodeId:n,emit:e=>{this.bridge.emit(e)}});this.bridge.emit({method:"DOM.setChildNodes",params:{parentId:n,nodes:null!==(t=o.children)&&void 0!==t?t:[]}})}))}requestNode(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}resolveNode(e){return a(this,void 0,void 0,(function*(){throw new Error("Method not implemented.")}))}setFileInputFiles(e){throw new Error("Method not implemented.")}setNodeStackTracesEnabled(e){throw new Error("Method not implemented.")}getNodeStackTraces(e){throw new Error("Method not implemented.")}getFileInfo(e){throw new Error("Method not implemented.")}setInspectedNode(e){return a(this,void 0,void 0,(function*(){var{nodeId:t}=e;this.tree.setInspectedNode(t)}))}setNodeName(e){throw new Error("Method not implemented.")}setNodeValue(e){return a(this,void 0,void 0,(function*(){var{value:t}=e,n=yield this.getExparserNodeFromParams(e);this.tree.getNodeType(n)===Z.TextNode&&(n.textContent=t)}))}setOuterHTML(e){throw new Error("Method not implemented.")}undo(){throw new Error("Method not implemented.")}getFrameOwner(e){throw new Error("Method not implemented.")}getContainerForNode(e){throw new Error("Method not implemented.")}setHideElement(e){return a(this,void 0,void 0,(function*(){var{nodeId:t,hide:n}=e,r=yield this.getExparserNodeFromParams({nodeId:t});if(r){var i=this.tree.getAttributeValue(r,"style");i.includes("visibility:")?i=i.replace(/visibility:(.*?);/,n?"visibility:hidden;":""):i+="visibility:hidden;",this.tree.setAttributeValue(r,"style",i),this.bridge.emit({method:"DOM.attributeModified",params:{nodeId:t,name:"style",value:i}})}}))}scrollIntoView(e){return a(this,void 0,void 0,(function*(){return yield this.scrollIntoViewIfNeeded(e)}))}getComponentData(e){return a(this,void 0,void 0,(function*(){var{nodeId:t}=e,n=this.tree.getNodeById(t),r=n.data,i=this.tree.virtualDOM.getNodeId(n);if(!i){for(r=null;n.parentNode&&(n=n.parentNode).__virtual;);n.__wxHost&&n.__wxHost.__virtual&&(r=n.__wxHost.data,i=this.tree.virtualDOM.getNodeId(n.__wxHost))}this.lastActiveNodeId=i,this.hasListenOnVdSyncBatch||(this.listenOnVdSyncBatch(),this.hasListenOnVdSyncBatch=!0),this.bridge.emit({method:"WxComponent.componentDataChanged",params:{componentData:r,exparseNodeId:this.lastActiveNodeId}})}))}componentDataByVdSync(e){var t=this.tree.virtualDOM.getNodeById(e).data;t&&this.bridge.emit({method:"WxComponent.componentDataChanged",params:{componentData:t,exparseNodeId:e}})}listenOnVdSyncBatch(){var e=this.lastActiveNodeId,t=this,n=()=>{var n=Date.now();if(!t.lastTimeForComponentData||n-t.lastTimeForComponentData>1e3)return t.componentDataByVdSync(e),void(t.lastTimeForComponentData=Date.now());this.timerForComponentData&&clearTimeout(this.timerForComponentData),this.timerForComponentData=setTimeout((function(){t.componentDataByVdSync(e),t.lastTimeForComponentData=Date.now()}),1e3)};(WeixinJSBridge.addSubscribeListener||wx.subscribe)("vdSyncBatch",(function(t){for(var r of(Array.isArray(t)||(t=t.data),t))if(r instanceof Array){for(var i of r)if(i===e){n();break}}else r&&r.nodeId&&r.nodeId===e&&n()}))}on(e,t){throw new Error("Method not implemented.")}};i([(0,r.WQ)(f),s("design:type",r.mc)],ie.prototype,"container",void 0),i([(0,r.WQ)(c),s("design:type",v)],ie.prototype,"bridge",void 0),ie=i([(0,r._G)()],ie);var oe=e=>e.replace(/[A-Z]/g,(e=>`-${e.toLowerCase()}`)),se=class{get enabled(){return this.DOMAdapter.enabled&&this._enabled}disable(){return a(this,void 0,void 0,(function*(){this._enabled=!1}))}enable(){return a(this,void 0,void 0,(function*(){if(!this.DOMAdapter.enabled)throw new Error("Enable DOM first.");this._enabled=!0,this.cssModel.init(this.DOMAdapter,this.bridge),this.cssModel.virtualSheets.forEach((({header:e})=>{this.bridge.emit({method:"CSS.styleSheetAdded",params:{header:e}})}))}))}addRule(e){throw new Error("Method not implemented.")}collectClassNames(e){throw new Error("Method not implemented.")}createStyleSheet(e){throw new Error("Method not implemented.")}forcePseudoState(e){throw new Error("Method not implemented.")}getBackgroundColors(e){throw new Error("Method not implemented.")}getComputedStyleForNode(e){return a(this,void 0,void 0,(function*(){var t=yield this.DOMAdapter.getExparserNodeFromParams(e);return{computedStyle:yield this.getComputedStyleByNode(t)}}))}getInlineStylesForNode(e){return a(this,void 0,void 0,(function*(){var t=yield this.DOMAdapter.getExparserNodeFromParams(e);return{inlineStyle:this.getInlineStylesByNode(t)}}))}getMatchedStylesForNode(e){return a(this,void 0,void 0,(function*(){try{var t=yield this.DOMAdapter.getExparserNodeFromParams(e);return{matchedCSSRules:yield this.getMatchedCSSRulesByNode(t),inlineStyle:this.getInlineStylesByNode(t),inherited:this.getInheritedCSSRulesByNode(t)}}catch(e){throw console.error("CSSAdapter::getMatchedStylesForNode",e),e}}))}getComputedStyleByNode(e){return a(this,void 0,void 0,(function*(){return(null==e?void 0:e.$$)?((e,t)=>{var n=[],{baseOffset:r=0,startLine:i=0,disabled:o=!1}=null!=t?t:{},s=r;for(var a in e){var d=e[a];if(isNaN(+a)&&"cssText"!==a&&"string"==typeof d&&d.length){var l=oe(a),u=`${l}: ${d};`;n.push({name:l,value:d,text:u,disabled:o,important:/!important/g.test(d),range:{startLine:i,endLine:i,startColumn:s,endColumn:s+=u.length}})}}return n})(yield F.getComputedStyle(e.$$)):[]}))}getInlineStylesByNode(e){if(null==e?void 0:e.$$)return this.cssModel.getInlineRules(e)}getMatchedCSSRulesByNode(e){return a(this,void 0,void 0,(function*(){return(null==e?void 0:e.$$)?yield this.cssModel.getMatchedRules(e):[]}))}getMediaQueries(){throw new Error("Method not implemented.")}getPlatformFontsForNode(e){throw new Error("Method not implemented.")}getStyleSheetText(e){throw new Error("Method not implemented.")}trackComputedStyleUpdates(e){throw new Error("Method not implemented.")}takeComputedStyleUpdates(){throw new Error("Method not implemented.")}setEffectivePropertyValueForNode(e){throw new Error("Method not implemented.")}setKeyframeKey(e){throw new Error("Method not implemented.")}setMediaText(e){throw new Error("Method not implemented.")}setContainerQueryText(e){throw new Error("Method not implemented.")}setRuleSelector(e){throw new Error("Method not implemented.")}setStyleSheetText(e){throw new Error("Method not implemented.")}applyStyleEdit(e){return this.cssModel.applyStyleEdit(e)}setStyleTexts(e){return a(this,void 0,void 0,(function*(){var{edits:t}=e;return{styles:t.map((e=>this.applyStyleEdit(e)))}}))}startRuleUsageTracking(){throw new Error("Method not implemented.")}stopRuleUsageTracking(){throw new Error("Method not implemented.")}takeCoverageDelta(){throw new Error("Method not implemented.")}setLocalFontsEnabled(e){throw new Error("Method not implemented.")}on(e,t){throw new Error("Method not implemented.")}};i([N("DOM"),s("design:type",ie)],se.prototype,"DOMAdapter",void 0),i([(0,r.WQ)(c),s("design:type",v)],se.prototype,"bridge",void 0),se=i([(0,r._G)()],se);var ae=/\/\*[^*]*\*+([^/*][^*]*\*+)*\//g;function de(e,t){t=t||{};var n=1,r=1;function i(e){var t=e.match(/\n/g);t&&(n+=t.length);var i=e.lastIndexOf("\n");r=~i?e.length-i:r+e.length}function o(){var e={line:n,column:r};return function(t){return t.position=new s(e),p(),t}}function s(e){this.startColumn=e.column-1,this.startLine=e.line-1,this.endColumn=r-1,this.endLine=n-1,this.source=t.source}s.prototype.content=e;var a=[];function d(i){var o=new Error(t.source+":"+n+":"+r+": "+i);if(o.reason=i,o.filename=t.source,o.line=n,o.column=r,o.source=e,!t.silent)throw o;a.push(o)}function l(){return h(/^{\s*/)}function u(){return h(/^}/)}function c(){var t,n=[];for(p(),f(n);e.length&&"}"!=e.charAt(0)&&(t=S()||E());)!1!==t&&(n.push(t),f(n));return n}function h(t){var n=t.exec(e);if(n){var r=n[0];return i(r),e=e.slice(r.length),n}}function p(){h(/^\s*/)}function f(e){var t;for(e=e||[];t=v();)!1!==t&&e.push(t);return e}function v(){var t=o();if("/"==e.charAt(0)&&"*"==e.charAt(1)){for(var n=2;""!=e.charAt(n)&&("*"!=e.charAt(n)||"/"!=e.charAt(n+1));)++n;if(n+=2,""===e.charAt(n-1))return d("End of comment missing");var s=e.slice(2,n-2);return r+=2,i(s),e=e.slice(n),r+=2,t({type:"comment",comment:s})}}function g(){var e=h(/^([^{]+)/);if(e)return le(e[0]).replace(/\/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*\/+/g,"").replace(/"(?:\\"|[^"])*"|'(?:\\'|[^'])*'/g,(function(e){return e.replace(/,/g,"‌")})).split(/\s*(?![^(]*\)),\s*/).map((function(e){return e.replace(/\u200C/g,",")}))}function m(){var e=o();h(/^[;\s]*/);var t=h(/^(\*?[-#\/\*\\\w]+(\[[0-9a-z_-]+\])?)\s*/);if(t){t=le(t[0]),h(/^:\s*/);var n=h(/^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^\)]*?\)|[^};])+)/),r=e({type:"declaration",property:t.replace(ae,""),value:n?le(n[0]).replace(ae,""):""});return h(/^[;\s]*/),r}}function y(){var e,t=[];if(!l())return d("missing '{'");for(f(t);e=m();)!1!==e&&(t.push(e),f(t));return u()?t:d("missing '}'")}function x(){for(var e,t=[],n=o();e=h(/^((\d+\.\d+|\.\d+|\d+)%?|[a-z]+)\s*/);)t.push(e[1]),h(/^,\s*/);if(t.length)return n({type:"keyframe",values:t,declarations:y()})}var b=T("import"),w=T("charset"),_=T("namespace");function T(e){var t=new RegExp("^@"+e+"\\s*([^;]+);");return function(){var n=o(),r=h(t);if(r){var i={type:e};return i[e]=r[1].trim(),n(i)}}}function S(){if("@"==e[0])return function(){var e=o();if(t=h(/^@([-\w]+)?keyframes\s*/)){var t,n=t[1];if(f(),!(t=h(/^([-\w]+)\s*/)))return d("@keyframes missing name");var r,i=t[1];if(f(),!l())return d("@keyframes missing '{'");for(var s=f();r=x();)s.push(r),s=s.concat(f());return u()?e({type:"keyframes",name:i,vendor:n,keyframes:s}):d("@keyframes missing '}'")}}()||function(){var e=o(),t=h(/^@media *([^{]+)/);if(t){var n=le(t[1]);if(!l())return d("@media missing '{'");var r=f().concat(c());return u()?e({type:"media",media:n,rules:r}):d("@media missing '}'")}}()||function(){var e=o(),t=h(/^@custom-media\s+(--[^\s]+)\s*([^{;]+);/);if(t)return e({type:"custom-media",name:le(t[1]),media:le(t[2])})}()||function(){var e=o(),t=h(/^@supports *([^{]+)/);if(t){var n=le(t[1]);if(!l())return d("@supports missing '{'");var r=f().concat(c());return u()?e({type:"supports",supports:n,rules:r}):d("@supports missing '}'")}}()||b()||w()||_()||function(){var e=o(),t=h(/^@([-\w]+)?document *([^{]+)/);if(t){var n=le(t[1]),r=le(t[2]);if(!l())return d("@document missing '{'");var i=f().concat(c());return u()?e({type:"document",document:r,vendor:n,rules:i}):d("@document missing '}'")}}()||function(){var e=o();if(h(/^@page */)){var t=g()||[];if(!l())return d("@page missing '{'");for(var n,r=f();n=m();)r.push(n),r=r.concat(f());return u()?e({type:"page",selectors:t,declarations:r}):d("@page missing '}'")}}()||function(){var e=o();if(h(/^@host\s*/)){if(!l())return d("@host missing '{'");var t=f().concat(c());return u()?e({type:"host",rules:t}):d("@host missing '}'")}}()||function(){var e=o();if(h(/^@font-face\s*/)){if(!l())return d("@font-face missing '{'");for(var t,n=f();t=m();)n.push(t),n=n.concat(f());return u()?e({type:"font-face",declarations:n}):d("@font-face missing '}'")}}()}function E(){var e=o(),t=g();return t||(t=""),f(),e({type:"rule",selectors:t,declarations:y()})}return ue({type:"stylesheet",stylesheet:{rules:c(),parsingErrors:a}})}function le(e){return e?e.replace(/^\s+|\s+$/g,""):""}function ue(e,t){var n=e&&"string"==typeof e.type,r=n?e:t;for(var i in e){var o=e[i];Array.isArray(o)?o.forEach((function(e){ue(e,r)})):o&&"object"==typeof o&&ue(o,r)}return n&&Object.defineProperty(e,"parent",{configurable:!0,writable:!0,enumerable:!1,value:t||null}),e}var ce="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:void 0!==n.g?n.g:"undefined"!=typeof self?self:{};var he,pe,fe={exports:{}},ve={exports:{}},ge={exports:{}},me={exports:{}};he=me.exports,pe=/^\s+/,he=function(e,t){if(null==t)return e.trimLeft?e.trimLeft():e.replace(pe,"");for(var n,r,i=0,o=e.length,s=t.length,a=!0;a&&i<o;)for(a=!1,n=-1,r=e.charAt(i);++n<s;)if(r===t[n]){a=!0,i++;break}return i>=o?"":e.substr(i,o)},me.exports=he;var ye={exports:{}};!function(e,t){t=function(e,t){if(null==t){if(e.trimRight)return e.trimRight();t=" \r\n\t\f\v"}for(var n,r,i=e.length-1,o=t.length,s=!0;s&&i>=0;)for(s=!1,n=-1,r=e.charAt(i);++n<o;)if(r===t[n]){s=!0,i--;break}return i>=0?e.substring(0,i+1):""},e.exports=t}(ye,ye.exports),function(e,t){var n=me.exports,r=ye.exports;t=function(e,t){return null==t&&e.trim?e.trim():n(r(e,t),t)},e.exports=t}(ge,ge.exports);var xe={exports:{}},be={exports:{}},we={exports:{}},_e={exports:{}};!function(e,t){var n=Object.prototype.toString;t=function(e){return n.call(e)},e.exports=t}(_e,_e.exports),function(e,t){var n=_e.exports;t=function(e){return"[object Number]"===n(e)},e.exports=t}(we,we.exports);var Te={exports:{}};!function(e,t){var n=_e.exports;t=function(e){var t=n(e);return"[object Function]"===t||"[object GeneratorFunction]"===t||"[object AsyncFunction]"===t},e.exports=t}(Te,Te.exports),function(e,t){var n=we.exports,r=Te.exports,i=Math.pow(2,53)-1;t=function(e){if(!e)return!1;var t=e.length;return n(t)&&t>=0&&t<=i&&!r(e)},e.exports=t}(be,be.exports);var Se={exports:{}},Ee={exports:{}};!function(e,t){var n=Object.prototype.hasOwnProperty;t=function(e,t){return n.call(e,t)},e.exports=t}(Ee,Ee.exports),function(e,t){var n=Ee.exports;t=Object.keys?Object.keys:function(e){var t=[];for(var r in e)n(e,r)&&t.push(r);return t},e.exports=t}(Se,Se.exports);var Ne={exports:{}},Ie={exports:{}};!function(e,t){t=function(e){return void 0===e},e.exports=t}(Ie,Ie.exports),function(e,t){var n=Ie.exports;t=function(e,t,r){if(n(t))return e;switch(null==r?3:r){case 1:return function(n){return e.call(t,n)};case 3:return function(n,r,i){return e.call(t,n,r,i)};case 4:return function(n,r,i,o){return e.call(t,n,r,i,o)}}return function(){return e.apply(t,arguments)}},e.exports=t}(Ne,Ne.exports),function(e,t){var n=be.exports,r=Se.exports,i=Ne.exports;t=function(e,t,o){var s,a;if(t=i(t,o),n(e))for(s=0,a=e.length;s<a;s++)t(e[s],s,e);else{var d=r(e);for(s=0,a=d.length;s<a;s++)t(e[d[s]],d[s],e)}return e},e.exports=t}(xe,xe.exports);var Ae={exports:{}};!function(e,t){t=function(e){return e},e.exports=t}(Ae,Ae.exports);var Me={exports:{}},Ce={exports:{}},Oe={exports:{}};!function(e,t){t=function(e){var t=typeof e;return!!e&&("function"===t||"object"===t)},e.exports=t}(Oe,Oe.exports);var Pe={exports:{}};!function(e,t){var n=_e.exports;t=Array.isArray?Array.isArray:function(e){return"[object Array]"===n(e)},e.exports=t}(Pe,Pe.exports);var Re={exports:{}},De={exports:{}},ke={exports:{}};!function(e,t){var n=Ie.exports,r=xe.exports;t=function(e,t){return function(i){return r(arguments,(function(o,s){if(0!==s){var a=e(o);r(a,(function(e){t&&!n(i[e])||(i[e]=o[e])}))}})),i}},e.exports=t}(ke,ke.exports),function(e,t){t=(0,ke.exports)(Se.exports),e.exports=t}(De,De.exports);var Le={exports:{}};!function(e,t){var n=Se.exports;t=function(e,t){var r=n(t),i=r.length;if(null==e)return!i;e=Object(e);for(var o=0;o<i;o++){var s=r[o];if(t[s]!==e[s]||!(s in e))return!1}return!0},e.exports=t}(Le,Le.exports),function(e,t){var n=De.exports,r=Le.exports;t=function(e){return e=n({},e),function(t){return r(t,e)}},e.exports=t}(Re,Re.exports);var Be={exports:{}},je={exports:{}},Fe={exports:{}};!function(e,t){var n=Ee.exports,r=Pe.exports;t=function(e,t){if(r(e))return e;if(t&&n(t,e))return[e];var s=[];return e.replace(i,(function(e,t,n,r){s.push(n?r.replace(o,"$1"):t||e)})),s};var i=/[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,o=/\\(\\)?/g;e.exports=t}(Fe,Fe.exports),function(e,t){var n=Ie.exports,r=Fe.exports;t=function(e,t){var i;for(i=(t=r(t,e)).shift();!n(i);){if(null==(e=e[i]))return;i=t.shift()}return e},e.exports=t}(je,je.exports),function(e,t){var n=Pe.exports,r=je.exports;t=function(e){return n(e)?function(t){return r(t,e)}:(t=e,function(e){return null==e?void 0:e[t]});var t},e.exports=t}(Be,Be.exports),function(e,t){var n=Te.exports,r=Oe.exports,i=Pe.exports,o=Ne.exports,s=Re.exports,a=Ae.exports,d=Be.exports;t=function(e,t,l){return null==e?a:n(e)?o(e,t,l):r(e)&&!i(e)?s(e):d(e)},e.exports=t}(Ce,Ce.exports),function(e,t){var n=Ce.exports,r=Se.exports,i=be.exports;t=function(e,t,o){t=n(t,o);for(var s=!i(e)&&r(e),a=(s||e).length,d=Array(a),l=0;l<a;l++){var u=s?s[l]:l;d[l]=t(e[u],u,e)}return d},e.exports=t}(Me,Me.exports),function(e,t){var n=ge.exports,r=xe.exports,i=Ae.exports,o=Me.exports,s="[\\x20\\t\\r\\n\\f]",a="(?:\\\\[\\da-fA-F]{1,6}".concat(s,"?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+"),d="\\[".concat(s,"*(").concat(a,")(?:").concat(s,"*([*^$|!~]?=)").concat(s,"*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(").concat(a,"))|)").concat(s,"*\\]"),l="::?(".concat(a,")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|").concat(d,")*)|.*)\\)|)"),u=new RegExp("^".concat(s,"*,").concat(s,"*")),c=new RegExp("^".concat(s,"*([>+~]|").concat(s,")").concat(s,"*")),h={id:{reg:new RegExp("^#(".concat(a,")")),value:function(e){return e.slice(1)},toStr:function(e){return"#".concat(e)}},class:{reg:new RegExp("^\\.(".concat(a,")")),value:function(e){return e.slice(1)},toStr:function(e){return".".concat(e)}},tag:{reg:new RegExp("^(".concat(a,"|[*])")),value:i},attribute:{reg:new RegExp("^".concat(d)),value:function(e){return e.slice(1,e.length-1)},toStr:function(e){return"[".concat(e,"]")}},pseudo:{reg:new RegExp("^".concat(l)),value:i}};r(h,(function(e){e.value||(e.value=i),e.toStr||(e.toStr=i)})),t={parse:function(e){e=n(e);for(var t,i,o,s=[];e&&(o&&!(i=u.exec(e))||(i&&(e=e.slice(i[0].length)),t=[],s.push(t)),o=!1,(i=c.exec(e))&&(o=i.shift(),e=e.slice(o.length),(o=n(o))||(o=" "),t.push({value:o,type:"combinator"})),r(h,(function(r,s){var a=r.reg,d=r.value;(i=a.exec(e))&&(o=i.shift(),e=e.slice(o.length),o=n(o),t.push({value:d(o),type:s}))})),o););return s},stringify:function(e){return o(e,(function(e){return(e=o(e,(function(e){var t=e.type,n=e.value;return"combinator"===t?" "===n?n:" ".concat(n," "):h[t].toStr(n)}))).join("")})).join(", ")}},e.exports=t}(ve,ve.exports);var Ve={exports:{}};!function(e,t){t=function(e,t){return 0===e.indexOf(t)},e.exports=t}(Ve,Ve.exports);var ze={exports:{}},We={exports:{}};!function(e,t){t=function(e,t,n){return Array.prototype.indexOf.call(e,t,n)},e.exports=t}(We,We.exports);var $e={exports:{}};!function(e,t){var n=_e.exports;t=function(e){return"[object String]"===n(e)},e.exports=t}($e,$e.exports);var Ge={exports:{}};!function(e,t){var n=xe.exports;t=function(e){var t=[];return n(e,(function(e){t.push(e)})),t},e.exports=t}(Ge,Ge.exports),function(e,t){var n=We.exports,r=$e.exports,i=be.exports,o=Ge.exports;t=function(e,t){return r(e)?e.indexOf(t)>-1:(i(e)||(e=o(e)),n(e,t)>=0)},e.exports=t}(ze,ze.exports);var Ue={exports:{}},He={exports:{}},qe={exports:{}};!function(e,t){var n=we.exports,r=Oe.exports,i=Te.exports,o=$e.exports;t=function(e){if(n(e))return e;if(r(e)){var t=i(e.valueOf)?e.valueOf():e;e=r(t)?t+"":t}return o(e)?+e:0===e?e:+e},e.exports=t}(qe,qe.exports),function(e,t){var n=qe.exports;t=function(e){return e?(e=n(e))-e%1:0===e?e:0},e.exports=t}(He,He.exports);var Ye={exports:{}};!function(e,t){t=function(){for(var e=arguments,t=e[0],n=1,r=e.length;n<r;n++)e[n]>t&&(t=e[n]);return t},e.exports=t}(Ye,Ye.exports),function(e,t){var n=He.exports,r=Ye.exports;t=function(e,t){e=e.split("."),t=t.split(".");for(var i=r(e.length,t.length),o=0;o<i;o++){var s=n(e[o]),a=n(t[o]);if(s>a)return 1;if(s<a)return-1}return 0},e.exports=t}(Ue,Ue.exports),function(e,t){var n=ve.exports,r=xe.exports,i=Ve.exports,o=ze.exports,s=Ue.exports;t=function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},s=t.important,d=void 0!==s&&s,l=t.inlineStyle,u=void 0!==l&&l,c=t.position,h=[0,0,0,0,0,void 0===c?0:c];d&&(h[0]=1),u&&(h[1]=1);var p=n.parse(e)[0];return r(p,(function(e){var t=e.type,n=e.value;switch(t){case"id":h[2]++;break;case"class":case"attribute":h[3]++;break;case"pseudo":o(a,n.replace(/:/g,""))?h[4]++:i(n,"::")||h[3]++;break;case"tag":"*"!==n&&h[4]++}})),h};var a=["first-letter","last-letter","first-line","last-line","first-child","last-child","before","after"];t.compare=function(e,t){return s(e.join("."),t.join("."))},e.exports=t}(fe,fe.exports);var Xe=fe.exports;class Ke{constructor(e,t={}){var n;this.id="",this.rulesMap={},this.id=e;var r,{node:i,fileName:o,disabled:s=!1,isConstructed:a=!1,isInline:d=!1,isMutable:l=!0,ownerNode:u,DOMAdapter:c,bridge:h}=t;d?r=de(`element.style{${this.getNodeStyleAttr(i)}}`,{silent:!0}):r=de(null==i?void 0:i.innerText,{silent:!0});this.DOMAdapter=c,this.bridge=h,this.fileName=o||"",this.header={styleSheetId:e,disabled:s,ownerNode:u,isInline:d,isMutable:l,isConstructed:a,origin:"regular",frameId:"114514",sourceURL:o,startLine:0,endLine:0,startColumn:0,endColumn:0,length:1,title:null!==(n=null==o?void 0:o.split("/").pop())&&void 0!==n?n:"untitled"},this.initSheet(r),this.node=i}get ownerNode(){return this.node}getNodeStyleAttr(e){throw new Error("Method not implemented.")}initSheet(e){var t,n;this.sheet=e;var r=null!==(t=null==e?void 0:e.stylesheet.rules)&&void 0!==t?t:[];if(this.rulesMap={},this.header.endLine=(null!==(n=null==e?void 0:e.stylesheet.rules)&&void 0!==n?n:[]).length,e)for(var i=0;i<r.length;i++){var o=r[i];this.rulesMap[i]=o}}getRuleByStartLine(e){return this.rulesMap[e]}getInlineRule(){for(var e=this.sheet.stylesheet.rules[0],t={cssProperties:[],styleSheetId:this.id,range:e.position,shorthandEntries:[]},n=0,r=e.declarations.length;n<r;n++){var i=e.declarations[n];if("comment"!==i.type)t.cssProperties.push({disabled:!1,name:i.property,value:i.value,range:i.position});else{var o=i.comment.replace(/;$/,"").trim(),[s,a]=o.split(":");s=s.trim(),a=a.trim(),t.cssProperties.push({disabled:!0,text:`/*${o}*/`,range:i.position,name:s,value:a})}}return t}getMatchedRules(e){return a(this,void 0,void 0,(function*(){throw new Error("getMatchedRules not implemented.")}))}sortMatchedStyleRules(e){for(var t=[],n=e.length,r=[],i=0;i<n;i++){var o=e[i].rule;t[i]=Xe(o.selectorList.text,{position:i})}t.sort(Xe.compare);for(var s=0;s<n;s++){var a=t[s][5];r[s]=e[a]}return r}filterMatchedRules(e,t){return a(this,void 0,void 0,(function*(){throw new Error("filterMatchedRules not implemented.")}))}serializeRule(e){var t=[],n=e.declarations||[];for(var r in e.selectors){var i=e.selectors[r],o={style:{cssProperties:[],range:e.position,shorthandEntries:[]},selectorList:{text:i,selectors:[]},styleSheetId:this.id,media:[],origin:"regular"},s=e.parent.media;for(var a of(s&&(o.media=s),n))if("comment"!=a.type)o.style.cssProperties.push({disabled:!1,name:a.property,value:a.value,range:a.position});else{var d=a.comment.replace(/;$/,"").trim(),[l,u]=d.split(":");l=l&&l.trim()||"",u=u&&u.trim()||"",o.style.cssProperties.push({disabled:!0,text:`/*${d}*/`,range:a.position,name:l,value:u})}t.push({rule:o,matchingSelectors:[]})}return t}setInlineStyle(e,t){F.setStyle(e,t,!0)}updateStyleText(e){throw new Error("updateStyleText not implemented.")}applyStyleEdit(e){var t,n;try{if(this.header.isInline){var r=null===(t=this.ownerNode)||void 0===t?void 0:t.__wxElement;this.setInlineStyle(r,e.text),n=de(`element.style{${e.text}}`)}else{for(var{startLine:i,endLine:o,endColumn:s}=e.range,{startColumn:a}=e.range,d=this.node.innerText,l=d.split("\n"),u=[],c=i;c<=o;c++){var h=l[c];c<o?(u.push(h.substr(a,h.length-a)),a=0):u.push(h.substr(a,s-a))}var p=u.join("\n"),f=de(p),v=[],g=f.stylesheet.rules[0];v.push(g.selectors.join(", ")),v.push("{"),v.push(e.text),v.push("}");var m=d.replace(p,v.join(""));n=de(m),this.updateStyleText(m)}this.initSheet(n)}catch(e){console.warn("applyStyleEdit fail:",e)}return{}}}class Je extends Ke{getNodeStyleAttr(e){var t;return(null===(t=null==e?void 0:e.getAttribute)||void 0===t?void 0:t.call(e,"style"))||""}getMatchedRules(e){return a(this,void 0,void 0,(function*(){var t=yield this.filterMatchedRules(this.rulesMap,e);return this.sortMatchedStyleRules(t)}))}filterMatchedRules(e,t){return a(this,void 0,void 0,(function*(){var n=[];for(var r in e){var i=e[r];"media"===i.type&&(n=n.concat(yield this.filterMatchedRules(i.rules,t)));var o=(t.matches||t.webkitMatchesSelector).bind(t);for(var s in i.selectors){var a=i.selectors[s],d=!1;try{d=o(a)}catch(e){continue}if(d){var l={style:{cssProperties:[],range:i.position},selectorList:{text:a},styleSheetId:this.id},u=i.parent.media;u&&(l.media=u);for(var c=0,h=i.declarations.length;c<h;c++){var p=i.declarations[c];if("comment"!=p.type)l.style.cssProperties.push({disabled:!1,name:p.property,value:p.value,range:p.position});else{var f=p.comment.replace(/;$/,"").trim(),[v,g]=f.split(":");v=v&&v.trim()||"",g=g&&g.trim()||"",l.style.cssProperties.push({disabled:!0,text:`/*${f}*/`,range:p.position,name:v,value:g})}}n.push({rule:l})}}}return n}))}updateStyleText(e){for(var t=document.createTextNode(e);this.node.childNodes.length>0;)this.node.removeChild(this.node.childNodes[0]);this.node.appendChild(t)}}class Qe{constructor(){this.assigner=new S,this.virtualSheetMap=new R,this.inlineStyleIdMap=new R,this._sheets=[],this._virtualDOM=null,this.styleSheetIdPrev="style_",this.inlineStyleIdPrev="node_",this.cssToJs=e=>e.replace(/\W+\w/g,(e=>e.slice(-1).toUpperCase()))}init(e,t){this.DOMAdapter=e,this.bridge=t}newInlineSheetId(){return`${this.inlineStyleIdPrev}${this.assigner.id}`}newStyleSheetId(e){return`${this.styleSheetIdPrev}${e}`}get virtualSheets(){return this._virtualDOM=this.DOMAdapter.tree.virtualDOM,this._sheets=this.findSheets(),this._sheets}getInlineRules(e){throw new Error("Method not implemented.")}getMatchedRules(e){return a(this,void 0,void 0,(function*(){var t=e.$$;if(!t||!t.matches&&!t.webkitMatchesSelector)return[];var n=[];for(var r of this.virtualSheets)n=n.concat(yield r.getMatchedRules(t));return n}))}getInheritedRules(e,t){return[]}applyStyleEdit(e){var{styleSheetId:t}=e,n=this.virtualSheetMap.get(t);if(!n)throw new Error("invalid styleSheetId");var r=n.applyStyleEdit(e);if(n.header.isInline){var i=this.inlineStyleIdMap.getRev(t);if(i){var o=this.DOMAdapter.tree.requestIdForNode(i.__wxElement);this.bridge.emit({method:"DOM.attributeModified",params:{nodeId:o,name:"style",value:e.text}})}}return r}}class Ze extends Qe{findSheets(){var e=document.querySelectorAll("style"),t=[];this.virtualSheetMap.clear();for(var n=0;n<e.length;n++)try{var r=this.newStyleSheetId(n),i=new Je(r,{node:e[n],fileName:e[n].getAttribute("wxss:path")||""});this.virtualSheetMap.set(r,i),t.push(i)}catch(e){}return t}getInlineRules(e){var t=e.$$,n=this.newInlineSheetId();this.inlineStyleIdMap.has(t)||this.inlineStyleIdMap.set(t,n);var r=this.inlineStyleIdMap.get(t),i=new Je(r,{isInline:!0,node:t});return this.virtualSheetMap.set(r,i),i.getInlineRule()}}class et{constructor(){this.iframe=document.createElement("iframe"),this.iframe.style.display="none"}get window(){return this.inited||this.init(),this.iframe.contentWindow}get document(){return this.window.document}init(){document.body.append(this.iframe),this.inited=!0}getDefaultComputedStyles(e){var t=this.document.createElement(e.tagName);this.document.body.appendChild(t);var n=this.window.getComputedStyle(t),r={};for(var i in n)r[i]=n[i];return t.remove(),r}getModifiedComputedStyles(e,t=globalThis.window){var n=this.getDefaultComputedStyles(e),r=t.getComputedStyle(e),i={};for(var o in r)!isNaN(+o)||/[_-]/.test(o)||["cssText","blockSize"].includes(o)||r[o]!==n[o]&&(i[o]=r[o]);return i}}var tt=class extends se{constructor(){super(...arguments),this.iframe=new et,this.cssModel=new Ze}getInheritedCSSRulesByNode(e){var t=null==e?void 0:e.$$;if(!t)return[];if(t.matches=t.matches||t.webkitMatchesSelector,!t.matches)return[];var n=this.iframe.getModifiedComputedStyles(t);return this.cssModel.getInheritedRules(t,n)}};tt=i([(0,r._G)()],tt);class nt extends Ke{getNodeStyleAttr(e){return((null==e?void 0:e.__wxElement.__styleSegments)||[]).join("")}getPageWxssScopeId(){var e,t;return a(this,void 0,void 0,(function*(){var n=yield null===(e=this.DOMAdapter)||void 0===e?void 0:e.tree.getPageContextId(),r=0;if(this.fileName){var i=this.fileName.replace("./","").replace(".\\","").replace(".wxss","");r=null===(t=this.DOMAdapter)||void 0===t?void 0:t.tree.getStyleSCopeId(n,i)}return r||0}))}getMatchedRules(e){return a(this,void 0,void 0,(function*(){var t=yield this.filterMatchedRules(this.rulesMap,e);return this.sortMatchedStyleRules(t)}))}filterMatchedRules(e,t){return a(this,void 0,void 0,(function*(){var n=[],r=yield this.getPageWxssScopeId();for(var i in e){var o=e[i];for(var s in"media"===o.type&&(n=n.concat(yield this.filterMatchedRules(o.rules,t))),o.selectors){var a=o.selectors[s],d=!1;try{d=t.matches(r,a)}catch(e){continue}if(d){var l={style:{cssProperties:[],range:o.position},selectorList:{text:a},styleSheetId:this.id},u=o.parent.media;u&&(l.media=u);for(var c=0,h=o.declarations.length;c<h;c++){var p=o.declarations[c];if("comment"!=p.type)l.style.cssProperties.push({disabled:!1,name:p.property,value:p.value,range:p.position});else{var f=p.comment.replace(/;$/,"").trim(),[v,g]=f.split(":");v=v&&v.trim()||"",g=g&&g.trim()||"",l.style.cssProperties.push({disabled:!0,text:`/*${f}*/`,range:p.position,name:v,value:g})}}n.push({rule:l})}}}return n}))}updateStyleText(e){var t,n,r;return a(this,void 0,void 0,(function*(){for(var i=document.createTextNode(e);this.node.childNodes.length>0;)this.node.removeChild(this.node.childNodes[0]);this.node.appendChild(i),null===(t=this.bridge)||void 0===t||t.emit({method:"WxHost.setWxssFile",params:{fileName:this.fileName,content:e}});var o=yield null===(n=this.DOMAdapter)||void 0===n?void 0:n.tree.getPageContextId();null===(r=this.DOMAdapter)||void 0===r||r.tree.webviewEngine.invalidateAllPreCompiled(o)}))}}class rt extends Qe{findSheets(){var e=document.querySelectorAll("style"),t=[];this.virtualSheetMap.clear();for(var n=0;n<e.length;n++){var r,i=this.newStyleSheetId(n);r=new nt(i,{node:e[n],fileName:e[n].getAttribute("wxss:path")||"",DOMAdapter:this.DOMAdapter,bridge:this.bridge}),this.virtualSheetMap.set(i,r),t.push(r)}return t}getInlineRules(e){var t=e.$$,n=this.newInlineSheetId();this.inlineStyleIdMap.has(t)||this.inlineStyleIdMap.set(t,n);var r=this.inlineStyleIdMap.get(t),i=new nt(r,{isInline:!0,node:t});return this.virtualSheetMap.set(r,i),i.getInlineRule()}}var it=class extends se{constructor(){super(...arguments),this.cssModel=new rt}getInheritedCSSRulesByNode(e){var t=null==e?void 0:e.$$;return t&&t.matches?this.cssModel.getInheritedRules(t,{}):[]}};it=i([(0,r._G)()],it);class ot extends re{constructor(){super(...arguments),this.getNodeName=(e,t="")=>{var n,r=((null===(n=null==e?void 0:e.$$)||void 0===n?void 0:n.tagName)||t).toLowerCase();return r.startsWith("wx-")?r.slice(3):r},this.getAttributes=e=>{var t,n,r;this.spreadScopeData();var i=[],o=e.$$;return o&&o.attributes&&Object.values(o.attributes).forEach((e=>{var t;this.skippedDOMAttrs.has(e.name)||null==i||i.push(e.name,null!==(t=e.textContent)&&void 0!==t?t:"")})),e.__id&&i.push("id",e.__id),(null===(n=null===(t=e.classList)||void 0===t?void 0:t._rawNames)||void 0===n?void 0:n.length)&&i.push("class",((null===(r=e.classList)||void 0===r?void 0:r._rawNames)||[]).join(" ")||""),e.__component__&&i.push("is",e.is),i},this.removeAttributes=(e,t)=>{"class"===t?e.classList.setClassNames(""):"id"===t?(delete e.id,delete e.__id):e.removeAttribute(t)},this.setAttributeValue=(e,t,n)=>{"class"===t?e.classList.setClassNames(n):"id"===t?e.id=n:e.setAttribute(t,n)}}getRoot(){return a(this,void 0,void 0,(function*(){return this._root?this._root():window.__DOMTree__}))}getAttributeValue(e,t){for(var n=this.getAttributes(e),r={},i=0;i<n.length;i+=2)r[n[i]]=n[i+1];return r[t]}}var st={exports:{}},at={},dt={exports:{}},lt={exports:{}},ut={exports:{}},ct={exports:{}},ht={exports:{}};!function(e,t){var n=Oe.exports,r=Te.exports,i=Object.getPrototypeOf,o={}.constructor;t=function(e){if(n(e)){if(i)return i(e);var t=e.__proto__;return t||null===t?t:r(e.constructor)?e.constructor.prototype:e instanceof o?o.prototype:void 0}},e.exports=t}(ht,ht.exports);var pt={exports:{}},ft={exports:{}};!function(e,t){var n=Ce.exports,r=xe.exports;t=function(e,t,i){var o=[];return t=n(t,i),r(e,(function(e,n,r){t(e,n,r)&&o.push(e)})),o},e.exports=t}(ft,ft.exports),function(e,t){var n=ft.exports;function r(e,t){return e===t}t=function(e,t){return t=t||r,n(e,(function(e,n,r){for(var i=r.length;++n<i;)if(t(e,r[n]))return!1;return!0}))},e.exports=t}(pt,pt.exports),function(e,t){var n=Se.exports,r=ht.exports,i=pt.exports,o=Object.getOwnPropertyNames,s=Object.getOwnPropertySymbols;t=function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},a=t.prototype,d=void 0===a||a,l=t.unenumerable,u=void 0!==l&&l,c=t.symbol,h=void 0!==c&&c,p=[];if((u||h)&&o){var f=n;u&&o&&(f=o);do{p=p.concat(f(e)),h&&s&&(p=p.concat(s(e)))}while(d&&(e=r(e))&&e!==Object.prototype);p=i(p)}else if(d)for(var v in e)p.push(v);else p=n(e);return p},e.exports=t}(ct,ct.exports),function(e,t){t=(0,ke.exports)(ct.exports),e.exports=t}(ut,ut.exports);var vt={exports:{}};!function(e,t){var n=be.exports,r=Me.exports,i=Pe.exports,o=$e.exports;t=function(e){return e?i(e)?e:n(e)&&!o(e)?r(e):[e]:[]},e.exports=t}(vt,vt.exports);var gt={exports:{}},mt={exports:{}};!function(e,t){var n=Oe.exports;t=function(e){if(!n(e))return{};if(r)return r(e);function t(){}return t.prototype=e,new t};var r=Object.create;e.exports=t}(mt,mt.exports),function(e,t){var n=mt.exports;t=function(e,t){e.prototype=n(t.prototype)},e.exports=t}(gt,gt.exports);var yt={exports:{}};!function(e,t){t="undefined"!=typeof wx&&(0,Te.exports)(wx.openLocation),e.exports=t}(yt,yt.exports),function(e,t){var n=ut.exports,r=vt.exports,i=gt.exports,o=je.exports,s=yt.exports;var a=(t=function(e,t){return a.extend(e,t)}).Base=function e(t,a,d){d=d||{};var l=a.className||o(a,"initialize.name")||"";delete a.className;var u=function(){var e=r(arguments);return this.initialize&&this.initialize.apply(this,e)||this};if(!s)try{u=new Function("toArr","return function "+l+"(){var args = toArr(arguments);return this.initialize ? this.initialize.apply(this, args) || this : this;};")(r)}catch(e){}return i(u,t),u.prototype.constructor=u,u.extend=function(t,n){return e(u,t,n)},u.inherits=function(e){i(u,e)},u.methods=function(e){return n(u.prototype,e),u},u.statics=function(e){return n(u,e),u},u.methods(a).statics(d),u}(Object,{className:"Base",callSuper:function(e,t,n){return e.prototype[t].apply(this,n)},toString:function(){return this.constructor.name}});e.exports=t}(lt,lt.exports);var xt={exports:{}};!function(e,t){t=function(e,t,n){var r=e.length;t=null==t?0:t<0?Math.max(r+t,0):Math.min(t,r),n=null==n?r:n<0?Math.max(r+n,0):Math.min(n,r);for(var i=[];t<n;)i.push(e[t++]);return i},e.exports=t}(xt,xt.exports);var bt={exports:{}},wt={exports:{}},_t={exports:{}};!function(e,t){t=function(e,t){return t=null==t?e.length-1:+t,function(){var n,r=Math.max(arguments.length-t,0),i=new Array(r);for(n=0;n<r;n++)i[n]=arguments[n+t];switch(t){case 0:return e.call(this,i);case 1:return e.call(this,arguments[0],i);case 2:return e.call(this,arguments[0],arguments[1],i)}var o=new Array(t+1);for(n=0;n<t;n++)o[n]=arguments[n];return o[t]=i,e.apply(this,o)}},e.exports=t}(_t,_t.exports),function(e,t){var n=vt.exports;t=(0,_t.exports)((function(e,t){return function(){var r=[];return r=(r=r.concat(t)).concat(n(arguments)),e.apply(this,r)}})),e.exports=t}(wt,wt.exports);var Tt={exports:{}};!function(e,t){t=function(e,t){var n;return function(){return--e>0&&(n=t.apply(this,arguments)),e<=1&&(t=null),n}},e.exports=t}(Tt,Tt.exports),function(e,t){t=(0,wt.exports)(Tt.exports,2),e.exports=t}(bt,bt.exports);var St={exports:{}};!function(e,t){var n=Oe.exports,r=Pe.exports,i=ut.exports;t=function(e){return n(e)?r(e)?e.slice():i({},e):e},e.exports=t}(St,St.exports),function(e,t){var n=Ee.exports,r=xe.exports,i=xt.exports,o=bt.exports,s=St.exports;t=(0,lt.exports)({initialize:function(){this._events=this._events||{}},on:function(e,t){return this._events[e]=this._events[e]||[],this._events[e].push(t),this},off:function(e,t){var r=this._events;if(n(r,e)){var i=r[e].indexOf(t);return i>-1&&r[e].splice(i,1),this}},once:function(e,t){return this.on(e,o(t)),this},emit:function(e){var t=this;if(n(this._events,e)){var o=i(arguments,1),a=s(this._events[e]);return r(a,(function(e){return e.apply(t,o)}),this),this}},removeAllListeners:function(e){return e?delete this._events[e]:this._events={},this}},{mixin:function(e){r(["on","off","once","emit","removeAllListeners"],(function(n){e[n]=t.prototype[n]})),e._events=e._events||{}}}),e.exports=t}(dt,dt.exports);var Et={exports:{}},Nt={exports:{}},It={exports:{}};!function(e,t){t=(0,_t.exports)((function(e,t){for(var n=e.length,r=0,i=t.length;r<i;r++)for(var o=t[r],s=0,a=o.length;s<a;s++)e[n++]=o[s];return e.length=n,e})),e.exports=t}(It,It.exports),function(e,t){var n=$e.exports,r=xe.exports,i=It.exports;t=(0,lt.exports)({className:"Select",initialize:function(e){return this.length=0,e?n(e)?o.find(e):void(e.nodeType&&(this[0]=e,this.length=1)):this},find:function(e){var n=new t;return this.each((function(){i(n,this.querySelectorAll(e))})),n},each:function(e){return r(this,(function(t,n){e.call(t,n,t)})),this}});var o=new t(document);e.exports=t}(Nt,Nt.exports);var At={exports:{}},Mt={exports:{}};!function(e,t){var n=$e.exports,r=vt.exports,i=Nt.exports;t=function(e){return r(n(e)?new i(e):e)},e.exports=t}(Mt,Mt.exports),function(e,t){var n=Mt.exports;t=function(e){var t=(e=n(e))[0].getBoundingClientRect();return{left:t.left+window.pageXOffset,top:t.top+window.pageYOffset,width:Math.round(t.width),height:Math.round(t.height)}},e.exports=t}(At,At.exports);var Ct={exports:{}};!function(e,t){var n=xe.exports,r=Mt.exports;t=function(e){e=r(e),n(e,(function(e){(function(e){return"none"==getComputedStyle(e,"").getPropertyValue("display")})(e)&&(e.style.display=function(e){var t,n;i[e]||(t=document.createElement(e),document.documentElement.appendChild(t),n=getComputedStyle(t,"").getPropertyValue("display"),t.parentNode.removeChild(t),"none"==n&&(n="block"),i[e]=n);return i[e]}(e.nodeName))}))};var i={};e.exports=t}(Ct,Ct.exports);var Ot={exports:{}},Pt={exports:{}},Rt={exports:{}};!function(e,t){var n=/([A-Z])/g,r=/[_.\- ]+/g,i=/(^-)|(-$)/g;t=function(e){return(e=e.replace(n,"-$1").toLowerCase().replace(r,"-").replace(i,"")).split("-")},e.exports=t}(Rt,Rt.exports),function(e,t){var n=Rt.exports;t=function(e){return n(e).join("-")},e.exports=t}(Pt,Pt.exports);var Dt={exports:{}},kt={exports:{}};!function(e,t){var n=Ee.exports;t=function(e,t){var r=function(i){var o=r.cache,s=""+(t?t.apply(this,arguments):i);return n(o,s)||(o[s]=e.apply(this,arguments)),o[s]};return r.cache={},r},e.exports=t}(kt,kt.exports);var Lt={exports:{}};!function(e,t){var n=Rt.exports;function r(e,t){this[t]=e.replace(/\w/,(function(e){return e.toUpperCase()}))}t=function(e){var t=n(e),i=t[0];return t.shift(),t.forEach(r,t),i+=t.join("")},e.exports=t}(Lt,Lt.exports);var Bt={exports:{}};!function(e,t){t=function(e){return e.length<1?e:e[0].toUpperCase()+e.slice(1)},e.exports=t}(Bt,Bt.exports),function(e,t){var n=kt.exports,r=Lt.exports,i=Bt.exports,o=Ee.exports,s=Pt.exports;t=n((function(e){if(e=e.replace(d,""),e=r(e),o(l,e))return e;for(var t=a.length;t--;){var n=a[t]+i(e);if(o(l,n))return n}return e})),t.dash=n((function(e){var n=t(e);return(d.test(n)?"-":"")+s(n)}));var a=["O","ms","Moz","Webkit"],d=/^(O)|(ms)|(Moz)|(Webkit)|(-o-)|(-ms-)|(-moz-)|(-webkit-)/g,l=document.createElement("p").style;e.exports=t}(Dt,Dt.exports),function(e,t){var n=$e.exports,r=Oe.exports,i=Pt.exports,o=Ie.exports,s=ze.exports,a=we.exports,d=Mt.exports,l=Dt.exports,u=xe.exports;t=function(e,t,h){if(e=d(e),o(h)&&n(t))return function(e,t){return e.style[l(t)]||getComputedStyle(e,"").getPropertyValue(t)}(e[0],t);var p=t;r(p)||((p={})[t]=h),function(e,t){u(e,(function(e){var n=";";u(t,(function(e,t){t=l.dash(t),n+=t+":"+function(e,t){var n=a(t)&&!s(c,i(e));return n?t+"px":t}(t,e)+";"})),e.style.cssText+=n}))}(e,p)};var c=["column-count","columns","font-weight","line-weight","opacity","z-index","zoom"];e.exports=t}(Ot,Ot.exports);var jt={exports:{}};!function(e,t){var n=vt.exports,r=Oe.exports,i=$e.exports,o=xe.exports,s=Ie.exports,a=Mt.exports;(t=function(e,t,n){if(e=a(e),s(n)&&i(t))return function(e,t){return e.getAttribute(t)}(e[0],t);var d=t;r(d)||((d={})[t]=n),function(e,t){o(e,(function(e){o(t,(function(t,n){e.setAttribute(n,t)}))}))}(e,d)}).remove=function(e,t){e=a(e),t=n(t),o(e,(function(e){o(t,(function(t){e.removeAttribute(t)}))}))},e.exports=t}(jt,jt.exports);var Ft={exports:{}};!function(e,t){var n=Ie.exports,r=xe.exports,i=Mt.exports;function o(e){return function(t,o){var s=(t=i(t))[0];if(n(o))return s?s[e]:"";s&&r(t,(function(t){t[e]=o}))}}t={html:o("innerHTML"),text:o("textContent"),val:o("value")},e.exports=t}(Ft,Ft.exports);var Vt={exports:{}};!function(e,t){t=function(e){var t=e?e.length:0;if(t)return e[t-1]},e.exports=t}(Vt,Vt.exports);var zt={exports:{}};!function(e,t){var n=xe.exports,r=Mt.exports;t=function(e){e=r(e),n(e,(function(e){var t=e.parentNode;t&&t.removeChild(e)}))},e.exports=t}(zt,zt.exports);var Wt=zt.exports,$t={exports:{}};!function(e,t){var n=jt.exports,r=$e.exports,i=Oe.exports,o=xe.exports;t=function(e,t,s){var a=t;return r(t)&&(a="data-"+t),i(t)&&(a={},o(t,(function(e,t){a["data-"+t]=e}))),n(e,a,s)},e.exports=t}($t,$t.exports);var Gt={exports:{}},Ut={exports:{}};!function(e,t){var n=ze.exports;function r(){return!0}function i(){return!1}function o(e){var n,r=this.events[e.type],i=s.call(this,e,r);e=new t.Event(e);for(var o,a,d=0;(a=i[d++])&&!e.isPropagationStopped();)for(e.curTarget=a.el,o=0;(n=a.handlers[o++])&&!e.isImmediatePropagationStopped();)!1===n.handler.apply(a.el,[e])&&(e.preventDefault(),e.stopPropagation())}function s(e,t){var r,i,o,s,a=e.target,d=[],l=t.delegateCount;if(a.nodeType)for(;a!==this;a=a.parentNode||this){for(i=[],s=0;s<l;s++)void 0===i[r=(o=t[s]).selector+" "]&&(i[r]=n(this.querySelectorAll(r),a)),i[r]&&i.push(o);i.length&&d.push({el:a,handlers:i})}return l<t.length&&d.push({el:this,handlers:t.slice(l)}),d}t={add:function(e,t,n,r){var i,s={selector:n,handler:r};e.events||(e.events={}),(i=e.events[t])||((i=e.events[t]=[]).delegateCount=0,e.addEventListener(t,(function(){o.apply(e,arguments)}),!1)),n?i.splice(i.delegateCount++,0,s):i.push(s)},remove:function(e,t,n,r){var i=e.events;if(i&&i[t])for(var o,s=i[t],a=s.length;a--;)o=s[a],n&&o.selector!=n||o.handler!=r||(s.splice(a,1),o.selector&&s.delegateCount--)},Event:(0,lt.exports)({className:"Event",initialize:function(e){this.origEvent=e},isDefaultPrevented:i,isPropagationStopped:i,isImmediatePropagationStopped:i,preventDefault:function(){var e=this.origEvent;this.isDefaultPrevented=r,e&&e.preventDefault&&e.preventDefault()},stopPropagation:function(){var e=this.origEvent;this.isPropagationStopped=r,e&&e.stopPropagation&&e.stopPropagation()},stopImmediatePropagation:function(){var e=this.origEvent;this.isImmediatePropagationStopped=r,e&&e.stopImmediatePropagation&&e.stopImmediatePropagation(),this.stopPropagation()}})},e.exports=t}(Ut,Ut.exports),function(e,t){var n=Ut.exports,r=Ie.exports,i=Mt.exports,o=xe.exports;function s(e){return function(t,s,a,d){t=i(t),r(d)&&(d=a,a=void 0),o(t,(function(t){n[e](t,s,a,d)}))}}t={on:s("add"),off:s("remove")},e.exports=t}(Gt,Gt.exports);var Ht={exports:{}},qt={exports:{}};!function(e,t){var n=Ce.exports,r=be.exports,i=Se.exports;t=function(e,t,o){t=n(t,o);for(var s=!r(e)&&i(e),a=(s||e).length,d=0;d<a;d++){var l=s?s[d]:d;if(t(e[l],l,e))return!0}return!1},e.exports=t}(qt,qt.exports),function(e,t){var n=vt.exports,r=qt.exports,i=Mt.exports,o=$e.exports,s=xe.exports;function a(e){return o(e)?e.split(/\s+/):n(e)}t={add:function(e,n){e=i(e);var r=a(n);s(e,(function(e){var n=[];s(r,(function(r){t.has(e,r)||n.push(r)})),0!==n.length&&(e.className+=(e.className?" ":"")+n.join(" "))}))},has:function(e,t){e=i(e);var n=new RegExp("(^|\\s)"+t+"(\\s|$)");return r(e,(function(e){return n.test(e.className)}))},toggle:function(e,n){e=i(e),s(e,(function(e){if(!t.has(e,n))return t.add(e,n);t.remove(e,n)}))},remove:function(e,t){e=i(e);var n=a(t);s(e,(function(e){s(n,(function(t){e.classList.remove(t)}))}))}},e.exports=t}(Ht,Ht.exports);var Yt={exports:{}};!function(e,t){var n=xe.exports,r=Mt.exports,i=$e.exports;function o(e){return function(t,o){t=r(t),n(t,(function(t){if(i(o))t.insertAdjacentHTML(e,o);else{var n=t.parentNode;switch(e){case"beforebegin":n&&n.insertBefore(o,t);break;case"afterend":n&&n.insertBefore(o,t.nextSibling);break;case"beforeend":t.appendChild(o);break;case"afterbegin":t.prepend(o)}}}))}}t={before:o("beforebegin"),after:o("afterend"),append:o("beforeend"),prepend:o("afterbegin")},e.exports=t}(Yt,Yt.exports),function(e,t){var n=Nt.exports,r=At.exports,i=Ct.exports,o=Ot.exports,s=jt.exports,a=Ft.exports,d=Vt.exports,l=zt.exports,u=$t.exports,c=Gt.exports,h=Ht.exports,p=Yt.exports,f=Ie.exports,v=$e.exports;t=function(e){return new n(e)},n.methods({offset:function(){return r(this)},hide:function(){return this.css("display","none")},show:function(){return i(this),this},first:function(){return t(this[0])},last:function(){return t(d(this))},get:function(e){return this[e]},eq:function(e){return t(this[e])},on:function(e,t,n){return c.on(this,e,t,n),this},off:function(e,t,n){return c.off(this,e,t,n),this},html:function(e){var t=a.html(this,e);return f(e)?t:this},text:function(e){var t=a.text(this,e);return f(e)?t:this},val:function(e){var t=a.val(this,e);return f(e)?t:this},css:function(e,t){var n=o(this,e,t);return g(e,t)?n:this},attr:function(e,t){var n=s(this,e,t);return g(e,t)?n:this},data:function(e,t){var n=u(this,e,t);return g(e,t)?n:this},rmAttr:function(e){return s.remove(this,e),this},remove:function(){return l(this),this},addClass:function(e){return h.add(this,e),this},rmClass:function(e){return h.remove(this,e),this},toggleClass:function(e){return h.toggle(this,e),this},hasClass:function(e){return h.has(this,e)},parent:function(){return t(this[0].parentNode)},append:function(e){return p.append(this,e),this},prepend:function(e){return p.prepend(this,e),this},before:function(e){return p.before(this,e),this},after:function(e){return p.after(this,e),this}});var g=function(e,t){return f(t)&&v(e)};e.exports=t}(Et,Et.exports);var Xt={},Kt={exports:{}},Jt={exports:{}};!function(e,t){t="object"==typeof window&&"object"==typeof document&&9===document.nodeType,e.exports=t}(Jt,Jt.exports),function(e,t){t=Jt.exports?window:ce,e.exports=t}(Kt,Kt.exports);var Qt={exports:{}},Zt={exports:{}},en={exports:{}};!function(e,t){var n=xe.exports,r=Ie.exports,i=Te.exports;t=function(e,t){r(t)&&(t=!0);var o=i(t),s={};return n(e,(function(e){s[e]=o?t(e):t})),s},e.exports=t}(en,en.exports);var tn={exports:{}},nn={exports:{}};!function(e,t){t=function(e){return null==e?"":e.toString()},e.exports=t}(nn,nn.exports),function(e,t){var n=nn.exports;t=function(e){return n(e).toLocaleLowerCase()},e.exports=t}(tn,tn.exports),function(e,t){var n=Vt.exports,r=Ve.exports,i=tn.exports;t=function(e,t){for(var u,c=[],h=e;e;){if(u=!0,n(c)&&l[n(c)]){var p=new RegExp("</".concat(n(c),"[^>]*>")).exec(e);if(p){var f=e.substring(0,p.index);e=e.substring(p.index+p[0].length),f&&t.text&&t.text(f)}_("",n(c))}else{if(r(e,"\x3c!--")){var v=e.indexOf("--\x3e");v>=0&&(t.comment&&t.comment(e.substring(4,v)),e=e.substring(v+3),u=!1)}else if(r(e,"<!")){var g=e.match(o);g&&(t.text&&t.text(e.substring(0,g[0].length)),e=e.substring(g[0].length),u=!1)}else if(r(e,"</")){var m=e.match(s);m&&(e=e.substring(m[0].length),m[0].replace(s,_),u=!1)}else if(r(e,"<")){var y=e.match(a);y&&(e=e.substring(y[0].length),y[0].replace(a,w),u=!1)}if(u){var x=e.indexOf("<"),b=x<0?e:e.substring(0,x);e=x<0?"":e.substring(x),t.text&&t.text(b)}}if(h===e)throw Error("Parse Error: "+e);h=e}function w(e,n,r,o){if(n=i(n),(o=!!o)||c.push(n),t.start){var s={};r.replace(d,(function(e,t,n,r,i){s[t]=n||r||i||""})),t.start(n,s,o)}}function _(e,n){var r;if(n=i(n))for(r=c.length-1;r>=0&&c[r]!==n;r--);else r=0;if(r>=0){for(var o=c.length-1;o>=r;o--)t.end&&t.end(c[o]);c.length=r}}_()};var o=/^<!\s*doctype((?:\s+[\w:]+(?:\s*=\s*(?:(?:"[^"]*")|(?:'[^']*')|[^>\s]+))?)*)\s*(\/?)>/i,s=/^<\/([-A-Za-z0-9_]+)[^>]*>/,a=/^<([-A-Za-z0-9_]+)((?:\s+[-A-Za-z0-9_:@.]+(?:\s*=\s*(?:(?:"[^"]*")|(?:'[^']*')|[^>\s]+))?)*)\s*(\/?)>/i,d=/([-A-Za-z0-9_:@.]+)(?:\s*=\s*(?:(?:"((?:\\.|[^"])*)")|(?:'((?:\\.|[^'])*)')|([^>\s]+)))?/g,l=(0,en.exports)("script,style".split(","));e.exports=t}(Zt,Zt.exports);var rn={exports:{}},on={exports:{}};!function(e,t){t=function(e){var t=e.length,n=Array(t);t--;for(var r=0;r<=t;r++)n[t-r]=e[r];return n},e.exports=t}(on,on.exports),function(e,t){var n=on.exports;t=(0,lt.exports)({initialize:function(){this.clear()},clear:function(){this._items=[],this.size=0},push:function(e){return this._items.push(e),++this.size},pop:function(){if(this.size)return this.size--,this._items.pop()},peek:function(){return this._items[this.size-1]},forEach:function(e,t){t=arguments.length>1?t:this;for(var n=this._items,r=this.size-1,i=0;r>=0;r--,i++)e.call(t,n[r],i,this)},toArr:function(){return n(this._items)}}),e.exports=t}(rn,rn.exports);var sn={exports:{}};!function(e,t){var n=Ce.exports,r=Se.exports;t=function(e,t,i){t=n(t,i);for(var o=r(e),s=o.length,a={},d=0;d<s;d++){var l=o[d];a[l]=t(e[l],l,e)}return a},e.exports=t}(sn,sn.exports),function(e,t){var n=Zt.exports,r=rn.exports,i=Pe.exports,o=xe.exports,s=$e.exports,a=sn.exports;var d=function(e){return e.replace(/&quot;/g,'"')},l=function(e){return e.replace(/"/g,"&quot;")};t={parse:function(e){var t=[],o=new r;return n(e,{start:function(e,t){t=a(t,(function(e){return d(e)})),o.push({tag:e,attrs:t})},end:function(){var e=o.pop();if(o.size){var n=o.peek();i(n.content)||(n.content=[]),n.content.push(e)}else t.push(e)},comment:function(e){var n="\x3c!--".concat(e,"--\x3e"),r=o.peek();r?(r.content||(r.content=[]),r.content.push(n)):t.push(n)},text:function(e){var n=o.peek();n?(n.content||(n.content=[]),n.content.push(e)):t.push(e)}}),t},stringify:function e(t){var n="";return i(t)?o(t,(function(t){return n+=e(t)})):s(t)?n=t:(n+="<".concat(t.tag),o(t.attrs,(function(e,t){return n+=" ".concat(t,'="').concat(l(e),'"')})),n+=">",t.content&&(n+=e(t.content)),n+="</".concat(t.tag,">")),n}},e.exports=t}(Qt,Qt.exports);var an=ce&&ce.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(Xt,"__esModule",{value:!0}),Xt.pxToNum=Xt.executeAfterTransition=Xt.hasVerticalScrollbar=Xt.measuredScrollbarWidth=Xt.eventClient=Xt.drag=Xt.classPrefix=void 0;var dn=an(Me.exports),ln=an(ge.exports),un=an(Kt.exports),cn=an(Qt.exports),hn=an(we.exports),pn=an(ze.exports),fn=an(qe.exports);function vn(e,t){for(var n=0,r=e.length;n<r;n++){var i=e[n];t(i),i.content&&vn(i.content,t)}}Xt.classPrefix=function(e){var t=`luna-${e}-`;function n(e){return dn.default(ln.default(e).split(/\s+/),(e=>pn.default(e,t)?e:e.replace(/[\w-]+/,(e=>`${t}${e}`)))).join(" ")}return function(e){if(/<[^>]*>/g.test(e))try{var t=cn.default.parse(e);return vn(t,(e=>{e.attrs&&e.attrs.class&&(e.attrs.class=n(e.attrs.class))})),cn.default.stringify(t)}catch(t){return n(e)}return n(e)}};var gn,mn="ontouchstart"in un.default,yn={start:"touchstart",move:"touchmove",end:"touchend"},xn={start:"mousedown",move:"mousemove",end:"mouseup"};Xt.drag=function(e){return mn?yn[e]:xn[e]},Xt.eventClient=function(e,t){var n="x"===e?"clientX":"clientY";return t[n]?t[n]:t.changedTouches?t.changedTouches[0][n]:0},Xt.measuredScrollbarWidth=function(){if(hn.default(gn))return gn;if(!document)return 16;var e=document.createElement("div"),t=document.createElement("div");return e.setAttribute("style","display: block; width: 100px; height: 100px; overflow: scroll;"),t.setAttribute("style","height: 200px"),e.appendChild(t),document.body.appendChild(e),gn=e.offsetWidth-e.clientWidth,document.body.removeChild(e),gn},Xt.hasVerticalScrollbar=function(e){return e.scrollHeight>e.offsetHeight},Xt.executeAfterTransition=function(e,t){var n=r=>{r.target===e&&(e.removeEventListener("transitionend",n),t())};e.addEventListener("transitionend",n)},Xt.pxToNum=function(e){return fn.default(e.replace("px",""))};var bn=ce&&ce.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(at,"__esModule",{value:!0});var wn=bn(dt.exports),_n=bn(Et.exports),Tn=Xt,Sn=bn(xe.exports);class En extends wn.default{constructor(e,{compName:t}){super(),this.compName=t,this.c=Tn.classPrefix(t),this.options={},this.container=e,this.$container=_n.default(e),this.$container.addClass(`luna-${t}`)}destroy(){this.$container.rmClass(`luna-${this.compName}`),this.$container.html(""),this.emit("destroy"),this.removeAllListeners()}setOption(e,t){var n=this.options,r={};"string"==typeof e?r[e]=t:r=e,Sn.default(r,((e,t)=>{var r=n[t];n[t]=e,this.emit("optionChange",t,e,r)}))}find(e){return this.$container.find(this.c(e))}}at.default=En;var Nn={},In={};function An(e,t){var n=e[3];return[(1-n)*t[0]+n*e[0],(1-n)*t[1]+n*e[1],(1-n)*t[2]+n*e[2],n+t[3]*(1-n)]}function Mn([e,t,n]){return.2126*(e<=.03928?e/12.92:Math.pow((e+.055)/1.055,2.4))+.7152*(t<=.03928?t/12.92:Math.pow((t+.055)/1.055,2.4))+.0722*(n<=.03928?n/12.92:Math.pow((n+.055)/1.055,2.4))}Object.defineProperty(In,"__esModule",{value:!0}),In.getContrastThreshold=In.isLargeFont=In.getAPCAThreshold=In.desiredLuminanceAPCA=In.contrastRatioByLuminanceAPCA=In.contrastRatioAPCA=In.luminanceAPCA=In.contrastRatio=In.luminance=In.rgbaToHsla=In.blendColors=void 0,In.blendColors=An,In.rgbaToHsla=function([e,t,n,r]){var i=Math.max(e,t,n),o=Math.min(e,t,n),s=i-o,a=i+o,d=.5*a;return[o===i?0:e===i?(1/6*(t-n)/s+1)%1:t===i?1/6*(n-e)/s+1/3:1/6*(e-t)/s+2/3,0===d||1===d?0:d<=.5?s/a:s/(2-a),d,r]},In.luminance=Mn,In.contrastRatio=function(e,t){var n=Mn(An(e,t)),r=Mn(t);return(Math.max(n,r)+.05)/(Math.min(n,r)+.05)};var Cn=12.82051282051282,On=.06;function Pn([e,t,n]){return.2126729*Math.pow(e,2.4)+.7151522*Math.pow(t,2.4)+.072175*Math.pow(n,2.4)}function Rn(e){return e>.03?e:e+Math.pow(.03-e,1.45)}function Dn(e,t){if(e=Rn(e),t=Rn(t),Math.abs(e-t)<5e-4)return 0;var n=0;return 100*(n=t>=e?(n=1.25*(Math.pow(t,.55)-Math.pow(e,.58)))<.001?0:n<.078?n-n*Cn*On:n-On:(n=1.25*(Math.pow(t,.62)-Math.pow(e,.57)))>-.001?0:n>-.078?n-n*Cn*On:n+On)}In.luminanceAPCA=Pn,In.contrastRatioAPCA=function(e,t){return Dn(Pn(e),Pn(t))},In.contrastRatioByLuminanceAPCA=Dn,In.desiredLuminanceAPCA=function(e,t,n){function r(){return n?Math.pow(Math.abs(Math.pow(e,.62)-(-t-On)/1.25),1/.57):Math.pow(Math.abs(Math.pow(e,.55)-(t+On)/1.25),1/.58)}e=Rn(e),t/=100;var i=r();return(i<0||i>1)&&(n=!n,i=r()),i};var kn=[[12,-1,-1,-1,-1,100,90,80,-1,-1],[14,-1,-1,-1,100,90,80,60,60,-1],[16,-1,-1,100,90,80,60,55,50,50],[18,-1,-1,90,80,60,55,50,40,40],[24,-1,100,80,60,55,50,40,38,35],[30,-1,90,70,55,50,40,38,35,40],[36,-1,80,60,50,40,38,35,30,25],[48,100,70,55,40,38,35,30,25,20],[60,90,60,50,38,35,30,25,20,20],[72,80,55,40,35,30,25,20,20,20],[96,70,50,35,30,25,20,20,20,20],[120,60,40,30,25,20,20,20,20,20]];function Ln(e,t){var n=72*parseFloat(e.replace("px",""))/96;return-1!==["bold","bolder","600","700","800","900"].indexOf(t)?n>=14:n>=18}kn.reverse(),In.getAPCAThreshold=function(e,t){var n=parseFloat(e.replace("px","")),r=parseFloat(t);for(var[i,...o]of kn)if(n>=i)for(var[s,a]of[900,800,700,600,500,400,300,200,100].entries())if(r>=a){var d=o[o.length-1-s];return-1===d?null:d}return null},In.isLargeFont=Ln;var Bn={aa:3,aaa:4.5},jn={aa:4.5,aaa:7};In.getContrastThreshold=function(e,t){return Ln(e,t)?Bn:jn};var Fn={};Object.defineProperty(Fn,"__esModule",{value:!0}),Fn.adoptStyleSheet=Fn.constrainNumber=Fn.ellipsify=Fn.createElement=Fn.createTextChild=Fn.createChild=Fn.log=Fn.Overlay=void 0;function Vn(e,t,n){var r=zn(t,n);return r.addEventListener("click",(function(e){e.stopPropagation()}),!1),e.appendChild(r),r}function zn(e,t){var n=document.createElement(e);if(t){var r=t.split(/\s+/);r=r.map((e=>"luna-dom-highlighter-"+e)),n.className=r.join(" ")}return n}function Wn(e){document.adoptedStyleSheets=[...document.adoptedStyleSheets,e]}Fn.Overlay=class{constructor(e,t=[]){this.viewportSize={width:800,height:600},this.deviceScaleFactor=1,this.emulationScaleFactor=1,this.pageScaleFactor=1,this.pageZoomFactor=1,this.scrollX=0,this.scrollY=0,this.canvasWidth=0,this.canvasHeight=0,this._installed=!1,this._window=e,this._document=e.document,Array.isArray(t)||(t=[t]),this.style=t}setCanvas(e){this.canvas=e,this._context=e.getContext("2d")}install(){for(var e of this.style)Wn(e);this._installed=!0}uninstall(){var e=function(e){document.adoptedStyleSheets=document.adoptedStyleSheets.filter((t=>t!==e))};for(var t of this.style)e(t);this._installed=!1}reset(e){e&&(this.viewportSize=e.viewportSize,this.visualViewportSize=e.visualViewportSize,this.deviceScaleFactor=e.deviceScaleFactor,this.pageScaleFactor=e.pageScaleFactor,this.pageZoomFactor=e.pageZoomFactor,this.emulationScaleFactor=e.emulationScaleFactor,this.scrollX=Math.round(e.scrollX),this.scrollY=Math.round(e.scrollY)),this.resetCanvas()}resetCanvas(){this.canvas&&this._context&&(this.canvas.width=this.deviceScaleFactor*this.viewportSize.width,this.canvas.height=this.deviceScaleFactor*this.viewportSize.height,this.canvas.style.width=this.viewportSize.width+"px",this.canvas.style.height=this.viewportSize.height+"px",this._context.scale(this.deviceScaleFactor,this.deviceScaleFactor),this.canvasWidth=this.viewportSize.width,this.canvasHeight=this.viewportSize.height)}setPlatform(e){this.platform=e,this._installed||this.install()}dispatch(e){this[e.shift()].apply(this,e)}eventHasCtrlOrMeta(e){return"mac"===this.platform?e.metaKey&&!e.ctrlKey:e.ctrlKey&&!e.metaKey}get context(){if(!this._context)throw new Error("Context object is missing");return this._context}get document(){if(!this._document)throw new Error("Document object is missing");return this._document}get window(){if(!this._window)throw new Error("Window object is missing");return this._window}get installed(){return this._installed}},Fn.log=function(e){var t=document.getElementById("log");t||((t=Vn(document.body,"div")).id="log"),Vn(t,"div").textContent=e},Fn.createChild=Vn,Fn.createTextChild=function(e,t){var n=document.createTextNode(t);return e.appendChild(n),n},Fn.createElement=zn,Fn.ellipsify=function(e,t){return e.length<=t?String(e):e.substr(0,t-1)+"…"},Fn.constrainNumber=function(e,t,n){return e<t?e=t:e>n&&(e=n),e},Fn.adoptStyleSheet=Wn;var $n={};Object.defineProperty($n,"__esModule",{value:!0}),$n.drawPath=$n.formatColor=$n.formatRgba=$n.parseHexa=$n.createPathForQuad=$n.hatchFillPath=$n.applyMatrixToPoint=$n.emptyBounds=$n.buildPath=$n.fillPathWithBoxStyle=$n.drawPathWithLineStyle=void 0;var Gn=In;function Un(e,t,n){var r=0;function i(i){for(var o=[],s=0;s<i;++s){var a=Math.round(e[r++]*n);t.maxX=Math.max(t.maxX,a),t.minX=Math.min(t.minX,a);var d=Math.round(e[r++]*n);t.maxY=Math.max(t.maxY,d),t.minY=Math.min(t.minY,d),t.leftmostXForY[d]=Math.min(t.leftmostXForY[d]||Number.MAX_VALUE,a),t.rightmostXForY[d]=Math.max(t.rightmostXForY[d]||Number.MIN_VALUE,a),t.topmostYForX[a]=Math.min(t.topmostYForX[a]||Number.MAX_VALUE,d),t.bottommostYForX[a]=Math.max(t.bottommostYForX[a]||Number.MIN_VALUE,d),t.allPoints.push({x:a,y:d}),o.push(a,d)}return o}for(var o=e.length,s=new Path2D;r<o;)switch(e[r++]){case"M":s.moveTo.apply(s,i(1));break;case"L":s.lineTo.apply(s,i(1));break;case"C":s.bezierCurveTo.apply(s,i(3));break;case"Q":s.quadraticCurveTo.apply(s,i(2));break;case"Z":s.closePath()}return s}$n.drawPathWithLineStyle=function(e,t,n,r=1){n&&n.color&&(e.save(),e.translate(.5,.5),e.lineWidth=r,"dashed"===n.pattern&&e.setLineDash([3,3]),"dotted"===n.pattern&&e.setLineDash([2,2]),e.strokeStyle=n.color,e.stroke(t),e.restore())},$n.fillPathWithBoxStyle=function(e,t,n,r,i){i&&(e.save(),i.fillColor&&(e.fillStyle=i.fillColor,e.fill(t)),i.hatchColor&&Kn(e,t,n,10,i.hatchColor,r,!1),e.restore())},$n.buildPath=Un,$n.emptyBounds=function(){return{minX:Number.MAX_VALUE,minY:Number.MAX_VALUE,maxX:-Number.MAX_VALUE,maxY:-Number.MAX_VALUE,leftmostXForY:{},rightmostXForY:{},topmostYForX:{},bottommostYForX:{},allPoints:[]}},$n.applyMatrixToPoint=function(e,t){var n=new DOMPoint(e.x,e.y);return{x:(n=n.matrixTransform(t)).x,y:n.y}};var Hn,qn=5,Yn=3,Xn="";function Kn(e,t,n,r,i,o,s){if((e.canvas.width<n.maxX-n.minX||e.canvas.height<n.maxY-n.minY)&&(n={minX:0,maxX:e.canvas.width,minY:0,maxY:e.canvas.height,allPoints:[]}),!Hn||i!==Xn){Xn=i;var a=document.createElement("canvas");a.width=r,a.height=qn+Yn;var d=a.getContext("2d");d.clearRect(0,0,a.width,a.height),d.rect(0,0,1,qn),d.fillStyle=i,d.fill(),Hn=e.createPattern(a,"repeat")}e.save();var l=new DOMMatrix;Hn.setTransform(l.scale(s?-1:1,1).rotate(0,0,-45+o)),e.fillStyle=Hn,e.fill(t),e.restore()}function Jn(e){return(e.match(/#(\w\w)(\w\w)(\w\w)(\w\w)/)||[]).slice(1).map((e=>parseInt(e,16)/255))}function Qn(e,t){if("rgb"===t){var[n,r,i,o]=e;return`rgb(${(255*n).toFixed()} ${(255*r).toFixed()} ${(255*i).toFixed()}${1===o?"":" / "+Math.round(100*o)/100})`}if("hsl"===t){var[s,a,d,l]=Gn.rgbaToHsla(e);return`hsl(${Math.round(360*s)}deg ${Math.round(100*a)} ${Math.round(100*d)}${1===l?"":" / "+Math.round(100*l)/100})`}throw new Error("NOT_REACHED")}$n.hatchFillPath=Kn,$n.createPathForQuad=function(e,t,n,r){var i=["M",e.p1.x,e.p1.y,"L",e.p2.x,e.p2.y,"L",e.p3.x,e.p3.y,"L",e.p4.x,e.p4.y];for(var o of t)i=[...i,"L",o.p4.x,o.p4.y,"L",o.p3.x,o.p3.y,"L",o.p2.x,o.p2.y,"L",o.p1.x,o.p1.y,"L",o.p4.x,o.p4.y,"L",e.p4.x,e.p4.y];return i.push("Z"),Un(i,n,r)},$n.parseHexa=Jn,$n.formatRgba=Qn,$n.formatColor=function(e,t){return"rgb"===t||"hsl"===t?Qn(Jn(e),t):e.endsWith("FF")?e.substr(0,7):e},$n.drawPath=function(e,t,n,r,i,o,s){e.save();var a=Un(t,o,s);return n&&(e.fillStyle=n,e.fill(a)),r&&("dashed"===i&&e.setLineDash([3,3]),"dotted"===i&&e.setLineDash([2,2]),e.lineWidth=2,e.strokeStyle=r,e.stroke(a)),e.restore(),a},Object.defineProperty(Nn,"__esModule",{value:!0}),Nn.HighlightOverlay=void 0;var Zn=In,er=Fn,tr=$n;class nr extends er.Overlay{constructor(){super(...arguments),this.gridLabelState={gridLayerCounter:0}}setContainer(e){this._container=e}setPlatform(e){this.container&&this.container.classList.add("luna-dom-highlighter-platform-"+e),super.setPlatform(e)}get container(){return this._container}reset(e){super.reset(e),this.tooltip.innerHTML="",this.gridLabelState.gridLayerCounter=0}install(){var e=this.document.createElement("canvas");e.id="canvas",e.classList.add("luna-dom-highlighter-fill"),this.container.append(e);var t=this.document.createElement("div");this.container.append(t),this.tooltip=t,this.setCanvas(e),super.install()}uninstall(){this.document.body.classList.remove("fill"),this.document.body.innerHTML="",super.uninstall()}drawHighlight(e){this.context.save();for(var t=tr.emptyBounds(),n=e.paths.slice();n.length;){var r=n.pop();r&&(this.context.save(),tr.drawPath(this.context,r.path,r.fillColor,r.outlineColor,void 0,t,this.emulationScaleFactor),n.length&&(this.context.globalCompositeOperation="destination-out",tr.drawPath(this.context,n[n.length-1].path,"red",void 0,void 0,t,this.emulationScaleFactor)),this.context.restore())}this.context.restore(),this.context.save();var i=Boolean(e.paths.length&&e.showRulers&&t.minX<20&&t.maxX+20<this.canvasWidth),o=Boolean(e.paths.length&&e.showRulers&&t.minY<20&&t.maxY+20<this.canvasHeight);return e.showRulers&&this.drawAxis(this.context,i,o),e.paths.length&&(e.showExtensionLines&&function(e,t,n,r,i,o,s,a){e.save();var d=s,l=a;e.strokeStyle=i||sr,e.lineWidth=1,e.translate(.5,.5),o&&e.setLineDash([3,3]);if(n)for(var u in t.rightmostXForY)e.beginPath(),e.moveTo(d,Number(u)),e.lineTo(t.rightmostXForY[u],Number(u)),e.stroke();else for(var c in t.leftmostXForY)e.beginPath(),e.moveTo(0,Number(c)),e.lineTo(t.leftmostXForY[c],Number(c)),e.stroke();if(r)for(var h in t.bottommostYForX)e.beginPath(),e.moveTo(Number(h),l),e.lineTo(Number(h),t.topmostYForX[h]),e.stroke();else for(var p in t.topmostYForX)e.beginPath(),e.moveTo(Number(p),0),e.lineTo(Number(p),t.topmostYForX[p]),e.stroke();e.restore()}(this.context,t,i,o,void 0,!1,this.canvasWidth,this.canvasHeight),e.elementInfo&&function(e,t,n,r,i,o){e.innerHTML="";var s=er.createChild(e,"div"),a=er.createChild(s,"div","tooltip-content"),d=function(e,t){var n=er.createElement("div","element-info"),r=er.createChild(n,"div","element-info-header"),i=function(e){if(e.layoutObjectName&&e.layoutObjectName.endsWith("Grid"))return"grid";if(e.layoutObjectName&&"LayoutNGFlexibleBox"===e.layoutObjectName)return"flex";return null}(e);i&&er.createChild(r,"div",`element-layout-type ${i}`);var o=er.createChild(r,"div","element-description");er.createChild(o,"span","material-tag-name").textContent=e.tagName;var s=er.createChild(o,"span","material-node-id"),a=80;s.textContent=e.idValue?"#"+er.ellipsify(e.idValue,a):"",s.classList.toggle("hidden",!e.idValue);var d=er.createChild(o,"span","material-class-name");s.textContent.length<a&&(d.textContent=er.ellipsify(e.className||"",a-s.textContent.length));d.classList.toggle("hidden",!e.className);var l=er.createChild(r,"div","dimensions");er.createChild(l,"span","material-node-width").textContent=String(Math.round(100*e.nodeWidth)/100),er.createTextChild(l,"×"),er.createChild(l,"span","material-node-height").textContent=String(Math.round(100*e.nodeHeight)/100);var u,c=e.style||{};e.isLockedAncestor&&S("Showing content-visibility ancestor","");e.isLocked&&S("Descendants are skipped due to content-visibility","");var h=c.color;h&&"#00000000"!==h&&E("Color",h,t);var p=c["font-family"],f=c["font-size"];p&&"0px"!==f&&S("Font",`${f} ${p}`);var v=c["background-color"];v&&"#00000000"!==v&&E("Background",v,t);var g=c.margin;g&&"0px"!==g&&S("Margin",g);var m=c.padding;m&&"0px"!==m&&S("Padding",m);var y=e.contrast?e.contrast.backgroundColor:null,x=h&&"#00000000"!==h&&y&&"#00000000"!==y;e.showAccessibilityInfo&&(w("Accessibility"),x&&c.color&&e.contrast&&N(c.color,e.contrast),S("Name",e.accessibleName),S("Role",e.accessibleRole),T("Keyboard-focusable",e.isKeyboardFocusable?"a11y-icon a11y-icon-ok":"a11y-icon a11y-icon-not-ok"));function b(){u||(u=er.createChild(n,"div","element-info-body"))}function w(e){b();var t=er.createChild(u,"div","element-info-row element-info-section");er.createChild(t,"div","section-name").textContent=e,er.createChild(er.createChild(t,"div","separator-container"),"div","separator")}function _(e,t,n){b();var r=er.createChild(u,"div","element-info-row");return t&&r.classList.add(t),er.createChild(r,"div","element-info-name").textContent=e,er.createChild(r,"div","element-info-gap"),er.createChild(r,"div",n||"")}function T(e,t){er.createChild(_(e,"","element-info-value-icon"),"div",t)}function S(e,t){er.createTextChild(_(e,"","element-info-value-text"),t)}function E(e,t,n){var r=_(e,"","element-info-value-color"),i=er.createChild(r,"div","color-swatch");er.createChild(i,"div","color-swatch-inner").style.backgroundColor=t,er.createTextChild(r,tr.formatColor(t,n))}function N(e,t){var n=tr.parseHexa(e),r=tr.parseHexa(t.backgroundColor);n[3]*=t.textOpacity;var i=_("Contrast","","element-info-value-contrast"),o=er.createChild(i,"div","contrast-text");o.style.color=tr.formatRgba(n,"rgb"),o.style.backgroundColor=t.backgroundColor,o.textContent="Aa";var s=er.createChild(i,"span");if("apca"===t.contrastAlgorithm){var a=Zn.contrastRatioAPCA(n,r),d=Zn.getAPCAThreshold(t.fontSize,t.fontWeight);s.textContent=String(Math.floor(100*a)/100)+"%",er.createChild(i,"div",null===d||Math.abs(a)<d?"a11y-icon a11y-icon-warning":"a11y-icon a11y-icon-ok")}else if("aa"===t.contrastAlgorithm||"aaa"===t.contrastAlgorithm){var l=Zn.contrastRatio(n,r),u=Zn.getContrastThreshold(t.fontSize,t.fontWeight)[t.contrastAlgorithm];s.textContent=String(Math.floor(100*l)/100),er.createChild(i,"div",l<u?"a11y-icon a11y-icon-warning":"a11y-icon a11y-icon-ok")}}return n}(t,n);a.appendChild(d);var l,u=a.offsetWidth,c=a.offsetHeight,h=8,p=2,f=2*h,v=h+2,g=p+v,m=i-p-v-f,y=r.maxX-r.minX<f+2*v;if(y)l=.5*(r.minX+r.maxX)-h;else{var x=r.minX+v,b=r.maxX-v-f;l=x>g&&x<m?x:er.constrainNumber(g,x,b)}var w=l<g||l>m,_=l-v;_=er.constrainNumber(_,p,i-u-p);var T=r.minY-h-c,S=!0;T<0?(T=Math.min(o-c,r.maxY+h),S=!1):r.minY>o&&(T=o-h-c);var E=_>=r.minX&&_+u<=r.maxX&&T>=r.minY&&T+c<=r.maxY,N=_<r.maxX&&_+u>r.minX&&T<r.maxY&&T+c>r.minY;if(N&&!E)return void(a.style.display="none");if(a.style.top=T+"px",a.style.left=_+"px",w)return;var I=er.createChild(a,"div","tooltip-arrow");I.style.clipPath=S?"polygon(0 0, 100% 0, 50% 100%)":"polygon(50% 0, 0 100%, 100% 100%)",I.style.top=(S?c-1:-h)+"px",I.style.left=l-_+"px"}(this.tooltip,e.elementInfo,e.colorFormat,t,this.canvasWidth,this.canvasHeight)),this.context.restore(),{bounds:t}}drawAxis(e,t,n){e.save();var r=this.pageZoomFactor*this.pageScaleFactor*this.emulationScaleFactor,i=this.scrollX*this.pageScaleFactor,o=this.scrollY*this.pageScaleFactor;function s(e){return Math.round(e*r)}function a(e){return Math.round(e/r)}var d=this.canvasWidth/r,l=this.canvasHeight/r,u=50;e.save(),e.fillStyle=or,n?e.fillRect(0,s(l)-15,s(d),s(l)):e.fillRect(0,0,s(d),15),e.globalCompositeOperation="destination-out",e.fillStyle="red",t?e.fillRect(s(d)-15,0,s(d),s(l)):e.fillRect(0,0,15,s(l)),e.restore(),e.fillStyle=or,t?e.fillRect(s(d)-15,0,s(d),s(l)):e.fillRect(0,0,15,s(l)),e.lineWidth=1,e.strokeStyle=ir,e.fillStyle=ir,e.save(),e.translate(-i,.5-o);for(var c=l+a(o),h=100;h<c;h+=100)e.save(),e.translate(i,s(h)),e.rotate(-Math.PI/2),e.fillText(String(h),2,t?s(d)-7:13),e.restore();e.translate(.5,-.5);for(var p=d+a(i),f=100;f<p;f+=100)e.save(),e.fillText(String(f),s(f)+2,n?o+s(l)-7:o+13),e.restore();e.restore(),e.save(),t&&(e.translate(s(d),0),e.scale(-1,1)),e.translate(-i,.5-o);for(var v=l+a(o),g=u;g<v;g+=u){e.beginPath(),e.moveTo(i,s(g));var m=g%100?5:8;e.lineTo(i+m,s(g)),e.stroke()}e.strokeStyle=rr;for(var y=5;y<v;y+=5)y%u&&(e.beginPath(),e.moveTo(i,s(y)),e.lineTo(i+5,s(y)),e.stroke());e.restore(),e.save(),n&&(e.translate(0,s(l)),e.scale(1,-1)),e.translate(.5-i,-o);for(var x=d+a(i),b=u;b<x;b+=u){e.beginPath(),e.moveTo(s(b),o);var w=b%100?5:8;e.lineTo(s(b),o+w),e.stroke()}e.strokeStyle=rr;for(var _=5;_<x;_+=5)_%u&&(e.beginPath(),e.moveTo(s(_),o),e.lineTo(s(_),o+5),e.stroke());e.restore(),e.restore()}}Nn.HighlightOverlay=nr;var rr="rgba(0,0,0,0.2)",ir="rgba(0,0,0,0.7)",or="rgba(255, 255, 255, 0.8)";var sr="rgba(128, 128, 128, 0.3)";var ar={exports:{}},dr={exports:{}};!function(e,t){var n=St.exports,r=xe.exports,i=vt.exports;t=(0,lt.exports)({initialize:function(){this._listeners=[]},addListener:function(e){this._listeners.push(e)},rmListener:function(e){var t=this._listeners.indexOf(e);t>-1&&this._listeners.splice(t,1)},rmAllListeners:function(){this._listeners=[]},emit:function(){var e=this,t=i(arguments),o=n(this._listeners);r(o,(function(n){return n.apply(e,t)}),this)}},{mixin:function(e){r(["addListener","rmListener","emit","rmAllListeners"],(function(n){e[n]=t.prototype[n]})),e._listeners=e._listeners||[]}}),e.exports=t}(dr,dr.exports);var lr={exports:{}},ur={exports:{}};!function(e,t){t=function(e){return!(!e||1!==e.nodeType)},e.exports=t}(ur,ur.exports),function(e,t){var n=ur.exports,r=$e.exports,i=Ve.exports,o=Ht.exports,s=Ot.exports,a=xe.exports,d=Te.exports;t=function(e,t){for(var l=arguments.length,u=new Array(l>2?l-2:0),c=2;c<l;c++)u[c-2]=arguments[c];(n(t)||r(t))&&(u.unshift(t),t=null),t||(t={});var h=function(e){for(var t="div",n="",r=[],o=[],s="",a=0,d=e.length;a<d;a++){var l=e[a];"#"===l||"."===l?(o.push(s),s=l):s+=l}o.push(s);for(var u=0,c=o.length;u<c;u++)(s=o[u])&&(i(s,"#")?n=s.slice(1):i(s,".")?r.push(s.slice(1)):t=s);return{tagName:t,id:n,classes:r}}(e),p=h.tagName,f=h.id,v=h.classes,g=document.createElement(p);return f&&g.setAttribute("id",f),o.add(g,v),a(u,(function(e){r(e)?g.appendChild(document.createTextNode(e)):n(e)&&g.appendChild(e)})),a(t,(function(e,t){r(e)?g.setAttribute(t,e):d(e)&&i(t,"on")?g.addEventListener(t.slice(2),e,!1):"style"===t&&s(g,e)})),g},e.exports=t}(lr,lr.exports),function(e,t){var n=dr.exports,r=lr.exports,i=Gt.exports,o=Ot.exports,s=ze.exports,a=ut.exports,d=Kt.exports;t=d.ResizeObserver?n.extend({initialize:function(e){var t=this;if(e._resizeSensor)return e._resizeSensor;this.callSuper(n,"initialize");var r=new d.ResizeObserver((function(){return t.emit()}));r.observe(e),e._resizeSensor=this,this._resizeObserver=r,this._el=e},destroy:function(){var e=this._el;e._resizeSensor&&(this.rmAllListeners(),delete e._resizeSensor,this._resizeObserver.unobserve(e))}}):n.extend({initialize:function(e){if(e._resizeSensor)return e._resizeSensor;this.callSuper(n,"initialize"),this._el=e,e._resizeSensor=this,s(["absolute","relative","fixed","sticky"],o(e,"position"))||o(e,"position","relative"),this._appendResizeSensor(),this._bindEvent()},destroy:function(){var e=this._el;e._resizeSensor&&(this.rmAllListeners(),delete e._resizeSensor,e.removeChild(this._resizeSensorEl))},_appendResizeSensor:function(){var e=this._el,t={pointerEvents:"none",position:"absolute",left:"0px",top:"0px",right:"0px",bottom:"0px",overflow:"hidden",zIndex:"-1",visibility:"hidden",maxWidth:"100%"},n={position:"absolute",left:"0px",top:"0px",transition:"0s"},i=r("div",{style:n}),o=r("div.resize-sensor-expand",{style:t},i),s=r("div.resize-sensor-shrink",{style:t},r("div",{style:a({width:"200%",height:"200%"},n)})),d=r("div.resize-sensor",{dir:"ltr",style:t},o,s);this._expandEl=o,this._expandChildEl=i,this._shrinkEl=s,this._resizeSensorEl=d,e.appendChild(d),this._resetExpandShrink()},_bindEvent:function(){var e=this;i.on(this._expandEl,"scroll",(function(){return e._onScroll()})),i.on(this._shrinkEl,"scroll",(function(){return e._onScroll()}))},_onScroll:function(){this.emit(),this._resetExpandShrink()},_resetExpandShrink:function(){var e=this._el,t=e.offsetWidth,n=e.offsetHeight;o(this._expandChildEl,{width:t+10,height:n+10}),a(this._expandEl,{scrollLeft:t+10,scrollTop:n+10}),a(this._shrinkEl,{scrollLeft:t+10,scrollTop:n+10})}}),e.exports=t}(ar,ar.exports);var cr={exports:{}},hr={exports:{}};!function(e,t){t=function(e,t,n){var r;return function(){var i=this,o=arguments;n||clearTimeout(r),n&&r||(r=setTimeout((function(){r=null,e.apply(i,o)}),t))}},e.exports=t}(hr,hr.exports),function(e,t){var n=hr.exports;t=function(e,t){return n(e,t,!0)},e.exports=t}(cr,cr.exports);var pr={exports:{}},fr={exports:{}};!function(e,t){var n=Ie.exports;t=function(e,t,r){return n(r)&&(r=t,t=void 0),!n(t)&&e<t?t:e>r?r:e},e.exports=t}(fr,fr.exports);var vr={exports:{}};!function(e,t){t=function(e){var t,o,s=e[0]/255,a=e[1]/255,d=e[2]/255,l=n(s,a,d),u=r(s,a,d),c=u-l;(t=n(60*(t=u===l?0:s===u?(a-d)/c:a===u?2+(d-s)/c:4+(s-a)/c),360))<0&&(t+=360);var h=(l+u)/2;o=u===l?0:h<=.5?c/(u+l):c/(2-u-l);var p=[i(t),i(100*o),i(100*h)];return e[3]&&(p[3]=e[3]),p};var n=Math.min,r=Math.max,i=Math.round;e.exports=t}(vr,vr.exports);var gr={exports:{}};!function(e,t){t=function(e){var t,r,i,o=e[0]/360,s=e[1]/100,a=e[2]/100,d=[];if(e[3]&&(d[3]=e[3]),0===s)return i=n(255*a),d[0]=d[1]=d[2]=i,d;for(var l=2*a-(t=a<.5?a*(1+s):a+s-a*s),u=0;u<3;u++)(r=o+1/3*-(u-1))<0&&r++,r>1&&r--,i=6*r<1?l+6*(t-l)*r:2*r<1?t:3*r<2?l+(t-l)*(2/3-r)*6:l,d[u]=n(255*i);return d};var n=Math.round;e.exports=t}(gr,gr.exports);var mr={exports:{}},yr={exports:{}},xr={exports:{}};!function(e,t){var n=we.exports;t=function(e){return n(e)&&e%1==0},e.exports=t}(xr,xr.exports),function(e,t){var n=xr.exports;t=function(e){return!!n(e)&&e%2!=0},e.exports=t}(yr,yr.exports),function(e,t){var n=yr.exports;t={encode:function(e){for(var t=[],n=0,r=e.length;n<r;n++){var i=e[n];t.push((i>>>4).toString(16)),t.push((15&i).toString(16))}return t.join("")},decode:function(e){var t=[],r=e.length;n(r)&&r--;for(var i=0;i<r;i+=2)t.push(parseInt(e.substr(i,2),16));return t}},e.exports=t}(mr,mr.exports),function(e,t){var n=$e.exports,r=fr.exports,i=vr.exports,o=gr.exports,s=mr.exports;t=(0,lt.exports)({initialize:function(e){n(e)&&(e=t.parse(e)),this.model=e.model,this.val=e.val},toRgb:function(){var e=this.val;"hsl"===this.model&&(e=o(e));var t="rgba";return 1===e[3]&&(t="rgb",e=e.slice(0,3)),t+"("+e.join(", ")+")"},toHex:function(){var e=this.val;"hsl"===this.model&&(e=o(e));var t=s.encode(e.slice(0,3));return t[0]===t[1]&&t[2]===t[3]&&t[4]===t[5]&&(t=t[0]+t[2]+t[5]),"#"+t},toHsl:function(){var e=this.val;"rgb"===this.model&&(e=i(e));var t="hsla";return 1===e[3]&&(t="hsl",e=e.slice(0,3)),e[1]=e[1]+"%",e[2]=e[2]+"%",t+"("+e.join(", ")+")"}},{parse:function(e){var t,n,i=[0,0,0,1],o="rgb";if(n=e.match(a))for(n=n[1],t=0;t<3;t++)i[t]=parseInt(n[t]+n[t],16);else if(n=e.match(d))for(n=n[1],t=0;t<3;t++){var s=2*t;i[t]=parseInt(n.slice(s,s+2),16)}else if(n=e.match(l)){for(t=0;t<3;t++)i[t]=parseInt(n[t+1],0);n[4]&&(i[3]=parseFloat(n[4]))}else if(n=e.match(u)){for(t=0;t<3;t++)i[t]=Math.round(2.55*parseFloat(n[t+1]));n[4]&&(i[3]=parseFloat(n[4]))}else(n=e.match(c))&&(o="hsl",i=[(parseFloat(n[1])%360+360)%360,r(parseFloat(n[2]),0,100),r(parseFloat(n[3]),0,100),r(parseFloat(n[4]),0,1)]);return{val:i,model:o}}});var a=/^#([a-fA-F0-9]{3})$/,d=/^#([a-fA-F0-9]{6})$/,l=/^rgba?\(\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*(?:,\s*([+-]?[\d.]+)\s*)?\)$/,u=/^rgba?\(\s*([+-]?[\d.]+)%\s*,\s*([+-]?[\d.]+)%\s*,\s*([+-]?[\d.]+)%\s*(?:,\s*([+-]?[\d.]+)\s*)?\)$/,c=/^hsla?\(\s*([+-]?\d*[.]?\d+)(?:deg)?\s*,\s*([+-]?[\d.]+)%\s*,\s*([+-]?[\d.]+)%\s*(?:,\s*([+-]?[\d.]+)\s*)?\)$/;e.exports=t}(pr,pr.exports);var br={exports:{}};!function(e,t){var n=nn.exports;t=function(e){return n(e).toLocaleUpperCase()},e.exports=t}(br,br.exports);var wr={};Object.defineProperty(wr,"__esModule",{value:!0});wr.default=[["menuitem","command"],["rel","roletype"],["article","article"],["header","banner"],["input","button",[["type","checkbox"]]],["summary","button",[["aria-expanded","false"]]],["summary","button",[["aria-expanded","true"]]],["input","button",[["type","button"]]],["input","button",[["type","image"]]],["input","button",[["type","reset"]]],["input","button",[["type","submit"]]],["button","button"],["td","cell"],["input","checkbox",[["type","checkbox"]]],["th","columnheader"],["input","combobox",[["type","email"]]],["input","combobox",[["type","search"]]],["input","combobox",[["type","tel"]]],["input","combobox",[["type","text"]]],["input","combobox",[["type","url"]]],["input","combobox",[["type","url"]]],["select","combobox"],["select","combobox",[["size",1]]],["aside","complementary"],["footer","contentinfo"],["dd","definition"],["dialog","dialog"],["body","document"],["figure","figure"],["form","form"],["form","form"],["form","form"],["span","generic"],["div","generic"],["table","grid",[["role","grid"]]],["td","gridcell",[["role","gridcell"]]],["details","group"],["fieldset","group"],["optgroup","group"],["h1","heading"],["h2","heading"],["h3","heading"],["h4","heading"],["h5","heading"],["h6","heading"],["img","img"],["img","img"],["a","link"],["area","link"],["link","link"],["menu","list"],["ol","list"],["ul","list"],["select","listbox"],["select","listbox"],["select","listbox"],["datalist","listbox"],["li","listitem"],["main","main"],["math","math"],["menuitem","command"],["nav","navigation"],["option","option"],["progress","progressbar"],["input","radio",[["type","radio"]]],["section","region"],["section","region"],["frame","region"],["tr","row"],["tbody","rowgroup"],["tfoot","rowgroup"],["thead","rowgroup"],["th","rowheader",[["scope","row"]]],["input","searchbox",[["type","search"]]],["hr","separator"],["input","slider",[["type","range"]]],["input","spinbutton",[["type","number"]]],["output","status"],["table","table"],["dfn","term"],["input","textbox"],["input","textbox",[["type","email"]]],["input","textbox",[["type","tel"]]],["input","textbox",[["type","text"]]],["input","textbox",[["type","url"]]],["textarea","textbox"]],function(e,t){var n=ce&&ce.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(t,"__esModule",{value:!0});var r=n(at),i=Nn,o=Xt,s=n(ar.exports),a=n(cr.exports),d=n(tn.exports),l=n(xe.exports),u=n(pr.exports),c=n(mr.exports),h=n(br.exports),p=n(ut.exports),f=n(Lt.exports),v=n(ze.exports),g=n(qe.exports),m=n(wr),y=n($e.exports);class x extends r.default{constructor(e,{showRulers:t=!1,showExtensionLines:n=!1,showInfo:r=!0,showStyles:o=!0,showAccessibilityInfo:s=!0,colorFormat:d="hex",contentColor:l="rgba(111, 168, 220, .66)",paddingColor:u="rgba(147, 196, 125, .55)",borderColor:c="rgba(255, 229, 153, .66)",marginColor:h="rgba(246, 178, 107, .66)",monitorResize:p=!0}={}){super(e,{compName:"dom-highlighter"}),this.overlay=new i.HighlightOverlay(window),this.reset=()=>{var e=document.documentElement.clientWidth,t=document.documentElement.clientHeight;this.overlay.reset({viewportSize:{width:e,height:t},deviceScaleFactor:1,pageScaleFactor:1,pageZoomFactor:1,emulationScaleFactor:1,scrollX:window.scrollX,scrollY:window.scrollY})},this.options={showRulers:t,showExtensionLines:n,showInfo:r,showStyles:o,showAccessibilityInfo:s,colorFormat:d,contentColor:l,paddingColor:u,borderColor:c,marginColor:h,monitorResize:p},this.overlay.setContainer(e),this.overlay.setPlatform("mac"),this.redraw=a.default((()=>{this.reset(),this.draw()}),16),this.redraw(),this.bindEvent()}highlight(e,t){t&&p.default(this.options,t),this.target=e,e instanceof HTMLElement&&this.options.monitorResize&&(this.resizeSensor&&this.resizeSensor.destroy(),this.resizeSensor=new s.default(e),this.resizeSensor.addListener(this.redraw)),this.redraw()}hide(){this.target=null,this.redraw()}intercept(e){this.interceptor=e}destroy(){window.removeEventListener("resize",this.redraw),window.removeEventListener("scroll",this.redraw),this.resizeSensor&&this.resizeSensor.destroy(),super.destroy()}draw(){var{target:e}=this;e&&(e instanceof Text?this.drawText(e):this.drawElement(e))}drawText(e){var{options:t}=this,n=document.createRange();n.selectNode(e);var{left:r,top:i,width:o,height:s}=n.getBoundingClientRect();n.detach();var a={paths:[{path:this.rectToPath({left:r,top:i,width:o,height:s}),fillColor:_(t.contentColor),name:"content"}],showExtensionLines:t.showExtensionLines,showRulers:t.showRulers};t.showInfo&&(a.elementInfo={tagName:"#text",nodeWidth:o,nodeHeight:s}),this.overlay.drawHighlight(a)}drawElement(e){var t={paths:this.getPaths(e),showExtensionLines:this.options.showExtensionLines,showRulers:this.options.showRulers,colorFormat:this.options.colorFormat};if(this.options.showInfo&&(t.elementInfo=this.getElementInfo(e)),this.interceptor){var n=this.interceptor(t);n&&(t=n)}this.overlay.drawHighlight(t)}getPaths(e){var{options:t}=this,n=window.getComputedStyle(e),{left:r,top:i,width:s,height:a}=e.getBoundingClientRect(),d=e=>o.pxToNum(n.getPropertyValue(e)),l=d("margin-left"),u=d("margin-right"),c=d("margin-top"),h=d("margin-bottom"),p=d("border-left-width"),f=d("border-right-width"),v=d("border-top-width"),g=d("border-bottom-width"),m=d("padding-left"),y=d("padding-right"),x=d("padding-top"),b=d("padding-bottom");return[{path:this.rectToPath({left:r+p+m,top:i+v+x,width:s-p-m-f-y,height:a-v-x-g-b}),fillColor:_(t.contentColor),name:"content"},{path:this.rectToPath({left:r+p,top:i+v,width:s-p-f,height:a-v-g}),fillColor:_(t.paddingColor),name:"padding"},{path:this.rectToPath({left:r,top:i,width:s,height:a}),fillColor:_(t.borderColor),name:"border"},{path:this.rectToPath({left:r-l,top:i-c,width:s+l+u,height:a+c+h}),fillColor:_(t.marginColor),name:"margin"}]}getElementInfo(e){var{width:t,height:n}=e.getBoundingClientRect(),r=e.getAttribute("class")||"";r=r.split(/\s+/).map((e=>"."+e)).join("");var i={tagName:d.default(e.tagName),className:r,idValue:e.id,nodeWidth:t,nodeHeight:n};return this.options.showStyles&&(i.style=this.getStyles(e)),this.options.showAccessibilityInfo&&p.default(i,this.getAccessibilityInfo(e)),i}getStyles(e){for(var t=window.getComputedStyle(e),n=!1,r=e.childNodes,i=0,o=r.length;i<o;i++)3===r[i].nodeType&&(n=!0);var s=[];return n&&s.push("color","font-family","font-size","line-height"),s.push("padding","margin","background-color"),T(t,s)}getAccessibilityInfo(e){return{showAccessibilityInfo:!0,contrast:{contrastAlgorithm:"aa",textOpacity:.1,...T(window.getComputedStyle(e),["font-size","font-weight","background-color","text-opacity"],!0)},isKeyboardFocusable:this.isFocusable(e),...this.getAccessibleNameAndRole(e)}}isFocusable(e){var t=d.default(e.tagName);if(v.default(["a","button","input","textarea","select","details"],t))return!0;var n=e.getAttribute("tabindex");return!!(n&&g.default(n)>-1)}getAccessibleNameAndRole(e){var t=e.getAttribute("labelledby")||e.getAttribute("aria-label"),n=e.getAttribute("role"),r=d.default(e.tagName);return m.default.forEach((t=>{if(!n){var i=t[0],o=t[2];if(i===r){if(o)for(var s of o)if(e.getAttribute(s[0])!==s[1])return;n=t[1]}}})),{accessibleName:t||e.getAttribute("title")||"",accessibleRole:n||"generic"}}bindEvent(){window.addEventListener("resize",this.redraw),window.addEventListener("scroll",this.redraw),this.on("optionChange",(()=>this.redraw()))}rectToPath({left:e,top:t,width:n,height:r}){var i=[];return i.push("M",e,t),i.push("L",e+n,t),i.push("L",e+n,t+r),i.push("L",e,t+r),i.push("Z"),i}}t.default=x,e.exports=x,e.exports.default=x;var b=/^rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$/,w=/^rgba\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3}),\s*(\d*(?:\.\d+)?)\)$/;function _(e){return y.default(e)?e:e.a?`rgba(${e.r}, ${e.g}, ${e.b}, ${e.a})`:`rgb(${e.r}, ${e.g}, ${e.b})`}function T(e,t,n=!1){var r={};return l.default(t,(t=>{var i,o=e["text-opacity"===t?"color":t];o&&(i=o,(b.test(i)||w.test(i))&&(o=function(e){var t=u.default.parse(e),n=t.val[3]||1;return t.val=t.val.slice(0,3),t.val.push(Math.round(255*n)),"#"+h.default(c.default.encode(t.val))}(o),"text-opacity"===t&&(o=o.slice(7),o=c.default.decode(o)[0]/255)),n&&(t=f.default(t)),r[t]=o)})),r}}(st,st.exports);var _r,Tr=(_r=st.exports)&&_r.__esModule&&Object.prototype.hasOwnProperty.call(_r,"default")?_r.default:_r,Sr={exports:{}};!function(e,t){t=function(e){var t=document.createElement("style");return t.textContent=e,t.type="text/css",document.head.appendChild(t),t},e.exports=t}(Sr,Sr.exports);var Er=Sr.exports,Nr={exports:{}};!function(e,t){t=(0,ke.exports)(ct.exports,!0),e.exports=t}(Nr,Nr.exports);var Ir=Nr.exports,Ar={showInfo:!0,showAccessibilityInfo:!0,showStyles:!0,contentColor:{r:111,g:168,b:220,a:.66},paddingColor:{r:147,g:196,b:125,a:.55},borderColor:{r:255,g:229,b:153,a:.66},marginColor:{r:246,g:178,b:107,a:.5},eventTargetColor:{r:255,g:196,b:196,a:.66},shapeColor:{r:96,g:82,b:177,a:.8},shapeMarginColor:{r:96,g:82,b:127,a:.6}};var Mr=new class extends V{constructor(){super(),this.container=document.createElement("div"),this.isInit=!1}init(){Er('.luna-dom-highlighter{position:fixed;left:0;top:0;width:100%;height:100%;z-index:100000;pointer-events:none;font-size:13px}.luna-dom-highlighter-fill{position:absolute;top:0;right:0;bottom:0;left:0}.luna-dom-highlighter-platform-linux{font-family:Roboto,Ubuntu,Arial,sans-serif}.luna-dom-highlighter-platform-mac{color:#303942;font-family:\'.SFNSDisplay-Regular\',\'Helvetica Neue\',\'Lucida Grande\',sans-serif}.luna-dom-highlighter-platform-windows{font-family:\'Segoe UI\',Tahoma,sans-serif}.luna-dom-highlighter-px{color:gray}#luna-dom-highlighter-element-title{position:absolute;z-index:10}.luna-dom-highlighter-tooltip-content{position:absolute;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:#fff;padding:5px 8px;border:1px solid #fff;border-radius:3px;box-sizing:border-box;min-width:100px;max-width:min(300px,100% - 4px);z-index:2;background-clip:padding-box;will-change:transform;text-rendering:optimizeLegibility;pointer-events:none;filter:drop-shadow(0 2px 4px rgba(0,0,0,.35))}.luna-dom-highlighter-tooltip-content .luna-dom-highlighter-tooltip-arrow{background:#fff;width:15px;height:8px;position:absolute}.luna-dom-highlighter-element-info-section{margin-top:12px;margin-bottom:6px}.luna-dom-highlighter-section-name{color:#333;font-weight:500;font-size:10px;text-transform:uppercase;letter-spacing:.05em;line-height:12px}.luna-dom-highlighter-element-info{display:flex;flex-direction:column}.luna-dom-highlighter-element-info-header{display:flex;align-items:center}.luna-dom-highlighter-element-info-body{display:flex;flex-direction:column;padding-top:2px;margin-top:2px}.luna-dom-highlighter-element-info-row{display:flex;line-height:19px}.luna-dom-highlighter-separator-container{display:flex;align-items:center;flex:auto;margin-left:7px}.luna-dom-highlighter-separator{border-top:1px solid #ddd;width:100%}.luna-dom-highlighter-element-info-name{flex-shrink:0;color:#666}.luna-dom-highlighter-element-info-gap{flex:auto}.luna-dom-highlighter-element-info-value-color{display:flex;color:#303942;margin-left:10px;align-items:baseline}.luna-dom-highlighter-a11y-icon{width:16px;height:16px;background-repeat:no-repeat;display:inline-block}.luna-dom-highlighter-element-info-value-contrast{display:flex;align-items:center;text-align:right;color:#303942;margin-left:10px}.luna-dom-highlighter-element-info-value-contrast .luna-dom-highlighter-a11y-icon{margin-left:8px}.luna-dom-highlighter-element-info-value-icon{display:flex;align-items:center}.luna-dom-highlighter-element-info-value-text{text-align:right;color:#303942;margin-left:10px;align-items:baseline;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.luna-dom-highlighter-color-swatch{display:flex;margin-right:2px;width:10px;height:10px;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAIAAADZF8uwAAAAGUlEQVQYV2M4gwH+YwCGIasIUwhT25BVBADtzYNYrHvv4gAAAABJRU5ErkJggg==);line-height:10px}.luna-dom-highlighter-color-swatch-inner{flex:auto;border:1px solid #808002}.luna-dom-highlighter-element-layout-type{margin-right:10px;width:16px;height:16px}.luna-dom-highlighter-element-layout-type.luna-dom-highlighter-grid{background-image:url(\'data:image/svg+xml,<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2.5" y="2.5" width="4" height="4" stroke="%231A73E8"/><rect x="9.5" y="2.5" width="4" height="4" stroke="%231A73E8"/><rect x="9.5" y="9.5" width="4" height="4" stroke="%231A73E8"/><rect x="2.5" y="9.5" width="4" height="4" stroke="%231A73E8"/></svg>\')}.luna-dom-highlighter-element-layout-type.luna-dom-highlighter-flex{background-image:url(\'data:image/svg+xml,<svg fill="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16"><path fill-rule="evenodd" clip-rule="evenodd" d="M1 3.5h8v3H1v-3zm-1 0a1 1 0 011-1h8a1 1 0 011 1v3a1 1 0 01-1 1H1a1 1 0 01-1-1v-3zm12 0h3v3h-3v-3zm-1 0a1 1 0 011-1h3a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-3zm-7 6H1v3h3v-3zm-3-1a1 1 0 00-1 1v3a1 1 0 001 1h3a1 1 0 001-1v-3a1 1 0 00-1-1H1zm6 4v-3h8v3H7zm-1-3a1 1 0 011-1h8a1 1 0 011 1v3a1 1 0 01-1 1H7a1 1 0 01-1-1v-3z" fill="%231A73E8"/></svg>\')}.luna-dom-highlighter-element-description{flex:1 1;font-weight:700;word-wrap:break-word;word-break:break-all}.luna-dom-highlighter-dimensions{color:#737373;text-align:right;margin-left:10px}.luna-dom-highlighter-material-node-width{margin-right:2px}.luna-dom-highlighter-material-node-height{margin-left:2px}.luna-dom-highlighter-material-tag-name{color:#881280}.luna-dom-highlighter-material-class-name,.luna-dom-highlighter-material-node-id{color:#1a1aa6}.luna-dom-highlighter-contrast-text{width:16px;height:16px;text-align:center;line-height:16px;margin-right:8px;border:1px solid #000;padding:0 1px}.luna-dom-highlighter-a11y-icon-not-ok{background-image:url(\'data:image/svg+xml,<svg fill="none" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg"><path d="m9 1.5c-4.14 0-7.5 3.36-7.5 7.5s3.36 7.5 7.5 7.5 7.5-3.36 7.5-7.5-3.36-7.5-7.5-7.5zm0 13.5c-3.315 0-6-2.685-6-6 0-1.3875.4725-2.6625 1.2675-3.675l8.4075 8.4075c-1.0125.795-2.2875 1.2675-3.675 1.2675zm4.7325-2.325-8.4075-8.4075c1.0125-.795 2.2875-1.2675 3.675-1.2675 3.315 0 6 2.685 6 6 0 1.3875-.4725 2.6625-1.2675 3.675z" fill="%239e9e9e"/></svg>\')}.luna-dom-highlighter-a11y-icon-warning{background-image:url(\'data:image/svg+xml,<svg fill="none" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg"><path d="m8.25 11.25h1.5v1.5h-1.5zm0-6h1.5v4.5h-1.5zm.7425-3.75c-4.14 0-7.4925 3.36-7.4925 7.5s3.3525 7.5 7.4925 7.5c4.1475 0 7.5075-3.36 7.5075-7.5s-3.36-7.5-7.5075-7.5zm.0075 13.5c-3.315 0-6-2.685-6-6s2.685-6 6-6 6 2.685 6 6-2.685 6-6 6z" fill="%23e37400"/></svg>\')}.luna-dom-highlighter-a11y-icon-ok{background-image:url(\'data:image/svg+xml,<svg fill="none" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg"><path d="m9 1.5c-4.14 0-7.5 3.36-7.5 7.5s3.36 7.5 7.5 7.5 7.5-3.36 7.5-7.5-3.36-7.5-7.5-7.5zm0 13.5c-3.3075 0-6-2.6925-6-6s2.6925-6 6-6 6 2.6925 6 6-2.6925 6-6 6zm-1.5-4.35-1.95-1.95-1.05 1.05 3 3 6-6-1.05-1.05z" fill="%230ca40c"/></svg>\')}@media (forced-colors:active){:root,body{background-color:transparent;forced-color-adjust:none}.luna-dom-highlighter-tooltip-content{border-color:Highlight;background-color:canvas;color:text;forced-color-adjust:none}.luna-dom-highlighter-tooltip-content::after{background-color:Highlight}.luna-dom-highlighter-color-swatch-inner,.luna-dom-highlighter-contrast-text,.luna-dom-highlighter-separator{border-color:Highlight}.luna-dom-highlighter-section-name{color:Highlight}.luna-dom-highlighter-dimensions,.luna-dom-highlighter-element-info-name,.luna-dom-highlighter-element-info-value-color,.luna-dom-highlighter-element-info-value-contrast,.luna-dom-highlighter-element-info-value-icon,.luna-dom-highlighter-element-info-value-text,.luna-dom-highlighter-material-class-name,.luna-dom-highlighter-material-node-id,.luna-dom-highlighter-material-tag-name{color:canvastext}}\n\n/*# sourceMappingURL=luna-dom-highlighter.css.map*/'),Er(".luna-dom-highlighter {\n    z-index: 2147483647;\n}"),this.domHighlighter=new Tr(this.container),this.domHighlighter.intercept((function(e){e.elementInfo&&(e.elementInfo.tagName=e.elementInfo.tagName.replace(/^wx-/,""))})),this.isInit=!0}show(e,t=Ar){this.isInit||this.init(),Ir(t,{contentColor:"transparent",paddingColor:"transparent",borderColor:"transparent",marginColor:"transparent"}),document.body.appendChild(this.container),this.domHighlighter.highlight(e.$$,t)}hide(){Wt(this.container),this.domHighlighter&&this.domHighlighter.hide()}dom(){return this.container}contain(e){return this.container===e||this.container.contains(e)}},Cr=class extends ie{constructor(){super(...arguments),this.highlight=Mr}enable(){return a(this,void 0,void 0,(function*(){if(!this.tree){var e=this.container.get(p.Props);this.tree=new ot(Object.assign({},e))}this.enabled=!0}))}scrollIntoViewIfNeeded(e){var t;return a(this,void 0,void 0,(function*(){var{nodeId:n,backendNodeId:r,objectId:i,rect:o}=e,s=yield this.getExparserNodeFromParams({nodeId:n,backendNodeId:r,objectId:i});null===(t=s.$$)||void 0===t||t.scrollIntoView()}))}getNodeForLocation(e){return a(this,void 0,void 0,(function*(){var{x:t,y:n}=e;if(!(null===document||void 0===document?void 0:document.elementFromPoint))throw new Error("Method not implemented.");var r=document.elementFromPoint(t,n).__wxElement;if(!r)throw new Error("");var i=this.tree.requestIdForNode(r);return{nodeId:i,backendNodeId:i,frameId:"n/a"}}))}querySelector(e){return a(this,void 0,void 0,(function*(){var{nodeId:t,selector:n}=e,r=yield this.getExparserNodeFromParams({nodeId:t}),i=-1;return r.querySelector(n)&&(i=this.tree.requestIdForNode(r)),{nodeId:i}}))}querySelectorAll(e){return a(this,void 0,void 0,(function*(){var{nodeId:t,selector:n}=e,r=(yield this.getExparserNodeFromParams({nodeId:t})).querySelectorAll(n),i=[];return(null==r?void 0:r.length)&&(i=r.map((e=>this.tree.requestIdForNode(e)))),{nodeIds:i}}))}};Cr=i([(0,r._G)()],Cr);class Or extends re{constructor({exparser:e,root:t,customTabbar:n,getSkylineEngine:r,getWebviewEngine:i,hideVirtual:o=!0}){super({exparser:e,root:t,customTabbar:n,hideVirtual:o}),this.getNodeName=(e,t="")=>{var n,r,i=(null===(r=null===(n=null==e?void 0:e.$$)||void 0===n?void 0:n.GetTagName)||void 0===r?void 0:r.call(n))||e.is||t;return this.isWxComponent(e)?i.slice(3):i},this.getAttributes=e=>{var t,n,r,i,o;this.spreadScopeData();var s=[];if(e.__attributes)for(var a in e.__attributes)this.skippedDOMAttrs.has(a)||null==s||s.push(a,null!==(t=e.__attributes[a])&&void 0!==t?t:"");return!e.__attributes.style&&(null===(n=e.__styleSegments)||void 0===n?void 0:n.length)&&s.push("style",e.__styleSegments.join("")),e.__id&&s.push("id",e.__id),(null===(i=null===(r=e.classList)||void 0===r?void 0:r._rawNames)||void 0===i?void 0:i.length)&&s.push("class",((null===(o=e.classList)||void 0===o?void 0:o._rawNames)||[]).join(" ")||""),e.__component__&&s.push("is",e.is),s},this.removeAttributes=(e,t)=>{"class"===t?e.classList.setClassNames(""):"id"===t?e.id="":"style"===t?e.setNodeStyle(""):e.removeAttribute(t)},this.setAttributeValue=(e,t,n)=>{"class"===t?e.classList.setClassNames(n):"id"===t?e.id=n:"style"===t&&e.setNodeStyle?e.setNodeStyle(n):e.setAttribute(t,n)},this._webviewEngine=i,this._skylineEngine=r}getRoot(){return a(this,void 0,void 0,(function*(){var e=yield this.getPageContextId();return __virtualDOM__.getDomTreeByPageId(e)}))}getPageContext(){return a(this,void 0,void 0,(function*(){var e=yield this.getPageContextId();return this.skylineEngine.getRuntime().allContexts[e]||{}}))}getPageContextId(){return a(this,void 0,void 0,(function*(){return new Promise(((e,t)=>{wx.getCurrentWebviewId({success(t){e(t.webviewId)},fail(){t()}})}))}))}removeNode(e){var t=Object.create(null,{removeNode:{get:()=>super.removeNode}});return a(this,void 0,void 0,(function*(){yield t.removeNode.call(this,e),(yield this.getPageContext()).startRender()}))}getAttributeValue(e,t){for(var n=this.getAttributes(e),r={},i=0;i<n.length;i+=2)r[n[i]]=n[i+1];return r[t]}}var Pr=class extends ie{constructor(){super(...arguments),this.highlight=ee}enable(){return a(this,void 0,void 0,(function*(){if(!this.tree){var e=this.container.get(p.Props);this.tree=new Or(Object.assign({},e))}this.enabled=!0}))}scrollIntoViewIfNeeded(e){var t;return a(this,void 0,void 0,(function*(){var{nodeId:n,backendNodeId:r,objectId:i,rect:o}=e,s=yield this.getExparserNodeFromParams({nodeId:n,backendNodeId:r,objectId:i});null===(t=s.$$)||void 0===t||t.setScrollPosition({scrollLeft:0,scrollTop:10})}))}getNodeForLocation(e){return a(this,void 0,void 0,(function*(){var{x:t,y:n}=e,r=yield this.tree.getPageContext();if(!(null==r?void 0:r.getNodeFromPoint))throw new Error("Method getNodeFromPoint not implemented.");var i=(yield L(r.getNodeFromPoint)([t,n])).__wxElement;if(!i)throw new Error("");var o=this.tree.requestIdForNode(i);return{nodeId:o,backendNodeId:o,frameId:"n/a"}}))}querySelector(e){return a(this,void 0,void 0,(function*(){var{nodeId:t,selector:n}=e;return yield this.getExparserNodeFromParams({nodeId:t}),{nodeId:1e3}}))}querySelectorAll(e){return a(this,void 0,void 0,(function*(){return{nodeIds:[]}}))}};Pr=i([(0,r._G)()],Pr);var Rr=class{constructor(){this.getNodeById=e=>{var t;return null===(t=this.DOMAdapter)||void 0===t?void 0:t.tree.getNodeById(e)}}get enabled(){var e,t;return null!==(t=null===(e=this.DOMAdapter)||void 0===e?void 0:e.enabled)&&void 0!==t&&t}logRemoteObject(e){return a(this,void 0,void 0,(function*(){return console.log(b(e.objectId))}))}setInspectedNode(e){var t;return a(this,void 0,void 0,(function*(){var n=null===(t=this.DOMAdapter)||void 0===t?void 0:t.tree.setInspectedNodeForExparser(e.nodeId);if(n)return{variableName:n};throw new Error("Failed to set inspected node")}))}getNodeData(e){var t;return a(this,void 0,void 0,(function*(){var{nodeId:n}=e,r=this.getNodeById(n);return{data:/^wx-/.test(null!==(t=r.is)&&void 0!==t?t:"")?{}:r.data}}))}getNodeDetails(e){var t,n,r;return a(this,void 0,void 0,(function*(){var{nodeId:i}=e,o=this.getNodeById(i),s={},a={},d={};if(!/^wx-/.test(null!==(t=o.is)&&void 0!==t?t:""))for(var[l,u]of Object.entries(o.data))s[l]=x(u);for(var c of null===(n=this.DOMAdapter)||void 0===n?void 0:n.tree.exparser.Component.listPublicProperties(o))Reflect.has(s,c)||(a[c]=x(o.__dataProxy._data[c]));for(var[h,p]of Object.entries(null!==(r=o.__wxEvents)&&void 0!==r?r:{}))d[h]=x(p);return{data:s,events:d,props:a}}))}disable(){var e;return a(this,void 0,void 0,(function*(){null===(e=this.DOMAdapter)||void 0===e||e.disable()}))}enable(){var e;return a(this,void 0,void 0,(function*(){null===(e=this.DOMAdapter)||void 0===e||e.enable()}))}};i([N("DOM"),(0,r.lq)(),s("design:type",Cr)],Rr.prototype,"DOMAdapter",void 0),Rr=i([(0,r._G)()],Rr);var Dr=class{get enabled(){return this.DOMAdapter.enabled&&this._enabled}disable(){return a(this,void 0,void 0,(function*(){this._enabled=!1}))}enable(){return a(this,void 0,void 0,(function*(){if(!this.DOMAdapter.enabled)throw new Error("Enable DOM first.");this._enabled=!0}))}findExparserNode(e){return a(this,void 0,void 0,(function*(){for(;e&&!e.__wxElement;)e=e.parentNode;if(e){var t,n=e.__wxElement;return exparser.ElementIterator.create(n,"composed-ancestors",exparser.Element).forEach((e=>{var n;if("//"===(null===(n=exparser.Component.getComponentOptions(e))||void 0===n?void 0:n.domain))return t=e,!1})),t}}))}emitInspectNodeRequested(e){return a(this,void 0,void 0,(function*(){if(e){var{tree:t}=this.DOMAdapter,n=t.requestIdForNode(e);this.bridge.emit({method:"Overlay.inspectNodeRequested",params:{backendNodeId:n}})}}))}getHighlightObjectForTest(e){throw new Error("Method not implemented.")}getGridHighlightObjectsForTest(e){throw new Error("Method not implemented.")}getSourceOrderHighlightObjectForTest(e){throw new Error("Method not implemented.")}hideHighlight(){throw new Error("Method not implemented.")}highlightFrame(e){throw new Error("Method not implemented.")}highlightNode(e){throw new Error("Method not implemented.")}highlightQuad(e){throw new Error("Method not implemented.")}highlightRect(e){throw new Error("Method not implemented.")}highlightSourceOrder(e){throw new Error("Method not implemented.")}setInspectMode(e){return a(this,void 0,void 0,(function*(){var{mode:t,highlightConfig:n}=e;switch(t){case"searchForNode":this.startInspect(n);break;case"none":this.stopInspect();break;default:throw new Error("Method not implemented.")}}))}setShowAdHighlights(e){throw new Error("Method not implemented.")}setPausedInDebuggerMessage(e){throw new Error("Method not implemented.")}setShowDebugBorders(e){throw new Error("Method not implemented.")}setShowFPSCounter(e){throw new Error("Method not implemented.")}setShowGridOverlays(e){throw new Error("Method not implemented.")}setShowFlexOverlays(e){throw new Error("Method not implemented.")}setShowScrollSnapOverlays(e){throw new Error("Method not implemented.")}setShowContainerQueryOverlays(e){throw new Error("Method not implemented.")}setShowPaintRects(e){throw new Error("Method not implemented.")}setShowLayoutShiftRegions(e){throw new Error("Method not implemented.")}setShowScrollBottleneckRects(e){throw new Error("Method not implemented.")}setShowHitTestBorders(e){throw new Error("Method not implemented.")}setShowWebVitals(e){throw new Error("Method not implemented.")}setShowViewportSizeOnResize(e){throw new Error("Method not implemented.")}setShowHinge(e){throw new Error("Method not implemented.")}on(e,t){throw new Error("Method not implemented.")}};i([N("DOM"),s("design:type",ie)],Dr.prototype,"DOMAdapter",void 0),i([(0,r.WQ)(c),s("design:type",v)],Dr.prototype,"bridge",void 0),Dr=i([(0,r._G)()],Dr);var kr=class extends Dr{constructor(){super(...arguments),this.highlight=Mr,this.handleClickEvents=e=>a(this,void 0,void 0,(function*(){e.preventDefault(),e.stopPropagation();var{x:t,y:n}=e,r=yield this.hitTest(t,n);if(r)return this.emitInspectNodeRequested(r),!1})),this.handleMouseDownEvents=e=>{document.body.dispatchEvent(new CustomEvent("touchcancel"))},this.handleMouseMoveEvents=e=>a(this,void 0,void 0,(function*(){var{x:t,y:n}=e,r=yield this.hitTest(t,n);if(r){var i=this.DOMAdapter.tree.requestIdForNode(r);this.bridge.emit({method:"Overlay.nodeHighlightRequested",params:{nodeId:i}}),this.highlight.show(r,this.highlightConfig)}}))}hitTest(e,t){return a(this,void 0,void 0,(function*(){document.body.style.pointerEvents="";var n=document.elementFromPoint(e,t),r=n?yield this.findExparserNode(n):null;return document.body.style.pointerEvents="none",r}))}startInspect(e){document.body.style.pointerEvents="none",this.highlightConfig=e,this._handleMouseMoveEvents=k(this.handleMouseMoveEvents.bind(this),100),document.addEventListener("click",this.handleClickEvents),document.addEventListener("mousedown",this.handleMouseDownEvents),document.addEventListener("mousemove",this._handleMouseMoveEvents)}stopInspect(){document.body.style.pointerEvents="",this.highlightConfig=void 0,document.removeEventListener("click",this.handleClickEvents),document.removeEventListener("mousedown",this.handleMouseDownEvents),document.removeEventListener("mousemove",this._handleMouseMoveEvents),this.bridge.emit({method:"Overlay.inspectModeCanceled",params:void 0})}};kr=i([(0,r._G)()],kr);var Lr=class extends Dr{constructor(){super(...arguments),this.highlight=ee,this.handleClickEvents=e=>a(this,void 0,void 0,(function*(){if(e&&!H(e))return this.emitInspectNodeRequested(e),!1}))}hitTest(e,t){return new Promise((n=>a(this,void 0,void 0,(function*(){(yield this.DOMAdapter.tree.getPageContext()).getNodeFromPoint(e,t,(e=>a(this,void 0,void 0,(function*(){var t=e?yield this.findExparserNode(e):null;t=H(t)?null:t,n(t)}))))}))))}handleMouseOverEvents(e){return a(this,void 0,void 0,(function*(){if(e&&!H(e)){var t=this.DOMAdapter.tree.requestIdForNode(e);this.bridge.emit({method:"Overlay.nodeHighlightRequested",params:{nodeId:t}}),yield this.highlight.show(e,this.highlightConfig)}}))}startInspect(e){return a(this,void 0,void 0,(function*(){this.highlightConfig=e,this._handleMouseOverEvents=k(this.handleMouseOverEvents.bind(this),100),this.DOMAdapter.tree.skylineEngine.getRuntime().startTouchEventInterception((e=>{var t=e.target;if(t){var n=t.__wxElement;"tap"===e.type?this.handleClickEvents(n):"mouseover"===e.type&&this._handleMouseOverEvents(n)}}))}))}stopInspect(){return a(this,void 0,void 0,(function*(){this.highlightConfig=void 0;var e=yield this.DOMAdapter.tree.getPageContextId();this.DOMAdapter.tree.skylineEngine.getRuntime().stopTouchEventInterception(e),this.bridge.emit({method:"Overlay.inspectModeCanceled",params:void 0})}))}};Lr=i([(0,r._G)()],Lr);var Br=class{constructor(e){this.fallbackAdapter=new D,this.handler=this.handleCommand.bind(this),this.bridge=e,this.bridge.on("command",this.handler)}destroy(){this.bridge.off("command",this.handler)}handleCommand(e){var t,n;return a(this,void 0,void 0,(function*(){var r,{id:i,method:o,params:s}=e,[a,d]=o.split("."),l=`${a}Adapter`,u=null!==(t=Reflect.get(this,l))&&void 0!==t?t:this.fallbackAdapter;if(u.enabled||"enable"===d)try{r=null!==(n=yield u[d](s))&&void 0!==n?n:{}}catch(e){console.error(`inspectee ${o} error:`,e),r={message:"N/A"}}else r={message:"disabled, enable it first"};this.bridge.reply(i,r)}))}};i([N("CSS"),(0,r.lq)(),s("design:type",se)],Br.prototype,"CSSAdapter",void 0),i([N("DOM"),(0,r.lq)(),s("design:type",Cr)],Br.prototype,"DOMAdapter",void 0),i([N("Misc"),(0,r.lq)(),s("design:type",P)],Br.prototype,"MiscAdapter",void 0),i([N("Runtime"),(0,r.lq)(),s("design:type",T)],Br.prototype,"RuntimeAdapter",void 0),i([N("Overlay"),(0,r.lq)(),s("design:type",Dr)],Br.prototype,"OverlayAdapter",void 0),i([N("Exparser"),(0,r.lq)(),s("design:type",Rr)],Br.prototype,"ExparserAdapter",void 0),i([N(),(0,r.lq)(),s("design:type",Object)],Br.prototype,"fallbackAdapter",void 0),Br=i([(0,r._G)(),o(0,(0,r.WQ)(c)),s("design:paramtypes",[v])],Br);var jr=!1;var Fr=n(4192),Vr=n(1911);class zr{init(){return e=(e,{bindAdapter:t,bindBridge:n,bindVirtualTreeProps:r})=>{n(new Vr.pS(Fr.yK.RendererInspectee)),window.__skylineEngine__?(r({exparser:()=>window.exparser||window.__skylineEngine__.getRuntime().getExparser(),root:()=>window.__DOMTree__,customTabbar:()=>window.__TAB_BAR__,getSkylineEngine:()=>window.__skylineEngine__,getWebviewEngine:()=>window.__webviewEngine__}),t(it,"CSS"),t(Pr,"DOM"),t(Lr,"Overlay")):(r({exparser:()=>window.exparser,root:()=>window.__DOMTree__,customTabbar:()=>window.__TAB_BAR__}),t(tt,"CSS"),t(Cr,"DOM"),t(kr,"Overlay"))},n=()=>{var e=E.get(h);return Reflect.set(globalThis,"wxInspectee",e),e},jr?t?n:n():(jr=!0,E.bind(f).toConstantValue(E),E.bind(h).to(Br).inSingletonScope(),E.bind(u).to(D).whenTargetNamed("default"),M(E,D),e(E,{bindAdapter:O(E,M),getAdapter:O(E,C),bindBridge:O(E,A),bindVirtualTreeProps:O(E,I)}),t?(t(n),n):n());var e,t,n}waitReady(){var e=null;return new Promise((t=>{e=setInterval((()=>{window.__DOMTree__&&(window.exparser||window.__skylineEngine__.getRuntime().getExparser())&&(clearInterval(e),t())}),100)}))}}},3521:(e,t,n)=>{"use strict";n.r(t),n.d(t,{Inspector:()=>_});var r=n(4515),i=n.n(r),o=(n(2803),n(4192)),s=n(1911),a=n(2993);function d(e,t,n,r){return new(n||(n=Promise))((function(i,o){function s(e){try{d(r.next(e))}catch(e){o(e)}}function a(e){try{d(r.throw(e))}catch(e){o(e)}}function d(e){var t;e.done?i(e.value):(t=e.value,t instanceof n?t:new n((function(e){e(t)}))).then(s,a)}d((r=r.apply(e,t||[])).next())}))}var l,u=()=>{};class c{constructor(e={}){this.resolve=u,this.reject=u,this.promise=new Promise(((t,n)=>{this.resolve=t,this.reject=n;var{timeout:r}=e;r&&setTimeout((()=>n("timeout")),r)}))}}class h extends Map{get(e){var t=super.get(e);return t&&super.delete(e),t}}!function(e){e[e.Inspector=0]="Inspector",e[e.RendererInspectee=1]="RendererInspectee",e[e.ServiceInspectee=2]="ServiceInspectee",e[e.AllInspectee=3]="AllInspectee"}(l||(l={}));var p,f=class{constructor(e=l.AllInspectee){this.callbacks=new Map,this.type=e}get inited(){return this._inited}init(){this.initSubscription(this.handleCDPMessage.bind(this)),this._inited=!0}emit(e){this.send(e)}reply(e,t){this.send({id:e,result:t})}on(e,t){this.callbacks.has(e)||this.callbacks.set(e,[]),this.callbacks.get(e).push(t)}off(e,t){if(this.callbacks.has(e)){var n=this.callbacks.get(e);n=[...n.filter((e=>e!==t))]}}handleCDPMessage(e,t,n){var r,i,o,s,a;((s=this.type)===(a=t)||s&a)&&("id"in e?null===(r=this.callbacks.get("command"))||void 0===r||r.forEach((t=>t(e,n))):null===(i=this.callbacks.get("event"))||void 0===i||i.forEach((t=>t(e,n))),null===(o=this.callbacks.get("all"))||void 0===o||o.forEach((t=>t(e,n))))}};f=function(e,t,n,r){var i,o=arguments.length,s=o<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(i=e[a])&&(s=(o<3?i(s):o>3?i(t,n,s):i(t,n))||s);return o>3&&s&&Object.defineProperty(t,n,s),s}([(0,a._G)(),function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)}("design:paramtypes",[Number])],f);class v{constructor(e,t,n){this.cachedObject={},this.inspector=t,this.object=e,this.target=n}getProperties(e={}){return d(this,void 0,void 0,(function*(){var{objectId:t}=this.object;if(t){var{result:n}=yield this.inspector.request({method:"Runtime.getProperties",params:Object.assign({objectId:t},e)},this.target);return n}return[]}))}}var g,m,y=p=class{constructor(e){this.requestMap=new h,this.eventHandlersMap=new Map,this._handleEvent=this.handleEvent.bind(this),this._handleCommand=this.handleCommand.bind(this),this.bridge=e,this.init()}init(){console.debug(this.bridge),this.bridge.on("event",this._handleEvent),this.bridge.on("command",this._handleCommand)}destroy(){this.bridge.off("event",this._handleEvent),this.bridge.off("command",this._handleCommand)}enable(e,t=l.AllInspectee){return this.request({method:`${e}.enable`,params:{}},t)}request(e,t=l.AllInspectee){return d(this,void 0,void 0,(function*(){var{id:n}=p.idAssigner,r=new c;return this.requestMap.set(n,r),this.bridge.send(Object.assign({id:n},e),t),r.promise}))}handleCommand(e){var{id:t,result:n}=e,r=this.requestMap.get(t);r&&(n?r.resolve(n):r.reject("protocol error"))}handleEvent(e,t){var{method:n}=e,r=this.eventHandlersMap.get(n);r&&r.forEach((n=>n(e,t)))}addListener(e,t,n){var r;this.eventHandlersMap.has(e)||this.eventHandlersMap.set(e,[]);var i=void 0===n?t:(e,r)=>r===n&&t(e,r);null===(r=this.eventHandlersMap.get(e))||void 0===r||r.push(i)}removeListener(e,t){var n=this.eventHandlersMap.get(e);n&&this.eventHandlersMap.set(e,t?n.filter((e=>e!==t)):[])}listenUntil(e,t,n){var r;this.eventHandlersMap.has(e)||this.eventHandlersMap.set(e,[]);null===(r=this.eventHandlersMap.get(e))||void 0===r||r.push(((r,i)=>{n&&i!==n||t(r,i)&&this.removeListener(e,t)}))}parseRemoteObject(e,t){return new v(e,this,t)}logToInspectee(e=l.AllInspectee,...t){var n=JSON.stringify(t);this.request({method:"Runtime.evaluate",params:{expression:`(console.log(...${n}))`}},e)}};y.idAssigner=new class{constructor(e=0){this._id=e}get id(){return this._id++}reset(){this._id=0}},y=p=function(e,t,n,r){var i,o=arguments.length,s=o<3?t:null===r?r=Object.getOwnPropertyDescriptor(t,n):r;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)s=Reflect.decorate(e,t,n,r);else for(var a=e.length-1;a>=0;a--)(i=e[a])&&(s=(o<3?i(s):o>3?i(t,n,s):i(t,n))||s);return o>3&&s&&Object.defineProperty(t,n,s),s}([(0,a._G)(),(g=0,m=(0,a.WQ)("Bridge"),function(e,t){m(e,t,g)}),function(e,t){if("object"==typeof Reflect&&"function"==typeof Reflect.metadata)return Reflect.metadata(e,t)}("design:paramtypes",[f])],y);var x={Adapter:"Adapter",Bridge:"Bridge",Inspectee:"Inspectee",Inspector:"Inspector",VirtualTree:{Props:"VirtualTreeProps"},HighLight:"HighLight",Container:"Container"};Map;var b=n(1278),w={Container:Symbol("Container")};class _{constructor({inspectee:e}){this._ready=!1,this._lastActiveId=null,this._inspectee=e,this._inspector=null}get debuggee(){return{targetId:window.__webviewId__}}init(){var e=this;return i()((function*(){e._inspector=e.initWxInspector(),e.addEventListeners(),e.bindHandlers(),e.initMessager(),e._ready=!0,yield e.enableDomains(),b.makeReady(),console.log("remote-debug inited")}))()}initWxInspector(){var e=new a.mc({skipBaseClassChecks:!0}),t=new s.pS(o.yK.Inspector);e.bind(w.Container).toConstantValue(e),e.bind(x.Bridge).toConstantValue(t),e.bind(x.Inspector).to(y).inSingletonScope();var n=e.get(x.Inspector);return Reflect.set(globalThis,"wxInspector",n),n}bindHandlers(){this._customMethodMap={"DOM.getDocument":"getDocument"}}addEventListeners(){["DOM.attributeRemoved","DOM.attributeModified","DOM.characterDataModified","DOM.childNodeInserted","DOM.childNodeRemoved","DOM.documentUpdated","DOM.setChildNodes","Overlay.inspectNodeRequested","Overlay.nodeHighlightRequested","WxHost.setWxssFile","WxComponent.componentDataChanged"].forEach((e=>{this._inspector.addListener(e,(({method:t,params:n})=>{this._ready&&(e.startsWith("WxHost.")?this.triggerHostEvent(t,n):this.triggerDebugeeEvent(t,n))}))}))}initMessager(){b.subscribe("remoteDebugCommand",(e=>{this.exec(e)}))}triggerDebugeeEvent(e,t){b.send({command:"DEBUGGEE_EVENT",data:{debuggee:this.debuggee,method:e,params:t}})}triggerHostEvent(e,t){b.send({command:"HOST_EVENT",data:{debuggee:this.debuggee,method:e,params:t}})}enableDomains(){var e=this;return i()((function*(){for(var t of["DOM","CSS","Overlay"])yield e._inspector.enable(t,o.yK.RendererInspectee)}))()}getDocument(e,t){var n=this;return i()((function*(){var{root:r}=yield n._inspector.request({method:e,params:t},o.yK.RendererInspectee);return{baseURL:"https://servicewechat.com/page-frame.html",inspectee:"exparser",root:r}}))()}commonCDPCall(e,t){var n=this;return i()((function*(){return yield n._inspector.request({method:e,params:t},o.yK.RendererInspectee)}))()}exec(e){var t=this;return i()((function*(){if(t._ready){var n,r=t._customMethodMap[e.method];n="function"==typeof t[r]?yield t[r](e.method,e.commandParams):yield t.commonCDPCall(e.method,e.commandParams),e.callbackID&&n&&b.send({command:"DEBUGGEE_CALLBACK",callbackID:e.callbackID,data:n})}}))()}}},1278:e=>{e.exports=new class{constructor(){this.isReady=!1,this.bridge=window.wx||__global.WeixinJSBridge,this.handles=[]}makeReady(){this.isReady=!0,this.handles.forEach((e=>e())),this.handles=[]}send(e){this.bridge.invoke("remoteDebugInfo",e,(()=>{}))}invoke(e,t,n){this.bridge.invoke(e,t,n)}subscribe(e,t){this.bridge.on(e,((...e)=>{this.isReady?t&&t(...e):this.handles.push((()=>{t&&t(...e)}))}))}}}},t={};function n(r){var i=t[r];if(void 0!==i)return i.exports;var o=t[r]={exports:{}};return e[r](o,o.exports,n),o.exports}n.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return n.d(t,{a:t}),t},n.d=(e,t)=>{for(var r in t)n.o(t,r)&&!n.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},n.g=function(){if("object"==typeof globalThis)return globalThis;try{return this||new Function("return this")()}catch(e){if("object"==typeof window)return window}}(),n.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),n.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var r=n(4515).default,{Inspector:i}=n(3521),{Inspectee:o}=n(9379);(Reflect.has(globalThis,"__wxConfig")&&__wxConfig.onReady?__wxConfig.onReady:setTimeout)(r((function*(){var e=new o,t=new i({inspectee:e});t.initMessager(),yield e.waitReady(),e.init(),t.init()})))})();var WARemoteDebugVersion="2024.9.24 19:43";
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 515:
/***/ ((module) => {

function asyncGeneratorStep(n, t, e, r, o, a, c) {
  try {
    var i = n[a](c),
      u = i.value;
  } catch (n) {
    return void e(n);
  }
  i.done ? t(u) : Promise.resolve(u).then(r, o);
}
function _asyncToGenerator(n) {
  return function () {
    var t = this,
      e = arguments;
    return new Promise(function (r, o) {
      var a = n.apply(t, e);
      function _next(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
      }
      function _throw(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
      }
      _next(void 0);
    });
  };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 374:
/***/ ((module, exports, __webpack_require__) => {

var keys = __webpack_require__(157);
var getProto = __webpack_require__(452);
var unique = __webpack_require__(138);
var getOwnPropertyNames = Object.getOwnPropertyNames;
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
exports = function (obj) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    _ref$prototype = _ref.prototype,
    prototype = _ref$prototype === void 0 ? true : _ref$prototype,
    _ref$unenumerable = _ref.unenumerable,
    unenumerable = _ref$unenumerable === void 0 ? false : _ref$unenumerable,
    _ref$symbol = _ref.symbol,
    symbol = _ref$symbol === void 0 ? false : _ref$symbol;
  var ret = [];
  if ((unenumerable || symbol) && getOwnPropertyNames) {
    var getKeys = keys;
    if (unenumerable && getOwnPropertyNames) getKeys = getOwnPropertyNames;
    do {
      ret = ret.concat(getKeys(obj));
      if (symbol && getOwnPropertySymbols) {
        ret = ret.concat(getOwnPropertySymbols(obj));
      }
    } while (prototype && (obj = getProto(obj)) && obj !== Object.prototype);
    ret = unique(ret);
  } else {
    if (prototype) {
      for (var key in obj) {
        ret.push(key);
      }
    } else {
      ret = keys(obj);
    }
  }
  return ret;
};
module.exports = exports;

/***/ }),

/***/ 81:
/***/ ((module, exports, __webpack_require__) => {

var has = __webpack_require__(745);
var isArr = __webpack_require__(362);
exports = function (str, obj) {
  if (isArr(str)) return str;
  if (obj && has(obj, str)) return [str];
  var ret = [];
  str.replace(regPropName, function (match, number, quote, str) {
    ret.push(quote ? str.replace(regEscapeChar, '$1') : number || match);
  });
  return ret;
};
var regPropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
var regEscapeChar = /\\(\\)?/g;
module.exports = exports;

/***/ }),

/***/ 71:
/***/ ((module, exports, __webpack_require__) => {

var isUndef = __webpack_require__(375);
var each = __webpack_require__(680);
exports = function (keysFn, defaults) {
  return function (obj) {
    each(arguments, function (src, idx) {
      if (idx === 0) return;
      var keys = keysFn(src);
      each(keys, function (key) {
        if (!defaults || isUndef(obj[key])) obj[key] = src[key];
      });
    });
    return obj;
  };
};
module.exports = exports;

/***/ }),

/***/ 655:
/***/ ((module, exports, __webpack_require__) => {

var createAssigner = __webpack_require__(71);
var allKeys = __webpack_require__(374);
exports = createAssigner(allKeys, true);
module.exports = exports;

/***/ }),

/***/ 680:
/***/ ((module, exports, __webpack_require__) => {

var isArrLike = __webpack_require__(421);
var keys = __webpack_require__(157);
var optimizeCb = __webpack_require__(775);
exports = function (obj, iterator, ctx) {
  iterator = optimizeCb(iterator, ctx);
  var i, len;
  if (isArrLike(obj)) {
    for (i = 0, len = obj.length; i < len; i++) {
      iterator(obj[i], i, obj);
    }
  } else {
    var _keys = keys(obj);
    for (i = 0, len = _keys.length; i < len; i++) {
      iterator(obj[_keys[i]], _keys[i], obj);
    }
  }
  return obj;
};
module.exports = exports;

/***/ }),

/***/ 189:
/***/ ((module, exports, __webpack_require__) => {

var keys = __webpack_require__(157);
var createAssigner = __webpack_require__(71);
exports = createAssigner(keys);
module.exports = exports;

/***/ }),

/***/ 151:
/***/ ((module, exports, __webpack_require__) => {

var safeCb = __webpack_require__(361);
var each = __webpack_require__(680);
exports = function (obj, predicate, ctx) {
  var ret = [];
  predicate = safeCb(predicate, ctx);
  each(obj, function (val, idx, list) {
    if (predicate(val, idx, list)) ret.push(val);
  });
  return ret;
};
module.exports = exports;

/***/ }),

/***/ 452:
/***/ ((module, exports, __webpack_require__) => {

var isObj = __webpack_require__(540);
var isFn = __webpack_require__(377);
var getPrototypeOf = Object.getPrototypeOf;
var ObjectCtr = {}.constructor;
exports = function (obj) {
  if (!isObj(obj)) return;
  if (getPrototypeOf && !false) return getPrototypeOf(obj);
  var proto = obj.__proto__;
  if (proto || proto === null) return proto;
  if (isFn(obj.constructor)) return obj.constructor.prototype;
  if (obj instanceof ObjectCtr) return ObjectCtr.prototype;
};
module.exports = exports;

/***/ }),

/***/ 745:
/***/ ((module, exports) => {

var hasOwnProp = Object.prototype.hasOwnProperty;
exports = function (obj, key) {
  return hasOwnProp.call(obj, key);
};
module.exports = exports;

/***/ }),

/***/ 995:
/***/ ((module, exports) => {

exports = function (val) {
  return val;
};
module.exports = exports;

/***/ }),

/***/ 568:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(762);
exports = function (val) {
  return objToStr(val) === '[object Arguments]';
};
module.exports = exports;

/***/ }),

/***/ 362:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(762);
if (Array.isArray && !false) {
  exports = Array.isArray;
} else {
  exports = function (val) {
    return objToStr(val) === '[object Array]';
  };
}
module.exports = exports;

/***/ }),

/***/ 421:
/***/ ((module, exports, __webpack_require__) => {

var isNum = __webpack_require__(605);
var isFn = __webpack_require__(377);
var MAX_ARR_IDX = Math.pow(2, 53) - 1;
exports = function (val) {
  if (!val) return false;
  var len = val.length;
  return isNum(len) && len >= 0 && len <= MAX_ARR_IDX && !isFn(val);
};
module.exports = exports;

/***/ }),

/***/ 777:
/***/ ((module, exports) => {

exports = typeof window === 'object' && typeof document === 'object' && document.nodeType === 9;
module.exports = exports;

/***/ }),

/***/ 100:
/***/ ((module, exports, __webpack_require__) => {

var isArrLike = __webpack_require__(421);
var isArr = __webpack_require__(362);
var isStr = __webpack_require__(366);
var isArgs = __webpack_require__(568);
var keys = __webpack_require__(157);
exports = function (val) {
  if (val == null) return true;
  if (isArrLike(val) && (isArr(val) || isStr(val) || isArgs(val))) {
    return val.length === 0;
  }
  return keys(val).length === 0;
};
module.exports = exports;

/***/ }),

/***/ 377:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(762);
exports = function (val) {
  var objStr = objToStr(val);
  return objStr === '[object Function]' || objStr === '[object GeneratorFunction]' || objStr === '[object AsyncFunction]';
};
module.exports = exports;

/***/ }),

/***/ 32:
/***/ ((module, exports, __webpack_require__) => {

var keys = __webpack_require__(157);
exports = function (obj, src) {
  var _keys = keys(src);
  var len = _keys.length;
  if (obj == null) return !len;
  obj = Object(obj);
  for (var i = 0; i < len; i++) {
    var key = _keys[i];
    if (src[key] !== obj[key] || !(key in obj)) return false;
  }
  return true;
};
module.exports = exports;

/***/ }),

/***/ 9:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(762);
exports = typeof process !== 'undefined' && objToStr(process) === '[object process]';
module.exports = exports;

/***/ }),

/***/ 605:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(762);
exports = function (val) {
  return objToStr(val) === '[object Number]';
};
module.exports = exports;

/***/ }),

/***/ 540:
/***/ ((module, exports) => {

exports = function (val) {
  var type = typeof val;
  return !!val && (type === 'function' || type === 'object');
};
module.exports = exports;

/***/ }),

/***/ 366:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(762);
exports = function (val) {
  return objToStr(val) === '[object String]';
};
module.exports = exports;

/***/ }),

/***/ 375:
/***/ ((module, exports) => {

exports = function (val) {
  return val === void 0;
};
module.exports = exports;

/***/ }),

/***/ 157:
/***/ ((module, exports, __webpack_require__) => {

var has = __webpack_require__(745);
if (Object.keys && !false) {
  exports = Object.keys;
} else {
  exports = function (obj) {
    var ret = [];
    for (var key in obj) {
      if (has(obj, key)) ret.push(key);
    }
    return ret;
  };
}
module.exports = exports;

/***/ }),

/***/ 937:
/***/ ((module, exports) => {

var regSpace = /^\s+/;
exports = function (str, chars) {
  if (chars == null) return str.replace(regSpace, '');
  var start = 0;
  var len = str.length;
  var charLen = chars.length;
  var found = true;
  var i;
  var c;
  while (found && start < len) {
    found = false;
    i = -1;
    c = str.charAt(start);
    while (++i < charLen) {
      if (c === chars[i]) {
        found = true;
        start++;
        break;
      }
    }
  }
  return start >= len ? '' : str.substr(start, len);
};
module.exports = exports;

/***/ }),

/***/ 735:
/***/ ((module, exports, __webpack_require__) => {

var safeCb = __webpack_require__(361);
var keys = __webpack_require__(157);
var isArrLike = __webpack_require__(421);
exports = function (obj, iterator, ctx) {
  iterator = safeCb(iterator, ctx);
  var _keys = !isArrLike(obj) && keys(obj);
  var len = (_keys || obj).length;
  var results = Array(len);
  for (var i = 0; i < len; i++) {
    var curKey = _keys ? _keys[i] : i;
    results[i] = iterator(obj[curKey], curKey, obj);
  }
  return results;
};
module.exports = exports;

/***/ }),

/***/ 667:
/***/ ((module, exports, __webpack_require__) => {

var extendOwn = __webpack_require__(189);
var isMatch = __webpack_require__(32);
exports = function (attrs) {
  attrs = extendOwn({}, attrs);
  return function (obj) {
    return isMatch(obj, attrs);
  };
};
module.exports = exports;

/***/ }),

/***/ 761:
/***/ ((module, exports) => {

if (Date.now && !false) {
  exports = Date.now;
} else {
  exports = function () {
    return new Date().getTime();
  };
}
module.exports = exports;

/***/ }),

/***/ 762:
/***/ ((module, exports) => {

var ObjToStr = Object.prototype.toString;
exports = function (val) {
  return ObjToStr.call(val);
};
module.exports = exports;

/***/ }),

/***/ 775:
/***/ ((module, exports, __webpack_require__) => {

var isUndef = __webpack_require__(375);
exports = function (fn, ctx, argCount) {
  if (isUndef(ctx)) return fn;
  switch (argCount == null ? 3 : argCount) {
    case 1:
      return function (val) {
        return fn.call(ctx, val);
      };
    case 3:
      return function (val, idx, collection) {
        return fn.call(ctx, val, idx, collection);
      };
    case 4:
      return function (accumulator, val, idx, collection) {
        return fn.call(ctx, accumulator, val, idx, collection);
      };
  }
  return function () {
    return fn.apply(ctx, arguments);
  };
};
module.exports = exports;

/***/ }),

/***/ 200:
/***/ ((module, exports, __webpack_require__) => {

var isArr = __webpack_require__(362);
var safeGet = __webpack_require__(150);
exports = function (path) {
  if (!isArr(path)) return shallowProperty(path);
  return function (obj) {
    return safeGet(obj, path);
  };
};
function shallowProperty(key) {
  return function (obj) {
    return obj == null ? void 0 : obj[key];
  };
}
module.exports = exports;

/***/ }),

/***/ 2:
/***/ ((module, exports) => {

exports = function (min, max, floating) {
  if (max == null) {
    max = min;
    min = 0;
  }
  var rand = Math.random();
  if (floating || min % 1 || max % 1) {
    return Math.min(min + rand * (max - min + parseFloat('1e-' + ((rand + '').length - 1))), max);
  }
  return min + Math.floor(rand * (max - min + 1));
};
module.exports = exports;

/***/ }),

/***/ 463:
/***/ ((module, exports, __webpack_require__) => {

var random = __webpack_require__(2);
var isBrowser = __webpack_require__(777);
var isNode = __webpack_require__(9);
exports = function (size) {
  var ret = new Uint8Array(size);
  for (var i = 0; i < size; i++) {
    ret[i] = random(0, 255);
  }
  return ret;
};
var crypto;
if (isBrowser) {
  crypto = window.crypto || window.msCrypto;
  if (crypto) {
    exports = function (size) {
      var ret = new Uint8Array(size);
      crypto.getRandomValues(ret);
      return ret;
    };
  }
} else if (isNode) {
  crypto = eval('require')('crypto');
  exports = function (size) {
    return crypto.randomBytes(size);
  };
}
module.exports = exports;

/***/ }),

/***/ 327:
/***/ ((module, exports) => {

var regSpace = /\s+$/;
exports = function (str, chars) {
  if (chars == null) return str.replace(regSpace, '');
  var end = str.length - 1;
  var charLen = chars.length;
  var found = true;
  var i;
  var c;
  while (found && end >= 0) {
    found = false;
    i = -1;
    c = str.charAt(end);
    while (++i < charLen) {
      if (c === chars[i]) {
        found = true;
        end--;
        break;
      }
    }
  }
  return end >= 0 ? str.substring(0, end + 1) : '';
};
module.exports = exports;

/***/ }),

/***/ 361:
/***/ ((module, exports, __webpack_require__) => {

var isFn = __webpack_require__(377);
var isObj = __webpack_require__(540);
var isArr = __webpack_require__(362);
var optimizeCb = __webpack_require__(775);
var matcher = __webpack_require__(667);
var identity = __webpack_require__(995);
var property = __webpack_require__(200);
exports = function (val, ctx, argCount) {
  if (val == null) return identity;
  if (isFn(val)) return optimizeCb(val, ctx, argCount);
  if (isObj(val) && !isArr(val)) return matcher(val);
  return property(val);
};
module.exports = exports;

/***/ }),

/***/ 150:
/***/ ((module, exports, __webpack_require__) => {

var isUndef = __webpack_require__(375);
var castPath = __webpack_require__(81);
exports = function (obj, path) {
  path = castPath(path, obj);
  var prop;
  prop = path.shift();
  while (!isUndef(prop)) {
    obj = obj[prop];
    if (obj == null) return;
    prop = path.shift();
  }
  return obj;
};
module.exports = exports;

/***/ }),

/***/ 896:
/***/ ((module, exports, __webpack_require__) => {

var trim = __webpack_require__(833);
var each = __webpack_require__(680);
var identity = __webpack_require__(995);
var map = __webpack_require__(735);
var whitespace = '[\\x20\\t\\r\\n\\f]';
var identifier = '(?:\\\\[\\da-fA-F]{1,6}'.concat(whitespace, '?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+');
var attributes = '\\['.concat(whitespace, '*(').concat(identifier, ')(?:').concat(whitespace, '*([*^$|!~]?=)').concat(whitespace, '*(?:\'((?:\\\\.|[^\\\\\'])*)\'|"((?:\\\\.|[^\\\\"])*)"|(').concat(identifier, '))|)').concat(whitespace, '*\\]');
var pseudos = '::?('.concat(identifier, ')(?:\\(((\'((?:\\\\.|[^\\\\\'])*)\'|"((?:\\\\.|[^\\\\"])*)")|((?:\\\\.|[^\\\\()[\\]]|').concat(attributes, ')*)|.*)\\)|)');
var regComma = new RegExp('^'.concat(whitespace, '*,').concat(whitespace, '*'));
var regCombinators = new RegExp('^'.concat(whitespace, '*([>+~]|').concat(whitespace, ')').concat(whitespace, '*'));
var matchExpr = {
  id: {
    reg: new RegExp('^#('.concat(identifier, ')')),
    value: function (raw) {
      return raw.slice(1);
    },
    toStr: function (value) {
      return '#'.concat(value);
    }
  },
  class: {
    reg: new RegExp('^\\.('.concat(identifier, ')')),
    value: function (raw) {
      return raw.slice(1);
    },
    toStr: function (value) {
      return '.'.concat(value);
    }
  },
  tag: {
    reg: new RegExp('^('.concat(identifier, '|[*])')),
    value: identity
  },
  attribute: {
    reg: new RegExp('^'.concat(attributes)),
    value: function (raw) {
      return raw.slice(1, raw.length - 1);
    },
    toStr: function (value) {
      return '['.concat(value, ']');
    }
  },
  pseudo: {
    reg: new RegExp('^'.concat(pseudos)),
    value: identity
  }
};
each(matchExpr, function (item) {
  if (!item.value) item.value = identity;
  if (!item.toStr) item.toStr = identity;
});
function parse(selector) {
  selector = trim(selector);
  var groups = [];
  var tokens;
  var match;
  var matched;
  while (selector) {
    if (!matched || (match = regComma.exec(selector))) {
      if (match) {
        selector = selector.slice(match[0].length);
      }
      tokens = [];
      groups.push(tokens);
    }
    matched = false;
    if (match = regCombinators.exec(selector)) {
      matched = match.shift();
      selector = selector.slice(matched.length);
      matched = trim(matched);
      if (!matched) matched = ' ';
      tokens.push({
        value: matched,
        type: 'combinator'
      });
    }
    each(matchExpr, function (_ref, type) {
      var reg = _ref.reg,
        value = _ref.value;
      if (match = reg.exec(selector)) {
        matched = match.shift();
        selector = selector.slice(matched.length);
        matched = trim(matched);
        tokens.push({
          value: value(matched),
          type: type
        });
      }
    });
    if (!matched) {
      break;
    }
  }
  return groups;
}
function stringify(groups) {
  return map(groups, function (group) {
    group = map(group, function (_ref2) {
      var type = _ref2.type,
        value = _ref2.value;
      if (type === 'combinator') {
        return value === ' ' ? value : ' '.concat(value, ' ');
      }
      return matchExpr[type].toStr(value);
    });
    return group.join('');
  }).join(', ');
}
exports = {
  parse: parse,
  stringify: stringify
};
module.exports = exports;

/***/ }),

/***/ 629:
/***/ ((module, exports) => {

exports = function (str, prefix) {
  return str.indexOf(prefix) === 0;
};
module.exports = exports;

/***/ }),

/***/ 149:
/***/ ((module, exports, __webpack_require__) => {

var isArrLike = __webpack_require__(421);
var map = __webpack_require__(735);
var isArr = __webpack_require__(362);
var isStr = __webpack_require__(366);
exports = function (val) {
  if (!val) return [];
  if (isArr(val)) return val;
  if (isArrLike(val) && !isStr(val)) return map(val);
  return [val];
};
module.exports = exports;

/***/ }),

/***/ 833:
/***/ ((module, exports, __webpack_require__) => {

var ltrim = __webpack_require__(937);
var rtrim = __webpack_require__(327);
var regSpace = /^\s+|\s+$/g;
exports = function (str, chars) {
  if (chars == null) return str.replace(regSpace, '');
  return ltrim(rtrim(str, chars), chars);
};
module.exports = exports;

/***/ }),

/***/ 138:
/***/ ((module, exports, __webpack_require__) => {

var filter = __webpack_require__(151);
exports = function (arr, cmp) {
  cmp = cmp || isEqual;
  return filter(arr, function (item, idx, arr) {
    var len = arr.length;
    while (++idx < len) {
      if (cmp(item, arr[idx])) return false;
    }
    return true;
  });
};
function isEqual(a, b) {
  return a === b;
}
module.exports = exports;

/***/ }),

/***/ 506:
/***/ ((module, exports, __webpack_require__) => {

var randomBytes = __webpack_require__(463);
exports = function () {
  var b = randomBytes(16);
  b[6] = b[6] & 0x0f | 0x40;
  b[8] = b[8] & 0x3f | 0x80;
  return hexBytes[b[0]] + hexBytes[b[1]] + hexBytes[b[2]] + hexBytes[b[3]] + '-' + hexBytes[b[4]] + hexBytes[b[5]] + '-' + hexBytes[b[6]] + hexBytes[b[7]] + '-' + hexBytes[b[8]] + hexBytes[b[9]] + '-' + hexBytes[b[10]] + hexBytes[b[11]] + hexBytes[b[12]] + hexBytes[b[13]] + hexBytes[b[14]] + hexBytes[b[15]];
};
var hexBytes = [];
for (var i = 0; i < 256; i++) {
  hexBytes[i] = (i + 0x100).toString(16).substr(1);
}
module.exports = exports;

/***/ }),

/***/ 446:
/***/ ((module, exports, __webpack_require__) => {

var now = __webpack_require__(761);
exports = function (condition) {
  var timeout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var interval = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 250;
  function evalCondition() {
    return new Promise(function (resolve, reject) {
      try {
        resolve(condition());
      } catch (e) {
        reject(e);
      }
    });
  }
  return new Promise(function (resolve, reject) {
    var startTime = now();
    var pollCondition = function () {
      evalCondition().then(function (val) {
        var elapsed = now() - startTime;
        if (val) {
          resolve(val);
        } else if (timeout && elapsed >= timeout) {
          reject(Error('Wait timed out after '.concat(timeout, ' ms')));
        } else {
          setTimeout(pollCondition, interval);
        }
      }, reject);
    };
    pollCondition();
  });
};
module.exports = exports;

/***/ }),

/***/ 233:
/***/ ((__unused_webpack_module, exports) => {

var xpath =  false ? 0 : exports;
(function (exports) {
  "use strict";
  function curry(func) {
    var slice = Array.prototype.slice,
      totalargs = func.length,
      partial = function (args, fn) {
        return function () {
          return fn.apply(this, args.concat(slice.call(arguments)));
        };
      },
      fn = function () {
        var args = slice.call(arguments);
        return args.length < totalargs ? partial(args, fn) : func.apply(this, slice.apply(arguments, [0, totalargs]));
      };
    return fn;
  }
  var forEach = function (f, xs) {
    for (var i = 0; i < xs.length; i += 1) {
      f(xs[i], i, xs);
    }
  };
  var reduce = function (f, seed, xs) {
    var acc = seed;
    forEach(function (x, i) {
      acc = f(acc, x, i);
    }, xs);
    return acc;
  };
  var map = function (f, xs) {
    var mapped = new Array(xs.length);
    forEach(function (x, i) {
      mapped[i] = f(x);
    }, xs);
    return mapped;
  };
  var filter = function (f, xs) {
    var filtered = [];
    forEach(function (x, i) {
      if (f(x, i)) {
        filtered.push(x);
      }
    }, xs);
    return filtered;
  };
  var includes = function (values, value) {
    for (var i = 0; i < values.length; i += 1) {
      if (values[i] === value) {
        return true;
      }
    }
    return false;
  };
  function always(value) {
    return function () {
      return value;
    };
  }
  function toString(x) {
    return x.toString();
  }
  var join = function (s, xs) {
    return xs.join(s);
  };
  var wrap = function (pref, suf, str) {
    return pref + str + suf;
  };
  var prototypeConcat = Array.prototype.concat;
  var MAX_ARGUMENT_LENGTH = 32767;
  function flatten(arr) {
    var result = [];
    for (var start = 0; start < arr.length; start += MAX_ARGUMENT_LENGTH) {
      var chunk = arr.slice(start, start + MAX_ARGUMENT_LENGTH);
      result = prototypeConcat.apply(result, chunk);
    }
    return result;
  }
  function assign(target, varArgs) {
    var to = Object(target);
    for (var index = 1; index < arguments.length; index++) {
      var nextSource = arguments[index];
      if (nextSource != null) {
        for (var nextKey in nextSource) {
          if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
            to[nextKey] = nextSource[nextKey];
          }
        }
      }
    }
    return to;
  }
  XPathParser.prototype = new Object();
  XPathParser.prototype.constructor = XPathParser;
  XPathParser.superclass = Object.prototype;
  function XPathParser() {
    this.init();
  }
  XPathParser.prototype.init = function () {
    this.reduceActions = [];
    this.reduceActions[3] = function (rhs) {
      return new OrOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[5] = function (rhs) {
      return new AndOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[7] = function (rhs) {
      return new EqualsOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[8] = function (rhs) {
      return new NotEqualOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[10] = function (rhs) {
      return new LessThanOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[11] = function (rhs) {
      return new GreaterThanOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[12] = function (rhs) {
      return new LessThanOrEqualOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[13] = function (rhs) {
      return new GreaterThanOrEqualOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[15] = function (rhs) {
      return new PlusOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[16] = function (rhs) {
      return new MinusOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[18] = function (rhs) {
      return new MultiplyOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[19] = function (rhs) {
      return new DivOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[20] = function (rhs) {
      return new ModOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[22] = function (rhs) {
      return new UnaryMinusOperation(rhs[1]);
    };
    this.reduceActions[24] = function (rhs) {
      return new BarOperation(rhs[0], rhs[2]);
    };
    this.reduceActions[25] = function (rhs) {
      return new PathExpr(undefined, undefined, rhs[0]);
    };
    this.reduceActions[27] = function (rhs) {
      rhs[0].locationPath = rhs[2];
      return rhs[0];
    };
    this.reduceActions[28] = function (rhs) {
      rhs[0].locationPath = rhs[2];
      rhs[0].locationPath.steps.unshift(new Step(Step.DESCENDANTORSELF, NodeTest.nodeTest, []));
      return rhs[0];
    };
    this.reduceActions[29] = function (rhs) {
      return new PathExpr(rhs[0], [], undefined);
    };
    this.reduceActions[30] = function (rhs) {
      if (Utilities.instance_of(rhs[0], PathExpr)) {
        if (rhs[0].filterPredicates == undefined) {
          rhs[0].filterPredicates = [];
        }
        rhs[0].filterPredicates.push(rhs[1]);
        return rhs[0];
      } else {
        return new PathExpr(rhs[0], [rhs[1]], undefined);
      }
    };
    this.reduceActions[32] = function (rhs) {
      return rhs[1];
    };
    this.reduceActions[33] = function (rhs) {
      return new XString(rhs[0]);
    };
    this.reduceActions[34] = function (rhs) {
      return new XNumber(rhs[0]);
    };
    this.reduceActions[36] = function (rhs) {
      return new FunctionCall(rhs[0], []);
    };
    this.reduceActions[37] = function (rhs) {
      return new FunctionCall(rhs[0], rhs[2]);
    };
    this.reduceActions[38] = function (rhs) {
      return [rhs[0]];
    };
    this.reduceActions[39] = function (rhs) {
      rhs[2].unshift(rhs[0]);
      return rhs[2];
    };
    this.reduceActions[43] = function (rhs) {
      return new LocationPath(true, []);
    };
    this.reduceActions[44] = function (rhs) {
      rhs[1].absolute = true;
      return rhs[1];
    };
    this.reduceActions[46] = function (rhs) {
      return new LocationPath(false, [rhs[0]]);
    };
    this.reduceActions[47] = function (rhs) {
      rhs[0].steps.push(rhs[2]);
      return rhs[0];
    };
    this.reduceActions[49] = function (rhs) {
      return new Step(rhs[0], rhs[1], []);
    };
    this.reduceActions[50] = function (rhs) {
      return new Step(Step.CHILD, rhs[0], []);
    };
    this.reduceActions[51] = function (rhs) {
      return new Step(rhs[0], rhs[1], rhs[2]);
    };
    this.reduceActions[52] = function (rhs) {
      return new Step(Step.CHILD, rhs[0], rhs[1]);
    };
    this.reduceActions[54] = function (rhs) {
      return [rhs[0]];
    };
    this.reduceActions[55] = function (rhs) {
      rhs[1].unshift(rhs[0]);
      return rhs[1];
    };
    this.reduceActions[56] = function (rhs) {
      if (rhs[0] == "ancestor") {
        return Step.ANCESTOR;
      } else if (rhs[0] == "ancestor-or-self") {
        return Step.ANCESTORORSELF;
      } else if (rhs[0] == "attribute") {
        return Step.ATTRIBUTE;
      } else if (rhs[0] == "child") {
        return Step.CHILD;
      } else if (rhs[0] == "descendant") {
        return Step.DESCENDANT;
      } else if (rhs[0] == "descendant-or-self") {
        return Step.DESCENDANTORSELF;
      } else if (rhs[0] == "following") {
        return Step.FOLLOWING;
      } else if (rhs[0] == "following-sibling") {
        return Step.FOLLOWINGSIBLING;
      } else if (rhs[0] == "namespace") {
        return Step.NAMESPACE;
      } else if (rhs[0] == "parent") {
        return Step.PARENT;
      } else if (rhs[0] == "preceding") {
        return Step.PRECEDING;
      } else if (rhs[0] == "preceding-sibling") {
        return Step.PRECEDINGSIBLING;
      } else if (rhs[0] == "self") {
        return Step.SELF;
      }
      return -1;
    };
    this.reduceActions[57] = function (rhs) {
      return Step.ATTRIBUTE;
    };
    this.reduceActions[59] = function (rhs) {
      if (rhs[0] == "comment") {
        return NodeTest.commentTest;
      } else if (rhs[0] == "text") {
        return NodeTest.textTest;
      } else if (rhs[0] == "processing-instruction") {
        return NodeTest.anyPiTest;
      } else if (rhs[0] == "node") {
        return NodeTest.nodeTest;
      }
      return new NodeTest(-1, undefined);
    };
    this.reduceActions[60] = function (rhs) {
      return new NodeTest.PITest(rhs[2]);
    };
    this.reduceActions[61] = function (rhs) {
      return rhs[1];
    };
    this.reduceActions[63] = function (rhs) {
      rhs[1].absolute = true;
      rhs[1].steps.unshift(new Step(Step.DESCENDANTORSELF, NodeTest.nodeTest, []));
      return rhs[1];
    };
    this.reduceActions[64] = function (rhs) {
      rhs[0].steps.push(new Step(Step.DESCENDANTORSELF, NodeTest.nodeTest, []));
      rhs[0].steps.push(rhs[2]);
      return rhs[0];
    };
    this.reduceActions[65] = function (rhs) {
      return new Step(Step.SELF, NodeTest.nodeTest, []);
    };
    this.reduceActions[66] = function (rhs) {
      return new Step(Step.PARENT, NodeTest.nodeTest, []);
    };
    this.reduceActions[67] = function (rhs) {
      return new VariableReference(rhs[1]);
    };
    this.reduceActions[68] = function (rhs) {
      return NodeTest.nameTestAny;
    };
    this.reduceActions[69] = function (rhs) {
      return new NodeTest.NameTestPrefixAny(rhs[0].split(':')[0]);
    };
    this.reduceActions[70] = function (rhs) {
      return new NodeTest.NameTestQName(rhs[0]);
    };
  };
  XPathParser.actionTable = [" s s        sssssssss    s ss  s  ss", "                 s                  ", "r  rrrrrrrrr         rrrrrrr rr  r  ", "                rrrrr               ", " s s        sssssssss    s ss  s  ss", "rs  rrrrrrrr s  sssssrrrrrr  rrs rs ", " s s        sssssssss    s ss  s  ss", "                            s       ", "                            s       ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "  s                                 ", "                            s       ", " s           s  sssss          s  s ", "r  rrrrrrrrr         rrrrrrr rr  r  ", "a                                   ", "r       s                    rr  r  ", "r      sr                    rr  r  ", "r   s  rr            s       rr  r  ", "r   rssrr            rss     rr  r  ", "r   rrrrr            rrrss   rr  r  ", "r   rrrrrsss         rrrrr   rr  r  ", "r   rrrrrrrr         rrrrr   rr  r  ", "r   rrrrrrrr         rrrrrs  rr  r  ", "r   rrrrrrrr         rrrrrr  rr  r  ", "r   rrrrrrrr         rrrrrr  rr  r  ", "r  srrrrrrrr         rrrrrrs rr sr  ", "r  srrrrrrrr         rrrrrrs rr  r  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "r   rrrrrrrr         rrrrrr  rr  r  ", "r   rrrrrrrr         rrrrrr  rr  r  ", "r  rrrrrrrrr         rrrrrrr rr  r  ", "r  rrrrrrrrr         rrrrrrr rr  r  ", "                sssss               ", "r  rrrrrrrrr         rrrrrrr rr sr  ", "r  rrrrrrrrr         rrrrrrr rr  r  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "                             s      ", "r  srrrrrrrr         rrrrrrs rr  r  ", "r   rrrrrrrr         rrrrr   rr  r  ", "              s                     ", "                             s      ", "                rrrrr               ", " s s        sssssssss    s sss s  ss", "r  srrrrrrrr         rrrrrrs rr  r  ", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss    s ss  s  ss", " s s        sssssssss      ss  s  ss", " s s        sssssssss    s ss  s  ss", " s           s  sssss          s  s ", " s           s  sssss          s  s ", "r  rrrrrrrrr         rrrrrrr rr rr  ", " s           s  sssss          s  s ", " s           s  sssss          s  s ", "r  rrrrrrrrr         rrrrrrr rr sr  ", "r  rrrrrrrrr         rrrrrrr rr sr  ", "r  rrrrrrrrr         rrrrrrr rr  r  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "                             s      ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "                             rr     ", "                             s      ", "                             rs     ", "r      sr                    rr  r  ", "r   s  rr            s       rr  r  ", "r   rssrr            rss     rr  r  ", "r   rssrr            rss     rr  r  ", "r   rrrrr            rrrss   rr  r  ", "r   rrrrr            rrrss   rr  r  ", "r   rrrrr            rrrss   rr  r  ", "r   rrrrr            rrrss   rr  r  ", "r   rrrrrsss         rrrrr   rr  r  ", "r   rrrrrsss         rrrrr   rr  r  ", "r   rrrrrrrr         rrrrr   rr  r  ", "r   rrrrrrrr         rrrrr   rr  r  ", "r   rrrrrrrr         rrrrr   rr  r  ", "r   rrrrrrrr         rrrrrr  rr  r  ", "                                 r  ", "                                 s  ", "r  srrrrrrrr         rrrrrrs rr  r  ", "r  srrrrrrrr         rrrrrrs rr  r  ", "r  rrrrrrrrr         rrrrrrr rr  r  ", "r  rrrrrrrrr         rrrrrrr rr  r  ", "r  rrrrrrrrr         rrrrrrr rr  r  ", "r  rrrrrrrrr         rrrrrrr rr  r  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", "r  rrrrrrrrr         rrrrrrr rr rr  ", " s s        sssssssss    s ss  s  ss", "r  rrrrrrrrr         rrrrrrr rr rr  ", "                             r      "];
  XPathParser.actionTableNumber = [" 1 0        /.-,+*)('    & %$  #  \"!", "                 J                  ", "a  aaaaaaaaa         aaaaaaa aa  a  ", "                YYYYY               ", " 1 0        /.-,+*)('    & %$  #  \"!", "K1  KKKKKKKK .  +*)('KKKKKK  KK# K\" ", " 1 0        /.-,+*)('    & %$  #  \"!", "                            N       ", "                            O       ", "e  eeeeeeeee         eeeeeee ee ee  ", "f  fffffffff         fffffff ff ff  ", "d  ddddddddd         ddddddd dd dd  ", "B  BBBBBBBBB         BBBBBBB BB BB  ", "A  AAAAAAAAA         AAAAAAA AA AA  ", "  P                                 ", "                            Q       ", " 1           .  +*)('          #  \" ", "b  bbbbbbbbb         bbbbbbb bb  b  ", "                                    ", "!       S                    !!  !  ", "\"      T\"                    \"\"  \"  ", "$   V  $$            U       $$  $  ", "&   &ZY&&            &XW     &&  &  ", ")   )))))            )))\\[   ))  )  ", ".   ....._^]         .....   ..  .  ", "1   11111111         11111   11  1  ", "5   55555555         55555`  55  5  ", "7   77777777         777777  77  7  ", "9   99999999         999999  99  9  ", ":  c::::::::         ::::::b :: a:  ", "I  fIIIIIIII         IIIIIIe II  I  ", "=  =========         ======= == ==  ", "?  ?????????         ??????? ?? ??  ", "C  CCCCCCCCC         CCCCCCC CC CC  ", "J   JJJJJJJJ         JJJJJJ  JJ  J  ", "M   MMMMMMMM         MMMMMM  MM  M  ", "N  NNNNNNNNN         NNNNNNN NN  N  ", "P  PPPPPPPPP         PPPPPPP PP  P  ", "                +*)('               ", "R  RRRRRRRRR         RRRRRRR RR aR  ", "U  UUUUUUUUU         UUUUUUU UU  U  ", "Z  ZZZZZZZZZ         ZZZZZZZ ZZ ZZ  ", "c  ccccccccc         ccccccc cc cc  ", "                             j      ", "L  fLLLLLLLL         LLLLLLe LL  L  ", "6   66666666         66666   66  6  ", "              k                     ", "                             l      ", "                XXXXX               ", " 1 0        /.-,+*)('    & %$m #  \"!", "_  f________         ______e __  _  ", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1 0        /.-,+*)('      %$  #  \"!", " 1 0        /.-,+*)('    & %$  #  \"!", " 1           .  +*)('          #  \" ", " 1           .  +*)('          #  \" ", ">  >>>>>>>>>         >>>>>>> >> >>  ", " 1           .  +*)('          #  \" ", " 1           .  +*)('          #  \" ", "Q  QQQQQQQQQ         QQQQQQQ QQ aQ  ", "V  VVVVVVVVV         VVVVVVV VV aV  ", "T  TTTTTTTTT         TTTTTTT TT  T  ", "@  @@@@@@@@@         @@@@@@@ @@ @@  ", "                             \x87      ", "[  [[[[[[[[[         [[[[[[[ [[ [[  ", "D  DDDDDDDDD         DDDDDDD DD DD  ", "                             HH     ", "                             \x88      ", "                             F\x89     ", "#      T#                    ##  #  ", "%   V  %%            U       %%  %  ", "'   'ZY''            'XW     ''  '  ", "(   (ZY((            (XW     ((  (  ", "+   +++++            +++\\[   ++  +  ", "*   *****            ***\\[   **  *  ", "-   -----            ---\\[   --  -  ", ",   ,,,,,            ,,,\\[   ,,  ,  ", "0   00000_^]         00000   00  0  ", "/   /////_^]         /////   //  /  ", "2   22222222         22222   22  2  ", "3   33333333         33333   33  3  ", "4   44444444         44444   44  4  ", "8   88888888         888888  88  8  ", "                                 ^  ", "                                 \x8a  ", ";  f;;;;;;;;         ;;;;;;e ;;  ;  ", "<  f<<<<<<<<         <<<<<<e <<  <  ", "O  OOOOOOOOO         OOOOOOO OO  O  ", "`  `````````         ``````` ``  `  ", "S  SSSSSSSSS         SSSSSSS SS  S  ", "W  WWWWWWWWW         WWWWWWW WW  W  ", "\\  \\\\\\\\\\\\\\\\\\         \\\\\\\\\\\\\\ \\\\ \\\\  ", "E  EEEEEEEEE         EEEEEEE EE EE  ", " 1 0        /.-,+*)('    & %$  #  \"!", "]  ]]]]]]]]]         ]]]]]]] ]] ]]  ", "                             G      "];
  XPathParser.gotoTable = ["3456789:;<=>?@ AB  CDEFGH IJ ", "                             ", "                             ", "                             ", "L456789:;<=>?@ AB  CDEFGH IJ ", "            M        EFGH IJ ", "       N;<=>?@ AB  CDEFGH IJ ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "            S        EFGH IJ ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "              e              ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                        h  J ", "              i          j   ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "o456789:;<=>?@ ABpqCDEFGH IJ ", "                             ", "  r6789:;<=>?@ AB  CDEFGH IJ ", "   s789:;<=>?@ AB  CDEFGH IJ ", "    t89:;<=>?@ AB  CDEFGH IJ ", "    u89:;<=>?@ AB  CDEFGH IJ ", "     v9:;<=>?@ AB  CDEFGH IJ ", "     w9:;<=>?@ AB  CDEFGH IJ ", "     x9:;<=>?@ AB  CDEFGH IJ ", "     y9:;<=>?@ AB  CDEFGH IJ ", "      z:;<=>?@ AB  CDEFGH IJ ", "      {:;<=>?@ AB  CDEFGH IJ ", "       |;<=>?@ AB  CDEFGH IJ ", "       };<=>?@ AB  CDEFGH IJ ", "       ~;<=>?@ AB  CDEFGH IJ ", "         \x7f=>?@ AB  CDEFGH IJ ", "\x80456789:;<=>?@ AB  CDEFGH IJ\x81", "            \x82        EFGH IJ ", "            \x83        EFGH IJ ", "                             ", "                     \x84 GH IJ ", "                     \x85 GH IJ ", "              i          \x86   ", "              i          \x87   ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "                             ", "o456789:;<=>?@ AB\x8cqCDEFGH IJ ", "                             ", "                             "];
  XPathParser.productions = [[1, 1, 2], [2, 1, 3], [3, 1, 4], [3, 3, 3, -9, 4], [4, 1, 5], [4, 3, 4, -8, 5], [5, 1, 6], [5, 3, 5, -22, 6], [5, 3, 5, -5, 6], [6, 1, 7], [6, 3, 6, -23, 7], [6, 3, 6, -24, 7], [6, 3, 6, -6, 7], [6, 3, 6, -7, 7], [7, 1, 8], [7, 3, 7, -25, 8], [7, 3, 7, -26, 8], [8, 1, 9], [8, 3, 8, -12, 9], [8, 3, 8, -11, 9], [8, 3, 8, -10, 9], [9, 1, 10], [9, 2, -26, 9], [10, 1, 11], [10, 3, 10, -27, 11], [11, 1, 12], [11, 1, 13], [11, 3, 13, -28, 14], [11, 3, 13, -4, 14], [13, 1, 15], [13, 2, 13, 16], [15, 1, 17], [15, 3, -29, 2, -30], [15, 1, -15], [15, 1, -16], [15, 1, 18], [18, 3, -13, -29, -30], [18, 4, -13, -29, 19, -30], [19, 1, 20], [19, 3, 20, -31, 19], [20, 1, 2], [12, 1, 14], [12, 1, 21], [21, 1, -28], [21, 2, -28, 14], [21, 1, 22], [14, 1, 23], [14, 3, 14, -28, 23], [14, 1, 24], [23, 2, 25, 26], [23, 1, 26], [23, 3, 25, 26, 27], [23, 2, 26, 27], [23, 1, 28], [27, 1, 16], [27, 2, 16, 27], [25, 2, -14, -3], [25, 1, -32], [26, 1, 29], [26, 3, -20, -29, -30], [26, 4, -21, -29, -15, -30], [16, 3, -33, 30, -34], [30, 1, 2], [22, 2, -4, 14], [24, 3, 14, -4, 23], [28, 1, -35], [28, 1, -2], [17, 2, -36, -18], [29, 1, -17], [29, 1, -19], [29, 1, -18]];
  XPathParser.DOUBLEDOT = 2;
  XPathParser.DOUBLECOLON = 3;
  XPathParser.DOUBLESLASH = 4;
  XPathParser.NOTEQUAL = 5;
  XPathParser.LESSTHANOREQUAL = 6;
  XPathParser.GREATERTHANOREQUAL = 7;
  XPathParser.AND = 8;
  XPathParser.OR = 9;
  XPathParser.MOD = 10;
  XPathParser.DIV = 11;
  XPathParser.MULTIPLYOPERATOR = 12;
  XPathParser.FUNCTIONNAME = 13;
  XPathParser.AXISNAME = 14;
  XPathParser.LITERAL = 15;
  XPathParser.NUMBER = 16;
  XPathParser.ASTERISKNAMETEST = 17;
  XPathParser.QNAME = 18;
  XPathParser.NCNAMECOLONASTERISK = 19;
  XPathParser.NODETYPE = 20;
  XPathParser.PROCESSINGINSTRUCTIONWITHLITERAL = 21;
  XPathParser.EQUALS = 22;
  XPathParser.LESSTHAN = 23;
  XPathParser.GREATERTHAN = 24;
  XPathParser.PLUS = 25;
  XPathParser.MINUS = 26;
  XPathParser.BAR = 27;
  XPathParser.SLASH = 28;
  XPathParser.LEFTPARENTHESIS = 29;
  XPathParser.RIGHTPARENTHESIS = 30;
  XPathParser.COMMA = 31;
  XPathParser.AT = 32;
  XPathParser.LEFTBRACKET = 33;
  XPathParser.RIGHTBRACKET = 34;
  XPathParser.DOT = 35;
  XPathParser.DOLLAR = 36;
  XPathParser.prototype.tokenize = function (s1) {
    var types = [];
    var values = [];
    var s = s1 + '\0';
    var pos = 0;
    var c = s.charAt(pos++);
    while (1) {
      while (c == ' ' || c == '\t' || c == '\r' || c == '\n') {
        c = s.charAt(pos++);
      }
      if (c == '\0' || pos >= s.length) {
        break;
      }
      if (c == '(') {
        types.push(XPathParser.LEFTPARENTHESIS);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == ')') {
        types.push(XPathParser.RIGHTPARENTHESIS);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == '[') {
        types.push(XPathParser.LEFTBRACKET);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == ']') {
        types.push(XPathParser.RIGHTBRACKET);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == '@') {
        types.push(XPathParser.AT);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == ',') {
        types.push(XPathParser.COMMA);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == '|') {
        types.push(XPathParser.BAR);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == '+') {
        types.push(XPathParser.PLUS);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == '-') {
        types.push(XPathParser.MINUS);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == '=') {
        types.push(XPathParser.EQUALS);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == '$') {
        types.push(XPathParser.DOLLAR);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == '.') {
        c = s.charAt(pos++);
        if (c == '.') {
          types.push(XPathParser.DOUBLEDOT);
          values.push("..");
          c = s.charAt(pos++);
          continue;
        }
        if (c >= '0' && c <= '9') {
          var number = "." + c;
          c = s.charAt(pos++);
          while (c >= '0' && c <= '9') {
            number += c;
            c = s.charAt(pos++);
          }
          types.push(XPathParser.NUMBER);
          values.push(number);
          continue;
        }
        types.push(XPathParser.DOT);
        values.push('.');
        continue;
      }
      if (c == '\'' || c == '"') {
        var delimiter = c;
        var literal = "";
        while (pos < s.length && (c = s.charAt(pos)) !== delimiter) {
          literal += c;
          pos += 1;
        }
        if (c !== delimiter) {
          throw XPathException.fromMessage("Unterminated string literal: " + delimiter + literal);
        }
        pos += 1;
        types.push(XPathParser.LITERAL);
        values.push(literal);
        c = s.charAt(pos++);
        continue;
      }
      if (c >= '0' && c <= '9') {
        var number = c;
        c = s.charAt(pos++);
        while (c >= '0' && c <= '9') {
          number += c;
          c = s.charAt(pos++);
        }
        if (c == '.') {
          if (s.charAt(pos) >= '0' && s.charAt(pos) <= '9') {
            number += c;
            number += s.charAt(pos++);
            c = s.charAt(pos++);
            while (c >= '0' && c <= '9') {
              number += c;
              c = s.charAt(pos++);
            }
          }
        }
        types.push(XPathParser.NUMBER);
        values.push(number);
        continue;
      }
      if (c == '*') {
        if (types.length > 0) {
          var last = types[types.length - 1];
          if (last != XPathParser.AT && last != XPathParser.DOUBLECOLON && last != XPathParser.LEFTPARENTHESIS && last != XPathParser.LEFTBRACKET && last != XPathParser.AND && last != XPathParser.OR && last != XPathParser.MOD && last != XPathParser.DIV && last != XPathParser.MULTIPLYOPERATOR && last != XPathParser.SLASH && last != XPathParser.DOUBLESLASH && last != XPathParser.BAR && last != XPathParser.PLUS && last != XPathParser.MINUS && last != XPathParser.EQUALS && last != XPathParser.NOTEQUAL && last != XPathParser.LESSTHAN && last != XPathParser.LESSTHANOREQUAL && last != XPathParser.GREATERTHAN && last != XPathParser.GREATERTHANOREQUAL) {
            types.push(XPathParser.MULTIPLYOPERATOR);
            values.push(c);
            c = s.charAt(pos++);
            continue;
          }
        }
        types.push(XPathParser.ASTERISKNAMETEST);
        values.push(c);
        c = s.charAt(pos++);
        continue;
      }
      if (c == ':') {
        if (s.charAt(pos) == ':') {
          types.push(XPathParser.DOUBLECOLON);
          values.push("::");
          pos++;
          c = s.charAt(pos++);
          continue;
        }
      }
      if (c == '/') {
        c = s.charAt(pos++);
        if (c == '/') {
          types.push(XPathParser.DOUBLESLASH);
          values.push("//");
          c = s.charAt(pos++);
          continue;
        }
        types.push(XPathParser.SLASH);
        values.push('/');
        continue;
      }
      if (c == '!') {
        if (s.charAt(pos) == '=') {
          types.push(XPathParser.NOTEQUAL);
          values.push("!=");
          pos++;
          c = s.charAt(pos++);
          continue;
        }
      }
      if (c == '<') {
        if (s.charAt(pos) == '=') {
          types.push(XPathParser.LESSTHANOREQUAL);
          values.push("<=");
          pos++;
          c = s.charAt(pos++);
          continue;
        }
        types.push(XPathParser.LESSTHAN);
        values.push('<');
        c = s.charAt(pos++);
        continue;
      }
      if (c == '>') {
        if (s.charAt(pos) == '=') {
          types.push(XPathParser.GREATERTHANOREQUAL);
          values.push(">=");
          pos++;
          c = s.charAt(pos++);
          continue;
        }
        types.push(XPathParser.GREATERTHAN);
        values.push('>');
        c = s.charAt(pos++);
        continue;
      }
      if (c == '_' || Utilities.isLetter(c.charCodeAt(0))) {
        var name = c;
        c = s.charAt(pos++);
        while (Utilities.isNCNameChar(c.charCodeAt(0))) {
          name += c;
          c = s.charAt(pos++);
        }
        if (types.length > 0) {
          var last = types[types.length - 1];
          if (last != XPathParser.AT && last != XPathParser.DOUBLECOLON && last != XPathParser.LEFTPARENTHESIS && last != XPathParser.LEFTBRACKET && last != XPathParser.AND && last != XPathParser.OR && last != XPathParser.MOD && last != XPathParser.DIV && last != XPathParser.MULTIPLYOPERATOR && last != XPathParser.SLASH && last != XPathParser.DOUBLESLASH && last != XPathParser.BAR && last != XPathParser.PLUS && last != XPathParser.MINUS && last != XPathParser.EQUALS && last != XPathParser.NOTEQUAL && last != XPathParser.LESSTHAN && last != XPathParser.LESSTHANOREQUAL && last != XPathParser.GREATERTHAN && last != XPathParser.GREATERTHANOREQUAL) {
            if (name == "and") {
              types.push(XPathParser.AND);
              values.push(name);
              continue;
            }
            if (name == "or") {
              types.push(XPathParser.OR);
              values.push(name);
              continue;
            }
            if (name == "mod") {
              types.push(XPathParser.MOD);
              values.push(name);
              continue;
            }
            if (name == "div") {
              types.push(XPathParser.DIV);
              values.push(name);
              continue;
            }
          }
        }
        if (c == ':') {
          if (s.charAt(pos) == '*') {
            types.push(XPathParser.NCNAMECOLONASTERISK);
            values.push(name + ":*");
            pos++;
            c = s.charAt(pos++);
            continue;
          }
          if (s.charAt(pos) == '_' || Utilities.isLetter(s.charCodeAt(pos))) {
            name += ':';
            c = s.charAt(pos++);
            while (Utilities.isNCNameChar(c.charCodeAt(0))) {
              name += c;
              c = s.charAt(pos++);
            }
            if (c == '(') {
              types.push(XPathParser.FUNCTIONNAME);
              values.push(name);
              continue;
            }
            types.push(XPathParser.QNAME);
            values.push(name);
            continue;
          }
          if (s.charAt(pos) == ':') {
            types.push(XPathParser.AXISNAME);
            values.push(name);
            continue;
          }
        }
        if (c == '(') {
          if (name == "comment" || name == "text" || name == "node") {
            types.push(XPathParser.NODETYPE);
            values.push(name);
            continue;
          }
          if (name == "processing-instruction") {
            if (s.charAt(pos) == ')') {
              types.push(XPathParser.NODETYPE);
            } else {
              types.push(XPathParser.PROCESSINGINSTRUCTIONWITHLITERAL);
            }
            values.push(name);
            continue;
          }
          types.push(XPathParser.FUNCTIONNAME);
          values.push(name);
          continue;
        }
        types.push(XPathParser.QNAME);
        values.push(name);
        continue;
      }
      throw new Error("Unexpected character " + c);
    }
    types.push(1);
    values.push("[EOF]");
    return [types, values];
  };
  XPathParser.SHIFT = 's';
  XPathParser.REDUCE = 'r';
  XPathParser.ACCEPT = 'a';
  XPathParser.prototype.parse = function (s) {
    var types;
    var values;
    var res = this.tokenize(s);
    if (res == undefined) {
      return undefined;
    }
    types = res[0];
    values = res[1];
    var tokenPos = 0;
    var state = [];
    var tokenType = [];
    var tokenValue = [];
    var s;
    var a;
    var t;
    state.push(0);
    tokenType.push(1);
    tokenValue.push("_S");
    a = types[tokenPos];
    t = values[tokenPos++];
    while (1) {
      s = state[state.length - 1];
      switch (XPathParser.actionTable[s].charAt(a - 1)) {
        case XPathParser.SHIFT:
          tokenType.push(-a);
          tokenValue.push(t);
          state.push(XPathParser.actionTableNumber[s].charCodeAt(a - 1) - 32);
          a = types[tokenPos];
          t = values[tokenPos++];
          break;
        case XPathParser.REDUCE:
          var num = XPathParser.productions[XPathParser.actionTableNumber[s].charCodeAt(a - 1) - 32][1];
          var rhs = [];
          for (var i = 0; i < num; i++) {
            tokenType.pop();
            rhs.unshift(tokenValue.pop());
            state.pop();
          }
          var s_ = state[state.length - 1];
          tokenType.push(XPathParser.productions[XPathParser.actionTableNumber[s].charCodeAt(a - 1) - 32][0]);
          if (this.reduceActions[XPathParser.actionTableNumber[s].charCodeAt(a - 1) - 32] == undefined) {
            tokenValue.push(rhs[0]);
          } else {
            tokenValue.push(this.reduceActions[XPathParser.actionTableNumber[s].charCodeAt(a - 1) - 32](rhs));
          }
          state.push(XPathParser.gotoTable[s_].charCodeAt(XPathParser.productions[XPathParser.actionTableNumber[s].charCodeAt(a - 1) - 32][0] - 2) - 33);
          break;
        case XPathParser.ACCEPT:
          return new XPath(tokenValue.pop());
        default:
          throw new Error("XPath parse error");
      }
    }
  };
  XPath.prototype = new Object();
  XPath.prototype.constructor = XPath;
  XPath.superclass = Object.prototype;
  function XPath(e) {
    this.expression = e;
  }
  XPath.prototype.toString = function () {
    return this.expression.toString();
  };
  function setIfUnset(obj, prop, value) {
    if (!(prop in obj)) {
      obj[prop] = value;
    }
  }
  XPath.prototype.evaluate = function (c) {
    c.contextNode = c.expressionContextNode;
    c.contextSize = 1;
    c.contextPosition = 1;
    if (c.isHtml) {
      setIfUnset(c, 'caseInsensitive', true);
      setIfUnset(c, 'allowAnyNamespaceForNoPrefix', true);
    }
    setIfUnset(c, 'caseInsensitive', false);
    return this.expression.evaluate(c);
  };
  XPath.XML_NAMESPACE_URI = "http://www.w3.org/XML/1998/namespace";
  XPath.XMLNS_NAMESPACE_URI = "http://www.w3.org/2000/xmlns/";
  Expression.prototype = new Object();
  Expression.prototype.constructor = Expression;
  Expression.superclass = Object.prototype;
  function Expression() {}
  Expression.prototype.init = function () {};
  Expression.prototype.toString = function () {
    return "<Expression>";
  };
  Expression.prototype.evaluate = function (c) {
    throw new Error("Could not evaluate expression.");
  };
  UnaryOperation.prototype = new Expression();
  UnaryOperation.prototype.constructor = UnaryOperation;
  UnaryOperation.superclass = Expression.prototype;
  function UnaryOperation(rhs) {
    if (arguments.length > 0) {
      this.init(rhs);
    }
  }
  UnaryOperation.prototype.init = function (rhs) {
    this.rhs = rhs;
  };
  UnaryMinusOperation.prototype = new UnaryOperation();
  UnaryMinusOperation.prototype.constructor = UnaryMinusOperation;
  UnaryMinusOperation.superclass = UnaryOperation.prototype;
  function UnaryMinusOperation(rhs) {
    if (arguments.length > 0) {
      this.init(rhs);
    }
  }
  UnaryMinusOperation.prototype.init = function (rhs) {
    UnaryMinusOperation.superclass.init.call(this, rhs);
  };
  UnaryMinusOperation.prototype.evaluate = function (c) {
    return this.rhs.evaluate(c).number().negate();
  };
  UnaryMinusOperation.prototype.toString = function () {
    return "-" + this.rhs.toString();
  };
  BinaryOperation.prototype = new Expression();
  BinaryOperation.prototype.constructor = BinaryOperation;
  BinaryOperation.superclass = Expression.prototype;
  function BinaryOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  BinaryOperation.prototype.init = function (lhs, rhs) {
    this.lhs = lhs;
    this.rhs = rhs;
  };
  OrOperation.prototype = new BinaryOperation();
  OrOperation.prototype.constructor = OrOperation;
  OrOperation.superclass = BinaryOperation.prototype;
  function OrOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  OrOperation.prototype.init = function (lhs, rhs) {
    OrOperation.superclass.init.call(this, lhs, rhs);
  };
  OrOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " or " + this.rhs.toString() + ")";
  };
  OrOperation.prototype.evaluate = function (c) {
    var b = this.lhs.evaluate(c).bool();
    if (b.booleanValue()) {
      return b;
    }
    return this.rhs.evaluate(c).bool();
  };
  AndOperation.prototype = new BinaryOperation();
  AndOperation.prototype.constructor = AndOperation;
  AndOperation.superclass = BinaryOperation.prototype;
  function AndOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  AndOperation.prototype.init = function (lhs, rhs) {
    AndOperation.superclass.init.call(this, lhs, rhs);
  };
  AndOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " and " + this.rhs.toString() + ")";
  };
  AndOperation.prototype.evaluate = function (c) {
    var b = this.lhs.evaluate(c).bool();
    if (!b.booleanValue()) {
      return b;
    }
    return this.rhs.evaluate(c).bool();
  };
  EqualsOperation.prototype = new BinaryOperation();
  EqualsOperation.prototype.constructor = EqualsOperation;
  EqualsOperation.superclass = BinaryOperation.prototype;
  function EqualsOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  EqualsOperation.prototype.init = function (lhs, rhs) {
    EqualsOperation.superclass.init.call(this, lhs, rhs);
  };
  EqualsOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " = " + this.rhs.toString() + ")";
  };
  EqualsOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).equals(this.rhs.evaluate(c));
  };
  NotEqualOperation.prototype = new BinaryOperation();
  NotEqualOperation.prototype.constructor = NotEqualOperation;
  NotEqualOperation.superclass = BinaryOperation.prototype;
  function NotEqualOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  NotEqualOperation.prototype.init = function (lhs, rhs) {
    NotEqualOperation.superclass.init.call(this, lhs, rhs);
  };
  NotEqualOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " != " + this.rhs.toString() + ")";
  };
  NotEqualOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).notequal(this.rhs.evaluate(c));
  };
  LessThanOperation.prototype = new BinaryOperation();
  LessThanOperation.prototype.constructor = LessThanOperation;
  LessThanOperation.superclass = BinaryOperation.prototype;
  function LessThanOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  LessThanOperation.prototype.init = function (lhs, rhs) {
    LessThanOperation.superclass.init.call(this, lhs, rhs);
  };
  LessThanOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).lessthan(this.rhs.evaluate(c));
  };
  LessThanOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " < " + this.rhs.toString() + ")";
  };
  GreaterThanOperation.prototype = new BinaryOperation();
  GreaterThanOperation.prototype.constructor = GreaterThanOperation;
  GreaterThanOperation.superclass = BinaryOperation.prototype;
  function GreaterThanOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  GreaterThanOperation.prototype.init = function (lhs, rhs) {
    GreaterThanOperation.superclass.init.call(this, lhs, rhs);
  };
  GreaterThanOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).greaterthan(this.rhs.evaluate(c));
  };
  GreaterThanOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " > " + this.rhs.toString() + ")";
  };
  LessThanOrEqualOperation.prototype = new BinaryOperation();
  LessThanOrEqualOperation.prototype.constructor = LessThanOrEqualOperation;
  LessThanOrEqualOperation.superclass = BinaryOperation.prototype;
  function LessThanOrEqualOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  LessThanOrEqualOperation.prototype.init = function (lhs, rhs) {
    LessThanOrEqualOperation.superclass.init.call(this, lhs, rhs);
  };
  LessThanOrEqualOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).lessthanorequal(this.rhs.evaluate(c));
  };
  LessThanOrEqualOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " <= " + this.rhs.toString() + ")";
  };
  GreaterThanOrEqualOperation.prototype = new BinaryOperation();
  GreaterThanOrEqualOperation.prototype.constructor = GreaterThanOrEqualOperation;
  GreaterThanOrEqualOperation.superclass = BinaryOperation.prototype;
  function GreaterThanOrEqualOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  GreaterThanOrEqualOperation.prototype.init = function (lhs, rhs) {
    GreaterThanOrEqualOperation.superclass.init.call(this, lhs, rhs);
  };
  GreaterThanOrEqualOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).greaterthanorequal(this.rhs.evaluate(c));
  };
  GreaterThanOrEqualOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " >= " + this.rhs.toString() + ")";
  };
  PlusOperation.prototype = new BinaryOperation();
  PlusOperation.prototype.constructor = PlusOperation;
  PlusOperation.superclass = BinaryOperation.prototype;
  function PlusOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  PlusOperation.prototype.init = function (lhs, rhs) {
    PlusOperation.superclass.init.call(this, lhs, rhs);
  };
  PlusOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).number().plus(this.rhs.evaluate(c).number());
  };
  PlusOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " + " + this.rhs.toString() + ")";
  };
  MinusOperation.prototype = new BinaryOperation();
  MinusOperation.prototype.constructor = MinusOperation;
  MinusOperation.superclass = BinaryOperation.prototype;
  function MinusOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  MinusOperation.prototype.init = function (lhs, rhs) {
    MinusOperation.superclass.init.call(this, lhs, rhs);
  };
  MinusOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).number().minus(this.rhs.evaluate(c).number());
  };
  MinusOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " - " + this.rhs.toString() + ")";
  };
  MultiplyOperation.prototype = new BinaryOperation();
  MultiplyOperation.prototype.constructor = MultiplyOperation;
  MultiplyOperation.superclass = BinaryOperation.prototype;
  function MultiplyOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  MultiplyOperation.prototype.init = function (lhs, rhs) {
    MultiplyOperation.superclass.init.call(this, lhs, rhs);
  };
  MultiplyOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).number().multiply(this.rhs.evaluate(c).number());
  };
  MultiplyOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " * " + this.rhs.toString() + ")";
  };
  DivOperation.prototype = new BinaryOperation();
  DivOperation.prototype.constructor = DivOperation;
  DivOperation.superclass = BinaryOperation.prototype;
  function DivOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  DivOperation.prototype.init = function (lhs, rhs) {
    DivOperation.superclass.init.call(this, lhs, rhs);
  };
  DivOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).number().div(this.rhs.evaluate(c).number());
  };
  DivOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " div " + this.rhs.toString() + ")";
  };
  ModOperation.prototype = new BinaryOperation();
  ModOperation.prototype.constructor = ModOperation;
  ModOperation.superclass = BinaryOperation.prototype;
  function ModOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  ModOperation.prototype.init = function (lhs, rhs) {
    ModOperation.superclass.init.call(this, lhs, rhs);
  };
  ModOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).number().mod(this.rhs.evaluate(c).number());
  };
  ModOperation.prototype.toString = function () {
    return "(" + this.lhs.toString() + " mod " + this.rhs.toString() + ")";
  };
  BarOperation.prototype = new BinaryOperation();
  BarOperation.prototype.constructor = BarOperation;
  BarOperation.superclass = BinaryOperation.prototype;
  function BarOperation(lhs, rhs) {
    if (arguments.length > 0) {
      this.init(lhs, rhs);
    }
  }
  BarOperation.prototype.init = function (lhs, rhs) {
    BarOperation.superclass.init.call(this, lhs, rhs);
  };
  BarOperation.prototype.evaluate = function (c) {
    return this.lhs.evaluate(c).nodeset().union(this.rhs.evaluate(c).nodeset());
  };
  BarOperation.prototype.toString = function () {
    return map(toString, [this.lhs, this.rhs]).join(' | ');
  };
  PathExpr.prototype = new Expression();
  PathExpr.prototype.constructor = PathExpr;
  PathExpr.superclass = Expression.prototype;
  function PathExpr(filter, filterPreds, locpath) {
    if (arguments.length > 0) {
      this.init(filter, filterPreds, locpath);
    }
  }
  PathExpr.prototype.init = function (filter, filterPreds, locpath) {
    PathExpr.superclass.init.call(this);
    this.filter = filter;
    this.filterPredicates = filterPreds;
    this.locationPath = locpath;
  };
  function findRoot(node) {
    while (node && node.parentNode) {
      node = node.parentNode;
    }
    return node;
  }
  PathExpr.applyPredicates = function (predicates, c, nodes) {
    if (predicates.length === 0) {
      return nodes;
    }
    var ctx = c.extend({});
    return reduce(function (inNodes, pred) {
      ctx.contextSize = inNodes.length;
      return filter(function (node, i) {
        ctx.contextNode = node;
        ctx.contextPosition = i + 1;
        return PathExpr.predicateMatches(pred, ctx);
      }, inNodes);
    }, nodes, predicates);
  };
  PathExpr.getRoot = function (xpc, nodes) {
    var firstNode = nodes[0];
    if (firstNode.nodeType === 9) {
      return firstNode;
    }
    if (xpc.virtualRoot) {
      return xpc.virtualRoot;
    }
    var ownerDoc = firstNode.ownerDocument;
    if (ownerDoc) {
      return ownerDoc;
    }
    var n = firstNode;
    while (n.parentNode != null) {
      n = n.parentNode;
    }
    return n;
  };
  PathExpr.applyStep = function (step, xpc, node) {
    var self = this;
    var newNodes = [];
    xpc.contextNode = node;
    switch (step.axis) {
      case Step.ANCESTOR:
        if (xpc.contextNode === xpc.virtualRoot) {
          break;
        }
        var m;
        if (xpc.contextNode.nodeType == 2) {
          m = PathExpr.getOwnerElement(xpc.contextNode);
        } else {
          m = xpc.contextNode.parentNode;
        }
        while (m != null) {
          if (step.nodeTest.matches(m, xpc)) {
            newNodes.push(m);
          }
          if (m === xpc.virtualRoot) {
            break;
          }
          m = m.parentNode;
        }
        break;
      case Step.ANCESTORORSELF:
        for (var m = xpc.contextNode; m != null; m = m.nodeType == 2 ? PathExpr.getOwnerElement(m) : m.parentNode) {
          if (step.nodeTest.matches(m, xpc)) {
            newNodes.push(m);
          }
          if (m === xpc.virtualRoot) {
            break;
          }
        }
        break;
      case Step.ATTRIBUTE:
        var nnm = xpc.contextNode.attributes;
        if (nnm != null) {
          for (var k = 0; k < nnm.length; k++) {
            var m = nnm.item(k);
            if (step.nodeTest.matches(m, xpc)) {
              newNodes.push(m);
            }
          }
        }
        break;
      case Step.CHILD:
        for (var m = xpc.contextNode.firstChild; m != null; m = m.nextSibling) {
          if (step.nodeTest.matches(m, xpc)) {
            newNodes.push(m);
          }
        }
        break;
      case Step.DESCENDANT:
        var st = [xpc.contextNode.firstChild];
        while (st.length > 0) {
          for (var m = st.pop(); m != null;) {
            if (step.nodeTest.matches(m, xpc)) {
              newNodes.push(m);
            }
            if (m.firstChild != null) {
              st.push(m.nextSibling);
              m = m.firstChild;
            } else {
              m = m.nextSibling;
            }
          }
        }
        break;
      case Step.DESCENDANTORSELF:
        if (step.nodeTest.matches(xpc.contextNode, xpc)) {
          newNodes.push(xpc.contextNode);
        }
        var st = [xpc.contextNode.firstChild];
        while (st.length > 0) {
          for (var m = st.pop(); m != null;) {
            if (step.nodeTest.matches(m, xpc)) {
              newNodes.push(m);
            }
            if (m.firstChild != null) {
              st.push(m.nextSibling);
              m = m.firstChild;
            } else {
              m = m.nextSibling;
            }
          }
        }
        break;
      case Step.FOLLOWING:
        if (xpc.contextNode === xpc.virtualRoot) {
          break;
        }
        var st = [];
        if (xpc.contextNode.firstChild != null) {
          st.unshift(xpc.contextNode.firstChild);
        } else {
          st.unshift(xpc.contextNode.nextSibling);
        }
        for (var m = xpc.contextNode.parentNode; m != null && m.nodeType != 9 && m !== xpc.virtualRoot; m = m.parentNode) {
          st.unshift(m.nextSibling);
        }
        do {
          for (var m = st.pop(); m != null;) {
            if (step.nodeTest.matches(m, xpc)) {
              newNodes.push(m);
            }
            if (m.firstChild != null) {
              st.push(m.nextSibling);
              m = m.firstChild;
            } else {
              m = m.nextSibling;
            }
          }
        } while (st.length > 0);
        break;
      case Step.FOLLOWINGSIBLING:
        if (xpc.contextNode === xpc.virtualRoot) {
          break;
        }
        for (var m = xpc.contextNode.nextSibling; m != null; m = m.nextSibling) {
          if (step.nodeTest.matches(m, xpc)) {
            newNodes.push(m);
          }
        }
        break;
      case Step.NAMESPACE:
        var n = {};
        if (xpc.contextNode.nodeType == 1) {
          n["xml"] = XPath.XML_NAMESPACE_URI;
          n["xmlns"] = XPath.XMLNS_NAMESPACE_URI;
          for (var m = xpc.contextNode; m != null && m.nodeType == 1; m = m.parentNode) {
            for (var k = 0; k < m.attributes.length; k++) {
              var attr = m.attributes.item(k);
              var nm = String(attr.name);
              if (nm == "xmlns") {
                if (n[""] == undefined) {
                  n[""] = attr.value;
                }
              } else if (nm.length > 6 && nm.substring(0, 6) == "xmlns:") {
                var pre = nm.substring(6, nm.length);
                if (n[pre] == undefined) {
                  n[pre] = attr.value;
                }
              }
            }
          }
          for (var pre in n) {
            var nsn = new XPathNamespace(pre, n[pre], xpc.contextNode);
            if (step.nodeTest.matches(nsn, xpc)) {
              newNodes.push(nsn);
            }
          }
        }
        break;
      case Step.PARENT:
        m = null;
        if (xpc.contextNode !== xpc.virtualRoot) {
          if (xpc.contextNode.nodeType == 2) {
            m = PathExpr.getOwnerElement(xpc.contextNode);
          } else {
            m = xpc.contextNode.parentNode;
          }
        }
        if (m != null && step.nodeTest.matches(m, xpc)) {
          newNodes.push(m);
        }
        break;
      case Step.PRECEDING:
        var st;
        if (xpc.virtualRoot != null) {
          st = [xpc.virtualRoot];
        } else {
          st = [findRoot(xpc.contextNode)];
        }
        outer: while (st.length > 0) {
          for (var m = st.pop(); m != null;) {
            if (m == xpc.contextNode) {
              break outer;
            }
            if (step.nodeTest.matches(m, xpc)) {
              newNodes.unshift(m);
            }
            if (m.firstChild != null) {
              st.push(m.nextSibling);
              m = m.firstChild;
            } else {
              m = m.nextSibling;
            }
          }
        }
        break;
      case Step.PRECEDINGSIBLING:
        if (xpc.contextNode === xpc.virtualRoot) {
          break;
        }
        for (var m = xpc.contextNode.previousSibling; m != null; m = m.previousSibling) {
          if (step.nodeTest.matches(m, xpc)) {
            newNodes.push(m);
          }
        }
        break;
      case Step.SELF:
        if (step.nodeTest.matches(xpc.contextNode, xpc)) {
          newNodes.push(xpc.contextNode);
        }
        break;
      default:
    }
    return newNodes;
  };
  function applyStepWithPredicates(step, xpc, node) {
    return PathExpr.applyPredicates(step.predicates, xpc, PathExpr.applyStep(step, xpc, node));
  }
  function applyStepToNodes(context, nodes, step) {
    return flatten(map(applyStepWithPredicates.bind(null, step, context), nodes));
  }
  PathExpr.applySteps = function (steps, xpc, nodes) {
    return reduce(applyStepToNodes.bind(null, xpc), nodes, steps);
  };
  PathExpr.prototype.applyFilter = function (c, xpc) {
    if (!this.filter) {
      return {
        nodes: [c.contextNode]
      };
    }
    var ns = this.filter.evaluate(c);
    if (!Utilities.instance_of(ns, XNodeSet)) {
      if (this.filterPredicates != null && this.filterPredicates.length > 0 || this.locationPath != null) {
        throw new Error("Path expression filter must evaluate to a nodeset if predicates or location path are used");
      }
      return {
        nonNodes: ns
      };
    }
    return {
      nodes: PathExpr.applyPredicates(this.filterPredicates || [], xpc, ns.toUnsortedArray())
    };
  };
  PathExpr.applyLocationPath = function (locationPath, xpc, nodes) {
    if (!locationPath) {
      return nodes;
    }
    var startNodes = locationPath.absolute ? [PathExpr.getRoot(xpc, nodes)] : nodes;
    return PathExpr.applySteps(locationPath.steps, xpc, startNodes);
  };
  PathExpr.prototype.evaluate = function (c) {
    var xpc = assign(new XPathContext(), c);
    var filterResult = this.applyFilter(c, xpc);
    if ('nonNodes' in filterResult) {
      return filterResult.nonNodes;
    }
    var ns = new XNodeSet();
    ns.addArray(PathExpr.applyLocationPath(this.locationPath, xpc, filterResult.nodes));
    return ns;
  };
  PathExpr.predicateMatches = function (pred, c) {
    var res = pred.evaluate(c);
    return Utilities.instance_of(res, XNumber) ? c.contextPosition === res.numberValue() : res.booleanValue();
  };
  PathExpr.predicateString = function (predicate) {
    return wrap('[', ']', predicate.toString());
  };
  PathExpr.predicatesString = function (predicates) {
    return join('', map(PathExpr.predicateString, predicates));
  };
  PathExpr.prototype.toString = function () {
    if (this.filter != undefined) {
      var filterStr = toString(this.filter);
      if (Utilities.instance_of(this.filter, XString)) {
        return wrap("'", "'", filterStr);
      }
      if (this.filterPredicates != undefined && this.filterPredicates.length) {
        return wrap('(', ')', filterStr) + PathExpr.predicatesString(this.filterPredicates);
      }
      if (this.locationPath != undefined) {
        return filterStr + (this.locationPath.absolute ? '' : '/') + toString(this.locationPath);
      }
      return filterStr;
    }
    return toString(this.locationPath);
  };
  PathExpr.getOwnerElement = function (n) {
    if (n.ownerElement) {
      return n.ownerElement;
    }
    try {
      if (n.selectSingleNode) {
        return n.selectSingleNode("..");
      }
    } catch (e) {}
    var doc = n.nodeType == 9 ? n : n.ownerDocument;
    var elts = doc.getElementsByTagName("*");
    for (var i = 0; i < elts.length; i++) {
      var elt = elts.item(i);
      var nnm = elt.attributes;
      for (var j = 0; j < nnm.length; j++) {
        var an = nnm.item(j);
        if (an === n) {
          return elt;
        }
      }
    }
    return null;
  };
  LocationPath.prototype = new Object();
  LocationPath.prototype.constructor = LocationPath;
  LocationPath.superclass = Object.prototype;
  function LocationPath(abs, steps) {
    if (arguments.length > 0) {
      this.init(abs, steps);
    }
  }
  LocationPath.prototype.init = function (abs, steps) {
    this.absolute = abs;
    this.steps = steps;
  };
  LocationPath.prototype.toString = function () {
    return (this.absolute ? '/' : '') + map(toString, this.steps).join('/');
  };
  Step.prototype = new Object();
  Step.prototype.constructor = Step;
  Step.superclass = Object.prototype;
  function Step(axis, nodetest, preds) {
    if (arguments.length > 0) {
      this.init(axis, nodetest, preds);
    }
  }
  Step.prototype.init = function (axis, nodetest, preds) {
    this.axis = axis;
    this.nodeTest = nodetest;
    this.predicates = preds;
  };
  Step.prototype.toString = function () {
    return Step.STEPNAMES[this.axis] + "::" + this.nodeTest.toString() + PathExpr.predicatesString(this.predicates);
  };
  Step.ANCESTOR = 0;
  Step.ANCESTORORSELF = 1;
  Step.ATTRIBUTE = 2;
  Step.CHILD = 3;
  Step.DESCENDANT = 4;
  Step.DESCENDANTORSELF = 5;
  Step.FOLLOWING = 6;
  Step.FOLLOWINGSIBLING = 7;
  Step.NAMESPACE = 8;
  Step.PARENT = 9;
  Step.PRECEDING = 10;
  Step.PRECEDINGSIBLING = 11;
  Step.SELF = 12;
  Step.STEPNAMES = reduce(function (acc, x) {
    return acc[x[0]] = x[1], acc;
  }, {}, [[Step.ANCESTOR, 'ancestor'], [Step.ANCESTORORSELF, 'ancestor-or-self'], [Step.ATTRIBUTE, 'attribute'], [Step.CHILD, 'child'], [Step.DESCENDANT, 'descendant'], [Step.DESCENDANTORSELF, 'descendant-or-self'], [Step.FOLLOWING, 'following'], [Step.FOLLOWINGSIBLING, 'following-sibling'], [Step.NAMESPACE, 'namespace'], [Step.PARENT, 'parent'], [Step.PRECEDING, 'preceding'], [Step.PRECEDINGSIBLING, 'preceding-sibling'], [Step.SELF, 'self']]);
  NodeTest.prototype = new Object();
  NodeTest.prototype.constructor = NodeTest;
  NodeTest.superclass = Object.prototype;
  function NodeTest(type, value) {
    if (arguments.length > 0) {
      this.init(type, value);
    }
  }
  NodeTest.prototype.init = function (type, value) {
    this.type = type;
    this.value = value;
  };
  NodeTest.prototype.toString = function () {
    return "<unknown nodetest type>";
  };
  NodeTest.prototype.matches = function (n, xpc) {
    console.warn('unknown node test type');
  };
  NodeTest.NAMETESTANY = 0;
  NodeTest.NAMETESTPREFIXANY = 1;
  NodeTest.NAMETESTQNAME = 2;
  NodeTest.COMMENT = 3;
  NodeTest.TEXT = 4;
  NodeTest.PI = 5;
  NodeTest.NODE = 6;
  NodeTest.isNodeType = function (types) {
    return function (node) {
      return includes(types, node.nodeType);
    };
  };
  NodeTest.makeNodeTestType = function (type, members, ctor) {
    var newType = ctor || function () {};
    newType.prototype = new NodeTest(type);
    newType.prototype.constructor = newType;
    assign(newType.prototype, members);
    return newType;
  };
  NodeTest.makeNodeTypeTest = function (type, nodeTypes, stringVal) {
    return new (NodeTest.makeNodeTestType(type, {
      matches: NodeTest.isNodeType(nodeTypes),
      toString: always(stringVal)
    }))();
  };
  NodeTest.hasPrefix = function (node) {
    return node.prefix || (node.nodeName || node.tagName).indexOf(':') !== -1;
  };
  NodeTest.isElementOrAttribute = NodeTest.isNodeType([1, 2]);
  NodeTest.nameSpaceMatches = function (prefix, xpc, n) {
    var nNamespace = n.namespaceURI || '';
    if (!prefix) {
      return !nNamespace || xpc.allowAnyNamespaceForNoPrefix && !NodeTest.hasPrefix(n);
    }
    var ns = xpc.namespaceResolver.getNamespace(prefix, xpc.expressionContextNode);
    if (ns == null) {
      throw new Error("Cannot resolve QName " + prefix);
    }
    return ns === nNamespace;
  };
  NodeTest.localNameMatches = function (localName, xpc, n) {
    var nLocalName = n.localName || n.nodeName;
    return xpc.caseInsensitive ? localName.toLowerCase() === nLocalName.toLowerCase() : localName === nLocalName;
  };
  NodeTest.NameTestPrefixAny = NodeTest.makeNodeTestType(NodeTest.NAMETESTPREFIXANY, {
    matches: function (n, xpc) {
      return NodeTest.isElementOrAttribute(n) && NodeTest.nameSpaceMatches(this.prefix, xpc, n);
    },
    toString: function () {
      return this.prefix + ":*";
    }
  }, function NameTestPrefixAny(prefix) {
    this.prefix = prefix;
  });
  NodeTest.NameTestQName = NodeTest.makeNodeTestType(NodeTest.NAMETESTQNAME, {
    matches: function (n, xpc) {
      return NodeTest.isNodeType([1, 2, XPathNamespace.XPATH_NAMESPACE_NODE])(n) && NodeTest.nameSpaceMatches(this.prefix, xpc, n) && NodeTest.localNameMatches(this.localName, xpc, n);
    },
    toString: function () {
      return this.name;
    }
  }, function NameTestQName(name) {
    var nameParts = name.split(':');
    this.name = name;
    this.prefix = nameParts.length > 1 ? nameParts[0] : null;
    this.localName = nameParts[nameParts.length > 1 ? 1 : 0];
  });
  NodeTest.PITest = NodeTest.makeNodeTestType(NodeTest.PI, {
    matches: function (n, xpc) {
      return NodeTest.isNodeType([7])(n) && (n.target || n.nodeName) === this.name;
    },
    toString: function () {
      return wrap('processing-instruction("', '")', this.name);
    }
  }, function (name) {
    this.name = name;
  });
  NodeTest.nameTestAny = NodeTest.makeNodeTypeTest(NodeTest.NAMETESTANY, [1, 2, XPathNamespace.XPATH_NAMESPACE_NODE], '*');
  NodeTest.textTest = NodeTest.makeNodeTypeTest(NodeTest.TEXT, [3, 4], 'text()');
  NodeTest.commentTest = NodeTest.makeNodeTypeTest(NodeTest.COMMENT, [8], 'comment()');
  NodeTest.nodeTest = NodeTest.makeNodeTypeTest(NodeTest.NODE, [1, 2, 3, 4, 7, 8, 9], 'node()');
  NodeTest.anyPiTest = NodeTest.makeNodeTypeTest(NodeTest.PI, [7], 'processing-instruction()');
  VariableReference.prototype = new Expression();
  VariableReference.prototype.constructor = VariableReference;
  VariableReference.superclass = Expression.prototype;
  function VariableReference(v) {
    if (arguments.length > 0) {
      this.init(v);
    }
  }
  VariableReference.prototype.init = function (v) {
    this.variable = v;
  };
  VariableReference.prototype.toString = function () {
    return "$" + this.variable;
  };
  VariableReference.prototype.evaluate = function (c) {
    var parts = Utilities.resolveQName(this.variable, c.namespaceResolver, c.contextNode, false);
    if (parts[0] == null) {
      throw new Error("Cannot resolve QName " + fn);
    }
    var result = c.variableResolver.getVariable(parts[1], parts[0]);
    if (!result) {
      throw XPathException.fromMessage("Undeclared variable: " + this.toString());
    }
    return result;
  };
  FunctionCall.prototype = new Expression();
  FunctionCall.prototype.constructor = FunctionCall;
  FunctionCall.superclass = Expression.prototype;
  function FunctionCall(fn, args) {
    if (arguments.length > 0) {
      this.init(fn, args);
    }
  }
  FunctionCall.prototype.init = function (fn, args) {
    this.functionName = fn;
    this.arguments = args;
  };
  FunctionCall.prototype.toString = function () {
    var s = this.functionName + "(";
    for (var i = 0; i < this.arguments.length; i++) {
      if (i > 0) {
        s += ", ";
      }
      s += this.arguments[i].toString();
    }
    return s + ")";
  };
  FunctionCall.prototype.evaluate = function (c) {
    var f = FunctionResolver.getFunctionFromContext(this.functionName, c);
    if (!f) {
      throw new Error("Unknown function " + this.functionName);
    }
    var a = [c].concat(this.arguments);
    return f.apply(c.functionResolver.thisArg, a);
  };
  var Operators = new Object();
  Operators.equals = function (l, r) {
    return l.equals(r);
  };
  Operators.notequal = function (l, r) {
    return l.notequal(r);
  };
  Operators.lessthan = function (l, r) {
    return l.lessthan(r);
  };
  Operators.greaterthan = function (l, r) {
    return l.greaterthan(r);
  };
  Operators.lessthanorequal = function (l, r) {
    return l.lessthanorequal(r);
  };
  Operators.greaterthanorequal = function (l, r) {
    return l.greaterthanorequal(r);
  };
  XString.prototype = new Expression();
  XString.prototype.constructor = XString;
  XString.superclass = Expression.prototype;
  function XString(s) {
    if (arguments.length > 0) {
      this.init(s);
    }
  }
  XString.prototype.init = function (s) {
    this.str = String(s);
  };
  XString.prototype.toString = function () {
    return this.str;
  };
  XString.prototype.evaluate = function (c) {
    return this;
  };
  XString.prototype.string = function () {
    return this;
  };
  XString.prototype.number = function () {
    return new XNumber(this.str);
  };
  XString.prototype.bool = function () {
    return new XBoolean(this.str);
  };
  XString.prototype.nodeset = function () {
    throw new Error("Cannot convert string to nodeset");
  };
  XString.prototype.stringValue = function () {
    return this.str;
  };
  XString.prototype.numberValue = function () {
    return this.number().numberValue();
  };
  XString.prototype.booleanValue = function () {
    return this.bool().booleanValue();
  };
  XString.prototype.equals = function (r) {
    if (Utilities.instance_of(r, XBoolean)) {
      return this.bool().equals(r);
    }
    if (Utilities.instance_of(r, XNumber)) {
      return this.number().equals(r);
    }
    if (Utilities.instance_of(r, XNodeSet)) {
      return r.compareWithString(this, Operators.equals);
    }
    return new XBoolean(this.str == r.str);
  };
  XString.prototype.notequal = function (r) {
    if (Utilities.instance_of(r, XBoolean)) {
      return this.bool().notequal(r);
    }
    if (Utilities.instance_of(r, XNumber)) {
      return this.number().notequal(r);
    }
    if (Utilities.instance_of(r, XNodeSet)) {
      return r.compareWithString(this, Operators.notequal);
    }
    return new XBoolean(this.str != r.str);
  };
  XString.prototype.lessthan = function (r) {
    return this.number().lessthan(r);
  };
  XString.prototype.greaterthan = function (r) {
    return this.number().greaterthan(r);
  };
  XString.prototype.lessthanorequal = function (r) {
    return this.number().lessthanorequal(r);
  };
  XString.prototype.greaterthanorequal = function (r) {
    return this.number().greaterthanorequal(r);
  };
  XNumber.prototype = new Expression();
  XNumber.prototype.constructor = XNumber;
  XNumber.superclass = Expression.prototype;
  function XNumber(n) {
    if (arguments.length > 0) {
      this.init(n);
    }
  }
  XNumber.prototype.init = function (n) {
    this.num = typeof n === "string" ? this.parse(n) : Number(n);
  };
  XNumber.prototype.numberFormat = /^\s*-?[0-9]*\.?[0-9]+\s*$/;
  XNumber.prototype.parse = function (s) {
    return this.numberFormat.test(s) ? parseFloat(s) : Number.NaN;
  };
  function padSmallNumber(numberStr) {
    var parts = numberStr.split('e-');
    var base = parts[0].replace('.', '');
    var exponent = Number(parts[1]);
    for (var i = 0; i < exponent - 1; i += 1) {
      base = '0' + base;
    }
    return '0.' + base;
  }
  function padLargeNumber(numberStr) {
    var parts = numberStr.split('e');
    var base = parts[0].replace('.', '');
    var exponent = Number(parts[1]);
    var zerosToAppend = exponent + 1 - base.length;
    for (var i = 0; i < zerosToAppend; i += 1) {
      base += '0';
    }
    return base;
  }
  XNumber.prototype.toString = function () {
    var strValue = this.num.toString();
    if (strValue.indexOf('e-') !== -1) {
      return padSmallNumber(strValue);
    }
    if (strValue.indexOf('e') !== -1) {
      return padLargeNumber(strValue);
    }
    return strValue;
  };
  XNumber.prototype.evaluate = function (c) {
    return this;
  };
  XNumber.prototype.string = function () {
    return new XString(this.toString());
  };
  XNumber.prototype.number = function () {
    return this;
  };
  XNumber.prototype.bool = function () {
    return new XBoolean(this.num);
  };
  XNumber.prototype.nodeset = function () {
    throw new Error("Cannot convert number to nodeset");
  };
  XNumber.prototype.stringValue = function () {
    return this.string().stringValue();
  };
  XNumber.prototype.numberValue = function () {
    return this.num;
  };
  XNumber.prototype.booleanValue = function () {
    return this.bool().booleanValue();
  };
  XNumber.prototype.negate = function () {
    return new XNumber(-this.num);
  };
  XNumber.prototype.equals = function (r) {
    if (Utilities.instance_of(r, XBoolean)) {
      return this.bool().equals(r);
    }
    if (Utilities.instance_of(r, XString)) {
      return this.equals(r.number());
    }
    if (Utilities.instance_of(r, XNodeSet)) {
      return r.compareWithNumber(this, Operators.equals);
    }
    return new XBoolean(this.num == r.num);
  };
  XNumber.prototype.notequal = function (r) {
    if (Utilities.instance_of(r, XBoolean)) {
      return this.bool().notequal(r);
    }
    if (Utilities.instance_of(r, XString)) {
      return this.notequal(r.number());
    }
    if (Utilities.instance_of(r, XNodeSet)) {
      return r.compareWithNumber(this, Operators.notequal);
    }
    return new XBoolean(this.num != r.num);
  };
  XNumber.prototype.lessthan = function (r) {
    if (Utilities.instance_of(r, XNodeSet)) {
      return r.compareWithNumber(this, Operators.greaterthan);
    }
    if (Utilities.instance_of(r, XBoolean) || Utilities.instance_of(r, XString)) {
      return this.lessthan(r.number());
    }
    return new XBoolean(this.num < r.num);
  };
  XNumber.prototype.greaterthan = function (r) {
    if (Utilities.instance_of(r, XNodeSet)) {
      return r.compareWithNumber(this, Operators.lessthan);
    }
    if (Utilities.instance_of(r, XBoolean) || Utilities.instance_of(r, XString)) {
      return this.greaterthan(r.number());
    }
    return new XBoolean(this.num > r.num);
  };
  XNumber.prototype.lessthanorequal = function (r) {
    if (Utilities.instance_of(r, XNodeSet)) {
      return r.compareWithNumber(this, Operators.greaterthanorequal);
    }
    if (Utilities.instance_of(r, XBoolean) || Utilities.instance_of(r, XString)) {
      return this.lessthanorequal(r.number());
    }
    return new XBoolean(this.num <= r.num);
  };
  XNumber.prototype.greaterthanorequal = function (r) {
    if (Utilities.instance_of(r, XNodeSet)) {
      return r.compareWithNumber(this, Operators.lessthanorequal);
    }
    if (Utilities.instance_of(r, XBoolean) || Utilities.instance_of(r, XString)) {
      return this.greaterthanorequal(r.number());
    }
    return new XBoolean(this.num >= r.num);
  };
  XNumber.prototype.plus = function (r) {
    return new XNumber(this.num + r.num);
  };
  XNumber.prototype.minus = function (r) {
    return new XNumber(this.num - r.num);
  };
  XNumber.prototype.multiply = function (r) {
    return new XNumber(this.num * r.num);
  };
  XNumber.prototype.div = function (r) {
    return new XNumber(this.num / r.num);
  };
  XNumber.prototype.mod = function (r) {
    return new XNumber(this.num % r.num);
  };
  XBoolean.prototype = new Expression();
  XBoolean.prototype.constructor = XBoolean;
  XBoolean.superclass = Expression.prototype;
  function XBoolean(b) {
    if (arguments.length > 0) {
      this.init(b);
    }
  }
  XBoolean.prototype.init = function (b) {
    this.b = Boolean(b);
  };
  XBoolean.prototype.toString = function () {
    return this.b.toString();
  };
  XBoolean.prototype.evaluate = function (c) {
    return this;
  };
  XBoolean.prototype.string = function () {
    return new XString(this.b);
  };
  XBoolean.prototype.number = function () {
    return new XNumber(this.b);
  };
  XBoolean.prototype.bool = function () {
    return this;
  };
  XBoolean.prototype.nodeset = function () {
    throw new Error("Cannot convert boolean to nodeset");
  };
  XBoolean.prototype.stringValue = function () {
    return this.string().stringValue();
  };
  XBoolean.prototype.numberValue = function () {
    return this.number().numberValue();
  };
  XBoolean.prototype.booleanValue = function () {
    return this.b;
  };
  XBoolean.prototype.not = function () {
    return new XBoolean(!this.b);
  };
  XBoolean.prototype.equals = function (r) {
    if (Utilities.instance_of(r, XString) || Utilities.instance_of(r, XNumber)) {
      return this.equals(r.bool());
    }
    if (Utilities.instance_of(r, XNodeSet)) {
      return r.compareWithBoolean(this, Operators.equals);
    }
    return new XBoolean(this.b == r.b);
  };
  XBoolean.prototype.notequal = function (r) {
    if (Utilities.instance_of(r, XString) || Utilities.instance_of(r, XNumber)) {
      return this.notequal(r.bool());
    }
    if (Utilities.instance_of(r, XNodeSet)) {
      return r.compareWithBoolean(this, Operators.notequal);
    }
    return new XBoolean(this.b != r.b);
  };
  XBoolean.prototype.lessthan = function (r) {
    return this.number().lessthan(r);
  };
  XBoolean.prototype.greaterthan = function (r) {
    return this.number().greaterthan(r);
  };
  XBoolean.prototype.lessthanorequal = function (r) {
    return this.number().lessthanorequal(r);
  };
  XBoolean.prototype.greaterthanorequal = function (r) {
    return this.number().greaterthanorequal(r);
  };
  XBoolean.true_ = new XBoolean(true);
  XBoolean.false_ = new XBoolean(false);
  AVLTree.prototype = new Object();
  AVLTree.prototype.constructor = AVLTree;
  AVLTree.superclass = Object.prototype;
  function AVLTree(n) {
    this.init(n);
  }
  AVLTree.prototype.init = function (n) {
    this.left = null;
    this.right = null;
    this.node = n;
    this.depth = 1;
  };
  AVLTree.prototype.balance = function () {
    var ldepth = this.left == null ? 0 : this.left.depth;
    var rdepth = this.right == null ? 0 : this.right.depth;
    if (ldepth > rdepth + 1) {
      var lldepth = this.left.left == null ? 0 : this.left.left.depth;
      var lrdepth = this.left.right == null ? 0 : this.left.right.depth;
      if (lldepth < lrdepth) {
        this.left.rotateRR();
      }
      this.rotateLL();
    } else if (ldepth + 1 < rdepth) {
      var rrdepth = this.right.right == null ? 0 : this.right.right.depth;
      var rldepth = this.right.left == null ? 0 : this.right.left.depth;
      if (rldepth > rrdepth) {
        this.right.rotateLL();
      }
      this.rotateRR();
    }
  };
  AVLTree.prototype.rotateLL = function () {
    var nodeBefore = this.node;
    var rightBefore = this.right;
    this.node = this.left.node;
    this.right = this.left;
    this.left = this.left.left;
    this.right.left = this.right.right;
    this.right.right = rightBefore;
    this.right.node = nodeBefore;
    this.right.updateInNewLocation();
    this.updateInNewLocation();
  };
  AVLTree.prototype.rotateRR = function () {
    var nodeBefore = this.node;
    var leftBefore = this.left;
    this.node = this.right.node;
    this.left = this.right;
    this.right = this.right.right;
    this.left.right = this.left.left;
    this.left.left = leftBefore;
    this.left.node = nodeBefore;
    this.left.updateInNewLocation();
    this.updateInNewLocation();
  };
  AVLTree.prototype.updateInNewLocation = function () {
    this.getDepthFromChildren();
  };
  AVLTree.prototype.getDepthFromChildren = function () {
    this.depth = this.node == null ? 0 : 1;
    if (this.left != null) {
      this.depth = this.left.depth + 1;
    }
    if (this.right != null && this.depth <= this.right.depth) {
      this.depth = this.right.depth + 1;
    }
  };
  function nodeOrder(n1, n2) {
    if (n1 === n2) {
      return 0;
    }
    if (n1.compareDocumentPosition) {
      var cpos = n1.compareDocumentPosition(n2);
      if (cpos & 0x01) {
        return 1;
      }
      if (cpos & 0x0A) {
        return 1;
      }
      if (cpos & 0x14) {
        return -1;
      }
      return 0;
    }
    var d1 = 0,
      d2 = 0;
    for (var m1 = n1; m1 != null; m1 = m1.parentNode || m1.ownerElement) {
      d1++;
    }
    for (var m2 = n2; m2 != null; m2 = m2.parentNode || m2.ownerElement) {
      d2++;
    }
    if (d1 > d2) {
      while (d1 > d2) {
        n1 = n1.parentNode || n1.ownerElement;
        d1--;
      }
      if (n1 === n2) {
        return 1;
      }
    } else if (d2 > d1) {
      while (d2 > d1) {
        n2 = n2.parentNode || n2.ownerElement;
        d2--;
      }
      if (n1 === n2) {
        return -1;
      }
    }
    var n1Par = n1.parentNode || n1.ownerElement,
      n2Par = n2.parentNode || n2.ownerElement;
    while (n1Par !== n2Par) {
      n1 = n1Par;
      n2 = n2Par;
      n1Par = n1.parentNode || n1.ownerElement;
      n2Par = n2.parentNode || n2.ownerElement;
    }
    var n1isAttr = Utilities.isAttribute(n1);
    var n2isAttr = Utilities.isAttribute(n2);
    if (n1isAttr && !n2isAttr) {
      return -1;
    }
    if (!n1isAttr && n2isAttr) {
      return 1;
    }
    if (n1Par) {
      var cn = n1isAttr ? n1Par.attributes : n1Par.childNodes,
        len = cn.length;
      for (var i = 0; i < len; i += 1) {
        var n = cn[i];
        if (n === n1) {
          return -1;
        }
        if (n === n2) {
          return 1;
        }
      }
    }
    throw new Error('Unexpected: could not determine node order');
  }
  AVLTree.prototype.add = function (n) {
    if (n === this.node) {
      return false;
    }
    var o = nodeOrder(n, this.node);
    var ret = false;
    if (o == -1) {
      if (this.left == null) {
        this.left = new AVLTree(n);
        ret = true;
      } else {
        ret = this.left.add(n);
        if (ret) {
          this.balance();
        }
      }
    } else if (o == 1) {
      if (this.right == null) {
        this.right = new AVLTree(n);
        ret = true;
      } else {
        ret = this.right.add(n);
        if (ret) {
          this.balance();
        }
      }
    }
    if (ret) {
      this.getDepthFromChildren();
    }
    return ret;
  };
  XNodeSet.prototype = new Expression();
  XNodeSet.prototype.constructor = XNodeSet;
  XNodeSet.superclass = Expression.prototype;
  function XNodeSet() {
    this.init();
  }
  XNodeSet.prototype.init = function () {
    this.tree = null;
    this.nodes = [];
    this.size = 0;
  };
  XNodeSet.prototype.toString = function () {
    var p = this.first();
    if (p == null) {
      return "";
    }
    return this.stringForNode(p);
  };
  XNodeSet.prototype.evaluate = function (c) {
    return this;
  };
  XNodeSet.prototype.string = function () {
    return new XString(this.toString());
  };
  XNodeSet.prototype.stringValue = function () {
    return this.toString();
  };
  XNodeSet.prototype.number = function () {
    return new XNumber(this.string());
  };
  XNodeSet.prototype.numberValue = function () {
    return Number(this.string());
  };
  XNodeSet.prototype.bool = function () {
    return new XBoolean(this.booleanValue());
  };
  XNodeSet.prototype.booleanValue = function () {
    return !!this.size;
  };
  XNodeSet.prototype.nodeset = function () {
    return this;
  };
  XNodeSet.prototype.stringForNode = function (n) {
    if (n.nodeType == 9 || n.nodeType == 1 || n.nodeType === 11) {
      return this.stringForContainerNode(n);
    }
    if (n.nodeType === 2) {
      return n.value || n.nodeValue;
    }
    if (n.isNamespaceNode) {
      return n.namespace;
    }
    return n.nodeValue;
  };
  XNodeSet.prototype.stringForContainerNode = function (n) {
    var s = "";
    for (var n2 = n.firstChild; n2 != null; n2 = n2.nextSibling) {
      var nt = n2.nodeType;
      if (nt === 1 || nt === 3 || nt === 4 || nt === 9 || nt === 11) {
        s += this.stringForNode(n2);
      }
    }
    return s;
  };
  XNodeSet.prototype.buildTree = function () {
    if (!this.tree && this.nodes.length) {
      this.tree = new AVLTree(this.nodes[0]);
      for (var i = 1; i < this.nodes.length; i += 1) {
        this.tree.add(this.nodes[i]);
      }
    }
    return this.tree;
  };
  XNodeSet.prototype.first = function () {
    var p = this.buildTree();
    if (p == null) {
      return null;
    }
    while (p.left != null) {
      p = p.left;
    }
    return p.node;
  };
  XNodeSet.prototype.add = function (n) {
    for (var i = 0; i < this.nodes.length; i += 1) {
      if (n === this.nodes[i]) {
        return;
      }
    }
    this.tree = null;
    this.nodes.push(n);
    this.size += 1;
  };
  XNodeSet.prototype.addArray = function (ns) {
    var self = this;
    forEach(function (x) {
      self.add(x);
    }, ns);
  };
  XNodeSet.prototype.toArray = function () {
    var a = [];
    this.toArrayRec(this.buildTree(), a);
    return a;
  };
  XNodeSet.prototype.toArrayRec = function (t, a) {
    if (t != null) {
      this.toArrayRec(t.left, a);
      a.push(t.node);
      this.toArrayRec(t.right, a);
    }
  };
  XNodeSet.prototype.toUnsortedArray = function () {
    return this.nodes.slice();
  };
  XNodeSet.prototype.compareWithString = function (r, o) {
    var a = this.toUnsortedArray();
    for (var i = 0; i < a.length; i++) {
      var n = a[i];
      var l = new XString(this.stringForNode(n));
      var res = o(l, r);
      if (res.booleanValue()) {
        return res;
      }
    }
    return new XBoolean(false);
  };
  XNodeSet.prototype.compareWithNumber = function (r, o) {
    var a = this.toUnsortedArray();
    for (var i = 0; i < a.length; i++) {
      var n = a[i];
      var l = new XNumber(this.stringForNode(n));
      var res = o(l, r);
      if (res.booleanValue()) {
        return res;
      }
    }
    return new XBoolean(false);
  };
  XNodeSet.prototype.compareWithBoolean = function (r, o) {
    return o(this.bool(), r);
  };
  XNodeSet.prototype.compareWithNodeSet = function (r, o) {
    var arr = this.toUnsortedArray();
    var oInvert = function (lop, rop) {
      return o(rop, lop);
    };
    for (var i = 0; i < arr.length; i++) {
      var l = new XString(this.stringForNode(arr[i]));
      var res = r.compareWithString(l, oInvert);
      if (res.booleanValue()) {
        return res;
      }
    }
    return new XBoolean(false);
  };
  XNodeSet.compareWith = curry(function (o, r) {
    if (Utilities.instance_of(r, XString)) {
      return this.compareWithString(r, o);
    }
    if (Utilities.instance_of(r, XNumber)) {
      return this.compareWithNumber(r, o);
    }
    if (Utilities.instance_of(r, XBoolean)) {
      return this.compareWithBoolean(r, o);
    }
    return this.compareWithNodeSet(r, o);
  });
  XNodeSet.prototype.equals = XNodeSet.compareWith(Operators.equals);
  XNodeSet.prototype.notequal = XNodeSet.compareWith(Operators.notequal);
  XNodeSet.prototype.lessthan = XNodeSet.compareWith(Operators.lessthan);
  XNodeSet.prototype.greaterthan = XNodeSet.compareWith(Operators.greaterthan);
  XNodeSet.prototype.lessthanorequal = XNodeSet.compareWith(Operators.lessthanorequal);
  XNodeSet.prototype.greaterthanorequal = XNodeSet.compareWith(Operators.greaterthanorequal);
  XNodeSet.prototype.union = function (r) {
    var ns = new XNodeSet();
    ns.addArray(this.toUnsortedArray());
    ns.addArray(r.toUnsortedArray());
    return ns;
  };
  XPathNamespace.prototype = new Object();
  XPathNamespace.prototype.constructor = XPathNamespace;
  XPathNamespace.superclass = Object.prototype;
  function XPathNamespace(pre, ns, p) {
    this.isXPathNamespace = true;
    this.ownerDocument = p.ownerDocument;
    this.nodeName = "#namespace";
    this.prefix = pre;
    this.localName = pre;
    this.namespaceURI = ns;
    this.nodeValue = ns;
    this.ownerElement = p;
    this.nodeType = XPathNamespace.XPATH_NAMESPACE_NODE;
  }
  XPathNamespace.prototype.toString = function () {
    return "{ \"" + this.prefix + "\", \"" + this.namespaceURI + "\" }";
  };
  XPathContext.prototype = new Object();
  XPathContext.prototype.constructor = XPathContext;
  XPathContext.superclass = Object.prototype;
  function XPathContext(vr, nr, fr) {
    this.variableResolver = vr != null ? vr : new VariableResolver();
    this.namespaceResolver = nr != null ? nr : new NamespaceResolver();
    this.functionResolver = fr != null ? fr : new FunctionResolver();
  }
  XPathContext.prototype.extend = function (newProps) {
    return assign(new XPathContext(), this, newProps);
  };
  VariableResolver.prototype = new Object();
  VariableResolver.prototype.constructor = VariableResolver;
  VariableResolver.superclass = Object.prototype;
  function VariableResolver() {}
  VariableResolver.prototype.getVariable = function (ln, ns) {
    return null;
  };
  FunctionResolver.prototype = new Object();
  FunctionResolver.prototype.constructor = FunctionResolver;
  FunctionResolver.superclass = Object.prototype;
  function FunctionResolver(thisArg) {
    this.thisArg = thisArg != null ? thisArg : Functions;
    this.functions = new Object();
    this.addStandardFunctions();
  }
  FunctionResolver.prototype.addStandardFunctions = function () {
    this.functions["{}last"] = Functions.last;
    this.functions["{}position"] = Functions.position;
    this.functions["{}count"] = Functions.count;
    this.functions["{}id"] = Functions.id;
    this.functions["{}local-name"] = Functions.localName;
    this.functions["{}namespace-uri"] = Functions.namespaceURI;
    this.functions["{}name"] = Functions.name;
    this.functions["{}string"] = Functions.string;
    this.functions["{}concat"] = Functions.concat;
    this.functions["{}starts-with"] = Functions.startsWith;
    this.functions["{}contains"] = Functions.contains;
    this.functions["{}substring-before"] = Functions.substringBefore;
    this.functions["{}substring-after"] = Functions.substringAfter;
    this.functions["{}substring"] = Functions.substring;
    this.functions["{}string-length"] = Functions.stringLength;
    this.functions["{}normalize-space"] = Functions.normalizeSpace;
    this.functions["{}translate"] = Functions.translate;
    this.functions["{}boolean"] = Functions.boolean_;
    this.functions["{}not"] = Functions.not;
    this.functions["{}true"] = Functions.true_;
    this.functions["{}false"] = Functions.false_;
    this.functions["{}lang"] = Functions.lang;
    this.functions["{}number"] = Functions.number;
    this.functions["{}sum"] = Functions.sum;
    this.functions["{}floor"] = Functions.floor;
    this.functions["{}ceiling"] = Functions.ceiling;
    this.functions["{}round"] = Functions.round;
  };
  FunctionResolver.prototype.addFunction = function (ns, ln, f) {
    this.functions["{" + ns + "}" + ln] = f;
  };
  FunctionResolver.getFunctionFromContext = function (qName, context) {
    var parts = Utilities.resolveQName(qName, context.namespaceResolver, context.contextNode, false);
    if (parts[0] === null) {
      throw new Error("Cannot resolve QName " + name);
    }
    return context.functionResolver.getFunction(parts[1], parts[0]);
  };
  FunctionResolver.prototype.getFunction = function (localName, namespace) {
    return this.functions["{" + namespace + "}" + localName];
  };
  NamespaceResolver.prototype = new Object();
  NamespaceResolver.prototype.constructor = NamespaceResolver;
  NamespaceResolver.superclass = Object.prototype;
  function NamespaceResolver() {}
  NamespaceResolver.prototype.getNamespace = function (prefix, n) {
    if (prefix == "xml") {
      return XPath.XML_NAMESPACE_URI;
    } else if (prefix == "xmlns") {
      return XPath.XMLNS_NAMESPACE_URI;
    }
    if (n.nodeType == 9) {
      n = n.documentElement;
    } else if (n.nodeType == 2) {
      n = PathExpr.getOwnerElement(n);
    } else if (n.nodeType != 1) {
      n = n.parentNode;
    }
    while (n != null && n.nodeType == 1) {
      var nnm = n.attributes;
      for (var i = 0; i < nnm.length; i++) {
        var a = nnm.item(i);
        var aname = a.name || a.nodeName;
        if (aname === "xmlns" && prefix === "" || aname === "xmlns:" + prefix) {
          return String(a.value || a.nodeValue);
        }
      }
      n = n.parentNode;
    }
    return null;
  };
  var Functions = new Object();
  Functions.last = function (c) {
    if (arguments.length != 1) {
      throw new Error("Function last expects ()");
    }
    return new XNumber(c.contextSize);
  };
  Functions.position = function (c) {
    if (arguments.length != 1) {
      throw new Error("Function position expects ()");
    }
    return new XNumber(c.contextPosition);
  };
  Functions.count = function () {
    var c = arguments[0];
    var ns;
    if (arguments.length != 2 || !Utilities.instance_of(ns = arguments[1].evaluate(c), XNodeSet)) {
      throw new Error("Function count expects (node-set)");
    }
    return new XNumber(ns.size);
  };
  Functions.id = function () {
    var c = arguments[0];
    var id;
    if (arguments.length != 2) {
      throw new Error("Function id expects (object)");
    }
    id = arguments[1].evaluate(c);
    if (Utilities.instance_of(id, XNodeSet)) {
      id = id.toArray().join(" ");
    } else {
      id = id.stringValue();
    }
    var ids = id.split(/[\x0d\x0a\x09\x20]+/);
    var count = 0;
    var ns = new XNodeSet();
    var doc = c.contextNode.nodeType == 9 ? c.contextNode : c.contextNode.ownerDocument;
    for (var i = 0; i < ids.length; i++) {
      var n;
      if (doc.getElementById) {
        n = doc.getElementById(ids[i]);
      } else {
        n = Utilities.getElementById(doc, ids[i]);
      }
      if (n != null) {
        ns.add(n);
        count++;
      }
    }
    return ns;
  };
  Functions.localName = function (c, eNode) {
    var n;
    if (arguments.length == 1) {
      n = c.contextNode;
    } else if (arguments.length == 2) {
      n = eNode.evaluate(c).first();
    } else {
      throw new Error("Function local-name expects (node-set?)");
    }
    if (n == null) {
      return new XString("");
    }
    return new XString(n.localName || n.baseName || n.target || n.nodeName || "");
  };
  Functions.namespaceURI = function () {
    var c = arguments[0];
    var n;
    if (arguments.length == 1) {
      n = c.contextNode;
    } else if (arguments.length == 2) {
      n = arguments[1].evaluate(c).first();
    } else {
      throw new Error("Function namespace-uri expects (node-set?)");
    }
    if (n == null) {
      return new XString("");
    }
    return new XString(n.namespaceURI);
  };
  Functions.name = function () {
    var c = arguments[0];
    var n;
    if (arguments.length == 1) {
      n = c.contextNode;
    } else if (arguments.length == 2) {
      n = arguments[1].evaluate(c).first();
    } else {
      throw new Error("Function name expects (node-set?)");
    }
    if (n == null) {
      return new XString("");
    }
    if (n.nodeType == 1) {
      return new XString(n.nodeName);
    } else if (n.nodeType == 2) {
      return new XString(n.name || n.nodeName);
    } else if (n.nodeType === 7) {
      return new XString(n.target || n.nodeName);
    } else if (n.localName == null) {
      return new XString("");
    } else {
      return new XString(n.localName);
    }
  };
  Functions.string = function () {
    var c = arguments[0];
    if (arguments.length == 1) {
      return new XString(XNodeSet.prototype.stringForNode(c.contextNode));
    } else if (arguments.length == 2) {
      return arguments[1].evaluate(c).string();
    }
    throw new Error("Function string expects (object?)");
  };
  Functions.concat = function (c) {
    if (arguments.length < 3) {
      throw new Error("Function concat expects (string, string[, string]*)");
    }
    var s = "";
    for (var i = 1; i < arguments.length; i++) {
      s += arguments[i].evaluate(c).stringValue();
    }
    return new XString(s);
  };
  Functions.startsWith = function () {
    var c = arguments[0];
    if (arguments.length != 3) {
      throw new Error("Function startsWith expects (string, string)");
    }
    var s1 = arguments[1].evaluate(c).stringValue();
    var s2 = arguments[2].evaluate(c).stringValue();
    return new XBoolean(s1.substring(0, s2.length) == s2);
  };
  Functions.contains = function () {
    var c = arguments[0];
    if (arguments.length != 3) {
      throw new Error("Function contains expects (string, string)");
    }
    var s1 = arguments[1].evaluate(c).stringValue();
    var s2 = arguments[2].evaluate(c).stringValue();
    return new XBoolean(s1.indexOf(s2) !== -1);
  };
  Functions.substringBefore = function () {
    var c = arguments[0];
    if (arguments.length != 3) {
      throw new Error("Function substring-before expects (string, string)");
    }
    var s1 = arguments[1].evaluate(c).stringValue();
    var s2 = arguments[2].evaluate(c).stringValue();
    return new XString(s1.substring(0, s1.indexOf(s2)));
  };
  Functions.substringAfter = function () {
    var c = arguments[0];
    if (arguments.length != 3) {
      throw new Error("Function substring-after expects (string, string)");
    }
    var s1 = arguments[1].evaluate(c).stringValue();
    var s2 = arguments[2].evaluate(c).stringValue();
    if (s2.length == 0) {
      return new XString(s1);
    }
    var i = s1.indexOf(s2);
    if (i == -1) {
      return new XString("");
    }
    return new XString(s1.substring(i + s2.length));
  };
  Functions.substring = function () {
    var c = arguments[0];
    if (!(arguments.length == 3 || arguments.length == 4)) {
      throw new Error("Function substring expects (string, number, number?)");
    }
    var s = arguments[1].evaluate(c).stringValue();
    var n1 = Math.round(arguments[2].evaluate(c).numberValue()) - 1;
    var n2 = arguments.length == 4 ? n1 + Math.round(arguments[3].evaluate(c).numberValue()) : undefined;
    return new XString(s.substring(n1, n2));
  };
  Functions.stringLength = function () {
    var c = arguments[0];
    var s;
    if (arguments.length == 1) {
      s = XNodeSet.prototype.stringForNode(c.contextNode);
    } else if (arguments.length == 2) {
      s = arguments[1].evaluate(c).stringValue();
    } else {
      throw new Error("Function string-length expects (string?)");
    }
    return new XNumber(s.length);
  };
  Functions.normalizeSpace = function () {
    var c = arguments[0];
    var s;
    if (arguments.length == 1) {
      s = XNodeSet.prototype.stringForNode(c.contextNode);
    } else if (arguments.length == 2) {
      s = arguments[1].evaluate(c).stringValue();
    } else {
      throw new Error("Function normalize-space expects (string?)");
    }
    var i = 0;
    var j = s.length - 1;
    while (Utilities.isSpace(s.charCodeAt(j))) {
      j--;
    }
    var t = "";
    while (i <= j && Utilities.isSpace(s.charCodeAt(i))) {
      i++;
    }
    while (i <= j) {
      if (Utilities.isSpace(s.charCodeAt(i))) {
        t += " ";
        while (i <= j && Utilities.isSpace(s.charCodeAt(i))) {
          i++;
        }
      } else {
        t += s.charAt(i);
        i++;
      }
    }
    return new XString(t);
  };
  Functions.translate = function (c, eValue, eFrom, eTo) {
    if (arguments.length != 4) {
      throw new Error("Function translate expects (string, string, string)");
    }
    var value = eValue.evaluate(c).stringValue();
    var from = eFrom.evaluate(c).stringValue();
    var to = eTo.evaluate(c).stringValue();
    var cMap = reduce(function (acc, ch, i) {
      if (!(ch in acc)) {
        acc[ch] = i > to.length ? '' : to[i];
      }
      return acc;
    }, {}, from);
    var t = join('', map(function (ch) {
      return ch in cMap ? cMap[ch] : ch;
    }, value));
    return new XString(t);
  };
  Functions.boolean_ = function () {
    var c = arguments[0];
    if (arguments.length != 2) {
      throw new Error("Function boolean expects (object)");
    }
    return arguments[1].evaluate(c).bool();
  };
  Functions.not = function (c, eValue) {
    if (arguments.length != 2) {
      throw new Error("Function not expects (object)");
    }
    return eValue.evaluate(c).bool().not();
  };
  Functions.true_ = function () {
    if (arguments.length != 1) {
      throw new Error("Function true expects ()");
    }
    return XBoolean.true_;
  };
  Functions.false_ = function () {
    if (arguments.length != 1) {
      throw new Error("Function false expects ()");
    }
    return XBoolean.false_;
  };
  Functions.lang = function () {
    var c = arguments[0];
    if (arguments.length != 2) {
      throw new Error("Function lang expects (string)");
    }
    var lang;
    for (var n = c.contextNode; n != null && n.nodeType != 9; n = n.parentNode) {
      var a = n.getAttributeNS(XPath.XML_NAMESPACE_URI, "lang");
      if (a != null) {
        lang = String(a);
        break;
      }
    }
    if (lang == null) {
      return XBoolean.false_;
    }
    var s = arguments[1].evaluate(c).stringValue();
    return new XBoolean(lang.substring(0, s.length) == s && (lang.length == s.length || lang.charAt(s.length) == '-'));
  };
  Functions.number = function () {
    var c = arguments[0];
    if (!(arguments.length == 1 || arguments.length == 2)) {
      throw new Error("Function number expects (object?)");
    }
    if (arguments.length == 1) {
      return new XNumber(XNodeSet.prototype.stringForNode(c.contextNode));
    }
    return arguments[1].evaluate(c).number();
  };
  Functions.sum = function () {
    var c = arguments[0];
    var ns;
    if (arguments.length != 2 || !Utilities.instance_of(ns = arguments[1].evaluate(c), XNodeSet)) {
      throw new Error("Function sum expects (node-set)");
    }
    ns = ns.toUnsortedArray();
    var n = 0;
    for (var i = 0; i < ns.length; i++) {
      n += new XNumber(XNodeSet.prototype.stringForNode(ns[i])).numberValue();
    }
    return new XNumber(n);
  };
  Functions.floor = function () {
    var c = arguments[0];
    if (arguments.length != 2) {
      throw new Error("Function floor expects (number)");
    }
    return new XNumber(Math.floor(arguments[1].evaluate(c).numberValue()));
  };
  Functions.ceiling = function () {
    var c = arguments[0];
    if (arguments.length != 2) {
      throw new Error("Function ceiling expects (number)");
    }
    return new XNumber(Math.ceil(arguments[1].evaluate(c).numberValue()));
  };
  Functions.round = function () {
    var c = arguments[0];
    if (arguments.length != 2) {
      throw new Error("Function round expects (number)");
    }
    return new XNumber(Math.round(arguments[1].evaluate(c).numberValue()));
  };
  var Utilities = new Object();
  Utilities.isAttribute = function (val) {
    return val && (val.nodeType === 2 || val.ownerElement);
  };
  Utilities.splitQName = function (qn) {
    var i = qn.indexOf(":");
    if (i == -1) {
      return [null, qn];
    }
    return [qn.substring(0, i), qn.substring(i + 1)];
  };
  Utilities.resolveQName = function (qn, nr, n, useDefault) {
    var parts = Utilities.splitQName(qn);
    if (parts[0] != null) {
      parts[0] = nr.getNamespace(parts[0], n);
    } else {
      if (useDefault) {
        parts[0] = nr.getNamespace("", n);
        if (parts[0] == null) {
          parts[0] = "";
        }
      } else {
        parts[0] = "";
      }
    }
    return parts;
  };
  Utilities.isSpace = function (c) {
    return c == 0x9 || c == 0xd || c == 0xa || c == 0x20;
  };
  Utilities.isLetter = function (c) {
    return c >= 0x0041 && c <= 0x005A || c >= 0x0061 && c <= 0x007A || c >= 0x00C0 && c <= 0x00D6 || c >= 0x00D8 && c <= 0x00F6 || c >= 0x00F8 && c <= 0x00FF || c >= 0x0100 && c <= 0x0131 || c >= 0x0134 && c <= 0x013E || c >= 0x0141 && c <= 0x0148 || c >= 0x014A && c <= 0x017E || c >= 0x0180 && c <= 0x01C3 || c >= 0x01CD && c <= 0x01F0 || c >= 0x01F4 && c <= 0x01F5 || c >= 0x01FA && c <= 0x0217 || c >= 0x0250 && c <= 0x02A8 || c >= 0x02BB && c <= 0x02C1 || c == 0x0386 || c >= 0x0388 && c <= 0x038A || c == 0x038C || c >= 0x038E && c <= 0x03A1 || c >= 0x03A3 && c <= 0x03CE || c >= 0x03D0 && c <= 0x03D6 || c == 0x03DA || c == 0x03DC || c == 0x03DE || c == 0x03E0 || c >= 0x03E2 && c <= 0x03F3 || c >= 0x0401 && c <= 0x040C || c >= 0x040E && c <= 0x044F || c >= 0x0451 && c <= 0x045C || c >= 0x045E && c <= 0x0481 || c >= 0x0490 && c <= 0x04C4 || c >= 0x04C7 && c <= 0x04C8 || c >= 0x04CB && c <= 0x04CC || c >= 0x04D0 && c <= 0x04EB || c >= 0x04EE && c <= 0x04F5 || c >= 0x04F8 && c <= 0x04F9 || c >= 0x0531 && c <= 0x0556 || c == 0x0559 || c >= 0x0561 && c <= 0x0586 || c >= 0x05D0 && c <= 0x05EA || c >= 0x05F0 && c <= 0x05F2 || c >= 0x0621 && c <= 0x063A || c >= 0x0641 && c <= 0x064A || c >= 0x0671 && c <= 0x06B7 || c >= 0x06BA && c <= 0x06BE || c >= 0x06C0 && c <= 0x06CE || c >= 0x06D0 && c <= 0x06D3 || c == 0x06D5 || c >= 0x06E5 && c <= 0x06E6 || c >= 0x0905 && c <= 0x0939 || c == 0x093D || c >= 0x0958 && c <= 0x0961 || c >= 0x0985 && c <= 0x098C || c >= 0x098F && c <= 0x0990 || c >= 0x0993 && c <= 0x09A8 || c >= 0x09AA && c <= 0x09B0 || c == 0x09B2 || c >= 0x09B6 && c <= 0x09B9 || c >= 0x09DC && c <= 0x09DD || c >= 0x09DF && c <= 0x09E1 || c >= 0x09F0 && c <= 0x09F1 || c >= 0x0A05 && c <= 0x0A0A || c >= 0x0A0F && c <= 0x0A10 || c >= 0x0A13 && c <= 0x0A28 || c >= 0x0A2A && c <= 0x0A30 || c >= 0x0A32 && c <= 0x0A33 || c >= 0x0A35 && c <= 0x0A36 || c >= 0x0A38 && c <= 0x0A39 || c >= 0x0A59 && c <= 0x0A5C || c == 0x0A5E || c >= 0x0A72 && c <= 0x0A74 || c >= 0x0A85 && c <= 0x0A8B || c == 0x0A8D || c >= 0x0A8F && c <= 0x0A91 || c >= 0x0A93 && c <= 0x0AA8 || c >= 0x0AAA && c <= 0x0AB0 || c >= 0x0AB2 && c <= 0x0AB3 || c >= 0x0AB5 && c <= 0x0AB9 || c == 0x0ABD || c == 0x0AE0 || c >= 0x0B05 && c <= 0x0B0C || c >= 0x0B0F && c <= 0x0B10 || c >= 0x0B13 && c <= 0x0B28 || c >= 0x0B2A && c <= 0x0B30 || c >= 0x0B32 && c <= 0x0B33 || c >= 0x0B36 && c <= 0x0B39 || c == 0x0B3D || c >= 0x0B5C && c <= 0x0B5D || c >= 0x0B5F && c <= 0x0B61 || c >= 0x0B85 && c <= 0x0B8A || c >= 0x0B8E && c <= 0x0B90 || c >= 0x0B92 && c <= 0x0B95 || c >= 0x0B99 && c <= 0x0B9A || c == 0x0B9C || c >= 0x0B9E && c <= 0x0B9F || c >= 0x0BA3 && c <= 0x0BA4 || c >= 0x0BA8 && c <= 0x0BAA || c >= 0x0BAE && c <= 0x0BB5 || c >= 0x0BB7 && c <= 0x0BB9 || c >= 0x0C05 && c <= 0x0C0C || c >= 0x0C0E && c <= 0x0C10 || c >= 0x0C12 && c <= 0x0C28 || c >= 0x0C2A && c <= 0x0C33 || c >= 0x0C35 && c <= 0x0C39 || c >= 0x0C60 && c <= 0x0C61 || c >= 0x0C85 && c <= 0x0C8C || c >= 0x0C8E && c <= 0x0C90 || c >= 0x0C92 && c <= 0x0CA8 || c >= 0x0CAA && c <= 0x0CB3 || c >= 0x0CB5 && c <= 0x0CB9 || c == 0x0CDE || c >= 0x0CE0 && c <= 0x0CE1 || c >= 0x0D05 && c <= 0x0D0C || c >= 0x0D0E && c <= 0x0D10 || c >= 0x0D12 && c <= 0x0D28 || c >= 0x0D2A && c <= 0x0D39 || c >= 0x0D60 && c <= 0x0D61 || c >= 0x0E01 && c <= 0x0E2E || c == 0x0E30 || c >= 0x0E32 && c <= 0x0E33 || c >= 0x0E40 && c <= 0x0E45 || c >= 0x0E81 && c <= 0x0E82 || c == 0x0E84 || c >= 0x0E87 && c <= 0x0E88 || c == 0x0E8A || c == 0x0E8D || c >= 0x0E94 && c <= 0x0E97 || c >= 0x0E99 && c <= 0x0E9F || c >= 0x0EA1 && c <= 0x0EA3 || c == 0x0EA5 || c == 0x0EA7 || c >= 0x0EAA && c <= 0x0EAB || c >= 0x0EAD && c <= 0x0EAE || c == 0x0EB0 || c >= 0x0EB2 && c <= 0x0EB3 || c == 0x0EBD || c >= 0x0EC0 && c <= 0x0EC4 || c >= 0x0F40 && c <= 0x0F47 || c >= 0x0F49 && c <= 0x0F69 || c >= 0x10A0 && c <= 0x10C5 || c >= 0x10D0 && c <= 0x10F6 || c == 0x1100 || c >= 0x1102 && c <= 0x1103 || c >= 0x1105 && c <= 0x1107 || c == 0x1109 || c >= 0x110B && c <= 0x110C || c >= 0x110E && c <= 0x1112 || c == 0x113C || c == 0x113E || c == 0x1140 || c == 0x114C || c == 0x114E || c == 0x1150 || c >= 0x1154 && c <= 0x1155 || c == 0x1159 || c >= 0x115F && c <= 0x1161 || c == 0x1163 || c == 0x1165 || c == 0x1167 || c == 0x1169 || c >= 0x116D && c <= 0x116E || c >= 0x1172 && c <= 0x1173 || c == 0x1175 || c == 0x119E || c == 0x11A8 || c == 0x11AB || c >= 0x11AE && c <= 0x11AF || c >= 0x11B7 && c <= 0x11B8 || c == 0x11BA || c >= 0x11BC && c <= 0x11C2 || c == 0x11EB || c == 0x11F0 || c == 0x11F9 || c >= 0x1E00 && c <= 0x1E9B || c >= 0x1EA0 && c <= 0x1EF9 || c >= 0x1F00 && c <= 0x1F15 || c >= 0x1F18 && c <= 0x1F1D || c >= 0x1F20 && c <= 0x1F45 || c >= 0x1F48 && c <= 0x1F4D || c >= 0x1F50 && c <= 0x1F57 || c == 0x1F59 || c == 0x1F5B || c == 0x1F5D || c >= 0x1F5F && c <= 0x1F7D || c >= 0x1F80 && c <= 0x1FB4 || c >= 0x1FB6 && c <= 0x1FBC || c == 0x1FBE || c >= 0x1FC2 && c <= 0x1FC4 || c >= 0x1FC6 && c <= 0x1FCC || c >= 0x1FD0 && c <= 0x1FD3 || c >= 0x1FD6 && c <= 0x1FDB || c >= 0x1FE0 && c <= 0x1FEC || c >= 0x1FF2 && c <= 0x1FF4 || c >= 0x1FF6 && c <= 0x1FFC || c == 0x2126 || c >= 0x212A && c <= 0x212B || c == 0x212E || c >= 0x2180 && c <= 0x2182 || c >= 0x3041 && c <= 0x3094 || c >= 0x30A1 && c <= 0x30FA || c >= 0x3105 && c <= 0x312C || c >= 0xAC00 && c <= 0xD7A3 || c >= 0x4E00 && c <= 0x9FA5 || c == 0x3007 || c >= 0x3021 && c <= 0x3029;
  };
  Utilities.isNCNameChar = function (c) {
    return c >= 0x0030 && c <= 0x0039 || c >= 0x0660 && c <= 0x0669 || c >= 0x06F0 && c <= 0x06F9 || c >= 0x0966 && c <= 0x096F || c >= 0x09E6 && c <= 0x09EF || c >= 0x0A66 && c <= 0x0A6F || c >= 0x0AE6 && c <= 0x0AEF || c >= 0x0B66 && c <= 0x0B6F || c >= 0x0BE7 && c <= 0x0BEF || c >= 0x0C66 && c <= 0x0C6F || c >= 0x0CE6 && c <= 0x0CEF || c >= 0x0D66 && c <= 0x0D6F || c >= 0x0E50 && c <= 0x0E59 || c >= 0x0ED0 && c <= 0x0ED9 || c >= 0x0F20 && c <= 0x0F29 || c == 0x002E || c == 0x002D || c == 0x005F || Utilities.isLetter(c) || c >= 0x0300 && c <= 0x0345 || c >= 0x0360 && c <= 0x0361 || c >= 0x0483 && c <= 0x0486 || c >= 0x0591 && c <= 0x05A1 || c >= 0x05A3 && c <= 0x05B9 || c >= 0x05BB && c <= 0x05BD || c == 0x05BF || c >= 0x05C1 && c <= 0x05C2 || c == 0x05C4 || c >= 0x064B && c <= 0x0652 || c == 0x0670 || c >= 0x06D6 && c <= 0x06DC || c >= 0x06DD && c <= 0x06DF || c >= 0x06E0 && c <= 0x06E4 || c >= 0x06E7 && c <= 0x06E8 || c >= 0x06EA && c <= 0x06ED || c >= 0x0901 && c <= 0x0903 || c == 0x093C || c >= 0x093E && c <= 0x094C || c == 0x094D || c >= 0x0951 && c <= 0x0954 || c >= 0x0962 && c <= 0x0963 || c >= 0x0981 && c <= 0x0983 || c == 0x09BC || c == 0x09BE || c == 0x09BF || c >= 0x09C0 && c <= 0x09C4 || c >= 0x09C7 && c <= 0x09C8 || c >= 0x09CB && c <= 0x09CD || c == 0x09D7 || c >= 0x09E2 && c <= 0x09E3 || c == 0x0A02 || c == 0x0A3C || c == 0x0A3E || c == 0x0A3F || c >= 0x0A40 && c <= 0x0A42 || c >= 0x0A47 && c <= 0x0A48 || c >= 0x0A4B && c <= 0x0A4D || c >= 0x0A70 && c <= 0x0A71 || c >= 0x0A81 && c <= 0x0A83 || c == 0x0ABC || c >= 0x0ABE && c <= 0x0AC5 || c >= 0x0AC7 && c <= 0x0AC9 || c >= 0x0ACB && c <= 0x0ACD || c >= 0x0B01 && c <= 0x0B03 || c == 0x0B3C || c >= 0x0B3E && c <= 0x0B43 || c >= 0x0B47 && c <= 0x0B48 || c >= 0x0B4B && c <= 0x0B4D || c >= 0x0B56 && c <= 0x0B57 || c >= 0x0B82 && c <= 0x0B83 || c >= 0x0BBE && c <= 0x0BC2 || c >= 0x0BC6 && c <= 0x0BC8 || c >= 0x0BCA && c <= 0x0BCD || c == 0x0BD7 || c >= 0x0C01 && c <= 0x0C03 || c >= 0x0C3E && c <= 0x0C44 || c >= 0x0C46 && c <= 0x0C48 || c >= 0x0C4A && c <= 0x0C4D || c >= 0x0C55 && c <= 0x0C56 || c >= 0x0C82 && c <= 0x0C83 || c >= 0x0CBE && c <= 0x0CC4 || c >= 0x0CC6 && c <= 0x0CC8 || c >= 0x0CCA && c <= 0x0CCD || c >= 0x0CD5 && c <= 0x0CD6 || c >= 0x0D02 && c <= 0x0D03 || c >= 0x0D3E && c <= 0x0D43 || c >= 0x0D46 && c <= 0x0D48 || c >= 0x0D4A && c <= 0x0D4D || c == 0x0D57 || c == 0x0E31 || c >= 0x0E34 && c <= 0x0E3A || c >= 0x0E47 && c <= 0x0E4E || c == 0x0EB1 || c >= 0x0EB4 && c <= 0x0EB9 || c >= 0x0EBB && c <= 0x0EBC || c >= 0x0EC8 && c <= 0x0ECD || c >= 0x0F18 && c <= 0x0F19 || c == 0x0F35 || c == 0x0F37 || c == 0x0F39 || c == 0x0F3E || c == 0x0F3F || c >= 0x0F71 && c <= 0x0F84 || c >= 0x0F86 && c <= 0x0F8B || c >= 0x0F90 && c <= 0x0F95 || c == 0x0F97 || c >= 0x0F99 && c <= 0x0FAD || c >= 0x0FB1 && c <= 0x0FB7 || c == 0x0FB9 || c >= 0x20D0 && c <= 0x20DC || c == 0x20E1 || c >= 0x302A && c <= 0x302F || c == 0x3099 || c == 0x309A || c == 0x00B7 || c == 0x02D0 || c == 0x02D1 || c == 0x0387 || c == 0x0640 || c == 0x0E46 || c == 0x0EC6 || c == 0x3005 || c >= 0x3031 && c <= 0x3035 || c >= 0x309D && c <= 0x309E || c >= 0x30FC && c <= 0x30FE;
  };
  Utilities.coalesceText = function (n) {
    for (var m = n.firstChild; m != null; m = m.nextSibling) {
      if (m.nodeType == 3 || m.nodeType == 4) {
        var s = m.nodeValue;
        var first = m;
        m = m.nextSibling;
        while (m != null && (m.nodeType == 3 || m.nodeType == 4)) {
          s += m.nodeValue;
          var del = m;
          m = m.nextSibling;
          del.parentNode.removeChild(del);
        }
        if (first.nodeType == 4) {
          var p = first.parentNode;
          if (first.nextSibling == null) {
            p.removeChild(first);
            p.appendChild(p.ownerDocument.createTextNode(s));
          } else {
            var next = first.nextSibling;
            p.removeChild(first);
            p.insertBefore(p.ownerDocument.createTextNode(s), next);
          }
        } else {
          first.nodeValue = s;
        }
        if (m == null) {
          break;
        }
      } else if (m.nodeType == 1) {
        Utilities.coalesceText(m);
      }
    }
  };
  Utilities.instance_of = function (o, c) {
    while (o != null) {
      if (o.constructor === c) {
        return true;
      }
      if (o === Object) {
        return false;
      }
      o = o.constructor.superclass;
    }
    return false;
  };
  Utilities.getElementById = function (n, id) {
    if (n.nodeType == 1) {
      if (n.getAttribute("id") == id || n.getAttributeNS(null, "id") == id) {
        return n;
      }
    }
    for (var m = n.firstChild; m != null; m = m.nextSibling) {
      var res = Utilities.getElementById(m, id);
      if (res != null) {
        return res;
      }
    }
    return null;
  };
  var XPathException = function () {
    function getMessage(code, exception) {
      var msg = exception ? ": " + exception.toString() : "";
      switch (code) {
        case XPathException.INVALID_EXPRESSION_ERR:
          return "Invalid expression" + msg;
        case XPathException.TYPE_ERR:
          return "Type error" + msg;
      }
      return null;
    }
    function XPathException(code, error, message) {
      var err = Error.call(this, getMessage(code, error) || message);
      err.code = code;
      err.exception = error;
      return err;
    }
    XPathException.prototype = Object.create(Error.prototype);
    XPathException.prototype.constructor = XPathException;
    XPathException.superclass = Error;
    XPathException.prototype.toString = function () {
      return this.message;
    };
    XPathException.fromMessage = function (message, error) {
      return new XPathException(null, error, message);
    };
    XPathException.INVALID_EXPRESSION_ERR = 51;
    XPathException.TYPE_ERR = 52;
    return XPathException;
  }();
  XPathExpression.prototype = {};
  XPathExpression.prototype.constructor = XPathExpression;
  XPathExpression.superclass = Object.prototype;
  function XPathExpression(e, r, p) {
    this.xpath = p.parse(e);
    this.context = new XPathContext();
    this.context.namespaceResolver = new XPathNSResolverWrapper(r);
  }
  XPathExpression.getOwnerDocument = function (n) {
    return n.nodeType === 9 ? n : n.ownerDocument;
  };
  XPathExpression.detectHtmlDom = function (n) {
    if (!n) {
      return false;
    }
    var doc = XPathExpression.getOwnerDocument(n);
    try {
      return doc.implementation.hasFeature("HTML", "2.0");
    } catch (e) {
      return true;
    }
  };
  XPathExpression.prototype.evaluate = function (n, t, res) {
    this.context.expressionContextNode = n;
    this.context.caseInsensitive = XPathExpression.detectHtmlDom(n);
    var result = this.xpath.evaluate(this.context);
    return new XPathResult(result, t);
  };
  XPathNSResolverWrapper.prototype = {};
  XPathNSResolverWrapper.prototype.constructor = XPathNSResolverWrapper;
  XPathNSResolverWrapper.superclass = Object.prototype;
  function XPathNSResolverWrapper(r) {
    this.xpathNSResolver = r;
  }
  XPathNSResolverWrapper.prototype.getNamespace = function (prefix, n) {
    if (this.xpathNSResolver == null) {
      return null;
    }
    return this.xpathNSResolver.lookupNamespaceURI(prefix);
  };
  NodeXPathNSResolver.prototype = {};
  NodeXPathNSResolver.prototype.constructor = NodeXPathNSResolver;
  NodeXPathNSResolver.superclass = Object.prototype;
  function NodeXPathNSResolver(n) {
    this.node = n;
    this.namespaceResolver = new NamespaceResolver();
  }
  NodeXPathNSResolver.prototype.lookupNamespaceURI = function (prefix) {
    return this.namespaceResolver.getNamespace(prefix, this.node);
  };
  XPathResult.prototype = {};
  XPathResult.prototype.constructor = XPathResult;
  XPathResult.superclass = Object.prototype;
  function XPathResult(v, t) {
    if (t == XPathResult.ANY_TYPE) {
      if (v.constructor === XString) {
        t = XPathResult.STRING_TYPE;
      } else if (v.constructor === XNumber) {
        t = XPathResult.NUMBER_TYPE;
      } else if (v.constructor === XBoolean) {
        t = XPathResult.BOOLEAN_TYPE;
      } else if (v.constructor === XNodeSet) {
        t = XPathResult.UNORDERED_NODE_ITERATOR_TYPE;
      }
    }
    this.resultType = t;
    switch (t) {
      case XPathResult.NUMBER_TYPE:
        this.numberValue = v.numberValue();
        return;
      case XPathResult.STRING_TYPE:
        this.stringValue = v.stringValue();
        return;
      case XPathResult.BOOLEAN_TYPE:
        this.booleanValue = v.booleanValue();
        return;
      case XPathResult.ANY_UNORDERED_NODE_TYPE:
      case XPathResult.FIRST_ORDERED_NODE_TYPE:
        if (v.constructor === XNodeSet) {
          this.singleNodeValue = v.first();
          return;
        }
        break;
      case XPathResult.UNORDERED_NODE_ITERATOR_TYPE:
      case XPathResult.ORDERED_NODE_ITERATOR_TYPE:
        if (v.constructor === XNodeSet) {
          this.invalidIteratorState = false;
          this.nodes = v.toArray();
          this.iteratorIndex = 0;
          return;
        }
        break;
      case XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE:
      case XPathResult.ORDERED_NODE_SNAPSHOT_TYPE:
        if (v.constructor === XNodeSet) {
          this.nodes = v.toArray();
          this.snapshotLength = this.nodes.length;
          return;
        }
        break;
    }
    throw new XPathException(XPathException.TYPE_ERR);
  }
  ;
  XPathResult.prototype.iterateNext = function () {
    if (this.resultType != XPathResult.UNORDERED_NODE_ITERATOR_TYPE && this.resultType != XPathResult.ORDERED_NODE_ITERATOR_TYPE) {
      throw new XPathException(XPathException.TYPE_ERR);
    }
    return this.nodes[this.iteratorIndex++];
  };
  XPathResult.prototype.snapshotItem = function (i) {
    if (this.resultType != XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE && this.resultType != XPathResult.ORDERED_NODE_SNAPSHOT_TYPE) {
      throw new XPathException(XPathException.TYPE_ERR);
    }
    return this.nodes[i];
  };
  XPathResult.ANY_TYPE = 0;
  XPathResult.NUMBER_TYPE = 1;
  XPathResult.STRING_TYPE = 2;
  XPathResult.BOOLEAN_TYPE = 3;
  XPathResult.UNORDERED_NODE_ITERATOR_TYPE = 4;
  XPathResult.ORDERED_NODE_ITERATOR_TYPE = 5;
  XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE = 6;
  XPathResult.ORDERED_NODE_SNAPSHOT_TYPE = 7;
  XPathResult.ANY_UNORDERED_NODE_TYPE = 8;
  XPathResult.FIRST_ORDERED_NODE_TYPE = 9;
  function installDOM3XPathSupport(doc, p) {
    doc.createExpression = function (e, r) {
      try {
        return new XPathExpression(e, r, p);
      } catch (e) {
        throw new XPathException(XPathException.INVALID_EXPRESSION_ERR, e);
      }
    };
    doc.createNSResolver = function (n) {
      return new NodeXPathNSResolver(n);
    };
    doc.evaluate = function (e, cn, r, t, res) {
      if (t < 0 || t > 9) {
        throw {
          code: 0,
          toString: function () {
            return "Request type not supported";
          }
        };
      }
      return doc.createExpression(e, r, p).evaluate(cn, t, res);
    };
  }
  ;
  try {
    var shouldInstall = true;
    try {
      if (document.implementation && document.implementation.hasFeature && document.implementation.hasFeature("XPath", null)) {
        shouldInstall = false;
      }
    } catch (e) {}
    if (shouldInstall) {
      installDOM3XPathSupport(document, new XPathParser());
    }
  } catch (e) {}
  installDOM3XPathSupport(exports, new XPathParser());
  (function () {
    var parser = new XPathParser();
    var defaultNSResolver = new NamespaceResolver();
    var defaultFunctionResolver = new FunctionResolver();
    var defaultVariableResolver = new VariableResolver();
    function makeNSResolverFromFunction(func) {
      return {
        getNamespace: function (prefix, node) {
          var ns = func(prefix, node);
          return ns || defaultNSResolver.getNamespace(prefix, node);
        }
      };
    }
    function makeNSResolverFromObject(obj) {
      return makeNSResolverFromFunction(obj.getNamespace.bind(obj));
    }
    function makeNSResolverFromMap(map) {
      return makeNSResolverFromFunction(function (prefix) {
        return map[prefix];
      });
    }
    function makeNSResolver(resolver) {
      if (resolver && typeof resolver.getNamespace === "function") {
        return makeNSResolverFromObject(resolver);
      }
      if (typeof resolver === "function") {
        return makeNSResolverFromFunction(resolver);
      }
      if (typeof resolver === "object") {
        return makeNSResolverFromMap(resolver);
      }
      return defaultNSResolver;
    }
    function convertValue(value) {
      if (value === null || typeof value === "undefined" || value instanceof XString || value instanceof XBoolean || value instanceof XNumber || value instanceof XNodeSet) {
        return value;
      }
      switch (typeof value) {
        case "string":
          return new XString(value);
        case "boolean":
          return new XBoolean(value);
        case "number":
          return new XNumber(value);
      }
      var ns = new XNodeSet();
      ns.addArray([].concat(value));
      return ns;
    }
    function makeEvaluator(func) {
      return function (context) {
        var args = Array.prototype.slice.call(arguments, 1).map(function (arg) {
          return arg.evaluate(context);
        });
        var result = func.apply(this, [].concat(context, args));
        return convertValue(result);
      };
    }
    function makeFunctionResolverFromFunction(func) {
      return {
        getFunction: function (name, namespace) {
          var found = func(name, namespace);
          if (found) {
            return makeEvaluator(found);
          }
          return defaultFunctionResolver.getFunction(name, namespace);
        }
      };
    }
    function makeFunctionResolverFromObject(obj) {
      return makeFunctionResolverFromFunction(obj.getFunction.bind(obj));
    }
    function makeFunctionResolverFromMap(map) {
      return makeFunctionResolverFromFunction(function (name) {
        return map[name];
      });
    }
    function makeFunctionResolver(resolver) {
      if (resolver && typeof resolver.getFunction === "function") {
        return makeFunctionResolverFromObject(resolver);
      }
      if (typeof resolver === "function") {
        return makeFunctionResolverFromFunction(resolver);
      }
      if (typeof resolver === "object") {
        return makeFunctionResolverFromMap(resolver);
      }
      return defaultFunctionResolver;
    }
    function makeVariableResolverFromFunction(func) {
      return {
        getVariable: function (name, namespace) {
          var value = func(name, namespace);
          return convertValue(value);
        }
      };
    }
    function makeVariableResolver(resolver) {
      if (resolver) {
        if (typeof resolver.getVariable === "function") {
          return makeVariableResolverFromFunction(resolver.getVariable.bind(resolver));
        }
        if (typeof resolver === "function") {
          return makeVariableResolverFromFunction(resolver);
        }
        if (typeof resolver === "object") {
          return makeVariableResolverFromFunction(function (name) {
            return resolver[name];
          });
        }
      }
      return defaultVariableResolver;
    }
    function copyIfPresent(prop, dest, source) {
      if (prop in source) {
        dest[prop] = source[prop];
      }
    }
    function makeContext(options) {
      var context = new XPathContext();
      if (options) {
        context.namespaceResolver = makeNSResolver(options.namespaces);
        context.functionResolver = makeFunctionResolver(options.functions);
        context.variableResolver = makeVariableResolver(options.variables);
        context.expressionContextNode = options.node;
        copyIfPresent('allowAnyNamespaceForNoPrefix', context, options);
        copyIfPresent('isHtml', context, options);
      } else {
        context.namespaceResolver = defaultNSResolver;
      }
      return context;
    }
    function evaluate(parsedExpression, options) {
      var context = makeContext(options);
      return parsedExpression.evaluate(context);
    }
    var evaluatorPrototype = {
      evaluate: function (options) {
        return evaluate(this.expression, options);
      },
      evaluateNumber: function (options) {
        return this.evaluate(options).numberValue();
      },
      evaluateString: function (options) {
        return this.evaluate(options).stringValue();
      },
      evaluateBoolean: function (options) {
        return this.evaluate(options).booleanValue();
      },
      evaluateNodeSet: function (options) {
        return this.evaluate(options).nodeset();
      },
      select: function (options) {
        return this.evaluateNodeSet(options).toArray();
      },
      select1: function (options) {
        return this.select(options)[0];
      }
    };
    function parse(xpath) {
      var parsed = parser.parse(xpath);
      return Object.create(evaluatorPrototype, {
        expression: {
          value: parsed
        }
      });
    }
    exports.parse = parse;
  })();
  assign(exports, {
    XPath,
    XPathParser,
    XPathResult,
    Step,
    PathExpr,
    NodeTest,
    LocationPath,
    OrOperation,
    AndOperation,
    BarOperation,
    EqualsOperation,
    NotEqualOperation,
    LessThanOperation,
    GreaterThanOperation,
    LessThanOrEqualOperation,
    GreaterThanOrEqualOperation,
    PlusOperation,
    MinusOperation,
    MultiplyOperation,
    DivOperation,
    ModOperation,
    UnaryMinusOperation,
    FunctionCall,
    VariableReference,
    XPathContext,
    XNodeSet,
    XBoolean,
    XString,
    XNumber,
    NamespaceResolver,
    FunctionResolver,
    VariableResolver,
    Utilities
  });
  exports.select = function (e, doc, single) {
    return exports.selectWithResolver(e, doc, null, single);
  };
  exports.useNamespaces = function (mappings) {
    var resolver = {
      mappings: mappings || {},
      lookupNamespaceURI: function (prefix) {
        return this.mappings[prefix];
      }
    };
    return function (e, doc, single) {
      return exports.selectWithResolver(e, doc, resolver, single);
    };
  };
  exports.selectWithResolver = function (e, doc, resolver, single) {
    var expression = new XPathExpression(e, resolver, new XPathParser());
    var type = XPathResult.ANY_TYPE;
    var result = expression.evaluate(doc, type, null);
    if (result.resultType == XPathResult.STRING_TYPE) {
      result = result.stringValue;
    } else if (result.resultType == XPathResult.NUMBER_TYPE) {
      result = result.numberValue;
    } else if (result.resultType == XPathResult.BOOLEAN_TYPE) {
      result = result.booleanValue;
    } else {
      result = result.nodes;
      if (single) {
        result = result[0];
      }
    }
    return result;
  };
  exports.select1 = function (e, doc) {
    return exports.select(e, doc, true);
  };
})(xpath);

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

// EXTERNAL MODULE: ../../node_modules/.pnpm/@babel+runtime@7.25.6/node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(515);
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/toArr.js
var toArr = __webpack_require__(149);
var toArr_default = /*#__PURE__*/__webpack_require__.n(toArr);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/startWith.js
var startWith = __webpack_require__(629);
var startWith_default = /*#__PURE__*/__webpack_require__.n(startWith);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/selector.js
var selector = __webpack_require__(896);
var selector_default = /*#__PURE__*/__webpack_require__.n(selector);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/each.js
var each = __webpack_require__(680);
var each_default = /*#__PURE__*/__webpack_require__.n(each);
;// CONCATENATED MODULE: ./src/webview/util.ts



function transSelector(sel, classPrefix = '', idPrefix = '') {
  var groups = selector_default().parse(sel);
  each_default()(groups, selector => {
    each_default()(selector, node => {
      if (node.type === 'tag') {
        if (node.value === 'page') {
          node.value = 'body';
        } else {
          node.value = 'wx-' + node.value;
        }
      } else if (node.type === 'class' && classPrefix) {
        node.value = classPrefix + '--' + node.value;
      } else if (node.type === 'id' && idPrefix) {
        node.type = 'attribute';
        node.value = `id='${idPrefix + '--' + node.value}'`;
      }
    });
  });
  return selector_default().stringify(groups);
}
function isValidEl(el) {
  if (!el) return false;
  return startWith_default()(el.tagName, 'WX-') || el.tagName === 'BODY';
}
function getClassPrefix(el) {
  var classPrefix = '';
  var wxElement = el.__wxElement;
  if (wxElement && wxElement.__component__) {
    classPrefix = wxElement.__componentOptions.classPrefix;
  } else if (wxElement && wxElement.classList) {
    classPrefix = wxElement.classList._prefix;
  }
  return classPrefix;
}
function getIdPrefix(el) {
  var idPrefix = '';
  var wxElement = el.__wxElement;
  if (wxElement && wxElement.__component__) {
    idPrefix = wxElement.__idPrefix;
  } else if (wxElement && wxElement.classList) {
    idPrefix = wxElement.classList._owner && wxElement.classList._owner._elem && wxElement.classList._owner._elem.__idPrefix;
  }
  return idPrefix;
}
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/uuid.js
var uuid = __webpack_require__(506);
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/safeGet.js
var safeGet = __webpack_require__(150);
var safeGet_default = /*#__PURE__*/__webpack_require__.n(safeGet);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/isUndef.js
var isUndef = __webpack_require__(375);
var isUndef_default = /*#__PURE__*/__webpack_require__.n(isUndef);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/map.js
var map = __webpack_require__(735);
var map_default = /*#__PURE__*/__webpack_require__.n(map);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/defaults.js
var defaults = __webpack_require__(655);
var defaults_default = /*#__PURE__*/__webpack_require__.n(defaults);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/isEmpty.js
var isEmpty = __webpack_require__(100);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty);
;// CONCATENATED MODULE: ./src/webview/element.ts









var element_elements = new Map();
function set(el) {
  var id = el._id;
  if (!id) {
    id = uuid_default()();
    el._id = id;
  }
  element_elements.set(id, {
    id,
    element: el
  });
  return id;
}
function get(elementId) {
  var el = element_elements.get(elementId);
  if (!el) {
    throw Error('element destroyed');
  }
  return el.element;
}
function transEl(el) {
  var element = {
    elementId: set(el),
    tagName: el.tagName.toLocaleLowerCase().replace('wx-', '')
  };
  var nodeId = safeGet_default()(el, '__wxElement.__wxTmplId');
  if (nodeId) element.nodeId = nodeId;
  if (element.tagName === 'video') {
    element.videoId = el.__wxElement.id || '';
  }
  return element;
}
function getElement(params) {
  var {
    elementId
  } = params;
  var {
    selector
  } = params;
  var el = get(elementId);
  selector = transSelector(selector, getClassPrefix(el), getIdPrefix(el));
  el = el.querySelector(selector);
  if (!isValidEl(el)) el = null;
  if (!el) {
    throw Error('no such element');
  }
  return transEl(el);
}
function getElements(params) {
  var {
    elementId
  } = params;
  var {
    selector
  } = params;
  var el = get(elementId);
  selector = transSelector(selector, getClassPrefix(el), getIdPrefix(el));
  var els = toArr_default()(el.querySelectorAll(selector));
  var elements = [];
  for (var _el of els) {
    if (isValidEl(_el)) {
      elements.push(transEl(_el));
    }
  }
  return {
    elements
  };
}
function getAttributes(_x) {
  return _getAttributes.apply(this, arguments);
}
function _getAttributes() {
  _getAttributes = asyncToGenerator_default()(function* (params) {
    var {
      elementId,
      names
    } = params;
    var el = get(elementId);
    return {
      attributes: names.map(name => el.getAttribute(name))
    };
  });
  return _getAttributes.apply(this, arguments);
}
function getStyles(_x2) {
  return _getStyles.apply(this, arguments);
}
function _getStyles() {
  _getStyles = asyncToGenerator_default()(function* (params) {
    var {
      elementId,
      names
    } = params;
    var el = get(elementId);
    var style = getComputedStyle(el);
    return {
      styles: names.map(name => style[name])
    };
  });
  return _getStyles.apply(this, arguments);
}
function getWXML(_x3) {
  return _getWXML.apply(this, arguments);
}
function _getWXML() {
  _getWXML = asyncToGenerator_default()(function* (params) {
    var {
      elementId,
      type
    } = params;
    var el = get(elementId);
    return {
      wxml: transHtmlToWxml(type === 'outer' ? el.outerHTML : el.innerHTML)
    };
  });
  return _getWXML.apply(this, arguments);
}
function transHtmlToWxml(html) {
  html = html.replace(/\n/g, '');
  html = html.replace(/(<wx-text[^>]*>)(<span[^>]*>[^<]*<\/span>)(.*?<\/wx-text>)/g, '$1$3');
  html = html.replace(/<\/?[^>]*>/g, match => {
    if (match.indexOf('<body') > -1) return '<page>';
    if (match === '</body>') return '</page>';
    if (match.indexOf('<wx-') !== 0 && match.indexOf('</wx-') !== 0) {
      return '';
    }
    match = match.replace(/wx-/g, '');
    match = match.replace(/ exparser:[^=]*="[^"]*"/g, '');
    match = match.replace(/ wx:[^=]*="[^"]*"/g, '');
    match = match.replace(/ role=""/g, '').replace(/ aria-label=""/g, '');
    return match;
  });
  return html;
}
function getDOMProperties(_x4) {
  return _getDOMProperties.apply(this, arguments);
}
function _getDOMProperties() {
  _getDOMProperties = asyncToGenerator_default()(function* (params) {
    var {
      elementId,
      names
    } = params;
    var el = get(elementId);
    return {
      properties: names.map(name => safeGet_default()(el, name))
    };
  });
  return _getDOMProperties.apply(this, arguments);
}
function getProperties(_x5) {
  return _getProperties.apply(this, arguments);
}
function _getProperties() {
  _getProperties = asyncToGenerator_default()(function* (params) {
    var {
      elementId,
      names
    } = params;
    var el = get(elementId).__wxElement;
    return {
      properties: names.map(name => safeGet_default()(el, name))
    };
  });
  return _getProperties.apply(this, arguments);
}
function getOffset(_x6) {
  return _getOffset.apply(this, arguments);
}
function _getOffset() {
  _getOffset = asyncToGenerator_default()(function* (params) {
    var el = get(params.elementId);
    var box = el.getBoundingClientRect();
    return {
      left: box.left + window.pageXOffset,
      top: box.top + window.pageYOffset
    };
  });
  return _getOffset.apply(this, arguments);
}
function tap(_x7) {
  return _tap.apply(this, arguments);
}
function _tap() {
  _tap = asyncToGenerator_default()(function* (params) {
    var {
      elementId
    } = params;
    var el = get(elementId);
    touchStart(el);
    touchEnd(el);
  });
  return _tap.apply(this, arguments);
}
function touchstart(_x8) {
  return _touchstart.apply(this, arguments);
}
function _touchstart() {
  _touchstart = asyncToGenerator_default()(function* (params) {
    var {
      elementId,
      touches,
      changedTouches
    } = params;
    var el = get(elementId);
    touchStart(el, {
      touches,
      changedTouches
    });
  });
  return _touchstart.apply(this, arguments);
}
function touchmove(_x9) {
  return _touchmove.apply(this, arguments);
}
function _touchmove() {
  _touchmove = asyncToGenerator_default()(function* (params) {
    var {
      elementId,
      touches,
      changedTouches
    } = params;
    var el = get(elementId);
    touchMove(el, {
      touches,
      changedTouches
    });
  });
  return _touchmove.apply(this, arguments);
}
function touchend(_x10) {
  return _touchend.apply(this, arguments);
}
function _touchend() {
  _touchend = asyncToGenerator_default()(function* (params) {
    var {
      elementId,
      touches,
      changedTouches
    } = params;
    var el = get(elementId);
    touchEnd(el, {
      touches,
      changedTouches
    });
  });
  return _touchend.apply(this, arguments);
}
function triggerEvent(_x11) {
  return _triggerEvent.apply(this, arguments);
}
function _triggerEvent() {
  _triggerEvent = asyncToGenerator_default()(function* (params) {
    var {
      type,
      elementId
    } = params;
    var {
      detail
    } = params;
    var el = get(elementId);
    if (isUndef_default()(detail)) detail = {};
    el.__wxElement.triggerEvent(type, detail);
  });
  return _triggerEvent.apply(this, arguments);
}
function callFunction(_x12) {
  return _callFunction.apply(this, arguments);
}
function _callFunction() {
  _callFunction = asyncToGenerator_default()(function* (params) {
    var {
      functionName,
      args,
      elementId
    } = params;
    if (!functionName) {
      throw Error('functionName is not provided');
    }
    var el = get(elementId);
    args.unshift(el);
    var fn = safeGet_default()(elementFunctions, functionName);
    if (!fn) {
      throw Error(`${functionName} not exists`);
    }
    return {
      result: fn.apply(null, args)
    };
  });
  return _callFunction.apply(this, arguments);
}
function genEvent(eventName, el, eventOptions) {
  var eventData = eventOptions.eventData || {};
  var eventDetail = eventData.detail || {};
  var touches = eventData.touches || [];
  var changedTouches = eventData.changedTouches || [];
  touches = normalizeTouches(el, touches);
  changedTouches = normalizeTouches(el, changedTouches);
  var event = document.createEvent('Event');
  event.initEvent(eventName, true, true);
  event.touches = touches;
  event.changedTouches = changedTouches;
  var parserEvent = {
    bubbles: true,
    capturePhase: true,
    composed: true,
    extraFields: {
      _allowWriteOnly: true,
      touches,
      changedTouches
    },
    originalEvent: event
  };
  var exparserEvent = exparser.Event.create(eventName, eventDetail, parserEvent);
  return exparserEvent;
}
function dispatchEvent(_x13) {
  return _dispatchEvent.apply(this, arguments);
}
function _dispatchEvent() {
  _dispatchEvent = asyncToGenerator_default()(function* (params) {
    var {
      eventName,
      elementId,
      ...other
    } = params;
    if (!eventName) {
      throw Error('eventName is not provided');
    }
    var el = get(elementId);
    var realTarget = other.$ ? el.__wxElement.$[other.$] : el;
    if (!realTarget) {
      throw Error('target is not found');
    }
    var _event = genEvent(eventName, realTarget, params);
    if (eventName === 'tap') {
      __virtualDOM__.wrapTapMark(() => {
        exparser.Event.dispatchEvent(realTarget, _event);
      });
    } else if (eventName === 'scroll') {
      var _params$eventData;
      var {
        scrollTop,
        scrollLeft
      } = (params === null || params === void 0 ? void 0 : (_params$eventData = params.eventData) === null || _params$eventData === void 0 ? void 0 : _params$eventData.scrollDetail) || {};
      if (realTarget !== document) {
        var _target = realTarget;
        if (_target.tagName === 'WX-SCROLL-VIEW') {
          var svTarget = realTarget.__wxElement.$;
          _target = svTarget.main.$$ ? svTarget.main.$$ : svTarget.main;
        }
        if (!isNaN(scrollTop)) {
          _target.scrollTop = Number(scrollTop);
        }
        if (!isNaN(scrollLeft)) {
          _target.scrollLeft = Number(scrollLeft);
        }
      } else {
        if (!isNaN(scrollTop)) {
          document.documentElement.scrollTop = Number(scrollTop);
          document.body.scrollTop = Number(scrollTop);
        }
      }
    } else {
      exparser.Event.dispatchEvent(realTarget, _event);
    }
  });
  return _dispatchEvent.apply(this, arguments);
}
var elementFunctions = {
  'scroll-view': {
    scrollTo(el, x, y) {
      var wxElement = el.__wxElement;
      wxElement.$.main.$$.scrollLeft = x;
      wxElement.$.main.$$.scrollTop = y;
    },
    scrollTop(el) {
      return el.__wxElement.$.main.$$.scrollTop;
    },
    scrollLeft(el) {
      return el.__wxElement.$.main.$$.scrollLeft;
    },
    scrollWidth(el) {
      return el.__wxElement.$.main.$$.scrollWidth;
    },
    scrollHeight(el) {
      return el.__wxElement.$.main.$$.scrollHeight;
    }
  },
  swiper: {
    swipeTo(el, index) {
      var wxElement = el.__wxElement;
      wxElement.__currentChangeSource = 'touch';
      wxElement.current = index;
      wxElement._animateViewport(index, 'touch', 0);
    }
  },
  input: {
    input(el, value) {
      var wxElement = el.__wxElement;
      if (wxElement.onKeyboardComplete) {
        var isIos = wx.getPlatform() === 'ios';
        var keyboardShow = false;
        if (isIos) {
          keyboardShow = wxElement._keyboardShow;
          wxElement._keyboardShow = true;
        }
        wxElement.onKeyboardComplete({
          detail: {
            value,
            cursor: value.length,
            inputId: wxElement._inputId
          }
        });
        if (isIos) {
          wxElement._keyboardShow = keyboardShow;
        }
      } else {
        wxElement._inputKey({
          target: {
            value
          }
        });
        wxElement._showValueChange(value);
      }
    }
  },
  textarea: {
    input(el, value) {
      var wxElement = el.__wxElement;
      if (wxElement.onKeyboardComplete) {
        wxElement.onKeyboardComplete({
          detail: {
            value,
            cursor: value.length,
            inputId: wxElement._inputId
          }
        });
      } else {
        wxElement.onTextAreaInput({
          target: {
            value
          }
        });
      }
    }
  },
  'movable-view': {
    moveTo(el, x, y) {
      el.__wxElement._animationTo(x, y);
    }
  },
  switch: {
    tap(el) {
      el.__wxElement.onInputChange();
    }
  },
  slider: {
    slideTo(el, value) {
      var wxElement = el.__wxElement;
      var width = wxElement.$.step.offsetWidth;
      var startLoc = wxElement.$.step.getBoundingClientRect().left;
      wxElement._onUserChangedValue({
        detail: {
          x: (value - wxElement.min) * width / (wxElement.max - wxElement.min) + startLoc
        }
      });
    }
  }
};
function touchStart(el, options = {}) {
  var {
    touches = [],
    changedTouches = []
  } = options;
  if (isEmpty_default()(touches)) touches = [getDefTouch(el)];
  if (isEmpty_default()(changedTouches)) changedTouches = [getDefTouch(el)];
  dispatchTouchEvent('touchstart', el, {
    touches,
    changedTouches
  });
}
function touchMove(el, options = {}) {
  var {
    touches = [],
    changedTouches = []
  } = options;
  if (isEmpty_default()(touches)) touches = [getDefTouch(el)];
  if (isEmpty_default()(changedTouches)) changedTouches = [getDefTouch(el)];
  dispatchTouchEvent('touchmove', el, {
    touches,
    changedTouches
  });
}
function touchEnd(el, options = {}) {
  var {
    touches = []
  } = options;
  var {
    changedTouches = []
  } = options;
  if (isEmpty_default()(changedTouches)) changedTouches = [getDefTouch(el)];
  dispatchTouchEvent('touchend', el, {
    touches,
    changedTouches
  });
}
function dispatchTouchEvent(type, el, options) {
  var {
    touches,
    changedTouches
  } = options;
  var event = document.createEvent('Event');
  event.initEvent(type, true, true);
  event.touches = normalizeTouches(el, touches);
  event.changedTouches = normalizeTouches(el, changedTouches);
  el.dispatchEvent(event);
}
function getDefTouch(el) {
  var pageX = el.offsetLeft + el.offsetWidth / 2;
  var pageY = el.offsetTop + el.offsetHeight / 2;
  return {
    identifier: 0,
    pageX,
    pageY,
    clientX: pageX - window.pageXOffset,
    clientY: pageY - window.pageYOffset
  };
}
function normalizeTouches(el, touches) {
  var scrollY = window.scrollY;
  var scrollX = window.scrollX;
  return map_default()(touches, touch => {
    if (isUndef_default()(touch.pageX) && touch.clientX) {
      touch.pageX = touch.clientX + scrollX;
    } else if (touch.pageX && isUndef_default()(touch.clientX)) {
      touch.clientX = touch.pageX - scrollX;
    }
    if (isUndef_default()(touch.pageY) && touch.clientY) {
      touch.pageY = touch.clientY + scrollY;
    } else if (touch.pageY && isUndef_default()(touch.clientY)) {
      touch.clientY = touch.pageY - scrollY;
    }
    defaults_default()(touch, {
      target: el,
      identifier: 0,
      pageX: 0,
      pageY: 0,
      clientX: 0,
      clientY: 0,
      force: 1
    });
    return touch;
  });
}
;// CONCATENATED MODULE: ./src/common/xpath.ts
var xpath = __webpack_require__(233);
xpath.NodeTest.localNameMatches = function (localName, xpc, n) {
  var wxlocalName = `wx-${localName}`;
  var nLocalName = n.localName || n.nodeName;
  return xpc.caseInsensitive ? localName.toLowerCase() === nLocalName.toLowerCase() || wxlocalName.toLowerCase() === nLocalName.toLowerCase() : localName === nLocalName || wxlocalName === nLocalName;
};
var _orginApplyStep = xpath.PathExpr.applyStep;
xpath.PathExpr.applyStep = function (step, xpc, node) {
  var newNodes = [];
  xpc.contextNode = node;
  switch (step.axis) {
    case xpath.Step.CHILD:
      {
        var st = [xpc.contextNode.firstChild];
        while (st.length > 0) {
          for (var m = st.shift(); m != null;) {
            var mLocalName = m.localName || m.nodeName;
            if (mLocalName.startsWith('wx-') || mLocalName.startsWith('#')) {
              if (step.nodeTest.matches(m, xpc)) {
                newNodes.push(m);
              }
            } else if (m.firstChild != null) {
              st.push(m.firstChild);
            }
            m = m.nextSibling;
          }
        }
        break;
      }
    default:
      newNodes = _orginApplyStep.call(xpath.PathExpr, step, xpc, node);
  }
  return newNodes;
};
/* harmony default export */ const common_xpath = (xpath);
;// CONCATENATED MODULE: ./src/webview/page.ts






function page_getElement(_x) {
  return _getElement.apply(this, arguments);
}
function _getElement() {
  _getElement = asyncToGenerator_default()(function* (params) {
    var {
      selector
    } = params;
    selector = transSelector(selector);
    var el = window.document.querySelector(selector);
    if (!isValidEl(el)) el = null;
    if (!el) {
      throw Error('no such element');
    }
    return transEl(el);
  });
  return _getElement.apply(this, arguments);
}
function page_getElements(_x2) {
  return _getElements.apply(this, arguments);
}
function _getElements() {
  _getElements = asyncToGenerator_default()(function* (params) {
    var {
      selector
    } = params;
    selector = transSelector(selector);
    var els = toArr_default()(window.document.querySelectorAll(selector));
    var elements = [];
    for (var el of els) {
      if (isValidEl(el)) {
        elements.push(transEl(el));
      }
    }
    return {
      elements
    };
  });
  return _getElements.apply(this, arguments);
}
function getWindowProperties(params) {
  var {
    names
  } = params;
  return {
    properties: names.map(name => safeGet_default()(window, name))
  };
}
function getElementsByXpath(_x3) {
  return _getElementsByXpath.apply(this, arguments);
}
function _getElementsByXpath() {
  _getElementsByXpath = asyncToGenerator_default()(function* (params) {
    var {
      selector
    } = params;
    var evaluator = common_xpath.parse(selector);
    var nodeSet = evaluator.evaluate({
      node: document.body,
      isHtml: true
    });
    var elements = [];
    for (var el of nodeSet.nodes) {
      if (isValidEl(el)) {
        elements.push(transEl(el));
      }
    }
    return {
      elements
    };
  });
  return _getElementsByXpath.apply(this, arguments);
}
function getElementByXpath(_x4) {
  return _getElementByXpath.apply(this, arguments);
}
function _getElementByXpath() {
  _getElementByXpath = asyncToGenerator_default()(function* (params) {
    var {
      selector
    } = params;
    var evaluator = common_xpath.parse(selector);
    var nodeSet = evaluator.evaluate({
      node: document.body,
      isHtml: true
    });
    var el = nodeSet.size > 0 ? nodeSet.nodes[0] : null;
    if (!isValidEl(el)) el = null;
    if (!el) {
      throw Error('no such element');
    }
    return transEl(el);
  });
  return _getElementByXpath.apply(this, arguments);
}
;// CONCATENATED MODULE: ./src/webview/methods.ts


var methods = {
  'Page.getElement': page_getElement,
  'Page.getElements': page_getElements,
  'Page.getWindowProperties': getWindowProperties,
  'Page.getElementByXpath': getElementByXpath,
  'Page.getElementsByXpath': getElementsByXpath,
  'Element.getElement': getElement,
  'Element.getElements': getElements,
  'Element.getAttributes': getAttributes,
  'Element.getStyles': getStyles,
  'Element.getWXML': getWXML,
  'Element.getDOMProperties': getDOMProperties,
  'Element.getProperties': getProperties,
  'Element.getOffset': getOffset,
  'Element.tap': tap,
  'Element.touchstart': touchstart,
  'Element.touchmove': touchmove,
  'Element.touchend': touchend,
  'Element.triggerEvent': triggerEvent,
  'Element.callFunction': callFunction,
  'Element.dispatchEvent': dispatchEvent
};
/* harmony default export */ const webview_methods = (methods);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/waitUntil.js
var waitUntil = __webpack_require__(446);
var waitUntil_default = /*#__PURE__*/__webpack_require__.n(waitUntil);
;// CONCATENATED MODULE: ./src/common/bridge.ts

var jsBridge = __webpack_require__.g.WeixinJSBridge;
var isReady = false;
var callbacks = [];
__webpack_require__.g.__wxConfig.clientDebug = true;
function ready() {
  isReady = true;
  for (var i = 0, len = callbacks.length; i < len; i++) {
    callbacks[i]();
  }
  callbacks = [];
}
var descriptor = Object.getOwnPropertyDescriptor(__webpack_require__.g, 'WeixinJSBridge');
if (jsBridge && jsBridge.on) {
  ready();
} else if (descriptor && descriptor.configurable === false) {
  waitUntil_default()(() => __webpack_require__.g.WeixinJSBridge && __webpack_require__.g.WeixinJSBridge.on, 5000, 50).then(() => {
    jsBridge = __webpack_require__.g.WeixinJSBridge;
    ready();
  });
} else {
  Object.defineProperty(__webpack_require__.g, 'WeixinJSBridge', {
    set(val) {
      if (val && val.on) {
        jsBridge = val;
        ready();
      }
    },
    get() {
      return jsBridge;
    },
    configurable: true
  });
}
/* harmony default export */ const bridge = ({
  on(...args) {
    return jsBridge.on(...args);
  },
  publish(...args) {
    return jsBridge.publish(...args);
  },
  invoke(...args) {
    if (__webpack_require__.g.__isAppServiceRemoteDebugMode__ && args[0] === 'sendAutoMessage') {
      var _global$__debugMessag;
      (_global$__debugMessag = __webpack_require__.g.__debugMessager) === null || _global$__debugMessag === void 0 ? void 0 : _global$__debugMessag.sendToDevtools(args[0], args[1]);
    }
    return jsBridge.invoke(...args);
  },
  subscribe(...args) {
    return jsBridge.subscribe(...args);
  },
  onReady(cb) {
    if (isReady) {
      cb();
    } else {
      callbacks.push(cb);
    }
  }
});
;// CONCATENATED MODULE: ./src/webview/jssdk.sdk.ts

var callbackIdInc = 1;
var jssdk_sdk_callbacks = {};
bridge.onReady(() => {
  bridge.subscribe('callbackAutoInvoke', ({
    res,
    callbackId
  }) => {
    var func = jssdk_sdk_callbacks[callbackId];
    if (!func) return;
    func(res);
    delete jssdk_sdk_callbacks[callbackId];
  });
});
function callAutoInvoke(api, args, callback) {
  var callbackId = callbackIdInc++;
  jssdk_sdk_callbacks[callbackId] = callback;
  bridge.publish('callAutoInvoke', {
    callbackId,
    name: api,
    args
  });
  return;
}
var JSSDK = {
  operateWXData: 'operateWXData',
  getPhoneNumber: 'getPhoneNumber',
  getUserAutoFillData: 'getUserAutoFillData',
  setUserAutoFillData: 'setUserAutoFillData',
  deleteUserAutoFillData: 'deleteUserAutoFillData',
  requestAuthUserAutoFillData: 'requestAuthUserAutoFillData'
};
;// CONCATENATED MODULE: ./src/webview/index.ts




bridge.onReady(() => {
  var _wxConfig__$debugL;
  bridge.subscribe('sendAutoMessage', /*#__PURE__*/function () {
    var _ref = asyncToGenerator_default()(function* (msg) {
      var {
        method,
        params,
        id
      } = msg;
      var resultMsg = {
        id
      };
      try {
        resultMsg.result = yield callMethod(method, params);
      } catch (e) {
        resultMsg.error = {
          message: e.message
        };
      }
      bridge.publish('sendAutoMessage', resultMsg);
    });
    return function (_x) {
      return _ref.apply(this, arguments);
    };
  }());
  var ____wxConfig__ = __webpack_require__.g.__wxConfig;
  if (____wxConfig__ !== null && ____wxConfig__ !== void 0 && (_wxConfig__$debugL = ____wxConfig__.debugLaunchInfo) !== null && _wxConfig__$debugL !== void 0 && _wxConfig__$debugL.autoTest) {
    var originInvoke = __webpack_require__.g.WeixinJSBridge.invoke;
    Object.defineProperty(__webpack_require__.g.WeixinJSBridge, 'invoke', {
      value(...argsArr) {
        var [name, args, callback, keepOriginalParams] = argsArr;
        if (JSSDK[name]) {
          return callAutoInvoke(name, args, callback);
        }
        return originInvoke.apply(__webpack_require__.g.WeixinJSBridge, argsArr);
      }
    });
  }
});
function callMethod(_x2, _x3) {
  return _callMethod.apply(this, arguments);
}
function _callMethod() {
  _callMethod = asyncToGenerator_default()(function* (method, params) {
    if (webview_methods[method]) {
      return (yield webview_methods[method](params)) || {};
    } else {
      throw Error(`webview ${method} unimplemented`);
    }
  });
  return _callMethod.apply(this, arguments);
}
})();

/******/ })()
;