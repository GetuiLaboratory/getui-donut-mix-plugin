this.__isAppServiceRemoteDebugMode__ = true;
var __WeixinJSCore__ = this.WeixinJSCore;

var __AppServiceRemoteDebugger__;!function(){var e={589:function(e){function t(e,t,r,i,n,s,a){try{var o=e[s](a),u=o.value}catch(e){return void r(e)}o.done?t(u):Promise.resolve(u).then(i,n)}e.exports=function(e){return function(){var r=this,i=arguments;return new Promise((function(n,s){var a=e.apply(r,i);function o(e){t(a,n,s,o,u,"next",e)}function u(e){t(a,n,s,o,u,"throw",e)}o(void 0)}))}},e.exports.__esModule=!0,e.exports.default=e.exports},852:function(e,t,r){var i,n,s;!function(){"use strict";n=[r(898)],void 0===(s="function"==typeof(i=function(e){var t=/(^|@)\S+:\d+/,r=/^\s*at .*(\S+:\d+|\(native\))/m,i=/^(eval@)?(\[native code])?$/;return{parse:function(e){if(void 0!==e.stacktrace||void 0!==e["opera#sourceloc"])return this.parseOpera(e);if(e.stack&&e.stack.match(r))return this.parseV8OrIE(e);if(e.stack)return this.parseFFOrSafari(e);throw new Error("Cannot parse given Error object")},extractLocation:function(e){if(-1===e.indexOf(":"))return[e];var t=/(.+?)(?::(\d+))?(?::(\d+))?$/.exec(e.replace(/[()]/g,""));return[t[1],t[2]||void 0,t[3]||void 0]},parseV8OrIE:function(t){return t.stack.split("\n").filter((function(e){return!!e.match(r)}),this).map((function(t){t.indexOf("(eval ")>-1&&(t=t.replace(/eval code/g,"eval").replace(/(\(eval at [^()]*)|(\),.*$)/g,""));var r=t.replace(/^\s+/,"").replace(/\(eval code/g,"("),i=r.match(/ (\((.+):(\d+):(\d+)\)$)/),n=(r=i?r.replace(i[0],""):r).split(/\s+/).slice(1),s=this.extractLocation(i?i[1]:n.pop()),a=n.join(" ")||void 0,o=["eval","<anonymous>"].indexOf(s[0])>-1?void 0:s[0];return new e({functionName:a,fileName:o,lineNumber:s[1],columnNumber:s[2],source:t})}),this)},parseFFOrSafari:function(t){return t.stack.split("\n").filter((function(e){return!e.match(i)}),this).map((function(t){if(t.indexOf(" > eval")>-1&&(t=t.replace(/ line (\d+)(?: > eval line \d+)* > eval:\d+:\d+/g,":$1")),-1===t.indexOf("@")&&-1===t.indexOf(":"))return new e({functionName:t});var r=/((.*".+"[^@]*)?[^@]*)(?:@)/,i=t.match(r),n=i&&i[1]?i[1]:void 0,s=this.extractLocation(t.replace(r,""));return new e({functionName:n,fileName:s[0],lineNumber:s[1],columnNumber:s[2],source:t})}),this)},parseOpera:function(e){return!e.stacktrace||e.message.indexOf("\n")>-1&&e.message.split("\n").length>e.stacktrace.split("\n").length?this.parseOpera9(e):e.stack?this.parseOpera11(e):this.parseOpera10(e)},parseOpera9:function(t){for(var r=/Line (\d+).*script (?:in )?(\S+)/i,i=t.message.split("\n"),n=[],s=2,a=i.length;s<a;s+=2){var o=r.exec(i[s]);o&&n.push(new e({fileName:o[2],lineNumber:o[1],source:i[s]}))}return n},parseOpera10:function(t){for(var r=/Line (\d+).*script (?:in )?(\S+)(?:: In function (\S+))?$/i,i=t.stacktrace.split("\n"),n=[],s=0,a=i.length;s<a;s+=2){var o=r.exec(i[s]);o&&n.push(new e({functionName:o[3]||void 0,fileName:o[2],lineNumber:o[1],source:i[s]}))}return n},parseOpera11:function(r){return r.stack.split("\n").filter((function(e){return!!e.match(t)&&!e.match(/^Error created at/)}),this).map((function(t){var r,i=t.split("@"),n=this.extractLocation(i.pop()),s=i.shift()||"",a=s.replace(/<anonymous function(: (\w+))?>/,"$2").replace(/\([^)]*\)/g,"")||void 0;s.match(/\(([^)]*)\)/)&&(r=s.replace(/^[^(]+\(([^)]*)\)$/,"$1"));var o=void 0===r||"[arguments not available]"===r?void 0:r.split(",");return new e({functionName:a,args:o,fileName:n[0],lineNumber:n[1],columnNumber:n[2],source:t})}),this)}}})?i.apply(t,n):i)||(e.exports=s)}(globalThis)},180:function(e,t,r){var i=r(994),n=Object.prototype.hasOwnProperty,s="undefined"!=typeof Map;function a(){this._array=[],this._set=s?new Map:Object.create(null)}a.fromArray=function(e,t){for(var r=new a,i=0,n=e.length;i<n;i++)r.add(e[i],t);return r},a.prototype.size=function(){return s?this._set.size:Object.getOwnPropertyNames(this._set).length},a.prototype.add=function(e,t){var r=s?e:i.toSetString(e),a=s?this.has(e):n.call(this._set,r),o=this._array.length;a&&!t||this._array.push(e),a||(s?this._set.set(e,o):this._set[r]=o)},a.prototype.has=function(e){if(s)return this._set.has(e);var t=i.toSetString(e);return n.call(this._set,t)},a.prototype.indexOf=function(e){if(s){var t=this._set.get(e);if(t>=0)return t}else{var r=i.toSetString(e);if(n.call(this._set,r))return this._set[r]}throw new Error('"'+e+'" is not in the set.')},a.prototype.at=function(e){if(e>=0&&e<this._array.length)return this._array[e];throw new Error("No element indexed by "+e)},a.prototype.toArray=function(){return this._array.slice()},t.C=a},973:function(e,t,r){var i=r(373);t.encode=function(e){var t,r="",n=function(e){return e<0?1+(-e<<1):0+(e<<1)}(e);do{t=31&n,(n>>>=5)>0&&(t|=32),r+=i.encode(t)}while(n>0);return r},t.decode=function(e,t,r){var n,s,a,o,u=e.length,c=0,h=0;do{if(t>=u)throw new Error("Expected more digits in base 64 VLQ value.");if(-1===(s=i.decode(e.charCodeAt(t++))))throw new Error("Invalid base64 digit: "+e.charAt(t-1));n=!!(32&s),c+=(s&=31)<<h,h+=5}while(n);r.value=(o=(a=c)>>1,1&~a?o:-o),r.rest=t}},373:function(e,t){var r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");t.encode=function(e){if(0<=e&&e<r.length)return r[e];throw new TypeError("Must be between 0 and 63: "+e)},t.decode=function(e){return 65<=e&&e<=90?e-65:97<=e&&e<=122?e-97+26:48<=e&&e<=57?e-48+52:43==e?62:47==e?63:-1}},720:function(e,t){function r(e,i,n,s,a,o){var u=Math.floor((i-e)/2)+e,c=a(n,s[u],!0);return 0===c?u:c>0?i-u>1?r(u,i,n,s,a,o):o==t.LEAST_UPPER_BOUND?i<s.length?i:-1:u:u-e>1?r(e,u,n,s,a,o):o==t.LEAST_UPPER_BOUND?u:e<0?-1:e}t.GREATEST_LOWER_BOUND=1,t.LEAST_UPPER_BOUND=2,t.search=function(e,i,n,s){if(0===i.length)return-1;var a=r(-1,i.length,e,i,n,s||t.GREATEST_LOWER_BOUND);if(a<0)return-1;for(;a-1>=0&&0===n(i[a],i[a-1],!0);)--a;return a}},943:function(e,t,r){var i=r(994);function n(){this._array=[],this._sorted=!0,this._last={generatedLine:-1,generatedColumn:0}}n.prototype.unsortedForEach=function(e,t){this._array.forEach(e,t)},n.prototype.add=function(e){var t,r,n,s,a,o;t=this._last,r=e,n=t.generatedLine,s=r.generatedLine,a=t.generatedColumn,o=r.generatedColumn,s>n||s==n&&o>=a||i.compareByGeneratedPositionsInflated(t,r)<=0?(this._last=e,this._array.push(e)):(this._sorted=!1,this._array.push(e))},n.prototype.toArray=function(){return this._sorted||(this._array.sort(i.compareByGeneratedPositionsInflated),this._sorted=!0),this._array},t.P=n},232:function(e,t){function r(e,t,r){var i=e[t];e[t]=e[r],e[r]=i}function i(e,t,n,s){if(n<s){var a=n-1;r(e,(h=n,l=s,Math.round(h+Math.random()*(l-h))),s);for(var o=e[s],u=n;u<s;u++)t(e[u],o)<=0&&r(e,a+=1,u);r(e,a+1,u);var c=a+1;i(e,t,n,c-1),i(e,t,c+1,s)}var h,l}t.g=function(e,t){i(e,t,0,e.length-1)}},961:function(e,t,r){var i=r(994),n=r(720),s=r(180).C,a=r(973),o=r(232).g;function u(e,t){var r=e;return"string"==typeof e&&(r=i.parseSourceMapInput(e)),null!=r.sections?new l(r,t):new c(r,t)}function c(e,t){var r=e;"string"==typeof e&&(r=i.parseSourceMapInput(e));var n=i.getArg(r,"version"),a=i.getArg(r,"sources"),o=i.getArg(r,"names",[]),u=i.getArg(r,"sourceRoot",null),c=i.getArg(r,"sourcesContent",null),h=i.getArg(r,"mappings"),l=i.getArg(r,"file",null);if(n!=this._version)throw new Error("Unsupported version: "+n);u&&(u=i.normalize(u)),a=a.map(String).map(i.normalize).map((function(e){return u&&i.isAbsolute(u)&&i.isAbsolute(e)?i.relative(u,e):e})),this._names=s.fromArray(o.map(String),!0),this._sources=s.fromArray(a,!0),this._absoluteSources=this._sources.toArray().map((function(e){return i.computeSourceURL(u,e,t)})),this.sourceRoot=u,this.sourcesContent=c,this._mappings=h,this._sourceMapURL=t,this.file=l}function h(){this.generatedLine=0,this.generatedColumn=0,this.source=null,this.originalLine=null,this.originalColumn=null,this.name=null}function l(e,t){var r=e;"string"==typeof e&&(r=i.parseSourceMapInput(e));var n=i.getArg(r,"version"),a=i.getArg(r,"sections");if(n!=this._version)throw new Error("Unsupported version: "+n);this._sources=new s,this._names=new s;var o={line:-1,column:0};this._sections=a.map((function(e){if(e.url)throw new Error("Support for url field in sections not implemented.");var r=i.getArg(e,"offset"),n=i.getArg(r,"line"),s=i.getArg(r,"column");if(n<o.line||n===o.line&&s<o.column)throw new Error("Section offsets must be ordered and non-overlapping.");return o=r,{generatedOffset:{generatedLine:n+1,generatedColumn:s+1},consumer:new u(i.getArg(e,"map"),t)}}))}u.fromSourceMap=function(e,t){return c.fromSourceMap(e,t)},u.prototype._version=3,u.prototype.__generatedMappings=null,Object.defineProperty(u.prototype,"_generatedMappings",{configurable:!0,enumerable:!0,get:function(){return this.__generatedMappings||this._parseMappings(this._mappings,this.sourceRoot),this.__generatedMappings}}),u.prototype.__originalMappings=null,Object.defineProperty(u.prototype,"_originalMappings",{configurable:!0,enumerable:!0,get:function(){return this.__originalMappings||this._parseMappings(this._mappings,this.sourceRoot),this.__originalMappings}}),u.prototype._charIsMappingSeparator=function(e,t){var r=e.charAt(t);return";"===r||","===r},u.prototype._parseMappings=function(e,t){throw new Error("Subclasses must implement _parseMappings")},u.GENERATED_ORDER=1,u.ORIGINAL_ORDER=2,u.GREATEST_LOWER_BOUND=1,u.LEAST_UPPER_BOUND=2,u.prototype.eachMapping=function(e,t,r){var n,s=t||null;switch(r||u.GENERATED_ORDER){case u.GENERATED_ORDER:n=this._generatedMappings;break;case u.ORIGINAL_ORDER:n=this._originalMappings;break;default:throw new Error("Unknown order of iteration.")}var a=this.sourceRoot;n.map((function(e){var t=null===e.source?null:this._sources.at(e.source);return{source:t=i.computeSourceURL(a,t,this._sourceMapURL),generatedLine:e.generatedLine,generatedColumn:e.generatedColumn,originalLine:e.originalLine,originalColumn:e.originalColumn,name:null===e.name?null:this._names.at(e.name)}}),this).forEach(e,s)},u.prototype.allGeneratedPositionsFor=function(e){var t=i.getArg(e,"line"),r={source:i.getArg(e,"source"),originalLine:t,originalColumn:i.getArg(e,"column",0)};if(r.source=this._findSourceIndex(r.source),r.source<0)return[];var s=[],a=this._findMapping(r,this._originalMappings,"originalLine","originalColumn",i.compareByOriginalPositions,n.LEAST_UPPER_BOUND);if(a>=0){var o=this._originalMappings[a];if(void 0===e.column)for(var u=o.originalLine;o&&o.originalLine===u;)s.push({line:i.getArg(o,"generatedLine",null),column:i.getArg(o,"generatedColumn",null),lastColumn:i.getArg(o,"lastGeneratedColumn",null)}),o=this._originalMappings[++a];else for(var c=o.originalColumn;o&&o.originalLine===t&&o.originalColumn==c;)s.push({line:i.getArg(o,"generatedLine",null),column:i.getArg(o,"generatedColumn",null),lastColumn:i.getArg(o,"lastGeneratedColumn",null)}),o=this._originalMappings[++a]}return s},t.SourceMapConsumer=u,c.prototype=Object.create(u.prototype),c.prototype.consumer=u,c.prototype._findSourceIndex=function(e){var t,r=e;if(null!=this.sourceRoot&&(r=i.relative(this.sourceRoot,r)),this._sources.has(r))return this._sources.indexOf(r);for(t=0;t<this._absoluteSources.length;++t)if(this._absoluteSources[t]==e)return t;return-1},c.fromSourceMap=function(e,t){var r=Object.create(c.prototype),n=r._names=s.fromArray(e._names.toArray(),!0),a=r._sources=s.fromArray(e._sources.toArray(),!0);r.sourceRoot=e._sourceRoot,r.sourcesContent=e._generateSourcesContent(r._sources.toArray(),r.sourceRoot),r.file=e._file,r._sourceMapURL=t,r._absoluteSources=r._sources.toArray().map((function(e){return i.computeSourceURL(r.sourceRoot,e,t)}));for(var u=e._mappings.toArray().slice(),l=r.__generatedMappings=[],p=r.__originalMappings=[],d=0,f=u.length;d<f;d++){var g=u[d],m=new h;m.generatedLine=g.generatedLine,m.generatedColumn=g.generatedColumn,g.source&&(m.source=a.indexOf(g.source),m.originalLine=g.originalLine,m.originalColumn=g.originalColumn,g.name&&(m.name=n.indexOf(g.name)),p.push(m)),l.push(m)}return o(r.__originalMappings,i.compareByOriginalPositions),r},c.prototype._version=3,Object.defineProperty(c.prototype,"sources",{get:function(){return this._absoluteSources.slice()}}),c.prototype._parseMappings=function(e,t){for(var r,n,s,u,c,l=1,p=0,d=0,f=0,g=0,m=0,v=e.length,b=0,y={},x={},S=[],_=[];b<v;)if(";"===e.charAt(b))l++,b++,p=0;else if(","===e.charAt(b))b++;else{for((r=new h).generatedLine=l,u=b;u<v&&!this._charIsMappingSeparator(e,u);u++);if(s=y[n=e.slice(b,u)])b+=n.length;else{for(s=[];b<u;)a.decode(e,b,x),c=x.value,b=x.rest,s.push(c);if(2===s.length)throw new Error("Found a source, but no line and column");if(3===s.length)throw new Error("Found a source and line, but no column");y[n]=s}r.generatedColumn=p+s[0],p=r.generatedColumn,s.length>1&&(r.source=g+s[1],g+=s[1],r.originalLine=d+s[2],d=r.originalLine,r.originalLine+=1,r.originalColumn=f+s[3],f=r.originalColumn,s.length>4&&(r.name=m+s[4],m+=s[4])),_.push(r),"number"==typeof r.originalLine&&S.push(r)}o(_,i.compareByGeneratedPositionsDeflated),this.__generatedMappings=_,o(S,i.compareByOriginalPositions),this.__originalMappings=S},c.prototype._findMapping=function(e,t,r,i,s,a){if(e[r]<=0)throw new TypeError("Line must be greater than or equal to 1, got "+e[r]);if(e[i]<0)throw new TypeError("Column must be greater than or equal to 0, got "+e[i]);return n.search(e,t,s,a)},c.prototype.computeColumnSpans=function(){for(var e=0;e<this._generatedMappings.length;++e){var t=this._generatedMappings[e];if(e+1<this._generatedMappings.length){var r=this._generatedMappings[e+1];if(t.generatedLine===r.generatedLine){t.lastGeneratedColumn=r.generatedColumn-1;continue}}t.lastGeneratedColumn=1/0}},c.prototype.originalPositionFor=function(e){var t={generatedLine:i.getArg(e,"line"),generatedColumn:i.getArg(e,"column")},r=this._findMapping(t,this._generatedMappings,"generatedLine","generatedColumn",i.compareByGeneratedPositionsDeflated,i.getArg(e,"bias",u.GREATEST_LOWER_BOUND));if(r>=0){var n=this._generatedMappings[r];if(n.generatedLine===t.generatedLine){var s=i.getArg(n,"source",null);null!==s&&(s=this._sources.at(s),s=i.computeSourceURL(this.sourceRoot,s,this._sourceMapURL));var a=i.getArg(n,"name",null);return null!==a&&(a=this._names.at(a)),{source:s,line:i.getArg(n,"originalLine",null),column:i.getArg(n,"originalColumn",null),name:a}}}return{source:null,line:null,column:null,name:null}},c.prototype.hasContentsOfAllSources=function(){return!!this.sourcesContent&&(this.sourcesContent.length>=this._sources.size()&&!this.sourcesContent.some((function(e){return null==e})))},c.prototype.sourceContentFor=function(e,t){if(!this.sourcesContent)return null;var r=this._findSourceIndex(e);if(r>=0)return this.sourcesContent[r];var n,s=e;if(null!=this.sourceRoot&&(s=i.relative(this.sourceRoot,s)),null!=this.sourceRoot&&(n=i.urlParse(this.sourceRoot))){var a=s.replace(/^file:\/\//,"");if("file"==n.scheme&&this._sources.has(a))return this.sourcesContent[this._sources.indexOf(a)];if((!n.path||"/"==n.path)&&this._sources.has("/"+s))return this.sourcesContent[this._sources.indexOf("/"+s)]}if(t)return null;throw new Error('"'+s+'" is not in the SourceMap.')},c.prototype.generatedPositionFor=function(e){var t=i.getArg(e,"source");if((t=this._findSourceIndex(t))<0)return{line:null,column:null,lastColumn:null};var r={source:t,originalLine:i.getArg(e,"line"),originalColumn:i.getArg(e,"column")},n=this._findMapping(r,this._originalMappings,"originalLine","originalColumn",i.compareByOriginalPositions,i.getArg(e,"bias",u.GREATEST_LOWER_BOUND));if(n>=0){var s=this._originalMappings[n];if(s.source===r.source)return{line:i.getArg(s,"generatedLine",null),column:i.getArg(s,"generatedColumn",null),lastColumn:i.getArg(s,"lastGeneratedColumn",null)}}return{line:null,column:null,lastColumn:null}},l.prototype=Object.create(u.prototype),l.prototype.constructor=u,l.prototype._version=3,Object.defineProperty(l.prototype,"sources",{get:function(){for(var e=[],t=0;t<this._sections.length;t++)for(var r=0;r<this._sections[t].consumer.sources.length;r++)e.push(this._sections[t].consumer.sources[r]);return e}}),l.prototype.originalPositionFor=function(e){var t={generatedLine:i.getArg(e,"line"),generatedColumn:i.getArg(e,"column")},r=n.search(t,this._sections,(function(e,t){var r=e.generatedLine-t.generatedOffset.generatedLine;return r||e.generatedColumn-t.generatedOffset.generatedColumn})),s=this._sections[r];return s?s.consumer.originalPositionFor({line:t.generatedLine-(s.generatedOffset.generatedLine-1),column:t.generatedColumn-(s.generatedOffset.generatedLine===t.generatedLine?s.generatedOffset.generatedColumn-1:0),bias:e.bias}):{source:null,line:null,column:null,name:null}},l.prototype.hasContentsOfAllSources=function(){return this._sections.every((function(e){return e.consumer.hasContentsOfAllSources()}))},l.prototype.sourceContentFor=function(e,t){for(var r=0;r<this._sections.length;r++){var i=this._sections[r].consumer.sourceContentFor(e,!0);if(i)return i}if(t)return null;throw new Error('"'+e+'" is not in the SourceMap.')},l.prototype.generatedPositionFor=function(e){for(var t=0;t<this._sections.length;t++){var r=this._sections[t];if(-1!==r.consumer._findSourceIndex(i.getArg(e,"source"))){var n=r.consumer.generatedPositionFor(e);if(n)return{line:n.line+(r.generatedOffset.generatedLine-1),column:n.column+(r.generatedOffset.generatedLine===n.line?r.generatedOffset.generatedColumn-1:0)}}}return{line:null,column:null}},l.prototype._parseMappings=function(e,t){this.__generatedMappings=[],this.__originalMappings=[];for(var r=0;r<this._sections.length;r++)for(var n=this._sections[r],s=n.consumer._generatedMappings,a=0;a<s.length;a++){var u=s[a],c=n.consumer._sources.at(u.source);c=i.computeSourceURL(n.consumer.sourceRoot,c,this._sourceMapURL),this._sources.add(c),c=this._sources.indexOf(c);var h=null;u.name&&(h=n.consumer._names.at(u.name),this._names.add(h),h=this._names.indexOf(h));var l={source:c,generatedLine:u.generatedLine+(n.generatedOffset.generatedLine-1),generatedColumn:u.generatedColumn+(n.generatedOffset.generatedLine===u.generatedLine?n.generatedOffset.generatedColumn-1:0),originalLine:u.originalLine,originalColumn:u.originalColumn,name:h};this.__generatedMappings.push(l),"number"==typeof l.originalLine&&this.__originalMappings.push(l)}o(this.__generatedMappings,i.compareByGeneratedPositionsDeflated),o(this.__originalMappings,i.compareByOriginalPositions)}},400:function(e,t,r){var i=r(973),n=r(994),s=r(180).C,a=r(943).P;function o(e){e||(e={}),this._file=n.getArg(e,"file",null),this._sourceRoot=n.getArg(e,"sourceRoot",null),this._skipValidation=n.getArg(e,"skipValidation",!1),this._sources=new s,this._names=new s,this._mappings=new a,this._sourcesContents=null}o.prototype._version=3,o.fromSourceMap=function(e){var t=e.sourceRoot,r=new o({file:e.file,sourceRoot:t});return e.eachMapping((function(e){var i={generated:{line:e.generatedLine,column:e.generatedColumn}};null!=e.source&&(i.source=e.source,null!=t&&(i.source=n.relative(t,i.source)),i.original={line:e.originalLine,column:e.originalColumn},null!=e.name&&(i.name=e.name)),r.addMapping(i)})),e.sources.forEach((function(i){var s=i;null!==t&&(s=n.relative(t,i)),r._sources.has(s)||r._sources.add(s);var a=e.sourceContentFor(i);null!=a&&r.setSourceContent(i,a)})),r},o.prototype.addMapping=function(e){var t=n.getArg(e,"generated"),r=n.getArg(e,"original",null),i=n.getArg(e,"source",null),s=n.getArg(e,"name",null);this._skipValidation||this._validateMapping(t,r,i,s),null!=i&&(i=String(i),this._sources.has(i)||this._sources.add(i)),null!=s&&(s=String(s),this._names.has(s)||this._names.add(s)),this._mappings.add({generatedLine:t.line,generatedColumn:t.column,originalLine:null!=r&&r.line,originalColumn:null!=r&&r.column,source:i,name:s})},o.prototype.setSourceContent=function(e,t){var r=e;null!=this._sourceRoot&&(r=n.relative(this._sourceRoot,r)),null!=t?(this._sourcesContents||(this._sourcesContents=Object.create(null)),this._sourcesContents[n.toSetString(r)]=t):this._sourcesContents&&(delete this._sourcesContents[n.toSetString(r)],0===Object.keys(this._sourcesContents).length&&(this._sourcesContents=null))},o.prototype.applySourceMap=function(e,t,r){var i=t;if(null==t){if(null==e.file)throw new Error('SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, or the source map\'s "file" property. Both were omitted.');i=e.file}var a=this._sourceRoot;null!=a&&(i=n.relative(a,i));var o=new s,u=new s;this._mappings.unsortedForEach((function(t){if(t.source===i&&null!=t.originalLine){var s=e.originalPositionFor({line:t.originalLine,column:t.originalColumn});null!=s.source&&(t.source=s.source,null!=r&&(t.source=n.join(r,t.source)),null!=a&&(t.source=n.relative(a,t.source)),t.originalLine=s.line,t.originalColumn=s.column,null!=s.name&&(t.name=s.name))}var c=t.source;null==c||o.has(c)||o.add(c);var h=t.name;null==h||u.has(h)||u.add(h)}),this),this._sources=o,this._names=u,e.sources.forEach((function(t){var i=e.sourceContentFor(t);null!=i&&(null!=r&&(t=n.join(r,t)),null!=a&&(t=n.relative(a,t)),this.setSourceContent(t,i))}),this)},o.prototype._validateMapping=function(e,t,r,i){if(t&&"number"!=typeof t.line&&"number"!=typeof t.column)throw new Error("original.line and original.column are not numbers -- you probably meant to omit the original mapping entirely and only map the generated position. If so, pass null for the original mapping instead of an object with empty or null values.");if((!(e&&"line"in e&&"column"in e&&e.line>0&&e.column>=0)||t||r||i)&&!(e&&"line"in e&&"column"in e&&t&&"line"in t&&"column"in t&&e.line>0&&e.column>=0&&t.line>0&&t.column>=0&&r))throw new Error("Invalid mapping: "+JSON.stringify({generated:e,source:r,original:t,name:i}))},o.prototype._serializeMappings=function(){for(var e,t,r,s,a=0,o=1,u=0,c=0,h=0,l=0,p="",d=this._mappings.toArray(),f=0,g=d.length;f<g;f++){if(e="",(t=d[f]).generatedLine!==o)for(a=0;t.generatedLine!==o;)e+=";",o++;else if(f>0){if(!n.compareByGeneratedPositionsInflated(t,d[f-1]))continue;e+=","}e+=i.encode(t.generatedColumn-a),a=t.generatedColumn,null!=t.source&&(s=this._sources.indexOf(t.source),e+=i.encode(s-l),l=s,e+=i.encode(t.originalLine-1-c),c=t.originalLine-1,e+=i.encode(t.originalColumn-u),u=t.originalColumn,null!=t.name&&(r=this._names.indexOf(t.name),e+=i.encode(r-h),h=r)),p+=e}return p},o.prototype._generateSourcesContent=function(e,t){return e.map((function(e){if(!this._sourcesContents)return null;null!=t&&(e=n.relative(t,e));var r=n.toSetString(e);return Object.prototype.hasOwnProperty.call(this._sourcesContents,r)?this._sourcesContents[r]:null}),this)},o.prototype.toJSON=function(){var e={version:this._version,sources:this._sources.toArray(),names:this._names.toArray(),mappings:this._serializeMappings()};return null!=this._file&&(e.file=this._file),null!=this._sourceRoot&&(e.sourceRoot=this._sourceRoot),this._sourcesContents&&(e.sourcesContent=this._generateSourcesContent(e.sources,e.sourceRoot)),e},o.prototype.toString=function(){return JSON.stringify(this.toJSON())},t.x=o},12:function(e,t,r){var i=r(400).x,n=r(994),s=/(\r?\n)/,a="$$$isSourceNode$$$";function o(e,t,r,i,n){this.children=[],this.sourceContents={},this.line=null==e?null:e,this.column=null==t?null:t,this.source=null==r?null:r,this.name=null==n?null:n,this[a]=!0,null!=i&&this.add(i)}o.fromStringWithSourceMap=function(e,t,r){var i=new o,a=e.split(s),u=0,c=function(){return e()+(e()||"");function e(){return u<a.length?a[u++]:void 0}},h=1,l=0,p=null;return t.eachMapping((function(e){if(null!==p){if(!(h<e.generatedLine)){var t=(r=a[u]||"").substr(0,e.generatedColumn-l);return a[u]=r.substr(e.generatedColumn-l),l=e.generatedColumn,d(p,t),void(p=e)}d(p,c()),h++,l=0}for(;h<e.generatedLine;)i.add(c()),h++;if(l<e.generatedColumn){var r=a[u]||"";i.add(r.substr(0,e.generatedColumn)),a[u]=r.substr(e.generatedColumn),l=e.generatedColumn}p=e}),this),u<a.length&&(p&&d(p,c()),i.add(a.splice(u).join(""))),t.sources.forEach((function(e){var s=t.sourceContentFor(e);null!=s&&(null!=r&&(e=n.join(r,e)),i.setSourceContent(e,s))})),i;function d(e,t){if(null===e||void 0===e.source)i.add(t);else{var s=r?n.join(r,e.source):e.source;i.add(new o(e.originalLine,e.originalColumn,s,t,e.name))}}},o.prototype.add=function(e){if(Array.isArray(e))e.forEach((function(e){this.add(e)}),this);else{if(!e[a]&&"string"!=typeof e)throw new TypeError("Expected a SourceNode, string, or an array of SourceNodes and strings. Got "+e);e&&this.children.push(e)}return this},o.prototype.prepend=function(e){if(Array.isArray(e))for(var t=e.length-1;t>=0;t--)this.prepend(e[t]);else{if(!e[a]&&"string"!=typeof e)throw new TypeError("Expected a SourceNode, string, or an array of SourceNodes and strings. Got "+e);this.children.unshift(e)}return this},o.prototype.walk=function(e){for(var t,r=0,i=this.children.length;r<i;r++)(t=this.children[r])[a]?t.walk(e):""!==t&&e(t,{source:this.source,line:this.line,column:this.column,name:this.name})},o.prototype.join=function(e){var t,r,i=this.children.length;if(i>0){for(t=[],r=0;r<i-1;r++)t.push(this.children[r]),t.push(e);t.push(this.children[r]),this.children=t}return this},o.prototype.replaceRight=function(e,t){var r=this.children[this.children.length-1];return r[a]?r.replaceRight(e,t):"string"==typeof r?this.children[this.children.length-1]=r.replace(e,t):this.children.push("".replace(e,t)),this},o.prototype.setSourceContent=function(e,t){this.sourceContents[n.toSetString(e)]=t},o.prototype.walkSourceContents=function(e){for(var t=0,r=this.children.length;t<r;t++)this.children[t][a]&&this.children[t].walkSourceContents(e);var i=Object.keys(this.sourceContents);for(t=0,r=i.length;t<r;t++)e(n.fromSetString(i[t]),this.sourceContents[i[t]])},o.prototype.toString=function(){var e="";return this.walk((function(t){e+=t})),e},o.prototype.toStringWithSourceMap=function(e){var t={code:"",line:1,column:0},r=new i(e),n=!1,s=null,a=null,o=null,u=null;return this.walk((function(e,i){t.code+=e,null!==i.source&&null!==i.line&&null!==i.column?(s===i.source&&a===i.line&&o===i.column&&u===i.name||r.addMapping({source:i.source,original:{line:i.line,column:i.column},generated:{line:t.line,column:t.column},name:i.name}),s=i.source,a=i.line,o=i.column,u=i.name,n=!0):n&&(r.addMapping({generated:{line:t.line,column:t.column}}),s=null,n=!1);for(var c=0,h=e.length;c<h;c++)10===e.charCodeAt(c)?(t.line++,t.column=0,c+1===h?(s=null,n=!1):n&&r.addMapping({source:i.source,original:{line:i.line,column:i.column},generated:{line:t.line,column:t.column},name:i.name})):t.column++})),this.walkSourceContents((function(e,t){r.setSourceContent(e,t)})),{code:t.code,map:r}}},994:function(e,t){t.getArg=function(e,t,r){if(t in e)return e[t];if(3===arguments.length)return r;throw new Error('"'+t+'" is a required argument.')};var r=/^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/,i=/^data:.+\,.+$/;function n(e){var t=e.match(r);return t?{scheme:t[1],auth:t[2],host:t[3],port:t[4],path:t[5]}:null}function s(e){var t="";return e.scheme&&(t+=e.scheme+":"),t+="//",e.auth&&(t+=e.auth+"@"),e.host&&(t+=e.host),e.port&&(t+=":"+e.port),e.path&&(t+=e.path),t}function a(e){var r=e,i=n(e);if(i){if(!i.path)return e;r=i.path}for(var a,o=t.isAbsolute(r),u=r.split(/\/+/),c=0,h=u.length-1;h>=0;h--)"."===(a=u[h])?u.splice(h,1):".."===a?c++:c>0&&(""===a?(u.splice(h+1,c),c=0):(u.splice(h,2),c--));return""===(r=u.join("/"))&&(r=o?"/":"."),i?(i.path=r,s(i)):r}function o(e,t){""===e&&(e="."),""===t&&(t=".");var r=n(t),o=n(e);if(o&&(e=o.path||"/"),r&&!r.scheme)return o&&(r.scheme=o.scheme),s(r);if(r||t.match(i))return t;if(o&&!o.host&&!o.path)return o.host=t,s(o);var u="/"===t.charAt(0)?t:a(e.replace(/\/+$/,"")+"/"+t);return o?(o.path=u,s(o)):u}t.urlParse=n,t.urlGenerate=s,t.normalize=a,t.join=o,t.isAbsolute=function(e){return"/"===e.charAt(0)||r.test(e)},t.relative=function(e,t){""===e&&(e="."),e=e.replace(/\/$/,"");for(var r=0;0!==t.indexOf(e+"/");){var i=e.lastIndexOf("/");if(i<0)return t;if((e=e.slice(0,i)).match(/^([^\/]+:\/)?\/*$/))return t;++r}return Array(r+1).join("../")+t.substr(e.length+1)};var u=!("__proto__"in Object.create(null));function c(e){return e}function h(e){if(!e)return!1;var t=e.length;if(t<9)return!1;if(95!==e.charCodeAt(t-1)||95!==e.charCodeAt(t-2)||111!==e.charCodeAt(t-3)||116!==e.charCodeAt(t-4)||111!==e.charCodeAt(t-5)||114!==e.charCodeAt(t-6)||112!==e.charCodeAt(t-7)||95!==e.charCodeAt(t-8)||95!==e.charCodeAt(t-9))return!1;for(var r=t-10;r>=0;r--)if(36!==e.charCodeAt(r))return!1;return!0}function l(e,t){return e===t?0:null===e?1:null===t?-1:e>t?1:-1}t.toSetString=u?c:function(e){return h(e)?"$"+e:e},t.fromSetString=u?c:function(e){return h(e)?e.slice(1):e},t.compareByOriginalPositions=function(e,t,r){var i=l(e.source,t.source);return 0!==i||0!==(i=e.originalLine-t.originalLine)||0!==(i=e.originalColumn-t.originalColumn)||r||0!==(i=e.generatedColumn-t.generatedColumn)||0!==(i=e.generatedLine-t.generatedLine)?i:l(e.name,t.name)},t.compareByGeneratedPositionsDeflated=function(e,t,r){var i=e.generatedLine-t.generatedLine;return 0!==i||0!==(i=e.generatedColumn-t.generatedColumn)||r||0!==(i=l(e.source,t.source))||0!==(i=e.originalLine-t.originalLine)||0!==(i=e.originalColumn-t.originalColumn)?i:l(e.name,t.name)},t.compareByGeneratedPositionsInflated=function(e,t){var r=e.generatedLine-t.generatedLine;return 0!==r||0!==(r=e.generatedColumn-t.generatedColumn)||0!==(r=l(e.source,t.source))||0!==(r=e.originalLine-t.originalLine)||0!==(r=e.originalColumn-t.originalColumn)?r:l(e.name,t.name)},t.parseSourceMapInput=function(e){return JSON.parse(e.replace(/^\)]}'[^\n]*\n/,""))},t.computeSourceURL=function(e,t,r){if(t=t||"",e&&("/"!==e[e.length-1]&&"/"!==t[0]&&(e+="/"),t=e+t),r){var i=n(r);if(!i)throw new Error("sourceMapURL could not be parsed");if(i.path){var u=i.path.lastIndexOf("/");u>=0&&(i.path=i.path.substring(0,u+1))}t=o(s(i),t)}return a(t)}},672:function(e,t,r){r(400).x,t.SourceMapConsumer=r(961).SourceMapConsumer,r(12)},898:function(e,t){var r,i,n;!function(){"use strict";i=[],void 0===(n="function"==typeof(r=function(){function e(e){return!isNaN(parseFloat(e))&&isFinite(e)}function t(e){return e.charAt(0).toUpperCase()+e.substring(1)}function r(e){return function(){return this[e]}}var i=["isConstructor","isEval","isNative","isToplevel"],n=["columnNumber","lineNumber"],s=["fileName","functionName","source"],a=["args"],o=["evalOrigin"],u=i.concat(n,s,a,o);function c(e){if(e)for(var r=0;r<u.length;r++)void 0!==e[u[r]]&&this["set"+t(u[r])](e[u[r]])}c.prototype={getArgs:function(){return this.args},setArgs:function(e){if("[object Array]"!==Object.prototype.toString.call(e))throw new TypeError("Args must be an Array");this.args=e},getEvalOrigin:function(){return this.evalOrigin},setEvalOrigin:function(e){if(e instanceof c)this.evalOrigin=e;else{if(!(e instanceof Object))throw new TypeError("Eval Origin must be an Object or StackFrame");this.evalOrigin=new c(e)}},toString:function(){var e=this.getFileName()||"",t=this.getLineNumber()||"",r=this.getColumnNumber()||"",i=this.getFunctionName()||"";return this.getIsEval()?e?"[eval] ("+e+":"+t+":"+r+")":"[eval]:"+t+":"+r:i?i+" ("+e+":"+t+":"+r+")":e+":"+t+":"+r}},c.fromString=function(e){var t=e.indexOf("("),r=e.lastIndexOf(")"),i=e.substring(0,t),n=e.substring(t+1,r).split(","),s=e.substring(r+1);if(0===s.indexOf("@"))var a=/@(.+?)(?::(\d+))?(?::(\d+))?$/.exec(s,""),o=a[1],u=a[2],h=a[3];return new c({functionName:i,args:n||void 0,fileName:o,lineNumber:u||void 0,columnNumber:h||void 0})};for(var h=0;h<i.length;h++)c.prototype["get"+t(i[h])]=r(i[h]),c.prototype["set"+t(i[h])]=function(e){return function(t){this[e]=Boolean(t)}}(i[h]);for(var l=0;l<n.length;l++)c.prototype["get"+t(n[l])]=r(n[l]),c.prototype["set"+t(n[l])]=function(t){return function(r){if(!e(r))throw new TypeError(t+" must be a Number");this[t]=Number(r)}}(n[l]);for(var p=0;p<s.length;p++)c.prototype["get"+t(s[p])]=r(s[p]),c.prototype["set"+t(s[p])]=function(e){return function(t){this[e]=String(t)}}(s[p]);return c})?r.apply(t,i):r)||(e.exports=n)}(globalThis)}},t={};function r(i){var n=t[i];if(void 0!==n)return n.exports;var s=t[i]={exports:{}};return e[i](s,s.exports,r),s.exports}r.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(t,{a:t}),t},r.d=function(e,t){for(var i in t)r.o(t,i)&&!r.o(e,i)&&Object.defineProperty(e,i,{enumerable:!0,get:t[i]})},r.g=function(){if("object"==typeof globalThis)return globalThis;try{return this||new Function("return this")()}catch(e){if("object"==typeof window)return window}}(),r.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)};var i={};!function(){"use strict";r.d(i,{default:function(){return oi}});class e{constructor(e){this.delegate=e}send(e){var t=JSON.stringify(e);this.delegate.sendMessage(t)}sendRaw(e){this.delegate.sendMessage(e)}set onmessage(e){"function"==typeof e&&(this.delegate.onMessage=t=>{var r;try{r=JSON.parse(t),e(r)}catch(e){console.warn("[FATAL]: failed to parse ws payload",e)}})}}class t{constructor(e){this.delegate=e}suspend(){this.delegate.suspend()}resume(){this.delegate.resume()}}var n=Object.prototype.toString;function s(e){return n.call(e).slice(8,-1)}function a(e){return"Int8Array"===e||"Uint8Array"===e||"Uint8ClampedArray"===e||"Int16Array"===e||"Uint16Array"===e||"Int32Array"===e||"Uint32Array"===e||"Float32Array"===e||"Float64Array"===e}function o(e){return"Object"===s(e)}function u(e){return"ArrayBuffer"===s(e)}function c(e){return a(s(e))}function h(e){return"DataView"===s(e)}function l(e){return"Symbol"===s(e)}function p(e){return"Map"===s(e)}function d(e){return"Set"===s(e)}function f(e){return"RegExp"===s(e)}var g=Number.isNaN||(e=>e!=e),m=(Number.isFinite,e=>(e=>"Number"===s(e))(e)&&Math.abs(e)===1/0);function v(e){return"string"==typeof e||"number"==typeof e||"bigint"==typeof e||"boolean"==typeof e||void 0===e||"symbol"==typeof e}function b(e){for(var t=0,r=3735928559;t<e.length;t++)r=Math.imul(r^e.charCodeAt(t),2654435761);return(r^r>>>16)>>>0}function y(e=""){return e?((Number(e)^16*Math.random())>>Number(e)/4).toString(16):"10000000-1000-4000-8000-100000000000".replace(/[018]/g,y)}class x{constructor(){this.handlers=[]}subscribe(e){this.handlers.push(e)}unsubscribe(e){this.handlers=this.handlers.filter((t=>t!==e))}publish(e){this.handlers.slice(0).forEach((t=>t(e)))}}class S{constructor(e,t,r){this.line=e,this.column=t,this.scriptId=r}}class _{constructor(e,t,r){this.line=void 0,this.column=void 0,this.scriptId=void 0,this.line=e,this.column=t,this.scriptId=r}}function w(e){var t,r="undefined";return void 0===e?r="undefined":null===e?r="null":"number"==typeof e?r=g(e)?"nan":m(e)?"infinity":"number":"boolean"==typeof e?r="boolean":"string"==typeof e?r="string":"function"==typeof e?r="function":(t=e,(Array.isArray&&"function"==typeof Array.isArray?Array.isArray(t):"Array"===s(t))?r="array":!function(e){return"Date"===s(e)}(e)?o(e)?r="object":f(e)?r="regexp":u(e)?r="arraybuffer":c(e)?r=s(e):h(e)?r="dataview":l(e)?r="symbol":p(e)?r="map":d(e)?r="set":!function(e){return"WeakMap"===s(e)}(e)?!function(e){return"WeakSet"===s(e)}(e)?(function(e){return"Math"===s(e)}(e)||function(e){return"JSON"===s(e)}(e)||"object"==typeof e)&&(r="object"):r="weakset":r="weakmap":r="date"),r}function C(e,t,r,i,n=!1){try{return k(e,t,r,i,n)}catch(e){return null}}function k(e,t,r,i,n=!1){var u,c,h,p,d="",f="",g="";"null"==t?(u="object",c="null",h=r):"undefined"===t?(u="undefined",h=r):"string"===t?(u="string",h=r):"number"===t?(u="number",h=r):"boolean"===t?(u="boolean",h=r):"function"===t?(u="function",d="Function",f="function"==typeof r&&r.__wrapped?r.toString():((e,t)=>{var r=e.toString(),i=t.getRawScriptGroup();if(i.length>0){var n=null;for(var s of i)s.rawScript.indexOf(r)>-1&&(n=s);if(!n)return"{}";try{var{line:a,column:o}=function(e,t){for(var r=e.split("\n"),i=t.split("\n"),n=0;n<r.length;){var s=r[n].indexOf(i[0]);if(s>-1){for(var a=1;a<i.length&&0===r[n+a].indexOf(i[a]);)a++;if(1===i.length)return{line:n,column:s};if(a===i.length)return{line:n,column:s}}n++}return{line:-1,column:-1}}(n.rawScript,r);if(-1===a||-1===o)return"{}";var u=n.consumer.originalPositionFor({line:a+1,column:o});if(u.source){var c=t.getScriptByName(u.source);for(var h of c.functions){var l=h.location[0],p=h.location[1];if(u.line===l&&u.column===p)return c.source.substring(h.start,h.end)}}}catch(e){return t.log("err:",e),"{}"}}return"{}"})(r,i),p=i.retainObjectGroup(e,r)):"nan"===t?(u="number",f="NaN",g="NaN"):"infinity"===t?(u="number",f="Infinity",g="Infinity"):"array"===t?(u="object",c="array",d="Array",f=`Array(${r.length})`,p=i.retainObjectGroup(e,r)):"date"===t?(u="object",c="date",h=r.toString()):"object"===t?(u="object",d="Object",f="Object",p=i.retainObjectGroup(e,r)):"regexp"===t?(u="object",c="regexp",d="RegExp",f=r.toString(),p=i.retainObjectGroup(e,r)):"arraybuffer"===t?(u="object",c="arraybuffer",d="ArrayBuffer",f=`ArrayBuffer(${r.byteLength})`,p=i.retainObjectGroup(e,r)):a(t)?(u="object",c="typedarray",d=t,f=`${t}(${r.length})`,p=i.retainObjectGroup(e,r)):"dataview"===t?(u="object",c="dataview",d="DataView",f=`DateView(${r.byteLength})`,p=i.retainObjectGroup(e,r)):"symbol"==t?(u="symbol",f=r.toString(),p=i.retainObjectGroup(e,r)):"map"===t?(u="object",c="map",d="Map",f=`Map(${r.size})`,p=i.retainObjectGroup(e,r)):"set"===t?(u="object",c="set",d="Set",f=`Set(${r.size})`,p=i.retainObjectGroup(e,r)):"weakset"===t?(u="object",c="weakset",d="WeakSet",f="WeakSet",p=i.retainObjectGroup(e,r)):"weakmap"===t&&(u="object",c="weakmap",d="WeakMap",f="WeakMap",p=i.retainObjectGroup(e,r));var m=null;if(n)if("Object"===d){var b=!1,y=I(r);y.length>5&&(b=!0);var x=[];for(var S of y.slice(0,5))if("__proto__"!==S){var _=r[S],C=w(_),E="";if(l(S)&&(S=S.toString()),v(_)){var A=k(e,C,_,i,!1);E=A.value||A.description||""}var T={name:S,type:C,value:E};x.push(T)}m={type:u,subtype:c,description:f,overflow:b,properties:x}}else if("Array"===d){var N=!1,P=r.length;P>100&&(N=!0);for(var O=[],L=0;L<Math.min(P,100);++L){var R=r[L],D=w(R),F="";if(v(R)){var M=k(e,D,R,i,!1);F=M.value||M.description||""}else if(o(R))F="Object";else if("Function"===s(R))F="";else{var V=k(e,D,R,i,!1);c=V.subtype,F=V.description||""}var B={name:String(L),type:D,value:F};c&&(B.subtype=c),O.push(B)}m={type:u,subtype:c,description:f,overflow:N,properties:O}}var j={type:u,subtype:c,value:h,className:d,description:f,objectId:p};return m&&(j.preview=m),g&&(j.unserializableValue=g),j}function E(e,t,r){return k(e,w(t),t,r)}function I(e){var t=Object.getOwnPropertyNames(e),r=Object.getOwnPropertySymbols(e),i=function(e){if(c(e))return["buffer","byteLength","byteOffset","length"];if(u(e))return["byteLength",A.int8Array,A.int16Array,A.int32Array,A.Uint8Array];if(h(e))return["buffer"];if(p(e)||d(e))return["[[Entries]]","size"];if(f(e))return["dotAll","flags","ignoreCase","multiline","source","sticky","unicode"];if(o(e))return["__proto__"];return[]}(e);return t.concat(r).concat(i)}var A={int8Array:"[[Int8Array]]",int16Array:"[[Int16Array]]",int32Array:"[[Int32Array]]",Uint8Array:"[[Uint8Array]]"};function T(e,t){return t.toString=()=>`${e}() { [native code] }`,Object.defineProperty(t,"name",{writable:!1,enumerable:!1,configurable:!1,value:e}),t}var N=r(672),P=r(852),O=r.n(P),L="https://servicewechat.com/",R=e=>`${L}${e}`,D=e=>e.replace(L,""),F=function(e){return e[e.Idle=0]="Idle",e[e.Running=1]="Running",e[e.Paused=2]="Paused",e}({}),M=function(e){return e.PausedOnEntry="PausedOnEntry",e.Ambiguous="Ambiguous",e}({}),V=function(e){return e.DebuggerStatement="debuggerStatement",e.Call="call",e.Return="return",e}({});class B extends S{constructor(e,t,r){super(e,t),this.breakType=void 0,this.breakType=r}}class j{constructor(e="log",t,r){this.type=e,this.messages=t,this.location=r}}class H{constructor(e,t,r,i,n,s,a){this.scriptId=e,this.url=t,this.relativePath=r,this.startLocation=i,this.endLocation=n,this.contextId=s,this.hashedScript=a}}class U{constructor(e,t,r,i){this.scriptId=e,this.line=t,this.column=r,this.reason=i}}class G{}class W{constructor(e,t,r,i){this.error=e,this.line=t,this.column=r,this.scriptId=i,this.id=W.nextId++}}W.nextId=0;class q{constructor(e,t){this.scriptId=e,this.url=t,this.id=void 0,this.name=void 0,this.evalFunction=void 0,this.evalInClosure=void 0,this.currentContext=void 0,this.metadata=void 0,this.callSite=void 0,this.interruptable=!1,this.currentDebuggerState=void 0,this.id=q.currentId++}}q.currentId=0;class ${constructor(e,t){this.type=e,this.value=t}}var z="(function _eval(_$expr, _$nextFuncDecl) {\n  return [eval(_$expr), eval(_$nextFuncDecl)]\n}.bind(this))",J=["error"];class K{constructor(e,t){this.thread=void 0,this.readFileSync=void 0,this.executionState=F.Idle,this.delegate=void 0,this.subContextGlobal=void 0,this.initialInject=!0,this.scriptsByScriptName={},this.scriptsByScriptId={},this.scriptByFunctionId=[],this.scriptByInterruptId=[],this.rawScriptGroup=[],this.retainedObjectPool=new Map,this.retainedObjectGroup=new Map,this.logEvent=new x,this.scriptParsedEvent=new x,this.pausedEvent=new x,this.resumedEvent=new x,this.contextCreatedEvent=new x,this.scriptExceptionEvent=new x,this.scriptReceivedEvent=new x,this.attachedPromise=void 0,this.resolveAttachedPromise=void 0,this.originalSubscribeHandler=void 0,this.bridgeBuffer=[],this.totalBreakpointCount=0,this.hasBreakpoints=!1,this.currentLine=0,this.currentColumn=0,this.currentScriptId=0,this.hasDebuggerStmt=!1,this.callFrames=[],this.metadataSplitted=!1,this.thread=e,this.readFileSync=t;var r=this,i=[];this.subContextGlobal={$dbg:{$:T("$",((e,t,n=-1)=>{var s,a=null===(s=i[n])||void 0===s?void 0:s[t];if(a)return a.bind(null,e);var o=this.metadataSplitted?this.scriptsByScriptId[n]:this.scriptByFunctionId[t],u=this.metadataSplitted?t:t-o.functionsRange[0],c=o.functions[u],h={scriptId:o.scriptId,url:`${L}${o.fileName}`,metadata:c,name:c.name,currentDebuggerState:Z.Normal},l=function(e,...t){var i={...h,id:q.currentId++,currentContext:this,interruptable:c.interruptsRequested>0};r.callFrames.push(i),(r.hasBreakpoints||r.hasDebuggerStmt)&&r.delegate.handlePushCallFrame();try{return e.apply(this,t)}finally{(r.hasBreakpoints||r.hasDebuggerStmt)&&r.delegate.handlePopCallFrame(),r.callFrames.pop(),i.interruptable&&r.releaseObjectGroup(String(i.id))}};return Object.defineProperty(l,"name",{writable:!0,enumerable:!0,configurable:!0,value:c.name}),Object.defineProperty(l,"toString",{writable:!0,enumerable:!0,configurable:!0,value:function(){return c?o.source.substring(c.start,c.end):"{}"}}),l.__wrapped=!0,i[n]||(i[n]=[]),i[n][t]=l,l.bind(null,e)})),__:T("__",(e=>{this.setEvaluateForCallFrame(e)})),_:T("_",((e,t,i,n=0)=>{if(this.currentLine=t,this.currentColumn=i,this.currentScriptId=e,n&&this.setInterruptableForCurrentCallFrame(),(r.hasBreakpoints||r.hasDebuggerStmt)&&this.callFrames[this.callFrames.length-1].interruptable){1===this.callFrames.length&&(this.getCurrentCallFrame().scriptId=e);var s=this.delegate&&this.delegate.handleInterruptSignal(e,t,i);if(n||s){this.executionState=F.Paused;var a=new U(e,t,i,M.Ambiguous);this.pausedEvent.publish(a),this.thread.suspend()}}}))},BaseConsole:class{log(...e){r.logEvent.publish(new j("log",e,new S(r.currentLine,r.currentColumn,r.currentScriptId)))}warn(...e){r.logEvent.publish(new j("warning",e,new S(r.currentLine,r.currentColumn,r.currentScriptId)))}error(...e){r.logEvent.publish(new j("error",e,new S(r.currentLine,r.currentColumn,r.currentScriptId)))}info(...e){r.logEvent.publish(new j("info",e,new S(r.currentLine,r.currentColumn,r.currentScriptId)))}debug(...e){r.logEvent.publish(new j("debug",e,new S(r.currentLine,r.currentColumn,r.currentScriptId)))}group(...e){r.logEvent.publish(new j("group",e,new S(r.currentLine,r.currentColumn,r.currentScriptId)))}groupEnd(...e){r.logEvent.publish(new j("groupEnd",e,new S(r.currentLine,r.currentColumn,r.currentScriptId)))}}},this.attachedPromise=new Promise((e=>{this.resolveAttachedPromise=e,setTimeout((()=>{e()}),3e4)}))}setupConsole(e,t){var r=new t;J.forEach((t=>{var i=e[t];"function"==typeof e[t]&&(e[t]=function(){r[t].apply(r,arguments),i.apply(e,arguments)})}))}notifyEntryCreated(){var e=new q(0,"");e.name="global",e.interruptable=!0,this.callFrames.push(e),this.delegate&&this.delegate.handlePushCallFrame(),this.executionState=F.Running}getSubContextGlobals(){return this.subContextGlobal}startBufferBridgeMessages(){var e=(...e)=>{this.bridgeBuffer.push(e)},t=r.g;this.originalSubscribeHandler=t.WeixinJSBridge.subscribeHandler;try{Object.defineProperty(t.WeixinJSBridge,"subscribeHandler",{get(){return e}})}catch(e){}}dispatchBridgeMessages(){var e=r.g,t=this.originalSubscribeHandler;for(var i of(Object.defineProperty(e.WeixinJSBridge,"subscribeHandler",{get(){return t}}),this.bridgeBuffer))e.WeixinJSBridge.subscribeHandler(...i)}setRuntimeDelegate(e){this.delegate=e}launch(){this.resolveAttachedPromise&&this.resolveAttachedPromise()}runAfterAttached(e=()=>{}){return this.attachedPromise.then((()=>{e()})).catch((e=>{}))}registerScript(e,t="",r=""){var i,n={},s="",a="";try{var o="";if(o=t||`${a=`${null!=e?e:""}__debug__/__jscore-debug__`}.png`,!r){var u="app-service.js.map";r=e?e+u:u}var c=e?e+"app-service.js":"app-service.js",h=this.readFileSync(o),l=this.readFileSync(r);s=this.readFileSync(c);try{i=JSON.parse(h)}catch(e){console.warn("[FATAL] failed to parse metadata")}try{n=JSON.parse(l)}catch(e){console.warn("[FATAL] failed to parse sourcemap")}}catch(e){console.warn("[FATAL] failed to regsiterScript",e)}i&&(i.fileList?(this.metadataSplitted=!0,this.internalRegisterScript(this.initialInject,i,n,s,a)):this.internalRegisterScriptOld(this.initialInject,i,n,s),this.initialInject=!1)}triggerLogEvent(e=[]){this.logEvent.publish(new j("log",e))}internalRegisterScriptOld(e,t,r,i){var n=new N.SourceMapConsumer(r),s=Object.keys(t.scriptFiles),a={rawScript:i,consumer:n};this.rawScriptGroup.push(a),s.forEach((e=>{var r="";try{r=n.sourceContentFor(e)}catch(e){console.warn("[FATAL] sourcemap error",e)}var i=t.scriptFiles[e];i.functions=i.functions.map((e=>{var r=t.functionMetadataKeys,i={};return r.forEach(((t,r)=>{i[t]=e[r]})),i.interruptsRequested=0,i})),i.fileName=e,i.source=r,i.consumer=n,i.rawScript=a,this.scriptsByScriptId[i.scriptId]=i,this.scriptsByScriptName[i.fileName]=i;for(var s=i.interruptsRange[0];s<=i.interruptsRange[1];++s)this.scriptByInterruptId[s]=i;for(var o=i.functionsRange[0];o<=i.functionsRange[1];++o)this.scriptByFunctionId[o]=i;this.scriptParsedEvent.publish(new H(i.scriptId,R(e),e,new S(1,0),new S(1,0),this.getContextId(),String(b(r))))})),e&&this.notifyEntryCreated(),this.hasDebuggerStmt=this.hasDebuggerStmt||t.hasDebuggerStmt}internalRegisterScript(e,t,r,i,n){var s=new N.SourceMapConsumer(r),a=t.fileList,o={rawScript:i,consumer:s};this.rawScriptGroup.push(o);var u=!1;a.forEach((e=>{var r="";try{r=s.sourceContentFor(e)}catch(e){console.warn("[FATAL] sourcemap error",e)}var i=void 0;try{var a=this.readFileSync(`${n}/${e}.png`);i=JSON.parse(a)}catch(t){console.warn("[FATAL] failed to parse metadata for",e)}i&&(i.functions=i.functions.map((e=>{var r=t.functionMetadataKeys,i={};return r.forEach(((t,r)=>{i[t]=e[r]})),i.interruptsRequested=0,i})),i.fileName=e,i.source=r,i.consumer=s,i.rawScript=o,this.scriptsByScriptId[i.scriptId]=i,this.scriptsByScriptName[i.fileName]=i,this.scriptParsedEvent.publish(new H(i.scriptId,R(e),e,new S(1,0),new S(1,0),this.getContextId(),String(b(r)))),u=i.hasDebuggerStmt)})),e&&this.notifyEntryCreated(),this.hasDebuggerStmt=this.hasDebuggerStmt||u}setEvaluateForCallFrame(e){var t=this.callFrames[this.callFrames.length-1];t?t.evalFunction=e:console.warn("[FATAL] invalid current call frame")}evaluateOnCallFrame(e,t=this.getCurrentCallFrame(),r=!1,i=!0){if(!t)return new $("undefined",void 0);var n=t.evalFunction;if(n){var s;r&&!t.evalInClosure&&(t.evalInClosure=n.call(t.currentContext,z));try{if(this.delegate&&this.delegate.willPerformEvaluate(e),r){var a=t.evalInClosure,[o,u]=a(e,z);t.evalInClosure=u,s=o}else s=n.call(t.currentContext,e)}catch(e){if(!i){var{line:c,column:h}=e;e.message=e.message,e.stack="",this.scriptExceptionEvent.publish(new W(e,c,h))}return new $("undefined",void 0)}finally{this.delegate&&this.delegate.didPerformEvaluate()}var l=w(s);return new $(l,s)}return new $("undefined",void 0)}rawEvaluateOnCallFrame(e,t=this.getCurrentCallFrame()){if(!t)return new $("undefined",void 0);var r=t.evalFunction;if(r){var i;try{this.delegate&&this.delegate.willPerformEvaluate(e),i=r.call(t.currentContext,e)}catch(e){return new $("undefined",void 0)}finally{this.delegate&&this.delegate.didPerformEvaluate()}return i}return null}retainObjectGroup(e,t){var r=y();return this.retainedObjectPool.set(r,{group:e,reference:t}),this.retainedObjectGroup.has(e)||this.retainedObjectGroup.set(e,[]),this.retainedObjectGroup.get(e).push(r),r}releaseObjectGroup(e){var t=this.retainedObjectGroup.get(e);if(t){for(var r of t)this.retainedObjectPool.delete(r);this.retainedObjectGroup.delete(e)}}getRetainedObject(e){var t;return null===(t=this.retainedObjectPool.get(e))||void 0===t?void 0:t.reference}getRetainedObjectGroup(e){var t;return null===(t=this.retainedObjectPool.get(e))||void 0===t?void 0:t.group}resumeExecution(){this.thread.resume(),this.resumedEvent.publish(new G)}searchFunctionInLocation(e,t){var r=this.getScriptByScriptId(e).functions;for(var i of r){var n=i.location[0],s=i.location[1],a=i.location[2],o=i.location[3];if(n===a){if(t.line===n&&t.column>=s&&t.column<=o)return i}else{if(t.line===n&&t.column>=s)return i;if(t.line===a&&t.column<=a)return i;if(t.line>n&&t.line<a)return i}}return null}increaseInterruptForFunction(e){if(e)for(var t of(++e.interruptsRequested,++this.totalBreakpointCount,this.totalBreakpointCount>0&&(this.hasBreakpoints=!0),this.callFrames))t.metadata===e&&(t.interruptable=!0)}decreaseInterruptForFunction(e){e&&(--e.interruptsRequested,--this.totalBreakpointCount,this.totalBreakpointCount<=0&&(this.hasBreakpoints=!1))}getCallFrames(){return this.callFrames}getGlobalCallFrame(){return this.callFrames[0]}getCallFrameById(e){return this.callFrames.find((t=>t.id===e))}getCurrentCallFrame(){var e=this.callFrames[this.callFrames.length-1];return e||console.warn("[FATAL] invalid call frame"),e}setInterruptableForCurrentCallFrame(){var e=this.getCurrentCallFrame();e&&(e.interruptable=!0)}setInterruptableForPreviousCallFrame(){var e=this.callFrames[this.callFrames.length-2];e&&(e.interruptable=!0)}dispatchError(e){if(this.log("[ERROR]",e),"object"==typeof e&&void 0!==e.message&&void 0!==e.stack){var t,r=(e=>{var t=O().parse(e);if(t.length<=0)return null;var r=t[0];return{fileName:r.fileName,lineNumber:r.lineNumber,columnNumber:r.columnNumber}})(e);if(r){e.line=r.lineNumber||1,e.column=r.columnNumber||1;var i=this.getScriptByName(r.fileName||"");i&&(t=i.scriptId)}this.scriptExceptionEvent.publish(new W(e,e.line,e.column,t))}else{var n=new Error;n.message=e,this.scriptExceptionEvent.publish(new W(n,-1,-1))}}getThisObjectOnCurrentCallFrame(){var e=this.callFrames[this.callFrames.length-1];if(e&&e.evalFunction){var t=(0,e.evalFunction)("this");if("object"==typeof t)return t}return{}}getPossibleInterrupts(e,t,r){var i,n,s=null!==(i=null===(n=this.scriptsByScriptId[+e])||void 0===n?void 0:n.interrupts)&&void 0!==i?i:[],a=[];for(var o of s)o[0]===t.line&&a.push(new B(o[0],o[1],V.DebuggerStatement));return a}getExecutionState(){return this.executionState}getLogEvent(){return this.logEvent}getScriptParsedEvent(){return this.scriptParsedEvent}getPausedEvent(){return this.pausedEvent}getResumedEvent(){return this.resumedEvent}getContextCreatedEvent(){return this.contextCreatedEvent}getScriptExceptionEvent(){return this.scriptExceptionEvent}getScriptReceivedEvent(){return this.scriptReceivedEvent}getConsumer(e){var t;return null===(t=this.scriptsByScriptName[e])||void 0===t?void 0:t.consumer}getFunctionMetadata(e){return this.scriptsByScriptName[e].functions}getScriptByScriptId(e){return this.scriptsByScriptId[e]}getScriptByName(e){return this.scriptsByScriptName[e]}getScriptNames(){return Object.keys(this.scriptsByScriptName)}getScriptsWithScriptName(){return this.scriptsByScriptName}findFileByInterruptId(e){return Object.values(this.scriptsByScriptId).find((t=>e>=t.interruptsRange[0]&&e<=t.interruptsRange[1]))}findScriptByFunctionId(e){return Object.values(this.scriptsByScriptId).find((t=>e>=t.functionsRange[0]&&e<=t.functionsRange[1]))}findScriptById(e){return this.scriptsByScriptId[e]}getRawScriptGroup(){return this.rawScriptGroup}getContextId(){return 1}isInitialInject(){return this.initialInject}log(...e){this.logEvent.publish(new j("log",e))}}K.globalScriptIndex=0;class Q{constructor(e,t,r,i){this.scriptId=e,this.line=t,this.column=r,this.condition=i}}var X,Y,Z=function(e){return e[e.Normal=0]="Normal",e[e.StepOver=1]="StepOver",e[e.StepInto=2]="StepInto",e[e.StepOut=3]="StepOut",e[e.SkipAllPauses=4]="SkipAllPauses",e[e.ContinueToLocation=5]="ContinueToLocation",e}({});class ee{constructor(e){this.runtime=void 0,this.breakpoints=[],this.nextBreakpointId=0,this.pausedOnEntry=!1,this.debuggerState=Z.Normal,this.savedDebuggerState=Z.Normal,this.targetContinueLocation=null,this.breakpointActive=!0,this.runtime=e,this.runtime.setRuntimeDelegate(this)}setPausedOnEntry(e=!0){this.pausedOnEntry=e}didResetRuntimeState(){this.breakpoints=[],this.debuggerState=Z.Normal,this.savedDebuggerState=Z.Normal}handleInterruptSignal(e,t,r){if(this.pausedOnEntry)return this.pausedOnEntry=!1,!0;if(!this.breakpointActive)return!1;if(this.debuggerState===Z.SkipAllPauses)return!1;if(this.debuggerState===Z.StepOver)return this.debuggerState=Z.Normal,!0;if(this.debuggerState===Z.StepInto){var i=this.runtime.callFrames[this.runtime.callFrames.length-1];return i&&(i.currentDebuggerState=Z.Normal),this.debuggerState=Z.Normal,!0}for(var n of this.breakpoints)if(n&&n.scriptId===e&&t===n.line&&r===n.column){if(n.condition)if(!this.runtime.rawEvaluateOnCallFrame(n.condition))return!1;return!0}if(this.debuggerState===Z.ContinueToLocation){if(this.targetContinueLocation){if(this.targetContinueLocation.line===t)return this.targetContinueLocation=null,this.debuggerState=Z.Normal,!0}else console.warn("[FATAL] ContinueToLocation command without targetContinueLocation");return!1}return!1}handlePushCallFrame(){var e=this.runtime.callFrames[this.runtime.callFrames.length-2];e&&(e.currentDebuggerState=this.debuggerState),this.debuggerState===Z.StepOver&&(e&&(e.currentDebuggerState=Z.StepOver),this.debuggerState=Z.Normal),e&&e.currentDebuggerState===Z.StepInto&&(this.debuggerState=Z.StepOver,e&&(e.currentDebuggerState=Z.Normal),this.runtime.setInterruptableForCurrentCallFrame())}handlePopCallFrame(){var e=this.runtime.callFrames[this.runtime.callFrames.length-1];if(this.debuggerState!==Z.SkipAllPauses){e&&e.currentDebuggerState===Z.StepOut&&(this.debuggerState=Z.StepOver,e.currentDebuggerState=Z.Normal,this.runtime.setInterruptableForPreviousCallFrame()),this.debuggerState===Z.StepOver&&(e.currentDebuggerState=Z.Normal,this.runtime.setInterruptableForPreviousCallFrame());var t=this.runtime.callFrames[this.runtime.callFrames.length-2];t&&t.currentDebuggerState===Z.StepOver&&(this.debuggerState=Z.StepOver)}}willPerformEvaluate(){this.savedDebuggerState=this.debuggerState,this.debuggerState=Z.SkipAllPauses}didPerformEvaluate(){this.debuggerState=this.savedDebuggerState,this.savedDebuggerState=Z.Normal}setBreakPointByUrlWithCondition(e,t,r){var i=this.runtime.getPossibleInterrupts(e,t,new S(0,0)),n=t.column,s=i.reduce((function(e,t){return Math.abs(t.column-n)<Math.abs(e.column-n)?t:e})),a=this.breakpoints.findIndex((e=>e&&e.line===t.line&&e.column===t.column));if(a>-1)return{breakpointId:a,breakpoint:this.breakpoints[a]};var o=new Q(e,s.line,s.column,r),u=this.nextBreakpointId++;this.breakpoints[u]=o;var c=this.runtime.searchFunctionInLocation(e,t);return c?this.runtime.increaseInterruptForFunction(c):console.warn("[FATAL] functionIndex is not found"),{breakpointId:u,breakpoint:o}}removeBreakpoint(e){if(void 0!==e){var t=this.breakpoints[e];if(t&&t.scriptId){var r=this.runtime.searchFunctionInLocation(t.scriptId,new S(t.line,t.column));r&&this.runtime.decreaseInterruptForFunction(r)}this.breakpoints[e]=void 0}}resume(){this.debuggerState!==Z.SkipAllPauses&&(this.debuggerState=Z.Normal),this.runtime.resumeExecution()}setSkipAllPauses(){this.debuggerState=Z.SkipAllPauses,setTimeout((()=>{this.debuggerState=Z.Normal}),0)}stepOver(){this.runtime.getExecutionState()===F.Paused&&(this.debuggerState=Z.StepOver,this.runtime.resumeExecution())}stepInto(){this.runtime.getExecutionState()===F.Paused&&(this.runtime.callFrames[this.runtime.callFrames.length-1].currentDebuggerState=Z.StepInto,this.debuggerState=Z.StepInto,this.runtime.resumeExecution())}stepOut(){if(this.runtime.getExecutionState()===F.Paused){if(this.runtime.getCallFrames().length>1)this.runtime.callFrames[this.runtime.callFrames.length-1].currentDebuggerState=Z.StepOut,this.debuggerState=Z.StepOut;else this.debuggerState=Z.SkipAllPauses;this.runtime.resumeExecution()}}continueToLocation(e,t,r){if(!(t<0||r&&r<0)&&this.runtime.getExecutionState()===F.Paused){this.debuggerState=Z.ContinueToLocation,this.targetContinueLocation=new _(t,r);var i=new S("number"==typeof t?t:-1,"number"==typeof r?r:-1),n=this.runtime.searchFunctionInLocation(e,i);n&&this.runtime.increaseInterruptForFunction(n),this.runtime.resumeExecution()}}setBreakpointActive(e){this.breakpointActive=e}}class te{constructor(e){this.ws=e}respond(e,t={}){var r={id:e,result:t};this.ws.send(r)}respondWithTag(e,t,r={}){var i={id:t,result:r};this.ws.sendRaw(e+"_"+JSON.stringify(i))}fireEvent(e,t={}){var r={method:e,params:t};this.ws.send(r)}fireEventWithTag(e,t,r={}){var i={method:t,params:r};this.ws.sendRaw(e+"_"+JSON.stringify(i))}}class re{constructor(e,t,r,i,n,s){this.pageInspector=t,this.runtimeInspector=r,this.debugerInspector=i,this.profilerInspector=n,this.fallbackInspector=s,this.ws=void 0,this.ws=e}dispatch(){this.ws.onmessage=e=>{var t=e.method;t.startsWith("Page")?this.pageInspector.handle(e):t.startsWith("Debugger")?this.debugerInspector.handle(e):t.startsWith("Runtime")?this.runtimeInspector.handle(e):t.startsWith("Profiler")?this.profilerInspector.handle(e):this.fallbackInspector.handle(e)}}}class ie extends te{constructor(e,t){super(e),this.runtime=void 0,this.runtimeHandlers=void 0,this.runtime=t,this.runtimeHandlers={"Runtime.enable":this.handleEnableCommand,"Runtime.getIsolateId":this.handleGetIsolateId,"Runtime.runIfWaitingForDebugger":this.handleRunIfWaitingForDebugger,"Runtime.getProperties":this.handleGetProperties,"Runtime.releaseObjectGroup":this.handleReleaseObjectGroup,"Runtime.compileScript":this.handleCompileScript,"Runtime.evaluate":this.handleEvaluate},this.runtime.getLogEvent().subscribe((e=>{this.onConsoleOutput(e.type,e.messages,e.location)})),this.runtime.getScriptExceptionEvent().subscribe((e=>{this.onExceptionThrown(e.id,e.error.message,e.line,e.column,e.error.stack||"",e.scriptId)}))}onConsoleOutput(e,t,r){var i=t.map((e=>k("console",w(e),e,this.runtime,!0))),n=this.runtime.getContextId(),s=this.runtime.getCurrentCallFrame(),a=[];if(s){var o={functionName:s.name||"",scriptId:r?String(r.scriptId):"",url:"https://servicewechat.com",lineNumber:r?r.line-1:0,columnNumber:r?r.column:0};a.push(o)}var u={type:e,args:i,executionContextId:n,timestamp:Date.now(),stackTrace:{callFrames:a}};this.fireEvent("Runtime.consoleAPICalled",u)}onExceptionThrown(e,t,r,i,n,s){var a={exceptionId:e,text:t+"\n"+n,lineNumber:1,columnNumber:1};void 0!==s&&Object.assign(a,{lineNumber:r-1,columnNumber:i,scriptId:s.toString()});var o={timestamp:Date.now(),exceptionDetails:a};this.fireEvent("Runtime.exceptionThrown",o)}handle(e){var t=this.runtimeHandlers[e.method];t?t.call(this,e.id,e.params):this.respond(e.id)}handleEnableCommand(e){this.fireExecutionContextCreatedEvent(),this.respond(e)}handleGetIsolateId(e){this.respond(e,{id:"0"})}handleRunIfWaitingForDebugger(e){this.respond(e),this.runtime.launch()}handleGetProperties(e,t){var r,i,n,s,a=[],o={result:a},{objectId:c}=t;if(c){var h=this.runtime.getRetainedObject(c),f=this.runtime.getRetainedObjectGroup(c),g=u(h),m=p(h),v=d(h);try{var b=I(h);for(var y of b){var x=void 0;if(g&&y.startsWith("[[")&&y.endsWith("]]"))try{n=h,x=(s=y)===A.int8Array?new Int8Array(n):s===A.int16Array?new Int16Array(n):s===A.int32Array?new Int32Array(n):s===A.Uint8Array?new Uint8Array(n):void 0}catch(e){continue}else m&&"[[Entries]]"===y?(i=h,x=Array.from(i.entries())):(m||v)&&"[[Entries]]"===y?(r=h,x=Array.from(r.values())):l(y)?(x=h[y],y=y.toString()):x=h[y];var S=C(f,w(x),x,this.runtime);if(S){var _={name:y,value:S,configurable:!1,enumerable:!1};a.push(_)}}}catch(e){}this.respond(e,o)}}handleReleaseObjectGroup(e,t){var r=t.objectGroup;this.runtime.releaseObjectGroup(r),this.respond(e,{})}handleCompileScript(e){this.respond(e,{})}handleEvaluate(e,t){var r=this.runtime.getGlobalCallFrame(),i="console"===t.objectGroup,n=this.runtime.evaluateOnCallFrame(t.expression,r,i),s={result:k(t.objectGroup||"default",n.type,n.value,this.runtime,t.generatePreview)};this.respond(e,s)}fireExecutionContextCreatedEvent(){var e={context:{id:this.runtime.getContextId(),origin:"",name:"sub_context"}};this.fireEvent("Runtime.executionContextCreated",e)}}class ne extends te{constructor(e,t){super(e),this.runtime=void 0,this.pageCommandHandlers=void 0,this.runtime=t,this.pageCommandHandlers={"Page.enable":this.handleEnableCommand,"Page.getResourceTree":this.handleGetResourceTreeCommand}}handle(e){var t=this.pageCommandHandlers[e.method];t?t.call(this,e.id,e.params):this.respond(e.id)}handleEnableCommand(e,t){this.respond(e,{})}handleGetResourceTreeCommand(e,t){var r={frameTree:{frame:{id:"0",loaderId:"0",name:"test",url:"https://debugger.io/app.js",securityOrigin:"://",mimeType:"text/javascript"},resources:[{url:"https://debugger.io/app.js",type:"Script",mimeType:"text/javascript"}]}};this.respond(e,r)}}class se extends te{constructor(e){super(e),this.profilerCommandHandlers=void 0,this.profilerCommandHandlers={"Profiler.enable":this.handleEnableCommand}}handle(e){var t=this.profilerCommandHandlers[e.method];t?t.call(this,e.id,e.params):this.respond(e.id)}handleEnableCommand(e){this.respond(e)}}class ae extends te{constructor(e,t,r){super(e),this.runtime=void 0,this.debugger=void 0,this.debuggerHandlers=void 0,this.sourcePathMap={},this.runtime=t,this.debugger=r,this.debuggerHandlers={"Debugger.enable":this.handleEnableCommand,"Debugger.setPauseOnExceptions":this.handleSetPauseOnExceptions,"Debugger.setAsyncCallStackDepth":this.handleSetAsyncCallStackDepth,"Debugger.setBlackboxPatterns":this.handleSetBlackboxPatterns,"Debugger.getScriptSource":this.handleGetScriptSourceCommand,"Debugger.stepOver":this.handleStepOverCommand,"Debugger.stepInto":this.handleStepIntoCommand,"Debugger.stepOut":this.handleStepOutCommand,"Debugger.resume":this.handleResumeCommand,"Debugger.setSkipAllPauses":this.handleSetSkipAllPauses,"Debugger.continueToLocation":this.handleContinueToLocation,"Debugger.getPossibleBreakpoints":this.handleGetPossibleBreakpoints,"Debugger.setBreakpointByUrl":this.handleSetBreakpointByUrl,"Debugger.removeBreakpoint":this.handleRemoveBreakpoint,"Debugger.evaluateOnCallFrame":this.handleEvaluateOnCallFrame,"Debugger.setBreakpointsActive":this.handleSetBreakpointActive},this.runtime.getScriptParsedEvent().subscribe((e=>{this.fireSourceParsedEvent(e.scriptId,e.url,e.relativePath,e.startLocation,e.endLocation,e.contextId,e.hashedScript)})),this.runtime.getPausedEvent().subscribe((e=>{this.firePausedEvent(e.scriptId,e.line,e.column,e.reason)})),this.runtime.getResumedEvent().subscribe((()=>{this.fireResumedEvent()}))}handle(e){var t=e.id,r=e.method,i=e.params,n=this.debuggerHandlers[r];n?n.call(this,t,i):this.respond(t)}handleEnableCommand(e,t){this.respond(e,{debuggerId:"0"})}handleSetPauseOnExceptions(e,t){this.respond(e)}handleSetAsyncCallStackDepth(e,t){this.respond(e)}handleSetBlackboxPatterns(e,t){this.respond(e)}handleGetScriptSourceCommand(e,t){this.respond(e,{scriptSource:this.runtime.getScriptByScriptId(+t.scriptId).source})}handleResumeCommand(e){this.debugger.resume(),this.respond(e)}handleSetSkipAllPauses(e){this.debugger.setSkipAllPauses(),this.respond(e)}handleStepOverCommand(e){this.debugger.stepOver(),this.respond(e)}handleStepIntoCommand(e){this.debugger.stepInto(),this.respond(e)}handleStepOutCommand(e){this.debugger.stepOut(),this.respond(e)}handleContinueToLocation(e,t){var r=t.location;r.lineNumber&&this.debugger.continueToLocation(+r.scriptId,r.lineNumber+1,r.columnNumber),this.respond(e)}handleGetPossibleBreakpoints(e,t){var r=t.start.lineNumber||0,i=t.start.columnNumber||0,n=t.end?t.end.lineNumber:0,s=t.end&&t.end.columnNumber?t.end.columnNumber:0,a=t.start.scriptId,o=new S(r+1,i),u=new S(n+1,s),c=this.runtime.getPossibleInterrupts(+a,o,u),h=[];for(var l of c){var p={scriptId:a,lineNumber:l.line-1,columnNumber:l.column,type:l.breakType};h.push(p)}var d={locations:h};this.respond(e,d)}handleSetBreakpointByUrl(e,t){var r=t.lineNumber,i=t.columnNumber||0,n=t.condition,s=t.url||"",a=t.urlRegex||"",o=null;if(s)o=this.runtime.getScriptByName(D(s));else if(a){var u=new RegExp(a);for(var c of this.runtime.getScriptNames())if(u.test(R(c))){o=this.runtime.getScriptsWithScriptName()[c];break}}if(o){var h=new S(r+1,i),{breakpointId:l,breakpoint:p}=this.debugger.setBreakPointByUrlWithCondition(o.scriptId,h,n),d={scriptId:p.scriptId.toString(),lineNumber:p.line-1,columnNumber:p.column},f={breakpointId:l.toString(),locations:[d]};this.respond(e,f)}}handleRemoveBreakpoint(e,t){var r=t.breakpointId;this.debugger.removeBreakpoint(parseInt(r,10)),this.respond(e)}handleEvaluateOnCallFrame(e,t){var r,i=t.callFrameId,n=this.runtime.getCallFrameById(parseInt(i,10)),s="console"===t.objectGroup,a=this.runtime.evaluateOnCallFrame(t.expression,n,s,null===(r=t.silent)||void 0===r||r),o={result:k(t.objectGroup||"default",a.type,a.value,this.runtime,t.generatePreview)};this.respond(e,o)}handleSetBreakpointActive(e,t){var r=t.active;this.debugger.setBreakpointActive(r),this.respond(e)}fireSourceParsedEvent(e,t,r,i,n,s,a){var o={url:t,scriptId:e.toString(),startLine:i.line-1,startColumn:i.column,endLine:n.line,endColumn:i.column,executionContextId:s,hash:a,isLiveEdit:!1,hasSourceURL:!1,isModule:!1,executionContextAuxData:{isDefault:!0},relativePath:D(t),sourceMapURL:""};this.sourcePathMap[e.toString()]=D(t),this.fireEventWithTag("asm","Debugger.scriptParsed",o)}firePausedEvent(e,t,r,i){for(var n=[],s=this.runtime.getCallFrames().length-1;s>=0;s--){var a=this.runtime.getCallFrames()[s],o=a.callSite,u=void 0!==o?o.line-1:t-1,c=void 0!==o?o.column:r,h={scriptId:a.scriptId.toString(),lineNumber:u,columnNumber:c},l={type:"object",className:"Object",value:a,description:"global"},p=[];if(a.metadata){for(var d={},f=0,g=a.metadata.scopeBindings.length;f<g;++f){var m=a.metadata.scopeBindings[f],v=this.runtime.rawEvaluateOnCallFrame(m,a);d[m]=v}var b={type:"local",object:E(String(a.id),d,this.runtime),name:a.name};p.push(b)}var y=null;a.metadata&&(y={lineNumber:a.metadata.location[0]-1,columnNumber:a.metadata.location[1],scriptId:a.scriptId.toString()});var x={callFrameId:String(a.id),functionName:a.name,location:h,url:a.url,scopeChain:p,this:l};y&&(x.functionLocation=y),n.push(x)}var S={callFrames:n,reason:"ambiguous"};this.fireEvent("Debugger.paused",S)}fireResumedEvent(){this.fireEvent("Debugger.resumed")}}class oe extends te{constructor(e){super(e)}handle(e){var t=e.id;this.respond(t)}}function ue(e){if(!e)return"text/plain";for(var t=["Content-Type","content-type","Content-type","content-Type"],r=0;r<t.length;r++){var i=t[r];if("string"==typeof e[i])return e[i].split(";")[0]}return"text/plain"}var ce,he,le,pe,de,fe,ge,me,ve,be,ye,xe={request:1,download:2,upload:3,socket:4},Se=0,_e=0,we=0,Ce=0,ke={request:{},download:{},upload:{},socket:{}},Ee={request:{},download:{},upload:{},socket:{}},Ie={request:{},download:{},upload:{},socket:{}};function Ae(e){return JSON.parse(JSON.stringify(e))}function Te(e){return __wxConfig.wmpfDirectInvokeJs?e:JSON.parse(e)||{}}function Ne(e,t){var r=(t||"").toLowerCase(),i=Ie[r]||{},n=ke[r];return i[e]&&n?function(e,t){var r=(t||"").toLowerCase(),i=ke[r];if(!i)return null;for(var n=Object.keys(i),s=0;s<n.length;s++){var a=n[s];if(i[a].id===e)return i[a]}return null}(i[e],r):null}class Pe{constructor(e){this.messager=void 0,this.messager=e,this._init()}_init(){var e=this.messager.getInstance();e.onReceiveNetworkHeader=this.onReceiveNetworkHeader.bind(this),e.registerCallback(this.onReceiveDevtoolsMessage.bind(this))}onReceiveNetworkHeader(e){try{var t=JSON.parse(e);if(!t.task_id||!t.api_name||!t.request_headers)return;t.api_name=t.api_name.toLowerCase();var r=t.api_name,i=t.task_id,n=`${xe[r]}.${i}`,s=Ee[r],a=JSON.parse(t.request_headers);s[n]={...s[n]||{},requestHeaders:a,requestTimestamp:t.timestamp||Date.now()};var{info:o}=Ne(i,t.api_name)||{info:{}},u={method:"Network.requestWillBeSent",params:{requestId:n,documentURL:a.Referer||a.referer,request:{url:o.url,method:o.method,postData:o.data,headers:a},timestamp:(s[n].requestTimestamp||Date.now())/1e3,type:"XHR"}};this.messager.sendToDevtools("__networkDebug",u)}catch(e){console.error(e)}}onReceiveDevtoolsMessage(e,t){if("__getNetworkResponseBody"===e)try{var r=JSON.parse(t),{id:i,api:n,devtoolsMsgId:s}=r,a=Ne(i,n)||{};a.data&&this.messager.sendToDevtools("__networkDebug",{id:s,result:{body:a.data,base64Encoded:!1}})}catch(e){console.error(e)}if("__resetNetworkCache"===e)for(var o=Object.keys(ke),u=0;u<o.length;u++)for(var c=o[u],h=ke[c],l=Object.keys(h),p=0;p<l.length;p++){var d=h[l[p]];"success"!==d.state&&"fail"!==d.state||(d.data=void 0,d.info=void 0,d.responseHeaders=void 0)}}invokeNetworkMethods(e,t,r){this._invokeRequestTask(e,t,r),this._invokeDownloadTask(e,t,r),this._invokeUploadTask(e,t,r),this._invokeSocketTask(e,t,r)}_invokeRequestTask(e,t,r){if("createRequestTask"===t||"createRequestTaskAsync"===t){var i=Te(r),n=++Se;return ke.request[e]={id:String(n),api:"request",info:{url:i.url,method:i.method||"GET",data:i.data||i.formData||void 0},state:"requestSent",data:null},JSON.stringify({errMsg:`${t}:ok`,requestTaskId:String(n)})}}_invokeDownloadTask(e,t,r){if("createDownloadTask"===t||"createDownloadTaskAsync"===t){var i=++_e,n=Te(r);return ke.download[e]={id:String(i),api:"download",info:{url:n.url,method:n.method||"GET",data:n.data||n.formData||void 0},state:"requestSent",data:null},JSON.stringify({errMsg:`${t}:ok`,downloadTaskId:String(i)})}}_invokeUploadTask(e,t,r){if("createUploadTask"===t||"createUploadTaskAsync"===t){var i=++we,n=Te(r);return ke.upload[e]={id:String(i),api:"upload",info:{url:n.url,method:n.method||"POST",data:n.data||n.formData||void 0},state:"requestSent",data:null},JSON.stringify({errMsg:`${t}:ok`,uploadTaskId:String(i)})}}_invokeSocketTask(e,t,r){if("createSocketTask"===t||"createSocketTaskAsync"===t){var i=++Ce,n=Te(r);return ke.socket[e]={id:String(i),api:"socket",info:{url:n.url,data:n.data||n.formData||void 0},state:"requestSent",data:""},JSON.stringify({errMsg:`${t}:ok`,socketTaskId:String(i)})}}invokeCallbackNetworkMethods(e,t){ke.request[e]&&t.requestTaskId&&(Ie.request[t.requestTaskId]=ke.request[e].id),ke.download[e]&&t.downloadTaskId&&(Ie.download[t.downloadTaskId]=ke.download[e].id),ke.upload[e]&&t.uploadTaskId&&(Ie.upload[t.uploadTaskId]=ke.upload[e].id),ke.socket[e]&&t.socketTaskId&&(Ie.socket[t.socketTaskId]=ke.socket[e].id)}onRequestTaskStateChange(e){var t=e[1]||{},r=(e[3]||{}).nativeTime||Date.now(),i=Ne(t.requestTaskId,"request");if(i)if("headersReceived"===t.state){i.responseHeaders=Ae(t.header),i.state="headersReceived";var n={id:t.requestTaskId,api:"request",responseHeaders:t.header,state:"headersReceived"};this.sendNetworkDebug(n,r)}else if("success"===t.state){i.state="success",i.data=t.data,i.statusCode=t.statusCode,i.statusText=t.statusText;var s={id:t.requestTaskId,state:"success",api:"request",statusCode:t.statusCode,statusText:t.statusText,dataLength:(t.data||"").length};this.sendNetworkDebug(s,r)}else if("fail"===t.state){i.state="fail",i.statusCode=i.statusCode||t.statusCode;var a={id:t.requestTaskId,api:"request",state:"fail"};this.sendNetworkDebug(a,r)}}onDownloadTaskStateChange(e){var t=e[1]||{},r=(e[3]||{}).nativeTime||Date.now(),i=Ne(t.downloadTaskId,"download");if(i)if("headersReceived"===t.state){i.responseHeaders=Ae(t.header),i.state="headersReceived";var n={id:t.downloadTaskId,api:"download",responseHeaders:t.header,state:"headersReceived"};this.sendNetworkDebug(n,r)}else if("progressUpdate"===t.state){i.state="dataReceived",i.dataLength=t.totalBytesWritten;var s={id:t.downloadTaskId,state:"dataReceived",dataLength:t.totalBytesWritten,api:"download"};this.sendNetworkDebug(s,r)}else if("success"===t.state){i.state="success","number"==typeof i.dataLength?i.data=`Saved ${i.dataLength} Bytes at "${t.tempFilePath}"`:i.data=`Saved at ${t.tempFilePath}`,i.statusCode=t.statusCode,i.statusText=t.statusText;var a={id:t.downloadTaskId,state:"success",api:"download",statusCode:t.statusCode,statusText:t.statusText};this.sendNetworkDebug(a,r)}else if("fail"===t.state){i.state="fail",i.statusCode=i.statusCode||t.statusCode;var o={id:t.downloadTaskId,api:"download",state:"fail"};this.sendNetworkDebug(o,r)}}onUploadTaskStateChange(e){var t=e[1]||{},r=(e[3]||{}).nativeTime||Date.now(),i=Ne(t.uploadTaskId,"upload");if(i)if("headersReceived"===t.state){i.responseHeaders=Ae(t.header),i.state="headersReceived";var n={id:t.uploadTaskId,api:"upload",responseHeaders:t.header,state:"headersReceived"};this.sendNetworkDebug(n,r)}else if("progressUpdate"===t.state){i.state="dataSent",i.dataLength=t.totalBytesSent;var s={id:t.uploadTaskId,state:"dataSent",dataLength:t.totalBytesSent,api:"upload"};this.sendNetworkDebug(s,r)}else if("success"===t.state){i.state="success",i.data=t.data,i.statusCode=t.statusCode,i.statusText=t.statusText;var a={id:t.uploadTaskId,state:"success",api:"upload",statusCode:t.statusCode,statusText:t.statusText,dataLength:(t.data||"").length};this.sendNetworkDebug(a,r)}else if("fail"===t.state){i.state="fail",i.statusCode=i.statusCode||t.statusCode;var o={id:t.uploadTaskId,api:"upload",state:"fail"};this.sendNetworkDebug(o,r)}}onSocketTaskStateChange(e){var t=e[1]||{},r=(e[3]||{}).nativeTime||Date.now(),i=Ne(t.socketTaskId,"socket");if(i)if("open"===t.state){i.responseHeaders=Ae(t.header),i.state="headersReceived";var n={id:t.socketTaskId,api:"socket",responseHeaders:t.header,state:"headersReceived",websocketState:"open"};this.sendNetworkDebug(n,r)}else if("close"===t.state){i.state="success",i.statusCode=t.statusCode,i.statusText=t.statusText;var s={id:t.socketTaskId,state:"success",api:"socket",statusCode:t.statusCode,statusText:t.statusText,websocketState:"close"};this.sendNetworkDebug(s,r)}else if("error"===t.state){i.state="fail",i.statusCode=i.statusCode||t.statusCode;var a={id:t.socketTaskId,api:"socket",websocketState:"error",state:"fail"};this.sendNetworkDebug(a,r)}}sendNetworkDebug(e,t){var{state:r,api:i}=e,n=`${xe[i]}.${e.id}`,s=Ee[i];s[n]&&("headersReceived"===r?this._netWorkDebugHeadersReceived(n,s,e,t):"dataReceived"===r?this._netWorkDebugDataReceived(n,s,e,t):"dataSent"===r?this._netWorkDebugDataSent(n,s,e,t):"success"===r?this._netWorkDebugSuccess(n,s,e,t):"fail"===r&&this._netWorkDebugFail(n,s,e,t))}_netWorkDebugHeadersReceived(e,t,r,i){if(t[e]={...t[e]||{},sate:r.state,responseHeaders:r.responseHeaders,responseReceivedTimestamp:i||Date.now()},"open"===r.websocketState){var n={method:"Network.responseReceived",params:{requestId:e,timestamp:(t[e].responseReceivedTimestamp||Date.now())/1e3,type:"XHR",response:{url:t[e].url,mimeType:ue(t[e].responseHeaders),status:t[e].statusCode||101,statusText:t[e].statusText||"Switching Protocols",headers:t[e].responseHeaders,connectionId:e,timing:{requestTime:(i||Date.now())/1e3,proxyStart:-1,proxyEnd:-1,dnsStart:-1,dnsEnd:-1,connectStart:-1,connectEnd:-1,sslStart:-1,sslEnd:-1,workerStart:-1,workerReady:-1,sendStart:-1,sendEnd:-1,pushStart:0,pushEnd:0,receiveHeadersEnd:(t[e].responseReceivedTimestamp||0)-(i||Date.now())||-1},protocol:"HTTP/1.1"}}};this.messager.sendToDevtools("__networkDebug",n)}}_netWorkDebugDataReceived(e,t,r,i){var n=t[e].datasReceived||[],s={dataLength:r.dataLength,timestamp:i||Date.now()};n.push(s),t[e]={...t[e]||{},state:r.state,datasReceived:n,dataLength:r.dataLength};var a={method:"Network.dataReceived",params:{requestId:e,timestamp:s.timestamp/1e3,dataLength:r.dataLength,encodedDataLength:r.dataLength}};this.messager.sendToDevtools("__networkDebug",a)}_netWorkDebugDataSent(e,t,r,i){var n=t[e].datasSent||[],s={dataLength:r.dataLength,timestamp:i||Date.now()};n.push(s),t[e]={...t[e]||{},state:r.state,datasSent:n,dataSentLength:r.dataLength}}_netWorkDebugSuccess(e,t,r,i){t[e]={...t[e]||{},state:r.state,statusCode:r.statusCode,statusText:r.statusText,finishedTimestamp:i||Date.now(),dataLength:r.dataLength||t[e].dataLength};var n=t[e].datasSent||[],s=-1,a=-1;n.length>0&&(s=0,a=(t[e].requestTimestamp||0)-(n[n.length-1].timestamp||0));var o={method:"Network.responseReceived",params:{requestId:e,timestamp:(t[e].responseReceivedTimestamp||Date.now())/1e3,type:"XHR",response:{url:t[e].url,status:t[e].statusCode,statusText:t[e].statusText||"",headers:t[e].responseHeaders,mimeType:ue(t[e].responseHeaders),connectionId:e,timing:{requestTime:(t[e].requestTimestamp||Date.now())/1e3,proxyStart:-1,proxyEnd:-1,dnsStart:-1,dnsEnd:-1,connectStart:-1,connectEnd:-1,sslStart:-1,sslEnd:-1,workerStart:-1,workerReady:-1,sendStart:s,sendEnd:a,pushStart:0,pushEnd:0,receiveHeadersEnd:(t[e].responseReceivedTimestamp||0)-(i||Date.now())||-1},protocol:"HTTP/1.1"}}},u={method:"Network.loadingFinished",params:{requestId:e,timestamp:(t[e].finishedTimestamp||Date.now())/1e3,dataLength:t[e].dataLength,encodedDataLength:t[e].dataLength}};"close"!==r.websocketState&&this.messager.sendToDevtools("__networkDebug",o),this.messager.sendToDevtools("__networkDebug",u)}_netWorkDebugFail(e,t,r,i){t[e]={...t[e]||{},state:r.state,finishedTimestamp:i||Date.now()};var n={method:"Network.loadingFailed",params:{requestId:e,timestamp:(t[e].finishedTimestamp||Date.now())/1e3,type:"XHR",errorText:"request failed",canceled:!1}};this.messager.sendToDevtools("__networkDebug",n)}}function Oe(){return{__appServiceSDK__:de,__appServiceEngine__:pe,exparser:fe,Reporter:ge,wx:le,_getCurrentPages:ce,_invokeWebviewMethod:he}}function Le(e){me=e.$eval,ve=e.setGlobalFunctions,r.g.$$autoDebug={$eval:me,setSubContextGlobalFunctions:ve}}var Re,De,Fe,Me=()=>{};class Ve{constructor(e){this.messager=void 0,this.__savedWebviewIds=new Set,this._handleSetWxAppDatas=e=>{var t=this.getCurrentPagesFn()(),r=this.getInvokeWebviewMethodFn();if(Array.isArray(t)&&t.length>0&&t.every((e=>"number"==typeof(e||{}).__wxWebviewId__))){var i={};t.forEach((e=>{i[e.__route__||e.route]=e})),Object.keys(e).forEach((t=>{var n=e[t],s=n.__webviewId__;i[t]&&"function"==typeof i[t].setData?i[t].setData(n):"function"==typeof r&&r("appDataChange",n,[s])}))}},this.messager=e,this._init()}_init(){this.messager.getInstance().registerCallback(this.onReceiveDevtoolsMessage.bind(this))}onReceiveDevtoolsMessage(e,t){if("__setAppData"===e){var r=JSON.parse(t);this._handleSetWxAppDatas(r)}else"__getAppData"===e&&this._handleGetWxAppDatas()}getCurrentPagesFn(){var{_getCurrentPages:e}=Oe();return"function"==typeof e?e:Me}getInvokeWebviewMethodFn(){var{_invokeWebviewMethod:e}=Oe();return e}onAppRouteDone(){var e=this.getCurrentPagesFn()();if(Array.isArray(e)&&e.length>0&&e.every((e=>"number"==typeof(e||{}).__wxWebviewId__))){e.forEach((e=>{this.__savedWebviewIds.add(e.__wxWebviewId__)}));var t={currentWebviewId:e[e.length-1].__wxWebviewId__,webviewIds:Array.from(this.__savedWebviewIds)};this.messager.sendToDevtools("__wxpagesinfo",t)}}onAppRoute(e){var t=e[1]||{};if("navigateBack"===t.openType){var r=e[2];this.__savedWebviewIds.clear(),this.__savedWebviewIds.add(r),this.updateAppData()}else"reLaunch"===t.openType||"autoReLaunch"===t.openType||"redirectTo"===t.openType||"appLaunch"===t.openType?(this.__savedWebviewIds.clear(),this.updateAppData()):"switchTab"!==t.openType&&"navigateTo"!==t.openType||this.updateAppData()}onAppRouteResized(){setTimeout((()=>{this.onAppRouteDone(),this.updateAppData()}),0)}updateAppData(){ye&&clearTimeout(ye),ye=setTimeout(this._handleGetWxAppDatas.bind(this),200)}_handleGetWxAppDatas(){ye&&clearTimeout(ye),ye=void 0;var e=this.getCurrentPagesFn()();if(Array.isArray(e)&&e.length>0&&e.every((e=>"number"==typeof(e||{}).__wxWebviewId__))){for(var t={},r=0;r<e.length;r++){var i=e[r];i&&(i.__route__||i.route)&&(t[i.__route__||i.route]={...i.data||{},__webviewId__:i.__wxWebviewId__})}this.messager.sendToDevtools("__wxappdatas",t)}}}class Be{constructor(e){this.messagerImpl=void 0,this.messagerImpl=e}sendToDevtools(e,t){var r;this.messagerImpl&&("string"!=typeof t&&(t=JSON.stringify(t)),null===(r=this.messagerImpl)||void 0===r||r.sendCustomMessage(e,t))}registerCallback(e){var t;this.messagerImpl&&(null===(t=this.messagerImpl)||void 0===t||t.registerCallback(e))}getInstance(){return this.messagerImpl}}class je{constructor(e,t,r,i,n){this.networkDebugger=void 0,this.wxmlDebugger=void 0,this.storageDebugger=void 0,this._subscribeHandler=(e,...t)=>{switch(t[0]){case"onRequestTaskStateChange":var r;null!==(r=t[1])&&void 0!==r&&r.requestTaskId&&this.networkDebugger.onRequestTaskStateChange(t);break;case"onDownloadTaskStateChange":var i;null!==(i=t[1])&&void 0!==i&&i.downloadTaskId&&this.networkDebugger.onDownloadTaskStateChange(t);break;case"onUploadTaskStateChange":var n;null!==(n=t[1])&&void 0!==n&&n.uploadTaskId&&this.networkDebugger.onUploadTaskStateChange(t);break;case"onSocketTaskStateChange":var s;null!==(s=t[1])&&void 0!==s&&s.socketTaskId&&this.networkDebugger.onSocketTaskStateChange(t);break;case"onAppRouteDone":this.wxmlDebugger.onAppRouteDone();break;case"onAppRoute":this.wxmlDebugger.onAppRoute(t);break;case"onAppRouteResized":this.wxmlDebugger.onAppRouteResized()}return e.call(De,...t)},this._invokeCallbackHandler=(e,...t)=>{var r=t[0],i=t[1];return this.networkDebugger.invokeCallbackNetworkMethods(r,i),e.call(De,...t)},this._hookWeixinJSCore=(e,t,...r)=>{var i=r[0],n=r[1],s=parseInt(r[2],10),a=isNaN(s)?0:s;if("publishHandler"===e){try{if(i.endsWith("invokeWebviewMethod"))"appDataChange"===(__wxConfig.wmpfDirectInvokeJs?n:JSON.parse(n)).data.name&&this.wxmlDebugger.updateAppData();(i.endsWith("vdSync")||i.endsWith("vdSyncBatch")||i.endsWith("appDataChange")||i.endsWith("pageInitData")||i.endsWith("__updateAppData"))&&this.wxmlDebugger.updateAppData()}catch(e){}return t.call(Re,...r)}return this._methodInvokeHandler(a,i,n,r,t)},De=e,Re=t,this.networkDebugger=r,this.wxmlDebugger=i,this.storageDebugger=n;var s=De.subscribeHandler,a=De.invokeCallbackHandler,o=Re.invokeHandler||(()=>{}),u=Re.publishHandler||(()=>{});Object.defineProperty(De,"subscribeHandler",{value:this._subscribeHandler.bind(null,s)}),Object.defineProperty(De,"invokeCallbackHandler",{value:this._invokeCallbackHandler.bind(null,a)}),Object.defineProperty(Re,"invokeHandler",{value:this._hookWeixinJSCore.bind(null,"invokeHandler",o)}),Object.defineProperty(Re,"publishHandler",{value:this._hookWeixinJSCore.bind(null,"publishHandler",u)})}_methodInvokeHandler(e,t,r,i,n){return this.networkDebugger.invokeNetworkMethods(e,t,r),this.storageDebugger.invokeStorageMethods(e,t),n.call(Re,...i)}}class He{constructor(e,t){this.messager=void 0,Fe=e,this.messager=t,this._init()}_init(){this.messager.getInstance().registerCallback(this.onAutoMessageReceive.bind(this))}onAutoMessageReceive(e,t){var r;"onAutoMessageReceive"===e&&(null===(r=Fe)||void 0===r||r.subscribeHandler("onAutoMessageReceive",JSON.parse(t)))}}var Ue=r(589),Ge=r.n(Ue);class We{constructor(e){this.messager=void 0,this.messager=e,this._init()}_init(){this.messager.getInstance().registerCallback(this.onReceiveDevtoolsMessage.bind(this))}onReceiveDevtoolsMessage(e,t){"__getStorageInfo"!==e?"__execStorageSdk"===e&&this.execStorageSdk(t):this.getFullStorage()}execStorageSdk(e){var t=this;return Ge()((function*(){var r,i,n,s;try{var a=JSON.parse(e);switch(a.api){case"removeStorage":case"removeStorageSync":yield t._removeStorage(null==a||null===(r=a.args)||void 0===r?void 0:r.key);break;case"setStorage":case"setStorageSync":yield t._setStorage(null==a||null===(i=a.args)||void 0===i?void 0:i.key,null==a||null===(n=a.args)||void 0===n?void 0:n.data,null==a||null===(s=a.args)||void 0===s?void 0:s.dataType);break;case"clearStorage":case"clearStorageSync":yield t._clearStorage()}}catch(e){console.error(e)}}))()}getFullStorage(){var e=this;return Ge()((function*(){var t=e._getStorageInfo();if(t){var r=(yield t()).keys,i={};for(var n of r){var s=yield e._getStorage(n),a=Object.prototype.toString.call(s).slice(8,-1);"string"!==a.toLowerCase()&&(s=JSON.stringify(s)),i[n]={data:void 0===s?"undefined":s,dataType:a}}e.messager.sendToDevtools("__getStorageInfo",JSON.stringify(i))}}))()}_getStorageInfo(){var{wx:e}=Oe();return"object"==typeof e&&e.getStorageInfo?e.getStorageInfo.bind(e):null}_getStorage(e){return Ge()((function*(){var{wx:t}=Oe();if("object"==typeof t&&t.getStorage)try{return(yield t.getStorage({key:e})).data}catch(e){return}}))()}_removeStorage(e){return Ge()((function*(){if(e){var{wx:t}=Oe();if("object"==typeof t&&t.removeStorage)try{yield t.removeStorage({key:e})}catch(e){return}}}))()}_setStorage(e,t,r){return Ge()((function*(){"string"!==r.toLowerCase()&&(t=JSON.parse(t));var{wx:i}=Oe();if("object"==typeof i&&i.setStorage)try{i.setStorageSync(e,t)}catch(e){return}}))()}_clearStorage(){return Ge()((function*(){var{wx:e}=Oe();if("object"==typeof e&&e.clearStorage)try{yield e.clearStorage()}catch(e){return}}))()}invokeStorageMethods(e,t){if(t.toLowerCase().includes("storage"))switch(t){case"setStorageSync":case"setStorage":case"removeStorageSync":case"removeStorage":case"clearStorageSync":case"clearStorage":setTimeout((()=>{this.getFullStorage()}),0)}}}var qe={3:"abstract boolean byte char class double enum export extends final float goto implements import int interface long native package private protected public short static super synchronized throws transient volatile",5:"class enum extends super const export import",6:"enum",strict:"implements interface let package private protected public static yield",strictBind:"eval arguments"},$e="break case catch continue debugger default do else finally for function if return switch throw try var while with null true false instanceof typeof void delete new in this",ze={5:$e,"5module":$e+" export import",6:$e+" const class extends export import super"},Je=/^in(stanceof)?$/,Ke="ªµºÀ-ÖØ-öø-ˁˆ-ˑˠ-ˤˬˮͰ-ʹͶͷͺ-ͽͿΆΈ-ΊΌΎ-ΡΣ-ϵϷ-ҁҊ-ԯԱ-Ֆՙՠ-ֈא-תׯ-ײؠ-يٮٯٱ-ۓەۥۦۮۯۺ-ۼۿܐܒ-ܯݍ-ޥޱߊ-ߪߴߵߺࠀ-ࠕࠚࠤࠨࡀ-ࡘࡠ-ࡪࢠ-ࢴࢶ-ࣇऄ-हऽॐक़-ॡॱ-ঀঅ-ঌএঐও-নপ-রলশ-হঽৎড়ঢ়য়-ৡৰৱৼਅ-ਊਏਐਓ-ਨਪ-ਰਲਲ਼ਵਸ਼ਸਹਖ਼-ੜਫ਼ੲ-ੴઅ-ઍએ-ઑઓ-નપ-રલળવ-હઽૐૠૡૹଅ-ଌଏଐଓ-ନପ-ରଲଳଵ-ହଽଡ଼ଢ଼ୟ-ୡୱஃஅ-ஊஎ-ஐஒ-கஙசஜஞடணதந-பம-ஹௐఅ-ఌఎ-ఐఒ-నప-హఽౘ-ౚౠౡಀಅ-ಌಎ-ಐಒ-ನಪ-ಳವ-ಹಽೞೠೡೱೲഄ-ഌഎ-ഐഒ-ഺഽൎൔ-ൖൟ-ൡൺ-ൿඅ-ඖක-නඳ-රලව-ෆก-ะาำเ-ๆກຂຄຆ-ຊຌ-ຣລວ-ະາຳຽເ-ໄໆໜ-ໟༀཀ-ཇཉ-ཬྈ-ྌက-ဪဿၐ-ၕၚ-ၝၡၥၦၮ-ၰၵ-ႁႎႠ-ჅჇჍა-ჺჼ-ቈቊ-ቍቐ-ቖቘቚ-ቝበ-ኈኊ-ኍነ-ኰኲ-ኵኸ-ኾዀዂ-ዅወ-ዖዘ-ጐጒ-ጕጘ-ፚᎀ-ᎏᎠ-Ᏽᏸ-ᏽᐁ-ᙬᙯ-ᙿᚁ-ᚚᚠ-ᛪᛮ-ᛸᜀ-ᜌᜎ-ᜑᜠ-ᜱᝀ-ᝑᝠ-ᝬᝮ-ᝰក-ឳៗៜᠠ-ᡸᢀ-ᢨᢪᢰ-ᣵᤀ-ᤞᥐ-ᥭᥰ-ᥴᦀ-ᦫᦰ-ᧉᨀ-ᨖᨠ-ᩔᪧᬅ-ᬳᭅ-ᭋᮃ-ᮠᮮᮯᮺ-ᯥᰀ-ᰣᱍ-ᱏᱚ-ᱽᲀ-ᲈᲐ-ᲺᲽ-Ჿᳩ-ᳬᳮ-ᳳᳵᳶᳺᴀ-ᶿḀ-ἕἘ-Ἕἠ-ὅὈ-Ὅὐ-ὗὙὛὝὟ-ώᾀ-ᾴᾶ-ᾼιῂ-ῄῆ-ῌῐ-ΐῖ-Ίῠ-Ῥῲ-ῴῶ-ῼⁱⁿₐ-ₜℂℇℊ-ℓℕ℘-ℝℤΩℨK-ℹℼ-ℿⅅ-ⅉⅎⅠ-ↈⰀ-Ⱞⰰ-ⱞⱠ-ⳤⳫ-ⳮⳲⳳⴀ-ⴥⴧⴭⴰ-ⵧⵯⶀ-ⶖⶠ-ⶦⶨ-ⶮⶰ-ⶶⶸ-ⶾⷀ-ⷆⷈ-ⷎⷐ-ⷖⷘ-ⷞ々-〇〡-〩〱-〵〸-〼ぁ-ゖ゛-ゟァ-ヺー-ヿㄅ-ㄯㄱ-ㆎㆠ-ㆿㇰ-ㇿ㐀-䶿一-鿼ꀀ-ꒌꓐ-ꓽꔀ-ꘌꘐ-ꘟꘪꘫꙀ-ꙮꙿ-ꚝꚠ-ꛯꜗ-ꜟꜢ-ꞈꞋ-ꞿꟂ-ꟊꟵ-ꠁꠃ-ꠅꠇ-ꠊꠌ-ꠢꡀ-ꡳꢂ-ꢳꣲ-ꣷꣻꣽꣾꤊ-ꤥꤰ-ꥆꥠ-ꥼꦄ-ꦲꧏꧠ-ꧤꧦ-ꧯꧺ-ꧾꨀ-ꨨꩀ-ꩂꩄ-ꩋꩠ-ꩶꩺꩾ-ꪯꪱꪵꪶꪹ-ꪽꫀꫂꫛ-ꫝꫠ-ꫪꫲ-ꫴꬁ-ꬆꬉ-ꬎꬑ-ꬖꬠ-ꬦꬨ-ꬮꬰ-ꭚꭜ-ꭩꭰ-ꯢ가-힣ힰ-ퟆퟋ-ퟻ豈-舘並-龎ﬀ-ﬆﬓ-ﬗיִײַ-ﬨשׁ-זּטּ-לּמּנּסּףּפּצּ-ﮱﯓ-ﴽﵐ-ﶏﶒ-ﷇﷰ-ﷻﹰ-ﹴﹶ-ﻼＡ-Ｚａ-ｚｦ-ﾾￂ-ￇￊ-ￏￒ-ￗￚ-ￜ",Qe="‌‍·̀-ͯ·҃-֑҇-ׇֽֿׁׂׅׄؐ-ًؚ-٩ٰۖ-ۜ۟-۪ۤۧۨ-ۭ۰-۹ܑܰ-݊ަ-ް߀-߉߫-߽߳ࠖ-࠙ࠛ-ࠣࠥ-ࠧࠩ-࡙࠭-࡛࣓-ࣣ࣡-ःऺ-़ा-ॏ॑-ॗॢॣ०-९ঁ-ঃ়া-ৄেৈো-্ৗৢৣ০-৯৾ਁ-ਃ਼ਾ-ੂੇੈੋ-੍ੑ੦-ੱੵઁ-ઃ઼ા-ૅે-ૉો-્ૢૣ૦-૯ૺ-૿ଁ-ଃ଼ା-ୄେୈୋ-୍୕-ୗୢୣ୦-୯ஂா-ூெ-ைொ-்ௗ௦-௯ఀ-ఄా-ౄె-ైొ-్ౕౖౢౣ౦-౯ಁ-ಃ಼ಾ-ೄೆ-ೈೊ-್ೕೖೢೣ೦-೯ഀ-ഃ഻഼ാ-ൄെ-ൈൊ-്ൗൢൣ൦-൯ඁ-ඃ්ා-ුූෘ-ෟ෦-෯ෲෳัิ-ฺ็-๎๐-๙ັິ-ຼ່-ໍ໐-໙༘༙༠-༩༹༵༷༾༿ཱ-྄྆྇ྍ-ྗྙ-ྼ࿆ါ-ှ၀-၉ၖ-ၙၞ-ၠၢ-ၤၧ-ၭၱ-ၴႂ-ႍႏ-ႝ፝-፟፩-፱ᜒ-᜔ᜲ-᜴ᝒᝓᝲᝳ឴-៓៝០-៩᠋-᠍᠐-᠙ᢩᤠ-ᤫᤰ-᤻᥆-᥏᧐-᧚ᨗ-ᨛᩕ-ᩞ᩠-᩿᩼-᪉᪐-᪙᪰-᪽ᪿᫀᬀ-ᬄ᬴-᭄᭐-᭙᭫-᭳ᮀ-ᮂᮡ-ᮭ᮰-᮹᯦-᯳ᰤ-᰷᱀-᱉᱐-᱙᳐-᳔᳒-᳨᳭᳴᳷-᳹᷀-᷹᷻-᷿‿⁀⁔⃐-⃥⃜⃡-⃰⳯-⵿⳱ⷠ-〪ⷿ-゙゚〯꘠-꘩꙯ꙴ-꙽ꚞꚟ꛰꛱ꠂ꠆ꠋꠣ-ꠧ꠬ꢀꢁꢴ-ꣅ꣐-꣙꣠-꣱ꣿ-꤉ꤦ-꤭ꥇ-꥓ꦀ-ꦃ꦳-꧀꧐-꧙ꧥ꧰-꧹ꨩ-ꨶꩃꩌꩍ꩐-꩙ꩻ-ꩽꪰꪲ-ꪴꪷꪸꪾ꪿꫁ꫫ-ꫯꫵ꫶ꯣ-ꯪ꯬꯭꯰-꯹ﬞ︀-️︠-︯︳︴﹍-﹏０-９＿",Xe=new RegExp("["+Ke+"]"),Ye=new RegExp("["+Ke+Qe+"]");Ke=Qe=null;var Ze=[0,11,2,25,2,18,2,1,2,14,3,13,35,122,70,52,268,28,4,48,48,31,14,29,6,37,11,29,3,35,5,7,2,4,43,157,19,35,5,35,5,39,9,51,157,310,10,21,11,7,153,5,3,0,2,43,2,1,4,0,3,22,11,22,10,30,66,18,2,1,11,21,11,25,71,55,7,1,65,0,16,3,2,2,2,28,43,28,4,28,36,7,2,27,28,53,11,21,11,18,14,17,111,72,56,50,14,50,14,35,349,41,7,1,79,28,11,0,9,21,107,20,28,22,13,52,76,44,33,24,27,35,30,0,3,0,9,34,4,0,13,47,15,3,22,0,2,0,36,17,2,24,85,6,2,0,2,3,2,14,2,9,8,46,39,7,3,1,3,21,2,6,2,1,2,4,4,0,19,0,13,4,159,52,19,3,21,2,31,47,21,1,2,0,185,46,42,3,37,47,21,0,60,42,14,0,72,26,230,43,117,63,32,7,3,0,3,7,2,1,2,23,16,0,2,0,95,7,3,38,17,0,2,0,29,0,11,39,8,0,22,0,12,45,20,0,35,56,264,8,2,36,18,0,50,29,113,6,2,1,2,37,22,0,26,5,2,1,2,31,15,0,328,18,190,0,80,921,103,110,18,195,2749,1070,4050,582,8634,568,8,30,114,29,19,47,17,3,32,20,6,18,689,63,129,74,6,0,67,12,65,1,2,0,29,6135,9,1237,43,8,8952,286,50,2,18,3,9,395,2309,106,6,12,4,8,8,9,5991,84,2,70,2,1,3,0,3,1,3,3,2,11,2,0,2,6,2,64,2,3,3,7,2,6,2,27,2,3,2,4,2,0,4,6,2,339,3,24,2,24,2,30,2,24,2,30,2,24,2,30,2,24,2,30,2,24,2,7,2357,44,11,6,17,0,370,43,1301,196,60,67,8,0,1205,3,2,26,2,1,2,0,3,0,2,9,2,3,2,0,2,0,7,0,5,0,2,0,2,0,2,2,2,1,2,0,3,0,2,0,2,0,2,0,2,0,2,1,2,0,3,3,2,6,2,3,2,3,2,0,2,9,2,16,6,2,2,4,2,16,4421,42717,35,4148,12,221,3,5761,15,7472,3104,541,1507,4938],et=[509,0,227,0,150,4,294,9,1368,2,2,1,6,3,41,2,5,0,166,1,574,3,9,9,370,1,154,10,176,2,54,14,32,9,16,3,46,10,54,9,7,2,37,13,2,9,6,1,45,0,13,2,49,13,9,3,2,11,83,11,7,0,161,11,6,9,7,3,56,1,2,6,3,1,3,2,10,0,11,1,3,6,4,4,193,17,10,9,5,0,82,19,13,9,214,6,3,8,28,1,83,16,16,9,82,12,9,9,84,14,5,9,243,14,166,9,71,5,2,1,3,3,2,0,2,1,13,9,120,6,3,6,4,0,29,9,41,6,2,3,9,0,10,10,47,15,406,7,2,7,17,9,57,21,2,13,123,5,4,0,2,1,2,6,2,0,9,9,49,4,2,1,2,4,9,9,330,3,19306,9,135,4,60,6,26,9,1014,0,2,54,8,3,82,0,12,1,19628,1,5319,4,4,5,9,7,3,6,31,3,149,2,1418,49,513,54,5,49,9,0,15,0,23,4,2,14,1361,6,2,16,3,6,2,1,2,4,262,6,10,9,419,13,1495,6,110,6,6,9,4759,9,787719,239];function tt(e,t){for(var r=65536,i=0;i<t.length;i+=2){if((r+=t[i])>e)return!1;if((r+=t[i+1])>=e)return!0}}function rt(e,t){return e<65?36===e:e<91||(e<97?95===e:e<123||(e<=65535?e>=170&&Xe.test(String.fromCharCode(e)):!1!==t&&tt(e,Ze)))}function it(e,t){return e<48?36===e:e<58||!(e<65)&&(e<91||(e<97?95===e:e<123||(e<=65535?e>=170&&Ye.test(String.fromCharCode(e)):!1!==t&&(tt(e,Ze)||tt(e,et)))))}var nt=function(e,t){void 0===t&&(t={}),this.label=e,this.keyword=t.keyword,this.beforeExpr=!!t.beforeExpr,this.startsExpr=!!t.startsExpr,this.isLoop=!!t.isLoop,this.isAssign=!!t.isAssign,this.prefix=!!t.prefix,this.postfix=!!t.postfix,this.binop=t.binop||null,this.updateContext=null};function st(e,t){return new nt(e,{beforeExpr:!0,binop:t})}var at={beforeExpr:!0},ot={startsExpr:!0},ut={};function ct(e,t){return void 0===t&&(t={}),t.keyword=e,ut[e]=new nt(e,t)}var ht={num:new nt("num",ot),regexp:new nt("regexp",ot),string:new nt("string",ot),name:new nt("name",ot),eof:new nt("eof"),bracketL:new nt("[",{beforeExpr:!0,startsExpr:!0}),bracketR:new nt("]"),braceL:new nt("{",{beforeExpr:!0,startsExpr:!0}),braceR:new nt("}"),parenL:new nt("(",{beforeExpr:!0,startsExpr:!0}),parenR:new nt(")"),comma:new nt(",",at),semi:new nt(";",at),colon:new nt(":",at),dot:new nt("."),question:new nt("?",at),questionDot:new nt("?."),arrow:new nt("=>",at),template:new nt("template"),invalidTemplate:new nt("invalidTemplate"),ellipsis:new nt("...",at),backQuote:new nt("`",ot),dollarBraceL:new nt("${",{beforeExpr:!0,startsExpr:!0}),eq:new nt("=",{beforeExpr:!0,isAssign:!0}),assign:new nt("_=",{beforeExpr:!0,isAssign:!0}),incDec:new nt("++/--",{prefix:!0,postfix:!0,startsExpr:!0}),prefix:new nt("!/~",{beforeExpr:!0,prefix:!0,startsExpr:!0}),logicalOR:st("||",1),logicalAND:st("&&",2),bitwiseOR:st("|",3),bitwiseXOR:st("^",4),bitwiseAND:st("&",5),equality:st("==/!=/===/!==",6),relational:st("</>/<=/>=",7),bitShift:st("<</>>/>>>",8),plusMin:new nt("+/-",{beforeExpr:!0,binop:9,prefix:!0,startsExpr:!0}),modulo:st("%",10),star:st("*",10),slash:st("/",10),starstar:new nt("**",{beforeExpr:!0}),coalesce:st("??",1),_break:ct("break"),_case:ct("case",at),_catch:ct("catch"),_continue:ct("continue"),_debugger:ct("debugger"),_default:ct("default",at),_do:ct("do",{isLoop:!0,beforeExpr:!0}),_else:ct("else",at),_finally:ct("finally"),_for:ct("for",{isLoop:!0}),_function:ct("function",ot),_if:ct("if"),_return:ct("return",at),_switch:ct("switch"),_throw:ct("throw",at),_try:ct("try"),_var:ct("var"),_const:ct("const"),_while:ct("while",{isLoop:!0}),_with:ct("with"),_new:ct("new",{beforeExpr:!0,startsExpr:!0}),_this:ct("this",ot),_super:ct("super",ot),_class:ct("class",ot),_extends:ct("extends",at),_export:ct("export"),_import:ct("import",ot),_null:ct("null",ot),_true:ct("true",ot),_false:ct("false",ot),_in:ct("in",{beforeExpr:!0,binop:7}),_instanceof:ct("instanceof",{beforeExpr:!0,binop:7}),_typeof:ct("typeof",{beforeExpr:!0,prefix:!0,startsExpr:!0}),_void:ct("void",{beforeExpr:!0,prefix:!0,startsExpr:!0}),_delete:ct("delete",{beforeExpr:!0,prefix:!0,startsExpr:!0})},lt=/\r\n?|\n|\u2028|\u2029/,pt=new RegExp(lt.source,"g");function dt(e,t){return 10===e||13===e||!t&&(8232===e||8233===e)}var ft=/[\u1680\u2000-\u200a\u202f\u205f\u3000\ufeff]/,gt=/(?:\s|\/\/.*|\/\*[^]*?\*\/)*/g,mt=Object.prototype,vt=mt.hasOwnProperty,bt=mt.toString;function yt(e,t){return vt.call(e,t)}var xt=Array.isArray||function(e){return"[object Array]"===bt.call(e)};function St(e){return new RegExp("^(?:"+e.replace(/ /g,"|")+")$")}var _t=function(e,t){this.line=e,this.column=t};_t.prototype.offset=function(e){return new _t(this.line,this.column+e)};var wt=function(e,t,r){this.start=t,this.end=r,null!==e.sourceFile&&(this.source=e.sourceFile)};function Ct(e,t){for(var r=1,i=0;;){pt.lastIndex=i;var n=pt.exec(e);if(!(n&&n.index<t))return new _t(r,t-i);++r,i=n.index+n[0].length}}var kt={ecmaVersion:10,sourceType:"script",onInsertedSemicolon:null,onTrailingComma:null,allowReserved:null,allowReturnOutsideFunction:!1,allowImportExportEverywhere:!1,allowAwaitOutsideFunction:!1,allowHashBang:!1,locations:!1,onToken:null,onComment:null,ranges:!1,program:null,sourceFile:null,directSourceFile:null,preserveParens:!1};function Et(e){var t={};for(var r in kt)t[r]=e&&yt(e,r)?e[r]:kt[r];if(t.ecmaVersion>=2015&&(t.ecmaVersion-=2009),null==t.allowReserved&&(t.allowReserved=t.ecmaVersion<5),xt(t.onToken)){var i=t.onToken;t.onToken=function(e){return i.push(e)}}return xt(t.onComment)&&(t.onComment=function(e,t){return function(r,i,n,s,a,o){var u={type:r?"Block":"Line",value:i,start:n,end:s};e.locations&&(u.loc=new wt(this,a,o)),e.ranges&&(u.range=[n,s]),t.push(u)}}(t,t.onComment)),t}function It(e,t){return 2|(e?4:0)|(t?8:0)}var At=function(e,t,r){this.options=e=Et(e),this.sourceFile=e.sourceFile,this.keywords=St(ze[e.ecmaVersion>=6?6:"module"===e.sourceType?"5module":5]);var i="";if(!0!==e.allowReserved){for(var n=e.ecmaVersion;!(i=qe[n]);n--);"module"===e.sourceType&&(i+=" await")}this.reservedWords=St(i);var s=(i?i+" ":"")+qe.strict;this.reservedWordsStrict=St(s),this.reservedWordsStrictBind=St(s+" "+qe.strictBind),this.input=String(t),this.containsEsc=!1,r?(this.pos=r,this.lineStart=this.input.lastIndexOf("\n",r-1)+1,this.curLine=this.input.slice(0,this.lineStart).split(lt).length):(this.pos=this.lineStart=0,this.curLine=1),this.type=ht.eof,this.value=null,this.start=this.end=this.pos,this.startLoc=this.endLoc=this.curPosition(),this.lastTokEndLoc=this.lastTokStartLoc=null,this.lastTokStart=this.lastTokEnd=this.pos,this.context=this.initialContext(),this.exprAllowed=!0,this.inModule="module"===e.sourceType,this.strict=this.inModule||this.strictDirective(this.pos),this.potentialArrowAt=-1,this.yieldPos=this.awaitPos=this.awaitIdentPos=0,this.labels=[],this.undefinedExports={},0===this.pos&&e.allowHashBang&&"#!"===this.input.slice(0,2)&&this.skipLineComment(2),this.scopeStack=[],this.enterScope(1),this.regexpState=null},Tt={inFunction:{configurable:!0},inGenerator:{configurable:!0},inAsync:{configurable:!0},allowSuper:{configurable:!0},allowDirectSuper:{configurable:!0},treatFunctionsAsVar:{configurable:!0}};At.prototype.parse=function(){var e=this.options.program||this.startNode();return this.nextToken(),this.parseTopLevel(e)},Tt.inFunction.get=function(){return(2&this.currentVarScope().flags)>0},Tt.inGenerator.get=function(){return(8&this.currentVarScope().flags)>0},Tt.inAsync.get=function(){return(4&this.currentVarScope().flags)>0},Tt.allowSuper.get=function(){return(64&this.currentThisScope().flags)>0},Tt.allowDirectSuper.get=function(){return(128&this.currentThisScope().flags)>0},Tt.treatFunctionsAsVar.get=function(){return this.treatFunctionsAsVarInScope(this.currentScope())},At.prototype.inNonArrowFunction=function(){return(2&this.currentThisScope().flags)>0},At.extend=function(){for(var e=[],t=arguments.length;t--;)e[t]=arguments[t];for(var r=this,i=0;i<e.length;i++)r=e[i](r);return r},At.parse=function(e,t){return new this(t,e).parse()},At.parseExpressionAt=function(e,t,r){var i=new this(r,e,t);return i.nextToken(),i.parseExpression()},At.tokenizer=function(e,t){return new this(t,e)},Object.defineProperties(At.prototype,Tt);var Nt=At.prototype,Pt=/^(?:'((?:\\.|[^'\\])*?)'|"((?:\\.|[^"\\])*?)")/;function Ot(){this.shorthandAssign=this.trailingComma=this.parenthesizedAssign=this.parenthesizedBind=this.doubleProto=-1}Nt.strictDirective=function(e){for(;;){gt.lastIndex=e,e+=gt.exec(this.input)[0].length;var t=Pt.exec(this.input.slice(e));if(!t)return!1;if("use strict"===(t[1]||t[2])){gt.lastIndex=e+t[0].length;var r=gt.exec(this.input),i=r.index+r[0].length,n=this.input.charAt(i);return";"===n||"}"===n||lt.test(r[0])&&!(/[(`.[+\-/*%<>=,?^&]/.test(n)||"!"===n&&"="===this.input.charAt(i+1))}e+=t[0].length,gt.lastIndex=e,e+=gt.exec(this.input)[0].length,";"===this.input[e]&&e++}},Nt.eat=function(e){return this.type===e&&(this.next(),!0)},Nt.isContextual=function(e){return this.type===ht.name&&this.value===e&&!this.containsEsc},Nt.eatContextual=function(e){return!!this.isContextual(e)&&(this.next(),!0)},Nt.expectContextual=function(e){this.eatContextual(e)||this.unexpected()},Nt.canInsertSemicolon=function(){return this.type===ht.eof||this.type===ht.braceR||lt.test(this.input.slice(this.lastTokEnd,this.start))},Nt.insertSemicolon=function(){if(this.canInsertSemicolon())return this.options.onInsertedSemicolon&&this.options.onInsertedSemicolon(this.lastTokEnd,this.lastTokEndLoc),!0},Nt.semicolon=function(){this.eat(ht.semi)||this.insertSemicolon()||this.unexpected()},Nt.afterTrailingComma=function(e,t){if(this.type===e)return this.options.onTrailingComma&&this.options.onTrailingComma(this.lastTokStart,this.lastTokStartLoc),t||this.next(),!0},Nt.expect=function(e){this.eat(e)||this.unexpected()},Nt.unexpected=function(e){this.raise(null!=e?e:this.start,"Unexpected token")},Nt.checkPatternErrors=function(e,t){if(e){e.trailingComma>-1&&this.raiseRecoverable(e.trailingComma,"Comma is not permitted after the rest element");var r=t?e.parenthesizedAssign:e.parenthesizedBind;r>-1&&this.raiseRecoverable(r,"Parenthesized pattern")}},Nt.checkExpressionErrors=function(e,t){if(!e)return!1;var r=e.shorthandAssign,i=e.doubleProto;if(!t)return r>=0||i>=0;r>=0&&this.raise(r,"Shorthand property assignments are valid only in destructuring patterns"),i>=0&&this.raiseRecoverable(i,"Redefinition of __proto__ property")},Nt.checkYieldAwaitInDefaultParams=function(){this.yieldPos&&(!this.awaitPos||this.yieldPos<this.awaitPos)&&this.raise(this.yieldPos,"Yield expression cannot be a default value"),this.awaitPos&&this.raise(this.awaitPos,"Await expression cannot be a default value")},Nt.isSimpleAssignTarget=function(e){return"ParenthesizedExpression"===e.type?this.isSimpleAssignTarget(e.expression):"Identifier"===e.type||"MemberExpression"===e.type};var Lt=At.prototype;Lt.parseTopLevel=function(e){var t={};for(e.body||(e.body=[]);this.type!==ht.eof;){var r=this.parseStatement(null,!0,t);e.body.push(r)}if(this.inModule)for(var i=0,n=Object.keys(this.undefinedExports);i<n.length;i+=1){var s=n[i];this.raiseRecoverable(this.undefinedExports[s].start,"Export '"+s+"' is not defined")}return this.adaptDirectivePrologue(e.body),this.next(),e.sourceType=this.options.sourceType,this.finishNode(e,"Program")};var Rt={kind:"loop"},Dt={kind:"switch"};Lt.isLet=function(e){if(this.options.ecmaVersion<6||!this.isContextual("let"))return!1;gt.lastIndex=this.pos;var t=gt.exec(this.input),r=this.pos+t[0].length,i=this.input.charCodeAt(r);if(91===i)return!0;if(e)return!1;if(123===i)return!0;if(rt(i,!0)){for(var n=r+1;it(this.input.charCodeAt(n),!0);)++n;var s=this.input.slice(r,n);if(!Je.test(s))return!0}return!1},Lt.isAsyncFunction=function(){if(this.options.ecmaVersion<8||!this.isContextual("async"))return!1;gt.lastIndex=this.pos;var e=gt.exec(this.input),t=this.pos+e[0].length;return!(lt.test(this.input.slice(this.pos,t))||"function"!==this.input.slice(t,t+8)||t+8!==this.input.length&&it(this.input.charAt(t+8)))},Lt.parseStatement=function(e,t,r){var i,n=this.type,s=this.startNode();switch(this.isLet(e)&&(n=ht._var,i="let"),n){case ht._break:case ht._continue:return this.parseBreakContinueStatement(s,n.keyword);case ht._debugger:return this.parseDebuggerStatement(s);case ht._do:return this.parseDoStatement(s);case ht._for:return this.parseForStatement(s);case ht._function:return e&&(this.strict||"if"!==e&&"label"!==e)&&this.options.ecmaVersion>=6&&this.unexpected(),this.parseFunctionStatement(s,!1,!e);case ht._class:return e&&this.unexpected(),this.parseClass(s,!0);case ht._if:return this.parseIfStatement(s);case ht._return:return this.parseReturnStatement(s);case ht._switch:return this.parseSwitchStatement(s);case ht._throw:return this.parseThrowStatement(s);case ht._try:return this.parseTryStatement(s);case ht._const:case ht._var:return i=i||this.value,e&&"var"!==i&&this.unexpected(),this.parseVarStatement(s,i);case ht._while:return this.parseWhileStatement(s);case ht._with:return this.parseWithStatement(s);case ht.braceL:return this.parseBlock(!0,s);case ht.semi:return this.parseEmptyStatement(s);case ht._export:case ht._import:if(this.options.ecmaVersion>10&&n===ht._import){gt.lastIndex=this.pos;var a=gt.exec(this.input),o=this.pos+a[0].length,u=this.input.charCodeAt(o);if(40===u||46===u)return this.parseExpressionStatement(s,this.parseExpression())}return this.options.allowImportExportEverywhere||(t||this.raise(this.start,"'import' and 'export' may only appear at the top level"),this.inModule||this.raise(this.start,"'import' and 'export' may appear only with 'sourceType: module'")),n===ht._import?this.parseImport(s):this.parseExport(s,r);default:if(this.isAsyncFunction())return e&&this.unexpected(),this.next(),this.parseFunctionStatement(s,!0,!e);var c=this.value,h=this.parseExpression();return n===ht.name&&"Identifier"===h.type&&this.eat(ht.colon)?this.parseLabeledStatement(s,c,h,e):this.parseExpressionStatement(s,h)}},Lt.parseBreakContinueStatement=function(e,t){var r="break"===t;this.next(),this.eat(ht.semi)||this.insertSemicolon()?e.label=null:this.type!==ht.name?this.unexpected():(e.label=this.parseIdent(),this.semicolon());for(var i=0;i<this.labels.length;++i){var n=this.labels[i];if(null==e.label||n.name===e.label.name){if(null!=n.kind&&(r||"loop"===n.kind))break;if(e.label&&r)break}}return i===this.labels.length&&this.raise(e.start,"Unsyntactic "+t),this.finishNode(e,r?"BreakStatement":"ContinueStatement")},Lt.parseDebuggerStatement=function(e){return this.next(),this.semicolon(),this.finishNode(e,"DebuggerStatement")},Lt.parseDoStatement=function(e){return this.next(),this.labels.push(Rt),e.body=this.parseStatement("do"),this.labels.pop(),this.expect(ht._while),e.test=this.parseParenExpression(),this.options.ecmaVersion>=6?this.eat(ht.semi):this.semicolon(),this.finishNode(e,"DoWhileStatement")},Lt.parseForStatement=function(e){this.next();var t=this.options.ecmaVersion>=9&&(this.inAsync||!this.inFunction&&this.options.allowAwaitOutsideFunction)&&this.eatContextual("await")?this.lastTokStart:-1;if(this.labels.push(Rt),this.enterScope(0),this.expect(ht.parenL),this.type===ht.semi)return t>-1&&this.unexpected(t),this.parseFor(e,null);var r=this.isLet();if(this.type===ht._var||this.type===ht._const||r){var i=this.startNode(),n=r?"let":this.value;return this.next(),this.parseVar(i,!0,n),this.finishNode(i,"VariableDeclaration"),(this.type===ht._in||this.options.ecmaVersion>=6&&this.isContextual("of"))&&1===i.declarations.length?(this.options.ecmaVersion>=9&&(this.type===ht._in?t>-1&&this.unexpected(t):e.await=t>-1),this.parseForIn(e,i)):(t>-1&&this.unexpected(t),this.parseFor(e,i))}var s=new Ot,a=this.parseExpression(!0,s);return this.type===ht._in||this.options.ecmaVersion>=6&&this.isContextual("of")?(this.options.ecmaVersion>=9&&(this.type===ht._in?t>-1&&this.unexpected(t):e.await=t>-1),this.toAssignable(a,!1,s),this.checkLVal(a),this.parseForIn(e,a)):(this.checkExpressionErrors(s,!0),t>-1&&this.unexpected(t),this.parseFor(e,a))},Lt.parseFunctionStatement=function(e,t,r){return this.next(),this.parseFunction(e,Mt|(r?0:Vt),!1,t)},Lt.parseIfStatement=function(e){return this.next(),e.test=this.parseParenExpression(),e.consequent=this.parseStatement("if"),e.alternate=this.eat(ht._else)?this.parseStatement("if"):null,this.finishNode(e,"IfStatement")},Lt.parseReturnStatement=function(e){return this.inFunction||this.options.allowReturnOutsideFunction||this.raise(this.start,"'return' outside of function"),this.next(),this.eat(ht.semi)||this.insertSemicolon()?e.argument=null:(e.argument=this.parseExpression(),this.semicolon()),this.finishNode(e,"ReturnStatement")},Lt.parseSwitchStatement=function(e){var t;this.next(),e.discriminant=this.parseParenExpression(),e.cases=[],this.expect(ht.braceL),this.labels.push(Dt),this.enterScope(0);for(var r=!1;this.type!==ht.braceR;)if(this.type===ht._case||this.type===ht._default){var i=this.type===ht._case;t&&this.finishNode(t,"SwitchCase"),e.cases.push(t=this.startNode()),t.consequent=[],this.next(),i?t.test=this.parseExpression():(r&&this.raiseRecoverable(this.lastTokStart,"Multiple default clauses"),r=!0,t.test=null),this.expect(ht.colon)}else t||this.unexpected(),t.consequent.push(this.parseStatement(null));return this.exitScope(),t&&this.finishNode(t,"SwitchCase"),this.next(),this.labels.pop(),this.finishNode(e,"SwitchStatement")},Lt.parseThrowStatement=function(e){return this.next(),lt.test(this.input.slice(this.lastTokEnd,this.start))&&this.raise(this.lastTokEnd,"Illegal newline after throw"),e.argument=this.parseExpression(),this.semicolon(),this.finishNode(e,"ThrowStatement")};var Ft=[];Lt.parseTryStatement=function(e){if(this.next(),e.block=this.parseBlock(),e.handler=null,this.type===ht._catch){var t=this.startNode();if(this.next(),this.eat(ht.parenL)){t.param=this.parseBindingAtom();var r="Identifier"===t.param.type;this.enterScope(r?32:0),this.checkLVal(t.param,r?4:2),this.expect(ht.parenR)}else this.options.ecmaVersion<10&&this.unexpected(),t.param=null,this.enterScope(0);t.body=this.parseBlock(!1),this.exitScope(),e.handler=this.finishNode(t,"CatchClause")}return e.finalizer=this.eat(ht._finally)?this.parseBlock():null,e.handler||e.finalizer||this.raise(e.start,"Missing catch or finally clause"),this.finishNode(e,"TryStatement")},Lt.parseVarStatement=function(e,t){return this.next(),this.parseVar(e,!1,t),this.semicolon(),this.finishNode(e,"VariableDeclaration")},Lt.parseWhileStatement=function(e){return this.next(),e.test=this.parseParenExpression(),this.labels.push(Rt),e.body=this.parseStatement("while"),this.labels.pop(),this.finishNode(e,"WhileStatement")},Lt.parseWithStatement=function(e){return this.strict&&this.raise(this.start,"'with' in strict mode"),this.next(),e.object=this.parseParenExpression(),e.body=this.parseStatement("with"),this.finishNode(e,"WithStatement")},Lt.parseEmptyStatement=function(e){return this.next(),this.finishNode(e,"EmptyStatement")},Lt.parseLabeledStatement=function(e,t,r,i){for(var n=0,s=this.labels;n<s.length;n+=1){s[n].name===t&&this.raise(r.start,"Label '"+t+"' is already declared")}for(var a=this.type.isLoop?"loop":this.type===ht._switch?"switch":null,o=this.labels.length-1;o>=0;o--){var u=this.labels[o];if(u.statementStart!==e.start)break;u.statementStart=this.start,u.kind=a}return this.labels.push({name:t,kind:a,statementStart:this.start}),e.body=this.parseStatement(i?-1===i.indexOf("label")?i+"label":i:"label"),this.labels.pop(),e.label=r,this.finishNode(e,"LabeledStatement")},Lt.parseExpressionStatement=function(e,t){return e.expression=t,this.semicolon(),this.finishNode(e,"ExpressionStatement")},Lt.parseBlock=function(e,t,r){for(void 0===e&&(e=!0),void 0===t&&(t=this.startNode()),t.body=[],this.expect(ht.braceL),e&&this.enterScope(0);this.type!==ht.braceR;){var i=this.parseStatement(null);t.body.push(i)}return r&&(this.strict=!1),this.next(),e&&this.exitScope(),this.finishNode(t,"BlockStatement")},Lt.parseFor=function(e,t){return e.init=t,this.expect(ht.semi),e.test=this.type===ht.semi?null:this.parseExpression(),this.expect(ht.semi),e.update=this.type===ht.parenR?null:this.parseExpression(),this.expect(ht.parenR),e.body=this.parseStatement("for"),this.exitScope(),this.labels.pop(),this.finishNode(e,"ForStatement")},Lt.parseForIn=function(e,t){var r=this.type===ht._in;return this.next(),"VariableDeclaration"===t.type&&null!=t.declarations[0].init&&(!r||this.options.ecmaVersion<8||this.strict||"var"!==t.kind||"Identifier"!==t.declarations[0].id.type)?this.raise(t.start,(r?"for-in":"for-of")+" loop variable declaration may not have an initializer"):"AssignmentPattern"===t.type&&this.raise(t.start,"Invalid left-hand side in for-loop"),e.left=t,e.right=r?this.parseExpression():this.parseMaybeAssign(),this.expect(ht.parenR),e.body=this.parseStatement("for"),this.exitScope(),this.labels.pop(),this.finishNode(e,r?"ForInStatement":"ForOfStatement")},Lt.parseVar=function(e,t,r){for(e.declarations=[],e.kind=r;;){var i=this.startNode();if(this.parseVarId(i,r),this.eat(ht.eq)?i.init=this.parseMaybeAssign(t):"const"!==r||this.type===ht._in||this.options.ecmaVersion>=6&&this.isContextual("of")?"Identifier"===i.id.type||t&&(this.type===ht._in||this.isContextual("of"))?i.init=null:this.raise(this.lastTokEnd,"Complex binding patterns require an initialization value"):this.unexpected(),e.declarations.push(this.finishNode(i,"VariableDeclarator")),!this.eat(ht.comma))break}return e},Lt.parseVarId=function(e,t){e.id=this.parseBindingAtom(),this.checkLVal(e.id,"var"===t?1:2,!1)};var Mt=1,Vt=2;Lt.parseFunction=function(e,t,r,i){this.initFunction(e),(this.options.ecmaVersion>=9||this.options.ecmaVersion>=6&&!i)&&(this.type===ht.star&&t&Vt&&this.unexpected(),e.generator=this.eat(ht.star)),this.options.ecmaVersion>=8&&(e.async=!!i),t&Mt&&(e.id=4&t&&this.type!==ht.name?null:this.parseIdent(),!e.id||t&Vt||this.checkLVal(e.id,this.strict||e.generator||e.async?this.treatFunctionsAsVar?1:2:3));var n=this.yieldPos,s=this.awaitPos,a=this.awaitIdentPos;return this.yieldPos=0,this.awaitPos=0,this.awaitIdentPos=0,this.enterScope(It(e.async,e.generator)),t&Mt||(e.id=this.type===ht.name?this.parseIdent():null),this.parseFunctionParams(e),this.parseFunctionBody(e,r,!1),this.yieldPos=n,this.awaitPos=s,this.awaitIdentPos=a,this.finishNode(e,t&Mt?"FunctionDeclaration":"FunctionExpression")},Lt.parseFunctionParams=function(e){this.expect(ht.parenL),e.params=this.parseBindingList(ht.parenR,!1,this.options.ecmaVersion>=8),this.checkYieldAwaitInDefaultParams()},Lt.parseClass=function(e,t){this.next();var r=this.strict;this.strict=!0,this.parseClassId(e,t),this.parseClassSuper(e);var i=this.startNode(),n=!1;for(i.body=[],this.expect(ht.braceL);this.type!==ht.braceR;){var s=this.parseClassElement(null!==e.superClass);s&&(i.body.push(s),"MethodDefinition"===s.type&&"constructor"===s.kind&&(n&&this.raise(s.start,"Duplicate constructor in the same class"),n=!0))}return this.strict=r,this.next(),e.body=this.finishNode(i,"ClassBody"),this.finishNode(e,t?"ClassDeclaration":"ClassExpression")},Lt.parseClassElement=function(e){var t=this;if(this.eat(ht.semi))return null;var r=this.startNode(),i=function(e,i){void 0===i&&(i=!1);var n=t.start,s=t.startLoc;return!!t.eatContextual(e)&&(!(t.type===ht.parenL||i&&t.canInsertSemicolon())||(r.key&&t.unexpected(),r.computed=!1,r.key=t.startNodeAt(n,s),r.key.name=e,t.finishNode(r.key,"Identifier"),!1))};r.kind="method",r.static=i("static");var n=this.eat(ht.star),s=!1;n||(this.options.ecmaVersion>=8&&i("async",!0)?(s=!0,n=this.options.ecmaVersion>=9&&this.eat(ht.star)):i("get")?r.kind="get":i("set")&&(r.kind="set")),r.key||this.parsePropertyName(r);var a=r.key,o=!1;return r.computed||r.static||!("Identifier"===a.type&&"constructor"===a.name||"Literal"===a.type&&"constructor"===a.value)?r.static&&"Identifier"===a.type&&"prototype"===a.name&&this.raise(a.start,"Classes may not have a static property named prototype"):("method"!==r.kind&&this.raise(a.start,"Constructor can't have get/set modifier"),n&&this.raise(a.start,"Constructor can't be a generator"),s&&this.raise(a.start,"Constructor can't be an async method"),r.kind="constructor",o=e),this.parseClassMethod(r,n,s,o),"get"===r.kind&&0!==r.value.params.length&&this.raiseRecoverable(r.value.start,"getter should have no params"),"set"===r.kind&&1!==r.value.params.length&&this.raiseRecoverable(r.value.start,"setter should have exactly one param"),"set"===r.kind&&"RestElement"===r.value.params[0].type&&this.raiseRecoverable(r.value.params[0].start,"Setter cannot use rest params"),r},Lt.parseClassMethod=function(e,t,r,i){return e.value=this.parseMethod(t,r,i),this.finishNode(e,"MethodDefinition")},Lt.parseClassId=function(e,t){this.type===ht.name?(e.id=this.parseIdent(),t&&this.checkLVal(e.id,2,!1)):(!0===t&&this.unexpected(),e.id=null)},Lt.parseClassSuper=function(e){e.superClass=this.eat(ht._extends)?this.parseExprSubscripts():null},Lt.parseExport=function(e,t){if(this.next(),this.eat(ht.star))return this.options.ecmaVersion>=11&&(this.eatContextual("as")?(e.exported=this.parseIdent(!0),this.checkExport(t,e.exported.name,this.lastTokStart)):e.exported=null),this.expectContextual("from"),this.type!==ht.string&&this.unexpected(),e.source=this.parseExprAtom(),this.semicolon(),this.finishNode(e,"ExportAllDeclaration");if(this.eat(ht._default)){var r;if(this.checkExport(t,"default",this.lastTokStart),this.type===ht._function||(r=this.isAsyncFunction())){var i=this.startNode();this.next(),r&&this.next(),e.declaration=this.parseFunction(i,4|Mt,!1,r)}else if(this.type===ht._class){var n=this.startNode();e.declaration=this.parseClass(n,"nullableID")}else e.declaration=this.parseMaybeAssign(),this.semicolon();return this.finishNode(e,"ExportDefaultDeclaration")}if(this.shouldParseExportStatement())e.declaration=this.parseStatement(null),"VariableDeclaration"===e.declaration.type?this.checkVariableExport(t,e.declaration.declarations):this.checkExport(t,e.declaration.id.name,e.declaration.id.start),e.specifiers=[],e.source=null;else{if(e.declaration=null,e.specifiers=this.parseExportSpecifiers(t),this.eatContextual("from"))this.type!==ht.string&&this.unexpected(),e.source=this.parseExprAtom();else{for(var s=0,a=e.specifiers;s<a.length;s+=1){var o=a[s];this.checkUnreserved(o.local),this.checkLocalExport(o.local)}e.source=null}this.semicolon()}return this.finishNode(e,"ExportNamedDeclaration")},Lt.checkExport=function(e,t,r){e&&(yt(e,t)&&this.raiseRecoverable(r,"Duplicate export '"+t+"'"),e[t]=!0)},Lt.checkPatternExport=function(e,t){var r=t.type;if("Identifier"===r)this.checkExport(e,t.name,t.start);else if("ObjectPattern"===r)for(var i=0,n=t.properties;i<n.length;i+=1){var s=n[i];this.checkPatternExport(e,s)}else if("ArrayPattern"===r)for(var a=0,o=t.elements;a<o.length;a+=1){var u=o[a];u&&this.checkPatternExport(e,u)}else"Property"===r?this.checkPatternExport(e,t.value):"AssignmentPattern"===r?this.checkPatternExport(e,t.left):"RestElement"===r?this.checkPatternExport(e,t.argument):"ParenthesizedExpression"===r&&this.checkPatternExport(e,t.expression)},Lt.checkVariableExport=function(e,t){if(e)for(var r=0,i=t;r<i.length;r+=1){var n=i[r];this.checkPatternExport(e,n.id)}},Lt.shouldParseExportStatement=function(){return"var"===this.type.keyword||"const"===this.type.keyword||"class"===this.type.keyword||"function"===this.type.keyword||this.isLet()||this.isAsyncFunction()},Lt.parseExportSpecifiers=function(e){var t=[],r=!0;for(this.expect(ht.braceL);!this.eat(ht.braceR);){if(r)r=!1;else if(this.expect(ht.comma),this.afterTrailingComma(ht.braceR))break;var i=this.startNode();i.local=this.parseIdent(!0),i.exported=this.eatContextual("as")?this.parseIdent(!0):i.local,this.checkExport(e,i.exported.name,i.exported.start),t.push(this.finishNode(i,"ExportSpecifier"))}return t},Lt.parseImport=function(e){return this.next(),this.type===ht.string?(e.specifiers=Ft,e.source=this.parseExprAtom()):(e.specifiers=this.parseImportSpecifiers(),this.expectContextual("from"),e.source=this.type===ht.string?this.parseExprAtom():this.unexpected()),this.semicolon(),this.finishNode(e,"ImportDeclaration")},Lt.parseImportSpecifiers=function(){var e=[],t=!0;if(this.type===ht.name){var r=this.startNode();if(r.local=this.parseIdent(),this.checkLVal(r.local,2),e.push(this.finishNode(r,"ImportDefaultSpecifier")),!this.eat(ht.comma))return e}if(this.type===ht.star){var i=this.startNode();return this.next(),this.expectContextual("as"),i.local=this.parseIdent(),this.checkLVal(i.local,2),e.push(this.finishNode(i,"ImportNamespaceSpecifier")),e}for(this.expect(ht.braceL);!this.eat(ht.braceR);){if(t)t=!1;else if(this.expect(ht.comma),this.afterTrailingComma(ht.braceR))break;var n=this.startNode();n.imported=this.parseIdent(!0),this.eatContextual("as")?n.local=this.parseIdent():(this.checkUnreserved(n.imported),n.local=n.imported),this.checkLVal(n.local,2),e.push(this.finishNode(n,"ImportSpecifier"))}return e},Lt.adaptDirectivePrologue=function(e){for(var t=0;t<e.length&&this.isDirectiveCandidate(e[t]);++t)e[t].directive=e[t].expression.raw.slice(1,-1)},Lt.isDirectiveCandidate=function(e){return"ExpressionStatement"===e.type&&"Literal"===e.expression.type&&"string"==typeof e.expression.value&&('"'===this.input[e.start]||"'"===this.input[e.start])};var Bt=At.prototype;Bt.toAssignable=function(e,t,r){if(this.options.ecmaVersion>=6&&e)switch(e.type){case"Identifier":this.inAsync&&"await"===e.name&&this.raise(e.start,"Cannot use 'await' as identifier inside an async function");break;case"ObjectPattern":case"ArrayPattern":case"RestElement":break;case"ObjectExpression":e.type="ObjectPattern",r&&this.checkPatternErrors(r,!0);for(var i=0,n=e.properties;i<n.length;i+=1){var s=n[i];this.toAssignable(s,t),"RestElement"!==s.type||"ArrayPattern"!==s.argument.type&&"ObjectPattern"!==s.argument.type||this.raise(s.argument.start,"Unexpected token")}break;case"Property":"init"!==e.kind&&this.raise(e.key.start,"Object pattern can't contain getter or setter"),this.toAssignable(e.value,t);break;case"ArrayExpression":e.type="ArrayPattern",r&&this.checkPatternErrors(r,!0),this.toAssignableList(e.elements,t);break;case"SpreadElement":e.type="RestElement",this.toAssignable(e.argument,t),"AssignmentPattern"===e.argument.type&&this.raise(e.argument.start,"Rest elements cannot have a default value");break;case"AssignmentExpression":"="!==e.operator&&this.raise(e.left.end,"Only '=' operator can be used for specifying default value."),e.type="AssignmentPattern",delete e.operator,this.toAssignable(e.left,t);case"AssignmentPattern":break;case"ParenthesizedExpression":this.toAssignable(e.expression,t,r);break;case"ChainExpression":this.raiseRecoverable(e.start,"Optional chaining cannot appear in left-hand side");break;case"MemberExpression":if(!t)break;default:this.raise(e.start,"Assigning to rvalue")}else r&&this.checkPatternErrors(r,!0);return e},Bt.toAssignableList=function(e,t){for(var r=e.length,i=0;i<r;i++){var n=e[i];n&&this.toAssignable(n,t)}if(r){var s=e[r-1];6===this.options.ecmaVersion&&t&&s&&"RestElement"===s.type&&"Identifier"!==s.argument.type&&this.unexpected(s.argument.start)}return e},Bt.parseSpread=function(e){var t=this.startNode();return this.next(),t.argument=this.parseMaybeAssign(!1,e),this.finishNode(t,"SpreadElement")},Bt.parseRestBinding=function(){var e=this.startNode();return this.next(),6===this.options.ecmaVersion&&this.type!==ht.name&&this.unexpected(),e.argument=this.parseBindingAtom(),this.finishNode(e,"RestElement")},Bt.parseBindingAtom=function(){if(this.options.ecmaVersion>=6)switch(this.type){case ht.bracketL:var e=this.startNode();return this.next(),e.elements=this.parseBindingList(ht.bracketR,!0,!0),this.finishNode(e,"ArrayPattern");case ht.braceL:return this.parseObj(!0)}return this.parseIdent()},Bt.parseBindingList=function(e,t,r){for(var i=[],n=!0;!this.eat(e);)if(n?n=!1:this.expect(ht.comma),t&&this.type===ht.comma)i.push(null);else{if(r&&this.afterTrailingComma(e))break;if(this.type===ht.ellipsis){var s=this.parseRestBinding();this.parseBindingListItem(s),i.push(s),this.type===ht.comma&&this.raise(this.start,"Comma is not permitted after the rest element"),this.expect(e);break}var a=this.parseMaybeDefault(this.start,this.startLoc);this.parseBindingListItem(a),i.push(a)}return i},Bt.parseBindingListItem=function(e){return e},Bt.parseMaybeDefault=function(e,t,r){if(r=r||this.parseBindingAtom(),this.options.ecmaVersion<6||!this.eat(ht.eq))return r;var i=this.startNodeAt(e,t);return i.left=r,i.right=this.parseMaybeAssign(),this.finishNode(i,"AssignmentPattern")},Bt.checkLVal=function(e,t,r){switch(void 0===t&&(t=0),e.type){case"Identifier":2===t&&"let"===e.name&&this.raiseRecoverable(e.start,"let is disallowed as a lexically bound name"),this.strict&&this.reservedWordsStrictBind.test(e.name)&&this.raiseRecoverable(e.start,(t?"Binding ":"Assigning to ")+e.name+" in strict mode"),r&&(yt(r,e.name)&&this.raiseRecoverable(e.start,"Argument name clash"),r[e.name]=!0),0!==t&&5!==t&&this.declareName(e.name,t,e.start);break;case"ChainExpression":this.raiseRecoverable(e.start,"Optional chaining cannot appear in left-hand side");break;case"MemberExpression":t&&this.raiseRecoverable(e.start,"Binding member expression");break;case"ObjectPattern":for(var i=0,n=e.properties;i<n.length;i+=1){var s=n[i];this.checkLVal(s,t,r)}break;case"Property":this.checkLVal(e.value,t,r);break;case"ArrayPattern":for(var a=0,o=e.elements;a<o.length;a+=1){var u=o[a];u&&this.checkLVal(u,t,r)}break;case"AssignmentPattern":this.checkLVal(e.left,t,r);break;case"RestElement":this.checkLVal(e.argument,t,r);break;case"ParenthesizedExpression":this.checkLVal(e.expression,t,r);break;default:this.raise(e.start,(t?"Binding":"Assigning to")+" rvalue")}};var jt=At.prototype;jt.checkPropClash=function(e,t,r){if(!(this.options.ecmaVersion>=9&&"SpreadElement"===e.type||this.options.ecmaVersion>=6&&(e.computed||e.method||e.shorthand))){var i,n=e.key;switch(n.type){case"Identifier":i=n.name;break;case"Literal":i=String(n.value);break;default:return}var s=e.kind;if(this.options.ecmaVersion>=6)"__proto__"===i&&"init"===s&&(t.proto&&(r?r.doubleProto<0&&(r.doubleProto=n.start):this.raiseRecoverable(n.start,"Redefinition of __proto__ property")),t.proto=!0);else{var a=t[i="$"+i];if(a)("init"===s?this.strict&&a.init||a.get||a.set:a.init||a[s])&&this.raiseRecoverable(n.start,"Redefinition of property");else a=t[i]={init:!1,get:!1,set:!1};a[s]=!0}}},jt.parseExpression=function(e,t){var r=this.start,i=this.startLoc,n=this.parseMaybeAssign(e,t);if(this.type===ht.comma){var s=this.startNodeAt(r,i);for(s.expressions=[n];this.eat(ht.comma);)s.expressions.push(this.parseMaybeAssign(e,t));return this.finishNode(s,"SequenceExpression")}return n},jt.parseMaybeAssign=function(e,t,r){if(this.isContextual("yield")){if(this.inGenerator)return this.parseYield(e);this.exprAllowed=!1}var i=!1,n=-1,s=-1;t?(n=t.parenthesizedAssign,s=t.trailingComma,t.parenthesizedAssign=t.trailingComma=-1):(t=new Ot,i=!0);var a=this.start,o=this.startLoc;this.type!==ht.parenL&&this.type!==ht.name||(this.potentialArrowAt=this.start);var u=this.parseMaybeConditional(e,t);if(r&&(u=r.call(this,u,a,o)),this.type.isAssign){var c=this.startNodeAt(a,o);return c.operator=this.value,c.left=this.type===ht.eq?this.toAssignable(u,!1,t):u,i||(t.parenthesizedAssign=t.trailingComma=t.doubleProto=-1),t.shorthandAssign>=c.left.start&&(t.shorthandAssign=-1),this.checkLVal(u),this.next(),c.right=this.parseMaybeAssign(e),this.finishNode(c,"AssignmentExpression")}return i&&this.checkExpressionErrors(t,!0),n>-1&&(t.parenthesizedAssign=n),s>-1&&(t.trailingComma=s),u},jt.parseMaybeConditional=function(e,t){var r=this.start,i=this.startLoc,n=this.parseExprOps(e,t);if(this.checkExpressionErrors(t))return n;if(this.eat(ht.question)){var s=this.startNodeAt(r,i);return s.test=n,s.consequent=this.parseMaybeAssign(),this.expect(ht.colon),s.alternate=this.parseMaybeAssign(e),this.finishNode(s,"ConditionalExpression")}return n},jt.parseExprOps=function(e,t){var r=this.start,i=this.startLoc,n=this.parseMaybeUnary(t,!1);return this.checkExpressionErrors(t)||n.start===r&&"ArrowFunctionExpression"===n.type?n:this.parseExprOp(n,r,i,-1,e)},jt.parseExprOp=function(e,t,r,i,n){var s=this.type.binop;if(null!=s&&(!n||this.type!==ht._in)&&s>i){var a=this.type===ht.logicalOR||this.type===ht.logicalAND,o=this.type===ht.coalesce;o&&(s=ht.logicalAND.binop);var u=this.value;this.next();var c=this.start,h=this.startLoc,l=this.parseExprOp(this.parseMaybeUnary(null,!1),c,h,s,n),p=this.buildBinary(t,r,e,l,u,a||o);return(a&&this.type===ht.coalesce||o&&(this.type===ht.logicalOR||this.type===ht.logicalAND))&&this.raiseRecoverable(this.start,"Logical expressions and coalesce expressions cannot be mixed. Wrap either by parentheses"),this.parseExprOp(p,t,r,i,n)}return e},jt.buildBinary=function(e,t,r,i,n,s){var a=this.startNodeAt(e,t);return a.left=r,a.operator=n,a.right=i,this.finishNode(a,s?"LogicalExpression":"BinaryExpression")},jt.parseMaybeUnary=function(e,t){var r,i=this.start,n=this.startLoc;if(this.isContextual("await")&&(this.inAsync||!this.inFunction&&this.options.allowAwaitOutsideFunction))r=this.parseAwait(),t=!0;else if(this.type.prefix){var s=this.startNode(),a=this.type===ht.incDec;s.operator=this.value,s.prefix=!0,this.next(),s.argument=this.parseMaybeUnary(null,!0),this.checkExpressionErrors(e,!0),a?this.checkLVal(s.argument):this.strict&&"delete"===s.operator&&"Identifier"===s.argument.type?this.raiseRecoverable(s.start,"Deleting local variable in strict mode"):t=!0,r=this.finishNode(s,a?"UpdateExpression":"UnaryExpression")}else{if(r=this.parseExprSubscripts(e),this.checkExpressionErrors(e))return r;for(;this.type.postfix&&!this.canInsertSemicolon();){var o=this.startNodeAt(i,n);o.operator=this.value,o.prefix=!1,o.argument=r,this.checkLVal(r),this.next(),r=this.finishNode(o,"UpdateExpression")}}return!t&&this.eat(ht.starstar)?this.buildBinary(i,n,r,this.parseMaybeUnary(null,!1),"**",!1):r},jt.parseExprSubscripts=function(e){var t=this.start,r=this.startLoc,i=this.parseExprAtom(e);if("ArrowFunctionExpression"===i.type&&")"!==this.input.slice(this.lastTokStart,this.lastTokEnd))return i;var n=this.parseSubscripts(i,t,r);return e&&"MemberExpression"===n.type&&(e.parenthesizedAssign>=n.start&&(e.parenthesizedAssign=-1),e.parenthesizedBind>=n.start&&(e.parenthesizedBind=-1)),n},jt.parseSubscripts=function(e,t,r,i){for(var n=this.options.ecmaVersion>=8&&"Identifier"===e.type&&"async"===e.name&&this.lastTokEnd===e.end&&!this.canInsertSemicolon()&&e.end-e.start==5&&this.potentialArrowAt===e.start,s=!1;;){var a=this.parseSubscript(e,t,r,i,n,s);if(a.optional&&(s=!0),a===e||"ArrowFunctionExpression"===a.type){if(s){var o=this.startNodeAt(t,r);o.expression=a,a=this.finishNode(o,"ChainExpression")}return a}e=a}},jt.parseSubscript=function(e,t,r,i,n,s){var a=this.options.ecmaVersion>=11,o=a&&this.eat(ht.questionDot);i&&o&&this.raise(this.lastTokStart,"Optional chaining cannot appear in the callee of new expressions");var u=this.eat(ht.bracketL);if(u||o&&this.type!==ht.parenL&&this.type!==ht.backQuote||this.eat(ht.dot)){var c=this.startNodeAt(t,r);c.object=e,c.property=u?this.parseExpression():this.parseIdent("never"!==this.options.allowReserved),c.computed=!!u,u&&this.expect(ht.bracketR),a&&(c.optional=o),e=this.finishNode(c,"MemberExpression")}else if(!i&&this.eat(ht.parenL)){var h=new Ot,l=this.yieldPos,p=this.awaitPos,d=this.awaitIdentPos;this.yieldPos=0,this.awaitPos=0,this.awaitIdentPos=0;var f=this.parseExprList(ht.parenR,this.options.ecmaVersion>=8,!1,h);if(n&&!o&&!this.canInsertSemicolon()&&this.eat(ht.arrow))return this.checkPatternErrors(h,!1),this.checkYieldAwaitInDefaultParams(),this.awaitIdentPos>0&&this.raise(this.awaitIdentPos,"Cannot use 'await' as identifier inside an async function"),this.yieldPos=l,this.awaitPos=p,this.awaitIdentPos=d,this.parseArrowExpression(this.startNodeAt(t,r),f,!0);this.checkExpressionErrors(h,!0),this.yieldPos=l||this.yieldPos,this.awaitPos=p||this.awaitPos,this.awaitIdentPos=d||this.awaitIdentPos;var g=this.startNodeAt(t,r);g.callee=e,g.arguments=f,a&&(g.optional=o),e=this.finishNode(g,"CallExpression")}else if(this.type===ht.backQuote){(o||s)&&this.raise(this.start,"Optional chaining cannot appear in the tag of tagged template expressions");var m=this.startNodeAt(t,r);m.tag=e,m.quasi=this.parseTemplate({isTagged:!0}),e=this.finishNode(m,"TaggedTemplateExpression")}return e},jt.parseExprAtom=function(e){this.type===ht.slash&&this.readRegexp();var t,r=this.potentialArrowAt===this.start;switch(this.type){case ht._super:return this.allowSuper||this.raise(this.start,"'super' keyword outside a method"),t=this.startNode(),this.next(),this.type!==ht.parenL||this.allowDirectSuper||this.raise(t.start,"super() call outside constructor of a subclass"),this.type!==ht.dot&&this.type!==ht.bracketL&&this.type!==ht.parenL&&this.unexpected(),this.finishNode(t,"Super");case ht._this:return t=this.startNode(),this.next(),this.finishNode(t,"ThisExpression");case ht.name:var i=this.start,n=this.startLoc,s=this.containsEsc,a=this.parseIdent(!1);if(this.options.ecmaVersion>=8&&!s&&"async"===a.name&&!this.canInsertSemicolon()&&this.eat(ht._function))return this.parseFunction(this.startNodeAt(i,n),0,!1,!0);if(r&&!this.canInsertSemicolon()){if(this.eat(ht.arrow))return this.parseArrowExpression(this.startNodeAt(i,n),[a],!1);if(this.options.ecmaVersion>=8&&"async"===a.name&&this.type===ht.name&&!s)return a=this.parseIdent(!1),!this.canInsertSemicolon()&&this.eat(ht.arrow)||this.unexpected(),this.parseArrowExpression(this.startNodeAt(i,n),[a],!0)}return a;case ht.regexp:var o=this.value;return(t=this.parseLiteral(o.value)).regex={pattern:o.pattern,flags:o.flags},t;case ht.num:case ht.string:return this.parseLiteral(this.value);case ht._null:case ht._true:case ht._false:return(t=this.startNode()).value=this.type===ht._null?null:this.type===ht._true,t.raw=this.type.keyword,this.next(),this.finishNode(t,"Literal");case ht.parenL:var u=this.start,c=this.parseParenAndDistinguishExpression(r);return e&&(e.parenthesizedAssign<0&&!this.isSimpleAssignTarget(c)&&(e.parenthesizedAssign=u),e.parenthesizedBind<0&&(e.parenthesizedBind=u)),c;case ht.bracketL:return t=this.startNode(),this.next(),t.elements=this.parseExprList(ht.bracketR,!0,!0,e),this.finishNode(t,"ArrayExpression");case ht.braceL:return this.parseObj(!1,e);case ht._function:return t=this.startNode(),this.next(),this.parseFunction(t,0);case ht._class:return this.parseClass(this.startNode(),!1);case ht._new:return this.parseNew();case ht.backQuote:return this.parseTemplate();case ht._import:return this.options.ecmaVersion>=11?this.parseExprImport():this.unexpected();default:this.unexpected()}},jt.parseExprImport=function(){var e=this.startNode();this.containsEsc&&this.raiseRecoverable(this.start,"Escape sequence in keyword import");var t=this.parseIdent(!0);switch(this.type){case ht.parenL:return this.parseDynamicImport(e);case ht.dot:return e.meta=t,this.parseImportMeta(e);default:this.unexpected()}},jt.parseDynamicImport=function(e){if(this.next(),e.source=this.parseMaybeAssign(),!this.eat(ht.parenR)){var t=this.start;this.eat(ht.comma)&&this.eat(ht.parenR)?this.raiseRecoverable(t,"Trailing comma is not allowed in import()"):this.unexpected(t)}return this.finishNode(e,"ImportExpression")},jt.parseImportMeta=function(e){this.next();var t=this.containsEsc;return e.property=this.parseIdent(!0),"meta"!==e.property.name&&this.raiseRecoverable(e.property.start,"The only valid meta property for import is 'import.meta'"),t&&this.raiseRecoverable(e.start,"'import.meta' must not contain escaped characters"),"module"!==this.options.sourceType&&this.raiseRecoverable(e.start,"Cannot use 'import.meta' outside a module"),this.finishNode(e,"MetaProperty")},jt.parseLiteral=function(e){var t=this.startNode();return t.value=e,t.raw=this.input.slice(this.start,this.end),110===t.raw.charCodeAt(t.raw.length-1)&&(t.bigint=t.raw.slice(0,-1).replace(/_/g,"")),this.next(),this.finishNode(t,"Literal")},jt.parseParenExpression=function(){this.expect(ht.parenL);var e=this.parseExpression();return this.expect(ht.parenR),e},jt.parseParenAndDistinguishExpression=function(e){var t,r=this.start,i=this.startLoc,n=this.options.ecmaVersion>=8;if(this.options.ecmaVersion>=6){this.next();var s,a=this.start,o=this.startLoc,u=[],c=!0,h=!1,l=new Ot,p=this.yieldPos,d=this.awaitPos;for(this.yieldPos=0,this.awaitPos=0;this.type!==ht.parenR;){if(c?c=!1:this.expect(ht.comma),n&&this.afterTrailingComma(ht.parenR,!0)){h=!0;break}if(this.type===ht.ellipsis){s=this.start,u.push(this.parseParenItem(this.parseRestBinding())),this.type===ht.comma&&this.raise(this.start,"Comma is not permitted after the rest element");break}u.push(this.parseMaybeAssign(!1,l,this.parseParenItem))}var f=this.start,g=this.startLoc;if(this.expect(ht.parenR),e&&!this.canInsertSemicolon()&&this.eat(ht.arrow))return this.checkPatternErrors(l,!1),this.checkYieldAwaitInDefaultParams(),this.yieldPos=p,this.awaitPos=d,this.parseParenArrowList(r,i,u);u.length&&!h||this.unexpected(this.lastTokStart),s&&this.unexpected(s),this.checkExpressionErrors(l,!0),this.yieldPos=p||this.yieldPos,this.awaitPos=d||this.awaitPos,u.length>1?((t=this.startNodeAt(a,o)).expressions=u,this.finishNodeAt(t,"SequenceExpression",f,g)):t=u[0]}else t=this.parseParenExpression();if(this.options.preserveParens){var m=this.startNodeAt(r,i);return m.expression=t,this.finishNode(m,"ParenthesizedExpression")}return t},jt.parseParenItem=function(e){return e},jt.parseParenArrowList=function(e,t,r){return this.parseArrowExpression(this.startNodeAt(e,t),r)};var Ht=[];jt.parseNew=function(){this.containsEsc&&this.raiseRecoverable(this.start,"Escape sequence in keyword new");var e=this.startNode(),t=this.parseIdent(!0);if(this.options.ecmaVersion>=6&&this.eat(ht.dot)){e.meta=t;var r=this.containsEsc;return e.property=this.parseIdent(!0),"target"!==e.property.name&&this.raiseRecoverable(e.property.start,"The only valid meta property for new is 'new.target'"),r&&this.raiseRecoverable(e.start,"'new.target' must not contain escaped characters"),this.inNonArrowFunction()||this.raiseRecoverable(e.start,"'new.target' can only be used in functions"),this.finishNode(e,"MetaProperty")}var i=this.start,n=this.startLoc,s=this.type===ht._import;return e.callee=this.parseSubscripts(this.parseExprAtom(),i,n,!0),s&&"ImportExpression"===e.callee.type&&this.raise(i,"Cannot use new with import()"),this.eat(ht.parenL)?e.arguments=this.parseExprList(ht.parenR,this.options.ecmaVersion>=8,!1):e.arguments=Ht,this.finishNode(e,"NewExpression")},jt.parseTemplateElement=function(e){var t=e.isTagged,r=this.startNode();return this.type===ht.invalidTemplate?(t||this.raiseRecoverable(this.start,"Bad escape sequence in untagged template literal"),r.value={raw:this.value,cooked:null}):r.value={raw:this.input.slice(this.start,this.end).replace(/\r\n?/g,"\n"),cooked:this.value},this.next(),r.tail=this.type===ht.backQuote,this.finishNode(r,"TemplateElement")},jt.parseTemplate=function(e){void 0===e&&(e={});var t=e.isTagged;void 0===t&&(t=!1);var r=this.startNode();this.next(),r.expressions=[];var i=this.parseTemplateElement({isTagged:t});for(r.quasis=[i];!i.tail;)this.type===ht.eof&&this.raise(this.pos,"Unterminated template literal"),this.expect(ht.dollarBraceL),r.expressions.push(this.parseExpression()),this.expect(ht.braceR),r.quasis.push(i=this.parseTemplateElement({isTagged:t}));return this.next(),this.finishNode(r,"TemplateLiteral")},jt.isAsyncProp=function(e){return!e.computed&&"Identifier"===e.key.type&&"async"===e.key.name&&(this.type===ht.name||this.type===ht.num||this.type===ht.string||this.type===ht.bracketL||this.type.keyword||this.options.ecmaVersion>=9&&this.type===ht.star)&&!lt.test(this.input.slice(this.lastTokEnd,this.start))},jt.parseObj=function(e,t){var r=this.startNode(),i=!0,n={};for(r.properties=[],this.next();!this.eat(ht.braceR);){if(i)i=!1;else if(this.expect(ht.comma),this.options.ecmaVersion>=5&&this.afterTrailingComma(ht.braceR))break;var s=this.parseProperty(e,t);e||this.checkPropClash(s,n,t),r.properties.push(s)}return this.finishNode(r,e?"ObjectPattern":"ObjectExpression")},jt.parseProperty=function(e,t){var r,i,n,s,a=this.startNode();if(this.options.ecmaVersion>=9&&this.eat(ht.ellipsis))return e?(a.argument=this.parseIdent(!1),this.type===ht.comma&&this.raise(this.start,"Comma is not permitted after the rest element"),this.finishNode(a,"RestElement")):(this.type===ht.parenL&&t&&(t.parenthesizedAssign<0&&(t.parenthesizedAssign=this.start),t.parenthesizedBind<0&&(t.parenthesizedBind=this.start)),a.argument=this.parseMaybeAssign(!1,t),this.type===ht.comma&&t&&t.trailingComma<0&&(t.trailingComma=this.start),this.finishNode(a,"SpreadElement"));this.options.ecmaVersion>=6&&(a.method=!1,a.shorthand=!1,(e||t)&&(n=this.start,s=this.startLoc),e||(r=this.eat(ht.star)));var o=this.containsEsc;return this.parsePropertyName(a),!e&&!o&&this.options.ecmaVersion>=8&&!r&&this.isAsyncProp(a)?(i=!0,r=this.options.ecmaVersion>=9&&this.eat(ht.star),this.parsePropertyName(a,t)):i=!1,this.parsePropertyValue(a,e,r,i,n,s,t,o),this.finishNode(a,"Property")},jt.parsePropertyValue=function(e,t,r,i,n,s,a,o){if((r||i)&&this.type===ht.colon&&this.unexpected(),this.eat(ht.colon))e.value=t?this.parseMaybeDefault(this.start,this.startLoc):this.parseMaybeAssign(!1,a),e.kind="init";else if(this.options.ecmaVersion>=6&&this.type===ht.parenL)t&&this.unexpected(),e.kind="init",e.method=!0,e.value=this.parseMethod(r,i);else if(t||o||!(this.options.ecmaVersion>=5)||e.computed||"Identifier"!==e.key.type||"get"!==e.key.name&&"set"!==e.key.name||this.type===ht.comma||this.type===ht.braceR||this.type===ht.eq)this.options.ecmaVersion>=6&&!e.computed&&"Identifier"===e.key.type?((r||i)&&this.unexpected(),this.checkUnreserved(e.key),"await"!==e.key.name||this.awaitIdentPos||(this.awaitIdentPos=n),e.kind="init",t?e.value=this.parseMaybeDefault(n,s,e.key):this.type===ht.eq&&a?(a.shorthandAssign<0&&(a.shorthandAssign=this.start),e.value=this.parseMaybeDefault(n,s,e.key)):e.value=e.key,e.shorthand=!0):this.unexpected();else{(r||i)&&this.unexpected(),e.kind=e.key.name,this.parsePropertyName(e),e.value=this.parseMethod(!1);var u="get"===e.kind?0:1;if(e.value.params.length!==u){var c=e.value.start;"get"===e.kind?this.raiseRecoverable(c,"getter should have no params"):this.raiseRecoverable(c,"setter should have exactly one param")}else"set"===e.kind&&"RestElement"===e.value.params[0].type&&this.raiseRecoverable(e.value.params[0].start,"Setter cannot use rest params")}},jt.parsePropertyName=function(e){if(this.options.ecmaVersion>=6){if(this.eat(ht.bracketL))return e.computed=!0,e.key=this.parseMaybeAssign(),this.expect(ht.bracketR),e.key;e.computed=!1}return e.key=this.type===ht.num||this.type===ht.string?this.parseExprAtom():this.parseIdent("never"!==this.options.allowReserved)},jt.initFunction=function(e){e.id=null,this.options.ecmaVersion>=6&&(e.generator=e.expression=!1),this.options.ecmaVersion>=8&&(e.async=!1)},jt.parseMethod=function(e,t,r){var i=this.startNode(),n=this.yieldPos,s=this.awaitPos,a=this.awaitIdentPos;return this.initFunction(i),this.options.ecmaVersion>=6&&(i.generator=e),this.options.ecmaVersion>=8&&(i.async=!!t),this.yieldPos=0,this.awaitPos=0,this.awaitIdentPos=0,this.enterScope(64|It(t,i.generator)|(r?128:0)),this.expect(ht.parenL),i.params=this.parseBindingList(ht.parenR,!1,this.options.ecmaVersion>=8),this.checkYieldAwaitInDefaultParams(),this.parseFunctionBody(i,!1,!0),this.yieldPos=n,this.awaitPos=s,this.awaitIdentPos=a,this.finishNode(i,"FunctionExpression")},jt.parseArrowExpression=function(e,t,r){var i=this.yieldPos,n=this.awaitPos,s=this.awaitIdentPos;return this.enterScope(16|It(r,!1)),this.initFunction(e),this.options.ecmaVersion>=8&&(e.async=!!r),this.yieldPos=0,this.awaitPos=0,this.awaitIdentPos=0,e.params=this.toAssignableList(t,!0),this.parseFunctionBody(e,!0,!1),this.yieldPos=i,this.awaitPos=n,this.awaitIdentPos=s,this.finishNode(e,"ArrowFunctionExpression")},jt.parseFunctionBody=function(e,t,r){var i=t&&this.type!==ht.braceL,n=this.strict,s=!1;if(i)e.body=this.parseMaybeAssign(),e.expression=!0,this.checkParams(e,!1);else{var a=this.options.ecmaVersion>=7&&!this.isSimpleParamList(e.params);n&&!a||(s=this.strictDirective(this.end))&&a&&this.raiseRecoverable(e.start,"Illegal 'use strict' directive in function with non-simple parameter list");var o=this.labels;this.labels=[],s&&(this.strict=!0),this.checkParams(e,!n&&!s&&!t&&!r&&this.isSimpleParamList(e.params)),this.strict&&e.id&&this.checkLVal(e.id,5),e.body=this.parseBlock(!1,void 0,s&&!n),e.expression=!1,this.adaptDirectivePrologue(e.body.body),this.labels=o}this.exitScope()},jt.isSimpleParamList=function(e){for(var t=0,r=e;t<r.length;t+=1){if("Identifier"!==r[t].type)return!1}return!0},jt.checkParams=function(e,t){for(var r={},i=0,n=e.params;i<n.length;i+=1){var s=n[i];this.checkLVal(s,1,t?null:r)}},jt.parseExprList=function(e,t,r,i){for(var n=[],s=!0;!this.eat(e);){if(s)s=!1;else if(this.expect(ht.comma),t&&this.afterTrailingComma(e))break;var a=void 0;r&&this.type===ht.comma?a=null:this.type===ht.ellipsis?(a=this.parseSpread(i),i&&this.type===ht.comma&&i.trailingComma<0&&(i.trailingComma=this.start)):a=this.parseMaybeAssign(!1,i),n.push(a)}return n},jt.checkUnreserved=function(e){var t=e.start,r=e.end,i=e.name;(this.inGenerator&&"yield"===i&&this.raiseRecoverable(t,"Cannot use 'yield' as identifier inside a generator"),this.inAsync&&"await"===i&&this.raiseRecoverable(t,"Cannot use 'await' as identifier inside an async function"),this.keywords.test(i)&&this.raise(t,"Unexpected keyword '"+i+"'"),this.options.ecmaVersion<6&&-1!==this.input.slice(t,r).indexOf("\\"))||(this.strict?this.reservedWordsStrict:this.reservedWords).test(i)&&(this.inAsync||"await"!==i||this.raiseRecoverable(t,"Cannot use keyword 'await' outside an async function"),this.raiseRecoverable(t,"The keyword '"+i+"' is reserved"))},jt.parseIdent=function(e,t){var r=this.startNode();return this.type===ht.name?r.name=this.value:this.type.keyword?(r.name=this.type.keyword,"class"!==r.name&&"function"!==r.name||this.lastTokEnd===this.lastTokStart+1&&46===this.input.charCodeAt(this.lastTokStart)||this.context.pop()):this.unexpected(),this.next(!!e),this.finishNode(r,"Identifier"),e||(this.checkUnreserved(r),"await"!==r.name||this.awaitIdentPos||(this.awaitIdentPos=r.start)),r},jt.parseYield=function(e){this.yieldPos||(this.yieldPos=this.start);var t=this.startNode();return this.next(),this.type===ht.semi||this.canInsertSemicolon()||this.type!==ht.star&&!this.type.startsExpr?(t.delegate=!1,t.argument=null):(t.delegate=this.eat(ht.star),t.argument=this.parseMaybeAssign(e)),this.finishNode(t,"YieldExpression")},jt.parseAwait=function(){this.awaitPos||(this.awaitPos=this.start);var e=this.startNode();return this.next(),e.argument=this.parseMaybeUnary(null,!1),this.finishNode(e,"AwaitExpression")};var Ut=At.prototype;Ut.raise=function(e,t){var r=Ct(this.input,e);t+=" ("+r.line+":"+r.column+")";var i=new SyntaxError(t);throw i.pos=e,i.loc=r,i.raisedAt=this.pos,i},Ut.raiseRecoverable=Ut.raise,Ut.curPosition=function(){if(this.options.locations)return new _t(this.curLine,this.pos-this.lineStart)};var Gt=At.prototype,Wt=function(e){this.flags=e,this.var=[],this.lexical=[],this.functions=[]};Gt.enterScope=function(e){this.scopeStack.push(new Wt(e))},Gt.exitScope=function(){this.scopeStack.pop()},Gt.treatFunctionsAsVarInScope=function(e){return 2&e.flags||!this.inModule&&1&e.flags},Gt.declareName=function(e,t,r){var i=!1;if(2===t){var n=this.currentScope();i=n.lexical.indexOf(e)>-1||n.functions.indexOf(e)>-1||n.var.indexOf(e)>-1,n.lexical.push(e),this.inModule&&1&n.flags&&delete this.undefinedExports[e]}else if(4===t){this.currentScope().lexical.push(e)}else if(3===t){var s=this.currentScope();i=this.treatFunctionsAsVar?s.lexical.indexOf(e)>-1:s.lexical.indexOf(e)>-1||s.var.indexOf(e)>-1,s.functions.push(e)}else for(var a=this.scopeStack.length-1;a>=0;--a){var o=this.scopeStack[a];if(o.lexical.indexOf(e)>-1&&!(32&o.flags&&o.lexical[0]===e)||!this.treatFunctionsAsVarInScope(o)&&o.functions.indexOf(e)>-1){i=!0;break}if(o.var.push(e),this.inModule&&1&o.flags&&delete this.undefinedExports[e],3&o.flags)break}i&&this.raiseRecoverable(r,"Identifier '"+e+"' has already been declared")},Gt.checkLocalExport=function(e){-1===this.scopeStack[0].lexical.indexOf(e.name)&&-1===this.scopeStack[0].var.indexOf(e.name)&&(this.undefinedExports[e.name]=e)},Gt.currentScope=function(){return this.scopeStack[this.scopeStack.length-1]},Gt.currentVarScope=function(){for(var e=this.scopeStack.length-1;;e--){var t=this.scopeStack[e];if(3&t.flags)return t}},Gt.currentThisScope=function(){for(var e=this.scopeStack.length-1;;e--){var t=this.scopeStack[e];if(3&t.flags&&!(16&t.flags))return t}};var qt=function(e,t,r){this.type="",this.start=t,this.end=0,e.options.locations&&(this.loc=new wt(e,r)),e.options.directSourceFile&&(this.sourceFile=e.options.directSourceFile),e.options.ranges&&(this.range=[t,0])},$t=At.prototype;function zt(e,t,r,i){return e.type=t,e.end=r,this.options.locations&&(e.loc.end=i),this.options.ranges&&(e.range[1]=r),e}$t.startNode=function(){return new qt(this,this.start,this.startLoc)},$t.startNodeAt=function(e,t){return new qt(this,e,t)},$t.finishNode=function(e,t){return zt.call(this,e,t,this.lastTokEnd,this.lastTokEndLoc)},$t.finishNodeAt=function(e,t,r,i){return zt.call(this,e,t,r,i)};var Jt=function(e,t,r,i,n){this.token=e,this.isExpr=!!t,this.preserveSpace=!!r,this.override=i,this.generator=!!n},Kt={b_stat:new Jt("{",!1),b_expr:new Jt("{",!0),b_tmpl:new Jt("${",!1),p_stat:new Jt("(",!1),p_expr:new Jt("(",!0),q_tmpl:new Jt("`",!0,!0,(function(e){return e.tryReadTemplateToken()})),f_stat:new Jt("function",!1),f_expr:new Jt("function",!0),f_expr_gen:new Jt("function",!0,!1,null,!0),f_gen:new Jt("function",!1,!1,null,!0)},Qt=At.prototype;Qt.initialContext=function(){return[Kt.b_stat]},Qt.braceIsBlock=function(e){var t=this.curContext();return t===Kt.f_expr||t===Kt.f_stat||(e!==ht.colon||t!==Kt.b_stat&&t!==Kt.b_expr?e===ht._return||e===ht.name&&this.exprAllowed?lt.test(this.input.slice(this.lastTokEnd,this.start)):e===ht._else||e===ht.semi||e===ht.eof||e===ht.parenR||e===ht.arrow||(e===ht.braceL?t===Kt.b_stat:e!==ht._var&&e!==ht._const&&e!==ht.name&&!this.exprAllowed):!t.isExpr)},Qt.inGeneratorContext=function(){for(var e=this.context.length-1;e>=1;e--){var t=this.context[e];if("function"===t.token)return t.generator}return!1},Qt.updateContext=function(e){var t,r=this.type;r.keyword&&e===ht.dot?this.exprAllowed=!1:(t=r.updateContext)?t.call(this,e):this.exprAllowed=r.beforeExpr},ht.parenR.updateContext=ht.braceR.updateContext=function(){if(1!==this.context.length){var e=this.context.pop();e===Kt.b_stat&&"function"===this.curContext().token&&(e=this.context.pop()),this.exprAllowed=!e.isExpr}else this.exprAllowed=!0},ht.braceL.updateContext=function(e){this.context.push(this.braceIsBlock(e)?Kt.b_stat:Kt.b_expr),this.exprAllowed=!0},ht.dollarBraceL.updateContext=function(){this.context.push(Kt.b_tmpl),this.exprAllowed=!0},ht.parenL.updateContext=function(e){var t=e===ht._if||e===ht._for||e===ht._with||e===ht._while;this.context.push(t?Kt.p_stat:Kt.p_expr),this.exprAllowed=!0},ht.incDec.updateContext=function(){},ht._function.updateContext=ht._class.updateContext=function(e){!e.beforeExpr||e===ht.semi||e===ht._else||e===ht._return&&lt.test(this.input.slice(this.lastTokEnd,this.start))||(e===ht.colon||e===ht.braceL)&&this.curContext()===Kt.b_stat?this.context.push(Kt.f_stat):this.context.push(Kt.f_expr),this.exprAllowed=!1},ht.backQuote.updateContext=function(){this.curContext()===Kt.q_tmpl?this.context.pop():this.context.push(Kt.q_tmpl),this.exprAllowed=!1},ht.star.updateContext=function(e){if(e===ht._function){var t=this.context.length-1;this.context[t]===Kt.f_expr?this.context[t]=Kt.f_expr_gen:this.context[t]=Kt.f_gen}this.exprAllowed=!0},ht.name.updateContext=function(e){var t=!1;this.options.ecmaVersion>=6&&e!==ht.dot&&("of"===this.value&&!this.exprAllowed||"yield"===this.value&&this.inGeneratorContext())&&(t=!0),this.exprAllowed=t};var Xt="ASCII ASCII_Hex_Digit AHex Alphabetic Alpha Any Assigned Bidi_Control Bidi_C Bidi_Mirrored Bidi_M Case_Ignorable CI Cased Changes_When_Casefolded CWCF Changes_When_Casemapped CWCM Changes_When_Lowercased CWL Changes_When_NFKC_Casefolded CWKCF Changes_When_Titlecased CWT Changes_When_Uppercased CWU Dash Default_Ignorable_Code_Point DI Deprecated Dep Diacritic Dia Emoji Emoji_Component Emoji_Modifier Emoji_Modifier_Base Emoji_Presentation Extender Ext Grapheme_Base Gr_Base Grapheme_Extend Gr_Ext Hex_Digit Hex IDS_Binary_Operator IDSB IDS_Trinary_Operator IDST ID_Continue IDC ID_Start IDS Ideographic Ideo Join_Control Join_C Logical_Order_Exception LOE Lowercase Lower Math Noncharacter_Code_Point NChar Pattern_Syntax Pat_Syn Pattern_White_Space Pat_WS Quotation_Mark QMark Radical Regional_Indicator RI Sentence_Terminal STerm Soft_Dotted SD Terminal_Punctuation Term Unified_Ideograph UIdeo Uppercase Upper Variation_Selector VS White_Space space XID_Continue XIDC XID_Start XIDS",Yt=Xt+" Extended_Pictographic",Zt={9:Xt,10:Yt,11:Yt},er="Cased_Letter LC Close_Punctuation Pe Connector_Punctuation Pc Control Cc cntrl Currency_Symbol Sc Dash_Punctuation Pd Decimal_Number Nd digit Enclosing_Mark Me Final_Punctuation Pf Format Cf Initial_Punctuation Pi Letter L Letter_Number Nl Line_Separator Zl Lowercase_Letter Ll Mark M Combining_Mark Math_Symbol Sm Modifier_Letter Lm Modifier_Symbol Sk Nonspacing_Mark Mn Number N Open_Punctuation Ps Other C Other_Letter Lo Other_Number No Other_Punctuation Po Other_Symbol So Paragraph_Separator Zp Private_Use Co Punctuation P punct Separator Z Space_Separator Zs Spacing_Mark Mc Surrogate Cs Symbol S Titlecase_Letter Lt Unassigned Cn Uppercase_Letter Lu",tr="Adlam Adlm Ahom Ahom Anatolian_Hieroglyphs Hluw Arabic Arab Armenian Armn Avestan Avst Balinese Bali Bamum Bamu Bassa_Vah Bass Batak Batk Bengali Beng Bhaiksuki Bhks Bopomofo Bopo Brahmi Brah Braille Brai Buginese Bugi Buhid Buhd Canadian_Aboriginal Cans Carian Cari Caucasian_Albanian Aghb Chakma Cakm Cham Cham Cherokee Cher Common Zyyy Coptic Copt Qaac Cuneiform Xsux Cypriot Cprt Cyrillic Cyrl Deseret Dsrt Devanagari Deva Duployan Dupl Egyptian_Hieroglyphs Egyp Elbasan Elba Ethiopic Ethi Georgian Geor Glagolitic Glag Gothic Goth Grantha Gran Greek Grek Gujarati Gujr Gurmukhi Guru Han Hani Hangul Hang Hanunoo Hano Hatran Hatr Hebrew Hebr Hiragana Hira Imperial_Aramaic Armi Inherited Zinh Qaai Inscriptional_Pahlavi Phli Inscriptional_Parthian Prti Javanese Java Kaithi Kthi Kannada Knda Katakana Kana Kayah_Li Kali Kharoshthi Khar Khmer Khmr Khojki Khoj Khudawadi Sind Lao Laoo Latin Latn Lepcha Lepc Limbu Limb Linear_A Lina Linear_B Linb Lisu Lisu Lycian Lyci Lydian Lydi Mahajani Mahj Malayalam Mlym Mandaic Mand Manichaean Mani Marchen Marc Masaram_Gondi Gonm Meetei_Mayek Mtei Mende_Kikakui Mend Meroitic_Cursive Merc Meroitic_Hieroglyphs Mero Miao Plrd Modi Modi Mongolian Mong Mro Mroo Multani Mult Myanmar Mymr Nabataean Nbat New_Tai_Lue Talu Newa Newa Nko Nkoo Nushu Nshu Ogham Ogam Ol_Chiki Olck Old_Hungarian Hung Old_Italic Ital Old_North_Arabian Narb Old_Permic Perm Old_Persian Xpeo Old_South_Arabian Sarb Old_Turkic Orkh Oriya Orya Osage Osge Osmanya Osma Pahawh_Hmong Hmng Palmyrene Palm Pau_Cin_Hau Pauc Phags_Pa Phag Phoenician Phnx Psalter_Pahlavi Phlp Rejang Rjng Runic Runr Samaritan Samr Saurashtra Saur Sharada Shrd Shavian Shaw Siddham Sidd SignWriting Sgnw Sinhala Sinh Sora_Sompeng Sora Soyombo Soyo Sundanese Sund Syloti_Nagri Sylo Syriac Syrc Tagalog Tglg Tagbanwa Tagb Tai_Le Tale Tai_Tham Lana Tai_Viet Tavt Takri Takr Tamil Taml Tangut Tang Telugu Telu Thaana Thaa Thai Thai Tibetan Tibt Tifinagh Tfng Tirhuta Tirh Ugaritic Ugar Vai Vaii Warang_Citi Wara Yi Yiii Zanabazar_Square Zanb",rr=tr+" Dogra Dogr Gunjala_Gondi Gong Hanifi_Rohingya Rohg Makasar Maka Medefaidrin Medf Old_Sogdian Sogo Sogdian Sogd",ir={9:tr,10:rr,11:rr+" Elymaic Elym Nandinagari Nand Nyiakeng_Puachue_Hmong Hmnp Wancho Wcho"},nr={};function sr(e){var t=nr[e]={binary:St(Zt[e]+" "+er),nonBinary:{General_Category:St(er),Script:St(ir[e])}};t.nonBinary.Script_Extensions=t.nonBinary.Script,t.nonBinary.gc=t.nonBinary.General_Category,t.nonBinary.sc=t.nonBinary.Script,t.nonBinary.scx=t.nonBinary.Script_Extensions}sr(9),sr(10),sr(11);var ar=At.prototype,or=function(e){this.parser=e,this.validFlags="gim"+(e.options.ecmaVersion>=6?"uy":"")+(e.options.ecmaVersion>=9?"s":""),this.unicodeProperties=nr[e.options.ecmaVersion>=11?11:e.options.ecmaVersion],this.source="",this.flags="",this.start=0,this.switchU=!1,this.switchN=!1,this.pos=0,this.lastIntValue=0,this.lastStringValue="",this.lastAssertionIsQuantifiable=!1,this.numCapturingParens=0,this.maxBackReference=0,this.groupNames=[],this.backReferenceNames=[]};function ur(e){return e<=65535?String.fromCharCode(e):(e-=65536,String.fromCharCode(55296+(e>>10),56320+(1023&e)))}function cr(e){return 36===e||e>=40&&e<=43||46===e||63===e||e>=91&&e<=94||e>=123&&e<=125}function hr(e){return e>=65&&e<=90||e>=97&&e<=122}function lr(e){return hr(e)||95===e}function pr(e){return lr(e)||dr(e)}function dr(e){return e>=48&&e<=57}function fr(e){return e>=48&&e<=57||e>=65&&e<=70||e>=97&&e<=102}function gr(e){return e>=65&&e<=70?e-65+10:e>=97&&e<=102?e-97+10:e-48}function mr(e){return e>=48&&e<=55}or.prototype.reset=function(e,t,r){var i=-1!==r.indexOf("u");this.start=0|e,this.source=t+"",this.flags=r,this.switchU=i&&this.parser.options.ecmaVersion>=6,this.switchN=i&&this.parser.options.ecmaVersion>=9},or.prototype.raise=function(e){this.parser.raiseRecoverable(this.start,"Invalid regular expression: /"+this.source+"/: "+e)},or.prototype.at=function(e,t){void 0===t&&(t=!1);var r=this.source,i=r.length;if(e>=i)return-1;var n=r.charCodeAt(e);if(!t&&!this.switchU||n<=55295||n>=57344||e+1>=i)return n;var s=r.charCodeAt(e+1);return s>=56320&&s<=57343?(n<<10)+s-56613888:n},or.prototype.nextIndex=function(e,t){void 0===t&&(t=!1);var r=this.source,i=r.length;if(e>=i)return i;var n,s=r.charCodeAt(e);return!t&&!this.switchU||s<=55295||s>=57344||e+1>=i||(n=r.charCodeAt(e+1))<56320||n>57343?e+1:e+2},or.prototype.current=function(e){return void 0===e&&(e=!1),this.at(this.pos,e)},or.prototype.lookahead=function(e){return void 0===e&&(e=!1),this.at(this.nextIndex(this.pos,e),e)},or.prototype.advance=function(e){void 0===e&&(e=!1),this.pos=this.nextIndex(this.pos,e)},or.prototype.eat=function(e,t){return void 0===t&&(t=!1),this.current(t)===e&&(this.advance(t),!0)},ar.validateRegExpFlags=function(e){for(var t=e.validFlags,r=e.flags,i=0;i<r.length;i++){var n=r.charAt(i);-1===t.indexOf(n)&&this.raise(e.start,"Invalid regular expression flag"),r.indexOf(n,i+1)>-1&&this.raise(e.start,"Duplicate regular expression flag")}},ar.validateRegExpPattern=function(e){this.regexp_pattern(e),!e.switchN&&this.options.ecmaVersion>=9&&e.groupNames.length>0&&(e.switchN=!0,this.regexp_pattern(e))},ar.regexp_pattern=function(e){e.pos=0,e.lastIntValue=0,e.lastStringValue="",e.lastAssertionIsQuantifiable=!1,e.numCapturingParens=0,e.maxBackReference=0,e.groupNames.length=0,e.backReferenceNames.length=0,this.regexp_disjunction(e),e.pos!==e.source.length&&(e.eat(41)&&e.raise("Unmatched ')'"),(e.eat(93)||e.eat(125))&&e.raise("Lone quantifier brackets")),e.maxBackReference>e.numCapturingParens&&e.raise("Invalid escape");for(var t=0,r=e.backReferenceNames;t<r.length;t+=1){var i=r[t];-1===e.groupNames.indexOf(i)&&e.raise("Invalid named capture referenced")}},ar.regexp_disjunction=function(e){for(this.regexp_alternative(e);e.eat(124);)this.regexp_alternative(e);this.regexp_eatQuantifier(e,!0)&&e.raise("Nothing to repeat"),e.eat(123)&&e.raise("Lone quantifier brackets")},ar.regexp_alternative=function(e){for(;e.pos<e.source.length&&this.regexp_eatTerm(e););},ar.regexp_eatTerm=function(e){return this.regexp_eatAssertion(e)?(e.lastAssertionIsQuantifiable&&this.regexp_eatQuantifier(e)&&e.switchU&&e.raise("Invalid quantifier"),!0):!!(e.switchU?this.regexp_eatAtom(e):this.regexp_eatExtendedAtom(e))&&(this.regexp_eatQuantifier(e),!0)},ar.regexp_eatAssertion=function(e){var t=e.pos;if(e.lastAssertionIsQuantifiable=!1,e.eat(94)||e.eat(36))return!0;if(e.eat(92)){if(e.eat(66)||e.eat(98))return!0;e.pos=t}if(e.eat(40)&&e.eat(63)){var r=!1;if(this.options.ecmaVersion>=9&&(r=e.eat(60)),e.eat(61)||e.eat(33))return this.regexp_disjunction(e),e.eat(41)||e.raise("Unterminated group"),e.lastAssertionIsQuantifiable=!r,!0}return e.pos=t,!1},ar.regexp_eatQuantifier=function(e,t){return void 0===t&&(t=!1),!!this.regexp_eatQuantifierPrefix(e,t)&&(e.eat(63),!0)},ar.regexp_eatQuantifierPrefix=function(e,t){return e.eat(42)||e.eat(43)||e.eat(63)||this.regexp_eatBracedQuantifier(e,t)},ar.regexp_eatBracedQuantifier=function(e,t){var r=e.pos;if(e.eat(123)){var i=0,n=-1;if(this.regexp_eatDecimalDigits(e)&&(i=e.lastIntValue,e.eat(44)&&this.regexp_eatDecimalDigits(e)&&(n=e.lastIntValue),e.eat(125)))return-1!==n&&n<i&&!t&&e.raise("numbers out of order in {} quantifier"),!0;e.switchU&&!t&&e.raise("Incomplete quantifier"),e.pos=r}return!1},ar.regexp_eatAtom=function(e){return this.regexp_eatPatternCharacters(e)||e.eat(46)||this.regexp_eatReverseSolidusAtomEscape(e)||this.regexp_eatCharacterClass(e)||this.regexp_eatUncapturingGroup(e)||this.regexp_eatCapturingGroup(e)},ar.regexp_eatReverseSolidusAtomEscape=function(e){var t=e.pos;if(e.eat(92)){if(this.regexp_eatAtomEscape(e))return!0;e.pos=t}return!1},ar.regexp_eatUncapturingGroup=function(e){var t=e.pos;if(e.eat(40)){if(e.eat(63)&&e.eat(58)){if(this.regexp_disjunction(e),e.eat(41))return!0;e.raise("Unterminated group")}e.pos=t}return!1},ar.regexp_eatCapturingGroup=function(e){if(e.eat(40)){if(this.options.ecmaVersion>=9?this.regexp_groupSpecifier(e):63===e.current()&&e.raise("Invalid group"),this.regexp_disjunction(e),e.eat(41))return e.numCapturingParens+=1,!0;e.raise("Unterminated group")}return!1},ar.regexp_eatExtendedAtom=function(e){return e.eat(46)||this.regexp_eatReverseSolidusAtomEscape(e)||this.regexp_eatCharacterClass(e)||this.regexp_eatUncapturingGroup(e)||this.regexp_eatCapturingGroup(e)||this.regexp_eatInvalidBracedQuantifier(e)||this.regexp_eatExtendedPatternCharacter(e)},ar.regexp_eatInvalidBracedQuantifier=function(e){return this.regexp_eatBracedQuantifier(e,!0)&&e.raise("Nothing to repeat"),!1},ar.regexp_eatSyntaxCharacter=function(e){var t=e.current();return!!cr(t)&&(e.lastIntValue=t,e.advance(),!0)},ar.regexp_eatPatternCharacters=function(e){for(var t=e.pos,r=0;-1!==(r=e.current())&&!cr(r);)e.advance();return e.pos!==t},ar.regexp_eatExtendedPatternCharacter=function(e){var t=e.current();return!(-1===t||36===t||t>=40&&t<=43||46===t||63===t||91===t||94===t||124===t)&&(e.advance(),!0)},ar.regexp_groupSpecifier=function(e){if(e.eat(63)){if(this.regexp_eatGroupName(e))return-1!==e.groupNames.indexOf(e.lastStringValue)&&e.raise("Duplicate capture group name"),void e.groupNames.push(e.lastStringValue);e.raise("Invalid group")}},ar.regexp_eatGroupName=function(e){if(e.lastStringValue="",e.eat(60)){if(this.regexp_eatRegExpIdentifierName(e)&&e.eat(62))return!0;e.raise("Invalid capture group name")}return!1},ar.regexp_eatRegExpIdentifierName=function(e){if(e.lastStringValue="",this.regexp_eatRegExpIdentifierStart(e)){for(e.lastStringValue+=ur(e.lastIntValue);this.regexp_eatRegExpIdentifierPart(e);)e.lastStringValue+=ur(e.lastIntValue);return!0}return!1},ar.regexp_eatRegExpIdentifierStart=function(e){var t=e.pos,r=this.options.ecmaVersion>=11,i=e.current(r);return e.advance(r),92===i&&this.regexp_eatRegExpUnicodeEscapeSequence(e,r)&&(i=e.lastIntValue),function(e){return rt(e,!0)||36===e||95===e}(i)?(e.lastIntValue=i,!0):(e.pos=t,!1)},ar.regexp_eatRegExpIdentifierPart=function(e){var t=e.pos,r=this.options.ecmaVersion>=11,i=e.current(r);return e.advance(r),92===i&&this.regexp_eatRegExpUnicodeEscapeSequence(e,r)&&(i=e.lastIntValue),function(e){return it(e,!0)||36===e||95===e||8204===e||8205===e}(i)?(e.lastIntValue=i,!0):(e.pos=t,!1)},ar.regexp_eatAtomEscape=function(e){return!!(this.regexp_eatBackReference(e)||this.regexp_eatCharacterClassEscape(e)||this.regexp_eatCharacterEscape(e)||e.switchN&&this.regexp_eatKGroupName(e))||(e.switchU&&(99===e.current()&&e.raise("Invalid unicode escape"),e.raise("Invalid escape")),!1)},ar.regexp_eatBackReference=function(e){var t=e.pos;if(this.regexp_eatDecimalEscape(e)){var r=e.lastIntValue;if(e.switchU)return r>e.maxBackReference&&(e.maxBackReference=r),!0;if(r<=e.numCapturingParens)return!0;e.pos=t}return!1},ar.regexp_eatKGroupName=function(e){if(e.eat(107)){if(this.regexp_eatGroupName(e))return e.backReferenceNames.push(e.lastStringValue),!0;e.raise("Invalid named reference")}return!1},ar.regexp_eatCharacterEscape=function(e){return this.regexp_eatControlEscape(e)||this.regexp_eatCControlLetter(e)||this.regexp_eatZero(e)||this.regexp_eatHexEscapeSequence(e)||this.regexp_eatRegExpUnicodeEscapeSequence(e,!1)||!e.switchU&&this.regexp_eatLegacyOctalEscapeSequence(e)||this.regexp_eatIdentityEscape(e)},ar.regexp_eatCControlLetter=function(e){var t=e.pos;if(e.eat(99)){if(this.regexp_eatControlLetter(e))return!0;e.pos=t}return!1},ar.regexp_eatZero=function(e){return 48===e.current()&&!dr(e.lookahead())&&(e.lastIntValue=0,e.advance(),!0)},ar.regexp_eatControlEscape=function(e){var t=e.current();return 116===t?(e.lastIntValue=9,e.advance(),!0):110===t?(e.lastIntValue=10,e.advance(),!0):118===t?(e.lastIntValue=11,e.advance(),!0):102===t?(e.lastIntValue=12,e.advance(),!0):114===t&&(e.lastIntValue=13,e.advance(),!0)},ar.regexp_eatControlLetter=function(e){var t=e.current();return!!hr(t)&&(e.lastIntValue=t%32,e.advance(),!0)},ar.regexp_eatRegExpUnicodeEscapeSequence=function(e,t){void 0===t&&(t=!1);var r,i=e.pos,n=t||e.switchU;if(e.eat(117)){if(this.regexp_eatFixedHexDigits(e,4)){var s=e.lastIntValue;if(n&&s>=55296&&s<=56319){var a=e.pos;if(e.eat(92)&&e.eat(117)&&this.regexp_eatFixedHexDigits(e,4)){var o=e.lastIntValue;if(o>=56320&&o<=57343)return e.lastIntValue=1024*(s-55296)+(o-56320)+65536,!0}e.pos=a,e.lastIntValue=s}return!0}if(n&&e.eat(123)&&this.regexp_eatHexDigits(e)&&e.eat(125)&&((r=e.lastIntValue)>=0&&r<=1114111))return!0;n&&e.raise("Invalid unicode escape"),e.pos=i}return!1},ar.regexp_eatIdentityEscape=function(e){if(e.switchU)return!!this.regexp_eatSyntaxCharacter(e)||!!e.eat(47)&&(e.lastIntValue=47,!0);var t=e.current();return!(99===t||e.switchN&&107===t)&&(e.lastIntValue=t,e.advance(),!0)},ar.regexp_eatDecimalEscape=function(e){e.lastIntValue=0;var t=e.current();if(t>=49&&t<=57){do{e.lastIntValue=10*e.lastIntValue+(t-48),e.advance()}while((t=e.current())>=48&&t<=57);return!0}return!1},ar.regexp_eatCharacterClassEscape=function(e){var t=e.current();if(function(e){return 100===e||68===e||115===e||83===e||119===e||87===e}(t))return e.lastIntValue=-1,e.advance(),!0;if(e.switchU&&this.options.ecmaVersion>=9&&(80===t||112===t)){if(e.lastIntValue=-1,e.advance(),e.eat(123)&&this.regexp_eatUnicodePropertyValueExpression(e)&&e.eat(125))return!0;e.raise("Invalid property name")}return!1},ar.regexp_eatUnicodePropertyValueExpression=function(e){var t=e.pos;if(this.regexp_eatUnicodePropertyName(e)&&e.eat(61)){var r=e.lastStringValue;if(this.regexp_eatUnicodePropertyValue(e)){var i=e.lastStringValue;return this.regexp_validateUnicodePropertyNameAndValue(e,r,i),!0}}if(e.pos=t,this.regexp_eatLoneUnicodePropertyNameOrValue(e)){var n=e.lastStringValue;return this.regexp_validateUnicodePropertyNameOrValue(e,n),!0}return!1},ar.regexp_validateUnicodePropertyNameAndValue=function(e,t,r){yt(e.unicodeProperties.nonBinary,t)||e.raise("Invalid property name"),e.unicodeProperties.nonBinary[t].test(r)||e.raise("Invalid property value")},ar.regexp_validateUnicodePropertyNameOrValue=function(e,t){e.unicodeProperties.binary.test(t)||e.raise("Invalid property name")},ar.regexp_eatUnicodePropertyName=function(e){var t=0;for(e.lastStringValue="";lr(t=e.current());)e.lastStringValue+=ur(t),e.advance();return""!==e.lastStringValue},ar.regexp_eatUnicodePropertyValue=function(e){var t=0;for(e.lastStringValue="";pr(t=e.current());)e.lastStringValue+=ur(t),e.advance();return""!==e.lastStringValue},ar.regexp_eatLoneUnicodePropertyNameOrValue=function(e){return this.regexp_eatUnicodePropertyValue(e)},ar.regexp_eatCharacterClass=function(e){if(e.eat(91)){if(e.eat(94),this.regexp_classRanges(e),e.eat(93))return!0;e.raise("Unterminated character class")}return!1},ar.regexp_classRanges=function(e){for(;this.regexp_eatClassAtom(e);){var t=e.lastIntValue;if(e.eat(45)&&this.regexp_eatClassAtom(e)){var r=e.lastIntValue;!e.switchU||-1!==t&&-1!==r||e.raise("Invalid character class"),-1!==t&&-1!==r&&t>r&&e.raise("Range out of order in character class")}}},ar.regexp_eatClassAtom=function(e){var t=e.pos;if(e.eat(92)){if(this.regexp_eatClassEscape(e))return!0;if(e.switchU){var r=e.current();(99===r||mr(r))&&e.raise("Invalid class escape"),e.raise("Invalid escape")}e.pos=t}var i=e.current();return 93!==i&&(e.lastIntValue=i,e.advance(),!0)},ar.regexp_eatClassEscape=function(e){var t=e.pos;if(e.eat(98))return e.lastIntValue=8,!0;if(e.switchU&&e.eat(45))return e.lastIntValue=45,!0;if(!e.switchU&&e.eat(99)){if(this.regexp_eatClassControlLetter(e))return!0;e.pos=t}return this.regexp_eatCharacterClassEscape(e)||this.regexp_eatCharacterEscape(e)},ar.regexp_eatClassControlLetter=function(e){var t=e.current();return!(!dr(t)&&95!==t)&&(e.lastIntValue=t%32,e.advance(),!0)},ar.regexp_eatHexEscapeSequence=function(e){var t=e.pos;if(e.eat(120)){if(this.regexp_eatFixedHexDigits(e,2))return!0;e.switchU&&e.raise("Invalid escape"),e.pos=t}return!1},ar.regexp_eatDecimalDigits=function(e){var t=e.pos,r=0;for(e.lastIntValue=0;dr(r=e.current());)e.lastIntValue=10*e.lastIntValue+(r-48),e.advance();return e.pos!==t},ar.regexp_eatHexDigits=function(e){var t=e.pos,r=0;for(e.lastIntValue=0;fr(r=e.current());)e.lastIntValue=16*e.lastIntValue+gr(r),e.advance();return e.pos!==t},ar.regexp_eatLegacyOctalEscapeSequence=function(e){if(this.regexp_eatOctalDigit(e)){var t=e.lastIntValue;if(this.regexp_eatOctalDigit(e)){var r=e.lastIntValue;t<=3&&this.regexp_eatOctalDigit(e)?e.lastIntValue=64*t+8*r+e.lastIntValue:e.lastIntValue=8*t+r}else e.lastIntValue=t;return!0}return!1},ar.regexp_eatOctalDigit=function(e){var t=e.current();return mr(t)?(e.lastIntValue=t-48,e.advance(),!0):(e.lastIntValue=0,!1)},ar.regexp_eatFixedHexDigits=function(e,t){var r=e.pos;e.lastIntValue=0;for(var i=0;i<t;++i){var n=e.current();if(!fr(n))return e.pos=r,!1;e.lastIntValue=16*e.lastIntValue+gr(n),e.advance()}return!0};var vr=function(e){this.type=e.type,this.value=e.value,this.start=e.start,this.end=e.end,e.options.locations&&(this.loc=new wt(e,e.startLoc,e.endLoc)),e.options.ranges&&(this.range=[e.start,e.end])},br=At.prototype;function yr(e){return"function"!=typeof BigInt?null:BigInt(e.replace(/_/g,""))}function xr(e){return e<=65535?String.fromCharCode(e):(e-=65536,String.fromCharCode(55296+(e>>10),56320+(1023&e)))}br.next=function(e){!e&&this.type.keyword&&this.containsEsc&&this.raiseRecoverable(this.start,"Escape sequence in keyword "+this.type.keyword),this.options.onToken&&this.options.onToken(new vr(this)),this.lastTokEnd=this.end,this.lastTokStart=this.start,this.lastTokEndLoc=this.endLoc,this.lastTokStartLoc=this.startLoc,this.nextToken()},br.getToken=function(){return this.next(),new vr(this)},"undefined"!=typeof Symbol&&(br[Symbol.iterator]=function(){var e=this;return{next:function(){var t=e.getToken();return{done:t.type===ht.eof,value:t}}}}),br.curContext=function(){return this.context[this.context.length-1]},br.nextToken=function(){var e=this.curContext();return e&&e.preserveSpace||this.skipSpace(),this.start=this.pos,this.options.locations&&(this.startLoc=this.curPosition()),this.pos>=this.input.length?this.finishToken(ht.eof):e.override?e.override(this):void this.readToken(this.fullCharCodeAtPos())},br.readToken=function(e){return rt(e,this.options.ecmaVersion>=6)||92===e?this.readWord():this.getTokenFromCode(e)},br.fullCharCodeAtPos=function(){var e=this.input.charCodeAt(this.pos);return e<=55295||e>=57344?e:(e<<10)+this.input.charCodeAt(this.pos+1)-56613888},br.skipBlockComment=function(){var e,t=this.options.onComment&&this.curPosition(),r=this.pos,i=this.input.indexOf("*/",this.pos+=2);if(-1===i&&this.raise(this.pos-2,"Unterminated comment"),this.pos=i+2,this.options.locations)for(pt.lastIndex=r;(e=pt.exec(this.input))&&e.index<this.pos;)++this.curLine,this.lineStart=e.index+e[0].length;this.options.onComment&&this.options.onComment(!0,this.input.slice(r+2,i),r,this.pos,t,this.curPosition())},br.skipLineComment=function(e){for(var t=this.pos,r=this.options.onComment&&this.curPosition(),i=this.input.charCodeAt(this.pos+=e);this.pos<this.input.length&&!dt(i);)i=this.input.charCodeAt(++this.pos);this.options.onComment&&this.options.onComment(!1,this.input.slice(t+e,this.pos),t,this.pos,r,this.curPosition())},br.skipSpace=function(){e:for(;this.pos<this.input.length;){var e=this.input.charCodeAt(this.pos);switch(e){case 32:case 160:++this.pos;break;case 13:10===this.input.charCodeAt(this.pos+1)&&++this.pos;case 10:case 8232:case 8233:++this.pos,this.options.locations&&(++this.curLine,this.lineStart=this.pos);break;case 47:switch(this.input.charCodeAt(this.pos+1)){case 42:this.skipBlockComment();break;case 47:this.skipLineComment(2);break;default:break e}break;default:if(!(e>8&&e<14||e>=5760&&ft.test(String.fromCharCode(e))))break e;++this.pos}}},br.finishToken=function(e,t){this.end=this.pos,this.options.locations&&(this.endLoc=this.curPosition());var r=this.type;this.type=e,this.value=t,this.updateContext(r)},br.readToken_dot=function(){var e=this.input.charCodeAt(this.pos+1);if(e>=48&&e<=57)return this.readNumber(!0);var t=this.input.charCodeAt(this.pos+2);return this.options.ecmaVersion>=6&&46===e&&46===t?(this.pos+=3,this.finishToken(ht.ellipsis)):(++this.pos,this.finishToken(ht.dot))},br.readToken_slash=function(){var e=this.input.charCodeAt(this.pos+1);return this.exprAllowed?(++this.pos,this.readRegexp()):61===e?this.finishOp(ht.assign,2):this.finishOp(ht.slash,1)},br.readToken_mult_modulo_exp=function(e){var t=this.input.charCodeAt(this.pos+1),r=1,i=42===e?ht.star:ht.modulo;return this.options.ecmaVersion>=7&&42===e&&42===t&&(++r,i=ht.starstar,t=this.input.charCodeAt(this.pos+2)),61===t?this.finishOp(ht.assign,r+1):this.finishOp(i,r)},br.readToken_pipe_amp=function(e){var t=this.input.charCodeAt(this.pos+1);if(t===e){if(this.options.ecmaVersion>=12)if(61===this.input.charCodeAt(this.pos+2))return this.finishOp(ht.assign,3);return this.finishOp(124===e?ht.logicalOR:ht.logicalAND,2)}return 61===t?this.finishOp(ht.assign,2):this.finishOp(124===e?ht.bitwiseOR:ht.bitwiseAND,1)},br.readToken_caret=function(){return 61===this.input.charCodeAt(this.pos+1)?this.finishOp(ht.assign,2):this.finishOp(ht.bitwiseXOR,1)},br.readToken_plus_min=function(e){var t=this.input.charCodeAt(this.pos+1);return t===e?45!==t||this.inModule||62!==this.input.charCodeAt(this.pos+2)||0!==this.lastTokEnd&&!lt.test(this.input.slice(this.lastTokEnd,this.pos))?this.finishOp(ht.incDec,2):(this.skipLineComment(3),this.skipSpace(),this.nextToken()):61===t?this.finishOp(ht.assign,2):this.finishOp(ht.plusMin,1)},br.readToken_lt_gt=function(e){var t=this.input.charCodeAt(this.pos+1),r=1;return t===e?(r=62===e&&62===this.input.charCodeAt(this.pos+2)?3:2,61===this.input.charCodeAt(this.pos+r)?this.finishOp(ht.assign,r+1):this.finishOp(ht.bitShift,r)):33!==t||60!==e||this.inModule||45!==this.input.charCodeAt(this.pos+2)||45!==this.input.charCodeAt(this.pos+3)?(61===t&&(r=2),this.finishOp(ht.relational,r)):(this.skipLineComment(4),this.skipSpace(),this.nextToken())},br.readToken_eq_excl=function(e){var t=this.input.charCodeAt(this.pos+1);return 61===t?this.finishOp(ht.equality,61===this.input.charCodeAt(this.pos+2)?3:2):61===e&&62===t&&this.options.ecmaVersion>=6?(this.pos+=2,this.finishToken(ht.arrow)):this.finishOp(61===e?ht.eq:ht.prefix,1)},br.readToken_question=function(){var e=this.options.ecmaVersion;if(e>=11){var t=this.input.charCodeAt(this.pos+1);if(46===t){var r=this.input.charCodeAt(this.pos+2);if(r<48||r>57)return this.finishOp(ht.questionDot,2)}if(63===t){if(e>=12)if(61===this.input.charCodeAt(this.pos+2))return this.finishOp(ht.assign,3);return this.finishOp(ht.coalesce,2)}}return this.finishOp(ht.question,1)},br.getTokenFromCode=function(e){switch(e){case 46:return this.readToken_dot();case 40:return++this.pos,this.finishToken(ht.parenL);case 41:return++this.pos,this.finishToken(ht.parenR);case 59:return++this.pos,this.finishToken(ht.semi);case 44:return++this.pos,this.finishToken(ht.comma);case 91:return++this.pos,this.finishToken(ht.bracketL);case 93:return++this.pos,this.finishToken(ht.bracketR);case 123:return++this.pos,this.finishToken(ht.braceL);case 125:return++this.pos,this.finishToken(ht.braceR);case 58:return++this.pos,this.finishToken(ht.colon);case 96:if(this.options.ecmaVersion<6)break;return++this.pos,this.finishToken(ht.backQuote);case 48:var t=this.input.charCodeAt(this.pos+1);if(120===t||88===t)return this.readRadixNumber(16);if(this.options.ecmaVersion>=6){if(111===t||79===t)return this.readRadixNumber(8);if(98===t||66===t)return this.readRadixNumber(2)}case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:return this.readNumber(!1);case 34:case 39:return this.readString(e);case 47:return this.readToken_slash();case 37:case 42:return this.readToken_mult_modulo_exp(e);case 124:case 38:return this.readToken_pipe_amp(e);case 94:return this.readToken_caret();case 43:case 45:return this.readToken_plus_min(e);case 60:case 62:return this.readToken_lt_gt(e);case 61:case 33:return this.readToken_eq_excl(e);case 63:return this.readToken_question();case 126:return this.finishOp(ht.prefix,1)}this.raise(this.pos,"Unexpected character '"+xr(e)+"'")},br.finishOp=function(e,t){var r=this.input.slice(this.pos,this.pos+t);return this.pos+=t,this.finishToken(e,r)},br.readRegexp=function(){for(var e,t,r=this.pos;;){this.pos>=this.input.length&&this.raise(r,"Unterminated regular expression");var i=this.input.charAt(this.pos);if(lt.test(i)&&this.raise(r,"Unterminated regular expression"),e)e=!1;else{if("["===i)t=!0;else if("]"===i&&t)t=!1;else if("/"===i&&!t)break;e="\\"===i}++this.pos}var n=this.input.slice(r,this.pos);++this.pos;var s=this.pos,a=this.readWord1();this.containsEsc&&this.unexpected(s);var o=this.regexpState||(this.regexpState=new or(this));o.reset(r,n,a),this.validateRegExpFlags(o),this.validateRegExpPattern(o);var u=null;try{u=new RegExp(n,a)}catch(e){}return this.finishToken(ht.regexp,{pattern:n,flags:a,value:u})},br.readInt=function(e,t,r){for(var i=this.options.ecmaVersion>=12&&void 0===t,n=r&&48===this.input.charCodeAt(this.pos),s=this.pos,a=0,o=0,u=0,c=null==t?1/0:t;u<c;++u,++this.pos){var h=this.input.charCodeAt(this.pos),l=void 0;if(i&&95===h)n&&this.raiseRecoverable(this.pos,"Numeric separator is not allowed in legacy octal numeric literals"),95===o&&this.raiseRecoverable(this.pos,"Numeric separator must be exactly one underscore"),0===u&&this.raiseRecoverable(this.pos,"Numeric separator is not allowed at the first of digits"),o=h;else{if((l=h>=97?h-97+10:h>=65?h-65+10:h>=48&&h<=57?h-48:1/0)>=e)break;o=h,a=a*e+l}}return i&&95===o&&this.raiseRecoverable(this.pos-1,"Numeric separator is not allowed at the last of digits"),this.pos===s||null!=t&&this.pos-s!==t?null:a},br.readRadixNumber=function(e){var t=this.pos;this.pos+=2;var r=this.readInt(e);return null==r&&this.raise(this.start+2,"Expected number in radix "+e),this.options.ecmaVersion>=11&&110===this.input.charCodeAt(this.pos)?(r=yr(this.input.slice(t,this.pos)),++this.pos):rt(this.fullCharCodeAtPos())&&this.raise(this.pos,"Identifier directly after number"),this.finishToken(ht.num,r)},br.readNumber=function(e){var t=this.pos;e||null!==this.readInt(10,void 0,!0)||this.raise(t,"Invalid number");var r=this.pos-t>=2&&48===this.input.charCodeAt(t);r&&this.strict&&this.raise(t,"Invalid number");var i=this.input.charCodeAt(this.pos);if(!r&&!e&&this.options.ecmaVersion>=11&&110===i){var n=yr(this.input.slice(t,this.pos));return++this.pos,rt(this.fullCharCodeAtPos())&&this.raise(this.pos,"Identifier directly after number"),this.finishToken(ht.num,n)}r&&/[89]/.test(this.input.slice(t,this.pos))&&(r=!1),46!==i||r||(++this.pos,this.readInt(10),i=this.input.charCodeAt(this.pos)),69!==i&&101!==i||r||(43!==(i=this.input.charCodeAt(++this.pos))&&45!==i||++this.pos,null===this.readInt(10)&&this.raise(t,"Invalid number")),rt(this.fullCharCodeAtPos())&&this.raise(this.pos,"Identifier directly after number");var s,a=(s=this.input.slice(t,this.pos),r?parseInt(s,8):parseFloat(s.replace(/_/g,"")));return this.finishToken(ht.num,a)},br.readCodePoint=function(){var e;if(123===this.input.charCodeAt(this.pos)){this.options.ecmaVersion<6&&this.unexpected();var t=++this.pos;e=this.readHexChar(this.input.indexOf("}",this.pos)-this.pos),++this.pos,e>1114111&&this.invalidStringToken(t,"Code point out of bounds")}else e=this.readHexChar(4);return e},br.readString=function(e){for(var t="",r=++this.pos;;){this.pos>=this.input.length&&this.raise(this.start,"Unterminated string constant");var i=this.input.charCodeAt(this.pos);if(i===e)break;92===i?(t+=this.input.slice(r,this.pos),t+=this.readEscapedChar(!1),r=this.pos):(dt(i,this.options.ecmaVersion>=10)&&this.raise(this.start,"Unterminated string constant"),++this.pos)}return t+=this.input.slice(r,this.pos++),this.finishToken(ht.string,t)};var Sr={};br.tryReadTemplateToken=function(){this.inTemplateElement=!0;try{this.readTmplToken()}catch(e){if(e!==Sr)throw e;this.readInvalidTemplateToken()}this.inTemplateElement=!1},br.invalidStringToken=function(e,t){if(this.inTemplateElement&&this.options.ecmaVersion>=9)throw Sr;this.raise(e,t)},br.readTmplToken=function(){for(var e="",t=this.pos;;){this.pos>=this.input.length&&this.raise(this.start,"Unterminated template");var r=this.input.charCodeAt(this.pos);if(96===r||36===r&&123===this.input.charCodeAt(this.pos+1))return this.pos!==this.start||this.type!==ht.template&&this.type!==ht.invalidTemplate?(e+=this.input.slice(t,this.pos),this.finishToken(ht.template,e)):36===r?(this.pos+=2,this.finishToken(ht.dollarBraceL)):(++this.pos,this.finishToken(ht.backQuote));if(92===r)e+=this.input.slice(t,this.pos),e+=this.readEscapedChar(!0),t=this.pos;else if(dt(r)){switch(e+=this.input.slice(t,this.pos),++this.pos,r){case 13:10===this.input.charCodeAt(this.pos)&&++this.pos;case 10:e+="\n";break;default:e+=String.fromCharCode(r)}this.options.locations&&(++this.curLine,this.lineStart=this.pos),t=this.pos}else++this.pos}},br.readInvalidTemplateToken=function(){for(;this.pos<this.input.length;this.pos++)switch(this.input[this.pos]){case"\\":++this.pos;break;case"$":if("{"!==this.input[this.pos+1])break;case"`":return this.finishToken(ht.invalidTemplate,this.input.slice(this.start,this.pos))}this.raise(this.start,"Unterminated template")},br.readEscapedChar=function(e){var t=this.input.charCodeAt(++this.pos);switch(++this.pos,t){case 110:return"\n";case 114:return"\r";case 120:return String.fromCharCode(this.readHexChar(2));case 117:return xr(this.readCodePoint());case 116:return"\t";case 98:return"\b";case 118:return"\v";case 102:return"\f";case 13:10===this.input.charCodeAt(this.pos)&&++this.pos;case 10:return this.options.locations&&(this.lineStart=this.pos,++this.curLine),"";case 56:case 57:if(e){var r=this.pos-1;return this.invalidStringToken(r,"Invalid escape sequence in template string"),null}default:if(t>=48&&t<=55){var i=this.input.substr(this.pos-1,3).match(/^[0-7]+/)[0],n=parseInt(i,8);return n>255&&(i=i.slice(0,-1),n=parseInt(i,8)),this.pos+=i.length-1,t=this.input.charCodeAt(this.pos),"0"===i&&56!==t&&57!==t||!this.strict&&!e||this.invalidStringToken(this.pos-1-i.length,e?"Octal literal in template string":"Octal literal in strict mode"),String.fromCharCode(n)}return dt(t)?"":String.fromCharCode(t)}},br.readHexChar=function(e){var t=this.pos,r=this.readInt(16,e);return null===r&&this.invalidStringToken(t,"Bad character escape sequence"),r},br.readWord1=function(){this.containsEsc=!1;for(var e="",t=!0,r=this.pos,i=this.options.ecmaVersion>=6;this.pos<this.input.length;){var n=this.fullCharCodeAtPos();if(it(n,i))this.pos+=n<=65535?1:2;else{if(92!==n)break;this.containsEsc=!0,e+=this.input.slice(r,this.pos);var s=this.pos;117!==this.input.charCodeAt(++this.pos)&&this.invalidStringToken(this.pos,"Expecting Unicode escape sequence \\uXXXX"),++this.pos;var a=this.readCodePoint();(t?rt:it)(a,i)||this.invalidStringToken(s,"Invalid Unicode escape"),e+=xr(a),r=this.pos}t=!1}return e+this.input.slice(r,this.pos)},br.readWord=function(){var e=this.readWord1(),t=ht.name;return this.keywords.test(e)&&(t=ut[e]),this.finishToken(t,e)};function _r(e,t){e.prototype=Object.create(t.prototype),e.prototype.constructor=e,e.__proto__=t}function wr(e){var t="function"==typeof Map?new Map:void 0;return wr=function(e){if(null===e||(r=e,-1===Function.toString.call(r).indexOf("[native code]")))return e;var r;if("function"!=typeof e)throw new TypeError("Super expression must either be null or a function");if(void 0!==t){if(t.has(e))return t.get(e);t.set(e,i)}function i(){return Cr(e,arguments,Er(this).constructor)}return i.prototype=Object.create(e.prototype,{constructor:{value:i,enumerable:!1,writable:!0,configurable:!0}}),kr(i,e)},wr(e)}function Cr(e,t,r){return Cr=function(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Date.prototype.toString.call(Reflect.construct(Date,[],(function(){}))),!0}catch(e){return!1}}()?Reflect.construct:function(e,t,r){var i=[null];i.push.apply(i,t);var n=new(Function.bind.apply(e,i));return r&&kr(n,r.prototype),n},Cr.apply(null,arguments)}function kr(e,t){return kr=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},kr(e,t)}function Er(e){return Er=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},Er(e)}At.acorn={Parser:At,version:"7.4.1",defaultOptions:kt,Position:_t,SourceLocation:wt,getLineInfo:Ct,Node:qt,TokenType:nt,tokTypes:ht,keywordTypes:ut,TokContext:Jt,tokContexts:Kt,isIdentifierChar:it,isIdentifierStart:rt,Token:vr,isNewLine:dt,lineBreak:lt,lineBreakG:pt,nonASCIIwhitespace:ft};var Ir=function(e){function t(){return e.apply(this,arguments)||this}return _r(t,e),t}(wr(Error)),Ar=function(e){function t(){return e.apply(this,arguments)||this}return _r(t,e),t}(wr(SyntaxError)),Tr=function(e){function t(){return e.apply(this,arguments)||this}return _r(t,e),t}(wr(ReferenceError)),Nr=function(e){function t(){return e.apply(this,arguments)||this}return _r(t,e),t}(wr(TypeError)),Pr=function(e){function t(){return e.apply(this,arguments)||this}return _r(t,e),t}(Ir),Or=function(e){function t(){return e.apply(this,arguments)||this}return _r(t,e),t}(Ar),Lr=function(e){function t(){return e.apply(this,arguments)||this}return _r(t,e),t}(Tr),Rr={UnknownError:[3001,"%0",Pr],ExecutionTimeOutError:[3002,"Script execution timed out after %0ms",Pr],NodeTypeSyntaxError:[1001,"Unknown node type: %0",Lr],BinaryOperatorSyntaxError:[1002,"Unknown binary operator: %0",Lr],LogicalOperatorSyntaxError:[1003,"Unknown logical operator: %0",Lr],UnaryOperatorSyntaxError:[1004,"Unknown unary operator: %0",Lr],UpdateOperatorSyntaxError:[1005,"Unknown update operator: %0",Lr],ObjectStructureSyntaxError:[1006,"Unknown object structure: %0",Lr],AssignmentExpressionSyntaxError:[1007,"Unknown assignment expression: %0",Lr],VariableTypeSyntaxError:[1008,"Unknown variable type: %0",Lr],ParamTypeSyntaxError:[1009,"Unknown param type: %0",Lr],AssignmentTypeSyntaxError:[1010,"Unknown assignment type: %0",Lr],FunctionUndefinedReferenceError:[2001,"%0 is not a function",Tr],VariableUndefinedReferenceError:[2002,"%0 is not defined",Tr],IsNotConstructor:[2003,"%0 is not a constructor",Nr]};function Dr(e,t,r){return Dr=function(){if("undefined"==typeof Reflect||!Reflect.construct)return!1;if(Reflect.construct.sham)return!1;if("function"==typeof Proxy)return!0;try{return Date.prototype.toString.call(Reflect.construct(Date,[],(function(){}))),!0}catch(e){return!1}}()?Reflect.construct:function(e,t,r){var i=[null];i.push.apply(i,t);var n=new(Function.bind.apply(e,i));return r&&Fr(n,r.prototype),n},Dr.apply(null,arguments)}function Fr(e,t){return Fr=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},Fr(e,t)}function Mr(e,t){Object.defineProperty(e,"name",{value:t,writable:!1,enumerable:!1,configurable:!0})}var Vr=Object.prototype.hasOwnProperty,Br=Symbol("Break"),jr=Symbol("Continue"),Hr=Symbol("DefaultCase"),Ur=Symbol("EmptyStatementReturn"),Gr=Symbol("WithScopeName"),Wr=Symbol("SuperScopeName"),qr=Symbol("RootScopeName"),$r=Symbol("GlobalScopeName");function zr(e){return"function"==typeof e}var Jr=function(){function e(e){this.interpreter=e}return e.prototype.generator=function(){var e=this.interpreter;return{getOptions:e.getOptions.bind(e),getCurrentScope:function(){return this.getCurrentScope()}.bind(e),getGlobalScope:function(){return this.getGlobalScope()}.bind(e),getCurrentContext:function(){return this.getCurrentContext()}.bind(e),getExecStartTime:e.getExecStartTime.bind(e)}},e}();function Kr(e,t,r){if(void 0===r&&(r=!0),!(e instanceof Jr))throw new Error("Illegal call");if("string"!=typeof t)return t;if(t){var i=e.generator(),n={timeout:i.getOptions().timeout,_initEnv:function(){r||this.setCurrentContext(i.getCurrentContext()),this.execStartTime=i.getExecStartTime(),this.execEndTime=this.execStartTime}},s=r?i.getGlobalScope():i.getCurrentScope();return new ii(s,n).evaluate(t)}}function Qr(e){if(!(e instanceof Jr))throw new Error("Illegal call");for(var t=e.generator(),r=arguments.length,i=new Array(r>1?r-1:0),n=1;n<r;n++)i[n-1]=arguments[n];var s=i.pop(),a=new ii(t.getGlobalScope(),t.getOptions()),o="\n\t\t    (function anonymous("+i.join(",")+"){\n\t\t        "+s+"\n\t\t    });\n\t\t    ";return a.evaluate(o)}Object.defineProperty(Kr,"__IS_EVAL_FUNC",{value:!0,writable:!1,enumerable:!1,configurable:!1}),Object.defineProperty(Qr,"__IS_FUNCTION_FUNC",{value:!0,writable:!1,enumerable:!1,configurable:!1});var Xr=function(e){this.value=e},Yr=function(e){this.value=e},Zr=function(e){this.value=e},ei=function(e,t,r){void 0===t&&(t=null),this.name=r,this.parent=t,this.data=e,this.labelStack=[]};function ti(){}var ri={NaN:NaN,Infinity:1/0,undefined:void 0,Object:Object,Array:Array,String:String,Boolean:Boolean,Number:Number,Date:Date,RegExp:RegExp,Error:Error,URIError:URIError,TypeError:TypeError,RangeError:RangeError,SyntaxError:SyntaxError,ReferenceError:ReferenceError,Math:Math,parseInt:parseInt,parseFloat:parseFloat,isNaN:isNaN,isFinite:isFinite,decodeURI:decodeURI,decodeURIComponent:decodeURIComponent,encodeURI:encodeURI,encodeURIComponent:encodeURIComponent,escape:escape,unescape:unescape,eval:Kr,Function:Qr};"undefined"!=typeof JSON&&(ri.JSON=JSON),"undefined"!=typeof Promise&&(ri.Promise=Promise),"undefined"!=typeof Set&&(ri.Set=Set),"undefined"!=typeof Map&&(ri.Map=Map),"undefined"!=typeof Symbol&&(ri.Symbol=Symbol),"undefined"!=typeof Proxy&&(ri.Proxy=Proxy),"undefined"!=typeof WeakMap&&(ri.WeakMap=WeakMap),"undefined"!=typeof WeakSet&&(ri.WeakSet=WeakSet),"undefined"!=typeof Reflect&&(ri.Reflect=Reflect);var ii=function(){function e(t,r){void 0===t&&(t=e.global),void 0===r&&(r={}),this.sourceList=[],this.collectDeclVars=Object.create(null),this.collectDeclFuncs=Object.create(null),this.isVarDeclMode=!1,this.lastExecNode=null,this.isRunning=!1,this.options={ecmaVersion:r.ecmaVersion||e.ecmaVersion,timeout:r.timeout||0,rootContext:r.rootContext,globalContextInFunction:void 0===r.globalContextInFunction?e.globalContextInFunction:r.globalContextInFunction,_initEnv:r._initEnv},this.context=t||Object.create(null),this.callStack=[],this.initEnvironment(this.context)}var t=e.prototype;return t.initEnvironment=function(e){var t;if(e instanceof ei)t=e;else{var r=null,i=this.createSuperScope(e);this.options.rootContext&&(r=new ei(function(e){return Object.create(e)}(this.options.rootContext),i,qr)),t=new ei(e,r||i,$r)}this.globalScope=t,this.currentScope=this.globalScope,this.globalContext=t.data,this.currentContext=t.data,this.collectDeclVars=Object.create(null),this.collectDeclFuncs=Object.create(null),this.execStartTime=Date.now(),this.execEndTime=this.execStartTime;var n=this.options._initEnv;n&&n.call(this)},t.getExecStartTime=function(){return this.execStartTime},t.getExecutionTime=function(){return this.execEndTime-this.execStartTime},t.setExecTimeout=function(e){void 0===e&&(e=0),this.options.timeout=e},t.getOptions=function(){return this.options},t.getGlobalScope=function(){return this.globalScope},t.getCurrentScope=function(){return this.currentScope},t.getCurrentContext=function(){return this.currentContext},t.isInterruptThrow=function(e){return e instanceof Pr||e instanceof Lr||e instanceof Or},t.createSuperScope=function(e){var t=Object.assign({},ri);return Object.keys(t).forEach((function(r){r in e&&delete t[r]})),new ei(t,null,Wr)},t.setCurrentContext=function(e){this.currentContext=e},t.setCurrentScope=function(e){this.currentScope=e},t.evaluate=function(t){var r,i,n;if(void 0===t&&(t=""),t)return i=t,n={ranges:!0,locations:!0,ecmaVersion:this.options.ecmaVersion||e.ecmaVersion},r=At.parse(i,n),this.evaluateNode(r,t)},t.appendCode=function(e){return this.evaluate(e)},t.evaluateNode=function(e,t){var r=this;void 0===t&&(t=""),this.value=void 0,this.source=t,this.sourceList.push(t),this.isRunning=!0,this.execStartTime=Date.now(),this.execEndTime=this.execStartTime,this.collectDeclVars=Object.create(null),this.collectDeclFuncs=Object.create(null);var i=this.getCurrentScope(),n=this.getCurrentContext(),s=i.labelStack.concat([]),a=this.callStack.concat([]);try{var o=this.createClosure(e);this.addDeclarationsToScope(this.collectDeclVars,this.collectDeclFuncs,this.getCurrentScope()),o()}catch(e){throw e}finally{r.setCurrentScope(i),r.setCurrentContext(n),i.labelStack=s,r.callStack=a,this.execEndTime=Date.now()}return this.isRunning=!1,this.getValue()},t.createErrorMessage=function(e,t,r){var i=e[1].replace("%0",String(t));return null!==r&&(i+=this.getNodePosition(r||this.lastExecNode)),i},t.createError=function(e,t){return new t(e)},t.createThrowError=function(e,t){return this.createError(e,t)},t.createInternalThrowError=function(e,t,r){return this.createError(this.createErrorMessage(e,t,r),e[2])},t.checkTimeout=function(){if(!this.isRunning)return!1;var e=this.options.timeout||0;return Date.now()-this.execStartTime>e},t.getNodePosition=function(e){if(e){return e.loc?" ["+e.loc.start.line+":"+e.loc.start.column+"]":""}return""},t.createClosure=function(e){var t,r=this;switch(e.type){case"BinaryExpression":t=this.binaryExpressionHandler(e);break;case"LogicalExpression":t=this.logicalExpressionHandler(e);break;case"UnaryExpression":t=this.unaryExpressionHandler(e);break;case"UpdateExpression":t=this.updateExpressionHandler(e);break;case"ObjectExpression":t=this.objectExpressionHandler(e);break;case"ArrayExpression":t=this.arrayExpressionHandler(e);break;case"CallExpression":t=this.callExpressionHandler(e);break;case"NewExpression":t=this.newExpressionHandler(e);break;case"MemberExpression":t=this.memberExpressionHandler(e);break;case"ThisExpression":t=this.thisExpressionHandler(e);break;case"SequenceExpression":t=this.sequenceExpressionHandler(e);break;case"Literal":t=this.literalHandler(e);break;case"Identifier":t=this.identifierHandler(e);break;case"AssignmentExpression":t=this.assignmentExpressionHandler(e);break;case"FunctionDeclaration":t=this.functionDeclarationHandler(e);break;case"VariableDeclaration":t=this.variableDeclarationHandler(e);break;case"BlockStatement":case"Program":t=this.programHandler(e);break;case"ExpressionStatement":t=this.expressionStatementHandler(e);break;case"EmptyStatement":t=this.emptyStatementHandler(e);break;case"ReturnStatement":t=this.returnStatementHandler(e);break;case"FunctionExpression":t=this.functionExpressionHandler(e);break;case"IfStatement":t=this.ifStatementHandler(e);break;case"ConditionalExpression":t=this.conditionalExpressionHandler(e);break;case"ForStatement":t=this.forStatementHandler(e);break;case"WhileStatement":t=this.whileStatementHandler(e);break;case"DoWhileStatement":t=this.doWhileStatementHandler(e);break;case"ForInStatement":t=this.forInStatementHandler(e);break;case"WithStatement":t=this.withStatementHandler(e);break;case"ThrowStatement":t=this.throwStatementHandler(e);break;case"TryStatement":t=this.tryStatementHandler(e);break;case"ContinueStatement":t=this.continueStatementHandler(e);break;case"BreakStatement":t=this.breakStatementHandler(e);break;case"SwitchStatement":t=this.switchStatementHandler(e);break;case"LabeledStatement":t=this.labeledStatementHandler(e);break;case"DebuggerStatement":t=this.debuggerStatementHandler(e);break;default:throw this.createInternalThrowError(Rr.NodeTypeSyntaxError,e.type,e)}return function(){var i=r.options.timeout;if(i&&i>0&&r.checkTimeout())throw r.createInternalThrowError(Rr.ExecutionTimeOutError,i,null);return r.lastExecNode=e,t.apply(void 0,arguments)}},t.binaryExpressionHandler=function(e){var t=this,r=this.createClosure(e.left),i=this.createClosure(e.right);return function(){var n=r(),s=i();switch(e.operator){case"==":return n==s;case"!=":return n!=s;case"===":return n===s;case"!==":return n!==s;case"<":return n<s;case"<=":return n<=s;case">":return n>s;case">=":return n>=s;case"<<":return n<<s;case">>":return n>>s;case">>>":return n>>>s;case"+":return n+s;case"-":return n-s;case"*":return n*s;case"**":return Math.pow(n,s);case"/":return n/s;case"%":return n%s;case"|":return n|s;case"^":return n^s;case"&":return n&s;case"in":return n in s;case"instanceof":return n instanceof s;default:throw t.createInternalThrowError(Rr.BinaryOperatorSyntaxError,e.operator,e)}}},t.logicalExpressionHandler=function(e){var t=this,r=this.createClosure(e.left),i=this.createClosure(e.right);return function(){switch(e.operator){case"||":return r()||i();case"&&":return r()&&i();default:throw t.createInternalThrowError(Rr.LogicalOperatorSyntaxError,e.operator,e)}}},t.unaryExpressionHandler=function(e){var t,r=this;if("delete"===e.operator){var i=this.createObjectGetter(e.argument),n=this.createNameGetter(e.argument);return function(){return delete i()[n()]}}if("typeof"===e.operator&&"Identifier"===e.argument.type){var s=this.createObjectGetter(e.argument),a=this.createNameGetter(e.argument);t=function(){return s()[a()]}}else t=this.createClosure(e.argument);return function(){var i=t();switch(e.operator){case"-":return-i;case"+":return+i;case"!":return!i;case"~":return~i;case"void":return;case"typeof":return typeof i;default:throw r.createInternalThrowError(Rr.UnaryOperatorSyntaxError,e.operator,e)}}},t.updateExpressionHandler=function(e){var t=this,r=this.createObjectGetter(e.argument),i=this.createNameGetter(e.argument);return function(){var n=r(),s=i();switch(t.assertVariable(n,s,e),e.operator){case"++":return e.prefix?++n[s]:n[s]++;case"--":return e.prefix?--n[s]:n[s]--;default:throw t.createInternalThrowError(Rr.UpdateOperatorSyntaxError,e.operator,e)}}},t.objectExpressionHandler=function(e){var t=this,r=[];var i=Object.create(null);return e.properties.forEach((function(e){var n=e.kind,s=function(e){return"Identifier"===e.type?e.name:"Literal"===e.type?e.value:this.throwError(Rr.ObjectStructureSyntaxError,e.type,e)}(e.key);i[s]&&"init"!==n||(i[s]={}),i[s][n]=t.createClosure(e.value),r.push({key:s,property:e})})),function(){for(var e={},t=r.length,n=0;n<t;n++){var s=r[n],a=s.key,o=i[a],u=o.init?o.init():void 0,c=o.get?o.get():function(){},h=o.set?o.set():function(e){};if("set"in o||"get"in o){var l={configurable:!0,enumerable:!0,get:c,set:h};Object.defineProperty(e,a,l)}else{var p=s.property,d=p.kind;"Identifier"!==p.key.type||"FunctionExpression"!==p.value.type||"init"!==d||p.value.id||Mr(u,p.key.name),e[a]=u}}return e}},t.arrayExpressionHandler=function(e){var t=this,r=e.elements.map((function(e){return e?t.createClosure(e):e}));return function(){for(var e=r.length,t=Array(e),i=0;i<e;i++){var n=r[i];n&&(t[i]=n())}return t}},t.safeObjectGet=function(e,t,r){return e[t]},t.createCallFunctionGetter=function(e){var t=this;if("MemberExpression"===e.type){var r=this.createClosure(e.object),i=this.createMemberKeyGetter(e),n=this.source;return function(){var s=r(),a=i(),o=t.safeObjectGet(s,a,e);if(!o||!zr(o)){var u=n.slice(e.start,e.end);throw t.createInternalThrowError(Rr.FunctionUndefinedReferenceError,u,e)}return o.__IS_EVAL_FUNC?function(e){return o(new Jr(t),e,!0)}:o.__IS_FUNCTION_FUNC?function(){for(var e=arguments.length,r=new Array(e),i=0;i<e;i++)r[i]=arguments[i];return o.apply(void 0,[new Jr(t)].concat(r))}:o.bind(s)}}var s=this.createClosure(e);return function(){var r="";"Identifier"===e.type&&(r=e.name);var i=s();if(!i||!zr(i))throw t.createInternalThrowError(Rr.FunctionUndefinedReferenceError,r,e);if("Identifier"===e.type&&i.__IS_EVAL_FUNC&&"eval"===r)return function(e){var n=t.getScopeFromName(r,t.getCurrentScope()),s=n.name===Wr||n.name===$r||n.name===qr;return i(new Jr(t),e,!s)};if(i.__IS_EVAL_FUNC)return function(e){return i(new Jr(t),e,!0)};if(i.__IS_FUNCTION_FUNC)return function(){for(var e=arguments.length,r=new Array(e),n=0;n<e;n++)r[n]=arguments[n];return i.apply(void 0,[new Jr(t)].concat(r))};var n=t.options.globalContextInFunction;if("Identifier"===e.type){var a=t.getIdentifierScope(e);a.name===Gr&&(n=a.data)}return i.bind(n)}},t.callExpressionHandler=function(e){var t=this,r=this.createCallFunctionGetter(e.callee),i=e.arguments.map((function(e){return t.createClosure(e)}));return function(){return r().apply(void 0,i.map((function(e){return e()})))}},t.functionExpressionHandler=function(e){var t=this,r=this,i=this.source,n=this.collectDeclVars,s=this.collectDeclFuncs;this.collectDeclVars=Object.create(null),this.collectDeclFuncs=Object.create(null);var a=e.id?e.id.name:"",o=e.params.length,u=e.params.map((function(e){return t.createParamNameGetter(e)})),c=this.createClosure(e.body),h=this.collectDeclVars,l=this.collectDeclFuncs;return this.collectDeclVars=n,this.collectDeclFuncs=s,function(){var t=r.getCurrentScope(),n=function e(){for(var i=arguments.length,n=new Array(i),s=0;s<i;s++)n[s]=arguments[s];r.callStack.push(""+a);var o=r.getCurrentScope(),p=function(e,t){return void 0===e&&(e=null),new ei(Object.create(null),e,t)}(t,"FunctionScope("+a+")");r.setCurrentScope(p),r.addDeclarationsToScope(h,l,p),a&&(p.data[a]=e),p.data.arguments=arguments,u.forEach((function(e,t){p.data[e()]=n[t]}));var d=r.getCurrentContext();r.setCurrentContext(this);var f=c();if(r.setCurrentContext(d),r.setCurrentScope(o),r.callStack.pop(),f instanceof Xr)return f.value};return Mr(n,a),Object.defineProperty(n,"length",{value:o,writable:!1,enumerable:!1,configurable:!0}),Object.defineProperty(n,"toString",{value:function(){return i.slice(e.start,e.end)},writable:!0,configurable:!0,enumerable:!1}),Object.defineProperty(n,"valueOf",{value:function(){return i.slice(e.start,e.end)},writable:!0,configurable:!0,enumerable:!1}),n}},t.newExpressionHandler=function(e){var t=this,r=this.source,i=this.createClosure(e.callee),n=e.arguments.map((function(e){return t.createClosure(e)}));return function(){var s=i();if(!zr(s)||s.__IS_EVAL_FUNC){var a=e.callee,o=r.slice(a.start,a.end);throw t.createInternalThrowError(Rr.IsNotConstructor,o,e)}return s.__IS_FUNCTION_FUNC?s.apply(void 0,[new Jr(t)].concat(n.map((function(e){return e()})))):Dr(s,n.map((function(e){return e()})))}},t.memberExpressionHandler=function(e){var t=this.createClosure(e.object),r=this.createMemberKeyGetter(e);return function(){return t()[r()]}},t.thisExpressionHandler=function(e){var t=this;return function(){return t.getCurrentContext()}},t.sequenceExpressionHandler=function(e){var t=this,r=e.expressions.map((function(e){return t.createClosure(e)}));return function(){for(var e,t=r.length,i=0;i<t;i++){e=(0,r[i])()}return e}},t.literalHandler=function(e){return function(){return e.regex?new RegExp(e.regex.pattern,e.regex.flags):e.value}},t.identifierHandler=function(e){var t=this;return function(){var r=t.getCurrentScope(),i=t.getScopeDataFromName(e.name,r);return t.assertVariable(i,e.name,e),i[e.name]}},t.getIdentifierScope=function(e){var t=this.getCurrentScope();return this.getScopeFromName(e.name,t)},t.assignmentExpressionHandler=function(e){var t=this;"Identifier"!==e.left.type||"FunctionExpression"!==e.right.type||e.right.id||(e.right.id={type:"Identifier",name:e.left.name});var r=this.createObjectGetter(e.left),i=this.createNameGetter(e.left),n=this.createClosure(e.right);return function(){var s=r(),a=i(),o=n();switch("="!==e.operator&&t.assertVariable(s,a,e),e.operator){case"=":return s[a]=o;case"+=":return s[a]+=o;case"-=":return s[a]-=o;case"*=":return s[a]*=o;case"**=":return s[a]=Math.pow(s[a],o);case"/=":return s[a]/=o;case"%=":return s[a]%=o;case"<<=":return s[a]<<=o;case">>=":return s[a]>>=o;case">>>=":return s[a]>>>=o;case"&=":return s[a]&=o;case"^=":return s[a]^=o;case"|=":return s[a]|=o;default:throw t.createInternalThrowError(Rr.AssignmentExpressionSyntaxError,e.type,e)}}},t.functionDeclarationHandler=function(e){if(e.id){var t=this.functionExpressionHandler(e);Object.defineProperty(t,"isFunctionDeclareClosure",{value:!0,writable:!1,configurable:!1,enumerable:!1}),this.funcDeclaration(e.id.name,t)}return function(){return Ur}},t.getVariableName=function(e){if("Identifier"===e.type)return e.name;throw this.createInternalThrowError(Rr.VariableTypeSyntaxError,e.type,e)},t.variableDeclarationHandler=function(e){for(var t,r=this,i=[],n=0;n<e.declarations.length;n++){var s=e.declarations[n];this.varDeclaration(this.getVariableName(s.id)),s.init&&i.push({type:"AssignmentExpression",operator:"=",left:s.id,right:s.init})}return i.length&&(t=this.createClosure({type:"BlockStatement",body:i})),function(){if(t){var e=r.isVarDeclMode;r.isVarDeclMode=!0,t(),r.isVarDeclMode=e}return Ur}},t.assertVariable=function(e,t,r){if(e===this.globalScope.data&&!(t in e))throw this.createInternalThrowError(Rr.VariableUndefinedReferenceError,t,r)},t.programHandler=function(e){var t=this,r=e.body.map((function(e){return t.createClosure(e)}));return function(){for(var e=Ur,i=0;i<r.length;i++){var n=r[i],s=t.setValue(n());if(s!==Ur&&((e=s)instanceof Xr||e instanceof Yr||e instanceof Zr||e===Br||e===jr))break}return e}},t.expressionStatementHandler=function(e){return this.createClosure(e.expression)},t.emptyStatementHandler=function(e){return function(){return Ur}},t.returnStatementHandler=function(e){var t=e.argument?this.createClosure(e.argument):ti;return function(){return new Xr(t())}},t.ifStatementHandler=function(e){var t=this.createClosure(e.test),r=this.createClosure(e.consequent),i=e.alternate?this.createClosure(e.alternate):function(){return Ur};return function(){return t()?r():i()}},t.conditionalExpressionHandler=function(e){return this.ifStatementHandler(e)},t.forStatementHandler=function(e){var t=this,r=ti,i=e.test?this.createClosure(e.test):function(){return!0},n=ti,s=this.createClosure(e.body);return"ForStatement"===e.type&&(r=e.init?this.createClosure(e.init):r,n=e.update?this.createClosure(e.update):ti),function(a){var o,u=Ur,c="DoWhileStatement"===e.type;for(a&&"LabeledStatement"===a.type&&(o=a.label.name),r();c||i();n()){c=!1;var h=t.setValue(s());if(h!==Ur&&h!==jr){if(h===Br)break;if((u=h)instanceof Zr&&u.value===o)u=Ur;else if(u instanceof Xr||u instanceof Yr||u instanceof Zr)break}}return u}},t.whileStatementHandler=function(e){return this.forStatementHandler(e)},t.doWhileStatementHandler=function(e){return this.forStatementHandler(e)},t.forInStatementHandler=function(e){var t=this,r=e.left,i=this.createClosure(e.right),n=this.createClosure(e.body);return"VariableDeclaration"===e.left.type&&(this.createClosure(e.left)(),r=e.left.declarations[0].id),function(e){var s,a,o=Ur;e&&"LabeledStatement"===e.type&&(s=e.label.name);var u=i();for(a in u){t.assignmentExpressionHandler({type:"AssignmentExpression",operator:"=",left:r,right:{type:"Literal",value:a}})();var c=t.setValue(n());if(c!==Ur&&c!==jr){if(c===Br)break;if((o=c)instanceof Zr&&o.value===s)o=Ur;else if(o instanceof Xr||o instanceof Yr||o instanceof Zr)break}}return o}},t.withStatementHandler=function(e){var t=this,r=this.createClosure(e.object),i=this.createClosure(e.body);return function(){var e=r(),n=t.getCurrentScope(),s=new ei(e,n,Gr);t.setCurrentScope(s);var a=t.setValue(i());return t.setCurrentScope(n),a}},t.throwStatementHandler=function(e){var t=this,r=this.createClosure(e.argument);return function(){throw t.setValue(void 0),r()}},t.tryStatementHandler=function(e){var t=this,r=this.createClosure(e.block),i=e.handler?this.catchClauseHandler(e.handler):null,n=e.finalizer?this.createClosure(e.finalizer):null;return function(){var e,s,a=t.getCurrentScope(),o=t.getCurrentContext(),u=a.labelStack.concat([]),c=t.callStack.concat([]),h=Ur,l=function(){t.setCurrentScope(a),t.setCurrentContext(o),a.labelStack=u,t.callStack=c};try{(h=t.setValue(r()))instanceof Xr&&(e=h)}catch(r){if(l(),t.isInterruptThrow(r))throw r;if(i)try{(h=t.setValue(i(r)))instanceof Xr&&(e=h)}catch(e){if(l(),t.isInterruptThrow(e))throw e;s=e}}if(n)try{(h=n())instanceof Xr&&(e=h)}catch(e){if(l(),t.isInterruptThrow(e))throw e;s=e}if(s)throw s;return e||h}},t.catchClauseHandler=function(e){var t=this,r=this.createParamNameGetter(e.param),i=this.createClosure(e.body);return function(e){var n,s=t.getCurrentScope().data,a=r(),o=Vr.call(s,a),u=s[a];return s[a]=e,n=i(),o?s[a]=u:delete s[a],n}},t.continueStatementHandler=function(e){return function(){return e.label?new Zr(e.label.name):jr}},t.breakStatementHandler=function(e){return function(){return e.label?new Yr(e.label.name):Br}},t.switchStatementHandler=function(e){var t=this,r=this.createClosure(e.discriminant),i=e.cases.map((function(e){return t.switchCaseHandler(e)}));return function(){for(var e,n,s,a=r(),o=!1,u=0;u<i.length;u++){var c=i[u](),h=c.testClosure();if(h!==Hr){if(o||h===a){if(o=!0,(n=t.setValue(c.bodyClosure()))===Ur)continue;if(n===Br)break;if((e=n)instanceof Xr||e instanceof Yr||e instanceof Zr||e===jr)break}}else s=c}!o&&s&&((n=t.setValue(s.bodyClosure()))===Ur||n===Br||(e=n));return e}},t.switchCaseHandler=function(e){var t=e.test?this.createClosure(e.test):function(){return Hr},r=this.createClosure({type:"BlockStatement",body:e.consequent});return function(){return{testClosure:t,bodyClosure:r}}},t.labeledStatementHandler=function(e){var t=this,r=e.label.name,i=this.createClosure(e.body);return function(){var n,s=t.getCurrentScope();return s.labelStack.push(r),(n=i(e))instanceof Yr&&n.value===r&&(n=Ur),s.labelStack.pop(),n}},t.debuggerStatementHandler=function(e){return function(){return Ur}},t.createParamNameGetter=function(e){if("Identifier"===e.type)return function(){return e.name};throw this.createInternalThrowError(Rr.ParamTypeSyntaxError,e.type,e)},t.createObjectKeyGetter=function(e){var t;return t="Identifier"===e.type?function(){return e.name}:this.createClosure(e),function(){return t()}},t.createMemberKeyGetter=function(e){return e.computed?this.createClosure(e.property):this.createObjectKeyGetter(e.property)},t.createObjectGetter=function(e){var t=this;switch(e.type){case"Identifier":return function(){return t.getScopeDataFromName(e.name,t.getCurrentScope())};case"MemberExpression":return this.createClosure(e.object);default:throw this.createInternalThrowError(Rr.AssignmentTypeSyntaxError,e.type,e)}},t.createNameGetter=function(e){switch(e.type){case"Identifier":return function(){return e.name};case"MemberExpression":return this.createMemberKeyGetter(e);default:throw this.createInternalThrowError(Rr.AssignmentTypeSyntaxError,e.type,e)}},t.varDeclaration=function(e){this.collectDeclVars[e]=void 0},t.funcDeclaration=function(e,t){this.collectDeclFuncs[e]=t},t.addDeclarationsToScope=function(e,t,r){var i=r.data;for(var n in t){var s=t[n];i[n]=s?s():s}for(var a in e)a in i||(i[a]=void 0)},t.getScopeValue=function(e,t){return this.getScopeFromName(e,t).data[e]},t.getScopeDataFromName=function(e,t){return this.getScopeFromName(e,t).data},t.getScopeFromName=function(e,t){var r=t;do{if(e in r.data)return r}while(r=r.parent);return this.globalScope},t.setValue=function(e){var t=this.callStack.length;return this.isVarDeclMode||t||e===Ur||e===Br||e===jr||e instanceof Yr||e instanceof Zr||(this.value=e instanceof Xr?e.value:e),e},t.getValue=function(){return this.value},e}();function ni(e,t,r){return new ii(t,r).evaluate(e)}ii.version="1.4.7",ii.eval=Kr,ii.Function=Qr,ii.ecmaVersion=5,ii.globalContextInFunction=void 0,ii.global=Object.create(null);var si=function(e,t,r){return ni(e,t,r)};var ai=(e,t,i)=>{var n=new Be(e);r.g.__debugMessager=n;var s=new Pe(n),a=new Ve(n),o=new We(n);new He(t,n),new je(t,i,s,a,o);return{__remoteDebug__:{setAppserviceHandlers:e=>{var r,i;e&&(i=t,ce=(r=e).getCurrentPages,he=r.invokeWebviewMethod,pe=r.__appServiceEngine__,de=r.__appServiceSDK__,fe=r.exparser,ge=r.Reporter,le=r.wx,be=r.__virtualDOM__,"function"==typeof __passWAServiceGlobal__&&__passWAServiceGlobal__({__appServiceSDK__:de,__appServiceEngine__:pe,exparser:fe,Reporter:ge,WeixinJSBridge:i,wx:le,__virtualDOM__:be}))},setAutoTestHandler:Le,$$eval:si}}};function oi(r,i,n,s,a){var o={},u=ai(n,a,__WeixinJSCore__);return"ios"===r&&(o=function(r,i,n){var s=new e(i),a=new t({suspend(){r.suspend()},resume(){r.resume()}});X=new K(a,n),Y=new ee(X);var o=new ne(s,X),u=new ie(s,X),c=new ae(s,X,Y),h=new se(s),l=new oe(s);return new re(s,o,u,c,h,l).dispatch(),{runtime:X,debuggerInst:Y}}(i,n,s)),{...o,...u}}}(),__AppServiceRemoteDebugger__=i.default}();
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ 4515:
/***/ ((module) => {

function asyncGeneratorStep(n, t, e, r, o, a, c) {
  try {
    var i = n[a](c),
      u = i.value;
  } catch (n) {
    return void e(n);
  }
  i.done ? t(u) : Promise.resolve(u).then(r, o);
}
function _asyncToGenerator(n) {
  return function () {
    var t = this,
      e = arguments;
    return new Promise(function (r, o) {
      var a = n.apply(t, e);
      function _next(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
      }
      function _throw(n) {
        asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
      }
      _next(void 0);
    });
  };
}
module.exports = _asyncToGenerator, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ 4374:
/***/ ((module, exports, __webpack_require__) => {

var keys = __webpack_require__(157);
var getProto = __webpack_require__(3452);
var unique = __webpack_require__(9138);
var getOwnPropertyNames = Object.getOwnPropertyNames;
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
exports = function (obj) {
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    _ref$prototype = _ref.prototype,
    prototype = _ref$prototype === void 0 ? true : _ref$prototype,
    _ref$unenumerable = _ref.unenumerable,
    unenumerable = _ref$unenumerable === void 0 ? false : _ref$unenumerable,
    _ref$symbol = _ref.symbol,
    symbol = _ref$symbol === void 0 ? false : _ref$symbol;
  var ret = [];
  if ((unenumerable || symbol) && getOwnPropertyNames) {
    var getKeys = keys;
    if (unenumerable && getOwnPropertyNames) getKeys = getOwnPropertyNames;
    do {
      ret = ret.concat(getKeys(obj));
      if (symbol && getOwnPropertySymbols) {
        ret = ret.concat(getOwnPropertySymbols(obj));
      }
    } while (prototype && (obj = getProto(obj)) && obj !== Object.prototype);
    ret = unique(ret);
  } else {
    if (prototype) {
      for (var key in obj) {
        ret.push(key);
      }
    } else {
      ret = keys(obj);
    }
  }
  return ret;
};
module.exports = exports;

/***/ }),

/***/ 2494:
/***/ ((module, exports, __webpack_require__) => {

var restArgs = __webpack_require__(1346);
exports = restArgs(function (fn, ctx, args) {
  return restArgs(function (callArgs) {
    return fn.apply(ctx, args.concat(callArgs));
  });
});
module.exports = exports;

/***/ }),

/***/ 8081:
/***/ ((module, exports, __webpack_require__) => {

var has = __webpack_require__(5745);
var isArr = __webpack_require__(2362);
exports = function (str, obj) {
  if (isArr(str)) return str;
  if (obj && has(obj, str)) return [str];
  var ret = [];
  str.replace(regPropName, function (match, number, quote, str) {
    ret.push(quote ? str.replace(regEscapeChar, '$1') : number || match);
  });
  return ret;
};
var regPropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
var regEscapeChar = /\\(\\)?/g;
module.exports = exports;

/***/ }),

/***/ 5048:
/***/ ((module, exports, __webpack_require__) => {

var isObj = __webpack_require__(540);
var isArr = __webpack_require__(2362);
var extend = __webpack_require__(8189);
exports = function (obj) {
  if (!isObj(obj)) return obj;
  return isArr(obj) ? obj.slice() : extend({}, obj);
};
module.exports = exports;

/***/ }),

/***/ 9481:
/***/ ((module, exports, __webpack_require__) => {

var toArr = __webpack_require__(8149);
exports = function () {
  var args = toArr(arguments);
  var ret = [];
  for (var i = 0, len = args.length; i < len; i++) {
    ret = ret.concat(toArr(args[i]));
  }
  return ret;
};
module.exports = exports;

/***/ }),

/***/ 6997:
/***/ ((module, exports, __webpack_require__) => {

var idxOf = __webpack_require__(6059);
var isStr = __webpack_require__(1366);
var isArrLike = __webpack_require__(6421);
var values = __webpack_require__(7147);
exports = function (arr, val) {
  if (isStr(arr)) return arr.indexOf(val) > -1;
  if (!isArrLike(arr)) arr = values(arr);
  return idxOf(arr, val) >= 0;
};
module.exports = exports;

/***/ }),

/***/ 1071:
/***/ ((module, exports, __webpack_require__) => {

var isUndef = __webpack_require__(2375);
var each = __webpack_require__(1680);
exports = function (keysFn, defaults) {
  return function (obj) {
    each(arguments, function (src, idx) {
      if (idx === 0) return;
      var keys = keysFn(src);
      each(keys, function (key) {
        if (!defaults || isUndef(obj[key])) obj[key] = src[key];
      });
    });
    return obj;
  };
};
module.exports = exports;

/***/ }),

/***/ 1680:
/***/ ((module, exports, __webpack_require__) => {

var isArrLike = __webpack_require__(6421);
var keys = __webpack_require__(157);
var optimizeCb = __webpack_require__(4775);
exports = function (obj, iterator, ctx) {
  iterator = optimizeCb(iterator, ctx);
  var i, len;
  if (isArrLike(obj)) {
    for (i = 0, len = obj.length; i < len; i++) {
      iterator(obj[i], i, obj);
    }
  } else {
    var _keys = keys(obj);
    for (i = 0, len = _keys.length; i < len; i++) {
      iterator(obj[_keys[i]], _keys[i], obj);
    }
  }
  return obj;
};
module.exports = exports;

/***/ }),

/***/ 6920:
/***/ ((module, exports) => {

exports = function (str, suffix) {
  var idx = str.length - suffix.length;
  return idx >= 0 && str.indexOf(suffix, idx) === idx;
};
module.exports = exports;

/***/ }),

/***/ 8189:
/***/ ((module, exports, __webpack_require__) => {

var createAssigner = __webpack_require__(1071);
var allKeys = __webpack_require__(4374);
exports = createAssigner(allKeys);
module.exports = exports;

/***/ }),

/***/ 9189:
/***/ ((module, exports, __webpack_require__) => {

var keys = __webpack_require__(157);
var createAssigner = __webpack_require__(1071);
exports = createAssigner(keys);
module.exports = exports;

/***/ }),

/***/ 4151:
/***/ ((module, exports, __webpack_require__) => {

var safeCb = __webpack_require__(8361);
var each = __webpack_require__(1680);
exports = function (obj, predicate, ctx) {
  var ret = [];
  predicate = safeCb(predicate, ctx);
  each(obj, function (val, idx, list) {
    if (predicate(val, idx, list)) ret.push(val);
  });
  return ret;
};
module.exports = exports;

/***/ }),

/***/ 4583:
/***/ ((module, exports, __webpack_require__) => {

var toSrc = __webpack_require__(4);
var stripCmt = __webpack_require__(8423);
var startWith = __webpack_require__(2629);
var isStr = __webpack_require__(1366);
exports = function (fn) {
  var fnStr = stripCmt(isStr(fn) ? fn : toSrc(fn));
  var open;
  var close;
  if (!startWith(fnStr, 'async') && !startWith(fnStr, 'function') && !startWith(fnStr, '(')) {
    open = 0;
    close = fnStr.indexOf('=>');
  } else {
    open = fnStr.indexOf('(') + 1;
    close = fnStr.indexOf(')');
  }
  var ret = fnStr.slice(open, close);
  ret = ret.match(regArgNames);
  return ret === null ? [] : ret;
};
var regArgNames = /[^\s,]+/g;
module.exports = exports;

/***/ }),

/***/ 3452:
/***/ ((module, exports, __webpack_require__) => {

var isObj = __webpack_require__(540);
var isFn = __webpack_require__(5377);
var getPrototypeOf = Object.getPrototypeOf;
var ObjectCtr = {}.constructor;
exports = function (obj) {
  if (!isObj(obj)) return;
  if (getPrototypeOf && !false) return getPrototypeOf(obj);
  var proto = obj.__proto__;
  if (proto || proto === null) return proto;
  if (isFn(obj.constructor)) return obj.constructor.prototype;
  if (obj instanceof ObjectCtr) return ObjectCtr.prototype;
};
module.exports = exports;

/***/ }),

/***/ 5745:
/***/ ((module, exports) => {

var hasOwnProp = Object.prototype.hasOwnProperty;
exports = function (obj, key) {
  return hasOwnProp.call(obj, key);
};
module.exports = exports;

/***/ }),

/***/ 7995:
/***/ ((module, exports) => {

exports = function (val) {
  return val;
};
module.exports = exports;

/***/ }),

/***/ 6059:
/***/ ((module, exports) => {

exports = function (arr, val, fromIdx) {
  return Array.prototype.indexOf.call(arr, val, fromIdx);
};
module.exports = exports;

/***/ }),

/***/ 2362:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(9762);
if (Array.isArray && !false) {
  exports = Array.isArray;
} else {
  exports = function (val) {
    return objToStr(val) === '[object Array]';
  };
}
module.exports = exports;

/***/ }),

/***/ 6421:
/***/ ((module, exports, __webpack_require__) => {

var isNum = __webpack_require__(6605);
var isFn = __webpack_require__(5377);
var MAX_ARR_IDX = Math.pow(2, 53) - 1;
exports = function (val) {
  if (!val) return false;
  var len = val.length;
  return isNum(len) && len >= 0 && len <= MAX_ARR_IDX && !isFn(val);
};
module.exports = exports;

/***/ }),

/***/ 5377:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(9762);
exports = function (val) {
  var objStr = objToStr(val);
  return objStr === '[object Function]' || objStr === '[object GeneratorFunction]' || objStr === '[object AsyncFunction]';
};
module.exports = exports;

/***/ }),

/***/ 2032:
/***/ ((module, exports, __webpack_require__) => {

var keys = __webpack_require__(157);
exports = function (obj, src) {
  var _keys = keys(src);
  var len = _keys.length;
  if (obj == null) return !len;
  obj = Object(obj);
  for (var i = 0; i < len; i++) {
    var key = _keys[i];
    if (src[key] !== obj[key] || !(key in obj)) return false;
  }
  return true;
};
module.exports = exports;

/***/ }),

/***/ 4034:
/***/ ((module, exports) => {

exports = function (val) {
  return val == null;
};
module.exports = exports;

/***/ }),

/***/ 6605:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(9762);
exports = function (val) {
  return objToStr(val) === '[object Number]';
};
module.exports = exports;

/***/ }),

/***/ 540:
/***/ ((module, exports) => {

exports = function (val) {
  var type = typeof val;
  return !!val && (type === 'function' || type === 'object');
};
module.exports = exports;

/***/ }),

/***/ 744:
/***/ ((module, exports, __webpack_require__) => {

var isObj = __webpack_require__(540);
var isFn = __webpack_require__(5377);
exports = function (val) {
  return isObj(val) && isFn(val.then) && isFn(val.catch);
};
module.exports = exports;

/***/ }),

/***/ 1366:
/***/ ((module, exports, __webpack_require__) => {

var objToStr = __webpack_require__(9762);
exports = function (val) {
  return objToStr(val) === '[object String]';
};
module.exports = exports;

/***/ }),

/***/ 2375:
/***/ ((module, exports) => {

exports = function (val) {
  return val === void 0;
};
module.exports = exports;

/***/ }),

/***/ 157:
/***/ ((module, exports, __webpack_require__) => {

var has = __webpack_require__(5745);
if (Object.keys && !false) {
  exports = Object.keys;
} else {
  exports = function (obj) {
    var ret = [];
    for (var key in obj) {
      if (has(obj, key)) ret.push(key);
    }
    return ret;
  };
}
module.exports = exports;

/***/ }),

/***/ 1893:
/***/ ((module, exports) => {

exports = function (arr) {
  var len = arr ? arr.length : 0;
  if (len) return arr[len - 1];
};
module.exports = exports;

/***/ }),

/***/ 5937:
/***/ ((module, exports) => {

var regSpace = /^\s+/;
exports = function (str, chars) {
  if (chars == null) return str.replace(regSpace, '');
  var start = 0;
  var len = str.length;
  var charLen = chars.length;
  var found = true;
  var i;
  var c;
  while (found && start < len) {
    found = false;
    i = -1;
    c = str.charAt(start);
    while (++i < charLen) {
      if (c === chars[i]) {
        found = true;
        start++;
        break;
      }
    }
  }
  return start >= len ? '' : str.substr(start, len);
};
module.exports = exports;

/***/ }),

/***/ 1735:
/***/ ((module, exports, __webpack_require__) => {

var safeCb = __webpack_require__(8361);
var keys = __webpack_require__(157);
var isArrLike = __webpack_require__(6421);
exports = function (obj, iterator, ctx) {
  iterator = safeCb(iterator, ctx);
  var _keys = !isArrLike(obj) && keys(obj);
  var len = (_keys || obj).length;
  var results = Array(len);
  for (var i = 0; i < len; i++) {
    var curKey = _keys ? _keys[i] : i;
    results[i] = iterator(obj[curKey], curKey, obj);
  }
  return results;
};
module.exports = exports;

/***/ }),

/***/ 5667:
/***/ ((module, exports, __webpack_require__) => {

var extendOwn = __webpack_require__(9189);
var isMatch = __webpack_require__(2032);
exports = function (attrs) {
  attrs = extendOwn({}, attrs);
  return function (obj) {
    return isMatch(obj, attrs);
  };
};
module.exports = exports;

/***/ }),

/***/ 9293:
/***/ ((module, exports) => {

exports = function () {};
module.exports = exports;

/***/ }),

/***/ 4761:
/***/ ((module, exports) => {

if (Date.now && !false) {
  exports = Date.now;
} else {
  exports = function () {
    return new Date().getTime();
  };
}
module.exports = exports;

/***/ }),

/***/ 9762:
/***/ ((module, exports) => {

var ObjToStr = Object.prototype.toString;
exports = function (val) {
  return ObjToStr.call(val);
};
module.exports = exports;

/***/ }),

/***/ 4775:
/***/ ((module, exports, __webpack_require__) => {

var isUndef = __webpack_require__(2375);
exports = function (fn, ctx, argCount) {
  if (isUndef(ctx)) return fn;
  switch (argCount == null ? 3 : argCount) {
    case 1:
      return function (val) {
        return fn.call(ctx, val);
      };
    case 3:
      return function (val, idx, collection) {
        return fn.call(ctx, val, idx, collection);
      };
    case 4:
      return function (accumulator, val, idx, collection) {
        return fn.call(ctx, accumulator, val, idx, collection);
      };
  }
  return function () {
    return fn.apply(ctx, arguments);
  };
};
module.exports = exports;

/***/ }),

/***/ 8200:
/***/ ((module, exports, __webpack_require__) => {

var isArr = __webpack_require__(2362);
var safeGet = __webpack_require__(6150);
exports = function (path) {
  if (!isArr(path)) return shallowProperty(path);
  return function (obj) {
    return safeGet(obj, path);
  };
};
function shallowProperty(key) {
  return function (obj) {
    return obj == null ? void 0 : obj[key];
  };
}
module.exports = exports;

/***/ }),

/***/ 1346:
/***/ ((module, exports) => {

exports = function (fn, startIdx) {
  startIdx = startIdx == null ? fn.length - 1 : +startIdx;
  return function () {
    var len = Math.max(arguments.length - startIdx, 0);
    var rest = new Array(len);
    var i;
    for (i = 0; i < len; i++) {
      rest[i] = arguments[i + startIdx];
    }
    switch (startIdx) {
      case 0:
        return fn.call(this, rest);
      case 1:
        return fn.call(this, arguments[0], rest);
      case 2:
        return fn.call(this, arguments[0], arguments[1], rest);
    }
    var args = new Array(startIdx + 1);
    for (i = 0; i < startIdx; i++) {
      args[i] = arguments[i];
    }
    args[startIdx] = rest;
    return fn.apply(this, args);
  };
};
module.exports = exports;

/***/ }),

/***/ 2327:
/***/ ((module, exports) => {

var regSpace = /\s+$/;
exports = function (str, chars) {
  if (chars == null) return str.replace(regSpace, '');
  var end = str.length - 1;
  var charLen = chars.length;
  var found = true;
  var i;
  var c;
  while (found && end >= 0) {
    found = false;
    i = -1;
    c = str.charAt(end);
    while (++i < charLen) {
      if (c === chars[i]) {
        found = true;
        end--;
        break;
      }
    }
  }
  return end >= 0 ? str.substring(0, end + 1) : '';
};
module.exports = exports;

/***/ }),

/***/ 8361:
/***/ ((module, exports, __webpack_require__) => {

var isFn = __webpack_require__(5377);
var isObj = __webpack_require__(540);
var isArr = __webpack_require__(2362);
var optimizeCb = __webpack_require__(4775);
var matcher = __webpack_require__(5667);
var identity = __webpack_require__(7995);
var property = __webpack_require__(8200);
exports = function (val, ctx, argCount) {
  if (val == null) return identity;
  if (isFn(val)) return optimizeCb(val, ctx, argCount);
  if (isObj(val) && !isArr(val)) return matcher(val);
  return property(val);
};
module.exports = exports;

/***/ }),

/***/ 6150:
/***/ ((module, exports, __webpack_require__) => {

var isUndef = __webpack_require__(2375);
var castPath = __webpack_require__(8081);
exports = function (obj, path) {
  path = castPath(path, obj);
  var prop;
  prop = path.shift();
  while (!isUndef(prop)) {
    obj = obj[prop];
    if (obj == null) return;
    prop = path.shift();
  }
  return obj;
};
module.exports = exports;

/***/ }),

/***/ 826:
/***/ ((module, exports) => {

exports = function (timeout) {
  return new Promise(function (resolve) {
    return setTimeout(resolve, timeout);
  });
};
module.exports = exports;

/***/ }),

/***/ 2629:
/***/ ((module, exports) => {

exports = function (str, prefix) {
  return str.indexOf(prefix) === 0;
};
module.exports = exports;

/***/ }),

/***/ 8423:
/***/ ((module, exports) => {

exports = function (str) {
  str = ('__' + str + '__').split('');
  var mode = {
    singleQuote: false,
    doubleQuote: false,
    regex: false,
    blockComment: false,
    lineComment: false,
    condComp: false
  };
  for (var i = 0, l = str.length; i < l; i++) {
    if (mode.regex) {
      if (str[i] === '/' && str[i - 1] !== '\\') mode.regex = false;
      continue;
    }
    if (mode.singleQuote) {
      if (str[i] === "'" && str[i - 1] !== '\\') mode.singleQuote = false;
      continue;
    }
    if (mode.doubleQuote) {
      if (str[i] === '"' && str[i - 1] !== '\\') mode.doubleQuote = false;
      continue;
    }
    if (mode.blockComment) {
      if (str[i] === '*' && str[i + 1] === '/') {
        str[i + 1] = '';
        mode.blockComment = false;
      }
      str[i] = '';
      continue;
    }
    if (mode.lineComment) {
      if (str[i + 1] === '\n') mode.lineComment = false;
      str[i] = '';
      continue;
    }
    mode.doubleQuote = str[i] === '"';
    mode.singleQuote = str[i] === "'";
    if (str[i] === '/') {
      if (str[i + 1] === '*') {
        str[i] = '';
        mode.blockComment = true;
        continue;
      }
      if (str[i + 1] === '/') {
        str[i] = '';
        mode.lineComment = true;
        continue;
      }
      mode.regex = true;
    }
  }
  return str.join('').slice(2, -2);
};
module.exports = exports;

/***/ }),

/***/ 8149:
/***/ ((module, exports, __webpack_require__) => {

var isArrLike = __webpack_require__(6421);
var map = __webpack_require__(1735);
var isArr = __webpack_require__(2362);
var isStr = __webpack_require__(1366);
exports = function (val) {
  if (!val) return [];
  if (isArr(val)) return val;
  if (isArrLike(val) && !isStr(val)) return map(val);
  return [val];
};
module.exports = exports;

/***/ }),

/***/ 4:
/***/ ((module, exports, __webpack_require__) => {

var isNil = __webpack_require__(4034);
exports = function (fn) {
  if (isNil(fn)) return '';
  try {
    return fnToStr.call(fn);
  } catch (e) {}
  try {
    return fn + '';
  } catch (e) {}
  return '';
};
var fnToStr = Function.prototype.toString;
module.exports = exports;

/***/ }),

/***/ 5833:
/***/ ((module, exports, __webpack_require__) => {

var ltrim = __webpack_require__(5937);
var rtrim = __webpack_require__(2327);
var regSpace = /^\s+|\s+$/g;
exports = function (str, chars) {
  if (chars == null) return str.replace(regSpace, '');
  return ltrim(rtrim(str, chars), chars);
};
module.exports = exports;

/***/ }),

/***/ 9138:
/***/ ((module, exports, __webpack_require__) => {

var filter = __webpack_require__(4151);
exports = function (arr, cmp) {
  cmp = cmp || isEqual;
  return filter(arr, function (item, idx, arr) {
    var len = arr.length;
    while (++idx < len) {
      if (cmp(item, arr[idx])) return false;
    }
    return true;
  });
};
function isEqual(a, b) {
  return a === b;
}
module.exports = exports;

/***/ }),

/***/ 7147:
/***/ ((module, exports, __webpack_require__) => {

var each = __webpack_require__(1680);
exports = function (obj) {
  var ret = [];
  each(obj, function (val) {
    ret.push(val);
  });
  return ret;
};
module.exports = exports;

/***/ }),

/***/ 446:
/***/ ((module, exports, __webpack_require__) => {

var now = __webpack_require__(4761);
exports = function (condition) {
  var timeout = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var interval = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 250;
  function evalCondition() {
    return new Promise(function (resolve, reject) {
      try {
        resolve(condition());
      } catch (e) {
        reject(e);
      }
    });
  }
  return new Promise(function (resolve, reject) {
    var startTime = now();
    var pollCondition = function () {
      evalCondition().then(function (val) {
        var elapsed = now() - startTime;
        if (val) {
          resolve(val);
        } else if (timeout && elapsed >= timeout) {
          reject(Error('Wait timed out after '.concat(timeout, ' ms')));
        } else {
          setTimeout(pollCondition, interval);
        }
      }, reject);
    };
    pollCondition();
  });
};
module.exports = exports;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";

// EXTERNAL MODULE: ../../node_modules/.pnpm/@babel+runtime@7.25.6/node_modules/@babel/runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__(4515);
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/startWith.js
var startWith = __webpack_require__(2629);
var startWith_default = /*#__PURE__*/__webpack_require__.n(startWith);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/endWith.js
var endWith = __webpack_require__(6920);
var endWith_default = /*#__PURE__*/__webpack_require__.n(endWith);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/contain.js
var contain = __webpack_require__(6997);
var contain_default = /*#__PURE__*/__webpack_require__.n(contain);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/fnParams.js
var fnParams = __webpack_require__(4583);
var fnParams_default = /*#__PURE__*/__webpack_require__.n(fnParams);
;// CONCATENATED MODULE: ./src/appservice/util.ts





var appservice_Function = __webpack_require__.g.Function;
var AsyncFunction = Object.getPrototypeOf(/*#__PURE__*/asyncToGenerator_default()(function* () {})).constructor;
function canIMock(method) {
  return !startWith_default()(method, 'on') && !startWith_default()(method, 'off');
}
function isSync(method) {
  return endWith_default()(method, 'Sync') || contain_default()(syncMethods, method);
}
var syncMethods = ['stopRecord', 'getRecorderManager', 'pauseVoice', 'stopVoice', 'pauseBackgroundAudio', 'stopBackgroundAudio', 'getBackgroundAudioManager', 'createAudioContext', 'createInnerAudioContext', 'createVideoContext', 'createCameraContext', 'createMapContext', 'canIUse', 'startAccelerometer', 'stopAccelerometer', 'startCompass', 'stopCompass', 'hideToast', 'hideLoading', 'showNavigationBarLoading', 'hideNavigationBarLoading', 'navigateBack', 'createAnimation', 'pageScrollTo', 'createSelectorQuery', 'createCanvasContext', 'createContext', 'drawCanvas', 'hideKeyboard', 'stopPullDownRefresh', 'arrayBufferToBase64', 'base64ToArrayBuffer'];
function parseFn(fnStr) {
  var result = fnParams_default()(fnStr);
  if (fnStr[fnStr.length - 1] !== '}') {
    result.push('return ' + fnStr.slice(fnStr.indexOf('=>') + 2));
  } else {
    result.push(fnStr.slice(fnStr.indexOf('{') + 1, fnStr.lastIndexOf('}')));
  }
  return result;
}
function isAppServiceRemoteDebugMode() {
  return __webpack_require__.g.__isAppServiceRemoteDebugMode__ && __webpack_require__.g.$$autoDebug;
}
function callFnWhenRemoteDebugAppservice(functionDeclaration, args, ctx) {
  var res = __webpack_require__.g.$$autoDebug.$eval('(' + functionDeclaration + ')', args, ctx);
  return res;
}
function callAsyncFnWhenRemoteDebugAppservice(_x, _x2, _x3) {
  return _callAsyncFnWhenRemoteDebugAppservice.apply(this, arguments);
}
function _callAsyncFnWhenRemoteDebugAppservice() {
  _callAsyncFnWhenRemoteDebugAppservice = asyncToGenerator_default()(function* (functionDeclaration, args, ctx) {
    var res = yield __webpack_require__.g.$$autoDebug.$eval('(' + functionDeclaration + ')', args, ctx);
    return res;
  });
  return _callAsyncFnWhenRemoteDebugAppservice.apply(this, arguments);
}
function callFn(_x4, _x5) {
  return _callFn.apply(this, arguments);
}
function _callFn() {
  _callFn = asyncToGenerator_default()(function* (functionDeclaration, args, ctx = null) {
    var fnParams = parseFn(functionDeclaration);
    var fn;
    if (startWith_default()(functionDeclaration, 'async')) {
      if (isAppServiceRemoteDebugMode()) {
        return yield callAsyncFnWhenRemoteDebugAppservice(functionDeclaration, args, ctx);
      }
      fn = AsyncFunction.apply(null, fnParams);
      return yield fn.apply(ctx, args);
    } else {
      if (isAppServiceRemoteDebugMode()) {
        return callFnWhenRemoteDebugAppservice(functionDeclaration, args, ctx);
      }
      fn = appservice_Function.apply(null, fnParams);
      return fn.apply(ctx, args);
    }
  });
  return _callFn.apply(this, arguments);
}
function callFnSync(functionDeclaration, args, ctx = null) {
  var fnParams = parseFn(functionDeclaration);
  if (isAppServiceRemoteDebugMode()) {
    return callFnWhenRemoteDebugAppservice(functionDeclaration, args, ctx);
  }
  var fn = appservice_Function.apply(null, fnParams);
  return fn.apply(ctx, args);
}
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/last.js
var last = __webpack_require__(1893);
var last_default = /*#__PURE__*/__webpack_require__.n(last);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/isUndef.js
var isUndef = __webpack_require__(2375);
var isUndef_default = /*#__PURE__*/__webpack_require__.n(isUndef);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/isFn.js
var isFn = __webpack_require__(5377);
var isFn_default = /*#__PURE__*/__webpack_require__.n(isFn);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/trim.js
var trim = __webpack_require__(5833);
var trim_default = /*#__PURE__*/__webpack_require__.n(trim);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/toArr.js
var toArr = __webpack_require__(8149);
var toArr_default = /*#__PURE__*/__webpack_require__.n(toArr);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/concat.js
var concat = __webpack_require__(9481);
var concat_default = /*#__PURE__*/__webpack_require__.n(concat);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/bind.js
var bind = __webpack_require__(2494);
var bind_default = /*#__PURE__*/__webpack_require__.n(bind);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/clone.js
var clone = __webpack_require__(5048);
var clone_default = /*#__PURE__*/__webpack_require__.n(clone);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/waitUntil.js
var waitUntil = __webpack_require__(446);
var waitUntil_default = /*#__PURE__*/__webpack_require__.n(waitUntil);
;// CONCATENATED MODULE: ./src/common/bridge.ts

var jsBridge = __webpack_require__.g.WeixinJSBridge;
var isReady = false;
var callbacks = [];
__webpack_require__.g.__wxConfig.clientDebug = true;
function ready() {
  isReady = true;
  for (var i = 0, len = callbacks.length; i < len; i++) {
    callbacks[i]();
  }
  callbacks = [];
}
var descriptor = Object.getOwnPropertyDescriptor(__webpack_require__.g, 'WeixinJSBridge');
if (jsBridge && jsBridge.on) {
  ready();
} else if (descriptor && descriptor.configurable === false) {
  waitUntil_default()(() => __webpack_require__.g.WeixinJSBridge && __webpack_require__.g.WeixinJSBridge.on, 5000, 50).then(() => {
    jsBridge = __webpack_require__.g.WeixinJSBridge;
    ready();
  });
} else {
  Object.defineProperty(__webpack_require__.g, 'WeixinJSBridge', {
    set(val) {
      if (val && val.on) {
        jsBridge = val;
        ready();
      }
    },
    get() {
      return jsBridge;
    },
    configurable: true
  });
}
/* harmony default export */ const bridge = ({
  on(...args) {
    return jsBridge.on(...args);
  },
  publish(...args) {
    return jsBridge.publish(...args);
  },
  invoke(...args) {
    if (__webpack_require__.g.__isAppServiceRemoteDebugMode__ && args[0] === 'sendAutoMessage') {
      var _global$__debugMessag;
      (_global$__debugMessag = __webpack_require__.g.__debugMessager) === null || _global$__debugMessag === void 0 ? void 0 : _global$__debugMessag.sendToDevtools(args[0], args[1]);
    }
    return jsBridge.invoke(...args);
  },
  subscribe(...args) {
    return jsBridge.subscribe(...args);
  },
  onReady(cb) {
    if (isReady) {
      cb();
    } else {
      callbacks.push(cb);
    }
  }
});
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/each.js
var each = __webpack_require__(1680);
var each_default = /*#__PURE__*/__webpack_require__.n(each);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/noop.js
var noop = __webpack_require__(9293);
var noop_default = /*#__PURE__*/__webpack_require__.n(noop);
;// CONCATENATED MODULE: ./src/common/serviceGlobal.ts


var serviceGlobal = {};
var serviceGlobal_callbacks = [];
var serviceGlobal_isReady = false;
var origPassWAServiceGlobal = __webpack_require__.g.__passWAServiceGlobal__ || (noop_default());
__webpack_require__.g.__passWAServiceGlobal__ = function (__WAServiceGlobal__) {
  each_default()(__WAServiceGlobal__, (val, key) => {
    serviceGlobal_isReady = true;
    if (key !== 'Protect') {
      serviceGlobal[key] = val;
    }
  });
  if (serviceGlobal_isReady) {
    serviceGlobal_callbacks.forEach(callback => {
      callback(serviceGlobal);
    });
    serviceGlobal_callbacks = [];
  }
  origPassWAServiceGlobal(__WAServiceGlobal__);
};
/* harmony default export */ function common_serviceGlobal(callback) {
  if (!serviceGlobal_isReady) {
    serviceGlobal_callbacks.push(callback);
  } else {
    callback(serviceGlobal);
  }
}
;// CONCATENATED MODULE: ./src/common/url.config.ts
var CGI_DOMAIN_ONLINE = 'https://servicewechat.com/';
var CGI_DOMAIN_RDM = 'https://wxardm.weixin.qq.com/';
var MP_DOMAIN = 'https://mp.weixin.qq.com/';
var CGI_DOMAIN = CGI_DOMAIN_ONLINE;
var urlConfig = {
  jsLoginURL: `${CGI_DOMAIN}wxa-dev-logic/jslogin`,
  jsRefreshSessionURL: `${CGI_DOMAIN}wxa-dev-logic/jsrefresh_session`,
  jsOperateWXDATAURL: `${CGI_DOMAIN}wxa-dev-logic/jsoperatewxdata`,
  jsAuthorizeURL: `${CGI_DOMAIN}wxa-dev-logic/jsauthorize`,
  jsAuthorizeConfirmURL: `${CGI_DOMAIN}wxa-dev-logic/jsauthorize-confirm`,
  getUserPhoneNumber: `${CGI_DOMAIN}wxa-dev-logic/jsgetuserwxphone`,
  checkWeRunState: `${CGI_DOMAIN}wxa-dev-logic/checkwerunstate`,
  getUserAutoFillData: `${CGI_DOMAIN}wxa-dev-logic/getuserfillinfo`,
  setUserAutoFillData: `${CGI_DOMAIN}wxa-dev-logic/saveuserfillinfo`,
  deleteUserAutoFillData: `${CGI_DOMAIN}wxa-dev-logic/deleteuserfillinfo`,
  requestAuthUserAutoFillData: `${CGI_DOMAIN}wxa-dev-logic/authuserfillinfo`,
  clearUserAutoFillInfo: `${CGI_DOMAIN}wxa-dev-logic/clearuserfillinfo`,
  batchGetCardInfoURL: `${MP_DOMAIN}debug/cgi-bin/webdebugger/getcarditeminfo`,
  batchAddCardURL: `${MP_DOMAIN}debug/cgi-bin/webdebugger/acceptcarditem`
};
var errcodeConfig = {
  ILLEGAL_URL: -2005,
  NOT_LIMITS: -1024,
  NOT_LIMITS_QY: -1025,
  NOT_LIMITS_CARD: -1026,
  NOT_LOGIN: 41001,
  INVALID_TOKEN: 40001,
  INVALID_LOGIN: 42001,
  NEED_CONFORM: -12000,
  AUTH_DENY: -12006,
  SCOPE_UNAUTHORIZED: -12007,
  INVALID_CODE: 10010,
  INVALID_CARD_ID: 10023
};
;// CONCATENATED MODULE: ./src/appservice/sdk/utils.ts


var ____wxConfig__ = __webpack_require__.g.__wxConfig;
var _requestSkipCheckDomain;
var autoTestInfo = {};
var appid;
common_serviceGlobal(g => {
  var _wxConfig__$debugL;
  autoTestInfo = (____wxConfig__ === null || ____wxConfig__ === void 0 ? void 0 : (_wxConfig__$debugL = ____wxConfig__.debugLaunchInfo) === null || _wxConfig__$debugL === void 0 ? void 0 : _wxConfig__$debugL.autoTest) || {};
  console.log('autoTestInfo..', autoTestInfo);
  _requestSkipCheckDomain = g.__appServiceSDK__._requestSkipCheckDomain;
  appid = autoTestInfo.appid;
});
var request = options => {
  var {
    success,
    fail,
    complete
  } = options;
  var urlSplit = (options.url || '').split('?');
  var urlResult = urlSplit[0];
  var query = [`newticket=${autoTestInfo.newticket}`, `appid=${autoTestInfo.appid}`, `clientversion=${autoTestInfo.clientversion}`];
  if (autoTestInfo.testuser) {
    query.push(`testuser=${autoTestInfo.testuser}`);
  }
  options.url = `${urlResult}?${query.join('&')}`;
  if (success || fail || complete) {
    return _requestSkipCheckDomain(options);
  } else {
    return new Promise((resolve, reject) => {
      _requestSkipCheckDomain({
        ...options,
        success: resolve,
        fail: reject
      });
    });
  }
};
var getAppid = () => {
  return appid;
};
function authorizeRequest(api, isAllowed, scopes, callback, otherRes) {
  request({
    url: `${urlConfig.jsAuthorizeConfirmURL}`,
    method: 'POST',
    data: {
      scope: scopes,
      opt: isAllowed ? 1 : 2
    },
    success: res => {
      var body = res.data;
      var errMsg = 'fail request error';
      if (body.baseresponse && body.baseresponse.errcode === 0) {
        if (isAllowed) {
          errMsg = 'ok';
        } else {
          errMsg = 'fail auth deny';
        }
      }
      return callback({
        errMsg: `${api}:${errMsg}`,
        ...otherRes
      });
    }
  });
}
;// CONCATENATED MODULE: ./src/appservice/sdk/account.sdk.ts



function login(api, args, callback) {
  return request({
    url: `${urlConfig.jsLoginURL}`,
    method: 'POST',
    data: {
      scope: ['snsapi_base']
    },
    success: res => {
      var body = res.data;
      callback({
        errMsg: `${api}:ok`,
        code: body.code
      });
    },
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function refreshSession(api, args, callback) {
  return request({
    url: `${urlConfig.jsRefreshSessionURL}`,
    method: 'POST',
    data: {
      scope: ['snsapi_base']
    },
    success: res => {
      var body = res.data;
      callback({
        errMsg: `${api}:ok`,
        expireIn: body.session_expire_in,
        err_code: body.baseresponse.errcode
      });
    },
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function operateWXDataConfirm(api, args, callback, options) {
  var isAllowed = true;
  var scopeList = options.scopeList;
  return request({
    url: `${urlConfig.jsOperateWXDATAURL}`,
    method: 'POST',
    data: {
      data: JSON.stringify(args.data || {}),
      grant_scope: scopeList[0].scope,
      opt: isAllowed ? 1 : 2
    },
    success: res => {
      var body = res.data;
      return callback({
        errMsg: `${api}:ok`,
        data: JSON.parse(body.data)
      });
    }
  });
}
function operateWXData(_x, _x2, _x3) {
  return _operateWXData.apply(this, arguments);
}
function _operateWXData() {
  _operateWXData = asyncToGenerator_default()(function* (api, args, callback) {
    var reqBody = {
      data: JSON.stringify(args.data || {})
    };
    if (args.data.api_name === 'webapi_plugin_setauth') {
      reqBody.ext_info = {
        source_env: 2
      };
    }
    return request({
      url: `${urlConfig.jsOperateWXDATAURL}`,
      method: 'POST',
      data: reqBody,
      success: res => {
        var body = res.data;
        var baseresponse = body.baseresponse;
        if (baseresponse) {
          var errcode = body.baseresponse.errcode;
          if (errcode === 0) {
            var respData = JSON.parse(body.data);
            return callback({
              errMsg: `${api}:ok`,
              data: respData
            });
          }
          if (errcode === errcodeConfig.NEED_CONFORM) {
            return operateWXDataConfirm(api, args, callback, {
              imageUrl: body.appicon_url,
              appName: body.appname,
              scopeList: [body.scope]
            });
          }
          if (errcode === errcodeConfig.SCOPE_UNAUTHORIZED) {
            return callback({
              errMsg: `${api}:fail ${baseresponse.errmsg}`
            });
          }
          return callback({
            errMsg: `${api}:fail ${baseresponse.errmsg}`,
            err_code: errcode
          });
        } else {
          callback({
            errMsg: `${api}:fail no baseresponse`
          });
        }
      },
      fail: () => {
        callback({
          errMsg: `${api}:fail response fail`
        });
      }
    });
  });
  return _operateWXData.apply(this, arguments);
}
function authorize(api, args, callback) {
  return request({
    url: `${urlConfig.jsAuthorizeURL}`,
    method: 'POST',
    data: {
      scope: args.scope || []
    },
    success: res => {
      var body = res.data;
      var baseresponse = body.baseresponse;
      if (baseresponse) {
        var errcode = baseresponse.errcode;
        if (errcode === 0) {
          return callback({
            errMsg: `${api}:ok`,
            body
          });
        }
        if (errcode === errcodeConfig.NEED_CONFORM) {
          var scopeList = body.scope_list || [];
          var isAllowed = true;
          var alloewScopeList = [];
          scopeList.forEach(item => {
            alloewScopeList.push(item.scope);
          });
          return authorizeRequest(api, isAllowed, scopeList, callback);
        }
      }
    },
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function openWeRunSetting(api, args, callback) {
  return request({
    url: `${urlConfig.checkWeRunState}`,
    method: 'POST',
    data: {
      appid: getAppid()
    },
    success: res => {
      var body = res.data;
      var state = body.state;
      if (state === 1) {
        return callback({
          errMsg: `${api}:ok`
        });
      }
      var wording = body.wording || 'USER_NOT_OPEN_WECHAT_MOVEMENT';
      return callback({
        errMsg: `${api}:fail ${wording}`
      });
    },
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
var accountSDK = (/* unused pure expression or super */ null && ({
  login,
  refreshSession,
  operateWXData,
  authorize,
  openWeRunSetting
}));
;// CONCATENATED MODULE: ./src/appservice/sdk/phone.sdk.ts



function getPhoneNumber(api, args, callback) {
  request({
    url: `${urlConfig.getUserPhoneNumber}`,
    method: 'POST',
    data: {
      appid: getAppid()
    },
    success: function () {
      var _ref = asyncToGenerator_default()(function* (res) {
        var body = res.data;
        console.log('getPhoneNumber', body);
        var baseresponse = body.jsapi_baseresponse;
        var errcode = baseresponse ? parseInt(baseresponse.errcode, 10) : -10000;
        try {
          if (errcode === 0) {
            var userData;
            var _res = {};
            try {
              _res = JSON.parse(body.data);
              userData = JSON.parse(_res.data);
            } catch (e) {
              throw new Error(`GET_DATA_ERROR ${e}`);
            }
            if (!userData || !userData.mobile) {
              throw new Error(`USER_NOT_BOUND_PHONE`);
            }
            if (userData.need_auth) {
              throw new Error(`PHONE_BOUND_NEED_VERIFIED`);
            }
            var scopeList = [body.scope];
            var isAllowed = true;
            var alloewScopeList = [];
            scopeList.forEach(item => {
              alloewScopeList.push(item.scope);
            });
            return authorizeRequest(api, isAllowed, scopeList, callback, _res);
          } else if (errcode === -12001) {
            throw new Error('APPID_NO_PERMISSIONS');
          } else if (errcode === -12004) {
            throw new Error('WX_LOGIN_FIRST');
          } else {
            throw new Error(`SYSTEM_ERROR errorCode:${errcode}`);
          }
        } catch (e) {
          return callback({
            errMsg: `${api}:fail ${e}`
          });
        }
      });
      return function success(_x) {
        return _ref.apply(this, arguments);
      };
    }(),
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
;// CONCATENATED MODULE: ./src/appservice/sdk/autofill.sdk.ts



function getUserAutoFillData(api, args, callback) {
  var bodyQuery = {
    appid: getAppid(),
    get_all_info: false,
    source: 1,
    user_info_list: args.fields,
    client_version: args.clientVersion
  };
  request({
    url: `${urlConfig.getUserAutoFillData}`,
    method: 'POST',
    data: bodyQuery,
    success: function () {
      var _ref = asyncToGenerator_default()(function* (res) {
        var body = res.data;
        callback({
          errMsg: `${api}:ok`,
          userData: body.user_info_json || '{}',
          authStatus: body.auth_status,
          authInfo: body.auth_info,
          authGroupList: body.auth_group_list
        });
      });
      return function success(_x) {
        return _ref.apply(this, arguments);
      };
    }(),
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function setUserAutoFillData(api, args, callback) {
  var bodyQuery = {
    appid: getAppid(),
    source: 1,
    user_info_json: args.dataList,
    client_version: args.clientVersion
  };
  request({
    url: `${urlConfig.getUserAutoFillData}`,
    method: 'POST',
    data: bodyQuery,
    success: function () {
      var _ref2 = asyncToGenerator_default()(function* (res) {
        var body = res.data;
        callback({
          errMsg: `${api}:ok`
        });
      });
      return function success(_x2) {
        return _ref2.apply(this, arguments);
      };
    }(),
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function deleteUserAutoFillData(api, args, callback) {
  var bodyQuery = {
    appid: getAppid(),
    source: 1,
    group_key: args.groupKey,
    group_id: args.groupId,
    client_version: args.clientVersion
  };
  request({
    url: `${urlConfig.deleteUserAutoFillData}`,
    method: 'POST',
    data: bodyQuery,
    success: function () {
      var _ref3 = asyncToGenerator_default()(function* (res) {
        var body = res.data;
        callback({
          errMsg: `${api}:ok`
        });
      });
      return function success(_x3) {
        return _ref3.apply(this, arguments);
      };
    }(),
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
function requestAuthUserAutoFillData(api, args, callback) {
  var yes = true;
  var bodyQuery = {
    appid: getAppid(),
    source: 1,
    auth_info_list: args.fields || [],
    auth_status: args.authStatus,
    user_confirm: yes,
    client_version: args.clientVersion
  };
  request({
    url: `${urlConfig.requestAuthUserAutoFillData}`,
    method: 'POST',
    data: bodyQuery,
    success: function () {
      var _ref4 = asyncToGenerator_default()(function* (res) {
        var body = res.data;
        callback({
          errMsg: `${api}:ok`
        });
      });
      return function success(_x4) {
        return _ref4.apply(this, arguments);
      };
    }(),
    fail: () => {
      callback({
        errMsg: `${api}:fail request fail`
      });
    }
  });
}
;// CONCATENATED MODULE: ./src/appservice/sdk/index.ts



var SDK = {
  login: login,
  refreshSession: refreshSession,
  operateWXData: operateWXData,
  authorize: authorize,
  openWeRunSetting: openWeRunSetting,
  getPhoneNumber: getPhoneNumber,
  getUserAutoFillData: getUserAutoFillData,
  setUserAutoFillData: setUserAutoFillData,
  deleteUserAutoFillData: deleteUserAutoFillData,
  requestAuthUserAutoFillData: requestAuthUserAutoFillData
};
;// CONCATENATED MODULE: ./src/appservice/app.ts














var __appServiceEngine__;
var ____wx;
function callWxMethod(params) {
  var {
    method,
    pluginId
  } = params;
  var wx = getWx(pluginId);
  var {
    args
  } = params;
  return new Promise((resolve, reject) => {
    if (!wx[method]) {
      return reject(Error(`wx.${method} not exists`));
    }
    if (isSync(method)) {
      resolve({
        result: wx[method].apply(wx, args)
      });
    } else {
      args = args[0] || {};
      wx[method]({
        ...args,
        success(res) {
          resolve({
            result: res
          });
        },
        fail(res) {
          reject(Error(res.errMsg.replace(`${method}:fail `, '')));
        }
      });
    }
  });
}
function callFunction(_x) {
  return _callFunction.apply(this, arguments);
}
function _callFunction() {
  _callFunction = asyncToGenerator_default()(function* (params) {
    var {
      functionDeclaration,
      args
    } = params;
    return {
      result: yield callFn(functionDeclaration, args)
    };
  });
  return _callFunction.apply(this, arguments);
}
function getCurrentPage() {
  return _getCurrentPage.apply(this, arguments);
}
function _getCurrentPage() {
  _getCurrentPage = asyncToGenerator_default()(function* () {
    return last_default()((yield getPageStack()).pageStack);
  });
  return _getCurrentPage.apply(this, arguments);
}
function getPageStack() {
  return _getPageStack.apply(this, arguments);
}
function _getPageStack() {
  _getPageStack = asyncToGenerator_default()(function* () {
    var pages = __appServiceEngine__.getCurrentPagesByDomain();
    return {
      pageStack: pages.map(page => {
        var {
          route
        } = page;
        var pluginPos = route.indexOf('__plugin__/');
        if (pluginPos > -1) {
          route = 'plugin-private://' + route.slice(pluginPos + 11);
        }
        return {
          pageId: page.__wxWebviewId__,
          path: route,
          query: page.options
        };
      })
    };
  });
  return _getPageStack.apply(this, arguments);
}
var pluginGlobals = {};
var originWxMethods = {};
var originWxMethodsGetterMap = {};
var originWxMethodsValMap = {};
function getMethodKey(method, pluginId = '') {
  return pluginId ? `${pluginId}_${method}` : method;
}
function getWx(pluginId = '') {
  if (pluginId) {
    if (!pluginGlobals[pluginId]) {
      throw Error(`Plugin ${pluginId} not exists`);
    }
    return pluginGlobals[pluginId].wx;
  }
  if (typeof wx === 'undefined') {
    return ____wx;
  }
  return wx;
}
function mockWxMethod(_x2) {
  return _mockWxMethod.apply(this, arguments);
}
function _mockWxMethod() {
  _mockWxMethod = asyncToGenerator_default()(function* (params) {
    var {
      method,
      result,
      pluginId
    } = params;
    var {
      functionDeclaration,
      args
    } = params;
    var wx = getWx(pluginId);
    if (!wx[method]) {
      throw Error(`wx.${method} not exists`);
    }
    if (!canIMock(method)) {
      throw Error(`You can't mock wx.${method}`);
    }
    if (isUndef_default()(result) && isUndef_default()(functionDeclaration)) {
      restoreWxMethod(method, pluginId);
      return;
    }
    if (!isUndef_default()(result)) {
      functionDeclaration = `function () {
      return arguments[arguments.length - 1];
    }`;
      args = [result];
    }
    var fn;
    var ctx = {
      origin: bind_default()(getOriginWxMethod(method, pluginId), wx)
    };
    if (isSync(method)) {
      fn = function () {
        return callFnSync(functionDeclaration, concat_default()(toArr_default()(arguments), args), ctx);
      };
    } else {
      fn = /*#__PURE__*/function () {
        var _ref = asyncToGenerator_default()(function* (...wxArgs) {
          var usePromise = false;
          var obj = wxArgs[0];
          if (isUndef_default()(obj)) {
            usePromise = true;
          } else if (isUndef_default()(obj.success) && isUndef_default()(obj.fail) && isUndef_default()(obj.complete)) {
            usePromise = true;
          }
          if (usePromise) {
            args = concat_default()(wxArgs, args);
            return new Promise(/*#__PURE__*/function () {
              var _ref2 = asyncToGenerator_default()(function* (resolve, reject) {
                var result = yield callFn(functionDeclaration, args, ctx);
                var errMsg = result.errMsg || `${method}:ok`;
                if (errMsg.indexOf(`${method}:ok`) > -1) {
                  resolve(result);
                } else {
                  reject(result);
                }
              });
              return function (_x4, _x5) {
                return _ref2.apply(this, arguments);
              };
            }());
          } else {
            var passedObj = clone_default()(obj);
            delete passedObj.success;
            delete passedObj.fail;
            delete passedObj.complete;
            var _result = yield callFn(functionDeclaration, concat_default()([passedObj], args), ctx);
            var errMsg = _result.errMsg || `${method}:ok`;
            if (errMsg.indexOf(`${method}:ok`) > -1) {
              if (obj.success) obj.success(_result);
            } else {
              if (obj.fail) obj.fail(_result);
            }
            if (obj.complete) obj.complete(_result);
          }
        });
        return function fn() {
          return _ref.apply(this, arguments);
        };
      }();
    }
    replaceWxMethod(method, fn, pluginId);
  });
  return _mockWxMethod.apply(this, arguments);
}
function getOriginWxMethod(method, pluginId) {
  var wx = getWx(pluginId);
  var methodKey = getMethodKey(method, pluginId);
  if (originWxMethods[methodKey]) {
    if (originWxMethodsGetterMap[methodKey]) {
      return originWxMethods[methodKey]();
    }
    return originWxMethods[methodKey];
  }
  var descriptor = Object.getOwnPropertyDescriptor(wx, method);
  if (descriptor && descriptor.get) {
    return descriptor.get();
  }
  return wx[method];
}
function restoreWxMethod(method, pluginId) {
  var wx = getWx(pluginId);
  var methodKey = getMethodKey(method, pluginId);
  if (!originWxMethods[methodKey]) return;
  var descriptor = Object.getOwnPropertyDescriptor(wx, method);
  if (descriptor) {
    if (originWxMethodsGetterMap[methodKey]) {
      Object.defineProperty(wx, method, {
        get: originWxMethods[methodKey]
      });
    } else {
      Object.defineProperty(wx, method, {
        value: originWxMethods[methodKey]
      });
    }
  } else {
    wx[method] = originWxMethods[methodKey];
  }
  delete originWxMethods[methodKey];
}
function replaceWxMethod(method, fn, pluginId) {
  var wx = getWx(pluginId);
  var methodKey = getMethodKey(method, pluginId);
  var descriptor = Object.getOwnPropertyDescriptor(wx, method);
  if (!originWxMethods[methodKey]) {
    var originMethod;
    var isGetter = false;
    var isVal = false;
    if (descriptor) {
      if (!descriptor.get) {
        isVal = true;
        originMethod = descriptor.value;
      } else {
        isGetter = true;
        originMethod = descriptor.get;
      }
    } else {
      originMethod = wx[method];
    }
    if (originMethod) {
      originWxMethodsValMap[methodKey] = isVal;
      originWxMethodsGetterMap[methodKey] = isGetter;
      originWxMethods[methodKey] = originMethod;
    }
  }
  if (descriptor) {
    Object.defineProperty(wx, method, {
      get: () => fn
    });
  } else {
    wx[method] = fn;
  }
}
var logMethods = ['log', 'info', 'warn', 'error', 'debug'];
function enableLog() {
  return _enableLog.apply(this, arguments);
}
function _enableLog() {
  _enableLog = asyncToGenerator_default()(function* () {
    logMethods.forEach(method => {
      var origin = console[method];
      console[method] = function (...args) {
        bridge.invoke('sendAutoMessage', {
          method: 'App.logAdded',
          params: {
            type: method,
            args
          }
        });
        if (isFn_default()(origin)) {
          origin.apply(console, args);
        }
      };
    });
  });
  return _enableLog.apply(this, arguments);
}
function addBinding(_x3) {
  return _addBinding.apply(this, arguments);
}
function _addBinding() {
  _addBinding = asyncToGenerator_default()(function* (params) {
    var {
      name
    } = params;
    var bindingFunction = function (...args) {
      bridge.invoke('sendAutoMessage', {
        method: 'App.bindingCalled',
        params: {
          name,
          args
        }
      });
    };
    if (__webpack_require__.g.__isAppServiceRemoteDebugMode__ && __webpack_require__.g.$$autoDebug) {
      var _global$$$autoDebug;
      (_global$$$autoDebug = __webpack_require__.g.$$autoDebug) === null || _global$$$autoDebug === void 0 ? void 0 : _global$$$autoDebug.setSubContextGlobalFunctions(name, bindingFunction);
    } else {
      __webpack_require__.g[name] = bindingFunction;
    }
  });
  return _addBinding.apply(this, arguments);
}
function exit() {
  return _exit.apply(this, arguments);
}
function _exit() {
  _exit = asyncToGenerator_default()(function* () {
    bridge.invoke('exitMiniProgram', {});
  });
  return _exit.apply(this, arguments);
}
function captureScreenshot() {
  return _captureScreenshot.apply(this, arguments);
}
function _captureScreenshot() {
  _captureScreenshot = asyncToGenerator_default()(function* () {
    return new Promise((resolve, reject) => {
      function throwErr() {
        reject(Error(`fail to capture screenshot`));
      }
      bridge.invoke('private_captureScreen', {}, /*#__PURE__*/function () {
        var _ref3 = asyncToGenerator_default()(function* (res) {
          var {
            errMsg
          } = res;
          if (contain_default()(errMsg, `:ok`)) {
            var {
              tempFilePath
            } = res;
            getOriginWxMethod('saveFile')({
              tempFilePath,
              success(res) {
                var fs = getOriginWxMethod('getFileSystemManager')();
                var savedFilePath = res.savedFilePath;
                fs.readFile({
                  filePath: savedFilePath,
                  encoding: 'base64',
                  success(res) {
                    getOriginWxMethod('removeSavedFile')({
                      filePath: savedFilePath
                    });
                    resolve({
                      data: res.data
                    });
                  },
                  fail() {
                    throwErr();
                  }
                });
              },
              fail() {
                throwErr();
              }
            });
          } else {
            throwErr();
          }
        });
        return function (_x6) {
          return _ref3.apply(this, arguments);
        };
      }());
    });
  });
  return _captureScreenshot.apply(this, arguments);
}
var app_wxConfig_ = __webpack_require__.g.__wxConfig;
common_serviceGlobal(g => {
  var _appServiceEngine__, _appServiceEngine__$_, _wxConfig__$debugL;
  __appServiceEngine__ = g.__appServiceEngine__;
  ____wx = g.wx;
  var createPluginGlobal = (_appServiceEngine__ = __appServiceEngine__) === null || _appServiceEngine__ === void 0 ? void 0 : (_appServiceEngine__$_ = _appServiceEngine__.__getCreatePluginGlobal) === null || _appServiceEngine__$_ === void 0 ? void 0 : _appServiceEngine__$_.call(_appServiceEngine__);
  var setCreatePluginGlobal = __appServiceEngine__.__setCreatePluginGlobal;
  setCreatePluginGlobal === null || setCreatePluginGlobal === void 0 ? void 0 : setCreatePluginGlobal((pluginId, pluginVersion) => {
    var pluginGlobal = createPluginGlobal === null || createPluginGlobal === void 0 ? void 0 : createPluginGlobal(pluginId, pluginVersion);
    pluginGlobals[pluginId] = pluginGlobal;
    return pluginGlobal;
  });
  g.Reporter.registerErrorListener(msg => {
    var lines = msg.split('\n');
    if (trim_default()(lines[0]) !== 'MiniProgramError') return;
    msg = lines[2];
    msg = trim_default()(msg.replace(/^((Type)|(Range)|(Reference)|(Syntax))?Error:/, ''));
    bridge.invoke('sendAutoMessage', {
      method: 'App.exceptionThrown',
      params: {
        message: msg,
        stack: lines.slice(2).join('\n')
      }
    });
  });
  if (app_wxConfig_ !== null && app_wxConfig_ !== void 0 && (_wxConfig__$debugL = app_wxConfig_.debugLaunchInfo) !== null && _wxConfig__$debugL !== void 0 && _wxConfig__$debugL.autoTest) {
    var originInvoke = g.WeixinJSBridge.invoke;
    Object.defineProperty(g.WeixinJSBridge, 'invoke', {
      value(...argsArr) {
        var [name, args, callback, keepOriginalParams] = argsArr;
        if (SDK[name]) {
          return SDK[name](name, args, callback);
        }
        return originInvoke.apply(g.WeixinJSBridge, argsArr);
      }
    });
    g.WeixinJSBridge.subscribe('callAutoInvoke', argsInvoke => {
      var {
        name,
        args,
        callbackId
      } = argsInvoke;
      var callback = res => {
        g.WeixinJSBridge.publish('callbackAutoInvoke', {
          callbackId,
          res: res
        });
      };
      if (SDK[name]) {
        return SDK[name](name, args, callback);
      }
    });
  }
});
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/isPromise.js
var isPromise = __webpack_require__(744);
var isPromise_default = /*#__PURE__*/__webpack_require__.n(isPromise);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/safeGet.js
var safeGet = __webpack_require__(6150);
var safeGet_default = /*#__PURE__*/__webpack_require__.n(safeGet);
;// CONCATENATED MODULE: ./src/appservice/page.ts



var page_appServiceEngine_;
common_serviceGlobal(g => {
  page_appServiceEngine_ = g.__appServiceEngine__;
});
function setData(params) {
  var {
    pageId,
    data
  } = params;
  var page = getPage(pageId);
  return new Promise(resolve => {
    page.setData(data, () => {
      resolve();
    });
  });
}
function getData(params) {
  var {
    pageId,
    path
  } = params;
  var page = getPage(pageId);
  var data = Object.assign({}, page.data);
  delete data.__webviewId__;
  if (path) data = safeGet_default()(data, path);
  return {
    data
  };
}
function callMethod(params) {
  var {
    method,
    args
  } = params;
  var page = getPage(params.pageId);
  return new Promise((resolve, reject) => {
    if (!page[method]) {
      return reject(Error(`page.${method} not exists`));
    }
    var result = page[method].apply(page, args);
    if (isPromise_default()(result)) {
      result.then(result => {
        resolve({
          result
        });
      }, reject);
    } else {
      resolve({
        result
      });
    }
  });
}
function getPage(pageId) {
  var pages = page_appServiceEngine_.getCurrentPagesByDomain();
  for (var page of pages) {
    if (page.__wxWebviewId__ === pageId) {
      return page;
    }
  }
  throw Error('page destroyed');
}
;// CONCATENATED MODULE: ./src/appservice/element.ts





var exparser;
var __virtualDOM__;
common_serviceGlobal(g => {
  exparser = g.exparser;
  __virtualDOM__ = g.__virtualDOM__;
});
function element_callMethod(params) {
  var {
    nodeId,
    method,
    args,
    pageId
  } = params;
  var host = __virtualDOM__.getNodeById(nodeId, pageId);
  if (!host) return;
  return new Promise((resolve, reject) => {
    var caller = exparser.Element.getMethodCaller(host);
    if (!caller[method]) {
      return reject(Error(`component.${method} not exists`));
    }
    var result = exparser.safeCallback('Event Handler', caller[method], caller, args, host);
    if (isPromise_default()(result)) {
      result.then(result => {
        resolve({
          result
        });
      }, reject);
    } else {
      resolve({
        result
      });
    }
  });
}
function element_getData(params) {
  var {
    nodeId,
    pageId,
    path
  } = params;
  var host = __virtualDOM__.getNodeById(nodeId, pageId);
  var data = host.data;
  if (path) data = safeGet_default()(data, path);
  return {
    data
  };
}
function element_setData(params) {
  var {
    nodeId,
    pageId,
    data
  } = params;
  var host = __virtualDOM__.getNodeById(nodeId, pageId);
  host.setData(data);
}
function callContextMethod(params) {
  var {
    nodeId,
    videoId,
    pageId,
    method,
    args
  } = params;
  var compInst;
  if (nodeId) {
    compInst = __virtualDOM__.getNodeById(nodeId, pageId);
  } else {
    compInst = getPage(pageId);
  }
  var context;
  if (videoId) {
    context = getOriginWxMethod('createVideoContext')(videoId, compInst);
  } else {
    throw Error('id is not provided');
  }
  return {
    result: context[method].apply(context, args)
  };
}
;// CONCATENATED MODULE: ./src/appservice/methods.ts



var methods = {
  'App.callWxMethod': callWxMethod,
  'App.callFunction': callFunction,
  'App.getCurrentPage': getCurrentPage,
  'App.getPageStack': getPageStack,
  'App.mockWxMethod': mockWxMethod,
  'App.enableLog': enableLog,
  'App.addBinding': addBinding,
  'App.exit': exit,
  'App.captureScreenshot': captureScreenshot,
  'Page.setData': setData,
  'Page.getData': getData,
  'Page.callMethod': callMethod,
  'Element.callMethod': element_callMethod,
  'Element.getData': element_getData,
  'Element.setData': element_setData,
  'Element.callContextMethod': callContextMethod
};
/* harmony default export */ const appservice_methods = (methods);
// EXTERNAL MODULE: ../../node_modules/.pnpm/licia@1.29.0/node_modules/licia/sleep.js
var sleep = __webpack_require__(826);
var sleep_default = /*#__PURE__*/__webpack_require__.n(sleep);
;// CONCATENATED MODULE: ./src/appservice/index.ts







bridge.onReady(/*#__PURE__*/asyncToGenerator_default()(function* () {
  bridge.on('onAutoMessageReceive', /*#__PURE__*/function () {
    var _ref2 = asyncToGenerator_default()(function* (msg) {
      var {
        method,
        params,
        id
      } = msg;
      var resultMsg = {
        id
      };
      if (!isUndef_default()(params.pageId) && !appservice_methods[method]) {
        try {
          getPage(params.pageId);
          bridge.publish('sendAutoMessage', msg, [params.pageId]);
          return;
        } catch (e) {
          resultMsg.error = {
            message: e.message
          };
        }
      } else {
        try {
          resultMsg.result = yield appservice_callMethod(method, params);
        } catch (e) {
          resultMsg.error = {
            message: e.message
          };
        }
      }
      bridge.invoke('sendAutoMessage', resultMsg);
    });
    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }());
  bridge.subscribe('sendAutoMessage', resultMsg => {
    bridge.invoke('sendAutoMessage', resultMsg);
  });
  yield waitUntil_default()(() => __webpack_require__.g.getCurrentPages && __webpack_require__.g.getCurrentPages().length > 0, 0, 50);
  yield sleep_default()(1000);
  bridge.invoke('sendAutoMessage', {
    method: 'App.initialized',
    params: {
      from: __webpack_require__.g.__isAppServiceRemoteDebugMode__ ? 'appservice' : 'devtools'
    }
  });
}));
function appservice_callMethod(_x2, _x3) {
  return _callMethod.apply(this, arguments);
}
function _callMethod() {
  _callMethod = asyncToGenerator_default()(function* (method, params) {
    if (appservice_methods[method]) {
      return (yield appservice_methods[method](params)) || {};
    } else {
      throw Error(`appservice ${method} unimplemented`);
    }
  });
  return _callMethod.apply(this, arguments);
}
})();

/******/ })()
;